# Source: https://www.oscarwylee.com.au/netta-optical.html

# Netta
1
## Frame Design of Netta Glasses
The frame design of Oscar Wylee’s Netta glasses is characterised by a square-round shape, nose pads and a TR90 and metal frame. Netta glasses are a women’s, statement frame that will work for any occasion, whether the wearer wants to liven up their work style or complement a fun outfit for a night out.
$169    
In stock
Only %1 left
2 pairs from $199
Discount auto-applied at checkout
3 pairs from $249
Discount auto-applied at checkout
Qty
Add to cart
Book an eye test
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
excluding prescription lenses
## About Netta Frames
If you love the shape of Aries and the subtlety of Drew, then
Netta is for you. The perfect combo of luxury and low-key.
| Frame fit | Measurements |
| --- | --- |
| MEDIUM | 53 - 18 - 140 |
These measurements mean lens width, bridge, and temple length in
millimetres (mm). They can be found on the inside of the temple
arm. If you already have a pair that you like, you can compare it
to these measurements.
### Made from Stainless Steel
Oscar Wylee’s Netta frame is a women’s, square-round glasses frame
that is perfect for medium-width faces and those with round and
oval face shapes. The Netta frame is a stylish, widely wearable
frame suited to many personal styles. The main specs of Oscar
Wylee’s Netta glasses frame including
dimensions, shape, materials, lenses, nose fit and hinges
are listed below.
| Netta Frame Features | Netta Frame Description | Dimensions | Shape | Materials | Lenses | Nose Fit | Hinges |
| --- | --- | --- | --- | --- | --- | --- | --- |
| The dimensions of the Netta frame are measured in millimetres
(mm) and are 53 - 18 - 140, meaning the lens width is 53 mm,
the bridge is 18 mm and the temple length is 140 mm. |
| The Netta frame is a square-round shape, well suited to
medium-width faces. |
| Netta glasses are made from TR90 and metal. |
| The lenses that can be used in the Netta frame are optical
lenses, which include single vision and multifocal lenses and
non-prescription lenses, which are plain and can have a filter
like a blue light filter applied. |
| Netta glasses are fitted with nose pads. |
| The hinges in Netta frames are normal hinges, also known as
standard or barrel hinges. |
Show All
### What Inspired the Frame Design of Oscar Wylee’s
Netta Glasses?
The Oscar Wylee Netta frame design was inspired by current
fashion trends as square-round glasses shapes are often in
fashion.
## What to Know
About Oscar Wylee’s Netta Glasses?
There are many aspects of the Oscar Wylee Netta frames that
customers should know about, so they can decide whether this
is the right frame for them. The Netta frame is a women’s
square-round-shaped frame. Oscar Wylee’s Netta frame is
suitable for many face shapes but is particularly compatible
with round and oval face shapes. The Netta frame’s simple
design means that they are fashionable all year round. Netta
glasses feature the standard
[parts of glasses](https://www.oscarwylee.com.au/glasses/eye/part-of-glasses)
such as a rim, temples, lenses, normal hinges and nose pads.
### What are the
Types of Temple Tips or Earpieces Included with
Oscar Wylee’s Netta Glasses?
The type of temple tips or earpieces included in Oscar Wylee’s
Netta Glasses are made from cupronickel.
### What Type of Nose Bridge do Oscar Wylee’s Serge
Small Glasses Have?
The type of nose bridge included in Oscar Wylee’s Netta frame
is nose pads.
### What Type of Nose Pads are Included with Oscar
Wylee’s Netta Glasses?
Oscar Wylee’s Netta frame includes standard nose pads. Nose
pads are great for comfort and can also be adjusted for the
perfect fit.
### What Type of Lenses do Oscar Wylee’s Netta Glasses
Have?
The type of lenses that typically come with the Oscar Wylee
Netta
[glasses frame](https://www.oscarwylee.com.au/glasses.html)
are optical lenses. Optical lenses are glasses lenses that
have a prescription within the lens to help correct vision
issues such as myopia, hyperopia and astigmatism. Netta
glasses can also come with non-prescription lenses, with
add-ons such as a blue light filter. Netta frames are
currently unavailable as sunglasses online, however, customers
can customise in-store and add on tint or polarisation.
### What Material is Used for the Rim of Oscar Wylee’s
Netta Glasses?
The materials used for the rim of Oscar Wylee’s Netta glasses
frames are TR90 and stainless steel. The rim refers to the
part of a glasses frame that holds the lenses.
### What Type of Hinges are Included with Oscar Wylee’s
Netta Glasses?
The type of hinges included with Oscar Wylee’s Netta frames
are normal hinges, also known as standard or barrel hinges.
These hinges have many interlocking loops that are stabilised
with a small screw.
## What Face Types are Most Suitable for Oscar Wylee’s
Netta Glasses?
The face types that are most suitable for Oscar Wylee’s Netta
frame are round and oval face shapes. The Netta frame is a
square-round shape, which complements the structure of round
and oval faces. The softly structured, square-round Netta
frame helps to balance the features of an
[oval face shape](https://www.oscarwylee.com.au/glasses/face-shapes/oval)
or a
[round face shape](https://www.oscarwylee.com.au/glasses/face-shapes/round), bringing the eyes and brows forward in a flattering way. A
square-round shape can also bring balance to the face by
providing some structure. Although there are many
[glasses for face shapes](https://www.oscarwylee.com.au/glasses/face-shapes)
that may be considered more aesthetically suitable than those
mentioned above, it is important that people also choose the
frames that make them feel most comfortable, and represent
their style.
## What Size Options are Available for Oscar Wylee’s
Netta Glasses?
The size options available for Oscar Wylee’s Netta frame are a
medium-fit frame across all colours.
## What Materials are Used to Create Oscar Wylee’s
Netta Glasses?
The materials used to create the Oscar Wylee Netta frame are
TR90 and metal. The rim is made from TR90 and stainless steel,
the nose bridge is made from cupronickel, the temples are made
from stainless steel and the temple tips are made from
cupronickel.
## What’s Included
## What's Included
Each pair of glasses comes with a stylish frame case and lens cloth. We offer free shipping across Australia and 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects.
* Free Shipping for Australian Orders
* 1 Year Warranty on frames and lenses
* Scratch resistance lens coating on all prescriptions
* UV-proof coating on all prescriptions
* Stylish case and cloth
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
## Make and Materials
The frames then go through cleaning and strict quality control, and many pairs of crafting hands to be hand-assembled and polished. After your frames have gone through the production process, they are individually examined and packed before making their way to you!As part of our durable frame family, some of our most popular styles, are now in stainless steel. These frames are hypoallergenic, corrosion resistant, light weight, and not sensitive to temperature changes.
## Warranty Information
### Warranty Information
### Warranty Information
Oscar Wylee provides a 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects. 
We will repair or replace faulty or defective frames or lenses free of charge for warranty claims made within 1 year of the delivery.
We also offer repairs or replacement for problems experienced with vision during everyday use for claims made within 30 days of delivery. If the same product has been discontinued or is no longer available, then we may offer an exchange for a similar product or a refund.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Find a Store Location](https://www.oscarwylee.com.au/locations/full-store-list.html)
Recommended
1. [](https://www.oscarwylee.com.au/aries-optical.html)
[Aries](https://www.oscarwylee.com.au/aries-optical.html)
Champagne
2. [](https://www.oscarwylee.com.au/peggy-optical.html)
[Peggy](https://www.oscarwylee.com.au/peggy-optical.html)
Blush Pink
3. [](https://www.oscarwylee.com.au/drew-optical.html)
[Drew](https://www.oscarwylee.com.au/drew-optical.html)
Clear Crystal