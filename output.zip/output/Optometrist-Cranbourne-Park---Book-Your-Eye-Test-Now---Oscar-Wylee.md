# Source: https://www.oscarwylee.com.au/locations/optometrist-cranbourne-park.html

# Optometrist Cranbourne Park
Cranbourne Park Shopping CentreSP 107, 125 High StreetCranbourne VIC 3977
* Next to Forever New
Opening hours
Monday9:00am - 5:30pm
Tuesday9:00am - 5:30pm
Wednesday9:00am - 5:30pm
Thursday9:00am - 9:00pm
Friday9:00am - 9:00pm
Saturday9:00am - 5:00pm
Sunday10:00am - 5:00pm
*Store hours reflect local standard trading hours and exclude public holidays
[Visit our Cranbourne Park Google Business page for directions, reviews, and updates.](https://g.page/r/CW8l9jKWEt-eEBM)
Book Appointment
[Call us: (03) 5992 1712](tel:(03) 5992 1712)
[Leave a Review!](https://g.page/r/CW8l9jKWEt-eEBM/review)
Our Reviews
Senthil Nathan
22 hours ago
Sophie Walker
1 day ago
Friendly service, staff were helpful and fun helping me decide on what frames to choose. Optometrist... was lovely too
See more
Faye Clissold
1 day ago
Very helpful good service nice people thank you
Ian Warren
1 day ago
Really quick and honest
I didn't need a new prescription and was not pressured into updating my glas...ses
Highly recommend going there
See more
Jessica Tomasello
1 week ago
Mariella Kennedy
1 week ago
Friendly and knowledgeable team.  I had been there a couple of months prior and the store manager wa...s so helpful fixing the glasses that they wouldn’t fix. So thank you! Looking forward to a long partnership with Oscar Wylee!
See more
Pete Mandarino
3 weeks ago
I’ve been a loyal customer since 2015 I’ve always been looked after by the staff no matter what stor...e I go I’m treated like a king, I asked if they have special training to be like this and they said no this is how we are that goes to show that the culture created by Head office is paramount
So well done guys keep up the awesome work
Regards Pete
See more
Steve O'Hare
4 weeks ago
Friendly and professional staff
aaliariley
1 month ago
Staff member was amazing and very friendly, explained everything perfectly, the optometrist was amaz...ing and very knowledgeable and thorough also.i picked out 2 great pairs of glasses and am very happy
See more
Holly Weston
1 month ago
Steve John
1 month ago
I had an excellent experience at Oscar Wylee Cranbourne. A huge thank you to Subhan for his outstand...ing customer service. He took the time to explain everything clearly, answered all of my questions, and helped me choose a pair of frames that suited me perfectly. I never felt rushed, and his knowledge and professionalism made the whole process easy and enjoyable. It’s rare to come across someone who genuinely cares about helping customers. Highly recommend this store, and if you get the chance, ask for Subhan!
See more
The Smiths
2 months ago
Great service as always. I was really happy with my Optometrist appointment super thorough, friendly... and professional. Was great to see team member Sienna in store again, she is always super knowledgeable, helpful and authentic in her service - I have seen her at a few of the Oscar Wylee stores over the years and she's fantastic, it is hard to find exceptional customer service these days with top tier product knowledge  and she's definitely a keeper. Thanks Sienna I will definitely come in when I know you are working for my appointment.
See more
Belinda Read
2 months ago
Amazing service will definitely be going there for eye care
Allan P
2 months ago
I fully recommend oscar wylee at cranbourne park, very friendly and helpful staff and optometrist. g...reat prices as well.
See more
mandip sidhu
3 months ago
Emily Jones
3 months ago
The Cranbourne Park team are helpful, accommodating, personable and professional.
LESLIE CLISSOLD
3 months ago
Excellent service, very helpful, Very knowledgeable on what you need
Lisa
3 months ago
Chloe McNicol-Davidson
3 months ago
I cannot fault my experience at the Cranbourne store at all. Every staff member I was helped and see...n by were wonderful. I believe there was one optometrist and two sales assistants when I was in. I had the easiest and quickest time picking my frames. The sales assistant was very helpful and knowledgeable in finding what colours and styles would suit me. I was also on crutches so was very appreciative of how attentive they were, not making me stand and walk around at all.
I cannot wait to pick up my glasses! :)
See more
Eliza Matyora
3 months ago
Good service and Respect
Bobby Gye
4 months ago
Brooke Hirst
5 months ago
Yolande
5 months ago
Everyone was super friendly. I hurt my leg and they saw me in my knee brace so the staff went above ...and beyond to make sure I was comfortable and helped me so so much to manoeuvre me to be as comfortable as possible. Cannot speak highly enough.
See more
Miranda NGOSA
5 months ago
Best team ever. They were so patient with me and my newborn. You get your glasses in a timely manner.... Got my within a week but they had said 2-3 weeks. You are not rushed during the eye test like other places. Highly recommend esp for moms with kids. Also, very clean and not crowded.
See more
Vanessa Blake
5 months ago
Girls at Cranbourne store were lovely..they took they time and made sure my father and myself were h...appy. Thank you for taking the time very happy!
See more
Tegy David
5 months ago
Alin Ibrahim
5 months ago
Great service! Fatima is excellent and will look after all your optometrist needs
Helen Burke
5 months ago
Jamie Davis
5 months ago
Very friendly and professional
Jagruti Patel
5 months ago
Great service !!
Sue McCoy
6 months ago
Great experience, lovely staff.
John Allen
6 months ago
My wife and I were served by Fatima and she was extremely helpful. Our eyes were checked by Jaswini ...and she was excellent. Would have no hesitation in referring them to others.
See more
Janet Russell
6 months ago
Excellent staff
A huge variety of stock and very well priced
I will be returning again
Robyn Davis
6 months ago
The customer service was efficient and friendly everything was explained,will go back there when the... need arises.
See more
tamara schwallie
6 months ago
Was very happy with the service
Shalika Mendis
6 months ago
Service was great
Beverley Short
6 months ago
Polite and professional
Rex Maverick
6 months ago
The service was ok, basically as you would expect. I was annoyed at the number of emails and texts I... received telling I have an appointment, an appointment tomorrow an appointment in an hour. Even though I was merely steps from the shop I received messages.
See more
Brian Walsh
6 months ago
Amy Windsor
7 months ago
Came in this morning for an eye test and the team were absolutely lovely! The optometrist was knowle...dgeable and kind, and Fatima, who helped me with the frames, was so friendly and helpful,  a real asset to the team. I was really impressed with the overall experience and can’t wait to pick up my glasses in a few weeks. Thanks again!
See more
Harsha Kandibanda
7 months ago
Jaswini did a great job, very happy with the test.
Roshin Mathew
7 months ago
Kaa Te (Kaatee)
7 months ago
Great service and punctual. Give great advice on which glasses are better to get for your frame of f...ace. Good price and great range of glasses.
See more
Phillipa Jupp
7 months ago
Walked past the shop in Frankston and browsed glasses.  Was unable to book a time that suited but wa...s able to get into the Cranbourne store for an appointment. I highly recommend the staff at both stores being extra helpful with booking times and choosing my frames. The optometrist was really good too and understood my eye issues perfect. I highly recommend going here.
See more
mahsa Hardi
7 months ago
Perfect timing and care
Highly recommended
Chris Rayeroux
8 months ago
Couldn't be any better, quicker &amp; simpler.
Chelsea Broadbent
8 months ago
Excellent customer service and a great selection of frames
Deb Ellaby
8 months ago
Seamless testing, pleasant staff. Funky frames to choose from at reasonable prices. That's why I go ...back each year.
See more
suzanne leone
8 months ago
The assistant behind the counter was full of knowledge and very helpful. She was funny and very plea...sent. The lady who did the eye testing was lovely too!
I will definitely go back!
It is nice to get served by people who are genuinely nice and know what they are doing! Thank you and Merry Christmas.
Sue &amp; Vinnie ????????
See more
Karen English
8 months ago
What a fabulous, friendly professional team. Just awesome!
## Find an Optometrist in Cranbourne Park With Oscar Wylee
Our Oscar Wylee store is located in Cranbourne Park Shopping Centre, close to Cranbourne Racecourse and a pleasant 15-minute walk from Cranbourne Station. Oscar Wylee Cranbourne Park offers bulk billed eye tests to valid Medicare cardholders. With an optometrist on-site to perform eye tests, you can check your eye health, update your prescription, and find your new favourite pairs of glasses on the same day! 
Cranbourne Park Shopping Centre is home to over 150 retailers and services for you to discover as well as many nice restaurants and cafes in the area. If you have time to do some exploring after your appointment in Oscar Wylee Cranbourne Park, we recommend you visit the Cranbourne Royal Botanic Gardens. You can walk through natural bushland and experience the beauty and diversity of the Australian landscape. Choose our Oscar Wylee Cranbourne Park optometrist for essential eye care processes.        
Meet Our Team
* Optometrist
* Store Manager
Our Services
* Bulk Billed Eye Examinations
* Professional Frame Styling
* Frame Adjustments and Repairs
* Visual Fields Testing
* Digital Retinal Scanning
* Children's Testing for Kids Over 6
Show All
## Find an Optometrist in Cranbourne, Melbourne for an Eye Health Test
For great eye care services including eye tests and prescription updates, you can find many optometrists in Cranbourne, Melbourne. At Oscar Wylee Cranbourne, we have dedicated and skilled optometrists performing bulk billed eye tests as part of Australia’s Medicare system. Our eye tests will assess a patient’s vision and check their eye health for any signs of eye disease. The average price range for an optometrist in Cranbourne can vary depending on factors such as the patient’s overall health and visual needs.
At Oscar Wylee Cranbourne, we have stylish frames that you can choose for your optical glasses, prescription sunglasses or non-prescription eyewear. While we do not have an eye doctor in-store, our optometrist and optical dispenser are equipped to provide high-quality eye health tests in Cranbourne.
## How to Find an Optometrist in Cranbourne, Melbourne?
To find an optometrist in Cranbourne, Melbourne, you can take certain steps that can help make it easier for you such as searching online, assessing the store’s opening hours and finding the directions to your chosen location. The steps on how to find an optometrist in Cranbourne are listed below.
1. Search online using the phrase, Cranbourne optometrist near me. This can also be done here on the website via our locations page.
2. Click on the Oscar Wylee link, which will take you directly to our Cranbourne optometrist store page.
3. See the store’s opening hours and where the store is located specifically.
4. Use the Cranbourne Google Business page link located under store hours to see the directions on how to get to the store.
You can also find an optometrist in Cranbourne, Melbourne by searching the keywords optometrist near me. If you have locations enabled on your smartphone and you’re in the Cranbourne area, our Oscar Wylee Cranbourne store page should appear easily for you to click on.
### Is it Hard to Get an Eye Appointment in Cranbourne, Melbourne?
No, it is not hard to get an eye appointment in Cranbourne. You can easily book an appointment to see an Oscar Wylee optometrist in Cranbourne right here on this page. At Oscar Wylee we have highly qualified optometrists available for bulk billed eye appointments, which can be booked online, over the phone, or in-store.
#### How to Compare Optometrists in Cranbourne to Each Other?
To compare optometrists in Cranbourne, you can use factors such as eye tests offered, health fund coverage, lens types and add-ons and eyewear offered. To take care of your vision and eye health, it is important to receive an eye test at least once every two years. There are different types of tests that can be performed in an eye test and not all optometrists may offer the same tests. Health funds can be used to help cover some of the cost of your frames and lenses. To find out if your health fund is accepted at a Cranbourne optometrist in Melbourne, visit their website. In the case of Oscar Wylee, we accept all major health funds and provide on-the-spot claims in-store. There are many different lens options available for prescription glasses such as single vision, multifocal and high index lenses. Most optometrists in Cranbourne will offer these lenses although it is good to make sure. There are also lens add-ons available to enhance your glasses such as anti-reflective and blue light filters. Finally, if you are looking to purchase a pair of glasses after your eye test, you can compare the different styles and colours you are interested in from the optometrists in Cranbourne, Melbourne. Oscar Wylee offers a wide range of frames with vintage and modern inspirations in bold colours and subtle designs.
#### How to Find an Eyeglasses Shop in Cranbourne, Melbourne?
To find a glasses store in Cranbourne, you can try to follow these simple steps including searching online, selecting a convenient location and looking at their health insurance policies. The steps on how to find a glasses store in Cranbourne, Melbourne are listed below.
1. Search online using the phrase, glasses store in Cranbourne. This will provide you with various options for glasses stores in the whole Cranbourne, Melbourne area.
2. Select a glasses store that is most convenient for you to travel to.
3. Click the link to find out more information such as opening hours, exact location and directions to the glasses store in Cranbourne.
4. Read their health insurance policies to ensure you know what health benefits you can access.
Our Oscar Wylee glasses store in Cranbourne, Melbourne offers primary eye care services such as comprehensive eye tests as well as other services performed by an optometrist and offers prescription and non-prescription eyewear.
##### Is it Possible to Purchase Prescribed Sunglasses in Cranbourne, Melbourne, Without Seeing an Optometrist?
Yes and no, it is possible to [purchase prescribed sunglasses](https://www.oscarwylee.com.au/sunglasses.html) in Cranbourne, Melbourne without seeing an optometrist if you already have a prescription that has not expired. If your prescription is expired, you can book an eye test to receive an updated or new prescription which will require you to see an optometrist. This will ensure your prescription sunglasses are appropriate for your visual needs.
## Where is the Oscar Wylee Cranbourne Optometrist Located in Melbourne?
The Oscar Wylee Cranbourne optometrist is located in the Cranbourne Park Shopping Centre, next to Forever New. Cranbourne is located in the City of Casey local government area, approximately 43 km south-east of Melbourne CBD.
### What is the Phone Number of Oscar Wylee Cranbourne Optometrist Store?
The Oscar Wylee Cranbourne optometrist store phone number is (03) 5992 1712. You can contact the Oscar Wylee Cranbourne store between the hours of 9 am and 5:30 pm from Monday to Wednesday, 9 am and 9 pm on Thursdays and Fridays, 9 am and 5 pm on Saturdays and 10 am and 5 pm on Sundays.
### What are the Reviews for Oscar Wylee Cranbourne Optometrist in Melbourne?
The many reviews for Oscar Wylee Cranbourne optometrist in Melbourne, left by our various customers can be found here on the website and online when you search for Oscar Wylee Cranbourne optometrist. The reviews for Oscar Wylee Cranbourne optometrist are listed below.
* Simone Morris-Garton:  I was greeted by two lovely staff, one male and one female. The test went great and a gentleman assisted me with trying on glasses and now I can’t wait to get them. Very good experience for the first time.
* Cara Thompson:  Fantastic service, felt very comfortable. Great help to pick glasses and style.
* Nikki Webb:  Lovely girls. This was my first eye test and the whole process was easy and dare I say fun.
* Bailey Blockley:  I had a great experience getting my eyes tested, the people were knowledgeable, helpful and kind. Thank you.
#### What Treatments or Eye Care Processes are Done in the Oscar Wylee Cranbourne Optometrist Location?
The treatments or eye care processes done in the Oscar Wylee Cranbourne optometrist Melbourne location include a tonometry test, a digital photograph, a slit lamp exam and a refraction test. Additional tests that may also be performed can include a visual field test and a dilated fundus exam. The treatments or eye-care processes that are done in the Oscar Wylee Cranbourne optometrist Melbourne location are listed below.
* A Tonometry Test: An optometrist or optical dispenser will conduct a tonometry test which involves the use of a machine that will release small puffs of air into your eyes. This will assist with measuring pressure in the eye.
* A Digital Photograph: An optometrist or optical dispenser may take a digital photograph of your eye which can be kept on record to use in future appointments to evaluate any changes to your eye.
* Slit Lamp Test: A slit lamp test can be used to evaluate your eye health, by examining your cornea and iris which are the anterior and posterior of the eye.
* Refraction Test: During a refraction test, an optometrist will have you view an image through different lenses and ask you to confirm which helps you see the image clearer.
* Visual Field Test: A visual field test can assist with assessing your peripheral vision, which may be beneficial for identifying any signs of glaucoma.
* Dilated Fundus Exam: A dilated fundus exam can help an optometrist assess your health in more detail by getting a clear view of the retina. This test is typically carried out for patients with diabetes and those who may be at risk of developing retinal damage.
## How Many Optometrists Exist in Cranbourne, Melbourne?
There are many optometrists that exist in Cranbourne, Melbourne to provide eye tests and glasses, including Oscar Wylee. The number of optometrists available in an area will typically depend on the population. At Oscar Wylee Cranbourne, we offer excellent optometry services including eye tests performed by skilled optometrists using high-quality equipment. We also have a wide range of fashion-forward frames that customers can browse in a large selection of sizes and colours. If you’re looking for an optometrist in Cranbourne, choose Oscar Wylee and we will take care of your optometry and eyewear needs.
### What are the Other Closest Optometrist Locations to Cranbourne, Melbourne in Australia?
The other closest Oscar Wylee optometrist locations to Cranbourne in Australia are Fountain Gate, Dandenong and Mornington. The locations and their distance from Cranbourne are listed below.
* Fountain Gate:  Fountain Gate is close to Cranbourne, around 13 km. The [Oscar Wylee Fountain Gate](https://www.oscarwylee.com.au/locations/optometrist-fountain-gate.html) store is located in Westfield Fountain Gate in Narre Warren, near Sportsgirl. You can visit Oscar Wylee Fountain Gate for excellent eye care and eyewear services.
* Dandenong:  Dandenong is a suburb approximately 15 km away from Cranbourne, where several optometrists are available including Oscar Wylee. [Oscar Wylee Dandenong](https://www.oscarwylee.com.au/locations/optometrist-dandenong.html) is located in the Armada Dandenong Plaza, where our dedicated team is available to provide a range of eye care services.
* Mornington:  Mornington is close to Cranbourne, around 31 km. The [Oscar Wylee Mornington](https://www.oscarwylee.com.au/locations/optometrist-mornington.html) store is located in the Mornington Central Shopping Centre, next to Telstra. Here you can have your eyes tested for a bulk billed price and also shop for a new pair of glasses.
### Bulk Billed Eye Tests in Cranbourne Park OW
Visit Oscar Wylee Cranbourne Park for some of the best optometrists in Cranbourne, Australia. Come and see the team in-store for vision testing, have your eye health checked for certain conditions and eye diseases and you can use your new or updated prescription to shop for a pair of glasses. We recommend you should have an eye test at least once every two years. Choose Oscar Wylee Cranbourne Park for all your eye health needs.
### Leading Health Funds Accepted at Oscar Wylee
Oscar Wylee in Cranbourne Park accepts major health funds for those with a valid card, so remember to bring yours to your next eye health test. Our experts can help you navigate the ins and outs of your insurance as well as process your claim in-store or provide an on-the-spot quote for Oscar Wylee frames and lenses.
### Glasses for the Fashion-Forward
Here at our Oscar Wylee store in Cranbourne Park, customers can browse on-trend and vintage-inspired frames for prescription eyeglasses and prescription sunglasses. Our experts in-store will help you choose what’s best for you, and you’ll leave our eyeglasses shop with a pair of frames that suit your face shape, personal style and prescription requirements.
Book Appointment
[Call us: (03) 5992 1712](tel:(03) 5992 1712)
[Leave a Review!](https://g.page/r/CW8l9jKWEt-eEBM/review)