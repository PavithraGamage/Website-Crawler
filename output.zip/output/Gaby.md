# Source: https://www.oscarwylee.com.au/gaby-sunglasses.html

# Gaby
1
## Frame Design of Gaby Sunglasses
The frame design of Oscar Wylee’s Gaby sunglasses is characterised by their cat eye shape, low nose bridge, and acetate frame. Gaby is a wearable women's glasses frame that will complement any outfit or event, day to night.
$169    
In stock
Only %1 left
2 pairs from $199
Discount auto-applied at checkout
3 pairs from $249
Discount auto-applied at checkout
* 2 &amp; 3 Pair pricing applies to non-prescription sunglasses only. Prescription sunglasses incur additional charges.    
[Non-Prescription](https://www.oscarwylee.com.au/gaby-sunglasses.html#)
Qty
Prescription
Book an eye test
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
excluding prescription lenses
## About Gaby Sunglasses
Funky and fierce, these cat-eye frames are sure to make a statement! Add some sass to your look with Gaby.
| Frame fit | Measurements |
| --- | --- |
| WIDE | 57 - 19 - 145 |
These measurements mean lens width, bridge, and temple length in millimetres (mm). They can be found on the inside of the temple arm. If you already have a pair that you like, you can compare it to these measurements.
### Made from Acetate
Oscar Wylee’s Gaby frame is a women's cat eye sunglasses frame that is perfect for those with heart, square, pear and diamond face shapes. The Gaby frame is a stylish and versatile frame that can be worn every day. The main specs of Oscar Wylee’s Gaby glasses frame, including dimensions, shape, materials, lenses, nose fit, and hinges are listed below.
Filter category 2 - General purpose sunglasses. Good protection against sunglare. Good UV Protection.Not suitable for driving in twilight, at night or under dull conditionsFilter category 3 (Obsidian Black &amp; Obsidian Black Matte only) - General purpose sunglasses. High protection against sunglare. Good UV Protection. Not suitable for driving in twilight, at night or under dull conditionsThis frame comes with polarised lenses. An additional $100 will be added to your order total for prescription orders.
| Gaby Frame Features | Gaby Frame Description | Dimensions | Shape | Materials | Lenses | Nose Fit | Hinges |
| --- | --- | --- | --- | --- | --- | --- | --- |
| The dimensions of the Gaby frame are measured in millimetres (mm) and are 57-19-145, meaning the lens width is 57 mm, the bridge is 19 mm, and the temple length is 145 mm. |
| Gaby is a cat eye shape, well-suited to wide faces. |
| Gaby is made from acetate. |
| The lenses that can be used in the Gaby frame are sunglass lenses, which provide UV protection. Prescription lenses are also available to purchase for the Gaby sunglass frame, both online and in-store. |
| The nose fit for Gaby is a low nose bridge. |
| The hinges in Gaby are spring hinges, which are more flexible than other types of hinges and can extend past 90 degrees. |
Show All
### What Inspired the Frame Design of Oscar Wylee's Gaby Glasses?
The Oscar Wylee Gaby frame design was inspired by current fashion trends, as cat eye shapes are often in fashion. A cat eye glasses shape is timeless; it remains popular throughout the decades while other trends come and go.
## What to Know About Oscar Wylee's Gaby Sunglasses?
There are many aspects of the Oscar Wylee Gaby frames that customers should know to decide whether this is the right frame for them. The Gaby frame is a women's cat eye sunglasses frame. Oscar Wylee’s Gaby frame is suitable for many face shapes, but particularly compatible with heart, square, pear and diamond face shapes. The Gaby frame’s simple design makes them fashionable all year round. Gaby features the standard [parts of glasses](https://www.oscarwylee.com.au/glasses/eye/part-of-glasses), such as a rim, temples, lenses, spring hinges, and a low nose bridge.
### What are the Types of Temple Tips or Earpieces Included with Oscar Wylee's Gaby Glasses?
The type of temple tips or earpieces included in Oscar Wylee’s Gaby Glasses are made from acetate.
### What Type of Nose Bridge do Oscar Wylee's Gaby Glasses Have?
The type of nose bridge included in Oscar Wylee’s Gaby frame is a low nose bridge.
### What Type of Nose Pads are Included with Oscar Wylee's Gaby Glasses?
Oscar Wylee’s Gaby frame does not include adjustable silicone nose pads.
### What Type of Lenses do Oscar Wylee's Gaby Sunglasses Have?
The lenses that can be used in the Gaby frame are sunglass lenses, which provide UV protection. UV protection lenses block harmful ultraviolet rays, safeguarding eyes from damage. The Gaby frame comes in Filter Category 2 in Tabby Tortoise. These are general purpose sunglasses. Good protection against sunglare. Good UV Protection. Not suitable for driving in twilight, at night or under dull conditions. Prescription lenses are also available for the Gaby frame, both online and in-store. The Gaby frame in Obsidian Black comes in Filter category 3. These are general purpose sunglasses with high protection against sun glare and good UV Protection. They are not suitable for driving in twilight, at night or under dull conditions.
### What Material is Used for the Rim of Oscar Wylee's Gaby Glasses?
The material used for the rim of Oscar Wylee’s Gaby glasses frames is acetate. The rim refers to the part of a glasses frame that holds the lenses.
### What Type of Hinges are Included with Oscar Wylee's Gaby Glasses?
The type of hinges included with Oscar Wylee’s Gaby frames are spring hinges. A spring hinge in a glasses frame refers to hinges that are more flexible than normal hinges and can go slightly beyond 90 degrees. Spring hinges can provide a closer fit to the face.
## What Face Types are Most Suitable for Oscar Wylee's Gaby Glasses?
The face types most suitable for Oscar Wylee’s Gaby frame are heart, square, pear and diamond face types. The Gaby frame is a cat eye shape, meaning it complements the structure of heart, square, pear and diamond faces particularly well. The cat eye Gaby frames help balance the features of a [heart face shape](https://www.oscarwylee.com.au/glasses/face-shapes/heart), [square face shape](https://www.oscarwylee.com.au/glasses/face-shapes/square), [pear face shape](https://www.oscarwylee.com.au/glasses/face-shapes/pear) and [diamond face shape](https://www.oscarwylee.com.au/glasses/face-shapes/diamond), bringing the eyes and brows forward in a flattering way. Although there are many different [glasses for face shapes](https://www.oscarwylee.com.au/glasses/face-shapes) that may be considered more aesthetically suitable, it is important that people also choose frames that make them feel most comfortable and represent their personal style.
## What Size Options are Available for Oscar Wylee's Gaby Glasses?
The size options available for Oscar Wylee’s Gaby frame are a wide-frame fit across all colours.
## What Materials are Used to Create Oscar Wylee's Gaby Glasses?
The material used to create the Oscar Wylee Gaby frame is acetate. Acetate, also known as cellulose acetate, is a bioplastic made from cotton fibres or wood pulp. At Oscar Wylee, acetate glasses are made by adding a dye to cellulose acetate, which is rolled into a sheet. The shape of the glasses is then cut from this sheet.
## What’s Included
## What's Included
Each pair of glasses comes with a stylish frame case and lens cloth. We offer free shipping across Australia and 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects.
* Free Shipping for Australian Orders
* 1 Year Warranty on frames and lenses
* Scratch resistance lens coating on all prescriptions
* UV-proof coating on all prescriptions
* Stylish case and cloth
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
## Make and Materials
The frames then go through cleaning and strict quality control, and many pairs of crafting hands to be hand-assembled and polished. After your frames have gone through the production process, they are individually examined and&nbsp;packed before making their way to you!Also known as cellulose acetate, these frames are traditionally hand-crafted by skilled craftsmen, with each frame passing through numerous stages of production and are hand-polished to ensure a glorious lustre.
## Warranty Information
### Warranty Information
### Warranty Information
Oscar Wylee provides a 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects. 
We will repair or replace faulty or defective frames or lenses free of charge for warranty claims made within 1 year of the delivery.
We also offer repairs or replacement for problems experienced with vision during everyday use for claims made within 30 days of delivery. If the same product has been discontinued or is no longer available, then we may offer an exchange for a similar product or a refund.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Find a Store Location](https://www.oscarwylee.com.au/locations/full-store-list.html)