# Source: https://www.oscarwylee.com.au/bryce-sunglass.html

[Skip to the end of the images gallery](#gallery-next-area)
[Skip to the beginning of the images gallery](#gallery-prev-area)
# Bryce
1
## Frame Design of Bryce Sunglasses
The frame design of Oscar Wylee’s Bryce sunglasses is characterised by their oval and round shape, adjustable nose pad fit, and stainless steel frame. Bryce is a wearable unisex glasses frame that will complement any outfit or event, day to night.
Prescription
Choose your lenses
What do you use your glasses for?
Distance
For being able to see far away objects clearly. Distance glasses are ideal for activities such as driving and watching TV.                
Reading
For magnifying nearby objects. These are ideal for close-up activities such as reading books and working on the computer.                
Multifocal Lenses
For clarity in both distance and reading vision. Multifocal lenses are helpful for those who require a certain prescription strength for reading and a different prescription strength for distance.                    
We currently do not offer multifocal lenses for purchase online, as they require an in-store fitting. To complete an order with multifocal lenses, visit us at your nearest Oscar Wylee store.
[Find a location](https://www.oscarwylee.com.au/locations/full-store-list.html/)
Please note that we cannot accept expired prescriptions. If your prescription has expired, [book an eye test](https://www.oscarwylee.com.au/booking/) with us.        
Add your prescription
back
I’m an existing customer                        We'll use your prescription we have on file, or contact you if more info is needed.
We'll use your prescription we have on file, or contact you if more info is needed.                    
Upload a photo of it                        This is the quickest option!
Please upload an image (in jpg, png or pdf) of your prescription.                    
images over 800px high or wide, will be resized before saving
Send it to us later                        Email us your prescription after checkout.
You can send us your prescription by:
|
|
| Email:[[email&nbsp;protected]](/cdn-cgi/l/email-protection#fc95929a93bc938f9f9d8e8b85909999d29f9391) |
Don't forget to include your prescription and the email address that you will be entering during checkout step.
Have us call your optometrist                        We will get your prescription from your optometrist.
Have us call your optometrist
Enter in your optometrist’s information, and we’ll reach out to obtain your prescription information.
Patient’s full name
Patient’s date of birth
Optometrist’s business name
Optometrist’s phone number
Choose another method to add prescription
Lens Options
Your Lenses
Pupillary Distance (PD)                            
[What is Pupillary Distance?](https://dj3im2gm3txew.cloudfront.net/pub/media/catalog/PD_measurement_tool.pdf)
I have 2 PD values
Select your PD (Right)25.025.526.026.527.027.528.028.529.029.530.030.531.031.532.032.533.033.534.034.535.035.536.036.537.037.538.0                                    
Select your PD (Left)25.025.526.026.527.027.528.028.529.029.530.030.531.031.532.032.533.033.534.034.535.035.536.036.537.037.538.0                                    
Select your PD505152535455565758596061626364656667686970717273747576                                
I confirm that this information is correct.
Pupillary Distance (PD)                            
[What's Pupillary Distance?](https://dj3im2gm3txew.cloudfront.net/pub/media/catalog/PD_measurement_tool.pdf)
I have 2 PD values
Select your PD (Right)25.025.526.026.527.027.528.028.529.029.530.030.531.031.532.032.533.033.534.034.535.035.536.036.537.037.538.0                                    
Select your PD (Left)25.025.526.026.527.027.528.028.529.029.530.030.531.031.532.032.533.033.534.034.535.035.536.036.537.037.538.0                                    
Select your PD505152535455565758596061626364656667686970717273747576                                
I confirm that this information is correct.
### Lens Thickness
Standard                            1.5 index lens
Recommended for prescriptions for power +/- 3.00
INCLUDED                            
Extra Thin                            1.61 index lens
Recommended for prescriptions for power +/- 3.00 to +/- 4.00
+$110                    
Super Thin                            1.67 index lens
Recommended for prescriptions for power +/- 4.00 to +/- 5.00
+$160                    
Ultimate Thin                            1.74 index lens
Recommended for strong prescriptions, power higher than +/- 5.00
+$260                    
Sun Protection
800px 
Tinted Lenses
Tinted lenses for style and comfort
+$30
Grey
Category 3
Brown
Category 3
Green
Category 3
800px 
Gradient Tint Lenses
Lenses that are darker on top and lighter below
+$30
Grey
Category 2
Brown
Category 2
Green
Category 2
800px 
Polarised Lenses
Polarised lenses for enhanced clarity
+$100
Grey
Category 3
Brown
Category 3
Green
Category 3
800px 
Photochromic and Transitions® Lenses
Lenses that darken in sunlight
from
$100
Adaptive Lenses
Changes from clear to darker opacity to adapt to light conditions.                                    
+$100
Grey
Category 3
Transitions® Gen S™
Transitions® branded photochromic lenses, quickly change from clear to a darker opacity to adapt to light conditions.                                    
+$160
Grey
Category 3
Brown
Category 3
Ruby
Category 3
Sapphire
Category 3
Graphite Green
Category 3
Amethyst
Category 3
Emerald
Category 3
Amber
Category 3
ⓘ
What are Lens Categories?
* Filter category 2:
General purpose sunglasses. Good protection against sun-glare. Good UV protection. Not suitable for driving in twilight or at night or under dull conditions.
* Filter category 3:
General purpose sunglasses. High protection against sun-glare. Good UV protection. Not suitable for driving in twilight or at night or under dull conditions.
Lens Add Ons
None
Anti-Reflective*
Reduces annoying reflection
Improves cosmetic appearance
Scratch resistant hard coating
INCLUDED
Premium Anti-Reflective*
Highly recommended
Reduces annoying reflections for clearer vision
Scratch and smudge resistant, anti-static
Improves cosmetic appearance
Can reduce eye strain due to glare
+$10
*on the back of sunglasses lenses only            
Review Your Selections
Free domestic shipping with every order
Edit Selections
Discounts will be calculated at checkout
$169    
In stock
Only %1 left
2 pairs from $199
Discount auto-applied at checkout
3 pairs from $249
Discount auto-applied at checkout
* 2 &amp; 3 Pair pricing applies to non-prescription sunglasses only. Prescription sunglasses incur additional charges.    
[Non-Prescription](https://www.oscarwylee.com.au/bryce-sunglass.html#)
Qty
Prescription
Book an eye test
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
excluding prescription lenses
## About Bryce Sunglasses
Bryce is a classic that will never go out of style. Simple in silhouette but full of charm. The perfect everyday sunglass.
| Frame fit | Measurements |
| --- | --- |
| WIDE | 56 - 21 - 145 |
These measurements mean lens width, bridge, and temple length in millimetres (mm). They can be found on the inside of the temple arm. If you already have a pair that you like, you can compare it to these measurements.
### Made from Stainless Steel
Oscar Wylee’s Bryce frame is a unisex oval and round sunglasses frame that is perfect for those with square, oval, heart, pear, and diamond face shapes. The Bryce frame is a sleek and versatile frame that can be worn every day. The main specs of Oscar Wylee’s Bryce glasses frame, including dimensions, shape, materials, lenses, nose fit, and hinges are listed below.
Filter category 3 - General purpose sunglasses. High protection against sunglare. Good UV Protection.Not suitable for driving in twilight, at night or under dull conditionsThis frame comes with polarised lenses. An additional $100 will be added to your order total for prescription orders.
| Bryce Frame Features | Bryce Frame Description | Dimensions | Shape | Materials | Lenses | Nose Fit | Hinges |
| --- | --- | --- | --- | --- | --- | --- | --- |
| The dimensions of the Bryce frame are measured in millimetres (mm) and are 56 - 21 - 145, meaning the lens width is 56 mm, the bridge is 21 mm, and the temple length is 145 mm. |
| Bryce is an oval and round shape, well-suited to wide faces. |
| Bryce is made from stainless steel. |
| The lenses that can be used in the Bryce frame are sunglass lenses, which provide UV protection. Prescription lenses are also available to purchase for the Bryce sunglass frame, both online and in-store. |
| The nose fit for Bryce is characterised by adjustable nose pads. |
| The hinges in Bryce are normal hinges, also known as standard or barrel hinges. These provide strength and smooth movement connecting the frame's arms and lenses. |
Show All
### What Inspired the Frame Design of Oscar Wylee's Bryce Glasses?
The Oscar Wylee Bryce frame design was inspired by current fashion trends, as oval and round shapes are often in fashion. An oval and round glasses shape is timeless; it remains popular throughout the decades while other trends come and go.
## What to Know About Oscar Wylee's Bryce Sunglasses?
There are many aspects of the Oscar Wylee Bryce frames that customers should know to decide whether this is the right frame for them. The Bryce frame is a unisex, oval and round sunglasses frame. Oscar Wylee’s Bryce frame is suitable for many face shapes, but particularly compatible with square, oval, heart, pear, and diamond face shapes. The Bryce frame’s simple design makes them fashionable all year round. Bryce features the standard [parts of glasses](https://www.oscarwylee.com.au/glasses/eye/part-of-glasses), such as a rim, temples, lenses, hinges, and nose pads.
### What are the Types of Temple Tips or Earpieces Included with Oscar Wylee's Bryce Glasses?
The type of temple tips or earpieces included in Oscar Wylee’s Bryce Glasses are made from stainless steel.
### What Type of Nose Bridge do Oscar Wylee's Bryce Glasses Have?
The type of nose bridge included in Oscar Wylee’s Bryce frame is characterised by adjustable nose pads.
### What Type of Nose Pads are Included with Oscar Wylee's Bryce Glasses?
Oscar Wylee’s Bryce frame includes adjustable silicone nose pads. Nose pads are adjustable for a perfect fit.
### What Type of Lenses do Oscar Wylee's Bryce Sunglasses Have?
The lenses that can be used in the Bryce frame are sunglass lenses, which provide UV protection. UV protection lenses block harmful ultraviolet rays, safeguarding eyes from damage. The Bryce frame comes in Filter Category 3. These are general purpose sunglasses. High protection against sunglare. Good UV protection. They are not suitable for driving in twilight, at night, or under dull conditions. Prescription lenses are also available for the Bryce frame, both online and in-store.
### What Material is Used for the Rim of Oscar Wylee's Bryce Glasses?
The material used for the rim of Oscar Wylee’s Bryce glasses frames is stainless steel. The rim refers to the part of a glasses frame that holds the lenses.
### What Type of Hinges are Included with Oscar Wylee's Bryce Glasses?
The type of hinges included with Oscar Wylee’s Bryce frames are normal hinges, also known as standard or barrel hinges. These provide strength and smooth movement connecting the frame's arms and lenses.
## What Face Types are Most Suitable for Oscar Wylee's Bryce Glasses?
The face types most suitable for Oscar Wylee’s Bryce frame are square, oval, heart, pear, and diamond face types. The Bryce frame is an oval and round shape, meaning it complements the structure of square, oval, heart, pear, and diamond faces particularly well. The oval and round Bryce frames help balance the features of a [square face shape](https://www.oscarwylee.com.au/glasses/face-shapes/square), an [oval face shape](https://www.oscarwylee.com.au/glasses/face-shapes/oval), a [heart face shape](https://www.oscarwylee.com.au/glasses/face-shapes/heart), a [pear face shape](https://www.oscarwylee.com.au/glasses/face-shapes/pear), and a [diamond face shape](https://www.oscarwylee.com.au/glasses/face-shapes/diamond), bringing the eyes and brows forward in a flattering way. Although there are many different [glasses for face shapes](https://www.oscarwylee.com.au/glasses/face-shapes) that may be considered more aesthetically suitable, it is important that people also choose frames that make them feel most comfortable and represent their personal style.
## What Size Options are Available for Oscar Wylee's Bryce Glasses?
The size options available for Oscar Wylee’s Bryce frame are a wide-fit frame across all colours.
## What Materials are Used to Create Oscar Wylee's Bryce Glasses?
The material used to create the Oscar Wylee Bryce frame is stainless steel. Stainless steel is a type of metal commonly used for glasses that is lightweight, durable and corrosion-resistant.
## What’s Included
## What's Included
Each pair of glasses comes with a stylish frame case and lens cloth. We offer free shipping across Australia and 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects.
* Free Shipping for Australian Orders
* 1 Year Warranty on frames and lenses
* Scratch resistance lens coating on all prescriptions
* UV-proof coating on all prescriptions
* Stylish case and cloth
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
## Make and Materials
The frames then go through cleaning and strict quality control, and many pairs of crafting hands to be hand-assembled and polished. After your frames have gone through the production process, they are individually examined and packed before making their way to you!As part of our durable frame family, some of our most popular styles, are now in stainless steel. These frames are hypoallergenic, corrosion resistant, light weight, and not sensitive to temperature changes.
## Warranty Information
### Warranty Information
### Warranty Information
Oscar Wylee provides a 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects. 
We will repair or replace faulty or defective frames or lenses free of charge for warranty claims made within 1 year of the delivery.
We also offer repairs or replacement for problems experienced with vision during everyday use for claims made within 30 days of delivery. If the same product has been discontinued or is no longer available, then we may offer an exchange for a similar product or a refund.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Find a Store Location](https://www.oscarwylee.com.au/locations/full-store-list.html)
Recommended
1. [](https://www.oscarwylee.com.au/kato-sunglasses.html)
[Kato](https://www.oscarwylee.com.au/kato-sunglasses.html)
Rose Gold
2. [](https://www.oscarwylee.com.au/soma-sunglasses.html)
[Soma](https://www.oscarwylee.com.au/soma-sunglasses.html)
Rose Gold
3. [](https://www.oscarwylee.com.au/haskell-sunglasses.html)
[Haskell](https://www.oscarwylee.com.au/haskell-sunglasses.html)
Rose Gold