# Source: https://www.oscarwylee.com.au/amelia-sunglasses.html

# Amelia
1
## Frame Design of Amelia Sunglasses
The frame design of Oscar Wylee’s Amelia sunglasses is characterised by a classic cat-eye shape, a high nose bridge fit and an acetate and stainless steel frame. Amelia glasses are a women's statement frame that will work for any occasion, whether the wearer wants to liven up their work style or complement an outfit for a night out.
$169    
In stock
Only %1 left
2 pairs from $199
Discount auto-applied at checkout
3 pairs from $249
Discount auto-applied at checkout
* 2 &amp; 3 Pair pricing applies to non-prescription sunglasses only. Prescription sunglasses incur additional charges.    
[Non-Prescription](https://www.oscarwylee.com.au/amelia-sunglasses.html#)
Qty
Prescription
Book an eye test
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
excluding prescription lenses
## About Amelia Frames
Amelia is rocking the retro vibes with an oversized cat-eye shape, reminiscent of timeless glamour. Perfect for those wanting to add a bit of drama to their wardrobe.
| Frame fit | Measurements |
| --- | --- |
| Medium | 52 - 22 - 145 |
These measurements mean lens width, bridge, and temple length in millimetres (mm). They can be found on the inside of the temple arm. If you already have a pair that you like, you can compare it to these measurements.
### Made from Acetate &amp; Stainless steel material
Oscar Wylee’s Amelia frame is a women's, cat-eye sunglasses frame that is perfect for heart, square, and oval face shapes. The Amelia frame is a sleek, widely wearable frame that can be worn every day. The main specs of Oscar Wylee’s Amelia glasses frame including dimensions, shape, materials, lenses, nose fit and hinges are listed below.
Filter category 2 (Butterscotch Tortoise only) - General purpose sunglasses. Good protection against sunglare. Good UV Protection. Not suitable for driving in twilight, at night or under dull conditions
Filter category 3 (Almond and Panther) - General purpose sunglasses. High protection against sunglare. Good UV Protection. Not suitable for driving in twilight, at night or under dull conditions
This frame (Almond only) comes with tinted lenses. An additional $30 will be added to your order total for prescription orders.
These frames (Butterscotch Tortoise and Panther only) come with polarised lenses. An additional $100 will be added to your order total for prescription orders.
| Amelia Frame Features | Amelia Frame Description | Dimensions | Shape | Materials | Lenses | Nose Fit | Hinges |
| --- | --- | --- | --- | --- | --- | --- | --- |
| The dimensions of the Amelia frame are measured in millimetres (mm) and are 52 - 22 - 145, meaning the lens width is 52 mm, the bridge is 22 mm and the temple length is 145 mm. |
| The Amelia frame is a cat-eye shape, well suited to medium faces. |
| Amelia glasses are made from a material called acetate and stainless steel. |
| The lenses that can be used in the Amelia frame are sunglass lenses, which provide UV 400 protection. Optical lenses are also available for the Amelia sunglass frame, however this is only available for in-store purchases. |
| The nose fit of Amelia frames is a high nose bridge fit. |
| The hinges in Amelia glasses are normal hinges, also known as standard or barrel hinges. |
Show All
### What Inspired the Frame Design of Oscar Wylee’s Amelia Glasses?
The Oscar Wylee Amelia frame design was inspired by current fashion trends as cat-eye shapes are often in fashion. A cat-eye glasses shape is timeless meaning it remains popular throughout the decades while other trends pass.
## What to Know About Oscar Wylee’s Amelia Glasses?
There are many aspects of the Oscar Wylee Amelia frames that customers should know about, so they can decide whether this is the right frame for them. The Amelia frame is a women's cat-eye-shaped frame. Oscar Wylee’s Amelia frame is suitable for many face shapes but particularly compatible with heart, square, and oval shapes. The Amelia frame’s simple design means that they are fashionable all year round. Amelia glasses feature the standard [parts of glasses such as a rim, temples, lenses, a normal hinge and a high nose bridge fit.](https://www.oscarwylee.com.au/glasses/eye/part-of-glasses)
### What are the Types of Temple Tips or Earpieces Included with Oscar Wylee’s Amelia Glasses?
The type of temple tips or earpieces included in Oscar Wylee’s Amelia Glasses are made from acetate, the same as the rest of the temple and part of the rim.
### What Type of Nose Bridge do Oscar Wylee’s Amelia Glasses Have?
The type of nose bridge included in Oscar Wylee’s Amelia frame is a high nose bridge fit.
### What Type of Nose Pads are Included with Oscar Wylee’s Amelia Glasses?
Oscar Wylee’s Amelia frame does not include adjustable silicone nose pads.
### What Type of Lenses do Oscar Wylee’s Amelia Glasses Have?
The lenses that can be used in the Amelia frame are sunglass lenses, which provide UV 400 protection. UV protection lenses block harmful ultraviolet rays, safeguarding eyes from damage. It comes in the Filter Category 3. This filter provides higher protection against sunglare. They are not suitable for use while driving at night. Prescription lenses are also available for the Amelia sunglass frame, in-store only.
### What Material is Used for the Rim of Oscar Wylee’s Amelia Glasses?
The materials used for the rim of Oscar Wylee’s Amelia glasses frames are acetate and stainless steel. The rim refers to the part of a glasses frame that holds the lenses.
### What Type of Hinges are Included with Oscar Wylee’s Amelia Glasses?
The type of hinges included with Oscar Wylee’s Easten frames are normal hinges. These provide strength and smooth movement connecting the frame’s arms and lenses.
## What Face Types are Most Suitable for Oscar Wylee’s Amelia Glasses?
The face types that are most suitable for Oscar Wylee’s Amelia frame are heart, square, and oval faces. The Amelia frame is a cat-eye shape, meaning that it complements the structure of heart, square, and oval faces particularly well. The Amelia frames help to balance the features of an [oval face shape, heart face shape, or a](https://www.oscarwylee.com.au/glasses/face-shapes/oval)[square face shape, bringing the eyes and brows forward in a flattering way. Although there are many](https://www.oscarwylee.com.au/glasses/face-shapes/square)[glasses for face shapes that may be considered more aesthetically suitable, it is important that people also choose the frames that make them feel most comfortable, and represent their personal style.](https://www.oscarwylee.com.au/glasses/face-shapes)
## What Size Options are Available for Oscar Wylee’s Amelia Glasses?
The size options available for Oscar Wylee’s Amelia frame are a medium-frame fit across all colours.
## What Materials are Used to Create Oscar Wylee’s Amelia Glasses?
The primary material used to create the Oscar Wylee Amelia frame is acetate. However, there is also stainless steel across the rim for added structural stability. Acetate, also known as cellulose acetate, is a bioplastic, made from cotton fibres or wood pulp. At Oscar Wylee, acetate glasses are made by adding a dye to cellulose acetate, which is rolled into a sheet. The shape of the glasses is then cut from this sheet.
## What’s Included
## What's Included
Each pair of glasses comes with a stylish frame case and lens cloth. We offer free shipping across Australia and 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects.
* Free Shipping for Australian Orders
* 1 Year Warranty on frames and lenses
* Scratch resistance lens coating on all prescriptions
* UV-proof coating on all prescriptions
* Stylish case and cloth
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
## Make and Materials
The frames then go through cleaning and strict quality control, and many pairs of crafting hands to be hand-assembled and polished. After your frames have gone through the production process, they are individually examined and packed before making their way to you!Also known as cellulose acetate, these frames are traditionally hand-crafted by skilled craftsmen, with each frame passing through numerous stages of production and are hand-polished to ensure a glorious lustre.
## Warranty Information
### Warranty Information
### Warranty Information
Oscar Wylee provides a 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects. We will repair or replace faulty or defective frames or lenses free of charge for warranty claims made within 1 year of the delivery. We also offer repairs or replacement for problems experienced with vision during everyday use for claims made within 30 days of delivery. If the same product has been discontinued or is no longer available, then we may offer an exchange for a similar product or a refund.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Find a Store Location](https://www.oscarwylee.com.au/locations/full-store-list.html)