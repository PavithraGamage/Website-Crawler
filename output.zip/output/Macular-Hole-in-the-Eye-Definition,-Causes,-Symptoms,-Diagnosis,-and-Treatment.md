# Source: https://www.oscarwylee.com.au/glasses/eye/macular-hole

# Macular Hole in the Eye: Definition, Causes, Symptoms, Diagnosis, and
Treatment
Published on August 16th, 2023
Updated on Month Date, 2025 
Australia
[Australia](https://www.oscarwylee.com.au/glasses/eye/macular-hole)
New Zealand

[Canada](https://oscarwylee.ca/glasses/eye/macular-hole)
Canadian French

A macular hole refers to a hole, tear or break in the macula, which is
located in the retina part of the eye. A hole in this part of the retina is
commonly caused by vitreous detachment, in which the vitreous fluid does not
cleanly separate from the macula, leaving a hole or tear, and is often
caused by ageing. Other causes of a macular hole can include retinal
detachment, eye injuries and refraction errors such as myopia. A macular
hole is diagnosed by an optometrist or other eye care professional. The
tests to diagnose a macular hole may include a dilated eye test and optical
coherence tomography (OCT). A macular hole may be treated with surgery and
the surgery for a macular hole is a vitrectomy.
Common methods to improve hand-eye coordination include practising with simple activities, practising
challenging activities, playing with certain toys, performing reaction time exercises, playing video games
and
taking up a hobby that requires hand-eye coordination. The 6 ways to improve hand-eye coordination are
listed
below.

Are You Due for an Eye Test?
Book an eye test with our Oscar Wylee optometrists who are highly trained
and passionate about providing quality eye care to our customers.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Definition](#definition)
[Causes](#causes)
[Symptoms](#symptoms)
[Treatments](#treatments)
## What is a Macular Hole in the Eye?
A macular hole in the eye
refers to a hole, a tear or a break in the macula. The macula is
located in the centre of the retina and has nerve cells that help
translate light to images and is also responsible for central vision. A
macular hole is a type of retinal hole, as the macula is part of the
retina. The answer to what is a macular hole in the eye is a hole or
opening in the macula that may interfere with central vision.
### What Part of the Eye Does Macular Hole Affect?
The part of the eye that is affected by a macular hole is
the macula and the retina. A macular hole is a hole in the
retina
[part of the eye](https://www.oscarwylee.com.au/glasses/eye/anatomy). The retina is the layer at the back of the eye that contains
photoreceptor cells. According to The Cleveland Clinic, these
photoreceptor cells react to light that enters the eye, changing this
light into electrical signals to send to the brain. The macula is
located in the middle of the retina and assists in translating light
that enters the eye into electrical signals to send to the brain.
#### What Does a Macular Hole in the Eye Look Like?
A macular hole, when examined by an optometrist or eye care
professional using specialist equipment,
may look like a circular hole, break or a tear in the surface of
the macula.
A macular hole will not be visible on the eye from the outside, as
the macula is part of the back layer of the eye. Someone looking at
the eye from the outside with no equipment will not see the hole.
According to NI Direct, a macular hole may make vision look blurry
or distorted in the earlier stages for those who have it, and
straight lines may look wavy. In later stages, vision may have a
small blank or black patch. The image below shows what a macular
hole may look like when examined up close by an eye care
professional using specialist equipment.
### How Common is a Macular Hole in the Eye?
A macular hole is
not an overly common eye condition, most often occurring in older
people.
According to Majumdar and Tripathy in their paper,
Macular Hole, the prevalence of macular holes in Australia is
around 0.2 per 1000 population. According to the NHS, macular holes
are more common in those 60 years old and above as ageing contributes
to changes in the eye, such as changes in the vitreous jelly, and may
lead to holes in the retina or a macular hole developing.
### What are the 4 Stages of a Macular Hole in the Eye?
There are four main stages of a macular hole in the eye, these are
small foveal detachment, small full thickness holes, larger full
thickness holes without vitreous separation and larger
full-thickness holes with vitreous separation,
according to the Centre for Retinal Diseases and Surgery. The four
stages of a macular hole are listed below.
* Small foveal detachment: Small
foveal detachment is generally considered to be stage 1 of a macular
hole.
* Small full thickness holes: Small
full thickness holes are considered to be stage 2 of a macular hole,
with the break in the macular less than 400 micrometres in size,
according to Majumdar S and Tripathy K in their article published in
the National Library of Medicine.
* Larger full thickness holes without vitreous separation:
Larger full thickness holes without vitreous separation are
considered stage 3 of a macular hole, with the hole in the macula
greater than 400 micrometres in size, according to the National
Library of Medicine.
* Larger full thickness holes with vitreous separation:
Larger full thickness holes with vitreous separation is the 4th
stage of a macular hole.
## What Causes a Macular Hole in the Eye?
One of the most
common causes of a macular hole in the eye is vitreous separation due
to the ageing of the eye.
The vitreous is a gel-like substance that fills the eye and helps keep
the shape of the eye. According to the NHS, as the eye ages, the
vitreous fluid can begin to separate from the retina and macula. As the
vitreous pulls away it may not do so cleanly, creating a hole or tear in
the macula, which may be known as a vitreous detachment.
Eye injuries and refraction errors such as myopia may also contribute
to the development of a macular hole, however, this is not as
common.
The exact answer to what causes a hole in the retina or a macular hole,
is most often a vitreous detachment, as a consequence of the eye ageing.
### What are the Risk Factors of a Macular Hole in the Eye?
The main risk factor for macular holes is generally
getting older. As people get older, the eye also ages and can lead
to issues with the vitreous, such as vitreous detachment, which is
one of the top causes of a macular hole in the eye.
Risk factors for getting a macular hole in the eye can also include
having shortsightedness (myopia), gender and injuries to the
eye.
The risk factors for a macular hole are listed below.
* Getting Older: Getting older and
ageing can affect parts of the eye such as the vitreous which may
lead to a macular hole if it begins to separate from the retina and
macula.
* Short-sightedness (myopia):
Short-sightedness or myopia may be a risk factor for a macular hole
due to tractional forces in the eye.
* Gender: Gender is a risk factor for
developing a macular hole as women are more likely to develop this
condition than men.
* Injuries to the eye: There is a type
of macular hole called traumatic macular hole, that is caused by
injuries or trauma to the eye. Therefore, sustaining an eye injury
can increase a person’s risk of developing a macular hole.
#### 1. Getting Older
Getting older is a risk factor for a macular hole as
an ageing eye can lead to vitreous detachment, which can cause a
macular hole.
According to the NHS, when the eye ages with the rest of the body,
the vitreous, a gel-like substance that fills the eye and keeps its
shape, can separate from the retina and macula. If the vitreous does
not separate cleanly from the macula, it may tear the macula,
leading to a macular hole.
#### 2. Short-sightedness (Myopia)
Short-sightedness also known as nearsightedness or myopia,
may be a risk factor for developing a macular hole due to the
tractional force that high levels of myopia may cause in the
eye.
According to an article by De Giacinto, Pastore, Cirigliano and
Tognetto called
Macular Hole in Myopic Eyes: A Narrative Review of the Current
Surgical Techniques,
it is stated that macular holes may develop in those that have
myopia due to tractional forces from various parts of the eye such
as the vitreomacular interface.
[Myopia or nearsightedness](https://www.oscarwylee.com.au/glasses/eye/nearsightedness)
is a refractive error, caused by either an elongated eyeball or an
overly curved cornea, in which the eye is not as capable of focusing
light onto the retina correctly, leading to issues with distance
vision.
#### 3. Gender
Gender
may be a risk factor for developing a hole in the macula, with
women more likely to have this issue than men.
According to an article by Wang J, Yu Y, Liang X, Wang Z, Qi B, and
Liu W, the female to male ratio for macular hole development is 3:1.
According to Hwang, S., Kang, S.W., Kim, S.J. et al, in an article
called
Risk factors for the development of idiopathic macular hole: a
nationwide population-based cohort study,
the authors discuss theories that the reason women are more likely
to get a macular hole than men is due to drops in oestrogen levels
when women enter menopause. It is theorised that a drop in oestrogen
causes a loss of vitreous collagen and glycosaminoglycan, which may
lead to premature vitreous detachment. However, this research is not
supported by all who study the topic, with small amounts of
epidemiological or biological evidence to support it.
#### 4. Injury to the Eye
Injuries to the eye
may be a risk factor for developing a hole in the eye due to the
trauma that an injury may cause.
Macular holes that are caused by an
[injury to the eye](https://www.oscarwylee.com.au/glasses/eye/injuries)
are called traumatic macular holes. According to the American
Academy of Ophthalmology, traumatic macular holes are generally
caused by blunt ocular trauma, with the macular hole either
presenting as soon as the trauma has happened, or weeks later.
## What are the Symptoms of a Macular Hole in the Eye?
The symptoms of a macular hole in the eye are
dependent upon what stage the macular hole is at. According to
the National Eye Institute, the symptoms of a macular hole in its
early stages are distorted or blurry vision. Straight lines may
look strange or wavy. Early signs of a macular hole can also include
trouble doing everyday activities such as writing or reading. The
macular hole symptoms for the
later stages usually revolve around issues with central vision, such
as having a blind spot or a gap in central vision.
Central vision refers to what a person sees directly in front of them.
## How Does an Eye Doctor Diagnose a Macular Hole in the Eye?
In Australia,
an eye doctor, also known as an ophthalmologist, may diagnose a
macular hole, as can an optometrist.
To diagnose a macular hole, an optometrist or ophthalmologist will first
begin with an understanding of your medical history and ask you to
describe any symptoms you may have experienced. The tests an
[eye care professional](https://www.oscarwylee.com.au/glasses/eye/doctors)
may perform to diagnose a macular hole include a dilated eye test and
optical coherence tomography (OCT) according to the National Eye
Institute. A patient may be given eye drops to dilate the pupil in order
to perform an OCT.
### Can Retinal Imaging Detect Macular Hole?
Yes, retinal imaging may help detect a macular hole.
[Retinal imaging](https://www.oscarwylee.com.au/glasses/eye/retinal-exam)
refers to a process in which a specialised camera takes digital images
of the retina. A camera will flash or low-power lasers enter the eye
through the pupil, according to The University of Edinburgh. The light
reflects off of the retina and is captured by the camera.
### Is a Macular Hole in the Eye Serious?
A macular hole
can be a serious eye condition, as it can impact a person’s central
vision and in turn their quality of life.
According to the National Eye Institute, some people with macular
holes may have mild symptoms in the early stages, and may not need
immediate treatment. However, an optometrist may recommend ongoing
observation and treatment down the line as, if a macular hole grows
bigger, it can interfere with a person’s central vision and make
everyday tasks such as driving and reading difficult.
Find Your Nearest Oscar Wylee Store
Use our store locator page to find your nearest Oscar Wylee team and
visit us in-store for eye care services including Medicare bulk billed
eye tests and new, stylish frames.
Find an Oscar Wylee store
## What are the Treatments for a Macular Hole in the Eye?
There is one primary treatment used for macular holes which is a surgery
called a vitrectomy. Some early-stage macular holes may heal on
their own, according to the University of Chicago Medicine. For those
with a macular hole in the early stages, eye care professionals may
recommend monitoring the hole, instead of treatment straight away. If a
macular hole does not heal on its own, a vitrectomy is usually required
to preserve eye health and central vision. The treatment for a macular
hole is listed below.
* Vitrectomy: A Vitrectomy is a
procedure in which a surgeon will remove the vitreous fluid from the
eye and any other tissue that is causing an issue, and insert a gas
bubble into the macular hole. According to the National Eye Institute,
this gas bubble acts as a bandage, holding the hole together until it
heals.
### Can a Macular Hole in the Eye Heal Without Surgery?
Yes,
in some cases a macular hole in the eye can heal without
surgery.
According to the Macular Disease Foundation, a macular hole that is in
its early stages may heal spontaneously without the aid of treatment,
but this is not always the case. While there is no way to treat a
macular hole naturally, it can be treated with a type of surgery
called a vitrectomy.
### Can Eye Drops Help Close a Macular Hole in the Eye?
In certain cases,
eye drops may help to close a macular hole in the eye.
According to the University of Chicago Medicine, medicated eye drops
may be prescribed to a patient to potentially help heal the macular
hole in their eye. Medicated eye drops work to heal a macular hole by
increasing fluid absorption in the retina and also by decreasing
inflammation in the eye.
### Can a Macular Hole in the Eye be Treated with Laser Surgery?
No, macular holes are
not generally treated with laser surgery. According to the
article, Laser treatment of macular holes, by Schocket,
Lakhanpal, Miao, Kelman, and Billings, laser surgery is not often used
to treat macular holes as it may cause retinal detachment.
### What Happens if a Macular Hole in the Eye is Untreated?
If a person develops a macular hole, it is very important they seek
advice from an eye care professional on how to proceed regarding
treatment. According to the National Health Service (NHS),
if a macular hole is not treated, it can lead to a decrease in
central vision and affect quality of life.
Therefore, it is crucial you have your eyes assessed if you believe
you have a macular hole in the eye or experience any symptoms of this
eye condition.
#### Do Macular Holes in the Eye Get Bigger?
Yes, according to the Macular Disease Foundation,
a macular hole in the eye can get bigger which can lead to more
vision issues.
It is important to have regular eye tests if you have a macular hole
as your optometrist can monitor its progression and assess if it is
getting any bigger.
### What to do to Prevent a Macular Hole in the Eye?
Currently, there
is no way to prevent a macular hole in the eye, according to
the American Society of Retina Specialists. Neither diet nor exercise
have shown signs of preventing a macular hole. There are certain ways
to treat and manage a macular hole such as through a type of surgery
called a vitrectomy. A person can also attempt to lower their risk of
developing a macular hole in the eye by having regular eye tests with
an optometrist as they can monitor the health of your eye and diagnose
certain eye diseases the patient may present with.
Read Macular Hole in the Eye: Definition, Causes, Symptoms, Diagnosis,
and Treatment in other Oscar Wylee regions and their languages.
Australia
[Australia](https://www.oscarwylee.com.au/glasses/eye/macular-hole)
New Zealand

[Canada](https://oscarwylee.ca/glasses/eye/macular-hole)
Canadian French

Oscar Wylee Accepts Leading Health Funds In-store
Visit Oscar Wylee for your eye care needs, and your health fund may
help cover some of the cost.
[Explore health funds](https://www.oscarwylee.com.au/health-funds.html)
Look After Your Eyes at Oscar Wylee
Book a Medicare bulk billed eye test with one of our skilled
optometrists and prioritise your eye health today.
[Book an eye test](https://www.oscarwylee.com.au/booking)