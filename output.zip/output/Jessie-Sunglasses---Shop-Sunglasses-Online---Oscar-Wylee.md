# Source: https://www.oscarwylee.com.au/jessie-sunglasses.html

# Jessie
1
## Frame Design of Jessie Sunglasses
The frame design of Oscar Wylee’s Jessie sunglasses is characterised by a classic rectangle shape, a high nose bridge fit and an acetate frame. Jessie glasses are a women's statement frame that will work for any occasion, whether the wearer wants to liven up their work style or complement an outfit for a night out.
$169    
In stock
Only %1 left
2 pairs from $199
Discount auto-applied at checkout
3 pairs from $249
Discount auto-applied at checkout
* 2 &amp; 3 Pair pricing applies to non-prescription sunglasses only. Prescription sunglasses incur additional charges.    
[Non-Prescription](https://www.oscarwylee.com.au/jessie-sunglasses.html#)
Qty
Prescription
Book an eye test
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
excluding prescription lenses
## About Jessie Frames
Jessie is our newest it girl, reminiscent of Hailey Bieber's iconic street style. Wear these sunnies on a trip to the beach or as the perfect accessory for a night out.
| Frame fit | Measurements |
| --- | --- |
| Medium | 53 - 18 - 145 |
These measurements mean lens width, bridge, and temple length in millimetres (mm). They can be found on the inside of the temple arm. If you already have a pair that you like, you can compare it to these measurements.
### Made from Acetate
Oscar Wylee’s Jessie frame is a women’s rectangle sunglasses frame that is perfect for those with round or oval face shapes. The Jessie frame is a sleek, widely wearable frame that can be worn every day. The main specs of Oscar Wylee’s Jessie glasses frame including dimensions, shape, materials, lenses, nose fit and hinges are listed below.
Filter category 2 (Cioccolato only) - General purpose sunglasses. Good protection against sunglare. Good UV Protection.Not suitable for driving in twilight, at night or under dull conditions
Filter category 3 (Cacao Tortoise and Panther only) - General purpose sunglasses. High protection against sunglare. Good UV Protection. Not suitable for driving in twilight, at night or under dull conditions 
These frames come with polarised lenses. An additional $100 will be added to your order total for prescription orders.
| Jessie Frame Features | Jessie Frame Description | Dimensions | Shape | Materials | Lenses | Nose Fit | Hinges |
| --- | --- | --- | --- | --- | --- | --- | --- |
| The dimensions of the Jessie frame are measured in millimetres (mm) and are 53 - 18 - 145, meaning the lens width is 53 mm, the bridge is 18 mm and the temple length is 145 mm. |
| The Jessie frame is a rectangle shape, well suited to medium faces. |
| Jessie glasses are made from a material called acetate. |
| The lenses that can be used in the Jessie frame are sunglass lenses, which provide UV protection. Optical lenses are also available for the Jessie sunglass frame, however this is only available for in-store purchases. |
| The nose fit of Jessie frames is a high nose bridge fit. |
| The hinges in Jessie glasses are normal hinges, also known as standard or barrel hinges. |
Show All
### What Inspired the Frame Design of Oscar Wylee’s Jessie Glasses?
The Oscar Wylee Jessie frame design was inspired by current fashion trends as rectangle shapes are often in fashion. A rectangle glass shape is timeless meaning it remains popular throughout the decades while other trends pass.
## What to Know About Oscar Wylee’s Jessie Glasses?
There are many aspects of the Oscar Wylee Jessie frames that customers should know about, so they can decide whether this is the right frame for them. The Jessie frame is a women's rectangle-shaped frame. Oscar Wylee’s Jessie frame is suitable for many face shapes but particularly compatible with round and oval face shapes. The Jessie frame’s simple design means that they are fashionable all year round. Jessie glasses feature the standard [parts of glasses](https://www.oscarwylee.com.au/glasses/eye/part-of-glasses) such as a rim, temples, lenses, hinges and a high nose bridge fit.
### What are the Types of Temple Tips or Earpieces Included with Oscar Wylee’s Jessie Glasses?
The type of temple tips or earpieces included in Oscar Wylee’s Jessie Glasses are made from acetate, the same as the rest of the temple and rim.
### What Type of Nose Bridge do Oscar Wylee’s Jessie Glasses Have?
The type of nose bridge included in Oscar Wylee’s Jessie frame is a high nose bridge fit.
### What Type of Nose Pads are Included with Oscar Wylee’s Jessie Glasses?
Oscar Wylee’s Jessie frame does not include adjustable siliconenose pads.
### What Type of Lenses do Oscar Wylee’s Jessie Glasses Have?
The lenses that can be used in the Jessie frame are sunglass lenses, which provide UV protection. UV protection lenses block harmful ultraviolet rays, safeguarding eyes from damage. Filter Category 2 is available for Cioccolato. These are general purpose sunglasses and provide good protection against sunglare. They are not suitable for use while driving at night. Prescription lenses are also available for the Jessie sunglass frame, in-store only.
### What Material is Used for the Rim of Oscar Wylee’s Jessie Glasses?
The material used for the rim of Oscar Wylee’s Jessie glasses frames is acetate. The rim refers to the part of a glasses frame that holds the lenses.
### What Type of Hinges are Included with Oscar Wylee’s Jessie Glasses?
The type of hinges included with Oscar Wylee’s Jessie frames are normal hinges. These provide strength and smooth movement connecting the frame’s arms and lenses.
## What Face Types are Most Suitable for Oscar Wylee’s Jessie Glasses?
The face types that are most suitable for Oscar Wylee’s Jessie frame are round and oval face types. The Jessie frame is a rectangle shape, meaning that it complements the structure of round and oval faces particularly well. The Jessie frames help to balance the features of an [oval face shape](https://www.oscarwylee.com.au/glasses/face-shapes/oval) or a [round face shape](https://www.oscarwylee.com.au/glasses/face-shapes/round), bringing the eyes and brows forward in a flattering way. Although there are many [glasses for face shapes](https://www.oscarwylee.com.au/glasses/face-shapes) that may be considered more aesthetically suitable, it is important that people also choose the frames that make them feel most comfortable, and represent their personal style.
## What Size Options are Available for Oscar Wylee’s Jessie Glasses?
The size options available for Oscar Wylee’s Jessie frame are a medium frame fit across all colours.
## What Materials are Used to Create Oscar Wylee’s Jessie Glasses?
The primary material used to create the Oscar Wylee Jessie frame is acetate. Acetate, also known as cellulose acetate, is a bioplastic, made from cotton fibres or wood pulp. At Oscar Wylee, acetate glasses are made by adding a dye to cellulose acetate, which is rolled into a sheet. The shape of the glasses is then cut from this sheet.
## What’s Included
## OW Case &amp; Cloth
Protective Case and Lens Cloth
Our high-quality glasses case and lens cloth are included with every purchase of an Oscar Wylee frame. The stylish, magnetic case is made from a hard shell. This sturdy and durable material keeps your glasses protected and safe, wherever you go. Ensure your lenses are clean and scratch-free with our OW microfibre cloth, specifically designed to ensure you have comfortable vision through your lenses.
Oscar Wylee offers:
* Free Shipping for Australian Orders
* 1 Year Warranty on frames and lenses
* Scratch resistance lens coating on all prescriptions
* UV-proof coating on all prescriptions
Health fund rebate: Once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. Learn more about [health funds](https://www.oscarwylee.com.au/health-funds.html).
## Make and Materials
The frames then go through cleaning and strict quality control, and many pairs of crafting hands to be hand-assembled and polished. After your frames have gone through the production process, they are individually examined and&nbsp;packed before making their way to you!Also known as cellulose acetate, these frames are traditionally hand-crafted by skilled craftsmen, with each frame passing through numerous stages of production and are hand-polished to ensure a glorious lustre.
## Warranty Information
### Warranty Information
### Warranty Information
Oscar Wylee provides a 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects. We will repair or replace faulty or defective frames or lenses free of charge for warranty claims made within 1 year of the delivery. We also offer repairs or replacement for problems experienced with vision during everyday use for claims made within 30 days of delivery. If the same product has been discontinued or is no longer available, then we may offer an exchange for a similar product or a refund.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Find a Store Location](https://www.oscarwylee.com.au/locations/full-store-list.html)