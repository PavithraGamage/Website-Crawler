# Source: https://www.oscarwylee.com.au/glasses/eye/refraction-test

# Refraction Test: Principles of Refraction Eye Exam, Benefits, Procedures
Published on May 15th, 2024
Updated on September 06th, 2024
Australia
[Australia](https://www.oscarwylee.com.au/glasses/eye/refraction-test)
[New Zealand](https://www.oscarwylee.co.nz/glasses/eye/refraction-test)
Canada
Canadian French

A refraction test, also referred to as a vision test is
normally performed as part of a routine eye test and informs the
optometrist if a patient requires prescription glasses or contact
lenses. For patients with normal vision, their cornea and lens should be capable
of refracting incoming light so it is positioned directly on the retina.
However, if you have a refractive error, the light is not bent correctly
when passing through the eye causing blurry vision. Refraction is the
bending of light when passing from one object to another, which occurs in
the eye through the cornea and lens. If you are experiencing blurry vision
and do not already use prescription glasses, it is important to have an eye
test in order to have a refraction eye exam performed. At Oscar Wylee, eye
tests are bulk billed for eligible
[Medicare](https://www.oscarwylee.com.au/eye-test/medicare) card
holders.
Prioritise Your Eye Health Today!
Our team is highly qualified to provide you with excellent optometry
services.
[Eye test near me](https://www.oscarwylee.com.au/booking)
[Definition](#definition ) [Function](#function )
[Equipment](#equipment ) [Results](#results)
## What is Refraction in an Eye Exam?
Refraction in an eye exam is defined as
a measure of what type of prescription you require or if a
prescription is needed at all. Refraction in an eye test enables the
[optometrist](https://www.oscarwylee.com.au/eye-care/optometrist)
to evaluate how well your eye bends light as it passes through the eye
and where the light lands in relation to your retina.
### What is the Purpose of Refraction in an Eye Exam?
The purpose of refraction in an eye exam is
to assess how the eye refracts light and whether you have any
refractive errors. If you do have a refractive error, the light that passes through
the eye is not correctly focused on the retina, resulting in eye
problems such as myopia (nearsightedness), hyperopia (farsightedness),
presbyopia (age-related farsightedness) and astigmatism.
## What are the Basic Steps of a Refraction Test?
The basic steps of a refraction test include an
auto-refraction or retinoscopy and a lens phoropter. The
auto-refraction or retinoscopy portion of the process is the first step
and involves measuring your distance vision by shining a light into your
eye or using an auto-refractor. This enables the optometrist to evaluate
how the light enters the eye and how the cornea and lens bend the light
for it to reach the retina. The optometrist will then get you to look
through a lens phoropter, which is a special device that features
multiple combinations of lenses and dials. Looking through the lens
phoropter will help the optometrist determine your prescription.
### How Does a Refraction Test Work?
A refraction test works
by using special instruments to examine how light rays are bent
when entering the eye, which indicates if you have any refractive
errors. An eye refraction exam begins with the optometrist using an
autorefractor or manual refraction which enables them to assess the
severity of your refractive error. The optometrist will also shine a
light in your eyes while looking through the pupil and examine how the
light reflects off the retina.
## Why Should You Undergo a Refraction Test?
You should undergo a refraction test so an optometrist can
identify any refractive errors and prescribe glasses for vision
correction
if deemed necessary. It is important to have a refraction test as part
of your regular eye test if you are experiencing any signs such as
blurry vision when looking at nearby objects or objects in the distance.
Refractive errors can develop as a result of an abnormally-shaped cornea
or lens, when the eyeball grows too long or too short and due to the
ageing of the lens according to the National Eye Institute.
## What are the Benefits of a Refraction Eye Exam?
The benefits of a refraction eye exam include identifying and
correcting refractive errors and monitoring changes to a patient’s
vision. A refraction eye exam is beneficial for detecting eye problems such
as nearsightedness, farsightedness, age-related presbyopia and
astigmatism. This allows the optometrist to prescribe the right glasses
according to your vision requirements. For patients who already use
prescription glasses, a refraction eye exam is important for monitoring
possible changes that can naturally develop over time.
## What is the Procedure for a Refraction Test?
The procedure of a refraction test
usually requires an optometrist to use certain instruments such as an
autorefractor or manual refractor, a phoropter and a Snellen chart. During a refraction test, the optometrist will examine how light
moves through the lens and cornea in the eye, which may involve a
computerised refractor or manual refractor. Using a computerised
refractor will involve looking through a special machine to determine
the amount of light reflected by the retina. The optometrist will then
position you in front of a phoropter to look through and read letters
from a chart 20 feet away. During this process, the optometrist will
swap out different lenses and ask which lens option is clearer. After
repeating this process on the other eye, the optometrist will then
create a prescription that can provide 20/20 vision.
## What Equipment is Used in Refraction Testing?
The equipment used in refraction testing can include a
phoropter, an autorefractor and a Snellen chart. A refraction
test usually involves an autorefractor, which measures the eye’s
focusing ability and helps the optometrist determine your prescription.
An auto-refractor removes the need for the patient to look at a chart or
respond to which lens option is clearer and identifies refractive errors
by observing how the light acts when entering the eye and reaching the
retina. A phoropter features multiple lenses, which the optometrist goes
through during your test to find the most suitable lens for your vision
condition. A Snellen chart has rows of letters that differ in size and
is used during a refraction test to evaluate how well you can see visual
details and distinguish between the different shapes.
## What do the Numbers in Your Prescription Mean?
The numbers in your prescription
indicate diopters, which is a unit of measurement that represents the
amount of correction you need for clear vision. Your prescription will have different columns of abbreviated terms
such as ADD (magnification required for close vision), axis, SPH
(sphere), CYL (cylinder), PD (pupillary distance) and int ADD
(intermediate ADD). The numbers in your prescription will let the
optical dispenser know what type of lenses to dispense according to your
visual needs.
[Understanding prescriptions](https://www.oscarwylee.com.au/glasses/eye/reading-eyeglasses-prescription)
can be easier when you are familiar with the different terms such as ADD
which you may have if you need reading glasses. Axis is the angle
between 0 and 180 degrees required to correct astigmatism. CYL
represents the amount of astigmatism you have denoted with a minus
symbol and is corrected using a CYL (cylindrical) lens. SPH (sphere)
signifies the amount in numerals of farsightedness denoted with a plus
symbol or nearsightedness denoted with a minus symbol. It will determine
the power of the lens you need for clear and comfortable vision. PD is
the measurement of the distance between the pupils and is used to ensure
that your lenses are positioned properly to give you clear vision. Int
ADD represents the amount of magnification required for intermediate
vision such as when looking at a computer, which is typically about 70cm
away.
## How are Eye Problems Diagnosed with a Refraction Test?
Eye problems are diagnosed through a refraction test as
they allow the optometrist to examine how the light acts when passing
through the eye and onto the retina. The optometrist is then able to
confirm whether the incoming light is bent correctly
so that it is directly on the retina. This will signify whether you have
a refractive error and how severe it is. Refractive errors include
nearsightedness (myopia), farsightedness (hyperopia), age-related
farsightedness (presbyopia) and astigmatism. Reading from a chart of
letters during your refraction test aids in indicating how well your
eyes can see details in objects.
### What Tests are Used to Diagnose Nearsightedness (Myopia)?
The tests used to diagnose nearsightedness can include a
refraction test, a visual acuity test and a retinoscopy. These
tests are normally part of a standard eye test, performed by an
optometrist. To
[diagnose nearsightedness](https://www.oscarwylee.com.au/glasses/eye/nearsightedness), an optometrist will use different tools to assess how your eyes
focus light and measure the required amount of power for your
prescription glasses. The optometrist will first examine your visual
acuity by having you read letters out loud from a chart. They will
then use a retinoscope to observe how your retina reflects light
according to the Cleveland Clinic.
### How Do Optometrists Identify Farsightedness (Hyperopia)?
Optometrists can identify farsightedness (hyperopia)
during a standard eye test.
[Diagnosing farsightedness](https://www.oscarwylee.com.au/glasses/eye/hyperopia)
(hyperopia)
usually involves a visual acuity test and a refraction test. A
visual acuity test is an eye test that determines how sharp and clear
your vision is. A visual acuity test will involve a person looking at
a chart consisting of lines of letters that decrease in size. The
patient will read the letters until their eyes cannot see clearly. The
line that a person stops at will give them a score determining their
visual acuity. A slit lamp test refers to an eye test conducted with a
microscope that has a light. A refraction test is an eye test that
will determine what prescription a person needs. An optometrist will
have their patient look through a series of different lenses with
varying magnification strengths to determine what level of vision
correction they need.
### What are the Common Methods For Detecting Astigmatism?
The common methods for detecting astigmatism usually require a
visual acuity test, an autorefraction and retinoscopy refraction
test, keratometry, pachymetry, and corneal topography. Optometrists may
[diagnose astigmatism](https://www.oscarwylee.com.au/glasses/eye/astigmatism)
if you are experiencing symptoms such as blurry or distorted vision at
all distances. Similar to the process of diagnosing nearsightedness
and farsightedness, astigmatism can be identified through a visual
acuity test, refraction test and a slit-lamp exam but also
keratometry, which uses an instrument known as a keratometer and
measures the curvature of your cornea. A pachymetry is a test that
assesses the thickness of the cornea. Corneal topography can be used
to diagnose astigmatism as it is a photography technique that maps the
cornea’s surface. Corneal topography works by allowing the eye care
professional to identify distortions in the curvature of the cornea,
according to the American Academy of Ophthalmology.
Find a Store Near You
Contact or visit your nearest store for a full quote on new frames.
[Optometrist near me](https://www.oscarwylee.com.au/locations/full-store-list.html)
## What Makes Refraction Tests Unique Compared to Other Eye Exams?
Refraction tests are unique to other eye tests
as they are intended to examine how light rays pass through your eye,
whether they are properly reaching the retina and how well you can
identify details in objects. Other eye exams may typically look at eye movement, eye pressure and
the physical nature of structures within the eye through scanning or
special photography.
### How are Refraction Tests and Visual Acuity Tests Different?
Refraction and visual acuity tests
are not necessarily different, as a visual acuity test is carried
out during a refraction test. A
[visual acuity test](https://www.oscarwylee.com.au/glasses/eye/test-glossary)
involves the use of a Snellen chart and indicates how well you can
discern details from the objects you see.
### What Should You Expect When Preparing for a Refraction Test?
When preparing for a refraction test,
you should expect the optometrist to ask you questions regarding
your eye condition
and for several tests to be performed. Therefore, it may be
helpful to think about your symptoms so you can easily present them to
your optometrist during your appointment. Ensure your eyes are in
optimal condition by getting enough sleep and avoiding long periods of
screen time to not overexert your eyes. If you have any concerns about
[what to expect from an eye test](https://www.oscarwylee.com.au/glasses/eye/test-glossary), be sure to talk with your optometrist.
### What are the Best Practices for a Successful Refraction Test?
The best practices for a successful refraction test may include
ensuring that the procedures are
time efficient, allowing sufficient time for patients to respond
and having the right tools. These practices are recommended for the eye care professional
carrying out the refraction test. The best practices for a successful
refraction test are listed below.
* Time efficient:  An optometrist
should ensure that the appointment is time efficient as it can be
common for patients to lose focus over a certain period and
therefore may not be capable of paying proper attention and provide
inaccurate responses.
* Allow sufficient time for patients to respond:
Allow sufficient time for patients to respond when using the
phoropter and swapping between different lenses to ensure they are
confident with their answers.
* Having the Right Tools:  It is vital
to have the right tools when conducting a refraction test to ensure
the optometrist achieves optimal results.
### How do Refraction Tests Vary Between Children and the Elderly?
Refraction tests may only vary between children and the elderly
in how frequently these age groups need to be tested.
[Eye exams for children](https://www.oscarwylee.com.au/glasses/eye/exam-for-children), with or without any existing eye conditions, are recommended once
every two years unless advised otherwise by their optometrist. Elderly
patients are typically recommended to have their eyes tested every
year due to the natural changes that occur in the eye with increased
age.
Read Refraction Test: Principles of Refraction Eye Exam, Benefits,
Procedures in other Oscar Wylee regions and their languages.
Australia
[Australia](https://www.oscarwylee.com.au/glasses/eye/refraction-test)
[New Zealand](https://www.oscarwylee.co.nz/glasses/eye/refraction-test)
Canada
Canadian French

Due for an Eye Test?
Book an appointment online with a qualified Oscar Wylee optometrist
today.
[Eye test near me](https://www.oscarwylee.com.au/booking)
Major Health Funds Accepted In-store
For the purchase of frames and lenses, use your private health fund to
limit how much you pay from your own pocket.
[Discover Health Funds](https://www.oscarwylee.com.au/health-funds.html)