# Source: https://www.oscarwylee.com.au/locations/optometrist-st-ives.html

# Optometrist St Ives
St Ives Shopping VillageShop 42, 166 Mona Vale Road St Ives NSW 2075
* Near Harris Farm
Opening hours
Monday9:00am - 5:30pm
Tuesday9:00am - 5:30pm
Wednesday9:00am - 5:30pm
Thursday9:00am - 5:30pm
Friday9:00am - 5:30pm
Saturday9:00am - 5:00pm
Sunday10:00am - 4:00pm
*Store hours reflect local standard trading hours and exclude public holidays
[Visit our St Ives Google Business page for directions, reviews, and updates.](https://g.page/r/CQXoNU_dFT8YEBA)
Book Appointment
[Call us: (02) 8959 7224](tel:(02) 8959 7224)
[Leave a Review!](https://g.page/r/CQXoNU_dFT8YEBA/review)
Our Reviews
Sylvia Suparjo
1 week ago
Ernie Wakamatsu
2 weeks ago
The Optometrist is very thoughtful and thorough.
Howard #
1 month ago
Great service. Thank you . Just waiting for my credit for not  tinting my lenses.
Dorothe Palamountain
3 months ago
My recent eye test went very well.
The practitioner was experienced and friendly, and made the test ...so easy. The variety of frames is impressive, and I got help from the Sales Assistant, in finding the right design for distance and sunglasses from a wide range. Thank you for such good service at St Ives branch.
See more
Mary Foley
4 months ago
Excellent experience considering that I walked in without an appointment in advance. Found out I nee...d eye surgery. Reema and Annie both very supportive with sound advice. ✨✨✨✨✨
See more
Denise Francis
4 months ago
My eye test was good and professional.   Very happy with everything and the staff were  helpful too....
Denise Francis
See more
Wesley Rodwell
6 months ago
Really great service at Oscar Wylee in St Ives.  Friendly, efficient, knowledgeable.  We have been c...ustomers since we moved to the Upper North Shore four years ago.
See more
Jill Leslie
7 months ago
Very positive experience efficient and effective communication ran to time I was in and out with no ...fuss
See more
Sue Smale
7 months ago
Professional, welcoming and an overall great experience.
Kerrie Betlem
8 months ago
I always see Annie , the optometrist here , as I trust her &amp; she is very knowledgeable &amp; thorough wi...th a lovely gentle manner. The gentleman who served me was incredibly patient &amp; helpful while we selected 2 pairs of glasses . A second opinion is always so valuable when choosing glasses.
See more
Frank
8 months ago
Brian Westgate
9 months ago
Anna is amazing as an optometrist. Very knowledgeable and helpful, wouldn’t go anywhere else.
John S
9 months ago
Excellent service
Dino-Beau Fabio
10 months ago
Annie the optometrist was fantastic! She explains everything very clearly and does a thorough eye ex...amination in addition to the regular vision eye test.
See more
mwych
10 months ago
The optometrist - Annie was very patient and took time to do the eye test. She made me feel comforta...ble during the process. She didn't rush me and gave ample time to ensure I got the right answer. Fully recommend !
See more
John Lim
10 months ago
Again, consistent and caring service provided by the team in St Ives. Very friendly and knowledgeabl...e Optometrist (Annie) who took the extra time to test my eyes and extra credit also to the Store Manager (Rima) on duty for her friendliness.
See more
Anjali Gusain
11 months ago
Sujay Orpe
11 months ago
Optometrist conducted all the tests necessary for basic eye check. She also advised me on maintainin...g the health of my eyes.
See more
Brittany Bloomer
11 months ago
Excellent experience. The team was attentive and the technology impressive. I really appreciated the... professionalism throughout my appointment, as well as the ability to book me in at short notice
See more
Askar Nurlanov
11 months ago
Oscar Wylee optometrist in St Ives was very helpful and professional, I would strongly recommend thi...s service to anyone
See more
Genia Podles
1 year ago
Very good, professional, informative and polite optometrist.
Kjell Jawerth
1 year ago
I found my visit to OW St Ives for the fitness to drive eye test a pleasant experience and I felt I ...was in competent hands.
See more
Yuko Wakamatsu
1 year ago
Optometrist was very thorough with the test and provided options to improve current symptoms.
chris christofi
1 year ago
Chris
1 year ago
Fantastic experience, very professional and thorough.
ian Macfarlane
1 year ago
rupa datar
1 year ago
Lovely staff and very neat organised store
Mark S
1 year ago
I needed an eye test and had not had one for a long time. I’m really glad I chose this store as the ...staff were absolutely delightful, informative and knowledgeable. I walked out knowing my eyes had been checked properly and I got just the right glasses for me. I got two pairs and my out of pocket was only $20!
See more
Prasann Atma
1 year ago
The optometrist was good and listened to my issues carefully. Eye test was thorough and I ended up g...etting my multi focal glasses from them. Thanks
See more
Alistair McEwan
1 year ago
An excellent consultation with Annie, she explained everything very clearly and workshopped options ...with me, so very pleased.
See more
Periplaneta Americanus
1 year ago
Annie was very thorough in her examination and intuitive questions resulting in glasses that fit and... a prescription which solves my particular visual needs.
She is kind and pleasant and her manner would be great for an AI robot i.e. light and warm.
See more
Susu1881 Su
1 year ago
Excellent service with very helpful staff, who were very polite and friendly.
Thank you Oscar Wylee ...Optometrists,  looking forward to receiving my new glasses.
See more
Tomato Fong
1 year ago
Amazing experience! Easy online booking, very detailed check and very happy with the results.
Trevor Roberts
1 year ago
I had a really good experience at Oscar Wylee in St Ives.
The eye test was very thorough and the pro...cess of buying my 3 pairs of glasses was very professional.
See more
Milgram &amp; Skinner Transport
1 year ago
Again the woman doing the tests was excellent.  I got my glasses yesterday and now I can see better ...when I sit at a screen or read a book than in the last year.  They are all right in my view (pun intended! 8--)
See more
Rich Arnott
1 year ago
Great
Jay Chander
1 year ago
Excellent service - Wonderful staff. Very professional, helpful and courteous.
Rob
1 year ago
Excellent service from Annie, the optometrist at St Ives
Richard Galvin
1 year ago
They were attentive, gave excellent feedback on eye conditions and very helpful. I will return next ...year.
————
… And I just did return this year (2025), with a similar pleasant and helpful experience.
________
See more
Kris Mason
1 year ago
The eye was great, quick, efficient and thorough, great assistance choosing the required specs, woul...d highly recommend
See more
Katherine Mahoney
1 year ago
Excellent as always with Annie. Professional,  and sensitive  to one’s needs
Norman Yiu
1 year ago
The Optometrist examined me in details and gave a professional service. She is very good.
Leo Niknam
1 year ago
Very friendly team and well organized.
I had a pleasant experience.
Claire S
1 year ago
Great service, advice and prices.
趙躍
1 year ago
Great job. Thank you
Adrian Teh
2 years ago
Praise God and thanks to Michael the master of fitting glasses for his expert skill, kindness and ca...re through the years with many pairs of specs! Thanks for your honest advice, putting your customers’ best interests first even above a sale and help resolving issues that come up too. Great seeing you each time!
See more
Nicole Smith
2 years ago
The staff were friendly and helpful. The optometrist too time to explain her procedures and to talk ...me through what was happening to my vision.
See more
Joe Singh
2 years ago
Fantastic experience with the best staff… awesome !!!
Catherine Willis
2 years ago
Annie &amp; Michael provided excellent professional service when I attended for my recent eye check-up.
...Annie made me feel very comfortable &amp; was very thorough in her explanation of all my eye tests.
Michael is very welcoming &amp; has a great bubbly personality.
See more
Marisa Calo
2 years ago
I took my two children here for their first ever eye tests. They are both autistic so I wasn't sure ...how they would go but the optometrist was wonderful with them and very patient and was able to do both tests without any problems.
See more
## Find an Optometrist in St Ives With Oscar Wylee
Come and visit us at Oscar Wylee St Ives, located in the idyllic, family-oriented suburb on the Upper North Shore of Sydney. Surrounded by lots of beautiful nature and local sporting grounds, community is the theme in St Ives. We offer in-store eye tests for same-day prescriptions and a variety of different glasses frames and lens options to suit your needs. Our eye care processes include eye health tests and vision testing, so you can be certain you’re receiving quality eye care at Oscar Wylee St Ives! 
An iconic Upper North Shore shopping centre, St Ives Village has been a staple of the community since the 1960s. Home to over 100 stores including fashion, homewares, and all your fresh food needs with Harris Farm Markets, Woolworths and Coles. St Ives Showground is Ku-ring-gai's largest sports venue with equestrian and dog training rings, a soccer field, BMX riding and BBQ facilities. Our central location of Oscar Wylee St Ives means several buses can bring you to and from the centre and there is free 3-hour parking available at the St Ives Shopping Village.        
Meet Our Team
* Optometrist
M.Clin Optom
B.Sc(Vision)
Therapeutically Endorsed
* Store Manager
Our Services
* Bulk Billed Eye Examinations
* Professional Frame Styling
* Frame Adjustments and Repairs
* Visual Fields Testing
* Digital Retinal Scanning
Show All
## Find an Optometrist in St Ives, Sydney for an Eye Health Test
Visit St Ives, Sydney for essential eye health services such as an eye health test in St Ives, assistance with prescription sunglasses or prescription glasses and more. If you are concerned about any eye diseases, our optometrists are highly qualified in diagnosing a wide range of eye problems and are happy to refer you to an eye doctor should you need one. In-store you can find our skilled optical dispenser who is responsible for dispensing our quality frames.
As part of Australia’s Medicare system, we offer eye tests at a bulk billed price. The average price for an optometrist in St Ives may depend on the availability of optometrists in the area, the required equipment and the current health of your vision. If you want to prioritise your vision health, come see us today!
## How to Find an Optometrist in St Ives, Sydney?
To find an optometrist in St Ives, Sydney you can take certain steps that can help make it easier for you such as searching online, assessing the store’s opening hours and finding the directions to your chosen location. The steps on how to find an optometrist in St Ives are listed below.
1. Search online using the phrase, St Ives optometrist near me. This can also be done here on the website via our locations page.
2. Click on the Oscar Wylee link, which will take you directly to our St Ives optometrist store page.
3. See the store’s opening hours and where the store is located specifically.
4. Use the St Ives Google Business page link located under store hours to see the directions on how to get to the store.
You can also find an optometrist in St Ives by searching the keywords optometrist near me. If you have locations enabled on your smartphone and you’re in the St Ives area, our St Ives store page should appear easily for you to click on.
### Is it Hard to Get an Eye Appointment in St Ives, Sydney?
No, it is not hard to get an eye appointment in St Ives. You can easily book an appointment to see an Oscar Wylee optometrist in St Ives right here on this page. At Oscar Wylee we have highly qualified optometrists available for bulk billed eye appointments, which can be booked online or in-store.
#### How to Compare Optometrists in St Ives to Each Other?
To compare optometrists in St Ives, you can use factors such as eye tests offered, health fund coverage, lens types and add-ons and eyewear offered. To take care of your vision and eye health, it is important to receive an eye test at least once every two years. There are different types of tests that can be performed in an eye test and not all optometrists may offer the same tests. Health funds can be used to help cover some of the cost of your frames and lenses. To find out if your health fund is accepted at St Ives optometrist in Sydney, visit their website. In the case of Oscar Wylee, we accept all major health funds and provide on-the-spot claims in-store. There are many different lens options available for prescription glasses such as single vision, multifocal and high index lenses. Most optometrists in St Ives will offer these lenses although it is good to make sure. There are also lens add-ons available to enhance your glasses such as anti-reflective and blue light filters. Finally, if you are looking to purchase a pair of glasses after your eye test, you can compare the different styles and colours you are interested in from St Ives optometrists in Sydney. Oscar Wylee offers a wide range of frames with vintage and modern inspirations in bold colours and subtle designs.
#### How to Find an Eyeglasses Shop in St Ives, Sydney?
To find a glasses store in St Ives, you can try to follow these simple steps including searching online, selecting a convenient location and looking at their health insurance policies. The steps on how to find a glasses store in St Ives, Sydney are listed below.
1. Search online using the phrase, glasses store in St Ives. This will provide you with various options for glasses stores in the whole area of St Ives.
2. Select a glasses store that is most convenient for you to travel to.
3. Click the link to find out more information such as opening hours, exact location and directions to the glasses store in St Ives.
4. Read their health insurance policies to ensure you know what health benefits you have access to.
Our Oscar Wylee glasses store in St Ives, Sydney offers primary eye care services such as comprehensive eye tests as well as other services performed by an optometrist and offers prescription and non-prescription eyewear.
##### Is it Possible to Purchase Prescribed Sunglasses in St Ives, Sydney Without Seeing an Optometrist?
Yes and no, it is possible to [purchase prescribed sunglasses](https://www.oscarwylee.com.au/sunglasses.html) in St Ives, Sydney without seeing an optometrist if you already have a prescription that has not expired. If your prescription is expired, you can book an eye test to receive an updated or new prescription which will require you to see an optometrist. This will ensure your prescription sunglasses are appropriate for your visual needs.
## Where is the Oscar Wylee St Ives Optometrist in Sydney Located?
The Oscar Wylee St Ives optometrist is located at the St Ives Shopping Centre, which is located at 166 Mona Vale Road. The Oscar Wylee St Ives store can be found near Harris Farm.
### What is the Phone Number of Oscar Wylee St Ives Optometrist Store?
The Oscar Wylee St Ives optometrist store phone number is [(02) 8959 7224](tel:(02) 8959 7224). You can contact the Oscar Wylee St Ives store between the hours of 9 am and 5:30 pm on Monday, Tuesday, Wednesday and Friday, on Thursdays between 9 am and 7 pm, on Saturdays between 9 am and 5 pm and on Sundays between 10 am and 4 pm.
### What are the Reviews for Oscar Wylee St Ives Optometrist in Sydney?
The many reviews for Oscar Wylee St Ives optometrist in Sydney, left by our various customers can be found here on the website and online when you search for Oscar Wylee St Ives optometrist. The reviews for Oscar Wylee St Ives optometrist are listed below.
* Donald D:  Recently visited Oscar Wylee St Ives after my friend told me about this store and how helpful the staff are here. She was not wrong. When I came in I was greeted by Breanna, the store manager there and she explained to me the things that I could get with my prescription. although I didn't get glasses this time and the ASM reminded me that it's almost the new year and health funds will reset soon anyways. Thank you so much to the St Ives team.
* Julia Salamonsen:  Very friendly and helpful staff. Had a wonderful experience and a lot of laughs with the staff. I received honest feedback on whether the glasses suited my face. I had confidence in the optometrists ability which was very important to me as there have been times in the past when I have bought glasses which I felt made very little difference to my eyesight. I also learnt to throw away my old glasses!
* Richard Adams:  I was losing sleep because of an irritation in one eye &amp; I tried over the counter drops &amp; saline but it was getting worse. So this morning I tried to book into the optometrist that I normally go to, and where I have spent thousands this year. They didn't want to know what the problem was, and simply said they had nothing available today. So I decided to try to get a walk-in from one of the many optometrist shops in the St Ives Centre and I discovered Oscar Wylee, which is fairly new. The team at Oscar Wylee could not have been better. Booking in for an examination was quick &amp; easy and the optometrist, Annie Li, did a very thorough check of my problem eye, found the problem and removed the particle that was causing the issue. I was so impressed by the way I was looked after and I will be going back here the next time I need glasses or other eye services.
#### What Treatments or Eye Care Processes are Done in the Oscar Wylee St Ives Optometrist Location?
The treatments or eye care processes done in the Oscar Wylee St Ives optometrist Sydney location include a tonometry test, a digital photograph, a slit lamp exam and a refraction test. Additional tests that may also be performed can include a visual field test and a dilated fundus exam. The treatments or eye-care processes that are done in the Oscar Wylee St Ives optometrist Sydney location are listed below.
* A Tonometry Test: An optometrist or optical dispenser will conduct a tonometry test which involves the use of a machine that will release small puffs of air into your eyes. This will assist with measuring pressure in the eye.
* A Digital Photograph: An optometrist or optical dispenser may take a digital photograph of your eye which can be kept on record to use in future appointments to evaluate any changes to your eye.
* Slit Lamp Test: A slit lamp test can be used to evaluate your eye health, by examining your cornea and iris which are the anterior and posterior of the eye.
* Refraction Test: During a refraction test, an optometrist will have you view an image through different lenses and ask you to confirm which helps you see the image clearer.
* Visual Field Test: A visual field test can assist with assessing your peripheral vision, which may be beneficial for identifying any signs of glaucoma.
* Dilated Fundus Exam: A dilated fundus exam can help an optometrist assess your health in more detail by getting a clear view of the retina. This test is typically carried out for patients with diabetes and those who may be at risk of developing retinal damage.
## How Many Optometrists Exist in St Ives, Sydney?
Many Oscar Wylee optometrists exist in St Ives, Sydney to provide eye tests and glasses, including Oscar Wylee. The number of optometrists in St Ives may be due to the number of residents in the area and the geographical size of the suburb. If you need essential eye services such as a comprehensive eye test, a wide selection of prescription eyewear and more, then choose Oscar Wylee as your first choice for optometry services.
### What are the Other Closest Optometrist Locations to St Ives, Sydney in Australia?
The other closest Oscar Wylee optometrist locations to St Ives, Sydney in Australia are Hornsby, Macquarie Centre, Chatswood, Top Ryde and Waringah. The other closest optometrist locations in Australia are listed below.
* Hornsby:  Hornsby is close to St Ives with 8 km in between stores and is located at Hornsby Westfield Shopping Centre. The [Oscar Wylee Hornsby](https://www.oscarwylee.com.au/locations/optometrist-hornsby.html) store is on level 1 and offers important services to help make sure your eyes are in optimal health.
* Macquarie Centre:  Macquarie Centre is close to St Ives with 9.5 km in between stores and is located at the Macquarie Shopping Centre. The [Oscar Wylee Macquarie Centre](https://www.oscarwylee.com.au/locations/optometrist-macquarie-centre.html) store can be found on level 2, next to Sheridan and provides comprehensive eye tests at a bulk billed for eligible Medicare cardholders.
* Chatswood:  Chatswood is close to St Ives with 10 km in between stores and is located at the Chatswood Chase Shopping Centre. The [Oscar Wylee Chatswood](https://www.oscarwylee.com.au/locations/optometrist-chatswood-chase.html) store offers same-day prescriptions as well as assistance with selecting frames.
* Top Ryde:  Top Ryde is close to St Ives with 12 km in between stores and is located at the Top Ryde Shopping Centre at 109-129 Blaxland Road. The [Oscar Wylee Top Ryde](https://www.oscarwylee.com.au/locations/optometrist-top-ryde.html) store can be found on level LG1 opposite Specsavers and offers optometry services carried out by passionate and highly-skilled team members.
* Warringah:  Warringah is close to St Ives with 19 km in between stores and is located at the Westfield shopping centre. The [Oscar Wylee Warringah](https://www.oscarwylee.com.au/locations/optometrist-warringah-mall.html) store can be found at 145 Old Pittwater Road in Brookvale and is where you can get a comprehensive eye test and browse for your desired frames all in one day.
### Bulk Billed Eye Tests Available
At Oscar Wylee St Ives, we can guarantee excellent eye tests that you can get bulk billed if you have a valid Medicare card. Come in and have your prescription updated and browse for a new pair of eyeglasses all on the same day. Our trained optometrists at Oscar Wylee St Ives can ensure your prescription is up to date Oscar Wylee in St Ives can keep you up-to-date on your eyesight and eye health needs.
### Health Funds Accepted at Oscar Wylee St Ives
Oscar Wylee in St Ives accepts major health funds such as Bupa, HCF and Medibank. We would be glad to take care of your health fund claim at our Oscar Wylee St Ives store with a valid health fund card, as well as walk you through your health fund, so you can receive the best price for either your prescription sunglasses, eyeglasses or eye health test!
### Fashion-Forward Glasses at Oscar Wylee
You can expect stylish frames at Oscar Wylee St Ives, as we offer prescription sunglasses and prescription glasses in a variety of styles that are both modern and vintage-inspired. If you’re interested in opting for one of our many different lens options, just let us know! Our experts in-store will guide you in choosing what’s best for your lifestyle. We think you’ll leave our Oscar Wylee St Ives eyeglasses shop with a great pair of prescription glasses or prescription sunglasses.
Book Appointment
[Call us: (02) 8959 7224](tel:(02) 8959 7224)
[Leave a Review!](https://g.page/r/CQXoNU_dFT8YEBA/review)