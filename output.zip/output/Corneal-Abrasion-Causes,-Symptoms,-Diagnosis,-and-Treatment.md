# Source: https://www.oscarwylee.com.au/glasses/eye/corneal-abrasion

# Corneal Abrasion: Causes, Symptoms, Diagnosis, and Treatment
Published on January 15th, 2024
Updated on March 21st, 2025 
Australia
[Australia](https://www.oscarwylee.com.au/glasses/eye/corneal-abrasion)
[Canada](https://oscarwylee.ca/glasses/eye/corneal-abrasion)
Canadian French

A corneal abrasion occurs when the cornea of the eye is scratched or
tears, which can lead to pain, sensitivity to light and blurry vision. The
cornea is the eye's clear front surface and covers the pupil and the iris,
allowing light to enter the eye. A corneal abrasion is also known as a
scratched cornea. Causes of a scratched cornea include a foreign body in the eye, rubbing the eyes too hard and wearing contact
lenses.
A scratch on the eye will typically heal on its own within 24-72 hours,
however, if it is more serious it may need medical attention. A corneal
abrasion may not need treatment, however, for those that do, eye drops
will often be prescribed.
Ready for an Eye Test?
We have qualified optometrists who can provide bulk billed eye tests so
you can stay on top of your vision and eye health.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Definition](#definition) [Causes](#causes)
[Risk Factors](#risk-factors) [Treatment](#treatments)
## What is Corneal Abrasion?
A corneal abrasion is a type of eye injury where the cornea sustains trauma which may be a
scratch or tear.
The cornea is the clear, outer layer at the front of the eye and it
directly covers the pupil, iris and anterior chamber. Corneal abrasions
may be minor and heal on their own or more severe and require immediate
assessment and treatment.&nbsp; A corneal abrasion may result in blurred
vision if the cornea is scarred and infected. Keep reading to learn more
about what is a corneal abrasion.
### What is the Other Term for Corneal Abrasion?
Corneal abrasion is the medical term for this eye condition. Other colloquial terms include scratched eye or scratched cornea.
According to the Cleveland Clinic, corneal erosion is a similar eye
condition that occurs when a layer of cells on the cornea's surface
loosens from the layer underneath.
## What are the Causes of a Corneal Abrasion?
Corneal abrasions can be caused by many things and often happen by
accident. The causes of a corneal abrasion include rubbing the eyes too hard, poking the eye with objects, contact lenses
and foreign objects in the eye.
The corneal abrasion causes and their definitions are listed below.
* Rubbing eyes too hard: Rubbing the eyes
too hard can cause a scratch on the cornea if there is dirt or debris on
the surface of the eye.
* Poking the eye with objects:
If you accidentally poke your eye with a fingernail or object, it can
cause a scratch on the cornea.
* Contact lenses: Contact lenses can cause a corneal abrasion if
they are dirty, too dry or have a torn or rough edge.
* Foreign objects in the eye: A corneal abrasion is often the
result of a foreign object in the eye scratching the surface.
### 1. Rubbing Eyes Too Hard
Rubbing the eyes too hard can cause a scratch on the cornea if there is dirt or debris on the
surface of the eye.
While it may feel good to rub your eyes, it can cause more damage to the
surface of the eye. If you feel there is something in your eye causing
irritation, try and flush the eye out with water.
### 2. Poking the Eye with Objects
If you accidentally poke your eye with a fingernail or object, it can cause a
scratch on the cornea.
This can often happen with children when they are playing with toys.
Also, they may accidentally scratch their eyes if their fingernails are
long which is why parents should try to clip them regularly.
### 3. Contact Lenses
Contact lenses
can cause a corneal abrasion if they are dirty, too dry or have a torn
or rough edge.
Contact lenses should only be worn according to their instructions such
as daily or extended wear to prevent scratches or eye irritation. If
your contact lenses are too dry, you can use a contact lens solution to
add moisture. According to an article published in the National Library
of Medicine, wearing contact lenses for a prolonged amount of time or if
your contact lenses are damaged, can increase a person’s risk of a
scratched cornea.
### 4. Foreign Objects in the Eye
A corneal abrasion is often the result of a foreign object in the eye scratching the surface. Foreign bodies that may cause a corneal abrasion are anything that
should not be in the eye including a wood chip, dust, metal shavings, an
insect or a piece of glass, according to Better Health Victoria. Foreign
objects or bodies in the eyes can cause pain, watery eyes, blurry vision
and photophobia. If you have a foreign object in the eye, seek medical
attention from an optometrist or other health care professional.
## What are the Corneal Abrasion Risk Factors?
Risk factors for corneal abrasions include
wearing contact lenses, working around eye hazards and playing sports,
according to the Cleveland Clinic. These risk factors and their
definitions are listed below.
* Wearing contact lenses:
Contact lenses can cause a corneal abrasion, especially if they are
dirty or too dry. Also, if contact lenses have rough edges they can
scratch the eye.
* Working around eye hazards: People who work with machines such as grinding machines and sawmills,
have a higher risk of an object or dust entering their eye and
scratching their cornea.
* Playing sports: Playing sports can make a person more at risk of having a corneal
abrasion which is why it is recommended to wear safety glasses when
playing certain sports.
### How Common is Corneal Abrasion?
A corneal abrasion is a common eye condition that can happen to anyone.
According to the American Academy of Family Physicians, 8% of all eye
presentations in primary care consist of corneal abrasions.
#### Is a Scratched Eye Common in Kids?
Yes, according to Nemours KidsHealth, a scratched eye or corneal abrasion is a common type of eye injury in
kids, teens and also adults. Children may scratch their eyes when playing
with toys or if they have long fingernails. Parents should try and
clip their child’s fingernails to prevent them from scratching their
eyes.
#### Is Corneal Abrasion a Rare Corneal Condition?
No, a corneal abrasion is not a rare corneal condition, rather it is a common eye injury that is typically minor and will
heal on its own. A corneal condition affects the cornea, which is the
clear, outer layer of the eye. Other [corneal conditions](https://www.oscarwylee.com.au/glasses/eye/corneal-diseases)
include keratitis, pterygium, corneal dystrophy and corneal
ectasia.
## What are the Symptoms of a Corneal Abrasion?
The cornea abrasion or eye scratch symptoms can differ depending on the
severity of the scratch. The symptoms of cornea abrasion include photophobia, blurry vision, pain in the eye, red eyes and watery eyes.
These symptoms and their definitions are listed below.
* Photophobia: Photophobia, also known as
sensitivity to light, is one of the main symptoms of corneal abrasions.
* Blurry vision:
A corneal abrasion may lead to blurry vision due to the disruption to
the surface of the eye.
* Pain in the eye: A corneal abrasion can cause pain in the eye
which may be mild or severe depending on the scratch.
* Red eyes: A person’s eye may become red if they have a scratched
cornea due to the trauma on the eye's surface.
* Watery eyes: A person may experience watery eyes due to a
scratched cornea as tears help the eyes heal when they sustain
trauma.
### 1. Photophobia
Photophobia, also known as sensitivity to light, is one of the main symptoms of corneal abrasions.
Photophobia is described as being abnormally sensitive to light and is a
common symptom of many eye conditions. According to an article published
in the National Library of Medicine, [photophobia](https://www.oscarwylee.com.au/glasses/eye/light-sensitivity)
caused by corneal abrasion can be treated with cycloplegic medications
which can be in the form of eye drops.
### 2. Blurry Vision
A corneal abrasion may lead to blurry vision due to the disruption to the surface of the
eye.
According to the National Library of Medicine, a person’s vision should
return to normal once the corneal abrasion is healed, which typically
takes 24-72 hours. Blurred vision can also be a complication of a
corneal abrasion due to scarring, as discussed by the Royal Victoria Eye
and Ear Hospital. If you experience blurry vision from a corneal
scratch, visit an optometrist to have your eyes assessed.
### 3. Pain in the Eye
A scratched cornea can often result in pain in the eye due to the
sensitivity of the area. Pain is typically not felt for a small scratch, however, if the
scratch is more severe it can be painful and uncomfortable. Medicine can
be taken to relieve pain if necessary. According to an article published
in the National Library of Medicine, this may include oral nonsteroidal
anti-inflammatory drugs. If you are experiencing [pain in the eye](https://www.oscarwylee.com.au/glasses/eye/pain-definition), you should book an appointment with an optometrist so they can assess
your condition.
### 4. Red Eyes
A person’s eye may become red if they have a scratched cornea due to the trauma on the
eye's surface.
Red eyes generally describe the surface of the eyes becoming red due to
trauma that causes the small blood vessels under the surface of the eye
to become large or inflamed, according to the Cleveland Clinic. [Redness in the eye](https://www.oscarwylee.com.au/glasses/eye/red-or-bloodshot)
will often go away on its own although may be helped with rest, using a
cold compress and eye drops.
### 5. Watery Eyes
Watery eyes or excessive tearing can be a symptom of a corneal
abrasion. A person may experience watery eyes due to a scratched cornea as tears help the
eyes heal when they sustain trauma.
Once the abrasion has healed, watery eyes will often go away on their
own without treatment.
Due for a New Pair of Glasses?
Visit an Oscar Wylee store near you and try on our wide range of
fashion-forward frames. We’ve got all different styles, colours and
shapes.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
## How is a Corneal Abrasion Diagnosed?
A corneal abrasion is typically diagnosed in an eye test.
An optometrist, sometimes known as an [eye doctor](https://www.oscarwylee.com.au/eye-care/optometry/eye-doctors.html), will ask about the history of the injury and if there is any pain you
have been experiencing. You will also be asked what other symptoms you are
experiencing. Symptoms of a corneal abrasion include photophobia, blurry
vision and a gritty feeling in the eyes. Diagnosis can also be achieved
through fluorescein dye which is placed on the surface of the eye to
highlight where an injury or scratch has occurred on the cornea.
### Can an Optometrist Diagnose a Corneal Abrasion?
Yes, an optometrist can diagnose a corneal abrasion in an eye test.
An optometrist is your first stop for fundamental eye care. If you feel
like you have a scratch on your cornea or feel there is something in
your eye, book an appointment with an [optometrist](https://www.oscarwylee.com.au/eye-care/optometrist)
and they can provide diagnosis and treatment plans if needed.
### How Dangerous is a Corneal Abrasion?
A corneal abrasion is not often a dangerous eye condition as they typically heal on their
own.
However, it can be a more serious eye injury that needs immediate
medical attention, especially if there is a foreign body penetrating the
eye.
#### Can Corneal Abrasions Lead to Blindness?
Although rare, corneal abrasions may lead to blindness if they are untreated, according to an article published in the National Library of
Medicine. Otherwise, the prognosis of corneal abrasions is typically
excellent if treatment is prompt. A person’s vision can be affected if
a corneal abrasion becomes infected, although this again is
rare.
#### Should I Go to the ED for a Corneal Abrasion?
Most cases of corneal abrasion do not necessitate going to the ED.
However, in severe cases, this may be advised, for example, if there
is a
foreign body that needs to be removed from the eye or if a person is
experiencing significant pain.
## What are the Treatments for Corneal Abrasion?
Scratched eye treatments can depend on the type of corneal abrasion as
many do not need treatment and will heal on their own. When treatments for
corneal abrasions are needed, they can include
eye drops and antibiotics and a healthcare professional may remove the
foreign body. The process for how to treat a scratched eye is listed below.
* Eye drops: Eye drops may be used to treat
a corneal abrasion. According to the American Academy of Ophthalmology,
moisturising eye drops add a soothing layer over the cornea. There are
also dilating eye drops used to decrease pain.
* Antibiotics:
Antibiotics may be prescribed by an optometrist to prevent an eye
infection. There are different options available for antibiotics
according to the National Library of Medicine. This includes ointments
and eye drops.
* Remove foreign body: If there is a foreign body in the eye, an
optometrist or other health care professional may remove the foreign
body if it is safe. This can prevent the cornea from becoming more
scratched or irritated.
### How Long Does Corneal Abrasions Take to Heal?
Most corneal abrasions will take approximately 24 to 72 hours to heal, according to the American Academy of Family Physicians. A corneal
abrasion will also typically heal without treatment although it depends
on the severity of the injury. Minor eye scratches from dust or debris
do not require treatment as they will heal with time.
#### Does Sleep Help Heal Corneal Abrasions?
Yes, sleeping may help heal a corneal abrasion
according to Medical News Today. Sleep can be effective in helping a
corneal abrasion as it can speed up a body’s healing process. Sleep
also means the eyes are closed and will most likely not be rubbed or
blink which can cause further irritation.
#### Can Eye Drops Treat a Corneal Abrasion?
Yes, eye drops are often prescribed to treat a corneal abrasion. These [eye drops](https://www.oscarwylee.com.au/glasses/eye/types-of-eye-drops)
can include antibiotic eye drops which provide lubrication to the eye
according to the National Library of Medicine. There are also
Cycloplegic eye drops which are used to manage photophobia (light
sensitivity) which may be caused by a corneal abrasion. Dilating eye
drops may be prescribed to treat pain caused by a scratched
cornea.
## What are Ways to Prevent Corneal Abrasions?
There are certain preventative measures a person can take to avoid
corneal abrasions. The ways to potentially prevent corneal abrasions
include wearing protective eyewear, not rubbing your eyes and clipping your
child’s fingernails.
These preventive measures and their definitions are listed below.
* Wear protective eyewear: Make sure to wear
protective eyewear when working in hazardous conditions or when playing a
sport that requires them. This can prevent the surface of the eye from
being scratched.
* Don’t rub your eyes:
If there is a foreign body such as dirt or sand in your eye, you should
not rub your eyes as it can cause scratches on the cornea. While you may
feel compelled to rub your eyes, try flushing the eyes with water
instead.
* Clip children’s fingernails: Children can accidentally scratch
their eyes with their fingernails if they are too long. Parents should
clip their children’s fingernails to prevent corneal abrasions.
### Can Glasses Prevent a Corneal Abrasion?
Yes, in some cases,
glasses, specifically safety glasses or goggles, can prevent corneal
abrasions.
Corneal abrasions can occur when working in a hazardous environment or
with certain machines such as a sawmill. Sunglasses can also help keep
dirt or debris out of a person’s eyes in windy environments.
#### What is the Difference Between a Corneal Abrasion and Keratitis?
While corneal abrasions and keratitis are both corneal diseases, they
have many differences. A corneal abrasion is a scratch on the cornea and keratitis is
inflammation in the cornea.
Keratitis is an eye condition that affects the cornea and is also
known as a corneal inflammation or corneal infection. Keratitis can be
caused by a virus, an eye injury or bacterial, fungal and parasitic
infections. A corneal abrasion and [keratitis](https://www.oscarwylee.com.au/glasses/eye/keratitis)
have similar symptoms including photophobia, excessive tearing, blurry
vision and pain in the eye.
Read Corneal Abrasion: Causes, Symptoms, Diagnosis, and Treatment in other
Oscar Wylee regions and their languages.
Australia
[Australia](https://www.oscarwylee.com.au/glasses/eye/corneal-abrasion)
[Canada](https://oscarwylee.ca/glasses/eye/corneal-abrasion)
Canadian French

We Accept all Major Health Funds
Bring a valid health fund card in-store and our staff can provide
on-the-spot claims and answer any questions you may have about your
coverage.
[Explore health funds](https://www.oscarwylee.com.au/health-funds.html)
Prioritise Your Eye Health
Your eye health is important, which is why you need to have regular eye
tests. Book yours today with an Oscar Wylee optometrist.
[Book an eye test](https://www.oscarwylee.com.au/booking)