# Source: https://www.oscarwylee.com.au/glasses/eye/dominant-eye-test

# Dominant Eye Test: How to Tell Which Eye is Dominant
Published on September 17th, 2024
Updated on Month Date, 2025 
Australia
[Australia](https://www.oscarwylee.com.au/glasses/eye/dominant-eye-test)
New Zealand

[Canada](https://oscarwylee.ca/glasses/eye/dominant-eye-test)
Canadian French

A dominant eye test refers to a test that can help determine which eye is dominant. A person can be either right eye dominant or left eye dominant, which
may, but not always, correspond to their hand dominance. A dominant eye is
not necessarily the eye with the best vision or visual acuity, but the one
that the brain favours using for certain tasks. Having a dominant eye does
not generally impact vision or overall eye health, but may be a beneficial
thing to know for people who play sports such as golf or darts, as well as
photographers. Using the dominant eye during these activities may improve
aim and overall performance. There are three main types of tests that can
help determine the dominant eye including a hole-in-a-card test, miles
test, and a point test. Keep reading to learn more about dominant eye
tests.
Prioritise Your Eye Health at Oscar Wylee
Oscar Wylee optometrists are available to perform bulk-billed eye tests,
with no out-of-pocket expenses for eligible Medicare cardholders.
[Eye test near me](https://www.oscarwylee.com.au/booking)
[Definition](#Definition) [How To Tell](#Tell)
[Importance](#Importance)
[Oscar Wylee Dominant Eye Test](#Dominant)
## What is a Dominant Eye?
A dominant eye
refers to the eye that is generally more favoured by the brain and is
often used to perform functions over the other. According to a paper by Moreno, Capdevila and Losilla, a person’s
dominant eye is usually the brain’s preference for input to the visual
cortex, and can relay information more accurately than a non dominant
eye. According to the American Academy of Ophthalmology, a dominant
eye is not necessarily the eye with the best vision. A dominant eye
will generally not have any bearing on overall vision or eye health,
however, it may be beneficial in performing certain tasks like
photography and sports such as golf and baseball. A dominant eye can
be either the left eye or the right eye, and can sometimes match a
person’s dominant hand, but this is not always the case.
## What is a Dominant Eye Test?
A dominant eye test is a test that a person can take to determine which eye is dominant. Finding out which eye is dominant is not always a part of a
standard eye test with an optometrist, as knowing which eye is
dominant does not always relate to overall vision quality or eye
health.
According to an article in the Hong Kong Journal of Ophthalmology, a
dominant eye test may be used by an optometrist if the clarity of
vision can't be balanced by refraction. A person may take a dominant
eye test if they are a photographer, or playing sports such as
baseball and golf, as this may help with performance. According to the
American Academy of Ophthalmology, knowing which eye is dominant may
also help with certain eye care such as treating strabismus and
amblyopia.
## How to Tell Which Eye is Dominant?
There are three main tests a person can take at home to determine
which eye is dominant, including the hole-in-a-card test, miles test, and a point test. An optometrist may use different methods to determine eye dominance
if needed. The at home tests to determine which eye is dominant are
listed below.
* Hole-in-a-card Test: A hole-in-a-card
test uses a card with a hole cut in the centre to determine eye
dominance.
* Miles Test:
A miles test uses the hands, crossed into a triangle shape in front
of the face, to determine eye dominance.
* Point Test: A point test involves pointing the index fingers at an object and
closing each eye to determine which eye keeps the object in focus,
determining eye dominance.
### 1. Hole-in-a-card Test
The hole-in-a-card test is a test to help determine which eye is dominant. To conduct this test, begin by cutting a hole in the middle of a
piece of card or paper. The hole should be around the size of the
eye. A person will then hold the card out in front of their face and
look through the hole, with eyes open, at an object in the distance.
The person will then slowly bring the card closer to their face. The
eye that the card is in front of will be the dominant eye.
### 2. Miles Test
A miles test is a simple test using just the hands, to help determine eye
dominance. To conduct a miles test, a person will put their arms out in
front of them, crossing their hands to make a triangle shape. A
person will then pick an object in the distance and look at it
through the triangle. The next step is to close each eye
alternatively. If the object moves out of the triangle, then the eye
being used is the non-dominant eye.
### 3. Point Test
A point test is a test that helps to determine eye dominance. A point test is simple and involves a person clasping hands
together with the index fingers out straight. A person will point
the index fingers at a distant object, in front of the face. A
person will then close each eye whilst looking at the object. If a
person closes an eye and the fingers remain pointed at the object,
this is the dominant eye.
## What is the Relation Between Eye Dominance and Handedness?
The relation between eye dominance and hand dominance, usually referred to as left
or right-handedness, is not fully understood and is the subject of
much scientific research. Eye dominance may, but not always, correspond to a person’s hand
dominance. The relation between eye and hand dominance is an important
area of study, as understanding it may help to improve [hand-eye coordination](https://www.oscarwylee.com.au/glasses/eye/hand-eye-coordination), which is an important part of daily activities, as well as sports
and photography.
### What is Crossed Dominance?
Crossed dominance refers to a person with no consistent right or left dominance, such
as eye or hand dominance, according to a paper by Ferrero, West and
Vadillo. A person with crossed dominance might favour their left hand for
writing but prefer to throw a ball with their right.
Find an Oscar Wylee Store Near You
Come and visit your local Oscar Wylee store where our friendly team
will help you shop our range of stylish and affordable frames.
[Optometrist near me](https://www.oscarwylee.com.au/locations/full-store-list.html)
## Why is a Dominant Eye Test Important?
A dominant eye test is
generally important for those who may find their performance enhanced
by knowing their dominant eye, such as athletes or those who do
photography. Knowing what your dominant eye is, is not always important in
regards to eye health or daily activities. However, an optometrist may
conduct one to help with treatment for certain eye conditions such as
strabismus or amblyopia. The
importance of a dominant eye test for athletes, for shooting purposes
and photography is listed and explained below.
* Dominant Eye Test for Athletes:
Dominant eye testing is important for athletes as it can help improve
aim and overall performance.
* Dominant Eye Test for Shooting Purposes:
A dominant eye test for shooting purposes may be beneficial as it
can help improve aim.
* Dominant Eye Test for Photography:
A dominant eye test for photography or photographers may be
important as it can help with alignment and framing.
### 1. Dominant Eye Test for Athletes
A dominant eye test for athletes may be beneficial as knowing the dominant eye may help to improve
sports performance. Athletes who pursue sports such as golf, darts and baseball may
find their aim when swinging or trying to hit a target is better if
they identify and use their dominant eye.
### 2. Dominant Eye Test for Shooting Purposes
A dominant eye test for shooting purposes may be important as knowing the dominant eye may allow for more
accurate aim. For activities such as archery, rifle shooting, pistol shooting
and hunting, being able to aim with precision plays a major role in
hitting a target accurately.
### 3. Dominant Eye Test for Photography
A dominant eye test for photography, particularly with cameras, as
opposed to mobile phones, may be beneficial as it can help make sure an image is aligned
correctly in the frame. Using your dominant eye when taking a photograph ensures that the
objects are framed more accurately.
## How is a Dominant Eye Test Done in Eye Clinics?
An optometrist or eye care professional may use a lens fogging technique during a refraction test, to test
accommodation and help determine which eye is dominant. Lens fogging involves having a patient focus on a distant object,
with a plus power lens over the eyes. The lens will make the object
appear blurry. The optometrist or eye care professional will
alternatively change the lens over each eye, with the patient
encouraged to determine in which eye the blur is more noticeable. The
eye that is blurry and less comfortable will be the dominant eye,
according to the paper Monovision Correction Preference and Eye Dominance
Measurements, published in the journal Translational Vision Science and Technology.
### Is a Dominant Eye Test Needed for Treating Amblyopia or Strabismus?
A dominant eye test is not necessarily needed for treating amblyopia (lazy eye) or
strabismus (crossed eye), but may be helpful information for an
optometrist or eye care professional to know. [Amblyopia](https://www.oscarwylee.com.au/glasses/eye/lazy-definition)
refers to an eye condition in which there is reduced vision in one
eye. According to the American Academy of Ophthalmology, amblyopia
treatment can involve patching the dominant eye to help strengthen
the weaker eye. A similar treatment can be used for [strabismus](https://www.oscarwylee.com.au/glasses/eye/crossed-definition) or crossed eyes.
### Does Oscar Wylee Offer Dominant Eye Testing?
Yes, Oscar Wylee can offer dominant eye testing as part of a general, routine eye
test with an optometrist. To book a Medicare bulk billed eye test with our optometrists,
go to our [Oscar Wylee booking page](https://www.oscarwylee.com.au/booking), visit us online, or call us on 1300 164 990 to make an
appointment.
## Does the Dominant Eye Have Better Vision?
A dominant eye does not necessarily have better vision than a non-dominant eye. A dominant eye is the eye that the brain favours to complete visual
tasks, which is not always the eye with better visual acuity.
### Is it Possible not to have a Dominant Eye?
Yes, it is possible that some people do not have a dominant eye, or at least
do not indicate a preference for one. According to the Cleveland Clinic, just under 7% of people say
they do not have an eye preference when doing certain tasks.
### Can a Person Change Their Dominant Eye?
A person may change the eye they use for certain tasks, but this
does not necessarily mean that the eye that is most dominant has
changed. If a person is fatigued for example, they may shift to the
other eye when performing tasks.
Read Dominant Eye Test: How to Tell Which Eye is Dominant in other
Oscar Wylee regions and their languages.
Australia
[Australia](https://www.oscarwylee.com.au/glasses/eye/dominant-eye-test)
New Zealand

[Canada](https://oscarwylee.ca/glasses/eye/dominant-eye-test)
Canadian French

Oscar Wylee Accepts Major Health Funds In-store
Visit Oscar Wylee in-store for eye care services and your health fund
may help cover some of the cost.
[Optometrist near me](https://www.oscarwylee.com.au/locations/full-store-list.html)
Are You Due for an Eye test?
Book online and our Oscar Wylee optometrists will help keep your eye
health on track.
[Eye test near me](https://www.oscarwylee.com.au/booking)