# Source: https://www.oscarwylee.com.au/glasses/eye/retinoblastoma

# Retinoblastoma: Causes, Symptoms and Treatment
Published on April 21st, 2026
Australia
Australia
New Zealand
Canada
Canadian French
 
Retinoblastoma is a type of cancer that develops in the retina, the layer in the eye that detects light and transforms it into signals for the brain. Retinoblastoma is a condition that mostly affects young children, constituting around 6% of all cancers in children under the age of 5, according to the Children's Health Queensland. Patients with retinoblastoma may experience symptoms such as the pupil appearing white when a light is shone into it, red eye or eye pain, larger eye, cloudiness in the iris and pupil and lazy or crossed eyes. Retinoblastoma may be caused by risk factors such as abnormalities in a certain gene known as RB1, which can run in families or develop for the first time in the child, according to Cancer Australia.
Do You Have Any Eye Health Concerns?
See one of our highly skilled and knowledgeable optometrists in-store.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Definition](#definition) [Types](#types) [Symptoms](#symptoms) [Treatment](#treatment)
## What is Retinoblastoma?
Retinoblastoma is a form of eye cancer that starts in the retina and mostly affects young children. Retinoblastoma can occur in one or both eyes and can develop due to a change in the gene called RB1, according to Cancer Australia. This type of cancer is usually found in both genders and diagnosed before the age of 5, according to Rare Cancers Australia.
### How does Retinoblastoma Develop in the Retina?
How retinoblastoma develops in the retina is still unknown, like other cancers. However, the mutation of the RB1 gene, causing the cells to multiply uncontrollably, may be what occurs when retinoblastoma ensues. The [retina](https://www.oscarwylee.com.au/glasses/eye/anatomy/retina) is the light-sensitive layer at the back of the eye, which is what helps convert the light that enters the eye into signals that are sent to the brain.
#### Is Retinoblastoma Caused by a Mutation in the RB1 Gene?
Yes, retinoblastoma may be caused by a mutation in the RB1 gene. Children who possess the heritable genetic type of retinoblastoma have a mutation in the chromosome 13, known as the retinoblastoma 1 (RB1) gene, according to Yun et al., (2011).
### What are the Types of Retinoblastoma?
The types of retinoblastoma include hereditary retinoblastoma, non-hereditary retinoblastoma and extraocular retinoblastoma. The types of retinoblastoma are listed below.
* Hereditary Retinoblastoma: Hereditary retinoblastomas, also known as familial retinoblastomas, are characterised as tumours that have occurred in patients with a history of the disease in the family. Cases of hereditary retinoblastomas may stem from a genetic mutation in the tumour suppressor gene RB1, according to Rare Cancers Australia.
* Non-Hereditary Retinoblastoma: Non-hereditary retinoblastomas are considered the most common type and can likely stem from a random genetic mutation. This form of retinoblastoma may predominantly be unilateral and identified at a later stage, unlike hereditary retinoblastomas.
* Extraocular Retinoblastomas: Extraocular retinoblastomas refer to retinoblastomas that have spread to neighbouring tissues and organs beyond the eye.
#### Are There Both Hereditary and Non-Hereditary Forms of Retinoblastoma?
Yes, there are both hereditary and non-hereditary forms of retinoblastoma. Hereditary retinoblastoma may likely result from a mutation in the RB1 gene, with 45% of children with retinoblastoma having the hereditary form, according to Kamihara et al., (2025). Non-hereditary forms of retinoblastoma may occur when both copies of the RB1 tumour suppressor gene are randomly mutated in a retinal cell, according to Fabian and Sagoo (2018).
## What Causes Retinoblastoma?
What causes retinoblastoma is not yet known. However, there may be certain risk factors such as a mutation in the RB1 gene, inherited RB1 gene mutation, sporadic RB1 gene mutation and the two-hit mutation process. The potential causes for retinoblastoma are listed below.
* Mutation in the RB1 Gene: A mutation in the RB1 gene can be a cause for retinoblastoma, as this gene provides instructions for producing an important tumour suppressor protein. This is what helps prevent the uncontrolled growth of cells.
* Inherited RB1 Gene Mutation: Inherited RB1 gene mutation may be a cause of retinoblastoma, as it means the mutation, which can lead to developing the disease, is already present in the cells of the body.
* Sporadic RB1 Gene Mutation: Sporadic RB1 gene mutation may be a cause for retinoblastoma and can occur when the RB1 tumour suppressor gene acquires two mutations in a single retinal cell.
* Two-hit Mutation Process: The two-hit mutation process refers to the cause of retinoblastoma stemming from two gene mutations, leading to the development of a tumour. One mutation occurs through a hereditary case or sporadic case, as well as a separate mutation occurring in the same cell.
### How do Genetic Mutations Trigger Retinoblastoma?
Genetic mutations may trigger retinoblastoma if they occur within the RB1 gene, as it is responsible for regulating cells and preventing uncontrolled division. Therefore, leading to the development of either hereditary or sporadic retinoblastoma.
#### Can Retinoblastoma be Inherited From a Parent?
Yes, retinoblastoma can be inherited from a parent. While retinoblastoma may be inherited from a parent, it may be considered less common. In many retinoblastoma cases among children, they are often the first in their family to have eye cancer, according to the Memorial Sloan Kettering Cancer Centre.
Find a Store Near You
Browse and try-on our wide range of frames in-store.
[Book an eye test](https://www.oscarwylee.com.au/locations)
## What are the Symptoms of Retinoblastoma?
The symptoms of retinoblastoma can include a white pupil reflection (leukocoria), crossed or misaligned eyes (strabismus), poor vision, red eye, eye pain and enlarged eye or swelling. If you experience a rapid change in your vision, please contact your optometrist or healthcare professional immediately, or visit the nearest emergency department. The symptoms of retinoblastoma are listed below.
* White Pupil Reflection (Leukocoria): A white pupil reflection (leukocoria) can be a notable symptom of retinoblastoma and may be more noticeable in photos or during low-light conditions. According to the Raising Children Network, a white pupil (leukocoria) may resemble a cat's eye or a glow or glint in the eye. Usually, when a light is shone in the eye, it would be a red reflex, as light bounces off the retina. If a mass obstructs the eyes and reflects incoming light instead of the retina, this can result in leukocoria.
* Crossed or Misaligned Eyes (strabismus): Crossed or misaligned eyes can occur as a symptom of retinoblastoma, which causes one or both eyes to appear turned outward, inward or misaligned. Retinoblastoma may lead to this symptom, potentially due to the tumour damaging central vision.
* Poor Vision: Poor vision may be a symptom of retinoblastoma and may likely occur as a result of increased pressure in the eye or from the tumour physically pressing on the structures of the eye. Poor vision can ensue during retinoblastoma from the growth of the tumour on the retina.
* Red Eye: A red eye may be a symptom of retinoblastoma through a tumour-related inflammation, increased eye pressure or irritation.
* Eye Pain: Eye pain may ensue as a result of retinoblastoma due to the tumour itself, increased ocular pressure and/or inflammation. The severity of [eye pain](https://www.oscarwylee.com.au/glasses/eye/pain-definition) may depend on the extent of the condition.
* Enlarged Eye or Swelling: An enlarged eye or swelling may arise as a symptom of retinoblastoma, primarily as a result of the tumour growth. This may stem from the physical presence of the tumour, high intraocular pressure and/or inflammation.
### How does Retinoblastoma Affect Vision and Eye Alignment?
Retinoblastoma may affect vision and eye alignment as a result of the tumour growing on the retina. The retina is located in the inner layer of the back of the eye and is responsible for turning light that enters the eye into electrical signals, which are sent to the brain. The brain then interprets these signals as a visual image. This is why the development of retinoblastoma can harm vision or eye alignment due to where it occurs and the physical nature of the disease.
#### Can Retinoblastoma Cause Crossed Eyes or Vision Loss?
Yes, retinoblastoma may cause [crossed eyes](https://www.oscarwylee.com.au/glasses/eye/crossed-definition) or vision loss as it causes a tumour to develop in the retina. Retinoblastoma may lead to crossed eyes due to the consequential vision loss, which can cause the brain to stop using the affected eye, together with the healthy eye.
## How is Retinoblastoma Diagnosed?
Retinoblastoma may be diagnosed initially through a routine eye test with an optometrist who will then refer you to an ophthalmologist for further examination. Retinoblastomas are rare in adults, so majority if retinoblastomas are detected by a paediatric specialist during checkups in early infancy. Your eye test with the optometrist will be helpful in identifying all the structures in the eye for growths, inflammation or changes to your blood vessels. The ophthalmologist will then be able to examine your condition further for the next steps in treatment. If you notice any changes in your vision, it is important to book an eye test with an optometrist so that the health of your eyes can be assessed.
### What Clinical Examinations Detect Retinoblastoma?
The clinical examinations that can detect retinoblastoma can include looking at your medical history, family history, an eye test, blood tests and medical imaging, according to Children's Health Queensland. The clinical examinations that can detect retinoblastoma are listed below.
* Medical History: Your medical history can be helpful for diagnosing retinoblastoma, as it can help the eye care professional rule out certain factors that can increase the likelihood of developing the disease.
* Family History: Considering your family history will also be inquired about during examination due to the potentially inheritable nature of the disease.
* Eye Test: An eye test is a crucial form of examination that can detect retinoblastoma as it allows eye care professionals to check all important regions of the eye, especially the retina and assess your vision.
* Blood Test: A blood test may be carried out to identify any mutations in the RB1 gene.
* Medical Imaging: Medical imaging may be used to detect retinoblastoma and include options such as an ultrasound of the eye, an MRI scan or a CT scan.
#### Is Genetic Testing Necessary for Family Members?
Yes and no, genetic testing may be necessary for family members if the faulty gene that causes the cancer is identified. In this case, genetic testing may be offered to family members, according to the Cancer Council Australia. However, you may need to consult with your family doctor more about whether this is necessary for you and your family. Oscar Wylee does not offer genetic testing services.
## What are the Treatment Options for Retinoblastoma?
The treatment options for retinoblastoma can include chemotherapy, laser therapy, cryotherapy, radiation therapy and enucleation. According to the Sydney Children's Hospitals Network, treatment options will depend on the size of the tumour, whether it is in one or both eyes and if it has spread to other parts of the body. The possible treatment options for retinoblastoma are listed below.
* Chemotherapy: Chemotherapy is a possible treatment option for retinoblastoma and involves the use of drugs to eliminate or delay the growth of cancer cells.
* Laser Therapy: Laser therapy is a treatment option for retinoblastoma that uses an infrared laser to increase the temperature of the tumour to shrink and eliminate cancer cells.
* Cryotherapy: Cryotherapy is another treatment option for retinoblastoma that freezes off cancerous tumours and/or growths with liquid nitrogen.
* Radiation Therapy: Radiation therapy is another treatment option for retinoblastoma that utilises managed doses of radiation to damage or kill cancer cells.
* Enucleation: Enucleation is a potential treatment option for retinoblastoma and involves surgically removing the entire eyeball from the orbit, while leaving the eye muscles that are responsible for eye movement intact.
### How is Chemotherapy Used to Treat Retinoblastoma?
Chemotherapy may be used to treat retinoblastoma by shrinking the tumours and killing cancer cells. Chemotherapy can be conducted through many different methods, such as directly into the vitreous humour, through a catheter inserted into an artery, typically in the thigh and through the veins or mouth to cover the whole body.
##### Can Prescription Glasses Improve Vision After Eye Cancer Treatment?
Yes and no, prescription glasses may improve your vision after eye cancer treatment; however, this will depend on your condition. Cancer treatments can lead to changes in your eyes and vision, and the outcome can vary between individuals, according to Cancer Care (2024). The eye care professional treating the disease will let you know the next steps post-treatment, including the use of [prescription glasses](https://www.oscarwylee.com.au/glasses/prescription).
Read Retinoblastoma: Causes, Symptoms and Treatment in other Oscar Wylee regions and their languages.
Australia
Australia
New Zealand
Canada
Canadian French
 
Major Health Funds Accepted In‐store
For the purchase of frames and lenses, use your private health fund insurance to cover some of the cost.
[Explore Health funds](https://www.oscarwylee.com.au/health-funds.html)
When was your last eye test?
At Oscar Wylee we offer bulk billed eye tests for eligible medicare card holders.
[Book an eye test](https://www.oscarwylee.com.au/booking)