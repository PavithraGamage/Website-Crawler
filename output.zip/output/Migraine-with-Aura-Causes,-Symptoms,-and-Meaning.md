# Source: https://www.oscarwylee.com.au/glasses/eye/migraine-with-aura

# Migraine with Aura: Causes, Symptoms, and Meaning
Published on July 31st, 2026
A migraine with aura refers to a migraine that also entails symptoms affecting vision, sensory and other neurological functions, according to Headache Australia Organisation. Visual symptoms include blurry vision, blind spots, zigzag lines in your vision and flashes of bright light. Read more about migraine with aura, including stages, symptoms and diagnosis.
You should seek out professional medical help for a migraine with aura. This can be done by a general practitioner or neurologist, however an optometrist can perform a comprehensive eye test to rule out underlying ocular conditions.
Prioritise Your Eye Health
Our team can help you stay up to date with regular eye tests to keep your eyes healthy!
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Definition](#definition) [Cause](#cause) [Symptoms](#symptoms) [Stages](#stages)
## What is a Migraine With Aura?
A Migraine with aura is a type of migraine characterised by neurological complications that appear during the headache, encompassing vision, sensory, and speech and language symptoms, according to Migraine Australia.
### What does "Aura" Mean in a Migraine?
"Aura" in terms of a migraine refers to a set of neurological symptoms you may experience as part of a migraine, according to The Migraine Trust Organisation. These auras are usually related to sight, such as blurred vision and seeing coloured spots.
#### Is a Migraine Aura Always Followed by a Headache?
No, a migraine aura is not always followed by a headache. A migraine aura without headache is known as a "silent migraine," and can be more common as people age, according to Migraine &amp; Headache Australia.
## What Causes Migraine With Aura?
The cause of migraine with aura is believed to be through a wave of electrical activity, called cortical spreading depression, that spreads across the brain cortex, according to Migraine Australia. This leads to a reduced nerve cell activity wherein the sensory system and vision is negatively affected.
### How Does a Migraine Aura Affect the Brain?
A migraine aura affects the brain because it is due to electrical or chemical waves that move through the brain, according to The Mayo Clinic. However, there is no harm caused to the brain as a result of this.
#### Can Migraine Aura Happen Without a Known Trigger?
Yes, a migraine aura can happen without a known trigger or catalyst.
## What are the Symptoms of Migraine With Aura?
The symptoms of migraine with aura encompass a variety of symptoms related to vision, the sensory system and speech. The vision-related symptoms include blurred vision, blind spots, seeing zigzag lines and flashing lights. Read more about the symptoms of migraine with aura below.
* Blurred Vision: Blurred vision, or foggy vision, is a common symptom of migraine with aura. Vision will be less sharp and clearer for those affected by a migraine with aura.
* Blind Spots: Blind spots may appear in your vision as a result of a migraine, where black or blurry spots will appear in your line of vision.
* Seeing zigzag lines: Seeing zigzag lines in your vision is a symptom that is commonly associated with migraines with aura.
* Flashing lights: Flashing lights and bright spots in your vision are a common sign of migraine with aura.
Find Your Nearest OW Store!
We've got knowledgeable teams who are passionate about delivering high-quality care.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
### What does a Visual Aura Look Like?
Visual aura can look like zigzag lines, flashing lights and blurred vision, alongside other visual impediments for the affected individual, according to the Sydney Headache and Migraine Clinic.
#### Can Migraine Aura Cause More Than Vision Changes?
Yes, migraine auras cause more than vision changes. While vision changes are the most common, sensory and motor functions can also be compromised.
##### Can Migraine With Aura Cause Blurred Vision?
Yes, migraine with aura is known to cause [blurred vision](https://www.oscarwylee.com.au/glasses/eye/blurred-vision).
## How Long Does a Migraine Aura Last?
A migraine aura can typically range from five minutes to an hour, according to Migraine Australia.
### What Happens During Each Stage of Migraine With Aura?
There are four stages of the migraine with aura: the premonitory stage, aura, main attack and postdrome, according to The Migraine Trust Organisation. Read below for an outline of what happens during each stage of migraine with aura.
* Premonitory stage: The premonitory stage is the beginning of the migraine with aura. You will start presenting with warning symptoms such as tiredness, difficulty concentrating and light sensitivity.
* Aura: Aura is the next stage wherein neurological issues such as vision difficulties, speech impediments and pins and needles are some of the problems that may emerge.
* Main Attack: The main attack the headache symptoms will begin. A severe, throbbing headache will take place, leading to general sickness symptoms.
* Postdrome: Postdrome is the end part of the migraine with aura where the headache will resolve, but lingering symptoms will remain, such as tiredness and difficulty concentrating.
#### Can Migraine Aura Last Longer Than One Hour?
Yes, migraine aura can last longer than one hour. However, this is relatively rare, and a health professional should be consulted if the migraine aura lasts more than an hour.
## How Is Migraine With Aura Diagnosed?
A migraine with aura will be diagnosed by a general practitioner or neurologist, according to Migraine and Headache Australia. You will need to have experienced a certain number of symptoms and have had two attacks.
### What Can Help Prevent Migraine With Aura?
To prevent a migraine with aura, you can identify key triggers, get enough sleep, and try certain medications. Read more about these preventative measures for migraine with aura below.
* Identify key triggers: Identify key triggers that you believe bring about the onset of migraines with aura. Some common ones include dehydration, excess caffeine intake and even stressful events. This will allow you to alter your lifestyle as much as possible to ensure triggers are minimised.
* Get enough sleep: Get enough sleep every day as this is known to reduce the potential of migraines with aura emerging, according to the Mayo Clinic. It is also important not to sleep too much, as this can also trigger migraines.
* Try certain medications: Trying certain medications when you feel the onset of a migraine with aura can mitigate the severity of it. Anti-inflammatory medicines and anti-nausea medicines can be helpful for certain individuals, which is best to check with a general practitioner.
#### Can Blue Light Glasses Help Reduce Migraine Symptoms?
[Blue light glasses](https://www.oscarwylee.com.au/glasses/eye/blue-light) may help reduce migraine symptoms. However, they are not a preventive measure or cure. You should keep your eyes away from digital devices whilst a migraine is occurring, and ensure the room you are resting in is dark, according to Health Direct Australia.
##### Can Transition Lenses Help People With Light Sensitivity During Migraine Attacks?
Yes, [transition lenses](https://www.oscarwylee.com.au/glasses/eye/photochromic-lenses) may help people with light sensitivity during migraine attacks, particularly if they are outside. However, they are not a cure for migraines with aura.
### How Is Migraine With Aura Different From Other Conditions?
A migraine with aura is different from other conditions as it involves neurological symptoms before or during the headache, unlike other types of headaches, which often do not. The "aura" predominantly affects the visual system, and it originates from the brain's visual cortex, according to Sydney Headache &amp; Migraine Clinic. Migraine with aura may be mistaken for a retinal detachment. However, a retinal detachment is a medical emergency that requires immediate medical attention. Common vision symptoms of retinal detachment are light flashes, an increase in floaters, a dark curtain appearing at the edge of your vision and distorted vision, according to Health Direct Australia.
### How is Visual Snow Syndrome Different From Migraine With Aura?
Visual snow syndrome is different from migraine with aura as it resembles television-like static in your line of vision, whereas those with migraine with aura will experience symptoms varying from blurred vision, zig-zag lines in your vision and [flashing lights](https://www.oscarwylee.com.au/glasses/eye/seeing-flashing-lights-in-corner-of-eye).
#### Can Migraine Aura be Mistaken for a Stroke?
Yes, in some cases, a migraine aura can be mistaken for a stroke due to the neurological complications of both, such as vision and sensory issues.
## How is Migraine With Aura Treated?
A migraine with aura is treated through over-the-counter medication such as ibuprofen, anti-nausea medication, and cold compresses whilst resting in dark rooms, according to Headache Australia.
### What Is the Difference Between Migraine With Aura and Ocular Migraine?
The difference between migraine with aura and ocular migraine are which eyes are affected and how they originate. Read more about these differences below.
| Migraine with Aura | Ocular Migraine |
| --- | --- |
| Usually affects both eyes | Affects one eye only |
| Originates in the brain; a neurological condition | Caused by changes in blood vessels |
#### Can You Have Both Migraines With and Without Aura?
Yes, you can have both migraines with and without aura-related symptoms. These are simply referred to as Migraine Without Aura.
Experience High Quality Eyecare Services From Our Team
Book an appointment online with an Oscar Wylee optometrist today.
[Book an eye test](https://www.oscarwylee.com.au/booking)
Major Health Funds Accepted In-store
For the purchase of frames and lenses, use your private health fund to limit how much you pay from your own pocket.
[Health Funds](https://www.oscarwylee.com.au/health-funds.html)