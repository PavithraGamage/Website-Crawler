# Source: https://www.oscarwylee.com.au/glasses/collection/kids-collection.html

## Flexible hinges
Hinges made to bend and flex, tough enough for the everyday
activities of kids.
## Shatter-resistant lenses
Made from a polycarbonate material, our kids' 1.59 index lenses are
more durable for children.
## Accessories
New adjustable ear grips and a neck band to make the glasses hard to
lose.
## Comfortable materials
The frames are made from latex-free, hypoallergenic materials,
perfect for your little ones.
Does your child need an eye test? Learn more about how regular
[eye exams for children](https://www.oscarwylee.com.au/glasses/eye/exam-for-children)
may benefit their overall health and well-being.
7 Products        
Showing 7
1. [](https://www.oscarwylee.com.au/sammie-optical.html)
[Sammie](https://www.oscarwylee.com.au/sammie-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/sammie-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/sammie-optical.html)
2. [](https://www.oscarwylee.com.au/bowie-optical.html)
[Bowie](https://www.oscarwylee.com.au/bowie-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/bowie-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/bowie-optical.html)
3. [](https://www.oscarwylee.com.au/ruthie-optical.html)
[Ruthie](https://www.oscarwylee.com.au/ruthie-optical.html)
$169
4. [](https://www.oscarwylee.com.au/eleonore-optical.html)
[Eleonore](https://www.oscarwylee.com.au/eleonore-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/eleonore-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/eleonore-optical.html)
5. [](https://www.oscarwylee.com.au/lucien-optical.html)
[Lucien](https://www.oscarwylee.com.au/lucien-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/lucien-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/lucien-optical.html)
6. [](https://www.oscarwylee.com.au/thais-optical.html)
[Thais](https://www.oscarwylee.com.au/thais-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/thais-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/thais-optical.html)
7. [](https://www.oscarwylee.com.au/glasses/collection/parker-small-optical.html)
[Parker Small](https://www.oscarwylee.com.au/glasses/collection/parker-small-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/glasses/collection/parker-small-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/glasses/collection/parker-small-optical.html)
7 Products        
Showing 7
Choosing the Best Glasses
Best Material
Width &amp; Colour
Price, Shipping + FAQs
## How to Choose the Best Glasses Frame for Kids?
To choose the best glasses for kids, you should
consider a child's eye care needs, their lifestyle factors
and their personality.
The ways to choose the best glasses for kids are listed below.
1. Consider a child's eye care needs: Considering a child's eye care needs is an important step in
choosing the best frames for them. Before buying glasses, it's
important to get your child's eyes tested to determine if or
what level of vision correction they need. Kids may also
benefit from sunglasses to protect their eyes from the sun.
2. Lifestyle factors: Lifestyle factors are
another important consideration in determining which frames
will be best for a child. Some younger children who are
active, may benefit from frames made from stronger, more
durable materials like TR90. Older children may be suited to
regular acetate or metal frames in a small size, a viable
option for tween or
[teen glasses](https://www.oscarwylee.com.au/glasses/collection/teen-boys-and-girls.html).
3. Consider personality: Considering personality
is another consideration when choosing the best glasses frames
for kids. If your child is vibrant in their clothing choice
and outgoing, frames in bright colours like pink and blue
might be a good choice. For kids who are more reserved, a
frame in a neutral colour like black may be a good choice.
[](https://www.oscarwylee.com.au/thais-optical.html)
[Thais](https://www.oscarwylee.com.au/thais-optical.html)
$169    
Add to Cart
[Shop Thais](https://www.oscarwylee.com.au/thais-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/thais-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/thais-optical.html)
[](https://www.oscarwylee.com.au/eleonore-optical.html)
[Eleonore](https://www.oscarwylee.com.au/eleonore-optical.html)
$169    
Add to Cart
[Shop Eleonore](https://www.oscarwylee.com.au/eleonore-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/eleonore-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/eleonore-optical.html)
[](https://www.oscarwylee.com.au/lucien-optical.html)
[Lucien](https://www.oscarwylee.com.au/lucien-optical.html)
$169    
Add to Cart
[Shop Lucien](https://www.oscarwylee.com.au/lucien-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/lucien-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/lucien-optical.html)
## Which Material is Best for Kids' Glasses?
The best material for kids' glasses is
mostly determined by a child's age and their lifestyle
factors.
For younger children who are active at day care or school,
frames made from durable materials like TR90 are a good choice.
At Oscar Wylee, our kids' glasses lenses are made from a
polycarbonate material, providing some
shatter-resistance. Our Oscar Wylee kids' glasses are also made
from
latex-free, hypoallergenic materials, which can
be more comfortable for younger children. The hinges in our
kids' frames are also made to bend and flex, tough enough for
the everyday activities of kids. For older children, they may be
well suited to regular adult frames made from materials such as
[acetate](https://www.oscarwylee.com.au/glasses/acetate-frame),
[titanium](https://www.oscarwylee.com.au/glasses/materials/titanium.html),
[bio-acetate](https://www.oscarwylee.com.au/glasses/materials/bio-acetate.html)
or
[TR90](https://www.oscarwylee.com.au/glasses/tr90),
made in smaller sizes.
### Which Frame is Best for Toddler Glasses?
The
best frames for toddler glasses are typically those that are
made with durable materials.
Toddlers can be very active and not as considerate with frames
that older kids may be. Durable frames with shatter-resistant
lenses and flexible hinges, such as those available at Oscar
Wylee, will be a good frame choice for toddlers. Toddlers may
also benefit from ear grips or a neck band, which makes the
glasses harder to lose.
## How to Buy Kids Glasses According to Width?
To buy kids' glasses according to width
refers to buying frames to fit the size of a child's
face.
Generally,
kids' glasses sold by optical retailers will come in a
standard, small or extra small size, to fit kids'
faces.
At Oscar Wylee, our glasses designed for children are an extra
small size. If you have an older child who may not fit into
extra small kids' glasses, there are small and narrow sizes of
frames designed for adults that may fit these needs.
### Which Colour Pattern is Best for Kids' Glasses Frames?
The colour pattern that is best for kids' glasses frames
will be up to the personality and style preferences of the
child.
The types of colour patterns that are available for kids'
glasses at Oscar Wylee include
matte, solid and two-tone. At Oscar Wylee, some
of our frames also come with fun animal prints on the temples.
The best colour patterns for kids' glasses frames are listed
below.
* Matte: Matte colour patterns are available
for kids' frames at Oscar Wylee, from pinks, blacks and blues.
Matte refers to a flat-looking, low-gloss finish.
* Solid: Solid colour patterns are also
available for kids' glasses at Oscar Wylee in blues, pinks and
black. Solid colour patterns refer to one uniform colour,
without any gradients.
* Two-tone: Two-tone colour patterns refer to
frames with two different colours or tones blending from the
top of the frame to the bottom, and are available in our kids'
frame, Stanislas.
### Which Colour is Best for Kids' Glasses?
The best colour for kids' glasses can include
blue, magenta, pink and black. The best colours
for kids glasses frames are listed below.
* Blue: Blue is a fun colour for kids frames,
coming in both light and darker blues at Oscar Wylee.
* Magenta: Magenta is a purple-red colour
available for kids frames at Oscar Wylee. Magenta is a bright,
fun colour for kids.
* Pink: Pink is a colour available at Oscar
Wylee for kids frames. Our pink frames can be both a lighter
and a darker print.
* Black: Black is a neutral colour, available
for kids' frames at Oscar Wylee.
[](https://www.oscarwylee.com.au/stanislas-optical.html)
[](https://www.oscarwylee.com.au/thais-optical.html)
[](https://www.oscarwylee.com.au/lucien-optical.html)
[](https://www.oscarwylee.com.au/stanislas-optical.html)
[](https://www.oscarwylee.com.au/thais-optical.html)
[](https://www.oscarwylee.com.au/lucien-optical.html)
### Which Colour Glasses are Best for Girls?
The
colour glasses that are best for girls are up to the
preference of the wearer. Whilst younger girls may gravitate towards lighter colours of
pink, magenta and blue, there is no best or preset colour for
girls.
### Which Colour Glasses are Best for Boys?
The
best glasses colour for boys depends on the child and their
colour preferences.
Younger boys may favour colours such as blues, black and greens,
but can also have pinks, magenta and reds as a glasses frame.
Ultimately, there is no best or preset colour for boys' glasses.
## What are the Price Factors for Kids' Glasses?
The
price factors for kids’ glasses will vary depending on the
retailer, as well as elements such as material, add-ons and
lens types. At Oscar Wylee, 1 pair of kids' glasses starts from $169, 2
pairs from $199 and 3 pairs from $249. See our[price guide](https://www.oscarwylee.com.au/price-guide/)
page for more information.
### What is the Duration of Shipment for Kids' Glasses?
At Oscar Wylee the
duration of shipment for kids' glasses is usually within 7-10
business days.
If a person is shipping to their home, this can take up to two
weeks.
[Oscar Wylee](https://www.oscarwylee.com.au/) ships
domestically only.
### Why Should Blue Light Filter be Considered for Kids' Glasses?
Blue light filters should be considered for kids' glasses,
more likely older kids' glasses, if the child is spending a
lot of time on digital screens, such as tablets, computers and
phones.
Blue light filters are made to help block or reduce the blue
light that digital screens emit. Blue light filters may help
limit eye strain, improve comfort while using devices and
improve sleep quality.
### What Accessories are Available for Kids' Glasses?
The accessories available for kids' glasses
will depend on the optical retailer from which they are
bought.
At Oscar Wylee, our kids' glasses come with adjustable ear grips
and some with a neck band, to make the glasses hard to lose.
### What are the Standard Lenses that Come with Kids' Glasses?
The
standard lenses that come with kids' glasses at Oscar Wylee
are 1.59 index lenses, made from polycarbonate
materials.
[Prescription Glasses](https://www.oscarwylee.com.au/glasses.html)
[Women’s Glasses](https://www.oscarwylee.com.au/glasses/collection/womens-glasses.html)
[Men’s Glasses](https://www.oscarwylee.com.au/glasses/collection/mens-glasses.html)
[Senior Glasses](https://www.oscarwylee.com.au/glasses/collection/seniors.html)
[Glasses for Kids](https://www.oscarwylee.com.au/glasses/collection/kids-collection.html)