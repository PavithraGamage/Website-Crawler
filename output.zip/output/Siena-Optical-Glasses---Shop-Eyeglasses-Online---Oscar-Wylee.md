# Source: https://www.oscarwylee.com.au/siena-optical.html

# Siena
1
## Frame Design of Siena Glasses
The frame design of Oscar Wylee’s Siena glasses is characterised by their oval and round shape, nose pads, and ultralight stainless steel and acetate frame. Siena is a sophisticated women’s glasses frame that will complement any outfit, day to night.
$169    
In stock
Only %1 left
2 pairs from $199
Discount auto-applied at checkout
3 pairs from $249
Discount auto-applied at checkout
Qty
Add to cart
Book an eye test
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
excluding prescription lenses
## About Siena Frames
The lustrous Siena showcases a sleek oval frame, exuding an IT girl energy and an effortlessly modern charm.
| Frame fit | Measurements |
| --- | --- |
| NARROW | 51 - 18 - 140 |
These measurements mean lens width, bridge, and temple length in millimetres (mm). They can be found on the inside of the temple arm. If you already have a pair that you like, you can compare it to these measurements.
### Made from Stainless Steel and Acetate
Oscar Wylee's Siena frame is a women's oval and round glasses frame that is perfect for narrow faces and those with square, oval, and heart face shapes. The Siena frame is a sleek, stylish frame that can be worn every day. The main specs of Oscar Wylee's Siena glasses frame, including dimensions, shape, materials, lenses, nose fit and hinges are listed below.
| Siena Frame Features | Siena Frame Description | Dimensions | Shape | Materials | Lenses | Nose Fit | Hinges |
| --- | --- | --- | --- | --- | --- | --- | --- |
| The dimensions of the Siena frame are measured in millimetres (mm) and are 51 - 18 - 140, meaning the lens width is 51 mm, the bridge is 18 mm, and the temple length is 140 mm. |
| The Siena frame is an oval and round shape, well-suited to narrow faces. |
| Siena glasses are made from stainless steel and acetate. |
| The lenses that can be used in the Siena frame are optical lenses, which include single vision and multifocal lenses and non-prescription lenses, which are plain and can have a filter such as a blue light filter applied. |
| The nose fit of Siena frames is characterised by nose pads. |
| The hinges in the Siena frame are normal hinges, also known as standard or barrel hinges. These provide strength and smooth movement connecting the frame's arms and lenses. |
Show All
### What Inspired the Frame Design of Oscar Wylee's Siena Glasses?
The Oscar Wylee Siena frame design was inspired by current fashion trends, as oval and round shapes are often in fashion.
## What to Know About Oscar Wylee's Siena Glasses?
There are many aspects of the Oscar Wylee Siena frames that customers should know about to decide whether this is the right frame for them. The Siena frame is a women's oval and round glasses frame. Oscar Wylee's Siena frame is suitable for many face shapes, but particularly compatible with square, oval, and heart face shapes. The Siena frame's simple and classic design means that they are fashionable all year round. Siena features the standard [parts of glasses](https://www.oscarwylee.com.au/glasses/eye/part-of-glasses), such as a rim, temples, lenses, hinges, and nose pads.
### What are the Types of Temple Tips or Earpieces Included with Oscar Wylee's Siena Glasses?
The type of temple tips or earpieces included in Oscar Wylee's Siena Glasses are made from acetate.
### What Type of Nose Bridge do Oscar Wylee's Siena Glasses Have?
The type of nose bridge included in Oscar Wylee's Siena frame is characterised by nose pads.
### What Type of Nose Pads are Included with Oscar Wylee's Siena Glasses?
Oscar Wylee's Siena frame includes standard nose pads. Nose pads are adjustable for a perfect fit.
### What Type of Lenses do Oscar Wylee's Siena Glasses Have?
The type of lenses that typically come with the Oscar Wylee Siena [glasses frame](https://www.oscarwylee.com.au/glasses.html) are optical lenses. Optical lenses are glasses lenses that have a prescription within the lens to help correct vision issues such as myopia, hyperopia and astigmatism. Siena can also come with non-prescription lenses, with add-ons such as a blue light filter. Siena frames can be customised into sunglasses in-store or online with add-on tints or polarisation.
### What Material is Used for the Rim of Oscar Wylee's Siena Glasses?
The material used for the rim of Oscar Wylee's Siena glasses frames is stainless steel. The rim refers to the part of a glasses frame that holds the lenses.
### What Type of Hinges are Included with Oscar Wylee's Siena Glasses?
The type of hinges included with Oscar Wylee's Siena frames are normal hinges, also known as standard or barrel hinges. These provide strength and smooth movement connecting the frame's arms and lenses.
## What Face Types are Most Suitable for Oscar Wylee's Siena Glasses?
The face types most suitable for Oscar Wylee's Siena frame are square, oval, and heart face types. The Siena frame is an oval and round shape, meaning it complements the structure of square, oval, and heart faces particularly well. The oval and round Siena frames help balance the features of a [square face shape](https://www.oscarwylee.com.au/glasses/face-shapes/square), an [oval face shape](https://www.oscarwylee.com.au/glasses/face-shapes/oval), or a [heart face shape](https://www.oscarwylee.com.au/glasses/face-shapes/heart), bringing the eyes and brows forward in a flattering way. Although there are many different [glasses for face shapes](https://www.oscarwylee.com.au/glasses/face-shapes) that may be considered more aesthetically suitable, it is important that people also choose frames that make them feel most comfortable and represent their personal style.
## What Size Options are Available for Oscar Wylee's Siena Glasses?
The size options available for Oscar Wylee's Siena frame are a narrow-frame fit across all colours.
## What Materials are Used to Create Oscar Wylee's Siena Glasses?
The primary material used to create the Oscar Wylee Siena frame is stainless steel, with acetate temple tips. Stainless steel is a durable iron-based alloy. Acetate, also known as cellulose acetate, is a bioplastic made from cotton fibres or wood pulp.
## What’s Included
## OW Case &amp; Cloth
Protective Case and Lens Cloth
Our high-quality glasses case and lens cloth are included with every purchase of an Oscar Wylee frame. The stylish, magnetic case is made from a hard shell. This sturdy and durable material keeps your glasses protected and safe, wherever you go. Ensure your lenses are clean and scratch-free with our OW microfibre cloth, specifically designed to ensure you have comfortable vision through your lenses.
Oscar Wylee offers:
* Free Shipping on all orders
* 1 Year Warranty on frames and lenses
* Scratch resistance lens coating on all prescriptions
* UV-proof coating on all prescriptions
Health fund rebate: Once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. Learn more about [health funds](https://www.oscarwylee.com.au/health-funds.html).
## Make and Materials
As part of our durable frame family, some of our most popular styles, are now in stainless steel. These frames are hypoallergenic, corrosion resistant, light weight, and not sensitive to temperature changes. The frames then go through cleaning and strict quality control, and many pairs of crafting hands to be hand-assembled and polished. After your frames have gone through the production process, they are individually examined and packed before making their way to you!
## Warranty Information
### Warranty Information
### Warranty Information
Oscar Wylee provides a 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects. We will repair or replace faulty or defective frames or lenses free of charge for warranty claims made within 1 year of the delivery. We also offer repairs or replacement for problems experienced with vision during everyday use for claims made within 30 days of delivery. If the same product has been discontinued or is no longer available, then we may offer an exchange for a similar product or a refund.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Find a Store Location](https://www.oscarwylee.com.au/locations/full-store-list.html)