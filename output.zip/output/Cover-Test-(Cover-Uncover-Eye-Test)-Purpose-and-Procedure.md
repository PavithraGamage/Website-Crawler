# Source: https://www.oscarwylee.com.au/glasses/cover-test-eye-test

# Cover Test (Cover-Uncover Eye Test): Purpose and Procedure
Published on July 9th, 2024 
Published on January 28th, 2026
New Zealand
Australia
New Zealand
Canada
 
The cover test, also known as the cover-uncover eye test, is a test used for the purposes of detecting ocular misalignment or vision impairment, such as strabismus, according to the Western Australia Child and Adolescent Health Service. Read more about the Cover Test such as how it's undertaken, what it detects and its importance.
Look After Your Eyes at Oscar Wylee!
Book an eye test with our Oscar Wylee optometrists for passionate eye care services.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Definition](#definition) [Importance](#importance) [Process](#process) [Results](#results)
## What is the Cover Test in an Eye Exam?
A cover test, also known as a cover-uncover test, may be conducted as part of a comprehensive eye exam to assess eye problems around alignment. Eye or ocular misalignment includes strabismus or a squint. This can appear as one of the eyes pointing inwards, towards the nose, or outwards, towards the ears.
### What Does the Cover Test Measure in Eye Alignment?
The cover test measures in regards to eye alignment, how coordinated and aligned both eyes work together. This allows optometrists to assess the presence of strabismus and phoria within patients.
### How is the Cover-Uncover Test Different From the Alternate Cover Test?
The cover-uncover test is different from the alternate cover test based on what they measure. The cover-uncover test determines if a patient has either a phoria or a tropia. The alternate cover test is used to measure the severity and direction of the misalignment for both a phoria or a tropia. The cover-uncover test is done before the alternate cover test.
#### Does the Cover Test Detect Eye Misalignment Even Without Symptoms?
The cover test generally requires some degree of symptoms to detect eye misalignment. The test requires the eyes to be moving outwards towards the ear, or inwards towards the nose, for eye misalignment to be detected.
#### Does the Cover Test Check if Both Eyes Work Together?
Yes, the cover test checks if both eyes are working together, also known as binocular vision. If the eyes are not working together when focusing on an object, this indicates eye misalignment.
## Why is the Cover Test Important for Eye Health and Vision Correction?
The cover test is important for [eye health](https://www.oscarwylee.com.au/glasses/eye/health-tips-keeping-eyesight-healthy) and vision correction, as it is used to diagnose eye misalignment, such as strabismus. Whilst eye misalignment is not a serious, life-threatening condition, it can affect a person’s vision, and affect quality of life. Issues that may arise as a result of eye misalignments include double vision, [blurred vision](https://www.oscarwylee.com.au/glasses/eye/blurred-vision), and affected depth perception.
### Why Do Eye Doctors Perform the Cover Test During Routine Eye Tests?
An eye care professional will generally perform the cover test during routine eye tests for children. In adults, this is usually done on indication. However, some optometrists may do it as part of their routine for every patient.
### How Does the Cover Test Help Diagnose Strabismus (Squint)?
The cover test helps diagnose [strabismus (squint)](https://www.oscarwylee.com.au/glasses/eye/crossed-definition) by assessing how well the eyes are working together, also known as binocular vision. It will detect the type of eye misalignment and the degree of misalignment.
#### Is a Cover Test Used in Lazy Eye Screening for Children?
Yes, a cover test is used when it comes to detecting a [lazy eye](https://www.oscarwylee.com.au/glasses/eye/lazy-definition) in children, also known as amblyopia. Amblyopia refers to a vision issue in which one eye has worse vision than the other due to developmental issues. A cover test can be conducted as part of an eye exam for children if amblyopia is suspected.
### How Do Eye Doctors Perform the Cover Test?
Eye doctors perform the cover test by having their patient focus on an object at either near or far distance. They will then place an opaque paddle or cover in front of one eye. The paddle is then removed, and the eye care professional will assess how much the eyes have to adjust or deviate (ocular deviation) to focus. After this initial cover test, an alternative cover test may be conducted in which the paddle is put over one eye, and then moved between one and the other to further assess eye movement. If the eye moves inwards when uncovered, the deviation is an exophoria, similarly if the eye moves outwards when uncovered the deviation can be considered an esophoria.
### Is the Cover Test Safe for Infants and Toddlers?
Yes, the cover test is safe for infants and toddlers. The cover test is an important and often used process [for eye screening for children](https://www.oscarwylee.com.au/glasses/eye/exam-for-children) for infants and toddlers to detect issues like lazy eye, crossed eyes, or focusing problems before they worsen. The cover test is non-invasive, and doesn’t require the patient to do actions beyond trying to focus the eyes.
### What Do Cover Test Results Mean?
The results of a cover test will indicate whether there is an ocular misalignment issue, such as strabismus. No ocular adjustment or eye movement means there is no misalignment. If there is a misalignment, it can be classified by the direction of eye alignment. According to the American Academy of Ophthalmology, esotropia refers to an eye that turns inwards towards the nose, exotropia refers to the eye turning towards the ear.
### When is a Prism Bar Cover Test Needed?
Prism bar cover tests are needed to help quantify the magnitude of the deviation or to measure it. This can be important for tracking the progress of vision therapy training or for calculations for strabismus surgery.
### Do Eye Movements During Uncovering Indicate Misalignment?
Yes, certain eye movements during uncovering can indicate misalignment. If the eye moves in towards the nose this is esophoria. For outwards towards ears, this is exophoria.
### How Do Cover Test Results Affect Glasses Prescription?
Cover test results affect glasses prescription, as they will tell an optometrist or eye care professional whether correction is needed for eye misalignment as well as power focus to correct myopia or hyperopia. Myopia and hyperopia are types of refractive errors, in which light does not focus on the eye properly. [Prescription glasses](https://www.oscarwylee.com.au/glasses/prescription), with a power over the lens, can be given to help reflect light on the retina properly, and help people see clearer. If a deviation is found via cover test, the optometrist may then conduct other tests to decide whether prism correction is also needed in the glasses prescription.
### How Does the Cover Test Help in Choosing the Right Glasses?
Yes, the cover test can help in choosing the right glasses, specifically in terms of lenses. There are certain lenses that can be created to help someone with binocular vision issues like strabismus, to see better. These lenses are called prism lenses, and they help bend light to hit the retina correctly.
Find Your Local Oscar Wylee Store
Do you need some new frames? Come and visit your local Oscar Wylee store where our friendly team will help you shop our range of vintage and modern-inspired glasses.
[Find an Oscar Wylee Store](https://www.oscarwylee.com.au/locations/full-store-list.html)
#### Can the Cover Test Determine if Prism Lenses are Necessary?
Yes, the cover test can help determine if prism lenses are necessary. [Prism lenses](https://www.oscarwylee.com.au/guides/lenses/prism-glasses.html) are special lenses that can help with binocular vision issues. Prism lenses work by bending the light that enters the eye, focusing it on the correct spot of the retina.
#### Can Proper Glasses Reduce Eye Strain Caused by Misalignment?
Yes, proper glasses, referring to glasses that are appropriate for the vision issue strabismus, can reduce [eye strain](https://www.oscarwylee.com.au/glasses/eye/strain) caused by misalignment. These glasses that you will be prescribed may include prism lenses, which are combined with regular lens prescriptions. Prism lenses function by making the wearer believe the object they are viewing is in a different location, in order to improve eye alignment, according to the Optometrists Organisation. As a result of these lenses, eye strain and headaches that come as a result of eye misalignment can be reduced.
## When to See a Doctor After a Cover Test?
Generally, it is not required to see a doctor after a cover test, as your eye care professional will be able to treat this issue. If someone is suffering from issues such as headaches, eye strain or double vision as a result of strabismus, then they may want to consult a doctor for suggestions on management.
### What Symptoms Require Further Evaluation After a Cover Test?
Symptoms that may require further evaluation after a cover test may include double vision, eye strain and trouble focusing. The cover test can be considered a screening tool, as opposed to a diagnostic test and further investigations into binocular vision is usually warranted.
### Should Frequent Headaches be Followed up After Abnormal Results?
Frequent headaches may be a result of misaligned eyes. If the cover test results indicate that you have misaligned eyes, then your optometrist may conduct further binocular vision testing to diagnose the misalignment and decide on a treatment plan.
#### Can Untreated Eye Misalignment Worsen Without Glasses or Treatment?
Yes, untreated eye misalignment can worsen without glasses or treatment. There are a myriad of complications that can arise as a result such as developing a lazy eye, double vision or having reduced depth perception, according to Clarity Eye Surgeons Australia.
### How Often Should the Cover Test Be Repeated?
The cover test should be repeated on the same eye around 2-3 times by your optometrist so they can verify their findings.
Read Cover Test (Cover-Uncover Eye Test): Purpose and Procedure in
other Oscar Wylee regions and their languages.
New Zealand
Australia
New Zealand
Canada

Are You Due for an Eye Test?
Look after your eyes at Oscar Wylee and book an eye test with our dedicated optometrists, bulk billed under Medicare for eligible cardholders.
[Book an eye test](https://www.oscarwylee.com.au/booking)
Oscar Wylee Accepts Major Health Funds In-store
Visit Oscar Wylee in-store for some new frames, and your health fund may help cover some of the cost.
[Explore health funds](https://www.oscarwylee.com.au/health-funds.html)