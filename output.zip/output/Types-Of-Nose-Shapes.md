# Source: https://www.oscarwylee.com.au/glasses/nose-types

# Types Of Nose Shapes
Published on July 24th, 2025
Updated on March 21st, 2025  
Australia   
[Australia](https://www.oscarwylee.com.au/glasses/nose-types)
New Zealand

[Canada](https://oscarwylee.ca/glasses/nose-types)
Canadian French

There are various types of nose shapes, such as the straight nose, aquiline nose, button nose, wide nose, celestial nose, Nixon nose and round nose. These nose types are influenced by culture, genetics and gender. Each is different and provides a distinct charm to any face. Nose shapes affect how glasses fit as they sit along the nose bridge. A frame that does not align with the nose bridge can be uncomfortable and sit awkwardly on the face. Read on to learn more about the types of nose shapes and their compatibility with different glasses bridges.
Book an Eye Test With Oscar Wylee Today
Our highly trained optometrists are available to provide bulk billed eye tests to eligible Medicare card holders.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Types Of Nose Shapes](#types) [Identifying My Nose Shape](#identify) [Common Nose Shapes](#common-nose) [Choosing The Right Glasses](#right-glasses)
The types of nose shapes include a straight nose, aquiline nose, button nose, wide nose, celestial nose, Nixon nose and round nose. The types of nose shapes are listed below.
* Straight Nose: The straight nose has a straight nose bridge without any humps or curves.
* Aquiline Nose: The aquiline nose has a prominent, often curved, nose bridge.
* Button Nose: The button nose refers to a nose with a small and rounded shape.
* Wide Nose: The wide nose is characterised by a wide bridge and separation between the nostrils
* Celestial Nose: The celestial nose is small, with a slight depression at the nose bridge and an upturned tip.
* Nixon Nose: The Nixon nose has a straight bridge and broad tip.
* Round Nose: The round nose has a rounded and curved tip, creating a curved silhouette.
* Fleshy Nose: The fleshy nose refers to noses with a larger size and more soft tissue.
## 1. Straight Nose
The straight nose has a distinct straight, high nose bridge without any humps or curves. They are a rarer nose type, and often contribute to a symmetrical looking face. Notable figures such as Jennifer Aniston and Princess Diana have this nose.
## 2. Aquiline Nose
The aquiline nose is distinct for its prominent, often curved, high nose bridge providing a distinctive appearance. The name "aquiline" derives from the Latin word "aquilinus," meaning "eagle-like." Notable examples of this nose include Barbra Streisand and Adrien Brody.
## 3. Button Nose
The button nose refers to a nose with a small and rounded profile and low nose bridge. Those with button noses will often have delicate, and sometimes youthful, features. Emma Stone and Elizabeth Taylor are notable figures with this nose type.
## 4. Wide Nose
A wide nose is characterised by a wide bridge and a visible separation between the nostrils, which are also notably wider than the typical nostril size.
## 5. Celestial Nose
The celestial nose is typically small, like a button nose. However, it is differentiated by a slight depression at the high nose bridge and an upturned tip, for a delicate appearance. Carey Mulligan and Emma Watson are examples of celebrities with a celestial nose.
## 6. Nixon Nose
### Nixon Nose Characteristics
The Nixon nose refers to a nose with a straight, high bridge which curves at the end and presents a broad tip. Its namesake is the 37th President of the United States, Richard Nixon, and it is considered a very rare nose type.
 
## 7. Round Nose
The round nose, as its name suggests, has a rounded and curved tip, creating a circular silhouette at the bottom of the nose. The low bridge is smooth with a lack of angular definition. Notable figures such as Khloe Kardashian and Bill Clinton have this nose.
## 8. Fleshy Nose
The fleshy nose has a larger size with more soft tissue than other nose types that are more angular. They have a rounded or wider appearance, notably at the nose tip. Celebrities with this nose type include Jennifer Lawrence and Mark Ruffalo.
Visit a Store Near You
Come in and see our friendly staff for all your optical and eyewear needs.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
## How Can I Identify My Nose Shape?
To identify your nose shape you should assess the bridge, tip of the nose, nostrils, overall size and identify your nose shape based on these characteristics. Read more about how to identify your nose shape below.
* Bridge: The bridge of your nose refers to the area of the nose extending from between the eyes down to the tip. Assess the appearance of your bridge, such as if it is straight, curved, has a bump, or is concave.
* Tip of the Nose: Describe the tip of the nose. For example: Is it rounded, pointed or bulbous?
* Nostrils: The nostrils are another characteristic to consider when identifying nose shape. Nostril shapes include narrow or small, round or oval, flared, or wide.
* Overall Size: Assess the overall size of your nose in proportion to your face and other features. Is it long or short? Is it wide or narrow?
* Identify your Nose Shape Based on These Characteristics: Identify your nose shape based on these characteristics. Once you have noted down the bridge, tip, nostrils and overall size of the nose, see if the majority of them align with a specific nose shape.
### Are Nose Shapes Different For Men And Women?
Yes, nose shapes can be different for men and women. Men tend to have larger noses than women, with broader nasal bases, larger nostrils and a more prominent nasal bridge. Contrastingly, women tend to have smaller noses with smaller nostrils, with a more elevated nose tip. However, this is not universal, and the nose shapes of men and women will differ through factors such as genetics. Nose shape plays a role in selecting [glasses for different faces shapes](https://www.oscarwylee.com.au/glasses/face-shapes).
## What Are The Different Types of Nose Bridges?
The different types of nose bridges are high nose bridges, low nose bridges and wide nose bridges. The nose bridge refers to the midline of the nose, called the "bridge" as it connects the tip of the nose to the face. Nose bridges play a key role in the fit of glasses, as the frame bridge should rest comfortably atop your nose bridge. Read more about these nose bridges below.
* High Nose Bridge: A high nose bridge is when the bridge of the nose is elevated away from the face and more pronounced in appearance.
* Low Nose Bridge: A low nose bridge is closer to the face, often resulting in a flatter profile that is less pronounced than the high nose bridge.
* Wide Nose Bridge: A wide nose bridge refers to a nose with a broader space across the top of the nose, providing a wider nose appearance.
### Which Nose Shape Fits Keyhole Bridge Glasses?
The nose shape that best fits keyhole bridge glasses are wide noses. The Keyhole Bridge as its name suggests, resembles an old-fashioned keyhole as it is stretched slightly on each side. This design distributes the weight of the frames to the sides of the nose, making it comfortable for those with wide noses.
### Which Nose Shape Fits Saddle Bridge Glasses?
The nose shape that fits saddle bridge glasses are a variety of nose types. The Saddle Bridge glasses are generally suited to a variety of nose shapes with varying bridges. It is ultimately best to try on the saddle bridge glasses to see if they accommodate your face well.
### Which Nose Shape Fits Low Bridge Fit Glasses?
The nose shapes that suit a low bridge fit glasses are shapes such as wide noses and button noses. Low bridge fit glasses refer to glasses with nose pads that are placed higher, allowing the glasses to sit up high and comfortably on a low nose bridge. This makes nose shapes such as button noses and wide noses, which have low nose bridges, compatible with low-bridge fit glasses.
[](https://www.oscarwylee.com.au/parker-optical.html)
[Parker](https://www.oscarwylee.com.au/parker-optical.html)
$169    
Add to Cart
[Shop Parker](https://www.oscarwylee.com.au/parker-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/parker-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/parker-optical.html)
[](https://www.oscarwylee.com.au/cara-optical.html)
[Cara](https://www.oscarwylee.com.au/cara-optical.html)
$169    
Add to Cart
[Shop Cara](https://www.oscarwylee.com.au/cara-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/cara-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/cara-optical.html)
[](https://www.oscarwylee.com.au/peyton-optical.html)
[Peyton](https://www.oscarwylee.com.au/peyton-optical.html)
$169    
Add to Cart
[Shop Peyton](https://www.oscarwylee.com.au/peyton-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/peyton-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/peyton-optical.html)
[](https://www.oscarwylee.com.au/odette-optical.html)
[Odette](https://www.oscarwylee.com.au/odette-optical.html)
$169    
Add to Cart
[Shop Odette](https://www.oscarwylee.com.au/odette-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/odette-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/odette-optical.html)
### Which Nose Shape Fits High Nose Bridge Glasses?
The nose shapes that fit high nose bridge glasses are shapes such as the Aquiline nose, Nixon nose and the straight nose. These nose shapes all have high nose bridges, which refer to nose bridges which are elevated and often angular, making them fitting for high nose bridge glasses.
[](https://www.oscarwylee.com.au/mumford-optical.html)
[Mumford](https://www.oscarwylee.com.au/mumford-optical.html)
$169    
Add to Cart
[Shop Mumford](https://www.oscarwylee.com.au/mumford-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/mumford-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/mumford-optical.html)
[](https://www.oscarwylee.com.au/zola-optical.html)
[Zola](https://www.oscarwylee.com.au/zola-optical.html)
$169    
Add to Cart
[Shop Zola](https://www.oscarwylee.com.au/zola-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/zola-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/zola-optical.html)
[](https://www.oscarwylee.com.au/andrew-optical.html)
[Andrew](https://www.oscarwylee.com.au/andrew-optical.html)
$169    
Add to Cart
[Shop Andrew](https://www.oscarwylee.com.au/andrew-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/andrew-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/andrew-optical.html)
[](https://www.oscarwylee.com.au/faye-optical.html)
[Faye](https://www.oscarwylee.com.au/faye-optical.html)
$169    
Add to Cart
[Shop Faye](https://www.oscarwylee.com.au/faye-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/faye-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/faye-optical.html)
### Which Nose Shape Fits Double Bridge Glasses?
The nose shapes that fit double bridge glasses are shapes such as button noses and wide noses. Double bridge glasses are characterised by an eyewear frame that has two parallel horizontal bars connecting the lenses above the nose bridge, rather than the typical single bridge. Button noses and wide noses are types that have low nose bridges, and double bridge glasses can provide a more comfortable and secure fit.
## What Is The Most Common Nose Shape?
The most common nose shape is the fleshy nose, with around 24.3% of people having a fleshy nose, according to a study called the Numerical Survey of the Different Shapes of the Human Nose. The fleshy nose has a larger size with more soft tissue than other nose types. They have a rounded or wider appearance, notably at the tip. Based on [glasses statistics](https://www.oscarwylee.com.au/glassses/how-many-people-wear-glasses) on usage around the world, it is important that various nose shapes are accommodated in glasses shapes.
### What Is The Rarest Nose Shape?
There is no clear answer as to what the rarest nose shape is. However, the Nixon nose shape is often regarded as one of the more rare types. The Nixon nose refers to a straight bridge nose curved at the end into a wider tip, resembling Richard Nixon's distinct facial feature.
## How To Choose The Right Eyewear Fit For Your Nose?
To choose the right eyewear fit for your nose, you should match the glasses nose bridge to your nose shape, consider adjustable nose pads and try your frames on. Read more on how to choose the right eyewear to fit your nose.
* Match the Glasses Nose Bridge to Your Nose Shape: Match the nose bridge to your nose shape for a compatible fit. For example, if you have a low nose bridge, where the bridge of your nose is set lower or flatter, opt for low nose bridge fit or double bridge glasses. If you have a high nose bridge, where the bridge of your nose is more pronounced or higher, opt for high nose bridge fit glasses.
* Consider Adjustable Nose Pads: Consider adjustable nose pads for your glasses. These will provide a more snug and comfortable fit, particularly for those with low nose bridges.
* Try Your Frames On: Ensure you try your frames on before purchasing. This will ensure they are snug and comfortable on the top of your nose.
### How Does Nose Shape Affect Eyeglass Fitting?
Nose shape affects eyeglass fitting, particularly through the nose bridge. Having a low or high nose bridge will affect the type of glasses that will best suit your face. For example, those with low nose bridges will be compatible with [prescription glasses](https://www.oscarwylee.com.au/glasses/prescription) that also have a low nose bridge fit.
#### Are Certain Nose Shapes Linked To Health Or Function?
No, certain nose shapes do not lead to better health or function. However, personal features of your nose regardless of your shape can affect how your nose functions. For example, a deviated septum, where the cartilage that separates the two nostrils is crooked or misaligned, can cause difficulty breathing. Additionally, a narrow or constricted nasal passage can also lead to breathing problems.
Read Types Of Nose Shapes in other Oscar Wylee regions and their languages.
Australia   
[Australia](https://www.oscarwylee.com.au/glasses/nose-types)
New Zealand

[Canada](https://oscarwylee.ca/glasses/nose-types)
Canadian French

Major Health Funds Accepted In-store
For the purchase of frames and lenses, use your private health fund insurance and you may minimise how much you pay from your own pocket.
[Explore health funds](https://www.oscarwylee.com.au/health-funds.html)
Are You Due For an Eye Test?
At Oscar Wylee we offer bulk billed eye tests for eligible medicare card holders.
[Book an eye test](https://www.oscarwylee.com.au/booking)