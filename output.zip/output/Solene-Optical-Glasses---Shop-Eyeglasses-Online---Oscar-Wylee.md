# Source: https://www.oscarwylee.com.au/solene-optical.html

# Solene
1
## Frame Design of Solene Glasses
The frame design of Oscar Wylee’s Solene glasses is characterised by their rectangle shape, low nose bridge, and acetate frame. Solene is a sophisticated unisex glasses frame that you can rely on day to night.
$169    
In stock
Only %1 left
2 pairs from $199
Discount auto-applied at checkout
3 pairs from $249
Discount auto-applied at checkout
Qty
Add to cart
Book an eye test
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
excluding prescription lenses
## About Solene Glasses
Introducing our Solene frame, a sleek rectangular silhouette with a modern, minimalist design made for effortless everyday wear. With a versatile unisex fit, Solene combines comfort and timeless style for every occasion.
| Frame fit | Measurements |
| --- | --- |
| WIDE | 54 - 19 - 145 |
These measurements mean lens width, bridge, and temple length in millimetres (mm). They can be found on the inside of the temple arm. If you already have a pair that you like, you can compare it to these measurements.
### Made from Acetate and Metal
Oscar Wylee’s Solene frame is a unisex rectangle glasses frame that is perfect for those with round and oval face shapes. The Solene frame is a stylish, modern frame that can be worn every day. The main specs of Oscar Wylee’s Solene glasses frame, including dimensions, shape, materials, lenses, nose fit, and hinges, are listed below.
Filter category 2 - General purpose sunglasses. Good protection against sunglare. Good UV Protection. Not suitable for driving in twilight, at night or under dull conditions 
This frame comes with tinted lenses. An additional $30 will be added to your order total for prescription orders. 

| solene Frame Features | solene Frame Description | Dimensions | Shape | Materials | Lenses | Nose Fit | Hinges |
| --- | --- | --- | --- | --- | --- | --- | --- |
| The dimensions of the Solene frame are measured in millimetres (mm) and are 54 - 19 - 145, meaning the lens width is 54 mm, the bridge is 19 mm, and the temple length is 145 mm. |
| Solene is a rectangle shape, well-suited to medium faces. |
| Solene is made from acetate. |
| The lenses that can be used in the Solene frame include optical lenses, such as single-vision, multifocal, and non-prescription lenses, which are plain and can have a filter, such as a blue-light filter, applied. |
| The nose fit for Solene is a low nose bridge fit. |
| The hinges in Solene are normal hinges, also known as standard or barrel hinges. |
Show All
### What Inspired the Frame Design of Oscar Wylee's Solene Glasses?
The Oscar Wylee Solene frame design was inspired by current fashion trends, as rectangle shapes are often in fashion. A rectangle glasses shape is timeless; it remains popular throughout the decades while other trends come and go.
## What to Know About Oscar Wylee's Solene Sunglasses?
There are many aspects of the Oscar Wylee Solene frames that customers should know about to decide whether this is the right frame for them. The Solene frame is a unisex, rectangle-shaped frame. Oscar Wylee’s Solene frame is suitable for many face shapes, but particularly compatible with round and oval face shapes. The Solene frame’s simple design makes them fashionable all year round. Solene features the standard [parts of glasses](https://www.oscarwylee.com.au/glasses/eye/part-of-glasses), such as a rim, temples, lenses, normal hinges, and a low nose bridge fit.
### What are the Types of Temple Tips or Earpieces Included with Oscar Wylee's Solene Glasses?
The type of temple tips or earpieces included in Oscar Wylee’s Solene Glasses are made from acetate.
### What Type of Nose Bridge do Oscar Wylee's Solene Glasses Have?
The type of nose bridge included in Oscar Wylee’s Solene frame is a low nose bridge fit.
### What Type of Nose Pads are Included with Oscar Wylee's Solene Glasses?
Oscar Wylee’s Solene frame does not include adjustable silicone nose pads.
### What Type of Lenses do Oscar Wylee's Solene Sunglasses Have?
The type of lenses that typically come with the Oscar Wylee Solene [glasses frame](https://www.oscarwylee.com.au/glasses.html) are optical lenses. Optical lenses are glasses lenses that have a prescription within the lens to help correct vision issues such as myopia, hyperopia, and astigmatism. Solene can also come with non-prescription lenses, with add-ons such as a blue light filter. Solene frames can be customised into sunglasses in-store or online with add-on tints or polarisation.
### What Material is Used for the Rim of Oscar Wylee's Solene Glasses?
The material used for the rim of Oscar Wylee’s Solene glasses frames is acetate. The rim refers to the part of a glasses frame that holds the lenses.
### What Type of Hinges are Included with Oscar Wylee's Solene Glasses?
The type of hinges included with Oscar Wylee’s Solene frames are normal hinges. These provide strength and smooth movement, connecting the frame's arms and lenses.
## What Face Types are Most Suitable for Oscar Wylee's Solene Glasses?
The face types that are most suitable for Oscar Wylee’s Solene frame are round and oval face types. The Solene frame is a rectangle shape, meaning that it complements the structure of round and oval faces particularly well. The rectangle Solene frames help balance the features of a [round face shape](https://www.oscarwylee.com.au/glasses/face-shapes/round) and an [oval face shape](https://www.oscarwylee.com.au/glasses/face-shapes/oval), bringing the eyes and brows forward in a flattering way. Although there are many [glasses for face shapes](https://www.oscarwylee.com.au/glasses/face-shapes) that may be considered more aesthetically suitable, it is important that people also choose frames that make them feel most comfortable and represent their personal style.
## What Size Options are Available for Oscar Wylee's Solene Glasses?
The size option available for Oscar Wylee’s Solene frame is a medium-fit frame.
## What Materials are Used to Create Oscar Wylee's Solene Glasses?
The material used to create the Oscar Wylee Solene frame is acetate. Acetate, also known as cellulose acetate, is a bioplastic made from cotton fibres or wood pulp. At Oscar Wylee, acetate glasses are made by adding a dye to cellulose acetate, which is rolled into a sheet. The shape of the glasses is then cut from this sheet.
## What’s Included
## OW Case &amp; Cloth
Protective Case and Lens Cloth
Our high-quality glasses case and lens cloth are included with every purchase of an Oscar Wylee frame. The stylish, magnetic case is made from a hard shell. This sturdy and durable material keeps your glasses protected and safe, wherever you go. Ensure your lenses are clean and scratch-free with our OW microfibre cloth, specifically designed to ensure you have comfortable vision through your lenses.
Oscar Wylee offers:
* Free Shipping on all orders
* 1 Year Warranty on frames and lenses
* Scratch resistance lens coating on all prescriptions
* UV-proof coating on all prescriptions
Health fund rebate: Once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. Learn more about [health funds](https://www.oscarwylee.com.au/health-funds.html).
## Make and Materials
Our frames go through numerous stages of production and are hand-polished to ensure a glorious lustre. Featuring a mix of high-quality acetate and polished metal, these mixed materials frames are sure to enhance your eyewear collection.The frames then go through cleaning and strict quality control, and many pairs of crafting hands to be hand-assembled and polished. The frames then go through cleaning and strict quality control, and many pairs of crafting hands to be hand-assembled and polished. After your frames have gone through the production process, they are individually examined and&nbsp;packed before making their way to you!
## Warranty Information
### Warranty Information
### Warranty Information
Oscar Wylee provides a 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects. We will repair or replace faulty or defective frames or lenses free of charge for warranty claims made within 1 year of the delivery. We also offer repairs or replacement for problems experienced with vision during everyday use for claims made within 30 days of delivery. If the same product has been discontinued or is no longer available, then we may offer an exchange for a similar product or a refund.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Find a Store Location](https://www.oscarwylee.com.au/locations/full-store-list.html)