# Source: https://www.oscarwylee.com.au/locations/optometrist-elizabeth.html

# Optometrist Elizabeth
Elizabeth City CentreShop S090, 50 Elizabeth WayElizabeth SA 5112
* Near Woolworths
Opening hours
Monday9:00am - 5:30pm
Tuesday9:00am - 5:30pm
Wednesday9:00am - 5:30pm
Thursday9:00am - 9:00pm
Friday9:00am - 5:30pm
Saturday9:00am - 5:00pm
Sunday11:00am - 5:00pm
*Store hours reflect local standard trading hours and exclude public holidays
[Visit our Elizabeth City Centre Google Business page for directions, reviews, and updates.](https://g.page/r/CWmSuEjSUMV9EBM)
Book Appointment
[Call us: (08) 7373 3549](tel:(08) 7373 3549)
[Leave a Review!](https://g.page/r/CWmSuEjSUMV9EBM/review)
Our Reviews
Lisa Perkins
2 days ago
Fabulous experience for my son.
Great service and great choices
Ngoc Vo
2 days ago
Service was personalised, unrushed and
second to none - staff were tremendously helpful
Peta Richards
4 days ago
Consistently the lovliest staff, super efficient time wise as well.
Andrew Henderson
1 week ago
Very friendly and welcoming staff.
Danny
3 weeks ago
Staff are awesome !!  Killa place to get eyes tested
Tracy Moore
3 weeks ago
The staff and optometrists at Oscar Wylee Elizabeth are so welcoming helpful and make you feel so re...laxed and comfortable especially when it comes to my eyes it is so important to get anything checked. I would highly recommend going there.
See more
Angela Fry
3 weeks ago
Troy Kite
4 weeks ago
Very excellent service from the team at Oscar Wylee,very helpful and polite staff 10/10.????
Michelle Stewart
4 weeks ago
I was very happy with all of the worker’s they were very good and helpful
Jasmine Gower
4 weeks ago
Very accomodating for me and my
Injury and super friendly people!!
jonathan bambila
1 month ago
Went in for eye test, and it was an awesome experience and great customer service, super friendly. D...efinitely coming back and would highly recommend
See more
Brenton Gates
1 month ago
Very good staff, great help but I had to go elsewhere to get the OCT test done as  you dont have tha...t machine.
See more
Aaron vo
1 month ago
I was really blown away with the staff there. They were really nice and very helpful and very profes...sional with making me feel so comfortable. They helped me chose my two frames for my prescription glasses and remained with me till the end even when the store was packed with other customers and did not once rushed me to tend to other customers. I really recommend going there if you want the same experience that i had.
See more
Verity Bird
1 month ago
Sharon Steinhauer
1 month ago
I had a fantastic experience at Oscar Wylee Elizabeth. Every member of the team was so kind, welcomi...ng, and incredibly helpful throughout the entire process. They took the time to answer my questions, offered genuine advice, and made me feel valued as a customer.
The level of customer service was outstanding, and it made the whole experience enjoyable from start to finish. I highly recommend Oscar Wylee Elizabeth to anyone looking for professional, friendly, and attentive service. Thank you to the whole team!
See more
Tanya Edwards
1 month ago
Excellent service! All the staff are so friendly and professional.
Karl Uffelmann
1 month ago
Great.staff very helpful and friendly
Great store layout and fantastic selection of products the eye... test was thorough and proffesional thank you
See more
Louise Agius
1 month ago
They are fantastic. Staff are always friendly and helpful. Vivian is great.
Robert Arnold
1 month ago
Sania Tanzeen
2 months ago
Really good optimistic I had… so patience and did really good check of my eyes. They are not pressur...ised to buy glasses from them. Given my prescription without even asking .
See more
Cherie Hoskin
2 months ago
I went to OSCar AND WYLEEat ELIZABETH STORE and I am very glad I did the young lady greeted me as I ...entered the store her name was MIKAYLA  she was the nicest lady knew her position with expertise she tested my eyes and then I went into the optometrist her name wasVIVIAN  absolutely the most professional optometrist I’ve been to she knew exactly what my eyes needed
do not go to any other store for your eyes but this one you will not be disappointed received my glasses within nearly two weeks and as soon as I put them on I was not disappointed straight away I could see perfectly again
I just wanted to say thank you to these ladies
At OSCAR AND WYLEE for restoring my eyesight
And for their such professional work
See more
ann o'connor
2 months ago
I had shopped around looking at a lot of places to find specs that are stylish and suit me.. Decided... to check out Oscar Wylee specs..I ended up buying two pairs, specs and sunnies ????The customer service was so helpful and not pushy..I also got an eye check within 20mins of being in the store..I am one very happy customer and highly recommend them ????????
See more
Sheridan Sellen
2 months ago
Everyone was so knowledgeable, helpful and friendly, whole process was smooth and pleasant.
Ann-marie Williams
2 months ago
Excellent proffesional service
Shaun Barry
2 months ago
Fantastic service at the Elizabeth Shopping Centre store. The staff in store are absolutely fabulous... to deal with. The only negative is you don’t have a great selection of men’s prescription frames to choose from. The young lady at the front desk told me all frames are considered suitable for both genders which is clearly not the case.
See more
Pam Simounds
2 months ago
Very experienced technician and very friendly. It was a good experience going to the Elizabeth store... to get eyes tested. Would definitely go back again.
See more
Rachel Baum
2 months ago
The optometrist was extremely thorough and informative. He listened to my concerns and explained thi...ngs very easily. The sales woman, Mikayla was so helpful and knowledgeable. She knew what was trending but also listened when I said no to styles. The whole experience was super relaxing and I felt like I wasn’t just a customer they both wanted what was best for me.
See more
Cassie Aleman
2 months ago
Excellent service! The everyone was friendly, professional and very thorough. They took the time to ...explain everything clearly and made the whole experience comfortable and stress-free. Highly recommend
See more
Adam Abraham
2 months ago
My daughter had to attend Urgent Care for an eye matter. We were referred to Oscar Whylee as they ma...y have a possible availability to be seen rather quickly. We were seen within 10 mins of calling, and were treated with the utmost professionalism and sincere respect. I was extremely happy and appreciated the assistance and guidance offered.
Extremely  happy. Thankyou
See more
Ashley Meffert
2 months ago
I have been a regular customer at Oscar Wylee’s Elizabeth location for several years now, wether it ...be for a routine check up for myself or the first time for my children, or replacing frames in an emergency or teaching my son how to use his contacts, I have never have anything less then exceptional service from every single staff member and the optometrists. They’re all incredible personable and I’ve always felt so at ease and comfortable to ask for anything I may have needed help with.  So shout out to the team, you guys are amazing!
See more
Jamie Lee Diggins
2 months ago
The entire team at Oscar Wylee provided exceptional assistance and attentiveness throughout the enti...re process. As a new customer to prescription glasses, I found them to be very informative, which greatly facilitated my decision-making.
See more
M B
3 months ago
Always a great experience here. It takes something special for me to recommend and refer friends and... family and they have it. The care, the support and thoroughness they take is amazing, prices are competative and frames make you look like a new you. Highly recommend I bring my whole family here they wont disappoint. A+++
See more
Rowena Wyatt
3 months ago
Great staff great glasses
Leanne Worthley
3 months ago
Staff really friendly and very helpful
Anthony klement
3 months ago
Fotini Mentis
3 months ago
was a great experience always
Samantha Dinsdale
3 months ago
All staff are amazing. There is no pressure  to buy expensive glasses. All staff very  friendly and ...professional.
Thankyou  Oscar wylee Elizabeth.
See more
Kevin Ansary
3 months ago
professional, communicative, and methodical
Thank you
Roger Gillies
3 months ago
Lisa bergen
3 months ago
Gillian K
3 months ago
such friendly and helpful staff. highly recommend
Zandra Buying
3 months ago
My experience was really quite pleasant.
Excellent service. Very professional. Staff very helpful an...d friendly.
See more
Deb Cindric
3 months ago
The team at Elizabeth are super helpful, friendly and very attentive. Would not go anywhere else.
John Collins
3 months ago
Very helpful people
Robbie Gruden
3 months ago
Debbie Mcgennity
4 months ago
Very friendly and professional makes you feel you’re there only customer
Rachel Hopkins
4 months ago
Staff are really helpful and friendly, the optometrist was excellent and I like the glasses range an...d they are not ridiculous prices.
See more
S B
4 months ago
Absolutely the best service. I normally use specsavers. The customer service and eye doctor is 100% ...more caring and thorough then specsavers. They gained a new customer from me
See more
Leo Mylett
4 months ago
Absolutely stunning. All the staff there were so helpful and went above and beyond to help me with m...y problem. The women with the dark hair on the front desk was especially so nice. Just a huge thank you to you all for being so supportive!!
See more
Karyn Kay
4 months ago
Really thorough eye check and the optomestrist was absolutely delightful.
## Find an Optometrist in Elizabeth With Oscar Wylee
Our Oscar Wylee store is located in Elizabeth City Centre and is close to surrounding areas such as Hillbank, Salisbury and Craigmore. Oscar Wylee Elizabeth is here to help you shop affordable, modern and vintage-style frames for your prescription glasses or sunglasses. Come visit us to get vision testing and comprehensive eye health tests with trained optometrists. For those who live in the area, Oscar Wylee optometrists nearest to you include Oscar Wylee Tea Tree Plaza. 
The Elizabeth City Centre is a growing regional shopping centre with multiple eateries, restaurants and a large open food court. It is a vibrant shopping and entertainment centre that has many things you can explore after your appointment, such as the Reading Cinemas, various boutique stores and large retail brands. There are undercover and non-paid parking, a Taxi zone and pram parking available for the convenience of shoppers. There are also train and bus stations within walking distance. You can also go for a swim at the Aquadome which is right across the street from the city centre.        
Meet Our Team
* Optometrist
BVisSci
MOptom
Therapeutically Endorsed
* Retail Partner
Certificate IV in Optical Dispensing
Our Services
* Bulk Billed Eye Examinations
* Professional Frame Styling
* Frame Adjustments and Repairs
* Visual Fields Testing
* Digital Retinal Scanning
* Children's Eye Checks
* Red Eye Assessments
* Cataract Assessments
* Team Health Care Plans
* Driver's Forms / Fitness to Drive
* Diabetic Assessments
* Macular Degeneration Assessments
Show All
## Find an Optometrist in Elizabeth, Adelaide for an Eye Health Test
Optometrists in Elizabeth, Adelaide in South Australia can provide eye health tests. The Oscar Wylee Elizabeth glasses store offers comprehensive eye tests for a bulk billed price for valid Medicare cardholders. However, the average price range for an optometrist in Elizabeth can vary depending on factors such as the patient’s overall health. Oscar Wylee Elizabeth has a wide range of stylish frames available as optical glasses and prescription sunglasses.
There’s no need to have an eye test with an eye doctor as our Oscar Wylee Elizabeth, Adelaide optometrists are qualified and trained to perform comprehensive eye tests. Eye tests involve assessing a patient's vision and eye health for eye diseases. We also have an optical dispenser that can provide professional frame styling and fitting.
## How to Find an Optometrist in Elizabeth, Adelaide?
To find an optometrist in Elizabeth, Adelaide, you can take certain steps that can help make it easier for you such as searching online, assessing the store’s opening hours and finding the directions to your chosen location. The steps on how to find an optometrist in Elizabeth are listed below.
1. Search online using the phrase, Elizabeth optometrist near me. This can also be done here on the website via our locations page.
2. Click on the Oscar Wylee link, which will take you directly to our Elizabeth optometrist store page.
3. See the store’s opening hours and where the store is located specifically.
4. Use the Elizabeth Google Business page link located under store hours to see the directions on how to get to the store.
You can also find an optometrist in Elizabeth, Adelaide by searching the keywords optometrist near me. If you have locations enabled on your smartphone and you’re in the Elizabeth area, our Oscar Wylee Elizabeth store page should appear easily for you to click on.
### Is it Hard to Get an Eye Appointment in Elizabeth, Adelaide?
No, it is not hard to get an eye appointment in Elizabeth. You can easily book an appointment to see an Oscar Wylee optometrist in Elizabeth right here on this page. At Oscar Wylee we have highly qualified optometrists available for bulk billed eye appointments, which can be booked online, over the phone, or in-store.
#### How to Compare Optometrists in Elizabeth to Each Other?
To compare optometrists in Elizabeth, you can use factors such as eye tests offered, health fund coverage, lens types and add-ons and eyewear offered. To take care of your vision and eye health, it is important to receive an eye test at least once every two years. There are different types of tests that can be performed in an eye test and not all optometrists may offer the same tests. Health funds can be used to help cover some of the cost of your frames and lenses. To find out if your health fund is accepted at an Elizabeth optometrist in Adelaide, visit their website. In the case of Oscar Wylee, we accept all major health funds and provide on-the-spot claims in-store. There are many different lens options available for prescription glasses such as single vision, multifocal and high index lenses. Most optometrists in Elizabeth will offer these lenses although it is good to make sure. There are also lens add-ons available to enhance your glasses such as anti-reflective and blue light filters. Finally, if you are looking to purchase a pair of glasses after your eye test, you can compare the different styles and colours you are interested in from the optometrists in Elizabeth, Adelaide. Oscar Wylee offers a wide range of frames with vintage and modern inspirations in bold colours and subtle designs.
#### How to Find an Eyeglasses Shop in Elizabeth, Adelaide?
To find a glasses store in Elizabeth, you can try to follow these simple steps including searching online, selecting a convenient location and looking at their health insurance policies.  The steps on how to find a glasses store in Elizabeth, Adelaide are listed below.
1. Search online using the phrase, glasses store in Elizabeth. This will provide you with various options for glasses stores in the whole Elizabeth, Adelaide area.
2. Select a glasses store that is most convenient for you to travel to.
3. Click the link to find out more information such as opening hours, exact location and directions to the glasses store in Elizabeth.
4. Read their health insurance policies to ensure you know what health benefits you have access to.
Our Oscar Wylee glasses store in Elizabeth, Adelaide offers primary eye care services such as comprehensive eye tests as well as other services performed by an optometrist and offers prescription and non-prescription eyewear.
##### Is it Possible to Purchase Prescribed Sunglasses in Elizabeth, Adelaide Without Seeing an Optometrist?
Yes and no, it is possible to [purchase prescribed sunglasses](https://www.oscarwylee.com.au/sunglasses.html) in Elizabeth, Adelaide without seeing an optometrist if you already have a prescription that has not expired. If your prescription is expired, you can book an eye test to receive an updated or new prescription which will require you to see an optometrist. This will ensure your prescription sunglasses are appropriate for your visual needs.
## Where is the Oscar Wylee Elizabeth Optometrist Located in Adelaide?
The Oscar Wylee Elizabeth optometrist is located in the Elizabeth City Centre near Woolworths. Elizabeth is a suburb in outer northern Adelaide in South Australia, 24 km north of the Adelaide city centre.
### What is the Phone Number of Oscar Wylee Elizabeth Optometrist Store?
The Oscar Wylee Elizabeth optometrist store phone number is (08) 7373 3549. You can contact the Oscar Wylee Elizabeth store between the hours of 9 am and 5:30 pm from Monday to Wednesday, 9 am and 9 pm on Thursdays, 9 am and 5:30 pm on Fridays, 9 am and 5 pm on Saturdays and 11 am and 5 pm on Sundays.
### What are the Reviews for Oscar Wylee Elizabeth Optometrist in Adelaide?
The many reviews for Oscar Wylee Elizabeth optometrist in Adelaide, left by our various customers can be found here on the website as well as online when you search for Oscar Wylee Elizabeth optometrist. The reviews for Oscar Wylee Elizabeth optometrist are listed below.
* Lisa Smallcombe:  Very good experience. Helpful and very informative.
* Robyn Corner:  The optometrist was lovely and gentle. Explained everything with suggestions. I felt comfortable with her. Also the girl that helped me with picking my glasses was great with her suggestions etc. Thanks.
* Darryl Barreau:  I was very happy with the friendly, efficient service and the thoroughness of the optometrist.
* Kristen Renn:  Excellent all round. Was able to get a walk-in appointment and testing was completed quickly by friendly staff. Accommodating for a pram with no concerns. Selections were easy and staff were very helpful and provided genuine feedback on style.
#### What Treatments or Eye Care Processes are Done in the Oscar Wylee Elizabeth Optometrist Location?
The treatments or eye care processes done in the Oscar Wylee Elizabeth optometrist Adelaide location include a tonometry test, a digital photograph, a slit lamp exam and a refraction test. Additional tests that may also be performed can include a visual field test and a dilated fundus exam. The treatments or eye-care processes that are done in the Oscar Wylee Elizabeth optometrist Adelaide location are listed below.
* A Tonometry Test: An optometrist or optical dispenser will conduct a tonometry test which involves the use of a machine that will release small puffs of air into your eyes. This will assist with measuring pressure in the eye.
* A Digital Photograph: An optometrist or optical dispenser may take a digital photograph of your eye which can be kept on record to use in future appointments to evaluate any changes to your eye.
* Slit Lamp Test: A slit lamp test can be used to evaluate your eye health, by examining your cornea and iris which are the anterior and posterior of the eye.
* Refraction Test: During a refraction test, an optometrist will have you view an image through different lenses and ask you to confirm which helps you see the image clearer.
* Visual Field Test: A visual field test can assist with assessing your peripheral vision, which may be beneficial for identifying any signs of glaucoma.
* Dilated Fundus Exam: A dilated fundus exam can help an optometrist assess your health in more detail by getting a clear view of the retina. This test is typically carried out for patients with diabetes and those who may be at risk of developing retinal damage.
## How Many Optometrists Exist in Elizabeth, Adelaide?
There are many optometrists that exist in Elizabeth, Adelaide to provide eye tests and glasses, including Oscar Wylee. The amount of optometrists available in an area will typically depend on the population. At Oscar Wylee Elizabeth, we offer excellent optometry services including eye tests performed by skilled optometrists using high-quality equipment. We also have a wide range of fashion-forward frames that customers can browse in a large selection of sizes and colours. If you’re looking for an optometrist in Elizabeth, choose Oscar Wylee and we will take care of your optometry and eyewear needs.
### What are the Other Closest Optometrist Locations to Elizabeth, Adelaide in Australia?
The other closest Oscar Wylee optometrist locations to Elizabeth in Australia are Tea Tree Plaza, Marion, Rundle Mall and West Lakes. The locations and their distance from Elizabeth are listed below.
* Tea Tree Plaza:  Tea Tree Plaza is close to Elizabeth, around 16 km. The [Oscar Wylee Tea Tree Plaza](https://www.oscarwylee.com.au/locations/optometrist-tea-tree-plaza.html) store is located in Modbury, South Australia, near Bevilles Jeweller. Visit Oscar Wylee Tea Tree Plaza for visual fielding testing and digital retinal scanning.
* Marion:  Marion is close to Elizabeth, around 19-20 km. The [Oscar Wylee Marion](https://www.oscarwylee.com.au/locations/optometrist-marion.html) store is located in Westfield Marion near Big W. Oscar Wylee Marion provides bulk billed eye tests, visual field testing and frame adjustments and repairs.
* Rundle Mall:  Rundle Mall is close to Elizabeth, around 27 km. The [Oscar Wylee Rundle Mall](https://www.oscarwylee.com.au/locations/optometrist-rundle-mall.html) store is located in Adelaide. Visit Oscar Wylee Rundle Mall for excellent eye care and eyewear services.
* West Lakes:  West Lakes is close to Elizabeth, around 29-30 km. The [Oscar Wylee West Lakes](https://www.oscarwylee.com.au/locations/optometrist-west-lakes.html) store is located in Westfield West Lakes opposite the Universal Store. For fashion-forward frames and comprehensive eye tests, visit Oscar Wylee West Lakes.
### Oscar Wylee Bulk billed Eye Test
We offer optometrist-led bulk billed eye tests in-store at Oscar Wylee Elizabeth City Centre for valid Medicare cardholders. Come in and have your prescription updated and order a new pair of glasses on the same day. Oscar Wylee in Elizabeth can keep you up-to-date on your eyesight and eye health needs by assessing your vision and checking your eye health for certain diseases and conditions.
### Health Funds Accepted in Elizabeth Oscar Wylee
Oscar Wylee in Elizabeth City Centre accepts major health funds including Bupa, HCF and NIB. Our friendly retail staff are onsite to process your claim in-store with a valid health fund card. We know the world of insurance can be confusing, but that’s why we’re here to help you navigate it and ensure you’re getting the best price for all of your prescription glasses needs.
### Fashion-forward and Affordable Glasses
Here at Oscar Wylee Elizabeth, we have fashion-forward eyewear with both local and international inspirations including the coastal Australian landscape. Our experts in-store will help you choose what’s best for you and your prescription needs, and you’ll leave our eyeglasses shop with a pair of prescription glasses or prescription sunglasses you’ll love.
Book Appointment
[Call us: (08) 7373 3549](tel:(08) 7373 3549)
[Leave a Review!](https://g.page/r/CWmSuEjSUMV9EBM/review)