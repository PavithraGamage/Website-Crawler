# Source: https://www.oscarwylee.com.au/locations/optometrist-fountain-gate.html

# Optometrist Fountain Gate
Westfield Level 1, Shop 1138352 Princes HwyNarre Warren VIC 3805
* Near Sportsgirl
Opening hours
Monday9:00am - 5:30pm
Tuesday9:00am - 5:30pm
Wednesday9:00am - 5:30pm
Thursday9:00am - 9:00pm
Friday9:00am - 9:00pm
Saturday9:00am - 5:00pm
Sunday10:00am - 5:00pm
*Store hours reflect local standard trading hours and exclude public holidays
[Visit our Fountain Gate Google Business page for directions, reviews, and updates.](https://g.page/r/CTrzy3AJEICpEBA)
Book Appointment
[Call us: (03) 8751 3773](tel:(03) 8751 3773)
[Leave a Review!](https://g.page/r/CTrzy3AJEICpEAg/review)
Our Reviews
Natalie Greggor
1 week ago
Scott McPherson
2 weeks ago
Excellent experience my script did not change with great advice from the team
SUSHANT CHAKRAVARTY
3 weeks ago
The staff at the Fountain Gate store are extremely helpful and friendly. Yousuf was particularly gre...at and provided us with excellent support throughout the entire process. The optometrist was also very helpful, professional, and thorough. Overall, a great experience with a very supportive and friendly team. Highly recommended!
See more
Kate Sinclair
3 weeks ago
Great staff and easy experience
Frank Baldacchino
1 month ago
The team are great. They explained every  thing in detail. To get you the best possible outcome for ...your eyes.
Job well done.
See more
Tharaka Kolonne
1 month ago
Steve John
1 month ago
Fantastic experience at Oscar Wylee Fountain Gate. Subhan provided exceptional service from start to... finish. He was friendly, patient, and incredibly knowledgeable, taking the time to explain the different lens and frame options so I could make the right decision. He also helped me pick out frames that looked great and suited my needs. The level of care and attention I received was outstanding. I highly recommend Oscar Wylee, especially if you’re assisted by Subhan. He made the whole experience stress-free and enjoyable.
See more
Natalie Stallbaum
1 month ago
The team that assisted me on Tuesday July 21 late morning (apologies, their names have been forgotte...n) were both so completely lovely, patient and kind. My staunch 14 month old even willingly gave out smiles and put on a show. I've been back to this particular store twice now and both times the staff have been efficient, informative and very kind.
See more
Jessica Stephenson
1 month ago
Nancy Sam
1 month ago
I love the frames.????????
robert virag
1 month ago
Great service the optometrist was very experienced.
Dino
1 month ago
I had my eyes tested for the first time here and they were so kind and welcoming. They were professi...onal and explained the process while making sure I was comfortable. Great Team !! ☺️
See more
Charmaine Kenny
1 month ago
I am very happy with the advice given to me by the optometrist at Fountain Gate. I am doing as she i...nstructed and so far so good.
See more
Joanne Folino
1 month ago
Suhaila Flynn
1 month ago
Rosika Senevirathne
2 months ago
Asma Ibrahimi
2 months ago
I’m very happy it was my first time in this store the staff was really friendly and helpful and I wi...ll definitely recommend everyone to go and purchase their glasses from them
See more
major 3
2 months ago
Very good and realisable team but was some technical difficulties but overcome them positively!
Konstandinos Boyacioglu
2 months ago
Super friendly staff. Very professional. If had to describe in one word, that word would be Genuine
Jane Carmody
2 months ago
I was received with a welcoming smile by the attendee at reception at the Fountain Gate store. My pr...essure test was attended to immediately and the optometrist treated me with interest, proficiency and a winning manner. Everything was done with efficiency and care.
See more
Slava Dosun
2 months ago
Esmat Vejdani
2 months ago
very nice and polite staff,  my glasses had a bit  problem and a returned it . They behaved kindly a...nd friendly and examined my eyes again and took the glasses back  to fix it . I appreciate especially Mr yosuf and his friendly behave with his customers
See more
Mandy Burgess
3 months ago
Cherie Babo
3 months ago
jaspreet manchanda
3 months ago
Best care for someone with eye health concerns. MANDY did a great job in testing my eyes by giving m...e plenty of time and i felt very comfortable and relaxed during my eye check up.  Got a best result/prescription in the end.  Highly recommended
See more
Brian D'Elton
3 months ago
Great company to deal with, explained more than opposition,very happy, with our service
Ian Gordon
3 months ago
Great service...informative and quick and easy
carol dp
3 months ago
Mandy did my eye test. Both she and the girls at reception were incredibly helpful.
Annie CREELY
3 months ago
The staff were efficient, helpful and informative
Maddi Stoj
4 months ago
Staff were amazing in helping me pick my new glasses! Whole experience was great - I felt looked aft...er and was comfortable!
See more
Claire Adcock
4 months ago
Zcoops
4 months ago
The ladies were amazing, and answered all of my questions!
Cathy Perry
4 months ago
Amazing!
My first visit to Fountain Gate Oscar Wylee, so happy. I’ve only done Specsavers for howeve...r long they’ve been at FG. My eyes were too dry at OW for a genuine read to be able to provide a prescription, need drops, gotta return after a couple of weeks of eye drop treatment, at least they told me, unlike the others when I also required drops, but they still changed my prescription, hope this makes sense.
The lady optometrist is wonderful, thankyou ????
See more
mick player
4 months ago
Amazing service from the Fountain gate staff
michelle Stewart
4 months ago
Andrew Wade
4 months ago
Murked On-
5 months ago
Wei Choong
5 months ago
Quick, easy and comprehensive
Jay Lee
5 months ago
Optometrist was lovely, friendly and knowledgeable
Andrea Silva
5 months ago
Oscar Cardenas
6 months ago
Oscar Wylee fountain gate are great to deal with, very helpful staff, recommend to all who need glas...ses, great prices too
See more
lindsay arlove
6 months ago
The staff was very friendly and helpful and did not get inpatient when i was trying to find the corr...ect frames
See more
Prof. U.S. Amarasinghe - University of Kelaniya
6 months ago
The overall service is satisfactory. I am still waiting for the report of eye test.
Ryanna Beru
6 months ago
Amazing
Heather King
7 months ago
Happy with the friendly and efficient service received from the staff at Oscar Wylee Fountain Gate. ...Looking forward to receiving my new glasses.
See more
Old Codger
7 months ago
Well done ... relaxed .. explained things well
Jodie Sanza
7 months ago
Extremely friendly team
Emila Amidzic
7 months ago
Shane Lazzarotto
7 months ago
Absolutely 1st class experience with the optometrist - Mandy Tiet.
Mandy was extremely personable an...d professional, taking the time to explain everything in detail to ensure your understanding. Mandy made it a really pleasant experience, and her guidance and advice was top rate. An absolute pleasure to deal with...
See more
Lucy Mackay
7 months ago
Cannot speak highly enough of the fantastic service at the fountain gate store yesterday (Tuesday 13...th Jan) the optometrist was absolutely lovely very thorough and efficient. I was in, our ordered glasses and on my way in half an hour! Great service!
See more
## Find an Optometrist in Fountain Gate With Oscar Wylee
Located in Narre Warren, Oscar Wylee Fountain Gate is close to the Hallam and Harkaway areas. Our Fountain Gate store can be found on level 1 of Westfield Fountain Gate. Our Oscar Wylee optometrist is on-site at Fountain Gate to provide a range of eye care processes, including Medicare bulk billed eye tests to assess vision, and detect possible eye conditions and eye diseases. You can also update your prescription, and find your new favourite pair of glasses on the same day. Oscar Wylee Fountain Gate has some of the best eye care services in Narre Warren, Australia, so come in and see the team! 
To make your appointment at Oscar Wylee Fountain Gate you can take the train to Narre Warren Train Station, which is around a 15-minute walk from the centre, or you can drive in. There is shopping centre parking available and it is also accessible by bus and taxi. Right next door to Fountain Gate Shopping Centre is Bunjil Place, a vibrant arts and entertainment precinct you can check out when your appointment with us is done!        
Meet Our Team
* Optometrist Partner
O.D. BBiomed
Therapeutically Endorsed
* Store Manager
Certificate IV in Optical Dispensing
Our Services
* Bulk Billed Eye Examinations
* Professional Frame Styling
* Frame adjustments and Repairs
* Visual Fields Testing
* Digital Retinal Scanning
* Children's Testing for Kids Over 6
Show All
## Find an Optometrist in Fountain Gate, Melbourne for an Eye Health Test
You can find an Oscar Wylee optometrist in the Fountain Gate Shopping Centre in Melbourne, for your routine eye health test. Fountain Gate shopping centre is located in the suburb of Narre Warren, where our Oscar Wylee optometrists are available in-store to provide eye tests that will include assessing a patient's vision and whether there are any signs of eye disease. Our optometrists can work with an eye doctor, also known as an ophthalmologist in Australia, if advanced eye care is needed. At our Oscar Wylee glasses store in Fountain Gate, Melbourne, our optical dispensers and knowledgeable retail staff are also available to help customers shop for a new pair of stylish frames, including prescription glasses, prescription sunglasses and non-prescription eyewear.
At Oscar Wylee our eye tests are available at a bulk billed price as part of Australia’s Medicare system, with no out-of-pocket expenses for eligible cardholders. The average price range for an optometrist in Fountain Gate, Melbourne can vary depending on factors such as the patient’s health, age, visual needs and the payment system of individual businesses. Come and visit the Oscar Wylee team for an eye health test in Fountain Gate, Melbourne and look after the health of your eyes.
## How to Find an Optometrist in Fountain Gate, Melbourne?
To find an optometrist in Fountain Gate, Melbourne you can take certain steps that can help make it easier for you such as searching online, assessing the store’s opening hours and finding the directions to your chosen location. The steps on how to find an optometrist in Fountain Gate, Melbourne are listed below.
1. Search online using the phrase, optometrist near me in Fountain Gate. This can also be done here on the website via our locations page.
2. Click on the Oscar Wylee link, which will take you directly to our Fountain Gate optometrist store page.
3. See the store’s opening hours and where the store is located specifically.
4. Use the Fountain Gate Google Business page link located under store hours to see the directions on how to get to the store.
You can also find an optometrist in Fountain Gate, Melbourne by searching the keywords optometrist near me. If you have locations enabled on your smartphone and you’re in the Fountain Gate, Melbourne area, our Fountain Gate store page should appear easily for you to click on.
### Is it Hard to Get an Eye Appointment in Fountain Gate, Melbourne?
No, it is not hard to get an eye appointment in Fountain Gate. You can easily book an appointment to see an Oscar Wylee optometrist in Fountain Gate, Melbourne right here on this page. At Oscar Wylee we have highly qualified optometrists available for bulk billed eye appointments, which can be booked online or in-store.
#### How to Compare Optometrists in Fountain Gate, Melbourne to Each Other?
To compare optometrists in Fountain Gate, Melbourne, you can use factors such as eye tests offered, health fund coverage, lens types and add-ons and eyewear offered. To take care of your vision and eye health, it is important to receive an eye test at least once every two years. There are different types of tests that can be performed in an eye test and not all optometrists may offer the same tests. Health funds can be used to help cover some of the cost of your frames and lenses. To find out if your health fund is accepted at an optometrist in Fountain Gate, Melbourne visit their website. In the case of Oscar Wylee, we accept all major health funds and provide on-the-spot claims in-store. There are many different lens options available for prescription glasses such as single vision, multifocal and high index lenses. Most optometrists in Fountain Gate, Melbourne will offer these lenses although it is good to make sure. There are also lens add-ons available to enhance your glasses such as anti-reflective and blue light filters. Finally, if you are looking to purchase a pair of glasses after your eye test, you can compare the different styles and colours you are interested in from the optometrists in Fountain Gate, Melbourne. Oscar Wylee offers a wide range of frames with vintage and modern inspirations in bold colours and subtle designs.
#### How to Find an Eyeglasses Shop in Fountain Gate, Melbourne?
To find a glasses store in Fountain Gate, Melbourne you can try to follow these simple steps including searching online, selecting a convenient location and looking at their health insurance policies. The steps on how to find a glasses store in Fountain Gate, Melbourne are listed below.
1. Search online using the phrase, glasses store in Fountain Gate, Melbourne. This will provide you with various options for glasses stores in the whole Fountain Gate, Melbourne area.
2. Select a glasses store that is most convenient for you to travel to.
3. Click the link to find out more information such as opening hours, exact location and directions to the glasses store in Fountain Gate.
4. Read their health insurance policies to ensure you know what health benefits you have access to.
Our Oscar Wylee glasses store in Fountain Gate, Melbourne offers primary eye care services such as comprehensive eye tests as well as other services performed by an optometrist and offers prescription and non-prescription eyewear.
##### Is it Possible to Purchase Prescribed Sunglasses in Fountain Gate, Melbourne Without Seeing an Optometrist?
Yes and no, it is possible to [purchase prescribed sunglasses](https://www.oscarwylee.com.au/sunglasses.html) in Fountain Gate, Melbourne without seeing an optometrist if you already have a prescription that has not expired. If your prescription is expired, you can book an eye test to receive an updated or new prescription which will require you to see an optometrist. This will ensure your prescription sunglasses are appropriate for your visual needs.
## Where is the Oscar Wylee Fountain Gate, Melbourne Optometrist Located?
The Oscar Wylee Fountain Gate optometrist is located in Fountain Gate’s Westfield Shopping Centre near Big W. Westfield Fountain Gate can be found on the Prince’s Highway in Narre Warren, which is a suburb in Melbourne, Melbourne.
### What is the Phone Number of Oscar Wylee Fountain Gate, Melbourne Optometrist Store?
The phone number for our Oscar Wylee Fountain Gate, Melbourne optometrist store is (03) 8751 3773. Our Oscar Wylee Fountain Gate, Melbourne store is open, and our staff are available to be contacted, between the hours of 9 am and 5:30 pm from Monday to Wednesday, 9 am and 9 pm on Thursdays and Fridays, 9 am and 5 pm on Saturdays and 10 am and 5 pm on Sundays.
### What are the Reviews for Oscar Wylee Fountain Gate, Melbourne Optometrist?
The customer reviews for our Oscar Wylee Fountain Gate, Melbourne optometrist, can be found here on the website as well as online when you search for Oscar Wylee Fountain Gate optometrist. The reviews for Oscar Wylee Fountain Gate optometrist are listed below.
* Emma Hampson:  Such lovely professional service honest from staff with opinions in choosing glasses styles. Optometrist was great, lovely, gentle approach, explaining everything.
* Sharon Jackon:  The team at Oscar Wylee Fountain Gate are amazing. Friendly and professional staff are always there to help you anyway they can.
* Erina Eveleens:  Really sweet and friendly staff, amazing customer service and plenty of cute frames for all types. Would 100% recommend.
#### What Treatments or Eye Care Processes are Done in the Oscar Wylee Fountain Gate, Melbourne Optometrist Location?
The treatments or eye care processes done in the Oscar Wylee Fountain Gate, Melbourne optometrist location include a tonometry test, a digital photograph, a slit lamp exam and a refraction test. Additional tests that may also be performed can include a visual field test and a dilated fundus exam. The treatments or eye-care processes that are done in the Oscar Wylee Fountain Gate optometrist location are listed below.
* A Tonometry Test: An optometrist or optical dispenser will conduct a tonometry test which involves the use of a machine that will release small puffs of air into your eyes. This will assist with measuring pressure in the eye.
* A Digital Photograph: An optometrist or optical dispenser may take a digital photograph of your eye which can be kept on record to use in future appointments to evaluate any changes to your eye.
* Slit Lamp Test: A slit lamp test can be used to evaluate your eye health, by examining your cornea and iris which are the anterior and posterior of the eye.
* Refraction Test: During a refraction test, an optometrist will have you view an image through different lenses and ask you to confirm which helps you see the image clearer.
* Visual Field Test: A visual field test can assist with assessing your peripheral vision, which may be beneficial for identifying any signs of glaucoma.
* Dilated Fundus Exam: A dilated fundus exam can help an optometrist assess your health in more detail by getting a clear view of the retina. This test is typically carried out for patients with diabetes and those who may be at risk of developing retinal damage.
## How Many Optometrists Exist in Fountain Gate, Melbourne?
There are many optometrists that exist in the Narre Warren, Melbourne area, specifically in the Fountain Gate Shopping Centre including Oscar Wylee. The amount of optometrists available in an area will typically depend on the population and the eye care needs of those in the area. At Oscar Wylee Fountain Gate, Melbourne, our team is passionate about providing our customers with high-quality, dedicated eye care services including bulk billed eye tests with our dedicated optometrists, prescription updates and new frames. If you are looking for an optometrist in Narre Warren, or the Fountain Gate Shopping Centre, Melbourne, Oscar Wylee is available to provide for your eye care and eyewear needs.
### What are the Other Closest Optometrist Locations to Fountain Gate, Melbourne in Australia?
The other closest Oscar Wylee optometrist locations to Fountain Gate, Melbourne in Australia are Dandenong Plaza, Doncaster and Chapel Street. The other closest optometrist locations to Fountain Gate, Melbourne are listed below.
* Dandenong Plaza:  Dandenong Plaza is a shopping centre approximately 12 km away from Fountain Gate, where there are several optometrists available, including Oscar Wylee. [Oscar Wylee Dandenong Plaza](https://www.oscarwylee.com.au/locations/optometrist-dandenong.html) is located on level 3 of the Armada Dandenong Plaza Shopping Centre. Here, our dedicated team is available to perform eye tests and help you shop for new stylish frames.
* Doncaster:  Doncaster is a suburb approximately 38 km away from Fountain Gate in which there is a range of optometrists available including our Oscar Wylee optometrists. Our [Oscar Wylee Doncaster](https://www.oscarwylee.com.au/locations/optometrist-doncaster.html) store is located on level 2 of Westfield Doncaster, where our team is available 7 days a week to provide high-quality eye care services.
* Chapel Street: Chapel Street is a location near Fountain Gate, around 40 km away in which a person can find several optometrists including Oscar Wylee. The team at [Oscar Wylee Chapel Street](https://www.oscarwylee.com.au/locations/optometrist-chapel-st.html) are available to provide dedicated eye care services such as eye tests and new frames.
### Medicare Bulk Billing with Oscar Wylee Optometrists
At Oscar Wylee Fountain Gate Westfield, our dedicated and passionate optometrists are equipped with the latest technology to help you on your eye care journey. Come in and have your prescription updated and shop for a new pair of frames on the same day. Our trained optometrists can conduct eye health tests, update your prescription or issue a new one, in a quick and time-efficient manner. For those who live in the Narre Warren areas, Oscar Wylee optometrists near you also include Oscar Wylee Dandenong Plaza.
### Health Funds Accepted In-Store at Fountain Gate
Our Oscar Wylee eyeglasses shop at Fountain Gate Westfield accepts major health funds in-store. Bring a valid health fund card, and our team can help you with a claim, as well as answer any questions you may have about the ins and outs of health insurance at Oscar Wylee. Book online and the team at Oscar Wylee Fountain Gate can keep you up-to-date on your eyesight and eye health needs.
### Fashion Forward Frames at Oscar Wylee Fountain Gate
At our store in Westfield Fountain Gate, Oscar Wylee offers a range of frames, in a variety of sizes, shapes and colours, inspired by both modern and vintage styles. Our range includes prescription glasses, prescription sunglasses, and non-prescription glasses. Our in-store retail team is available in-store to help you choose the frame that is best for you; one that is suitable to both your eye care needs and fits your personal style.
Book Appointment
[Call us: (03) 8751 3773](tel:(03) 8751 3773)
[Leave a Review!](https://g.page/r/CTrzy3AJEICpEAg/review)