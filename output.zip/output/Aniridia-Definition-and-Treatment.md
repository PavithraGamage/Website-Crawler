# Source: https://www.oscarwylee.com.au/glasses/eye/aniridia

# Aniridia: Definition and Treatment
Published on March 23rd, 2026
Aniridia is the name given to a condition wherein part or all of the iris in one eye is not present, making the eye appear to have little to no colour, according to VisAbility Tasmania. This is a genetic disorder that can lead to underdeveloped eyes in children and increase the risk of other eye conditions. Read more about all there is to know about aniridia, including its characteristics, link to genetics and treatment options. It should be noted that this information is general in nature and is not a substitute for professional medical advice. Always consult a qualified optometrist or ophthalmologist.
Schedule your next appointment with our team for great eyecare!
Our optometrists and teams are dedicated to your healthy vision.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Definition](#definition) [Types](#types) [Eye Tests](#eye-tests) [Management](#management)
## What is Aniridia?
Aniridia is a rare condition where an individual does not have a completely formed iris. This gives the appearance of an eye with no colour. This leads to the underdevelopment of the fovea, which is responsible for central vision, according to the School of Special Education Needs WA.
#### Is Aniridia a Congenital Condition Affecting the Iris?
Yes, aniridia is a congenital condition affecting the iris. A congenital condition is a health condition that is present before or at birth, according to Health Direct.
## How Rare is Aniridia?
Aniridia is a very rare condition, affecting approximately 1 in 80,000 people globally, according to The Eye Practice.
## What are the Types of Aniridia?
There are two types of aniridia: congenital (genetic) or acquired, according to K. Tripathy and B. Salini's research paper titled 'Aniridia', published in 2023. Congenital aniridia is a rare disease that affects both eyes, and most of its cases are sporadic in nature. Sporadic aniridia may correspond with WAGR syndrome (Wilm's tumour, aniridia and genitourinary anomalies) (K. Tripathy and B. Salini, 2023). Acquired aniridia can happen after trauma or ocular surgery.
### How do Bilateral and Unilateral Aniridia Differ?
Aniridia is typically bilateral, meaning it is found in both eyes.
#### Can Aniridia Affect Both Eyes Simultaneously?
Yes, aniridia can affect both eyes simultaneously. In fact, aniridia is a bilateral condition, so it always affects both eyes rather than just one eye, according to the Cleveland Clinic.
## How does Aniridia Affect Vision?
Aniridia affects vision in numerous ways. Aniridia increases the risk of various conditions, such as cataracts and glaucoma. These conditions can lead to deterioration of vision, an increase in light sensitivity, decrease in contrast sensitivity, according to the Lions Eye Institute.
### What Visual Problems are Common in People with Aniridia?
The visual problems that are common in people with aniridia are light sensitivity, poor vision and progressive visual deterioration according to Gene Vision. Read more about these visual problems that are common in people with aniridia below.
* Light Sensitivity: Light sensitivity is a common vision problem for those with Aniridia because the iris isn't formed properly. Normally, the iris controls how much light enters the eye, but in this case, it can't do that well.
* Poor Vision: Poor vision can occur as eyesight can be blurry or weak because parts of the eye (like the fovea or optic nerve) didn't fully develop. This affects sharp vision, colour vision, and how well the brain receives visual information.
* Progressive Visual Deterioration: Progressive visual deterioration is a common visual problem for those with Aniridia. Eye conditions such as cataracts, glaucoma and Aniridia-related keratopathy (ARK) can emerge.
#### Does Aniridia Often Cause Reduced Visual Acuity?
Yes, aniridia often causes reduced visual acuity. It can lead to complications that negatively affect visual acuity, such as dry eyes, nystagmus, ptosis and photophobia, according to the Osmosis Organisation.
Experience passionate eye care and a memorable in-store experience!
Visit your local OW store for any of your concerns or browse our wide selection of stylish frames!
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
## How does Aniridia Lead to Nystagmus?
Aniridia leads to Nystagmus as it is said to be the result of incorrect signals between the retina and the brain, according to the International WAGR Syndrome Association. [Nystagmus](https://www.oscarwylee.com.au/glasses/eye/nystagmus) is defined as rapid, involuntary movements that cause flickering eyes. Aniridia can cause nystagmus because the signals between the eye and the brain don't work properly. The severity of nystagmus can vary from person to person, and there is no cure.
### How is Eye Movement Affected by Aniridia?
Eye movement is affected by aniridia, as nystagmus, which is involuntary eye movement, is a common condition that can occur in those with Aniridia.
#### Is Nystagmus Common in Patients with Aniridia?
Nystagmus is considered somewhat common in patients with Aniridia. Nystagmus occurs in around 64-95% of patients with Aniridia, according to a paper done by the Survey of Ophthalmology.
## What is the Relationship Between Aniridia and Glaucoma?
The relationship between aniridia and glaucoma is that glaucoma is often a complication for those who suffer from Aniridia. [Glaucoma](https://www.oscarwylee.com.au/eye-care/eye-conditions/glaucoma) refers to eye diseases wherein vision is lost due to optic nerve damage, according to Glaucoma Australia.
### How does Aniridia Increase the Risk of Developing Glaucoma?
People with aniridia have an increased risk of developing glaucoma due to the part of the eye that drains fluid not forming properly. This makes it harder for fluid to leave the eye, according to the International WAGR Syndrome Association. Reduced drainage can lead to increased intraocular pressure, which can lead to glaucoma (K. Tripathy and B. Salini, 2023).
#### Can Aniridia Lead to Elevated Intraocular Pressure?
Yes, aniridia can lead to elevated intraocular pressure. Intraocular pressure is the term for the pressure of the fluid inside your eyes, according to the Cleveland Clinic. If the pressure is too high and left untreated, it can cause [glaucoma](https://my.clevelandclinic.org/health/diseases/4212-glaucoma) and lead to permanent vision loss.
## How do Eye Doctors Diagnose Aniridia?
An [eye doctor](https://www.oscarwylee.com.au/eye-care/optometry/eye-doctors.html), namely a paediatric ophthalmologist, will often be the one to diagnose Aniridia. A slit lamp test is mainly used as it detects difficulties a child may experience with light sensitivity as well as involuntary eye movements, according to The Eye Practice.
### What Eye Tests are Used to Detect Aniridia?
The eye tests that can be used to detect aniridia are slit-lamp examination, optical coherence tomography (OCT) and high-frequency ultrasound biomicroscopy. Read more about these [eye tests](https://www.oscarwylee.com.au/glasses/eye/test-glossary) to detect aniridia below.
* Slit-Lamp Examination: A special microscope is used to look closely at the eye. It helps check light sensitivity and any unusual eye movements.
* Optical Coherence Tomography: Optical Coherence Tomography is a scan that takes detailed images of the inside of the eye to see if the fovea (important for central vision) is underdeveloped.
* High-Frequency Ultrasound Biomicroscopy: The High-Frequency Ultrasound Biomicroscopy uses sound waves to check for problems like cloudy corneas, corneal oedema, or an underdeveloped iris.
#### Can a Comprehensive Eye Test Identify Aniridia at Birth?
Yes, a comprehensive eye test can identify aniridia at birth. Infants suspected of having Aniridia should have an appointment with an optometrist or [ophthalmologist](https://www.oscarwylee.com.au/eye-health/optometrist-vs-ophthalmologist.html). These infants should be monitored closely in these early years to assess if there are emerging signs of cataracts, glaucoma or other conditions, according to the International WAGR Syndrome Association.
## What are the Complications Associated with Aniridia?
The complications that are associated with aniridia are cataracts, glaucoma and poor vision. Read more about these complications associated with aniridia below.
* Cataracts: Cataracts refer to a cloudy area in the eye lens. A complication of cataracts is that, due to the cloudy eye lens, light passing through will be scattered, and vision will be blurry.
* Glaucoma: Glaucoma is a common complication associated with aniridia. It is a condition caused by an increase in intraocular pressure, which can damage the optic nerve and cause irreversible eye damage.
* Poor Vision: Poor vision often emerges as a result of aniridia, due to complications as a result of diseases such as cataracts and glaucoma.
### How does Aniridia Affect the Cornea?
Aniridia affects the cornea, as the surface of the cornea consists of cells that regularly regenerate from stem cells. Individuals with aniridia often have a deficiency in the regeneration of these cells, according to the Lions Eye Institute. This can make the [cornea](https://www.oscarwylee.com.au/glasses/eye/cornea) irregular and cloudy over time.
#### Can Aniridia Cause Corneal Opacification or Cataracts?
Yes, aniridia can cause [cataracts](https://www.oscarwylee.com.au/glasses/eye/cataracts), and it is considered a common complication of aniridia. However, corneal opacification is a less-reported symptom of aniridia.
## How is Aniridia Treated?
Treatment for aniridia focuses on managing complications and supporting vision. Main treatment approaches for aniridia include specialised glasses, medications for eye pressure, and surgical interventions. There is no cure for aniridia, but medical, surgical, and optical interventions help preserve vision, according to A. Gour's research paper titled 'New horizons in aniridia management: Clinical insights and therapeutic advances' was published in 2023.
### What Medical and Surgical Treatments are Available for Aniridia?
The medical and surgical treatments available for patients with aniridia are vast and include specialised glasses, lubrication, artificial iris implantation, and cataract surgery. An extended list of medical and surgical treatments available for aniridia patients is written below.
Medical treatments
* Specialised glasses: Tinted or photochromic glasses and sunglasses can help reduce light sensitivity in patients with aniridia.
* Lubrication: Preservative-free artificial tears and ointments can help treat dry eye and protect the cornea.
* Autologous serum eye drops: These specialised, preservative-free eye drops may help to treat moderate to severe aniridia-associated keratopathy (AAK) by using growth factors that can encourage corneal healing.
* Glaucoma medication: Antiglaucoma medication applied topically may help reduce intraocular pressure (IOP).
* Low vision aids: Low vision aids include magnifiers, closed-circuit televisions (CCTV), and specialised computer programs that may help maximise patients' remaining vision.
Surgical treatments
* Artificial iris implantation: Artificial iris implantation is a key surgery available for aniridia patients, helping to reduce glare, improve visual acuity, and provide cosmetic improvements.
* Cataract surgery: Cataract surgery may be performed as well, but it is high-risk in the context of aniridia.
* Aniridia-Associated Keratopathy (AAK) Management: AAK management involves various transplants that aim to restore corneal transparency, improve visual acuity, and stabilise the ocular surface.
* Glaucoma Surgery: Glaucoma surgery may be required if medications alone are insufficient to reduce the intraocular pressure.
#### Can Treatment Improve Vision in Aniridia Patients?
Yes, treatment may improve or stabilise vision in some aniridia patients. Early intervention can help prevent or reduce further visual deterioration, although currently there is no cure for aniridia. It should be noted that treatment outcomes vary depending on severity and individual response.
## How can Eye Protection Help People with Aniridia?
Eye protection can help people with aniridia by reducing light sensitivity and glare, providing essential UV protection, improving visual acuity, protecting against injury, and reducing the amount of light entering the eye. [Eye protection](https://www.oscarwylee.com.au/glasses/eye/uv-protection) is vital for aniridia patients as it reduces light sensitivity and prevents additional eye damage. Patients with aniridia struggle to control light intake due to the partial or complete absence of their iris, and this can lead to severe light sensitivity, glare, and risk of further complications. Eye protection helps to improve visual comfort, safety, and functionality for patients.
### Why are Sunglasses Recommended for Individuals with Light Sensitivity?
Sunglasses are recommended for individuals with light sensitivity due to aniridia to block harmful UV rays, filter bright light and reduce glare, and minimise eye strain and discomfort. This helps individuals with aniridia function comfortably outdoors, according to the International WAGR Syndrome Association. Tinted and polarised [sunglasses](https://www.oscarwylee.com.au/glasses/eye/sunglasses) are recommended for aniridia patients as they can also prevent further issues from developing.
#### Can Sunglasses Reduce Photophobia in Aniridia Patients?
Yes, sunglasses may reduce photophobia in aniridia patients. Photophobia refers to a sensitivity or intolerance to light, according to the Vision Eye Institute Australia. It is a common symptom of aniridia patients because they do not have an iris and, as a result, cannot easily adjust to different light levels, such as harsh lighting, according to the Aniridia Network. Sunglasses can be helpful to aniridia patients as they block the harsh light and glare that comes from sun exposure.
#### Can Contact Lenses Improve Visual Comfort in Aniridia?
Yes, contact lenses may improve visual comfort in aniridia. [Contact lenses](https://www.oscarwylee.com.au/glasses/eye/contact-lenses) reduce glare, protect the cornea, optimise vision, and improve cosmetic appearance.
## How are Glasses Adjusted for Vision Deficits in Aniridia?
Glasses are not necessarily adjusted specifically for those with vision deficits related to aniridia. The prescription glasses will be tailored to individual refractive errors.
### How can Prescription Glasses Help People with Aniridia?
Prescription glasses can help people with aniridia by correcting refractive errors such as myopia, hyperopia, and astigmatism according to the International WAGR Syndrome Association. However it is important to note that [prescription glasses](https://www.oscarwylee.com.au/glasses.html) cannot correct or cure eye issues associated with Aniridia that cause unclear vision.
## How is Aniridia Different from Other Iris Disorders?
Aniridia refers to a disorder wherein an individual has a partial or completely non-existent iris. This differentiates it from iris disorders such as pigment-dispersion syndrome, where the iris bows backwards and rubs against zonules which makes the pigmentation dislodge, according to Glaucoma Australia. This is not a congenital condition, unlike Aniridia.
#### Is Aniridia Distinct from Iris Hypoplasia or Coloboma?
Yes, Aniridia, iris hypoplasia, and iris coloboma are distinct in that they are all conditions that affect the coloured part of the eye (the iris), but they differ in severity and appearance. Aniridia is the most serious, where the iris is mostly missing, and vision problems are common. Iris hypoplasia is milder, with the iris present but underdeveloped, so symptoms are usually less severe. Iris coloboma is a structural gap or hole in the iris, often giving the pupil a keyhole shape, and it may have little to mild effect on vision depending on its size.
## How is Aniridia Managed in Children?
How aniridia is managed in children will depend on a case-by-case basis. Overall, it is important that a child has regular eye tests to monitor the condition and ensure any vision changes are detected early.
### What Special Considerations are Needed for Pediatric Patients?
The special considerations needed for pediatric patients with Aniridia include will differ based on the severity of their condition. They will generally need to get regular eye tests, and will likely need prescription glasses if they have refractive errors.
#### Should Children with Aniridia Have Regular Eye Checkups?
Yes, children with aniridia should have regular eye checkups to ensure eye problems that may emerge are detected early.
Experience Quality Eye Care!
We have knowledgeable optometrists at Oscar Wylee, who are available in-store to perform high-quality eye tests.
[Book an eye test](https://www.oscarwylee.com.au/booking)
Oscar Wylee Accepts Major Health Funds In-store
Visit Oscar Wylee in-store for eye care and eye wear services, and your health fund may help cover some of the cost.
[Explore health funds](https://www.oscarwylee.com.au/health-funds.html)