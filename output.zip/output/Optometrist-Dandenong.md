# Source: https://www.oscarwylee.com.au/locations/optometrist-dandenong.html

# Optometrist Dandenong
Armada Dandenong Square
T331, Corner McCrae and Walker St
Dandenong VIC 3175

Level 3 opposite Priceline Pharmacy

Our Oscar Wylee Dandenong store has closed, but this isn’t the end
of your eye care journey!
Visit another Oscar Wylee store to experience our high-quality eye
care services, such as eye tests and new frames, as we still have your
eye care details.
See your nearby stores below!
[Fountain Gate Westfield](https://www.oscarwylee.com.au/locations/optometrist-fountain-gate.html)[The Glen](https://www.oscarwylee.com.au/locations/optometrist-glen-waverley.html)[Knox Westfield](https://www.oscarwylee.com.au/locations/optometrist-knox.html)[Southland Westfield](https://www.oscarwylee.com.au/locations/optometrist-southland.html)
Opening hours 
Monday9:00am - 5:30pm
Tuesday9:00am - 5:30pm
Wednesday9:00am - 5:30pm
Thursday9:00am - 7:00pm
Friday9:00am - 7:00pm
Saturday9:00am - 5:00pm
Sunday10:00am - 4:00pm
*Store hours reflect local standard trading hours and exclude
public holidays

Visit our Dandenong Google Business page for directions,
reviews, and updates.

Book Appointment
[Call us: 1300 164 990](tel:1300 164 990)
Our Reviews
Naman Garg
2 years ago
Liz Burman
2 years ago
service was great, staff were friendly, eye test was a breeze
Fatima Ali
2 years ago
Scotty Clark
2 years ago
Nice efficient staff! A pleasant experience!
Najma I
2 years ago
Came in for my yearly checkup and the team was lovely in making sure I got the frames that suited me... best. Thank you Dylan and team for making the experience seamless! :)
See more
Imran Afzal
2 years ago
Dylan was amazing! He really helped me get the look I wanted without sacrificing my eye sight!
Could...n’t recommend this store more and the lovely staff!
Keep it up!
See more
Kerem Doruk
2 years ago
I visited the store for my grandmas frame selection. Store manager Dylan was amazing and he supporte...d us with expert advice throughout the process. Recommend everyone in the south east to visit Oscar Wylee Dandenong.
See more
Wais Osmani
2 years ago
I came in with my mother to have her yearly check and renew her glasses as it was getting worn.
Spo...ke to Dylan and he was amazing, provided us with amazing information and was great to deal with throughout the whole process .
See more
pinilisa7
2 years ago
Lovejit
2 years ago
It was my first time at oscar wylee and it was good and amazing staff. But only one thing oscar wyle...e is soo expensive as compare to other opticals.
See more
zohra
2 years ago
Excellent
TruthSayer
2 years ago
Very nice and organised shop. Optom was very knowledgeable and the assistant in store marwa was very... kind and attentive. Would come again
See more
Del agha
2 years ago
Duy Phuc Nguyen
2 years ago
Marwa is an amazing person
Danial Browning
2 years ago
bernadine arnold
2 years ago
Very good &amp; so helpful to my needs, when it comes to my eyes.
Hamidreza Topalkhan
2 years ago
Nor Aidaa
2 years ago
Good service..
Myrosss
2 years ago
Lara Blinoff
2 years ago
Just saw a similar review about one of the girls working at this store, her name was jovana I believ...e. This store was clean and well kept, the young lady assisted me in helping my mother choose a new frame. She was honestly so helpful I wish I needed glasses to be able to be treated with such elegant service!! 10/10 would recommend. What a great hiring team!
See more
Ismeta Duratovic
2 years ago
Came in looking for a pair of glasses and the wonderful young lady helping me, Jovana, was so patien...t and helpful. She informed me about the eyewear and all the benefits that come with each pair. I will definitely be coming back to purchase a pair of glasses because of her amazing service! We need more people like this young lady, seriously blown away by the knowledge she possessed about the products, will be recommending to my friends and family!
See more
Anastasia Wangui
2 years ago
Kat Ganic
2 years ago
Very helpful. Quick and easy process
P R
2 years ago
I have an eye irritation turned into allergy the optometrist prescribed medication and it has helped... me a great deal
See more
mia tomciu
2 years ago
Very professional, friendly staff and transparent.
Bambi Felarca
2 years ago
Krishna Ganeshan
2 years ago
Best service by darina and marwa. Give them two a pay raise and much love, care and attention.
doully seven
2 years ago
sofia khan
2 years ago
The girl named Marwa assisted me and was extremely helpful, sweet and approachable she explained evr...ything to me in perfect detail as i am a 60yr old woman who doesn’t know a lot about glasses it’s hard to find true customer service in this new generation
See more
Gayle Linklater
2 years ago
I was very impressed with the eye test.  The lady that did it was very thorough and explained everyt...hing. I then found the great service just continued  above and beyond to make sure I was happy with my purchase of glasses. I ordered 3 pair of glasses and hope that the after care is as good as the initial service.  If that is the case then they will deserve 100%.
See more
Michelle Maritim
2 years ago
Manjesh Kumari
2 years ago
I was curious for my eyes check up which I never done before. It been great experience at Oscar Wyle...e. I got great results. I love that.
See more
Fathima Nathika Ahamed
2 years ago
Good service
Valerie Mootoosamy
2 years ago
3 stars for good variety of trendy frames and friendly staff.
First time customer at Oscar Wylee, my... first appt felt rushed. Was told if I didn't like the strength to come back and they'd change it.
I went back to only be told to come back a week later for when the manager is around. Travelled 30 mins just for them to say that, 1 hr trip wasted.
Get a phone call from a staff member to confirm my appt which I confirmed. Get a text to confirm my appt as well, tried to confirm however link wasn't working. Called up to confirm again, young lady said it was all confirmed.
On the day, I call up to let them know Im running 10 mins late and they tell me I'm not even booked in ????‍???? but to come anyway.
Eventually get seen by optometrist who is able to offer slightly better strength lenses.
Now I have to wait another 2 weeks for my new pairs without an alternative to wear in between.
My only suggestion is Oscar Wylee Dandenong definitely need to improve your processes and customer service. Be transparent on what the customer should expect at the time, don't assume the customer just knows it all. Customers don't like to be messed around.
See more
Acalia R
2 years ago
Fantastic optometrist and great customer service. No hidden costs that they don't tell you about, un...like other stores. I wouldn't go anywhere else, particularly at Dandenong Plaza.
See more
Eric Bergado Hilado (Papabear)
2 years ago
Very friendly Optometrist
I'm very happy with the result of my eye test. Thank You
mick chen
2 years ago
Loveheli
2 years ago
I went to the shop the week before Wednesday,there was a girl, nice and patient, Marwah. Help me to ...fix the nose pad of my glasses. She fixed it very well, very professional. Loveley team Lovley store i want get to check my eyes here soon really. See you Soon!
See more
AW
2 years ago
Five stars for the optometrist, very friendly and honest.  I was disappointed in the choice of frame...s for sunglasses and ended up not purchasing as this was the reason I came in for.
Sorry to say but I did not get a friendly feel helpful from the young girl the first tests before seeing the optometrist.
See more
Snezana Gavrilovic
2 years ago
Wafiyah
3 years ago
last month was my second time at oscar wylee and it was a great experience. Marwa was very approacha...ble, and explained everything with care and patience, ensuring i felt comfortable with my choices and add on options. her eyewear selection is top-notch and expertise was impressive. I left with stylish, high quality glasses (which has gotten several compliments thanks to the style tips), and a sense that my needs truly mattered.
See more
Cameron Bedelph
3 years ago
Very good but I will give the staff member a ???? star's
Farjana Akter
3 years ago
I went to eye test and buy glasses. The receptionist was very helpful. But optometrist was not co-op...erative like she was unprofessional. I had concern about my vision and ask few question. i think she was not happy with that
See more
archie smb
3 years ago
Very accommodating and good customer service. Specialty the receptionist that day. Thank you????
A Google User
3 years ago
I have been going to Oscar Wylee for the last 3 years and have never had a bad experience   They hav...e answered all my questions and even helped me save money on my purchase.  I highly recommend anyone to give them a try. You won’t be disappointed
See more
Rebecca Narayan
3 years ago
Best and most comfortable eye test I have had so far. Staff were quick and very friendly. Choosing m...y glass was a breeze as I  was left free to choose and not forced into getting designs that I  didn't like or were expensive. I would definitely recommend people to go and visit them.
See more
مهناز امینی
3 years ago
I had eye test here they were very nice and helpful and I got two perfect sunglasses with good price
Gaithree Sundhar
3 years ago
Lillian Balalovski
3 years ago
Wonderfully Professional Dandenong staff - exceptionally efficient and friendly with fantastic custo...mer service.
See more
Paese Tiatia
3 years ago
## Find an Optometrist in Dandenong With Oscar Wylee
In the heart of Dandenong’s shopping district, you can find our
Oscar Wylee Dandenong store on level 3 of the Dandenong Square Shopping
Centre, across from Priceline. Here, our dedicated Oscar Wylee Dandenong
optometrists can provide you with Medicare bulk billed eye health tests.
Dandenong Square is easily accessible by several bus lines and is close to the
Dandenong Train Station. You could also utilise the Plaza’s multi-level car
park, free for up to 5 hours. 
Dandenong Square provides
shoppers with a relaxing indoor shopping experience, with over 100 stores to
explore. If you are after something different, there are also markets and
on-street shops in the surrounding areas. If you're stopping by Oscar Wylee
Dandenong to shop our stylish frames, be sure to explore the local arcade and
theatres. If you are close to the Doveton or Noble Park areas, our Oscar Wylee
store is your go-to for some of the best optometry services in Dandenong.        
Our Services
* Bulk Billed Eye Examinations
* Professional Frame Styling
* Frame Adjustments and Repairs
Show All
## Find an Optometrist in Dandenong, Melbourne for an Eye Health Test
Optometrists in Dandenong, Melbourne Victoria can provide eye
health tests. The Oscar Wylee Dandenong store offers
comprehensive eye tests for a bulk billed price for valid
Medicare cardholders. However, the average price range for an
optometrist in Dandenong can vary depending on factors such as
the patient’s overall health and age. There’s no need to have an
eye test with an eye doctor as our Oscar Wylee Dandenong,
Melbourne optometrists are qualified and trained to perform
comprehensive eye tests.
Eye tests involve assessing a patient's vision and eye health
for eye diseases. We also have an optical dispenser that can
provide professional frame styling and fitting. Oscar Wylee
Dandenong has a wide range of stylish frames available as
optical glasses, prescription sunglasses and non-prescription
eyewear.
## How to Find an Optometrist in Dandenong, Melbourne?
To find an optometrist in Dandenong, Melbourne, you can take
certain steps that can help make it easier for you such as
searching online, assessing the store’s opening hours and
finding the directions to your chosen location.
The steps on how to find an optometrist in Dandenong are listed
below.
1. Search online using the phrase, Dandenong optometrist near me.
This can also be done here on the website via our locations
page.
2. Click on the Oscar Wylee link, which will take you directly to
our Dandenong optometrist store page.
3. See the store’s opening hours and where the store is located
specifically.
4. Use the Dandenong Google Business page link located under
store hours to see the directions on how to get to the store.
You can also find an optometrist in Dandenong, Melbourne by
searching the keywords optometrist near me. If you have
locations enabled on your smartphone and you’re in the Dandenong
area, our Oscar Wylee Dandenong store page should appear easily
for you to click on.
### Is it Hard to Get an Eye Appointment in Dandenong, Melbourne?
No, it is not hard to get an eye appointment in Dandenong. You
can easily book an appointment to see an Oscar Wylee optometrist
in Dandenong right here on this page. At Oscar Wylee we have
highly qualified optometrists available for bulk billed eye
appointments, which can be booked online, over the phone, or
in-store.
#### How to Compare Optometrists in Dandenong to Each Other?
To compare optometrists in Dandenong, you can use factors such
as eye
tests offered, health fund coverage, lens types and add-ons
and eyewear offered.
To take care of your vision and eye health, it is important to
receive an eye test at least once every two years. There are
different types of tests that can be performed in an eye test
and not all optometrists may offer the same tests. Health funds
can be used to help cover some of the cost of your frames and
lenses. To find out if your health fund is accepted at a
Dandenong optometrist in Melbourne, visit their website. In the
case of Oscar Wylee, we accept all major health funds and
provide on-the-spot claims in-store. There are many different
lens options available for prescription glasses such as single
vision, multifocal and high index lenses. Most optometrists in
Dandenong will offer these lenses although it is good to make
sure. There are also lens add-ons available to enhance your
glasses such as anti-reflective and blue light filters. Finally,
if you are looking to purchase a pair of glasses after your eye
test, you can compare the different styles and colours you are
interested in from the optometrists in Dandenong, Melbourne.
Oscar Wylee offers a wide range of frames with vintage and
modern inspirations in bold colours and subtle designs.
#### How to Find an Eyeglasses Shop in Dandenong, Melbourne?
To find a glasses store in Dandenong, you can try to follow
these simple steps including
searching online, selecting a convenient location and looking
at their health insurance policies.
The steps on how to find a glasses store in Dandenong, Melbourne
are listed below.
1. Search online using the phrase, glasses store in Dandenong.
This will provide you with various options for glasses stores
in the whole Dandenong, Melbourne area.
2. Select a glasses store that is most convenient for you to
travel to.
3. Click the link to find out more information such as opening
hours, exact location and directions to the glasses store in
Dandenong.
4. Read their health insurance policies to ensure you know what
health benefits you can access.
Our Oscar Wylee glasses store in Dandenong, Melbourne offers
primary eye care services such as comprehensive eye tests as
well as other services performed by an optometrist and offers
prescription and non-prescription eyewear.
##### Is it Possible to Purchase Prescribed Sunglasses in Dandenong,
Melbourne, Without Seeing an Optometrist?
Yes and no, it is possible to
[purchase prescribed sunglasses](https://www.oscarwylee.com.au/sunglasses.html)
in Dandenong, Melbourne without seeing an optometrist if you
already have a prescription that has not expired. If your
prescription is expired, you can book an eye test to receive an
updated or new prescription which will require you to see an
optometrist. This will ensure your prescription sunglasses are
appropriate for your visual needs.
## Where is the Oscar Wylee Dandenong Optometrist Located in
Melbourne?
The Oscar Wylee Dandenong optometrist is located on level 3 of
the Dandenong Square Shopping Centre, opposite Priceline
Pharmacy. Dandenong is approximately 35 km from Melbourne CBD.
### What is the Phone Number of Oscar Wylee Dandenong Optometrist
Store?
The Oscar Wylee Dandenong optometrist store phone number is (03)
8712 5088. You can contact the Oscar Wylee Dandenong store
between the hours of 9 am and 5:30 pm from Monday to Wednesday,
9 am and 9 pm on Thursdays and Fridays, 9 am and 5 pm on
Saturdays and 10 am and 5 pm on Sundays.
### What are the Reviews for Oscar Wylee Dandenong Optometrist in
Melbourne?
The many reviews for Oscar Wylee Dandenong optometrist in
Melbourne, left by our various customers can be found here on
the website and online when you search for Oscar Wylee Dandenong
optometrist. The reviews for Oscar Wylee Dandenong optometrist
are listed below.
* Acalia Ryan:  Fantastic optometrist and great customer
service. No hidden costs that they don’t tell you about,
unlike other stores. I wouldn’t go anywhere else, particularly
at Dandenong Square.
* Eric Bergado Hilado:  Very friendly optometrist. I’m
very happy with the result of my eye test. Thank you.
* Archie Smb:  Very accommodating and good customer
service. Especially the receptionist that day. Thank you.
* Rebecca Narayan:  Best and most comfortable eye test I
have had so far. Staff were quick and very friendly. Choosing
my glasses was a breeze as I was left free to choose and not
forced into getting designs that I didn’t like or were
expensive. I would definitely recommend people to go and visit
them.
#### What Treatments or Eye Care Processes are Done in the Oscar Wylee
Dandenong Optometrist Location?
The treatments or eye care processes done in the Oscar Wylee
Dandenong optometrist Melbourne location include
a tonometry test, a slit lamp exam and a refraction test.
Additional tests that may also be performed can include
a dilated fundus exam. The treatments or eye-care
processes that are done in the Oscar Wylee Dandenong optometrist
Melbourne location are listed below.
* A Tonometry Test: An optometrist or optical dispenser
will conduct a tonometry test which involves the use of a
machine that will release small puffs of air into your eyes.
This will assist with measuring pressure in the eye.
A Digital Photograph: An optometrist or optical dispenser
may take a digital photograph of your eye which can be kept on
record to use in future appointments to evaluate any changes to
your eye.

* Slit Lamp Test: A slit lamp test can be used to
evaluate your eye health, by examining your cornea and iris
which are the anterior and posterior of the eye.
* Refraction Test: During a refraction test, an
optometrist will have you view an image through different
lenses and ask you to confirm which helps you see the image
clearer.
Visual Field Test: A visual field test can assist with
assessing your peripheral vision, which may be beneficial for
identifying any signs of glaucoma.

* Dilated Fundus Exam: A dilated fundus exam can help an
optometrist assess your health in more detail by getting a
clear view of the retina. This test is typically carried out
for patients with diabetes and those who may be at risk of
developing retinal damage.
## How Many Optometrists Exist in Dandenong, Melbourne?
There are many optometrists that exist in Dandenong, Melbourne
to provide eye tests and glasses, including Oscar Wylee. The
number of optometrists available in an area will typically
depend on the population. At Oscar Wylee Dandenong, we offer
excellent optometry services including eye tests performed by
skilled optometrists using high-quality equipment. We also have
a wide range of fashion-forward frames that customers can browse
in a large selection of sizes and colours. If you’re looking for
an optometrist in Dandenong, choose Oscar Wylee and we will take
care of your optometry and eyewear needs.
### What are the Other Closest Optometrist Locations to Dandenong,
Melbourne in Australia?
The other closest Oscar Wylee optometrist locations to Dandenong
in Australia are
Fountain Gate, Southland and Cranbourne. The locations
and their distance from Dandenong are listed below.
* Fountain Gate:  Fountain Gate is close to Dandenong,
around 9 km. The
[Oscar Wylee Fountain Gate](https://www.oscarwylee.com.au/locations/optometrist-fountain-gate.html)
store is located in Westfield Fountain Gate in Narre Warren,
near Sportsgirl. You can visit Oscar Wylee Fountain Gate for
excellent eye care and eyewear services.
* Southland:  Southland is close to Dandenong, around 16
km. The
[Oscar Wylee Southland](https://www.oscarwylee.com.au/locations/optometrist-southland.html)
store is located in Westfield Southland in Cheltenham, near
David Jones. Here you will find bulk billed eye tests and a
wide range of fashionable eyewear to browse.
* Cranbourne:  Cranbourne is close to Dandenong, around
15-16 km. The
[Oscar Wylee Cranbourne](https://www.oscarwylee.com.au/locations/optometrist-cranbourne-park.html)
store is located in the Cranbourne Park Shopping Centre, next
to Forever New. Here you can have your eyes tested for a bulk
billed price and also shop for a new pair of glasses.
### Medicare Bulk Billed Eye Tests at Oscar Wylee
Book an eye test at Oscar Wylee Dandenong online, in-store or over the
phone where we offer bulk billing for eligible Medicare cardholders.
Our trusted optometrists offer eye care processes such as checking
your eye health for certain eye diseases, assessing your vision and
providing an updated prescription if needed. With a new prescription,
you can browse for a new pair of glasses and order them on the same
day.
### Health Funds Accepted in Dandenong
Oscar Wylee in Dandenong accepts major health funds including NIB, HCF
and Bupa. Our in-store experts can process your claim with a valid
health fund card, as well as provide an on-the-spot quote for frames
and lenses. Visit Oscar Wylee Dandenong where our staff can help you
navigate the ins and outs of your insurance.
### Fashion-Forward Frames at Oscar Wylee
The Oscar Wylee eyeglasses shop in Dandenong Square offers a wide
range of stylish frames at affordable prices. Choose from both bold
and subtle colours in contemporary and classic shapes. Plus, you can
customise your lenses with a number of add-ons and lens options
including anti-reflective coatings and polarisation for sunglasses for
an additional price. Our experts in-store will help you choose what’s
best for you, and you’ll leave our store with your perfect pair of
prescription glasses or prescription sunglasses.
Book Appointment
[Call us: 1300 164 990](tel:1300 164 990)