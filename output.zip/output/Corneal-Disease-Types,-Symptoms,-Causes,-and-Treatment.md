# Source: https://www.oscarwylee.com.au/glasses/eye/corneal-diseases

# Corneal Disease: Types, Symptoms, Causes, and Treatment
Published on October 23rd, 2023
Updated on Month Date, 2025  
Australia   
[Australia](https://www.oscarwylee.com.au/glasses/eye/corneal-diseases)
New Zealand
 
[Canada](https://oscarwylee.ca/glasses/eye/corneal-diseases)
[Canadian French](https://oscarwylee.ca/fr/glasses/eye/corneal-diseases)
Corneal diseases are different types of conditions that affect the cornea, which is the clear outer layer located at the front of the eye. Symptoms of corneal disease may include blurry vision, eye pain, red or watery eyes and light sensitivity. Common causes of corneal disease may include trauma or injury to the eye, an eye infection, genetic mutations and other conditions. Corneal diseases can be diagnosed through a comprehensive eye exam which can be carried out by an optometrist. Treating corneal diseases can involve eye drops, laser treatment and surgery. However, this can depend on the type and severity of the corneal disease. This article will cover more about the different types of cornea eye problems, common symptoms, causes and typical treatment processes.
Do You Have Any Eye Concerns?
Book an appointment to see our friendly optometrists who can assist in diagnosing eye and vision issues.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Definition](#definition) [Types](#types) [Symptoms](#symptoms) [Causes](#causes)
## What is Corneal Disease?
Corneal disease is a categorisation of conditions that affect the cornea, the clear outer layer at the front of the eye. The different types of cornea diseases can include inflammation, abrasions (scratches), diseases as a result of genetic mutation, dryness and allergies. According to the Centre For Sight, the eye’s cornea is a very sensitive tissue and significantly more receptive to pain than the skin. Therefore, small injuries involving the eye can cause a substantial amount of pain.
### What is the Other Term For Corneal Disease?
There are no other terms for corneal disease as it is a term that refers to the different types of diseases that affect the cornea. Inflammation of the eye, corneal abrasions and corneal dystrophies are a few of the different forms of corneal disease.
### Does Corneal Disease Affect Both Eyes?
Yes and no, corneal diseases can affect both eyes, however, it can depend on which form of corneal disease you have. Some corneal diseases may affect both eyes, while others may only affect one eye, however, it can also depend on the severity of the condition.
## How Common is Corneal Disease?
Corneal diseases may be common depending on the type, however, several corneal diseases are considered rare. Common corneal diseases may include keratitis and corneal abrasions while corneal dystrophies such as corneal ectasia and iridocorneal endothelial syndrome are considered rare.
### Who Commonly Has Corneal Disease?
People around the age of 20 and up can develop corneal diseases, however, this can depend on the type of disease and potentially a combination of genetic and environmental factors. Corneal diseases can affect a range of age groups with diseases affecting older age groups more than others.
#### Is Corneal Disease a Common Eye Condition?
Yes and no, corneal disease can be a common eye condition depending on which form as certain types are more common than others. The most common forms of corneal disease may be corneal abrasions, inflammation, eye infections and certain corneal dystrophies.
## What are the Types of Corneal Disease?
The types of corneal disease are  keratitis, corneal dystrophy, corneal ectasia, pterygium, corneal abrasion and keratoconjunctivitis. The types of corneal disease are listed below.
* Keratitis: Keratitis is a corneal disease, also known as a corneal ulcer and refers to the inflammation or infection of the cornea.
* Corneal Dystrophy: Corneal dystrophy refers to a group of rare eye diseases that cause changes in the cornea and can worsen over time.
* Corneal Ectasia: Corneal ectasia belongs to a group of rare conditions that result in changes to the shape of the cornea often occurring with an unknown cause.
* Pterygium: Pterygium is a condition that causes a growth of flesh on the surface of the eye and may be caused by irritation from exposure to UV rays, a hot and dry climate, dusty air and genetics.
* Corneal Abrasion: Corneal abrasion is a scratch on the surface of the cornea and can occur from an injury, dust, sand, or dirt getting into the eye or rubbing your eye.
* Keratoconjunctivitis: Keratoconjunctivitis occurs when the conjunctiva and the superficial cornea are both inflamed and can commonly be caused by viral or bacterial infection or allergies.
### 1. Keratitis
Keratitis, also known as corneal inflammation is a type of corneal disease and refers to the inflammation or infection of the cornea. [Keratitis](https://www.oscarwylee.com.au/glasses/eye/keratitis) can either be infectious or non-infectious. Infectious keratitis can be caused by viruses, bacteria, parasites, fungi and improper care of contact lenses. Non-infectious keratitis can stem from an injury to the cornea, dryness, allergies and a foreign body in the eye. This form of corneal disease can bring on symptoms such as redness in the eye, eye pain, watery eyes, sensation of a foreign body in the eye, light sensitivity, blurry vision and reduced vision. It is important to note that other corneal infections such as [herpetic eye disease](https://www.oscarwylee.com.au/glasses/eye/herpes) fall under keratitis. Diagnosis can involve discussing medical history and a complete eye exam according to the Cleveland Clinic. Treatment for mild keratitis can include lubricant eye drops to allow for the eyes to heal on their own. Medication is typically used to treat infectious keratitis and either antibiotic, antifungal or antiviral eye drops may be helpful treatments depending on the cause. A corneal transplant may be required if the condition does not improve after medication and causes scars on the cornea according to the Cleveland Clinic.
### 2. Corneal Dystrophy
Corneal dystrophy refers to a group of rare genetic eye diseases that cause changes in the cornea such as iridocorneal endothelial syndrome (ICE) and bullous keratopathy . Corneal dystrophies can be progressive, some may lead to loss of vision or pain but others may not present any symptoms. An optometrist can diagnose [corneal dystrophy](https://www.oscarwylee.com.au/glasses/eye/corneal-dystrophy) through a comprehensive eye exam using a slit lamp exam according to the National Eye Institute. The different types of dystrophies are categorised by which layers of the cornea are implicated. These layers include the epithelial and subepithelial, bowmans layer, stromal, Descemets membrane, and endothelial layer dystrophies according to the National Library of Medicine. Treating corneal dystrophies will depend on the affected anatomic region as dystrophies of the same level often share similar symptoms.
### 3. Corneal Ectasia
Corneal ectasia is a corneal disease that leads to the thinning or bulging of the cornea which can take place gradually. Corneal ectasia typically affects both eyes, however, it can affect just one eye. This condition may not likely lead to blindness but can reach the extent of severely impaired vision wherein glasses may no longer be helpful according to the Cleveland Clinic. Therefore, it is important you see an optometrist if you experience changes to your vision. The different types of corneal ectasia are keratoconus pellucid marginal degeneration, keratoglobus, post-keratorefractive surgery ectasia and post-penetrating keratoplasty ectasia. Corneal ectasia may exhibit symptoms such as vision gradually getting worse, halos forming around lights, glare and diplopia (double vision). Discussing your personal medical history and your family's medical history may help with detecting corneal ectasia as well as a comprehensive eye exam. The form of treatment will be based on the severity of your condition but may likely involve prescription glasses, or surgery.
### 4. Pterygium
Pterygium also known as surfer’s eye is characterised as the fleshy overgrowth of the conjunctiva which can extend onto the cornea. [Pterygium](https://www.oscarwylee.com.au/glasses/eye/pterygium-definition) may be caused by overexposure to sunlight, especially for those who frequently spend time outdoors, increased age, dusty or sandy environments or a combination of these causes. This condition may be considered uncommon with it affecting 1 in every 100 Australians according to Better Health. As pterygium grows larger, it may induce discomfort, redness, irritation, the sensation of a foreign body in the eye, distortion of the cornea and blurred vision. Pterygium may also occur without causing any symptoms, which may mean no treatment is required. However, if the growth is causing symptoms, using lubricating eye drops may provide some relief for irritation and discomfort. Surgery performed by an ophthalmologist may be recommended to completely remove the growth and prevent it from reaching the cornea according to Lions Eye Institute.
### 5. Corneal Abrasion
A corneal abrasion refers to scratches or injuries to the surface of the cornea, caused by debris or other foreign bodies in the eye. [Corneal abrasions](https://www.oscarwylee.com.au/glasses/eye/corneal-abrasion) can commonly come from dirt, sand, dust or even from rubbing your eyes. Symptoms of corneal abrasion can include foreign body sensation in the eye, eye redness, pain, watery eyes, sensitivity to light and blurred vision according to the American Academy of Ophthalmology. An optometrist can diagnose corneal abrasions through fluorescein dye placed on the surface of your eye which will highlight where an injury or scratch has occurred on the cornea. Treating corneal abrasions will depend on the severity of the injury or scratch and may require flushing out the eye, as well as topical antibiotics according to the Cleveland Clinic. For minor scratches, the cornea typically heals on its own within 24-48 hours as the cells within this region of the eye reproduce quickly.
### 6. Keratoconjunctivitis
Keratoconjunctivitis refers to inflammation of both the cornea and conjunctiva, developing as a result of allergies, and viral and bacterial infections. [Keratoconjunctivitis](https://www.oscarwylee.com.au/glasses/eye/keratoconjunctivitis) can either be infectious or non-infectious and there are several different types within the two groups. This corneal disease can be diagnosed by evaluating the physical symptoms and an eye exam. Treatment will depend on what is causing the inflammation, however, this can normally involve the use of eye drops, lubricating ointment, cold compresses, and topical or oral products according to the Cleveland Clinic.
## What are the Symptoms of Corneal Disease?
The symptoms of corneal disease are eye pain, blurred vision, bloodshot or red eyes, light sensitivity, vision deterioration, feeling of having something in your eye, teary eyes and eye discharge. If you experience any of the symptoms mentioned above please seek medical attention. These symptoms of cornea damage and disease are common in other eye conditions, therefore it is important to have a complete exam done by an optometrist to accurately determine a suitable treatment plan. The symptoms of corneal disease are listed below.
* Eye Pain: Eye pain can occur due to corneal disease depending on which form and can range from mild to severe.
* Blurred Vision: Blurred vision can develop as a result of corneal disease but may occur due to various factors.
* Bloodshot or Red Eyes: Bloodshot or red eyes can be induced by certain corneal diseases due to infection, irritation or inflammation of the eye.
* Light Sensitivity: Light sensitivity can develop as a result of corneal disease due to the impact of the condition on the structures of the eye.
* Vision Deterioration: Vision deterioration refers to when an eye condition impairs the visual system and visual functions.
* The Feeling of Having Something in Your Eye: The feeling of having something in your eye can be a common symptom of corneal disease as a result of injury or irritation in the eye.
* Teary Eyes: Teary eyes can be triggered by corneal diseases such as keratitis, corneal abrasions and herpetic eye diseases.
* Eye Discharge: Eye discharge can occur due to infection or inflammation related to keratitis as a result of excessive tear production.
### 1. Eye Pain
Eye pain can occur due to corneal diseases and may feel like there is a foreign body stuck in the cornea. Eye pain from corneal disease may also be characterised as a throbbing, aching or stabbing sensation, however, this can differ between the different types of corneal disease. Eye pain may be managed by using eye drops or oral medication as prescribed by your optometrist.
### 2. Blurred Vision
Blurred vision is described as sight that is out of focus or unclear and can develop as a result of corneal disease. Blurred vision may be caused by the accumulation of fluid in the cornea, corneal damage or changes to the cornea’s curve shape. However, the cause can differ between the different types of diseases. These are just a few examples of how blurred vision may develop as a result of corneal disease.
### 3. Bloodshot or Red Eyes
Bloodshot or red eyes can occur as a result of the eye’s small blood vessels enlarging. Different corneal diseases can induce bloodshot eyes or red eyes which can commonly be caused by infection of the eye, injury or irritation and other factors. Bloodshot or red eyes can be described as the sclera of the eye appearing red.
### 4. Light Sensitivity
Light sensitivity can arise due to corneal disease and may feel like pain, irritation or discomfort in the eye when exposed to light. Light sensitivity typically occurs as a result of the different corneal conditions. The possible causes could stem from inflammation in the eye or when certain conditions affect the way the eye processes light according to the Royal National Institute of Blind People.
### 5. Vision Deterioration
Vision deterioration may develop from certain corneal diseases as they can severely alter or cause damage to the structural foundations of the cornea. A patient’s vision can deteriorate due to scarring on the cornea caused by keratitis. However, this is only one example of how a corneal disease may cause vision deterioration according to the National Institutes of Health.&nbsp; Any changes to your vision such as loss of vision or vision impairment are considered serious, therefore, it is important to promptly seek assistance from an optometrist.
### 6. The Feeling of Having Something in Your Eye
The feeling of having something in your eye can be a possible symptom commonly associated with several types of corneal diseases. The feeling of having something in your eye may induce pain or discomfort. This may be managed with artificial tear eye drops to increase moisture in the eyes and help relieve the sensation of foreign body in the eye.
### 7. Teary Eyes
Teary eyes can be triggered by corneal diseases such as keratitis, corneal abrasions and herpetic eye disease due to the eye’s natural protective response. The eyes may be teary as a result of injuries to the eye or an eye infection as a way of protecting and relieving the eyes of what might be causing infection or injury. Managing teary eyes may require the use of antihistamines or artificial tear eye drops. However, treatment of any symptoms should be advised by an optometrist as they will be capable of identifying the main cause and the most suitable treatment.
### 8. Eye Discharge
Eye discharge may develop due to infections or inflammation related to keratitis. Eye discharge can occur when the eye becomes infected with bacteria or viruses causing the eye to produce excessive mucus. Eye discharge may commonly occur as a sign of infection and from the excessive production of tears in the eyes. This may be alleviated by using eye drops prescribed by your optometrist according to Health Direct.
## What are the Causes of Corneal Disease?
The causes of corneal disease are eye infections, genetic changes or genetic mutations, eye injury, or other eye problems. These causes may lead to other eye conditions, therefore, it is advisable to have them assessed by an optometrist for professional diagnosis and treatment. The causes of corneal diseases are listed below.
* Eye Infection: Eye infections occur when bacteria or viruses contaminate the eye and can be a possible cause of the corneal disease, keratitis.
* Genetic Changes or Genetic Mutations: Genetic changes or genetic mutations are defined as changes in DNA sequences and may cause corneal disease.
* Eye Injury: Eye injuries may contribute to corneal disease as they can lead to corneal scratches and scarring.
* Other Eye Problems: Other eye problems such as blepharitis and dry eye may also lead to corneal damage and pain in their severe stages.
### 1. Eye Infection
An eye infection such as keratitis may be a possible cause of corneal disease due to the condition’s impact on the cornea. Eye infections can lead to inflammation and damage to the cornea. Therefore it is important to seek treatment promptly to prevent further complications in the cornea. An eye infection can be characterised by redness in the eye, watery eyes, pain, swelling and irritation.
### 2. Genetic Changes or Genetic Mutations
Genetic changes or genetic mutations refer to changes in the genetic sequence in an organism and can be a cause of corneal diseases as they can lead to changes in the cornea. Genetic changes or genetic mutations such as corneal dystrophies can cause a build-up of unusual matter in the outside layer of the cornea. In some cases, this cause may not always give rise to symptoms but in other cases, symptoms that do occur can likely progress over time according to the National Eye Institute.
### 3. Eye Injury
An eye injury may contribute to corneal diseases due to the consequence of scratches on the surface of the cornea, which may lead to corneal scarring. Eye injuries can be a risk factor for corneal diseases. However, if injury to the cornea is minor, the eye’s healing process should naturally take place and may take two to three days. Examination from an optometrist may still be necessary to ensure further injuries were not caused and if the injury is considered severe and likely requires professional intervention.
### 4. Other Eye Problems
Other eye problems such as blepharitis and dry eye may also cause corneal disease. Blepharitis may lead to pain in the cornea due to eyelid swelling or irritation according to the National Eye Institute. Untreated dry eye can lead to long-term damage to the cornea and reduced vision according to John Hopkins Medicine. It is important to note that these other eye problems may not always result in corneal damage or pain, especially when diagnosed and treated in their early stages.
## Who is at Risk of Having Corneal Diseases?
People at risk of having corneal diseases may be those with eye problems and conditions that affect the cornea. Individuals who experience eye infections, eye inflammation, injuries or trauma to the eye and allergies may be at risk of having corneal diseases. There may not be a specific group of people that are more at risk of having corneal diseases than others as this group of eye conditions can affect any age.
## How is Corneal Disease Diagnosed?
Corneal disease is diagnosed by an optometrist or eye health professional through a comprehensive eye exam. Scratches on the cornea for example, can be identified using fluorescein dye according to the National Eye Institute.
### What to Expect During a Corneal Disease Diagnosis?
You can expect a standard comprehensive eye exam during the diagnosis of a corneal disease. This typically involves many different tests such as a slit lamp test and visual acuity test, to be able to thoroughly assess the condition of your cornea and other parts of the eye.
### How Long Does Diagnosis For Corneal Disease Take?
It may take around 20 minutes to diagnose corneal disease as it can be identified through a comprehensive eye exam. At Oscar Wylee, a range of eye conditions including corneal disease can be diagnosed through a complete eye exam, which typically takes 20 minutes. However, this may vary depending on the severity of your condition and if the optometrist identifies any other signs of concern.
### How Serious is Corneal Disease?
Corneal disease can be serious if it is left untreated as it can lead to loss of vision. However, this can also depend on which form of corneal disease you have and how severe the condition is. Many corneal diseases can cause pain, discomfort or irritation, therefore, it is important to seek medical help to prevent further complications.
#### Do Corneal Diseases Harm the Cornea Permanently?
Yes and no, corneal diseases may harm the cornea permanently depending on which type of disease you have and its severity. Factors such as foreign objects penetrating the cornea’s epithelial layer or cases of corneal infections that are severe and/or left untreated [may harm the cornea](https://www.oscarwylee.com.au/glasses/eye/cornea) as they can lead to permanent scarring. However, minor cases of corneal diseases can typically heal on their own within 24-48 hours.
### Does Corneal Disease Affect Other Parts of the Eye?
Yes certain corneal diseases can affect other parts of the eye such as the conjunctiva. Corneal diseases such as keratoconjunctivitis affect both the cornea and the conjunctiva, however, corneal diseases mainly affect the cornea.
#### Does Corneal Disease Lead to Blindness?
Yes, corneal disease can lead to blindness if left untreated. Many forms of corneal disease typically respond well to treatment, therefore, it is important to seek treatment from an eye care professional to prevent the development of corneal blindness.
#### Is Corneal Disease Contagious?
No, most corneal diseases are not contagious, however, viral infections that lead to keratitis and the viruses related to herpetic eye disease are contagious. Keratitis can be transmitted through contact with contaminated surfaces or items according to the Cleveland Clinic while herpes simplex virus is transmissible through skin-to-skin contact. Therefore, it is advisable to maintain proper hygiene by regularly washing your hands and minimising touching your face.
Find a Store Near You
Contact or visit your nearest store for a full quote for new frames.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
## What are the Treatments for Corneal Disease?
The treatments for corneal disease are corneal transplant surgery, artificial cornea, prescription eyeglasses, contact lenses and eye drops. Corneal disease treatment should vary depending on the severity of the condition and which form you have. The treatments for corneal disease are listed below.
* Corneal Transplant Surgery: Corneal transplant surgery involves removing either a portion or all of the affected cornea and replacing it with a healthy one.
* Artificial Cornea: An artificial cornea transplant may be an option for patients who are not able to tolerate cornea tissue from a donor.
* Prescription Eyeglasses: Prescription eyeglasses may be recommended for mild cases of corneal ectasia to improve vision.
* Contact Lenses: Contact lenses may be advised for improving vision when affected by a form of corneal disease.
* Eye Drops: Eye drops can be used to relieve corneal disease symptoms such as inflammation, infection, pain and irritation.
### 1. Corneal Transplant Surgery
Corneal transplant surgery typically involves removing some or all of the damaged cornea and replacing it with healthy corneal tissue from a donor. A corneal transplant surgery may be necessary if the patient’s cornea is beyond repair. There are three different types of corneal transplant surgery, which include penetrating keratoplasty, deep anterior lamellar keratoplasty and endothelial keratoplasty. An ophthalmologist will choose to carry out one of the options based on what part of the cornea is affected and how much is required for replacement according to the National Health Service. The risks of this form of treatment may involve the body rejecting the replaced tissue. However, this is considered a small risk as most surgeries are successful and experience no issues post-operation.
### 2. Artificial Cornea
An artificial cornea may be used to replace a patient’s damaged cornea if they are not able to tolerate donor tissue. The process of using an artificial cornea is called a keratoprosthesis and may be considered for stages of corneal disease wherein the patient experiences recurring graft failures or inflammation on the ocular’s surface according to the National Institutes of Health.
### 3. Prescription Eyeglasses
Prescription eyeglasses may be capable of improving vision that is mildly affected by corneal ectasia. Prescription eyeglasses may help with clear vision during mild corneal ectasia. If the condition worsens over time, eyeglasses may not be effective. However, this also depends on the type of corneal ectasia you have.
### 4. Contact Lenses
Contact lenses are thin synthetic lenses that are placed on the surface of the eye to correct vision problems that may be caused by symptoms of corneal diseases. Contact lenses may only be recommended to treat vision problems in mild cases of certain corneal diseases such as corneal ectasia.
### 5. Eye Drops
Eye drops may be used to treat different symptoms caused by corneal diseases. Eye drops are typically recommended for treating corneal diseases that result in swelling, redness, pain, teary eyes and the sensation of a foreign body in the eye. The type of eyedrops required for treatment usually include anti-inflammatory eye drops, antiviral eye drops, antibiotic eye drops or artificial tear eye drops, however, this will differ depending on the cause of symptoms.
### How Long Can a Corneal Disease Take to Heal?
The time it takes for a corneal disease to heal will vary depending on the type of disease the patient has. For more common corneal diseases such as keratitis, it can take around 1-2 days, for corneal abrasions, it may take 1-3 days and for corneal infections, it could take up to 2 weeks. However, it is important to note that these cases can differ between individuals and depend on the severity of the condition.
#### Do Corneal Diseases Go Away on Their Own?
Some corneal diseases can go away on their own but others require proper treatment. According to the National Eye Institute, minor injuries such as small abrasions on the cornea typically go away or heal on their own, whereas more serious diseases such as corneal ectasia and herpetic eye disease will need treatment. While some corneal diseases can go away on their own, it is best to book an appointment with an optometrist who can provide the best advice for your eye care needs.
## What Might Happen if the Cornea is Infected?
If the cornea is infected, you may experience symptoms such as redness or bloodshot eyes, the sensation of a foreign body in the eyes, eye pain, watery eyes, light sensitivity, blurry vision and reduced vision. It is important to see an optometrist as they can evaluate these symptoms and provide you with an accurate diagnosis and treatment plan.
### What to Do to Prevent Corneal Disease Infection?
To prevent corneal disease infection, it is important to maintain good hygiene by washing your hands regularly and minimising touching your eyes and general facial area. If you wear contact lenses, it is strongly recommended to take proper care of them by following the specific cleaning and storage instructions that come with them. This will help increase the prevention of corneal disease infections.
#### Can Wearing Glasses Reduce Corneal Disease Infection?
No, wearing glasses may not reduce corneal diseases that cause infections as they can only help correct vision. Reducing corneal disease infections will likely require anti-inflammatory or antibiotic eye drops to treat symptoms of an infection. However, glasses may reduce the likelihood of developing a corneal abrasion.
### When to call a Doctor about Corneal Disease?
It is important to call a doctor or eye care professional if you have any concerns about your vision. According to the National Eye Institute, the signs and symptoms that indicate when to call or visit a doctor include changes in vision, intense eye pain, blurry vision, an object stuck in the eye, very watery and red eyes and a serious eye injury.
### How can Glasses Help Treat Corneal Disease?
Glasses may not help treat corneal disease as most forms of corneal disease require some form of topical treatment or surgery. However, in mild cases, glasses may help correct vision that is affected by corneal ectasia. An eye care professional will advise the right treatment based on which form of corneal disease you have.
#### How Can Oscar Wylee Help You Choose Glasses for Corneal Diseases?
Oscar Wylee may help you choose glasses for corneal diseases when you get a comprehensive eye test with one of our optometrists in-store. Our team will be able to evaluate the extent of damage to your cornea and vision and assess whether prescription glasses are suitable for your condition. However, it is important to note that glasses may not be effective for improving vision as your condition worsens.
Read Corneal Disease: Types, Symptoms, Causes, and Treatment in other Oscar Wylee regions and their languages.
Australia   
[Australia](https://www.oscarwylee.com.au/glasses/eye/corneal-diseases)
New Zealand
 
[Canada](https://oscarwylee.ca/glasses/eye/corneal-diseases)
[Canadian French](https://oscarwylee.ca/fr/glasses/eye/corneal-diseases)
Major Health Funds Accepted In-store
For the purchase of frames and lenses, use your private health fund insurance to limit how much you pay from your own pocket.
[Health Fund](https://www.oscarwylee.com.au/health-funds.html)
Are You Due For An Eye Test?
Oscar Wylee offers bulk billed eye tests, so there are no out-of-pocket expenses for eligible Medicare cardholders.
[Book an eye test](https://www.oscarwylee.com.au/booking)