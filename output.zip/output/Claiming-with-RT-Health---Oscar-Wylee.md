# Source: https://www.oscarwylee.com.au/health-funds/rt-health.html

# RT Health at Oscar Wylee

As a member of RT Health, you can claim on optical extras using your health fund’s coverage for optical services, such as prescription frames, lenses or glasses. RT Health benefits reset every calendar year, claim your glasses before time runs out! At the end of the year, any extras you don’t use will be lost.  With Oscar Wylee, you can have up to 100% coverage on select optical purchases when you shop with us. Look at the table below to see your RT Health policy’s name and the amount of coverage that policy gives when you shop at Oscar Wylee.Your coverage might change or not apply to extras such as add-ons, coatings or tinting.
## Are you seeing double?
Taking care of your eyes can be done in only 30 minutes with Oscar Wylee.
[Book an eye test](https://www.oscarwylee.com.au/booking)
#### Waiting Period
3 Months for Value Extras, Smart Extras and Top Extras
#### Benefit Limits Reset
1st of January
#### Claimable Benefits %
100%
To learn whether your plan includes single-vision lenses, bifocal lenses and/or multifocal lenses, talk to your health insurance provider.
| Your Extras Package Annual Limit:* | Value Extras | Smart Extras | Top Extras | SINGLES COVER | 1 Standard OW Pair from $169^ | 2 Standard OW Pairs from $199^ | 3 Standard OW Pairs from $249^ |
| --- | --- | --- | --- | --- | --- | --- | --- |
| $200 | $250 | $300 |
| Covered | Covered | Covered |
| Covered | Covered | Covered |
| Partial Cover | Covered | Covered |
^Excludes add-ons. Standard frames and lenses only. Oscar Wylee’s standard product inclusions are calculated based on the optical allowances under each health fund package and may vary. If unsure, please confirm with your provider. Our two pair and three pair deals are only available per person and cannot be split between two people. Only one prescription can be used per offer. If you have a distance and a reading prescription, this is included in the offer as this is considered to be one prescription. Any prescriptions must have the full name of the person claiming and a valid expiry date to be able to order. If you have two different prescribed prescriptions, you will need to visit a store to be eligible for our two pair and three pair deals.
| FAMILY COVER | 1 Standard OW Pair from $169^ | 2 Standard OW Pairs from $199^ | 3 Standard OW Pairs from $249^ |
| --- | --- | --- | --- |
| $200 per person | $250 per person | $300 per person |
| Covered | Covered | Covered |
| Covered | Covered | Covered |
| Partial Cover | Covered | Covered |
^Excludes add-ons. Standard frames and lenses only. Oscar Wylee’s standard product inclusions are calculated based on the optical allowances under each health fund package and may vary. If unsure, please confirm with your provider. Our two pair and three pair deals are only available per person and cannot be split between two people. Only one prescription can be used per offer. If you have a distance and a reading prescription, this is included in the offer as this is considered to be one prescription. Any prescriptions must have the full name of the person claiming and a valid expiry date to be able to order. If you have two different prescribed prescriptions, you will need to visit a store to be eligible for our two pair and three pair deals.
## Due for an eye test?
We recommend that everyone should have an eye test with an optometrist at least once every 2 years.
[Book an an eye test](https://www.oscarwylee.com.au/booking)
*Based on RT Health’s [Cover Guide](https://rthealthfund.com.au/understanding-your-cover/), [Product Brochure](https://rthealthfund.com.au/getmedia/aaf17157-0bf4-48e8-9b41-f68337b0a749/Product-Comparison-Table.pdf) and product factsheet as presented to the Commonwealth Ombudsman [1](https://assets-us-01.kc-usercontent.com/1e7d44d9-4a81-002b-825a-a99c796ddad3/f34686b4-b906-4e9d-a473-76751b4cc1da/Value-Extras.pdf) [2](https://assets-us-01.kc-usercontent.com/1e7d44d9-4a81-002b-825a-a99c796ddad3/395b4f5b-17bd-45de-8ad0-b665161d198f/Smart-Extras.pdf) [3](https://assets-us-01.kc-usercontent.com/1e7d44d9-4a81-002b-825a-a99c796ddad3/3141d12f-a4c5-4c12-9449-0b229f9e6c66/Top-Extras_1.pdf).  Information correct as of August 2026.
## Your eye test explained
Routine eye test appointments are quick and painless. Find out what to expect during an eye exam and how to understand your eye test results.
[Find out more](https://www.oscarwylee.com.au/eye-health/your-eye-test-explained.html)
## Bulk Billing
Find out what bulk billing is and whether you're eligible to receive an eye test free of charge.
[Find out more](https://www.oscarwylee.com.au/eye-health/eye-test-info/bulk-billing.html)
## What is Pupillary Distance? (PD)
Do you know your PD? It's something you'll need to know when ordering glasses online. Find out what Pupillary Distance is and how you can measure your own.
[Read more](https://www.oscarwylee.com.au/eye-care/eye-test/what-is-pupillary-distance.html)
## Book an eye test
Oscar Wylee eye tests are bulk billed through Medicare. This means there will be no out-of-pocket expense for eligible Medicare cardholders.
[Book online](https://www.oscarwylee.com.au/booking/)
## Find a store near you
Contact or visit your nearest store for a full quote.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)