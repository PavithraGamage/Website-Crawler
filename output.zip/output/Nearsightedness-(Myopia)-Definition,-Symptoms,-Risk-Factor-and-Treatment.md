# Source: https://www.oscarwylee.com.au/glasses/eye/nearsightedness

# Nearsightedness (Myopia): Definition, Symptoms, Risk Factor and Treatment
Published on April 17th, 2023
Updated on October 31st, 2024
Australia    
[Australia](https://www.oscarwylee.com.au/glasses/eye/nearsightedness)
[New Zealand](https://www.oscarwylee.co.nz/glasses/eye/nearsightedness)
[Canada](https://oscarwylee.ca/glasses/eye/nearsightedness)
[Canadian French](https://oscarwylee.ca/fr/glasses/eye/nearsightedness)
Nearsightedness, medically known as myopia, is an an eye condition that is commonly caused by a misshapen eye, which disrupts the eyes’ ability to receive and bend light. The misshapen eye causes blurred vision when looking in the distance or focusing on distant objects. The following article will discuss the nearsightedness definition, nearsightedness symptoms, nearsightedness causes, nearsightedness treatments and nearsightedness risk factors.
Nearsightedness symptoms include blurred vision, strained eyes, trouble seeing distant objects and squinting. Nearsightedness is commonly caused by a misshapen eye, cornea, or lens that cannot receive or bend light at proper capacity. Nearsightedness can be treated with a pair of prescription eyeglasses. Nearsighted risk factors include genetics, excessive screen time and not enough time spent outdoors.
[Definition](#definition) [Types](#types) [Symptoms](#symptoms) [Risk Factors](#risk-factors) [Complications](#complications)
## What is Nearsightedness?
Nearsightedness, or myopia, is an eye condition in which, due to an elongated eyeball or an overly curved cornea, the eye is not as capable of bending and focusing light onto the retina correctly. The retina is the part of the eye which changes light into images and sends the visual information through the optic nerve to the brain.
What is nearsightedness?
The following is an image of myopia’s definition. The image illustrated how the misshapen retina and lens are disrupting the eye’s ability to focus light directly onto the retina.
Look after your eyes!
At Oscar Wylee, you can book an eye test with one of our optometrists to get the best care for your eyes. Our eye tests are bulk billed for all eligible Medicare card holders.
[Book an eye test](https://www.oscarwylee.com.au/booking)
## What are Other Terms for Nearsightedness?
Other terms for nearsightedness are shortsightedness and myopia. Nearsightedness is medically known as myopia by doctors and other health professionals. More severe forms of nearsightedness are known as high myopia, pathological myopia, degenerative myopia, or malignant myopia.
## How Does Nearsightedness Develop?
Nearsightedness most commonly develops when the cornea or the length of the eye becomes misshapen, causing the eye to not receive or bend light well, which is a refractive error. Nearsightedness is most commonly caused by the eyeballs being more ovular instead of round or by the cornea or lens being misshapen.
## How Common is Nearsightedness?
Nearsightedness is one of the most common refractive errors of the eye in the world, and affects 25% of Australians, according to the Australian College of Optometry.
### Who is at Higher Risk of Developing Myopia?
Children between the age of 6 and 14 are at the highest risk of developing myopia, according to Healthy Child, a research and information site in association with the American Academy of Paediatrics. A higher risk of myopia is also likely if a child’s parents have nearsightedness.
## What are the Types of Nearsightedness?
The types of nearsightedness or myopia, can refer to the degree of myopia a person has. A person may have simple, or mild myopia, which occurs at a level of 0 to −1.5 diopters, according to the National Institue of Health. The types of more advanced nearsightedness are high myopia and pathological myopia. The following are some of the types of more advanced myopia.
1. High Myopia: High myopia is a type of extreme nearsightedness caused by an elongated, misshapen and ovular eye that disrupts vision more than common myopia, or ‘low myopia’.
2. Pathological Myopia: Pathologic myopia, or malignant myopia, is a type of nearsightedness where, due to genetic reasons, the eyeball becomes longer over a short period of time, causing a high level of myopia and creating a risk of other eye conditions.
### 1. High Myopia
High myopia refers to nearsightedness that is caused by a longer and more ovular shape of the eye. The longer shape of the eye is even greater than a typical case of nearsightedness, causing a severe inability to focus the eye. Medically, high myopia can also be defined as nearsightedness to a level of -6 diopters, a unit that measures the focal ability of lenses, according to All About Vision. High myopia is different from pathological myopia because high myopia is specifically caused by, or refers to, a large degree of refractive error in the eye, whereas pathological myopia refers to other forms of complication within the eye's general makeup. High myopia is diagnosed by a standard eye test, as performed by an optometrist or other eye health professional.
If a case of high myopia or pathological myopia has been diagnosed, it is highly advised to book regular optometry appointments to monitor the condition and continually check for any further retinal issues.
### 2. Pathological Myopia
Pathological myopia, also known as degenerative myopia or malignant myopia, is a rare type of nearsightedness where the shape of the eye lengthens over a short period of time, notably shaping and causing complications within the fundus, or back of the eye. Pathological myopia causes greater visual issues and creates a risk of other eye conditions, such as glaucoma, macular degeneration and retinal detachment. Pathological myopia differs from high myopia because it is a genetic condition that is more severe than high myopia. Pathological myopia most commonly occurs within eyes that are also affected by high myopia. Pathological myopia is diagnosed by a fundus examination as performed by an optometrist or other relevant health professional.
If high myopia or pathological myopia has been diagnosed, it is highly advised to book regular optometry appointments to monitor the condition and continually check for any further retinal issues.
Stop by your local Oscar Wylee store
See our friendly and experienced team at your nearest Oscar Wylee store, to find the perfect pair of frames for you.
[Find your store](https://www.oscarwylee.com.au/locations/full-store-list.html)
## What are the Causes of Nearsightedness (Myopia)?
Nearsightedness causes, or what causes nearsightedness (myopia) in the eye is not strictly known and can vary from person to person. Nearsightedness (myopia) causes can be genetics, abnormal eyeball growth, too much time indoors, environmental factors, excessive amounts of close work and more.
## What are the Symptoms of Nearsightedness (Myopia)?
The symptoms of nearsightedness (myopia) are nearby objects that seem to be clear, frequent squinting to see clearly, eye strain, objects in the distance that appear fuzzy or blurry, eye fatigue and headaches. The symptoms of nearsightedness are listed below.
* Nearby objects that seem to be clear: Nearby objects that seem to be clear, but far away objects are blurry, is a symptom of nearsightedness, because myopia does not affect up-close vision.
* Frequently squinting to see clearly: Frequently squinting to see clearly is a symptom of nearsightedness because a person may squint to overcome the poor distance focus myopia causes.
* Eye strain: Eye strain is a symptom of nearsightedness as extended periods of focus caused by myopia may be straining the muscles of the eye.
* Objects in the distance that appear fuzzy or blurry: Objects in the distance that appear fuzzy or blurry are a symptom of nearsightedness as issues with the cornea and lens have affected distant vision, resulting in far-off focus appearing blurry and hazy.
* Eye fatigue: Eye fatigue is a symptom of nearsightedness because the eyes have strained themselves attempting to focus through the visual issues caused by myopia, resulting in fatigue and eye exhaustion.
* Headaches: Headaches are a symptom of nearsightedness that is caused by continually focusing on one object, as well as eye strain and eye fatigue caused by attempting to focus in order to overcome myopia.
### 1. Nearby Objects that Seem to be Clear
Nearby objects seeming to be clear, with far away objects appearing blurry, refers to the fact that  myopia does not commonly interfere with up-close vision, allowing the eyes to focus on nearby objects without [blurred vision](https://www.oscarwylee.com.au/glasses/eye/blurred-vision). Nearby objects seeming to be clear with faraway objects appearing blurry, is a symptom of myopia because clear up-close vision makes the issues with distance vision more apparent.
### 2. Frequently Squinting to See Clearly
Frequent squinting to see clearly refers to the eyes squinting and closing in order to focus more on distant objects, causing strain and fatigue to overcompensate for the distance vision. Frequent squinting to see clearly becomes a symptom of myopia when a person tries to overcompensate or force their eyes to correct the lost levels of focus that nearsightedness causes, additionally creating eye strain and eye fatigue.
### 3. Eye Strain
Eye strain refers to fatigue and extreme effort placed on the eyes to stay focused, which could eventually cause headaches, nausea and eye pain. [Eye strain](https://www.oscarwylee.com.au/glasses/eye/strain) becomes a symptom of myopia when the eyes attempt to overcompensate for poor focusing abilities, causing squinting and prolonged periods of concentration that can cause fatigue in the eye’s muscles.
### 4. Objects in the Distance Appearing Fuzzy or Blurry
Object in the distance appearing fuzzy or blurry refers to people or focal points in the distance being hazy, blurry, or unclear until that object is moved closer. Objects in the distance appearing fuzzy or blurry is a symptom of nearsightedness as myopia has affected the eyes’ ability to bend and receive light, affecting overall visual abilities at certain distances.
### 5. Eye Fatigue
Eye fatigue refers to strain and exhaustion within the muscles of the eye. [Eye fatigue](https://www.oscarwylee.com.au/glasses/eye/fatigue-definition) can be a symptom of nearsightedness because the eyes are straining to concentrate in order to overcompensate for the poor focal abilities that conditions like myopia cause.
### 6. Headaches
Headaches refer to an aching pain that can feel like a constant dull uncomfortable pressure in the skull or a pulsing pain from the frontal lobe. Headaches become a symptom of nearsightedness as a possible side effect of eye strain and eye fatigue. Headaches may also be a result of extreme periods of prolonged focus.
If headaches persist, it is important to seek medical attention.
### When do Nearsightedness Symptoms Usually Occur?
Nearsightedness symptoms usually begin appearing from childhood to adolescence, according to the Lions Eye Institute, an Australian ophthalmologic institute. Nearsightedness should stop progressing in a person's vision by the time they are 20, but certain factors and health conditions, such as diabetes, may result in myopia symptoms appearing in adulthood.
#### Can Nearsightedness Disappear by Itself?
Nearsightedness is a long-term condition and will not disappear by itself. Nearsightedness requires long-term treatment and without medical assistance, a person's vision skills will remain compromised.
## What are the Risk Factors of Nearsightedness (Myopia)?
The risk factors of nearsightedness (myopia) are genetics or family history, age, extended close-up activities, diabetes, environmental factors, recurring visual stress, long-term use of devices and spending less time outside. The risk factors of nearsightedness (myopia) are listed below.
* Genetics or family history: Genetics or family history is a risk factor for nearsightedness because it shows a genetic propensity towards the condition in children.
* Age: Age is a risk factor for nearsightedness because if a child has myopia it may degenerate as they age.
* Extended close-up activities: Extended close-up activities are a risk factor for nearsightedness as these activities may cause eye strain and exacerbate symptoms of myopia.
* Diabetes: Diabetes is a risk factor for nearsightedness as high glucose levels can affect the eyes and how they function.
* Environmental factors: Environmental factors are a risk factor for nearsightedness because the eyes may not be receiving the light and nutrients they need to function properly.
* Recurring visual stress: Recurring visual stress is a risk factor for nearsightedness as repeated instances of eye strain or eye fatigue may result in symptoms of myopia affecting vision.
* Long-term use of devices: Long-term use of devices is a risk factor for nearsightedness because too much concentration on an up-close object may create symptoms of myopia.
* Spending less time outside: Spending less time outside is a risk factor for nearsightedness because it may cause the eye to develop myopia due to the lack of the necessary sunlight.
### 1. Genetics or Family History
Genetics or family history refers to repeated instances of certain conditions or aspects throughout someone’s entire family history, such as brown hair or certain eye colours. Genetics or family history is a risk factor of nearsightedness (myopia) because if a parent has myopia, it is very likely that the condition shall be inherited by any children that person has.
### 2. Age
Age refers to a person's eyes becoming older, putting them more at risk of becoming affected by certain eye conditions and requiring treatment. Age is a risk factor for nearsightedness as myopia symptoms typically first appear at a young age. As the child ages, there is a risk of the condition becoming worse. Past a certain age, there is less risk of myopia progression as ageing itself is not correlated with myopia.
### 3. Extended Close-up Activities
Extended close-up activities refer to prolonged periods of visual concentration and focus on a single object or area, such as a long time spent looking at a phone screen. Extended close-up activities are a risk factor for nearsightedness, especially in children, because the extended period of focus elongates the eyes and can cause digital eye strain, which may lead to, or exacerbate symptoms of myopia.
### 4. Diabetes
Diabetes refers to a health condition that affects the body's blood glucose levels and interrupts how the body turns food into energy. Diabetes is a risk factor for nearsightedness as the health condition can cause structrual changes in the eye, including changes to the lens. Lens changes caused by diabetes can be myopic in nature, meaning they can affect long distance vision, according to the paper Refractive changes in diabetes: not always what meets the eye by Ryan J. Diel, MD; Heather A. Stiff, MD; Young H. Kwon, MD, PhD and Jaclyn M. Haugsdal, MD.
### 5. Environmental Factors
Environmental factors refer to issues with a person's lifestyle and environment, such as poor diet or not receiving enough sunlight. Poor diet affects overall health, which may also affect eye function. Reduced sunlight exposure may also be linked to the development of progressive myopia.
### 6. Recurring Visual Stress
Recurring visual stress refers to any object of focus or lifestyle patterns that are causing consistent eye fatigue and eye strain on a regular basis. Recurring visual stress is a risk factor for nearsightedness because it creates a risk of myopia and the additional strain and fatigue the eyes are undergoing may result in symptoms of myopia in general vision.
### 7. Long-term Use of Devices
Long-term use of devices refers to prolonged periods of time on digital devices, such as a smartphone, computer screen, tablet or television. Long-term use of devices is a risk factor for nearsightedness because intensely focusing on a nearby object for an extended period of time may cause the eyeballs to elongate and bend in a similar way to the causes of myopia, which may cause symptoms of nearsightedness in vision.
### 8. Spending Less Time Outside
Spending less time outside refers to the body not receiving the essential sunlight it may need in order to function at proper capacity. According to a study performed by Aparna Ramasubramanian of the American Academy of Ophthalmology, natural sunlight intervention was shown to reduce the myopic shift and elongation of the eyeballs. Spending less time outside is a risk factor for nearsightedness in children specifically, because it may affect the eyes and increase the likelihood of myopia developing.
#### Does Myopia Get Worse as We Age?
Myopia is more commonly an issue during adolescence. The risk of myopia may lessen as the eyes age after 20 and will be unlikely to develop past the age of 50.
### What are Nearsightedness Complications?
Nearsightedness complications are poor vision, education issues for children, consistent eye strain, and risk of other eye conditions. The possible complications of nearsightedness are listed below.
* Poor Vision: Poor vision is a complication of nearsightedness as the inability to see clearly can compromise a person's daily quality of life and may pose a safety risk if a person with myopia is operating certain machinery, such as cars.
* Education issues for children: Education issues for children are a complication of nearsightedness because a child with untreated myopia may be developing slower due to myopia interfering with their reading and may result in a child falling behind their peers in a classroom.
* Consistent eye strain: Consistent eye strain is a complication of nearsightedness because untreated myopia may be causing eye fatigue and eye strain whenever a person is trying to see a distant object, which may affect the quality of life and cause daily eye pain.
* Risk of other eye conditions: Risk of other conditions is a complication of nearsightedness because extreme forms of myopia such as high myopia or pathologic myopia also increased the risk factors of other eye conditions, such as glaucoma, retinal detachments or cataracts.
#### Can Myopia Cause Blindness?
Myopia can lead to blindness under certain circumstances, and nearsightedness can be an additional risk factor for other, more severe eye conditions that can cause permanent blindness in one or both eyes. Myopia may cause blindness if the condition degenerates into pathological myopia, which lengthens the eye, puts strain on the retina and creates a risk factor for glaucoma, myopic macular degeneration and nuclear cataracts, according to All About Vision, a global eyecare database.
How does myopia affect vision?
Myopia affects vision by causing the eye to be unable to receive, bend and manipulate light with full functionality, affecting how well the light can be translated into an image and causing symptoms such as blurry vision or headaches.
### How is Nearsightedness Diagnosed?
Nearsightedness is diagnosed by an optometrist or other eye health professional conducting a typical eye test to check for visual acuity, 20/20 vision and focal abilities.
#### Where Can You Seek a Nearsightedness Diagnosis?
A nearsightedness (myopia) diagnosis can be performed by an optometrist with various examination methods, such as a basic eye test.
## What are the Treatments Available for Nearsightedness (Myopia)?
The treatments available for nearsightedness are eyeglasses or contact lenses and refractive surgery. The possible treatments for nearsightedness are listed below.
* Eyeglasses or contact lenses: Eyeglasses or contact lenses refer to corrective prescriptions that treat nearsightedness by providing the eyes with the necessary focal power. Oscar Wylee does not sell contact lenses.
* Refractive surgery: Refractive surgery refers to procedures such as LASIK or PRK, which treat nearsightedness by reshaping the cornea and correcting refractive errors.
### Can Eye Drops Treat Nearsightedness?
Eyedrops cannot treat nearsightedness as it is caused by structural issues with the eye. Nearsightedness is likely a lifelong issue. However, for children with myopia, eyedrops with a small amount of atropine have been shown to possibly slow the effects and progression of myopia within the eye, according to the National Library of Medicine, an American centre for biotechnical information.
### Is Wearing Glasses Correct for My Nearsightedness?
Wearing glasses is the correct and effective way to treat nearsightedness and prevent the symptoms of myopia from affecting the daily quality of life. Contact lenses are a similar treatment that will also correct the visual issues caused by nearsightedness.
### Does Myopia Get Better Over Time?
Myopia does not get better over time in a person who has been diagnosed with it, however, at a certain age the condition will stop progressing. The risk and prevalence of myopia have been shown to decrease from the ages of 45 to 50, according to Investigative Ophthalmology and Visual Science, an online journal for research into the visual system.
### Can Laser Eye Surgery Cure Nearsightedness?
Laser eye surgery can correct nearsightedness through laser eye treatments, most commonly through a specific procedure called LASIK, or laser-assisted in situ keratomileusis. LASIK uses a cutting laser to change the shape of the cornea and correct refraction errors and similar conditions. Laser eye surgery however, does not change the elongation of the eyeball, so the risk of certain eye conditions is still the same after surgery.
### What are the Best Contact Lenses for Nearsightedness?
Concave contact lenses are the most common contact lenses used to treat nearsightedness.
Please be advised, Oscar Wylee does not produce or sell contact lenses at this time.
#### Do Contact Lenses Correct My Nearsightedness?
Contact lenses, specifically concave contact lenses, with the right level of prescriptions, will help to correct nearsightedness.
Please be advised, Oscar Wylee does not sell contact lenses online or in-store.
#### What are the Best Eyeglasses for Nearsightedness?
The best eyeglasses for nearsightedness are any frames that use the correct prescriptions in order to correct the wearer's myopia. Eyeglasses for nearsightedness use concave lenses in order to correct the focal issues, and eyeglasses prescriptions for myopia are available in a single lens, bifocal lens, or progressive and multifocal lens. However, multifocal lenses on children with myopia may slow the progress of nearsightedness in addition to being more versatile in use, according to the American Optometric Association, an American organisation of optometrists. Other details of eyeglasses for myopia can change depending on the wearer’s preference and can include choices in material, colour or frame style.
## How to Prevent Nearsightedness?
Nearsightedness may not be preventable once it is diagnosed, however, preventing further myopic degeneration and encouraging good vision and eye health can be achieved by getting regular eye tests as performed by an optometrist or other eye health specialist, limiting up-close phone activities and only reading in comfortable and clear lighting.
### Does Wearing Glasses Every Day Prevent Nearsightedness?
Wearing glasses every day does not prevent the condition of nearsightedness from forming. Wearing glasses all day helps to correct the visual and focal issues nearsightedness is creating in the eye, allowing for full visual functionality and focal abilities in eyes that are affected by myopia.
#### What is the Difference Between Nearsightedness and Farsightedness?
The difference between nearsightedness and farsightedness is the way that light focuses on the retina. With myopia or nearsightedness, the light focuses before the retina, which may cause symptoms such as blurry distance vision. With hyperopia or farsightedness, light focuses behind the retina, which may cause symptoms such as blurry near vision.
Read Nearsightedness (Myopia): Definition, Symptoms, Risk Factor and Treatment in other Oscar Wylee regions and their languages.
Australia    
[Australia](https://www.oscarwylee.com.au/glasses/eye/nearsightedness)
[New Zealand](https://www.oscarwylee.co.nz/glasses/eye/nearsightedness)
[Canada](https://oscarwylee.ca/glasses/eye/nearsightedness)
[Canadian French](https://oscarwylee.ca/fr/glasses/eye/nearsightedness)
Australia’s leading health funds accepted in-store at Oscar Wylee
Shop with Oscar Wylee, and your health fund may be able to help cover a new pair of prescription glasses.
[Health Funds](https://www.oscarwylee.com.au/health-funds.html)
Ready for an eye test?
Book a Medicare bulk billed eye test in-store with our dedicated and skilled Oscar Wylee optometrists.
[Book an eye test](https://www.oscarwylee.com.au/booking)