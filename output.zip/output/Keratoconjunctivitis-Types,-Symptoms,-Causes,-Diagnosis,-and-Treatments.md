# Source: https://www.oscarwylee.com.au/glasses/eye/keratoconjunctivitis

# Keratoconjunctivitis: Types, Symptoms, Causes, Diagnosis, and Treatments
Published on September 19th, 2024
Updated on August 20th, 2024 
Keratoconjunctivitis refers to
the inflammation of both the conjunctiva and cornea, which can stem from
causes such as bacteria, viruses, allergens and pollutants
according to the Cleveland Clinic. Keratoconjunctivitis symptoms can include
watery eyes, itchy eyes, redness, swollen eyes and discharge. The
conjunctiva is defined as the clear tissue that covers the sclera (the white
part of the eye) and lines the inside of the eyelid, providing protection
for the eyes. The cornea is the clear outer layer of the eye covering the
iris and the pupil. Keratoconjunctivitis can occur in non-infectious cases
which can lead to allergic keratoconjunctivitis, exposure
keratoconjunctivitis and keratoconjunctivitis sicca. Infectious cases of
keratoconjunctivitis can include epidemic keratoconjunctivitis, bacterial
keratoconjunctivitis, phlyctenular and keratoconjunctivitis, Keep reading to
learn more about the symptoms and causes of keratoconjunctivitis, treatment
and prevention.
Prioritise Your Eye Health at Oscar Wylee
Come see our friendly optometrists and team for great eye care services.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Definition](#Definition)
[Types](#Types)
[Symptoms](#Symptoms)
[Causes](#Causes)
[Treatments](#Treatments)
## What is Keratoconjunctivitis?
Keratoconjunctivitis is a condition that
causes inflammation in the conjunctiva and cornea.
Keratoconjunctivitis can develop as a result of viral and bacterial
infections, allergic reactions, eye injuries, dry eyes and from
pollutants entering the eye. While keratitis and conjunctivitis are
separate eye problems, keratoconjunctivitis is when you have both
according to the Cleveland Clinic. Symptoms that are commonly associated
with keratoconjunctivitis can involve watery eyes, redness, itchy eyes,
swelling and discharge.
### What Does Keratoconjunctivitis Look Like?
Keratoconjunctivitis looks
like watery eyes, swollen eyes, discharge filled eyes and redness
in the white part of the eye. Individuals with keratoconjunctivitis may not experience all known
symptoms as it can depend on the severity of your condition.
The image below depicts what keratoconjunctivitis can look like in
affected individuals. The eye pictured below exhibits slight redness,
discharge and swelling.
### What is the Medical Term for Keratoconjunctivitis?
The medical term for Keratoconjunctivitis
is keratoconjunctivitis. This medical term describes
inflammation of the cornea and conjunctiva.
#### Is Keratoconjunctivitis the Same as Dry Eyes?
No, keratoconjunctivitis is
not the same as dry eye, however, keratoconjunctivitis can
develop as a consequence of dry eye.
[Dry eyes](https://www.oscarwylee.com.au/glasses/eye/dry-eyes)
can mean that the eyes are not producing enough tears to maintain
optimal moisture. The other cause for dry eyes can be that the tears
that are produced, are evaporating too quickly causing dryness in
the eyes. Keratoconjunctivitis that is caused by dry eyes is
referred to as keratoconjunctivitis sicca according to the College
of Optometrists.
## How Common is Keratoconjunctivitis?
Keratoconjunctivitis
can be common depending on the type of this condition. A common
form of keratoconjunctivitis may be allergic keratoconjunctivitis
according to the Cleveland Clinic. Up to 40% of the population are
affected by allergic keratoconjunctivitis according to Baab, Le, Gurnani
and Kinzer (2024).
### Is Keratoconjunctivitis a Common Disease on the Cornea?
No, it may
not be considered a common disease on the cornea, however, forms
such as allergic conjunctivitis is considered common. Other
[common diseases on the cornea](https://www.oscarwylee.com.au/glasses/eye/corneal-diseases)
can include keratitis, corneal ectasia and corneal dystrophy according
to the Cleveland Clinic.
### Who Typically Gets Keratoconjunctivitis?
Anyone can get keratoconjunctivitis as it can develop through various
causes. However,
certain groups of people may be more susceptible to certain forms
of keratoconjunctivitis. Vernal keratoconjunctivitis is an allergy associated form that is
reported to affect young males living in hot climates according to
Burrow and Patel (2023). Children are most commonly associated with
allergic, viral and bacterial keratoconjunctivitis according to the
Cleveland Clinic.
#### Do Children Get Keratoconjunctivitis?
Yes, children can get keratoconjunctivitis.
Children may be more likely to contract viral and bacterial
keratoconjunctivitis and allergic conjunctivitis
according to the Cleveland Clinic. Children may be more vulnerable
to viral and bacterial forms of keratoconjunctivitis due to their
developing immune systems and smaller anatomy. Children’s higher
chances of getting allergy-associated keratoconjunctivitis are a
result of their underdeveloped mucosal defences according to the
National Institutes of Health.
## What are the Different Types of Keratoconjunctivitis?
The different types of keratoconjunctivitis include
vernal keratoconjunctivitis, epidemic keratoconjunctivitis, atopic
keratoconjunctivitis, superior limbic keratoconjunctivitis, allergic
keratoconjunctivitis, keratoconjunctivitis sicca and phlyctenular
keratoconjunctivitis. It is important to note that keratoconjunctivitis symptoms of
redness, itchy eyes, swelling, watery eyes and discharge are typically
similar across the different forms. The different types of
keratoconjunctivitis are listed below.
* Vernal Keratoconjunctivitis:  Vernal
keratoconjunctivitis is a recurrent form that occurs from allergic
reactions and can affect both eyes.
* Epidemic Keratoconjunctivitis: 
Epidemic keratoconjunctivitis is categorised as a form of viral
keratoconjunctivitis and is highly contagious.
* Atopic Keratoconjunctivitis: 
Atopic keratoconjunctivitis is a chronic, allergy associated form of
keratoconjunctivitis that develops in patients with atopic dermatitis.
* Superior Limbic Keratoconjunctivitis: 
Superior limbic keratoconjunctivitis is a rare form of
keratoconjunctivitis and causes inflammation in the superior bulbar
conjunctiva, limbus and upper cornea.
* Allergic Keratoconjunctivitis: 
Allergic keratoconjunctivitis is a form that ensues when coming into
contact with allergens such as pet dander, pollen and dust.
* Keratoconjunctivitis Sicca: 
Keratoconjunctivitis sicca can develop as a consequence of dry eyes.
* Phlyctenular Keratoconjunctivitis: 
Phlyctenular keratoconjunctivitis causes an immune reaction to
bacteria that is on or around the eyes.
## 1. Vernal Keratoconjunctivitis
Vernal keratoconjunctivitis is a recurrent allergic disorder that
typically occurs during spring or warm weather. Vernal
keratoconjunctivitis is considered non-contagious and is often found in
patients with atopic dermatitis or eczema according to the College of
Optometrists. This form of keratoconjunctivitis typically affects young
male patients within the age range of 3-25 years old according to the
National Organisation for Rare Disorders.
## 2. Epidemic Keratoconjunctivitis
Epidemic keratoconjunctivitis also referred to as viral
keratoconjunctivitis is
a very contagious form that is caused by adenoviruses. Epidemic
keratoconjunctivitis can be spread by coming into contact with an
infected person’s tears or discharge from their eyes and then touching
your own eyes. This may occur when touching surfaces that may be
contaminated or touching an infected person’s hands. According to NSW
Health, there is no treatment for epidemic keratoconjunctivitis and
should alleviate on its own after 1 to 6 weeks.
## 3. Atopic Keratoconjunctivitis
Atopic keratoconjunctivitis is chronic and
affects patients with atopic dermatitis. According to the
University of Michigan Health, this form can occur all year round but
may worsen during winter. Atopic keratoconjunctivitis may affect the
lower eyelid more than the upper eyelid, which can help differentiate
from vernal keratoconjunctivitis. A combination of topical and oral
antihistamines may be helpful in managing symptoms according to the
University of Michigan Health.
## 4. Superior Limbic Keratoconjunctivitis
Superior limbic keratoconjunctivitis is
the inflammation of superior bulbar conjunctiva, limbus and upper
cornea. Superior limbic keratoconjunctivitis may be related to
keratoconjunctivitis sicca, thyroid dysfunction and rheumatoid arthritis
according to Bert et al. (2024). This form of keratoconjunctivitis has
been noted to affect women in their 60s more than men according to the
American Academy of Ophthalmology and may require different types of
topical steroids for treatment. However, there is not enough robust
evidence to confirm the most effective treatment.
## 5. Allergic Keratoconjunctivitis
Allergic keratoconjunctivitis is
a very common form that can occur when coming into contact with
allergens such as animal dander, pollen and dust. Allergic keratoconjunctivitis may only arise among individuals who do
experience allergic reactions to certain substances. According to the
National Institutes of Health, antihistamine eye drops prescribed from
an optometrist may help alleviate symptoms.
## 6. Keratoconjunctivitis Sicca
Keratoconjunctivitis sicca refers to
the inflammation of the cornea and conjunctiva as a result of dry
eyes. Keratoconjunctivitis sicca may come about when the eyes are not able
to generate enough tears or when the eyes produce tears that evaporate
too quickly. This can lead to a lack of proper moisture in the eyes
causing dryness, irritation and discomfort. Applying artificial or
lubricating tears every couple of hours can typically reduce the
problem. Artificial tears are eye drops mixed with substances that mimic
real tears and assist with keeping the eyes coated with moisture.
## 7. Phlyctenular Keratoconjunctivitis
Phlyctenular keratoconjunctivitis
may be associated with hypersensitivity reactions as a consequence of
Mycobacterium tuberculosis or chlamydial infections. However, it can
also originate from other bacterial, viral, or environmental
allergens. Treatment may require addressing the initial cause, such as
antimicrobial treatment for infections, corticosteroids to reduce
inflammation and relieve symptoms. Lubricating eye drops or artificial
tears may also be recommended to reduce dryness and discomfort. It is
important to see an optometrist so you can receive a professional
diagnosis and the right form of treatment.
## What are the Symptoms of Keratoconjunctivitis?
The symptoms of keratoconjunctivitis include
eye discharge, feeling something in your eye, swollen eyelids
(blepharitis), burning in the eye, light sensitivity (photophobia),
watery eyes, itchy eyes and redness in the eyes. The symptoms of keratoconjunctivitis are listed below.
* Eye Discharge:  Eye discharge is the
clear, grey, or in some cases yellowish mucus-like substance that is
released from the eye when experiencing eye injuries, infections and
dryness.
* Feeling something in your eye: 
Feeling something in your eye is a symptom of keratoconjunctivitis can
stem from the dryness, injuries and infections that occur.
* Swollen Eyelids (Blepharitis): 
Swollen eyelids (blepharitis) are when the eyelids become puffy and
slightly red as a natural reaction to inflammation.
* Burning in the eye: 
Burning in the eye may feel like a stinging sensation, which occurs
when the eyes lack moisture or when they become irritated.
* Light Sensitivity (Photophobia): 
Light sensitivity (photophobia) is defined as feeling discomfort or
the inability to keep eyes open normally when the eyes are exposed to
bright lights.
* Watery Eyes: 
Watery eyes are characterised by the increased production of tears in
response to dryness, injuries and infections.
* Itchy Eyes: 
Itchy eyes are a symptom of keratoconjunctivitis that arises during an
allergic reaction and infections.
* Redness in the eyes: 
Redness in the eyes occurs when the small vessels under the surface of
the eyes become larger in response to inflammation.
### 1. Eye Discharge
Eye discharge is a typical
symptom of keratoconjunctivitis as a result of injuries,
infections, dryness and allergies. Eye discharge is characterised as a clear, grey or yellowish,
mucus-like fluid that can be found in the eyes. Eye discharge can
typically develop when inflammation arises in the eye causing the eyes
to create more mucus resulting in eye discharge as the eye’s attempt
to remove irritants or debris.
### 2. Feeling something in your eye
Feeling something in your eye can be another
common attribute of keratoconjunctivitis due to inflammation
symptoms. It can easily feel like something is in your eye due to increased
sensitivity and irritation of the eye's surface. The inflammatory
response can also affect certain nerves of the eye, making the eye
more sensitive to discomfort.
### 3. Swollen Eyelids (Blepharitis)
Swollen eyelids (blepharitis) are
a symptom of keratoconjunctivitis that is characterised by the
increased and puffy appearance of the eyelids and slight redness.
Swollen eyelids or
[blepharitis](https://www.oscarwylee.com.au/glasses/eye/eyelids-inflammation)
can occur during inflammation, triggering more white blood cells and fluids to flow towards the
affected or injured area. This is part of the body’s healing process
and is what contributes to the swollen and slightly red appearance of
the eyelids according to the National Institutes of Health.
### 4. Burning in the eye
Burning in the eye can feel similar to
a stinging sensation and generally occurs when the eyes are dry or
irritated. The burning feeling in the eyes can take place during
keratoconjunctivitis as the tissues of the eye increase in sensitivity
and typically occurs along with other common inflammation symptoms.
### 5. Light Sensitivity (Photophobia)
Light sensitivity (photophobia)
can arise during keratoconjunctivitis as the eyes are more
susceptible to discomfort. The eyes can become more sensitive when exposed to stimuli such as
bright lights according to the National Institutes of Health.
[Light sensitivity](https://www.oscarwylee.com.au/glasses/eye/light-sensitivity)
may be alleviated when the initial cause is addressed, however, it may
be helpful to wear sunglasses or avoid the use of bright artificial
light.
### 6. Watery Eyes
Watery eyes are
a common symptom of keratoconjunctivitis and can occur from
dryness, infections and injuries.
[Watery eyes](https://www.oscarwylee.com.au/glasses/eye/watery)
develop during keratoconjunctivitis as a way for the eye to eliminate
whatever may be causing the issue in the eye. It is also how the eye
maintains optimal moisture for comfort and health.
### 7. Itchy Eyes
Itchy eyes
may come about when experiencing keratoconjunctivitis as a result
of allergies and infections. The itchy sensation occurs when the body releases histamine, a
chemical that produces allergic reaction symptoms. Infections may also
lead to
[itchy eyes](https://www.oscarwylee.com.au/glasses/eye/watery)
poor also as part of the body’s immune response to bacteria and
viruses getting into the eye according to Science Direct.
### 8. Redness in the eyes
Redness in the eyes may develop when experiencing keratoconjunctivitis
as a result of the inflammation.
[Redness in the eyes](https://www.oscarwylee.com.au/glasses/eye/red-or-bloodshot)
can develop due to the dilation of small blood vessels that are in the
white of the eye which causes the red appearance of the eyes. When the
eyes are injured, the eyes can become dilated, bringing the blood
cells to the affected area to repair and heal the injury.
Find your nearest Oscar Wylee store
Come in to see our knowledgeable team and browse our range of frames.
[Book an eye test](https://www.oscarwylee.com.au/booking)
## What are the Causes of Keratoconjunctivitis?
The causes of keratoconjunctivitis are
autoimmune disorders, bacteria, viruses, allergens and pollutants. The causes of keratoconjunctivitis are listed below.
* Autoimmune Disorders:  Autoimmune
disorders cause a patient’s immune system to attack the body and may
be a cause of keratoconjunctivitis.
* Bacteria: 
Bacteria can be a common cause of keratoconjunctivitis as certain
types of bacteria can contaminate the cornea and conjunctiva.
* Viruses: 
Viruses such as adenovirus can remain on surfaces for up to 30 days
making it easy to come into contact with and contract
keratoconjunctivitis.
* Allergens: 
Allergens may cause keratoconjunctivitis for individuals who may be
allergic to certain substances such as pollen, mould, dust and animal
dander.
* Pollutants: 
Pollutants can get into the eye and cause injury or irritation, which
can result in keratoconjunctivitis depending on the type of pollutant.
### 1. Autoimmune Disorders
Autoimmune disorders can be
a possible risk factor for developing keratoconjunctivitis due to
their compromised or poor immune systems. Autoimmune disorders refer to when a patient’s immune system
attacks their own body as it fails to distinguish between healthy
tissues and potentially harmful substances. This leads to the body
initiating a reaction that harms normal tissues according to
MedlinePlus.
### 2. Bacteria
Bacteria is one of the most common causes of keratoconjunctivitis
as bacteria can easily get into the eye causing contamination.
Bacteria can develop as a result of poor hygiene or touching your eyes
after touching contaminated surfaces and is typically common in
children according to the Cleveland Clinic.
### 3. Viruses
Viruses are also a very
common cause in developing keratoconjunctivitis as they are highly
contagious and easy to come into contact with, from an infected individual. This may occur by touching their eye
discharge or tears from contaminated surfaces or their hands and then
touching your eyes.
### 4. Allergens
Allergens are a typical cause of keratoconjunctivitis as
pollen, mould, dust and pet dander can trigger the body’s
inflammation system. Individuals with allergies may have a higher chance at developing
keratoconjunctivitis than those who do not have existing allergies to
those substances. Keratoconjunctivitis that is caused by allergens may
be alleviated with antihistamine eye drops prescribed by an
optometrist.
### 5. Pollutants
Pollutants can likely contribute as
a risk factor for keratoconjunctivitis as they can irritate or burn
the surface of the eye. Pollutants in the air can include particulate matter, nitrogen
oxides and carbon dioxides according to the National Library of
medicine. The effects of particulate matter, nitrogen oxides and
carbon oxides are found to irritate the eyes and least to inflammation
according to a 2022 study on The Adverse Effects of Air Pollution on
the Eye: A Review.
## How is Keratoconjunctivitis Diagnosed?
Keratoconjunctivitis is diagnosed
through an eye test with an optometrist. The optometrist may ask
about your medical history and assess the symptoms you are experiencing.
As part of the standard eye test, a visual acuity test is carried out to
check your vision and a slit-lamp examination to evaluate if there is
inflammation in the cornea and conjunctiva.
### What are the Eye Tests For Keratoconjunctivitis?
A normal eye test will be carried out for keratoconjunctivitis and
will therefore include a
visual acuity test and a slit-lamp examination. It is important
to have an
[eye test for keratoconjunctivitis](https://www.oscarwylee.com.au/eye-care/eye-test)
with an optometrist first as they can refer you to a specialist if
necessary. Other eye tests that may be required to diagnose your
condition include a
lacrimal function test and a cornea sensitivity test, however,
these will be conducted by an ophthalmologist. Depending on the cause
and severity of your condition, you may be directed to an
ophthalmologist for further examination. The eye tests for
keratoconjunctivitis are listed below.
* Visual Acuity Test:  A visual acuity
test can help diagnose keratoconjunctivitis and confirm how sharp
your vision is. This test will involve reading different sized
letters from a chart while standing at standard distance according
to the National Institutes of Health.
* Slit-Lamp Examination: 
A slit-lamp examination helps to assess the structures of the eye
with the use of a special magnifying microscope.
* Lacrimal Function Test: 
A lacrimal function test can assist with seeing whether the eyes
produce enough tears to maintain moisture.
* Cornea Sensitivity Test: 
A cornea sensitivity test can be used to check for
keratoconjunctivitis as it can confirm whether your normal blink
reflex has been compromised.
### How Dangerous is Keratoconjunctivitis?
Keratoconjunctivitis
may be dangerous in certain cases and when left untreated, however,
it may also not be considered dangerous depending on its initial
cause. Keratoconjunctivitis can range from mild to severe with viral and
allergic forms typically being less serious and may alleviate on their
own. However cases like bacterial keratoconjunctivitis, can lead to
complications such as corneal scarring or vision loss, if left
untreated. Chronic or severe cases may require medical treatment to
prevent prolonged discomfort or eye damage.
#### Does Keratoconjunctivitis Lead to Blindness?
Yes, keratoconjunctivitis
can lead to blindness, however, this may only occur in more
severe cases and depend on the initial cause. Certain types of keratoconjunctivitis such as vernal
keratoconjunctivitis can lead to vision loss if no treatment is
sought according to the American Academy of Paediatrics.
## What are the Treatments for Keratoconjunctivitis?
The treatment for keratoconjunctivitis may be
artificial tears, antihistamine eye drops and antibiotic eye
drops prescribed by an optometrist. However, this will depend on your
condition and the underlying cause. The treatments for
keratoconjunctivitis are listed below.
* Artificial Tear Drops:  Artificial
tear drops can help with restoring moisture or maintaining moisture in
the eyes during keratoconjunctivitis.
* Antibiotic Eye Drops: 
Antibiotic eye drops may aid with bacterial infections that can lead
to keratoconjunctivitis.
* Antihistamine Eye Drops: 
Antihistamine eye drops can alleviate allergic reaction symptoms such
as itchiness, redness and swelling.
### What Type of Eye Drops Help Treat Keratoconjunctivitis?
The type of eye drops that help treat keratoconjunctivitis can
include antibiotic eye drops, antihistamine eye drops and
artificial tears. However, these may not be able to treat all types of
keratoconjunctivitis. It is important to see your optometrist so you
can get a professional examination so they can also advise what
[type of eye drops](https://www.oscarwylee.com.au/glasses/eye/types-of-eye-drops)
to use and if any other medication is required.
### How Long Does Keratoconjunctivitis Last?
Keratoconjunctivitis can last up to two or three weeks.
However, more serious types may differ and can depend on the initial
cause. According to NSW Health, epidemic keratoconjunctivitis can last
up to two weeks or more and symptoms from vernal keratoconjunctivitis
can last between 7 and 21 days according to the National Institutes of
Health.
#### Does Keratoconjunctivitis Heal Overnight?
No, keratoconjunctivitis does not heal overnight.
Keratoconjunctivitis usually takes at least a week or more to
fully recover. According to the Cleveland Clinic, keratoconjunctivitis can be
hyperacute which means that it lasts less than 1 week, acute cases
last 3 to 4 weeks and chronic cases can last more than 4 weeks.
## How to Prevent Keratoconjunctivitis?
To prevent keratoconjunctivitis,
wash your hands regularly, take allergy medications and manage sugar
levels. It may not be easy to prevent all types of conjunctivitis as some
cases can happen from a variety of factors or unknown causes. It is
always advised to see an optometrist or your GP so you can get
professional advice. The steps to prevent keratoconjunctivitis are
listed below.
1. Wash Your Hands Regularly:  Wash your
hands regularly to avoid spreading viruses or bacteria that can result
in keratoconjunctivitis. It is important to wash your hands for at
least 20 seconds to ensure proper removal of any germs you may have
picked up from touching different surfaces according to the Centers
for Disease Control and Prevention.
2. Take Allergy Medication: 
Take allergy medication, if you do have existing allergies or you can
speak with your GP about identifying possible allergies through an
allergy test.
3. Manage Sugar Levels:: 
Manage sugar levels if you are a diabetic to help prevent fluid levels
in the eyes from increasing, which causes swelling in the eyes.
### How Can Oscar Wylee Help You Prevent Keratoconjunctivitis?
Oscar Wylee can help you prevent keratoconjunctivitis
by providing comprehensive eye tests that can assist with assessing
different parts of the eye. This will help ensure your eyes and vision are healthy. Oscar Wylee
is an optical eyewear company that offers both prescription and
non-prescription eyewear as well as primary eyecare and eye health
services.
#### What is the Difference between Keratoconjunctivitis and
Conjunctivitis?
The difference between keratoconjunctivitis and conjunctivitis
is the specific region of the eye that is inflamed.
Keratoconjunctivitis refers to the inflammation of both the cornea
and conjunctiva while conjunctivitis involves the inflammation of
just the conjunctiva.
[Conjunctivitis](https://www.oscarwylee.com.au/glasses/eye/conjunctivitis)
and keratoconjunctivitis present the same symptoms and have the same
causes, keratoconjunctivitis is simply when you have conjunctivitis
and keratitis.
#### What is the Difference Between Keratoconjunctivitis and Keratitis?
The difference between keratoconjunctivitis and keratitis
is where the inflammation occurs. Keratoconjunctivitis
affects the cornea and conjunctivitis and keratitis affects the
cornea. Keratoconjunctivitis and keratitis are not very different as
keratoconjunctivitis is when you have both
[keratitis](https://www.oscarwylee.com.au/glasses/eye/keratitis)
as well as conjunctivitis.
Have You Had a Recent Eye Test?
It is recommended to have your eyes checked at least once every two
years or as otherwise advised by an optometrist.
[Book an eye test](https://www.oscarwylee.com.au/booking)
Oscar Wylee Accepts Leading Health Funds
Visit Oscar Wylee for your eye wear needs, and your health fund may
help cover some of the cost.
[Explore health funds](https://www.oscarwylee.com.au/health-funds.html)