# Source: https://www.oscarwylee.com.au/glasses/eye/test-glossary

# Eye Checkup and Exams with Glossary Terms: What happens in an Eye Exam?
An eye checkup and exam is an important aspect of taking care of your eye
health and your overall health. It is performed by an eye care professional,
most often an optometrist, and is a check of your vision and eyes.
Eye exams and checkups are necessary as they detect eye conditions or
diseases that threaten the health of your eye and provide you with any
vision correction needed. Eye exams are used to detect serious eye diseases
such as glaucoma, cataracts, macular degeneration and diabetic retinopathy.
For many eye conditions, early detection is a key aspect of the treatment
and prevention of worsening conditions. Eye tests are most commonly
performed by optometrists, but they are also done by ophthalmologists.
Optical dispensers are trained to perform the pre-testing procedure. There
are different eye tests within an eye exam that make up the procedure such
as an eye pressure test which is conducted during pre-testing, a visual
field test or a visual acuity test.
Prioritise your eye health by booking an eye test
Our Oscar Wylee optometrists perform bulk billed eye tests for eligible
Medicare cardholders.
[Book an eye test](https://www.oscarwylee.com.au/booking)
## What Happens in an Eye Exam?
An eye exam is
a procedure, most commonly performed by an optometrist, where a
person’s eyes are checked to assess their vision. It is an important part of maintaining eye health as an eye test is
used to detect a wide range of eye diseases and vision issues. The
results of an eye test enable eye care professionals to provide tailored
advice on how to best support your visual needs, which vary with age,
lifestyle and the type of work you do.
An eye test begins with pre-testing, where an eye care professional will
test the pressure of the eye and take a picture of the back of the eye
&nbsp;(not all Oscar Wylee stores offer this machine). Afterwards, the patient will see the optometrist, who starts off the
appointment by asking for information on their medical history as well
as family medical history, why they are here, what concerns they have,
any symptoms and any existing prescriptions.
Easily book an eye test with our dedicated Oscar Wylee optometrists on
our online booking page. Using high-quality equipment, our eye tests
take approximately 20 minutes, which is quick and convenient, meaning
you can come in on your lunch break or on the weekend. The eye test
experience at Oscar Wylee is an easy and enjoyable way to look after
your eye health and with bulk billed eye tests for eligible
[Medicare](https://www.oscarwylee.com.au/eye-test/medicare)
card holders, there is no gap or out-of-pocket expenses.
## What are the Types of Eye Exams?
There are four main types of eye exams that are performed for
different purposes and are only necessary for certain people.
According to Australia’s National Health Advice Service Healthdirect,
the three main eye tests are a
refraction test, an eye muscle test and an internal and external
test. The definitions of these tests are listed below.
* Refraction test:
A refraction test checks a patient's ability to see objects
up-close and at a distance, to determine their prescription.
* Eye muscle test:
An eye muscle test checks to ensure the muscles around the eye
are working together correctly.
* Internal and external test:
An internal and external eye test looks at the inside and outside
of the eyes for any issues.
### What is a Glaucoma Test for Eye Health?
A
[Glaucoma test](https://www.oscarwylee.com.au/glasses/eye/glaucoma)
for eye health is used to
examine the eye for a condition known as glaucoma. Glaucoma is tested using many different procedures, although
the most common is an eye pressure test which is performed
during pre-testing. Glaucoma occurs due to a buildup of intraocular pressure and
causes deterioration of the optic nerve. It begins as a loss of
peripheral vision until it devolves into complete vision loss.
An optometrist may perform three tests to assess for glaucoma.
The first is an eye pressure test which is a screening tool
performed during pre-testing with an NCT (non-contact
tonometer). Contact tonometry is also used to diagnose
glaucoma. The next is an eye health check which includes an assessment of
your optic nerve. The third test for glaucoma is a visual field
test, where a person’s vision is mapped with a visual field
machine, checking peripheral vision.
### What Does Ophthalmic Test Mean?
An ophthalmic test is
a series of comprehensive tests performed to check the health of
your eye and vision. Ophthalmology exams are performed by either an ophthalmologist or
an optometrist.
### What is the Average Duration for an Eye Exam?
The average duration of an eye exam depends on many factors such as
the tests performed or the specific patient and their needs. For
example, if a person has more serious eye conditions, an eye test
could take up to an hour but for a standard eye test, it is usually 20
to 30 minutes.
At Oscar Wylee, our eye test appointments are
approximately 20 minutes, meaning they are quick and
convenient.
## How Often Should I Get My Eyes Checked?
At Oscar Wylee,
we recommend that everyone should have an eye test with an
optometrist at least once every 2 years. If you are over the age of 65, then an annual eye test is suggested.
This frequency of eye tests depends on your health, age and if you have
a risk of certain eye conditions. There are certain factors that require
you to have more frequent eye tests.
Medical conditions: If you have medical conditions such as high
blood pressure and diabetes, you may require more frequent eye tests as
they may affect your vision.
Diagnosed eye conditions: For people with existing eye conditions
such as glaucoma or retinal detachment, your eye care professional may
recommend you come in for regular eye tests.
Age: The recommended frequency of eye tests changes depending on
age. For example, if you are older you are more likely to develop
certain eye conditions leading to more frequent eye tests.
## What are the Procedures in an Eye Exam?
There are many different procedures that make up an eye exam, some
common and some that are only performed for a patient with specific eye
care needs. The procedures performed in an eye exam and their
definitions are listed below.
1. Visual Acuity Exam for Eyes:  A visual
acuity test measures the sharpness and clarity of your vision.
2. Visual Field Test for Eyes: A visual
field test is conducted to check your visual field which includes the
sides of your vision.
3. Pupillary Reactions for Eyes:
Pupillary reaction tests assess optic nerve function using the
pupil’s light reflex.
4. Cover Test for Eyes:
A cover test is used to determine misalignment in eyes and
performed by an optometrist or ophthalmologist.
5. Retinoscopy for Eyes:  A retinoscopy
measures the refractive error in a patient's eye to determine their
prescription.
6. Refraction for Eye Tests: A refraction
test assesses a patient's ability to see at near and far distances.
7. Slit Lamp Exam for Eyes: A slit lamp
microscopically examines the eyes for problems or abnormalities.
8. Pachymetry Tests for Eye: A pachymetry
test measures the thickness of the cornea.
9. External Exam for Eyes: An external
exam inspects the alignment and position of the eyes as well as the
pupils and extraocular movements.
10. Retinal Examination for Eyes: A
retinal exam, often known as funduscopy, evaluates the back of the eye
including the retina.
11. Eye Dilation Exams for Eyes:  An eye
dilation exam checks for various eye conditions such as glaucoma and
diabetic retinopathy.
### 1. Visual Acuity Exam for Eyes
A visual acuity test is used to measure the sharpness and clarity of a
person’s vision and how well they see at a distance. A
[visual acuity test](https://www.oscarwylee.com.au/glasses/eye/test/visual-acuity)
involves a patient sitting across from a Snellen eye testing chart
or a LogMAR chart set at 6
metres away. The optometrist instructs the patient to cover one eye
and read letters that get progressively smaller until they are unable
to read the letters clearly. This process is then repeated with the
other eye covered. The further down the chart a patient sees, the
better the visual acuity is. The lowest line they are able to read to
is expressed as a fraction and is then used to describe visual acuity.
Visual acuity is an important part of determining the clarity of your
vision but it is only one aspect of a comprehensive eye exam.
### 2. Visual Field Test for Eyes
A Visual Field Test (VFT) for eyes is used to quantify how well a
person sees through each eye individually
and binocularly. It maps a
patient’s visual scope and peripheral vision and helps identify vision
loss and associated eye conditions. This test helps the optometrist
establish a baseline and diagnose ocular injuries or diseases,
including glaucoma.
A visual
[visual field test](https://www.oscarwylee.com.au/visual_field.html)
frame varies on the model of the machine and the test that is being
done, from 10-40 minutes. The test involves identifying lights or
objects that appear on the sides of your vision; this could be through
a machine or performed by an optometrist or a trained team member. For
this test, a patient is positioned on the machine with one eye
covered. Fixating on the central light in the machine, the patient
presses their response button each time they see a light pop up, using
their peripheral vision. The lights vary in position, speed and
brightness. The results are printed as a map and interpreted by the
optometrist.
### 3. Pupillary Reactions for Eyes
Pupillary reactions for eyes, refers to how the pupil of the eye
responds to light stimuli. The pupillary light reflex is an important
part of eye health as it is used to assess
optic nerve function. In a 2022
article in the National Library of Medicine, the function of a
pupillary light reflex test is described to evaluate and manage
abnormal pupillary light reflexes. This test is conducted using a
penlight where the eye care professional will shine the light into one
eye and then withdraw it for a few seconds and observe the pupils’
reactions.
### 4. Cover Test for Eyes
A cover test for eyes is used to determine the magnitude and type of
ocular misalignment, also known as strabismus. According to the
American Academy of Ophthalmology, a cover test is typically performed
by optometrists and ophthalmologists
using a sheer or opaque occluder that covers one eye. The patient
fixates on a target and the eye care professional observes the shift
in fixation in the non-occluded eye.
### 5. Retinoscopy for Eyes
Retinoscopy for the eyes refers to a testing technique that measures
the refractive error in an eye. A refractive error occurs when the
light entering the eye does not properly hit the retina. This could
mean light hits before the retina, or behind the retina, resulting in
vision issues. A retinoscopy helps to identify and determine the
degree of the refractive error.
Optometrists use a retinoscope, a handheld tool that they look
through, in conjunction with the retinoscopy technique, to determine a
refractive error. According to the American Academy for Paediatric
Ophthalmology and Strabismus, the retinoscope has a beam of light that
shines from it, that your optometrist will direct onto the eye. The
optometrist uses the retinoscopy technique to assess how this light
bounces off the retina and determines the refraction issue.
### 6. Refraction for Eye Tests
A refraction test for the eyes is performed by an eye care
professional to determine the necessary correction for a refractive
error, according to the non-profit organisation, My Vision. A
refractive error is a category of visual issue that affects a
patient’s ability to see clearly. Refractive errors include
myopia, hyperopia and astigmatism. The most common tests for eye refraction are retinoscopy,
autorefraction and phoropter refraction.
Retinoscopy: Using a retinoscope, the optometrist will move the
light across both eyes to determine how the light reflects off the
retina.
Autorefraction:  This test involves an autorefractor to measure
refraction, which is a computer-controlled machine.
Phoropter refraction: Uses a phoropter to measure refraction
which is a device that looks like a large mask and a patient looks
through a combination of lenses.
### 7. Slit Lamp Exam for Eyes
A slit lamp exam for the eyes refers to a test in which a microscope
with a bright light is used to examine the various structures of the
eyes such as the cornea, the lens, the optic nerve and the retina.
Your eyes may be dilated for this procedure. According to the American
Academy of Ophthalmology, a slit lamp test is used to observe parts of
the eyes for abnormalities and eye diseases such as glaucoma, macular
degeneration and cataracts.
To conduct a slit lamp test, an optometrist will position the
patient’s chin in a chin rest connected to the microscope and the
forehead rests on a band, also connected to the microscope. The
optometrist then uses the beam of light from the microscope to inspect
the eye.
### 8. Pachymetry Tests for Eye
A pachymetry test for the eyes is used to measure the thickness of the
cornea. It is an important aspect of eye health as it can detect if a
patient’s cornea is swollen, which can be caused by certain eye
conditions or even by wearing contact lenses. A pachymetry test is
performed in two ways, using an ultrasound or an optical pachymeter.
### 9. External Exam for Eyes
An external exam for eyes is defined by Frank C. Bell in a paper
published in the National Library of Medicine, as an external eye
examination involving the external eye structures including the
eyelids and surrounding tissues, the cornea, conjunctiva, anterior
chamber and the lacrimal apparatus. The purpose of an external eye
exam is to gain information about the patient that could help diagnose
certain eye conditions or diseases.
A pocket flashlight or more commonly a slit lamp
is used in an external eye exam to inspect areas of the eye such as
the cornea and the anterior chamber.
### 10. Retinal Examination for Eyes
A retinal examination for the eyes, also known as a funduscopy, allows
an eye care professional to evaluate the back of a person’s eye.
This includes looking at the retina and optic disc. A
[retinal exam](https://www.oscarwylee.com.au/glasses/eye/retinal-exam)
often involves a person’s pupils being dilated for better
visualisation for the optometrist and using an ophthalmoscope which
shines a beam of light into the pupil in order to examine the back
of the eye.
### 11. Eye Dilation Exams for Eyes
An eye dilation exam for eyes, refers to a procedure in which an
optometrist dilates your eye to get a better view of its inner
structures. This exam helps an optometrist to get a more in-depth
picture of your eye health, beyond a standard eye exam. The exam is
used to help check for eye conditions such as glaucoma, macular
degeneration and diabetic retinopathy.
An optometrist conducts an
[eye dilation exam](https://www.oscarwylee.com.au/glasses/eye/dilated-pupil-exam)
by administering eye drops. These eye drops will dilate, or widen,
your pupil so the optometrist can see the inner structures of the eye
more clearly.
Once the pupil is dilated, the optometrist may complete more eye
tests such as visual acuity testing.
Find an Oscar Wylee store near you
Our friendly team can help you shop our range of stylish and
affordable frames. All major health funds accepted in
store.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
## What You Need to Know About Eye Anatomy to Understand Eye Exams and
Checkups?
It is important to know about eye anatomy in order to
understand eye exams and checkups. The eye (oculus–Latin term for eye), approximately 2.5 centimetres in diameter, is one of the most
important organs in the body. It processes the light that is
reflected off surfaces into electrical signals creating the images
we see, allowing people to interpret shapes, faces, colours and
depth. The eye rests in a socket in the skull and is surrounded by 6
motion-regulating muscles and many layers of fatty tissue for
protection and flexibility. There are many different parts of
[eye anatomy](https://www.oscarwylee.com.au/glasses/eye/anatomy)
and various procedures, surgeries and treatments to address eye
conditions and diseases.
An eye exam tests the function of your vision and assesses for any
eye conditions or diseases using various tools such as a slit lamp
or a DRS machine (digital retinal scanning).
### 1. Applanation Tonometry
Applanation tonometry is a procedure that tests the pressure in a
person's eye. Eye pressure is an important aspect of your eye health
as high eye pressure may potentially damage your optic nerve and cause
glaucoma. For this exam, eyes are numbed using drops with dye in them
and the patient’s head is positioned on a slit lamp, a diagnostic tool
used in ocular examinations. The eye pressure is measured using a
small tip that gently touches the eye's surface.
### 2. Achromatopsia
Achromatopsia is an eye condition that causes complete or partial
absence of colour in a person’s vision meaning they only perceive
white, black and shades of grey, no colour. According to the National
Library of Medicine, someone with achromatopsia may have a sensitivity
to glare and light, and have a significantly diminished sharpness of
vision.
Achromatopsia is different from colour blindness as a person who is
colour blind is able to perceive colour but has trouble telling the
difference between certain colours.
### 3. Aqueous humour
Aqueous humour is a part of the eye anatomy and is located in the
anterior and posterior chambers of the eye. It is a transparent, thin
fluid that is made up of almost completely water with a small number
of proteins and other nutrients.
The aqueous humour’s main function is to supply nutrients to the
lens and cornea.
### 4. Choroid
The choroid is a tissue layer that sits in between the sclera and the
retina. According to the National Cancer Institute, it provides oxygen
and nourishment to the outer layers of the retina and maintains the
volume and temperature of the eye. The
[choroid](https://www.oscarwylee.com.au/glasses/eye/choroid)
functions to shield the eye from harmful reflection and light. If the
choroid is damaged, the retina may bleed and the damage eventually
results in the loss of peripheral vision.
### 5. Choroiditis
Choroiditis, also known as Serpiginous Choroiditis, is a rare eye
disorder that causes recurrent lesions that affect two layers of the
eye, the retinal pigment epithelium and the choriocapillaris. There
are commonly no symptoms of this eye disorder unless the macula is
damaged. Choroiditis most often affects both eyes and the cause of
this eye disorder is unknown.
### 6. Conjunctiva
The conjunctiva is part of the eye anatomy and is a protective, clear
membrane that covers the inside of a person's eyelid as well as the
sclera. Its purpose is to secrete fluids that keep the eyes lubricated
and protected from infections and outside bacteria and bodies, such as
dust. The
[conjunctiva](https://www.oscarwylee.com.au/glasses/eye/anatomy/conjunctiva)
is defined by Mayo Clinic as creating the mucus layer that forms part
of a person’s tears. The conjunctiva can be affected by eye disorders
such as conjunctivitis, also known as pink eye, and a subconjunctival
haemorrhage.
The conjunctiva comprises three aspects, the bulbar conjunctiva, the
palpebral conjunctiva and the fornix conjunctiva. These three layers
ensure that no foreign bodies or objects travel behind the eye.
### 7. Conjunctivitis (Pink Eye)
Conjunctivitis, also known as pink eye, is an inflammation of the
conjunctiva, a lining covering the white part of the eye and
underneath the eyelids. The small blood vessels within the conjunctiva
dilate and cause the eye to take on a pinkish-red colour (that is
where the term “pink eye” comes from).
The most common causes of
[conjunctivitis](https://www.oscarwylee.com.au/glasses/eye/conjunctivitis)
are allergies, bacterial infections, viral infections and contact lens
wear. Besides pink eye, there are other associated conjunctivitis
symptoms such as watery eyes, crusting in the corners of the eyes,
white, yellow or stringy discharge and itchy, irritated, sore, and
gritty feeling in the eyes.
### 8. Cornea
The cornea is the clear front surface of the eye, acting like a
transparent window according to the National Cancer Institute. The
cornea has a refractive index and it covers the pupil and the iris,
allowing light to enter the eye. The cornea functions by bending and
refracting light that the eye receives which is achieved by the
pupil changing size, becoming
smaller or larger, depending on the volume of light. The
[cornea](https://www.oscarwylee.com.au/glasses/eye/cornea)
protects the eye by filtering out harmful glare from the eye, such as
ultraviolet rays from the sun. The cornea does not contain blood
vessels, rather it is composed of proteins and cells, this means it
receives its nutrients from tears and the aqueous humour, which is a
fluid similar to plasma.
9. Cryotherapy
Cryotherapy is a treatment that involves applying extreme cold to freeze abnormal tissue. It is performed using argon gas or liquid nitrogen. According to the Cleveland Clinic, cryotherapy is used to treat a number of different eye conditions such as retinoblastoma, which is cancer of the retina in children. It is used to treat tumours, retinal tears, small retinal detachments and vascular lesions. Cryotherapy is considered to be a less invasive procedure as it is applied with a probe and does not require any incisions, unlike other eye surgeries.

### 9. Cyclitis
Cyclitis is a type of uveitis, which is an inflammation of the tissue
within the eyeball. Cyclitis is a type of anterior uveitis and causes
inflammation to occur in the muscles that operate the lens.
### 10. Dilation
Dilation occurs when the pupil, which is the black centre of the iris,
is enlarged. Pupils change their width depending on the eye’s exposure
to light, for example when they are exposed to bright light the pupil
will constrict. When a person is in a dark room, the pupils enlarge,
which allows them to see in low lighting.
### 11. Dilated Pupillary Exam
A dilated pupillary exam is performed on patients to check their
eye health as it can detect certain eye diseases. This painless
and simple exam involves an eye care professional administering
eye drops to dilate the pupil in order to check for eye diseases.
According to the National Eye Institute, a
[dilated pupillary exam](https://www.oscarwylee.com.au/glasses/eye/dilated-pupil-exam)
checks for diseases such as glaucoma, age-related macular
degeneration and diabetic retinopathy.
### 12. Fluorescein Angiography
Fluorescein angiography is a procedure in which an ophthalmologist
uses a special camera to take images of the retina. These images allow
the eye doctor to view the blood vessels and other aspects that exist
in the back of the eye.
The American Academy of Ophthalmology reports that
[fluorescein angiography](https://www.oscarwylee.com.au/glasses/eye/flourescein-angiography)
is used to detect and diagnose eye conditions and diseases such as
macular degeneration, macular edema, diabetic retinopathy and ocular
melanoma.
14. Enucleation
Enucleation is described by the American Academy of Ophthalmology as a surgical procedure that removes the entire eye globe as well as its intraocular contents while preserving the other periorbital and orbital structures. An enucleation procedure may be undergone if a person’s eye has had trauma without visual potential, if they are blind with a painful eye, or if they have a severe infection without visual potential.

### 13. Hyperopia
Hyperopia, also known as farsightedness, is a refractive error in
which images are focused behind the retina rather than on it, making
it hard to see objects at a near distance. Some people with
[hyperopia](https://www.oscarwylee.com.au/glasses/eye/hyperopia)
may struggle with both long and short distances.
Hyperopia is corrected with a converging or plus power lens. Common
causes of hyperopia include a decrease in refractive index (cortical
cataracts), the eye is shorter than normal and the cornea is flatter
than normal. Hyperopia is different from presbyopia because with
presbyopia, the trouble with near vision is due to the decreased lens
flexibility that comes with age.
### 14. Intraocular
Intraocular is a term that refers to anything occurring, implanted or
administered by entering the eyeball. It is often associated with
intraocular pressure which refers to the fluid pressure of the eye.
### 15. Iris
The iris is a part of the eye anatomy and makes up the coloured
portion of the eye. It contains muscles that contract to adjust pupil
size depending on light conditions. The
[iris](https://www.oscarwylee.com.au/glasses/eye/anatomy/iris)
is constantly changing its dilation due to how much or little light
there is which allows the eye to see clearly. The iris is as unique as
a fingerprint, meaning no two people have the same eye colour.
### 16. Low Vision
Low vision is an eye problem that affects your ability to do
everyday activities like reading and driving. Low vision is caused
by various eye conditions such as cataracts and age-related
macular degeneration and cannot be corrected with glasses.
According to the National Eye Institute, there are four main types
of low vision. These include blurry or hazy vision, central vision
loss, peripheral vision loss and night blindness.
### 17. Macula
The macula is the part of the eye anatomy that processes what you
see in your central vision, that which is directly in front of you.
It is found at the back of the eyeball. The
[macula](https://www.oscarwylee.com.au/glasses/eye/anatomy/macula)
functions to help a person understand specific details and parts of
images such as colour, and text on a page and discern the difference
between faces.
### 18. Macular Oedema
Macular edema occurs when there is swelling in the part of the
retina which causes blurry or wavy vision as well as dull colour
vision. According to the National Eye Institute, the most common
cause of macular edema includes diabetic retinopathy. Other causes
include uveitis and age-related macular degeneration.
### 19. Myopia
Myopia, also known as nearsightedness, is a refractive error that
occurs when light focuses before the retina rather than on it due to
curvature (increased corneal curve) or axial (increased eyeball
length). It causes patients to have difficulty seeing distant
objects clearly. Treatment may include glasses, contact lenses,
laser or IOL surgery. A minus-power lens is prescribed to bring the
light back to focus on the retina.
[Myopia](https://www.oscarwylee.com.au/glasses/eye/nearsightedness)
is one of the most prevalent eye conditions on the planet. It is
estimated that by 2050, nearly 5 billion people will be affected by
myopia, according to a 2016 study by the American Academy of
Ophthalmology.
### 20. Nyctalopia (night blindness)
Nyctalopia is a term that refers to a person who has difficulty
seeing in dim light or at night. People with nyctalopia will usually
find their daytime vision is unaffected, according to an article
published in the National Library of Medicine, by Divy Mehra and
Patrick H. Le.
[Night blindness](https://www.oscarwylee.com.au/glasses/eye/night-blindness)
is caused by the eye’s inability to respond quickly from lightness
to darkness.
### 21. Non-Contact Tonometry
Non-contact tonometry (NCT), also known as air puff
[tonometry](https://www.oscarwylee.com.au/glasses/eye/tonometry-test), uses a rapid air pulse that flattens your cornea. The period when
your eye becomes flat, is how the pressure is measured, which is
derived from the monitored reflection of an incident infrared light.
The NCT method tests your intraocular eye pressure which is the
internal pressure of the eye. It is part of the pre-testing routine
and can be built into an autorefractor.
### 22. Ocular
Ocular refers to anything that is perceived or done by the eye or
relates to the eye in any way.
### 23. Ophthalmologist
An
[ophthalmologist](https://www.oscarwylee.com.au/eye-care/optometrist/ophthalmologist.html)
is a medical doctor that specialises in eye care and provides
advanced visual care that your optometrist cannot. This includes
assessing and managing serious eye conditions like advanced glaucoma
and performing surgeries.
As medical doctors that are specially trained in eye health,
ophthalmologists are qualified to carry out a variety of eye care
services such as the treatment and management of complex eye
diseases and performing eye surgery. Ophthalmologists receive
patients from referrals, either by a General Practitioner or from
optometrists who have noticed serious eye conditions beyond their
expertise. Ophthalmologists then assess the patient and create
treatment plans for their eye or vision problems.
### 24. Ophthalmoscope
An ophthalmoscope is a tool used by eye care professionals that
allows them to look at the back of the eye. An ophthalmoscope uses a
beam of light to assess the health of the optic nerve, retina,
vitreous humour and vasculature.
### 25. Optic Nerve
The optic nerve transmits all visual information from the retina to
the brain, to process the sensory information so that a person can
see. The
[optic nerve](https://www.oscarwylee.com.au/glasses/eye/anatomy/optic-nerve)
is an extension of your central nervous system along with the brain
and the spine.
### 26. Optometrist
An optometrist is the most common type of eye care professional
and the one you are most likely to encounter when having an eye
exam. They are eye care professionals who have completed a
university degree in optometry. Optometrists provide comprehensive
eye exams which address both visual concerns relating to
prescription errors as well as ocular surface diseases. Your
[optometrist](https://www.oscarwylee.com.au/eye-care/optometrist)
is your first point of contact in your eye health journey.
Most optometrists in Australia provide services such as complete
eye exams, identification and management of vision problems and
eye infections, prescription of eyeglasses, diagnosis and
treatment of eye disorders, providing advice on eye care and
referring patients to ophthalmologists as needed.
### 27. Peripheral Vision
Peripheral vision is the part of your sight at the sides of the
visual field, as opposed to what you are able to see straight in
front of you. Your peripheral vision is tested in a visual field
test and used to detect eye conditions such as glaucoma.
### 28. Photocoagulation
Laser photocoagulation is a type of laser surgery performed on the
eyes to treat age-related macular degeneration, an eye disease that
can result in vision loss. The surgery involves the doctor using a
laser to burn away abnormal structures in the retina or to
deliberately scar the eye.
### 29. Presbyopia
Presbyopia is the inability to see objects at close distances.
The refractive error
[presbyopia](https://www.oscarwylee.com.au/glasses/eye/presbyopia)
occurs naturally with age as the protein composition of the
crystalline lens changes, reducing its flexibility. Light focuses
behind the retina meaning things need to be further away to see.
Presbyopia is corrected with an ADD power in reading glasses or
multifocals glasses.
### 30. Pupil
The pupil is the centre of the iris where light enters. It works
like a camera aperture, if the light is bright, the
[pupil](https://www.oscarwylee.com.au/glasses/eye/anatomy/pupil)
is smaller, and if it is darker, the pupil is dilated.
### 31. Refraction
Refraction is described as the bending of light rays as they pass
from one object to another, according to The National Eye Institute.
In the eye, refraction occurs as the lens and cornea bend the light
to focus them on the retina.
### 32. Refractive Error
A refractive error is a type of vision issue that affects a person’s
ability to see clearly. They are the most common type of vision
problem and occur when the shape of the eye stops light from
focusing correctly on the retina.
There are four different types of
[refractive errors](https://www.oscarwylee.com.au/glasses/eye/refractive-errors)
defined by the National Eye Institute.
Farsightedness: Also known as hyperopia, farsightedness
causes near objects to appear blurry.
Nearsightedness: Also known as myopia, nearsightedness makes
distant objects look blurry.
Presbyopia: Presbyopia is an age-related eye condition that
makes it difficult for older people to see things close up.
Astigmatism: Astigmatism makes both far-away and nearby
objects appear distorted or blurry.
### 33. Retina
The retina is a fine layer of nerve cells at the back of the eye,
responsible for analysing colour, intensity and form, like the film
in a camera. The
[retina](https://www.oscarwylee.com.au/glasses/eye/anatomy/retina)
receives visual information through millions of light-sensitive
cells and sends it to your brain via the optic nerve, allowing you
to see.
### 34. Retinal Tomography
Retinal tomography is used to precisely observe and document the
optic nerve head. This diagnostic procedure is essential in managing
and diagnosing glaucoma. According to the University of British
Columbia, the procedure involves taking images of the optic nerve
and surrounding retina to create a 3D image of the optic nerve.
### 35. Retinitis Pigmentosa
Retinitis pigmentosa (RP) is the name for a group of rare eye
diseases affecting the retina by causing cells to slowly break down
over time which leads to vision loss. According to the National Eye
Institute,
[retinitis pigmentosa](https://www.oscarwylee.com.au/glasses/eye/retinitis-pigmentosa)
is a genetic disease that people are born with and there is no cure,
however, vision rehabilitation programs are available.
Although there are certain Australian institutes researching gene
therapy as a cure for retinitis pigmentosa
The symptoms of RP are loss of peripheral vision, difficulty
adjusting to dim lighting, tunnel vision, loss of colour vision and
sensitivity to light.
38. Retinoblastoma
Retinoblastoma is an eye cancer of the retina and most commonly affects young children. It is a rare form of cancer that can occur in one or both eyes. The symptoms of retinoblastoma may include poor vision, swelling of the eye and redness in the eye.

### 36. Sclera
The sclera is the white part of the eye. The
[sclera](https://www.oscarwylee.com.au/glasses/eye/anatomy/sclera)
is described as an opaque, fibrous, protective outer layer of the
eye and contains collagen and elastic fibre.
### 37. Strabismus
Strabismus also known as eye misalignment, is a muscle imbalance
that causes double vision, unstable images, eye strain and fatigue,
as well as reduced depth perception and 3D vision.
[Strabismus](https://www.oscarwylee.com.au/glasses/eye/crossed-definition)
occurs when the eyes struggle to work together and converge images.
A person with strabismus will have eyes that have a turn.
### 38. Tunnel vision
Tunnel vision, also known as peripheral vision loss, occurs when a
person loses their peripheral sight (side vision). Tunnel vision
means a person is still able to see clearly out the front of their
vision but may have gaps or holes out the sides of their visual
field.
### 39. Ultrasound
An ultrasound is used to assess the structural integrity of the eye
and also diagnose conditions such as tumours and retinal detachment.
An ultrasound works by reflecting sound waves to create an image
that provides information that cannot be obtained by direct
visualisation.
### 40. Visual Acuity
Visual acuity is defined as a person’s ability to see at a distance,
measuring the sharpness and clarity of their vision. It is tested
during a routine eye exam by an optometrist using a Snellen Chart,
testing one eye at a time. Your
[visual acuity](https://www.oscarwylee.com.au/glasses/eye/test/visual-acuity)
is important as it is a consistent way for an eye health
professional to detect changes in your vision.
Visual acuity is denoted using fractions. The normal measure of
visual acuity is 20/20 vision, or 6/6 when using the metric system.
If a person has 20/20 vision, it means they see objects clearly from
20 feet away.
### 41. Visual Field
Visual field describes the total area in which objects can be seen
in the sides (periphery) of their vision when they focus on a
central point. A
[visual field](https://www.oscarwylee.com.au/visual_field.html)
test is conducted by an eye health professional to measure the
amount of vision a patient has in each eye.
Certain medical conditions can cause people to experience loss of
their peripheral vision such as diabetes and high blood pressure,
this is why visual field testing is important as it monitors the
effect of these medical conditions on a person’s vision.
### 42. Vitrectomy
A vitrectomy is a type of eye surgery performed by an
ophthalmologist to treat different problems with the vitreous and
retina. A Vitrectomy is conducted if a patient has eye conditions
such as a macular hole or pucker, diabetic retinopathy, a severe eye
injury or an infection in the eye.
The surgery involves the ophthalmologist making a small incision in
the sclera, the white of the eye. The doctor may do one or more of
the following steps: remove cataracts, take away scar tissue on the
retina, get rid of cloudy vitreous and remove any foreign objects
from the eye.
### 43. Vitreous humour
Vitreous humour is a clear, gelatinous mass that fills the space in
the eye between the lens and the retina. It is composed mostly of
water and functions to ensure vision clarity, maintain the shape of
the eye and absorb impact to the eye or head.
According to the Vision Eye Institute, over time,
[vitreous humour](https://www.oscarwylee.com.au/glasses/eye/vitreous-humour)
may shrink and liquefy and the collagen and protein can become
stringy which potentially causes floaters in the eye.
Need a new pair of glasses?
Shop our range of vintage and modern inspired frames.
[Shop our glasses](https://www.oscarwylee.com.au/glasses.html)
## How to Perform Eye Vision Tests at Home?
It is not recommended to perform eye vision tests at home as they are not
reliable and often provide inaccurate results. It is best to have an eye
test performed by a professional who has the knowledge, experience and
equipment to provide you with the most accurate results.
If you need an eye test of any kind, it is best to book an appointment
with an optometrist. They perform the eye vision test and interpret the
results correctly.
## Why is Understanding Eye Exams important?
It is important to understand eye exams because they are a
crucial aspect of your eye care and overall health. By
learning the different tests performed and possible eye conditions, it
allows you to know why eye exams are beneficial and should not be ignored.
## Who Can Perform Medical Eye Tests?
There are two main eye care professionals who can perform eye tests, these
include optometrists and ophthalmologists, and there are
also certain procedures an optical dispenser can conduct.
The definition of these professions and their duties are listed below.
* Optometrist: An
[optometrist](https://www.oscarwylee.com.au/eye-care/optometrist)
is the person you encounter when you book an eye test as it is one of
their main roles. They provide comprehensive eye exams which address
both visual concerns relating to prescription errors as well as ocular
surface diseases.
* Ophthalmologist:
An ophthalmologist is an eye doctor who performs surgeries and
provides specialised care for eye conditions that cannot otherwise
be managed by optometrists. You see an ophthalmologist if you have
been referred by an optometrist, General Practitioner or medical
specialist.
* Optical Dispenser:
The role of an optical dispenser is to interpret the prescriptions
given to them by the optometrist, with some performing pre-testing.
Optical dispensers take pupillary distance measurements and ensure
eyewear fits comfortably and correctly on a patient.
### What is the Cost of a Medical Eye Test?
In Australia, Medicare provides a subsidy for Australians to regularly
get their eyes tested. For eligible Medicare cardholders, people receive
a bulk billed eye test with no gap or out-of-pocket expenses. If you are
not covered under Medicare, eye tests at Oscar Wylee are $70 each.
Medicare is Australia’s healthcare system that officially started in
1984. Since then, it has provided coverage and gap payments for
Australian citizens and permanent residents for all payments going
towards health costs and medical aid. According to Services Australia,
bulk billing occurs when a healthcare specialist sends the entirety of
the bill for their Medicare-covered services to the government to be
paid in one instance.
### Are you Obligated to Buy Glasses if You Have an Eye Test?
No,
you are not obligated to buy glasses after you have had an eye
test. An eye test is a way to check your eye health and is an important
part of eye care. Your optometrist may prescribe that you wear glasses
to correct your vision although it is your decision to listen to their
advice or not.
We recommend that if you are prescribed glasses by an eye care
professional, if you are able to, you purchase these corrective devices.
Prescription glasses improve your day-to-day life and are safer,
especially for driving.
### Does Oscar Wylee Provide Free Optometrist Tests?
At Oscar Wylee,
a qualified optometrist is available in-store to conduct a bulk
billed eye test for all eligible Medicare cardholders. An
[Oscar Wylee eye test](https://www.oscarwylee.com.au/booking)
has no gap and requires no out-of-pocket expenses necessary
however certain driver's license testing and occupational testing
are not covered. Regardless of Medicare status, anyone seeking a professional eye
test is welcome at Oscar Wylee stores.
## What are the Statistics of Medical Eye Tests?
Optometry Australia reported that in 2019, Australian optometrists
performed a record of more than 10 million eye examinations under
Medicare. In 2019, Optometry Australia found that the number of registered
optometrists in Australia has exceeded 6,000.
A study conducted by the Australian Bureau of Statistics in 2017-18 found
that in Australia, over 13 million people have one or more long-term
chronic eye conditions. This includes:
* 7.2 million with hyperopia (long-sightedness)
* 6.3 million with myopia (short-sightedness)
* 1.4 million with astigmatism
* 687,000 with presbyopia (loss of focusing ability with age)
* 549,000 with colour blindness
* 411,000 with cataracts
* 244,000 with macular degeneration
* 131,000 with blindness (complete and partial)
Also, according to the Australian Government Department of Health and Aged
Care, around 90% of all vision impairment and blindness in Australia are
treatable or preventable if detected early.
Find your nearest location
Visit our friendly staff-in-store and they can assist with all your
optometry and glasses needs.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
Are you in need of an eye test?
We recommend everyone has a complete eye examination at least once
every two years. Book yours today with Oscar wylee.
[Book an eye test](https://www.oscarwylee.com.au/booking)