# Source: https://www.oscarwylee.com.au/glasses/eye/check-up

# Eye Exam: Eye Test and Other Vision Testing
Published on June 2nd, 2023
Updated on June 12th, 2025
Australia
[Australia](https://www.oscarwylee.com.au/glasses/eye/check-up)
[Canada](https://oscarwylee.ca/glasses/eye/check-up)
[Canadian French](https://oscarwylee.ca/fr/glasses/eye/check-up)
An
eye exam or eye test is performed by an optometrist or health care
professional, to assess a person’s vision and the health of their eyes. A checkup eye test is defined as a series of procedures and tests
relating to the eye and vision. A person can expect a series of eye tests
performed to assess if a person requires corrective eyewear such as
prescription glasses, or has any existing eye conditions that may need
treatment. Some of these tests include a visual acuity test, a visual field
test, a slit-lamp exam and a tonometry test. An optometrist may also refer a
patient to an ophthalmologist if they detect a condition or issue in a
checkup eye test that requires more advanced treatment from an eye doctor.
An eye doctor is a colloquial term often used globally to refer to an
optometrist. In Australia, we refer to optometrists as eye care
professionals as they are not doctors and are not qualified to operate on
patients. On the other hand, an ophthalmologist is a qualified eye doctor
who performs surgeries and often deals with more advanced and complicated
eye conditions. A person should have an eye test every 2 years if they are
under 65, every year if they are over 65, or as otherwise advised by an
optometrist. Regular eye tests are important and hugely beneficial in
maintaining eye health as they can detect a large variety of eye diseases
and vision issues. Keep reading to learn more about eye exams and other
vision testing.
When was your last eye test?
We recommend that everyone should have an eye test with an optometrist at
least once every 2 years.
[Eye test near me](https://www.oscarwylee.com.au/booking)
[Definition](#Definition) [What to Expect](#Expect)
[Importance](#Importance)
[How to Find an Optometrist](#Optometrist)
## What is an Eye Test?
An eye test or exam is a&nbsp;procedure performed by an optometrist to assess a person’s vision and
the health of their eye. An eye test is typically performed by an optometrist and is crucial
in maintaining eye health as it can detect a large variety of eye
diseases and vision issues. Some of the vision issues and eye diseases
that can be diagnosed and detected in an eye test include refractive
errors, such as myopia (nearsightedness) and hyperopia
(farsightedness), glaucoma, cataracts and macular degeneration.A person should book a regular eye test every 1-2 years to ensure
they are taking care of their eye health. An eye exam is important as
an optometrist can diagnose and treat certain eye conditions early on,
so they do not develop into a bigger problem later on. Even if you
feel your vision is clear or you are not noticing any issues, it is
still important to get your eyes tested regularly.
### How Does a Checkup Eye Test Work?
A checkup eye test works by&nbsp;assessing a patient's vision and eye health, performed by an
optometrist, in order for them to provide the proper treatment
whether that is prescribing prescription glasses, treating certain
eye conditions, or referring the patient to an
ophthalmologist&nbsp;for further or more advanced treatment. In an eye test, a
patient will go through pre-testing with an optical assistant which
will assess eye pressure. Next, the optometrist will perform further
tests, often a visual acuity test, a refraction test and a slit-lamp
test. If the patient requires corrective eyewear, the optometrist
will provide a prescription which is handed over to an optical
dispenser who can help the patient find the frames and lenses to
suit their visual and lifestyle needs.
## What to Expect During a Checkup Eye Test?
Some of the tests to expect during a checkup eye test include
a&nbsp;retinal exam,&nbsp;colour vision test, visual
field test, tonometry test, eye muscle test, refraction test, dilated
pupil exam, slit-lamp exam and OCT (optical coherence tomography) and
fundus photography test. The tests you can expect during a checkup eye test are listed
below.
* Retinal exam: A retinal exam, also
known as a fundoscopy, is performed by an eye care professional to
evaluate the back of a person’s eye. This exam often requires the
patient’s eyes to be dilated for better visualisation.
* Colour vision test:&nbsp;A colour vision test is commonly done on children and upon
indication such as occupational testing. This test is used to detect
what colours a person can see and is typically performed using a
colour plate.
* Visual field test:&nbsp;A visual field test is performed on indication only and is used to
assess a person’s visual scope and peripheral vision. It is
conducted to quantify how well a patient sees through each eye, both
individually and binocularly.
* Visual acuity test:&nbsp;A visual acuity test is performed by an
optometrist to determine the clarity and sharpness of a person’s
vision. It is typically conducted using a Snellen eye testing chart or
a LogMAR chart.
* Tonometry test:&nbsp;A tonometry test is performed during pre-testing and is used to
measure a patient’s intraocular eye pressure. A tonometry test is
often used to assess for glaucoma as this eye condition can be
associated with high eye pressure.
* Eye muscle test:&nbsp;An
eye muscle test, also known as an extraocular muscle function test,
checks to ensure the muscles around the eye are working together
correctly.
* Refraction test:&nbsp;A refraction test is used to detect refractive errors such as
nearsightedness, farsightedness and astigmatism. The types of
refraction tests include a phoropter refraction test, retinoscopy
and an autorefractor test.
* Dilated pupil exam:&nbsp;A dilated pupil exam is performed on indication and refers to a
procedure that requires an optometrist to dilate a person’s eyes in
order to have a better view of the eye’s inner structures
* Slit-lamp exam:&nbsp;A
slit-lamp exam is a test that examines the different structures of the
eye including the lens, cornea, optic nerve and retina.
* OCT (optical coherence tomography) and fundus photography
test:&nbsp;OCT and Fundus Photography are imaging tests that
allow eye care professionals to obtain detailed images of the
structures of the eye.
### 1. Retinal Exam
A retinal exam, also known as a fundoscopy and ophthalmoscopy,
is&nbsp;a diagnostic test that enables the optometrist to inspect the
retina and optic nerve located at the back of the eye. The procedure typically involves using specialised tools like an
ophthalmoscope or a slit-lamp biomicroscope to detect any
indications of eye diseases or irregularities. Eye drops may be
administered to dilate the pupils, which permits a more thorough
examination of the retina. According to the National Cancer
Institute, a retinal exam, or fundoscopy, is used to check for
macular degeneration, glaucoma, eye injuries and eye&nbsp;cancer. According to Standford University, a retinal exam is very
beneficial as it can provide important information about a medical
diagnosis such as high blood pressure and diabetes.
### 2. Colour Vision Test
A colour vision test is&nbsp;used to detect what colours a person can see. Colour blindness, more accurately known as colour vision
deficiency, is an eye condition that causes a person to have trouble
seeing specific colours, or, it may mean a person sees colours in a
different way to other people.&nbsp;[Colour vision deficiency](https://www.oscarwylee.com.au/glasses/eye/colour-vision-deficiency)&nbsp;is the more accurate term for colour blindness, which is used
more colloquially, as people who have this condition, may not be
completely blind to colour, rather they only see certain
colours.According to the National Eye Institute, to test for colour
blindness, an optometrist typically uses a colour plate test. This
test uses images made up of different coloured dots with a number in
the middle that a patient is asked to identify. There are different
colour plates made up of certain colours in order to identify
different types of colour vision deficiency.
### 3. Visual Field Test
A visual field test (VFT) is a procedure&nbsp;performed by an eye care professional to quantify how well a
patient sees through each eye, both individually and
binocularly. A&nbsp;[visual field test](https://www.oscarwylee.com.au/visual_field.html)&nbsp;aids an optometrist in establishing a baseline for a person’s
vision to diagnose eye diseases or injuries. This test works by
mapping the person’s visual scope as well as their peripheral vision
to identify if there is any vision loss.A visual field test is typically performed using a machine such as
a static automated perimetry test or frequency doubling perimetry.
The time frame for a visual field test varies depending on the test
that is being performed and the model of the machine, varying from
10-40 minutes. The test typically involves the patient identifying
objects or light that appears in their periphery (the sides of their
vision) and they are tasked with pressing a response button when
they see a light pop up. The results of a visual field test will
typically be printed as a map and interpreted by the
optometrist.
### 4. Visual Acuity Test
A visual acuity test is&nbsp;a standard component of an eye test that evaluates a person's
ability to see distant objects. The&nbsp;[visual acuity](https://www.oscarwylee.com.au/eye-care/eye-test/visual-acuity.html)&nbsp;examination involves reading letters or symbols displayed on
an eye chart, which is usually positioned 20 feet away from the
person, or 6 metres in the metric system. The eye chart is typically
a Snellen eye testing chart or a LogMAR chart which tests the
clarity and sharpness of a person’s eyesight. In case the smallest
letters on the chart are not legible, the individual may be asked to
move closer to the chart until they are able to read them.
Alternatively, the test can be conducted with a handheld or
computerised chart.The optometrist will instruct the patient to cover one eye and read
letters off the eye chart that get progressively smaller until they
are unable to read the letters clearly. This process is then
repeated with the other eye covered. The further down the chart a
patient sees, the better the visual acuity is. The outcome of the
visual acuity test is expressed as a fraction, and it helps detect
refractive errors such as nearsightedness, farsightedness, and
astigmatism. If a person is diagnosed with a refractive error, the
optometrist may recommend corrective measures like glasses to
improve vision.
### 5. Tonometry Test
A tonometry test is commonly&nbsp;performed during pre-testing and is used to measure a patient’s
intraocular eye pressure. Tonometry is a diagnostic test often used to diagnose glaucoma as
people with this condition typically have a high intraocular
pressure due to slowly draining fluid in the eye. There are multiple
types of tonometry tests used to test intraocular pressure.
Non-contact tonometry is a type of tonometry test also known as air
puff tonometry. This test uses a rapid air pulse that flattens the
cornea which is how it measures intraocular pressure. Another type
is Applanation tonometry which requires the patient's eyes to be
numb and the pressure is measured with a diagnostic tool while their
head is positioned in a slit-lamp.
### 6. Eye Muscle Test
An eye muscle test&nbsp;checks to ensure the muscles around the eye are working together
correctly. An eye muscle test is also known as an extraocular muscle
function test and is performed by an optometrist to observe if there
are any weaknesses in the muscles of the eye. According to the
National Library of Medicine, an eye muscle test involves the
patient moving the eyes in eight different directions without moving
their head. If a person has issues with eye muscles, it may result
in uncontrolled eye movements or double vision.
### 7. Refraction Test
A refraction test is&nbsp;performed by an eye care professional to determine the necessary
correction for a refractive error, according to the non-profit organisation, My Vision. A refractive
error is a type of vision issue that affects a person’s ability to
see clearly. Refractive errors include myopia, hyperopia and
astigmatism. There are three main types of refraction tests
performed by eye care professionals. A phoropter refraction test
uses a phoropter to determine the best glasses or contact lens
prescription for an individual. The person views various lenses, and
the optometrist selects the most appropriate combination of lenses.
By interpreting the results, the optometrist can prescribe the
appropriate corrective lenses to enhance vision and correct
refractive errors. Another type of refraction test is a retinoscopy
which uses a retinoscope, a handheld tool that shines a light into a
person’s eye. The optometrist will move the light across both eyes
to determine how the light reflects off the retina. The final type
of refraction test is performed using an autorefractor, which is a
computer-controlled machine that measures refraction.
### 8. Dilated Pupil Exam
A dilated pupil exam&nbsp;refers to a procedure that requires an optometrist to dilate a
person’s eyes in order to have a better view of the eye’s inner
structures. A dilated pupil exam is performed by an optometrist to help them
get an in-depth picture of their patient's eye health that goes
beyond a standard eye exam. This eye test is used to detect eye
conditions including macular degeneration, diabetic retinopathy and
glaucoma.To perform this eye exam, an optometrist will administer eye drops
in order to dilate the pupils which will widen the pupil to give the
optometrist a better look at the inner structures of the eyes.
According to the National Eye Institute, a dilated pupil exam may
include a visual field test, a visual acuity test, an eye muscle
test, a tonometry test and a pupil response test.
### 9. Slit-Lamp Exam
A slit-lamp exam is&nbsp;a test that examines the different structures of the eye including
the lens, cornea, optic nerve and retina. A slit-lamp exam is performed using a microscope with a bright
light and, according to the American Academy of Ophthalmology, is
used to produce three-dimensional measurements and visualisation of
the eye. This test may require a patient’s eyes to be dilated to
allow the eye care professional to have a better visualisation of
the eye. A slit-lamp examination is used to observe the eyes for eye
diseases and abnormalities such as cataracts, glaucoma and macular
degeneration.To perform a slit lamp exam, an eye care professional, typically an
optometrist, will position a patient’s chin on a chin rest connected
to the microscope. Their forehead will rest on a band, also
connected to the microscope, and the beam of light from the
microscope will be used to inspect the eye.
### 10. OCT (Optical Coherence Tomography) and Fundus Photography Test
OCT (Optical Coherence Tomography) and Fundus Photography
are&nbsp;imaging tests that allow eye care professionals to obtain detailed
images of the retina and optic nerve, which can help detect and monitor eye diseases and other
abnormalities. According to the American Academy of Ophthalmology,
an OCT is typically performed by an ophthalmologist and is used to
view the distinct layers of the retina. An OCT is used to guide the
treatment of certain eye conditions such as age-related macular
degeneration, diabetic eye disease and glaucoma.A fundus photography test is a non-invasive test allowing eye care
professionals to view the back of the eye which helps them to
provide accurate diagnosis for eye conditions. According to
ScienceDirect, the process of fundus imaging involves obtaining
two-dimensional images of the retina. Comparing these two imaging
techniques, an OCT produces higher-resolution images and is a more
modern technique.
#### Can you Get a Free Eye Test?
A
customer can not technically get a
[free eye test](https://www.oscarwylee.com.au/free-eye-test)
at Oscar Wylee, as they are bulk-billed under Medicare. At Oscar Wylee, eye tests may be bulk-billed by Medicare, for
eligible card holders. This means the customer does not pay any
out-of-pocket expenses on the day, but is not technically free, as
Medicare is still paying. However, if a customer is an international
student, they can receive a free eye test with the purchase of a new
pair of Oscar Wylee frames.
Visit a store near you
Come in and see the Oscar Wylee team where our staff can help you with
all your optometry and eyewear needs.
[Optometrist near me](https://www.oscarwylee.com.au/locations/full-store-list.html)
## What is the Importance of a Checkup Eye Exam?
The answer to why is a checkup eye exam important is
simple.&nbsp;A checkup eye exam is an essential tool for maintaining good eye
health and detecting any issues related to the eyes early on. Eye exams can help identify vision problems, eye diseases, and
other abnormalities that may not have noticeable symptoms in their
early stages. Detecting and diagnosing these issues early can lead to
more effective treatment and management, helping to prevent vision
loss and other complications. It is important to book regular eye
exams to maintain the health of your eyes and allow your optometrists
to monitor any changes in your vision or eye health.
### What is the Benefit of a Bulk Billed Eye Test?
The benefit of a Medicare, bulk billed eye test is that (for those
who are eligible), you&nbsp;will not have to pay out-of-pocket for your eye test as it will be
covered by Medicare.&nbsp;Medicare is Australia’s healthcare system that provides
coverage and gap payments for Australian citizens and permanent
residents for all payments going towards health costs and medical
aid. Because a person does not have to pay for a bulk billed eye
test, it is commonly referred to as a&nbsp;[free eye test](https://www.oscarwylee.com.au/free-eye-test). However, this is not technically correct as Medicare is still
paying for the eye test.
## How Often Should You Have a Checkup Eye Test?
At Oscar Wylee,&nbsp;we recommend that you have an eye test every 1-2 years. If you are
over 65 years of age, then a yearly eye test is ideal. Other factors that may determine how often you should have an eye
test include if you have certain medical conditions such as diabetes
and high blood pressure which means you will likely need frequent eye
tests as these conditions can affect your vision. If you have
existing, diagnosed eye conditions such as retinal detachment or
glaucoma, your optometrist or ophthalmologist may recommend you book
frequent eye tests. It is recommended to get into an eye exam routine,
meaning you are booking regular eye tests at least once every two
years.The answer to how long does an eye appointment take can vary
depending on the person. An eye appointment will typically only take
between 20-30 minutes, therefore, you should make time for an eye test
in your everyday life to ensure the health of your eyes and
vision.
### How to Find an Optometrist?
You can find an optometrist in Australia by taking a few essential
steps that make the process simple and easy. The steps on how
to[find an optometrist](https://www.oscarwylee.com.au/find-optometrist)&nbsp;in Australia include searching online to find optometrists
near you, next choosing the location that is most convenient for
your location and finally selecting the date and time for your
appointment.
### What to Prepare for A Checkup Eye Exam?
Some ways to prepare for getting an eye exam include bringing your
glasses to the appointment if you use them.&nbsp;Your current pair of corrective lenses may help the optometrist get
a well-rounded and accurate picture of your vision and eye
health. Another way to prepare is to be ready to tell the optometrist if
you’ve experienced any changes in your vision. It is important to
tell them the exact changes you have experienced, if any, when they
occurred and how often. This can help the optometrist in assessing
the health of your eyes and may also assist in the diagnosis of
certain eye conditions. Finally, try to relax before your eye test.
While people may get nervous before an eye exam, it is best to put
it out of your mind and also let the eye care professionals know if
you are feeling anxious or uncomfortable and they will aim to make
your experience as comfortable as possible.
#### How Much Does a Checkup Eye Exam Cost?
The cost of a checkup eye exam&nbsp;can be covered under Medicare which is called bulk
billing. According to Health Direct, Medicare subsidises eye tests that
are provided by optometrists for all permanent residents of
Australia. At Oscar Wylee, eligible Medicare card holders can have
their routine eye test bulk billed.&nbsp;For those that are not eligible Medicare cardholders, an eye test
will cost $70.
Does insurance cover it?Typically, health insurance does not cover the cost of eye exams,
rather, they are covered under Medicare. However, some
international students are able to claim back their eye test
through their insurer.
#### What to Do if You Experience Discomfort or Anxiety During a Checkup
Eye Test?
It is important to&nbsp;let your optometrist know if you experience any discomfort or
anxiety during a checkup eye test. If they are informed of how you are feeling, they can help ease
your anxieties by talking you through the eye test and reducing
discomfort where possible. Another way to help ease eye test
anxiety is to book the test. Sometimes the hardest part is
scheduling the test, but once it’s done, you can prepare yourself
for the appointment and reward yourself for setting it up instead
of putting it off for weeks or months. Booking regular eye tests
can also help if you experience discomfort or anxiety during an
eye checkup as it can help you get used to the process and be
aware of the different tests and procedures the optometrist will
perform.
### What Not to Do Before an Eye Test?
Generally, there is not much a person needs to do to prepare for an
eye exam. The optometrist and staff are equipped to provide
high-quality eye tests and will instruct their patients on
everything that will need to be done.Having said that, it is advised that you&nbsp;do not overexert your eyes before the eye test so that they are not
fatigued. This can mean making sure you have adequate rest the day before
to ensure you are comfortable. You should also try to avoid drinking
an excessive amount of caffeine as it may affect your blood pressure
which may be necessary to assess during the eye test.
### How Long Does a Checkup Eye Exam Typically Take?
How long a checkup eye exam typically takes can vary as&nbsp;it depends on the type of tests performed. At Oscar Wylee, we
allocate approximately 20 minutes for each eye test. However, this time frame can vary, especially for those who have
more complex eye diseases that require more extensive testing.
#### Can you Fail an Eye Exam?
No,&nbsp;you cannot fail an eye exam. An eye exam is an assessment of your vision and eye health and
the tests performed are used to determine if you need corrective
devices and detect any eye diseases or issues. Therefore, you
cannot fail an eye exam as everyone’s eyes are unique and will
require different treatments.People may be confusing a regular eye test performed by an
optometrist with the eyesight test for driver and rider licensing.
According to the New South Wales Government, this eye test will
involve the person reading aloud from a chart of letters. If the
person fails this test, they will be unable to resit it at the
service centre, rather, they will need to provide a report of
their eyesight that they can acquire from an optometrist or an
ophthalmologist.
#### Can a Checkup Eye Exam Detect Eye Diseases?
Yes,&nbsp;a checkup eye exam can detect eye diseases, in fact, an eye test
is the primary way eye conditions or diseases are diagnosed.&nbsp;Not only are eye tests important in detecting and diagnosing eye
diseases, they are also used to monitor their progression. Some of
the main ways to diagnose and&nbsp;[detect eye diseases](https://www.oscarwylee.com.au/glasses/eye/how-to-detect-diseases)&nbsp;include a slit-lamp examination. Another test includes
optical coherence tomography (OCT) which is used to view eye
diseases such as glaucoma and macular degeneration. According to
the American Academy of Ophthalmology, OCT is a non-invasive
imaging test that is used to take pictures of the retina.
##### Can an Eye Exam Detect Optic Neuritis?
Yes,&nbsp;an eye test can be used to detect and diagnose optic
neuritis.&nbsp;[Optic neuritis](https://www.oscarwylee.com.au/glasses/eye/optic-neuritis)&nbsp;is an eye condition that develops when the optic nerve is
inflamed and swollen causing pain in the eye and in some cases
vision loss or impaired vision. An ophthalmologist and
optometrist can check your optic nerve for inflammation by
shining a light into your eyes with a slit lamp.
#### Is a Checkup Eye Exam Necessary for Maintaining Good Eye Health?
Yes,&nbsp;a checkup eye test is necessary for maintaining good eye health
as it ensures your eye health is being monitored&nbsp;so that if anything changes or you develop an eye
condition, an optometrist will be able to diagnose and provide the
proper treatment. Undetected eye conditions can be a major issue
as for some conditions like glaucoma and diabetic retinopathy,
early detection can prevent partial or complete vision loss.A checkup eye exam is also necessary as you may have uncorrected
vision issues that an optometrist can help with by providing a
prescription for corrective lenses. Many people assume that their
eyesight is perfect, but the only way to know what your vision is
like is to have it assessed by an optometrist.&nbsp;You can&nbsp;[find an optometrist](https://www.oscarwylee.com.au/find-optometrist)&nbsp;to provide a checkup eye test at one of our many Oscar
Wylee stores.
Read Checkup Eye Test: Definition, and What to Expect? in other Oscar
Wylee regions and their languages.
Australia
[Australia](https://www.oscarwylee.com.au/glasses/eye/check-up)
[Canada](https://oscarwylee.ca/glasses/eye/check-up)
[Canadian French](https://oscarwylee.ca/fr/glasses/eye/check-up)
Make your eye health a priority
Book a bulk billed eye test with one of our skilled optometrists and
prioritise your eye health today.
[Eye test near me](https://www.oscarwylee.com.au/booking)
Leading health funds accepted at Oscar Wylee.
Use your private health fund insurance to limit how much you pay from
your own pocket so you can save big on OW frames and lenses!
[Discover Health Funds](https://www.oscarwylee.com.au/health-funds.html)