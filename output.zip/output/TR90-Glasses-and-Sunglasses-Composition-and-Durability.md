# Source: https://www.oscarwylee.com.au/glasses/tr90

# TR90 Glasses and Sunglasses: Composition and Durability
Updated on December 16th, 2024
Published on December 13th, 2024
TR90 glasses and sunglasses refer to
eyewear that is made from a thermoplastic material that is durable,
flexible and lightweight. TR90 is defined as an advanced memory material that was created by EMS, a
Swiss chemical industrial group and is typically used in eyewear frames.
TR90 can be a popular material choice as they provide optimal flexibility,
durability and lightweightedness for glasses and sunglasses frames. Here at
Oscar Wylee, our TR90 frames are placed through conditions ensuring they
will maintain their properties in extreme temperatures including extremely
humid or dry climates. Read on to learn more about TR90 glasses.
Take Care of Your Vision Health With Our Dedicated Team
See one of our friendly optometrists and retail team in-store for
excellent eye care services.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Definition](#Definition) [Benefits](#Benefits)
[Comparison to Other Materials](#Comparison)
[Difference Between TR90 and Acetate](#Difference)
## What Are TR90 Glasses?
TR90 glasses are
eyewear made from TR90, a thermoplastic material known for its
optimal flexibility, lightweight nature, and durability. This high-tech material helps provide comfortable and resilient
frames that can be more resistant to daily wear and tear than frames
made from other materials. Due to these key qualities, TR90 is widely
utilised in producing both prescription eyeglasses and sunglasses,
making them a reliable choice for manufacturers wanting to use quality
materials.
### Why is TR90 Material Popular for Eyewear?
TR90 material can be popular for eyewear
due to its lightweight, flexible, and durable properties, making
them ideal for comfortable and stylish eyewear. TR90 can be molded into various stylish designs, appealing to both
fashion and functionality in eyewear.
[Lightweight glasses](https://www.oscarwylee.com.au/glasses/materials/lightweight.html)
help ensure even more comfort and a minimal look and feel for daily
wear. Here at Oscar Wylee, we have a wide range of lightweight
options, such as TR90 frames and more.
### How Lightweight are TR90 Frames?
The lightweightness of TR90 frames
can vary depending on the style and/or when other materials are
combined.
Most TR90 frames at Oscar Wylee make ideal lightweight glasses
options, however, the weight of our TR90 frames do vary and can depend
on the type of lenses. For more information on lightweight frames,
read
[Lightweight Eyeglasses: Materials, Design, and Comfort](https://www.oscarwylee.com.au/glasses/lightweight-frame).
### What are the Benefits of TR90 Glasses?
The benefits of TR90 glasses are their
lightweight nature, hypoallergenic nature and flexibility and
durability. The benefits of TR90 glasses are listed below.
* Lightweight Nature:  A primary
benefit of TR90 glasses is their lightweight nature. TR90 frames are
a reliable option for comfortable frames as they won’t feel heavy on
your nose bridge and ears.
* Hypoallergenic Nature:  Another
benefit of TR90 frames is their hypoallergenic nature.
Hypoallergenic is a term commonly used to refer to materials and/or
cosmetics that are not likely to cause allergies. Therefore, TR90
frames are an ideal option for individuals who may have allergies or
sensitive skin.
* Flexibility and Durability:  An
essential benefit of TR90 glasses is their flexibility and
durability. TR90 frames withstand daily wear due to their memory
material, retaining shape even with frequent handling or accidental
minor stretching. TR90 frames are distinctly strong while
maintaining their lightweight nature. Read more about other flexible
frames such as
[memory metal in memory metal glasses: durable, flexible, and
lightweight frames](https://www.oscarwylee.com.au/glasses/memory-metal).
#### Are TR90 Glasses Durable and Long-Lasting?
Yes, TR90 glasses are durable and long-lasting. TR90 glasses
are able to withstand minor wear and tear that can occur daily,
making them the perfect frame for a range of lifestyles and
activities.
Come Experience Excellent Eye Care Services
Our team and optometrists are passionate and dedicated to providing
high quality eye care assistance and a memorable in-store experience.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
## How Do TR90 Sunglasses Compare to Other Frame Materials?
TR90 sunglasses in comparison to other frame materials are
primarily lighter due to a combination of plastic and polymer. Other frame materials that are typically combined with&nbsp; TR90 to
make frames such as rubber, acetate and metal may also feature
durability and comfort and allow for a range of styles. Learn more about
acetate by reading about
[acetate glasses: material, benefits and caring tips](https://www.oscarwylee.com.au/glasses/acetate-frame). TR90 may also be a go-to material for sports eyewear as they are more
resistant to accidental bends and twists. For individuals that may want
or require a more minimal-feeling pair of eyeglasses, TR90 may be a good
match. It can be helpful to try TR90 frames along with other sunglasses
made from different materials to feel the difference in weight and feel.
### What Makes TR90 Ideal for Bendable Sunglasses?
TR90 does not make bendable sunglasses.
It is important to note that while they are more flexible, TR90
sunglasses are not necessarily bendable
as this can lead to damage. The flexible and durable nature of TR90
sunglasses is beneficial for accidental and minor cases of bending and
twisting.
### How to Choose the Best TR90 Glasses?
To choose the best TR90 glasses,
determine your desired frame shape, select either sunglasses or
optical glasses and consider your lifestyle and hobbies. The steps to choosing the best TR90 glasses are listed below.
1. Determine your desired frame shape: 
Determine your desired frame shape by trying on different TR90
glasses to figure out what you think suits you best. Alternatively,
you may want to consider choosing frames based on your face shape.
2. Select either sunglasses or optical glasses:
Select out of either sunglasses or optical glasses to narrow down
TR90 eyewear options.
3. Consider your lifestyle and hobbies:
Consider your lifestyle and hobbies when selecting the best TR90
glasses. For example, if you frequent outdoor activities, it may be
best to opt for active or sports TR90 frames as they are designed to
provide more protection against the sun’s UV rays.
#### Are TR90 Frames Suitable for Prescription Lenses?
Yes, TR90 frames are suitable for prescription lenses as
they can help ensure your frames are lightweight and durable.
TR90 frames can make ideal frames for prescription lenses as they
are able to endure possible mishaps, last long and feel comfortable
even after long periods. At Oscar Wylee, we offer an abundant range
of TR90 frames for
[prescription eyewear](https://www.oscarwylee.com.au/glasses/prescription)
and have friendly staff that will be happy to assist with personal
styling recommendations.
### Where Can You Find TR90 Glasses Online?
You can find TR90 glasses online
on many e-commerce websites and the websites of retail stores. If
you’re in search of minimalist styles, bold styles and classic
styles, [Oscar Wylee](https://www.oscarwylee.com.au/) has a wide
range of stylish TR90 frames that may suit different aesthetics. It is
important to try on TR90 glasses first before buying online so you can
be sure of the quality of your frames and can choose the pair that
suit you best.
### How to Maintain and Clean TR90 Glasses?
To maintain and clean your TR90 glasses,
clean them regularly, use the designated cleaning kit, handle
glasses with care and store them properly. The ways to maintain and clean TR90 glasses are listed below.
* Clean TR90 glasses regularly:  Clean
TR90 glasses regularly to prevent any build-up of dust, specks of
dirt and smudges to maintain TR90 glasses.
* Use the designated cleaning kit: 
Use the designated cleaning kit that you can purchase along with
your TR90 frames to ensure you don’t cause any scratches and ensure
you are cleaning them optimally. Spray both sides of your glasses
with the Oscar Wylee lens cleaner and using the cloth, gently wipe
your glasses in a circular motion. Do not rub back and forth.
* Handle glasses with care:  Handle
glasses with care to maintain TR90 frames by making sure you use
both hands when putting them on and taking them off. This can help
minimise any incorrect bending of the glasses arms.
* Store glasses properly:  Store
glasses properly by using the case that comes with your TR90 frames
to protect them from damage that can occur from falling or being sat
on.
#### Are TR90 Frames the Best Choice for Active Lifestyles?
Yes, TR90 frames may be the
best choice for active lifestyles with their distinct durability
and lightweight nature. TR90 frames can be a reliable frame option for outdoor glasses
and
[sports eyewear](https://www.oscarwylee.com.au/glasses/sport-sunglasses)
as they won’t feel heavy on certain facial features, can stay on
your face for long periods and are more resistant to any minor
mishaps.
### What is The Difference Between TR90 and Acetate Frames?
The difference between TR90 and acetate frames are
their materials, weight and colour options. TR90 is more
lightweight and slightly more flexible than acetate as they allow for
more bend in the frames whereas acetate won’t bend. However, both TR90
frames and
[acetate frames](https://www.oscarwylee.com.au/glasses/acetate-frame)
are reliable for durable and comfortable frames and can come in a
varied range of styles and shapes.
When was your last eye test?
At Oscar Wylee we offer bulk billed eye tests for eligible Medicare
card holders.
[Book an eye test](https://www.oscarwylee.com.au/booking)
Major Health Funds Accepted In-store
For the purchase of frames and lenses, use your private health fund
insurance to cover some of the cost.
[Explore health funds](https://www.oscarwylee.com.au/health-funds.html)