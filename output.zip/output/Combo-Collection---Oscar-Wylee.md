# Source: https://www.oscarwylee.com.au/glasses/collection/combo-collection.html

[](#layer-product-list)
[SHOP NOW](#layer-product-list)
[](#layer-product-list)

Our new collection introduces a full range of sizes from small, regular to large, celebrating
inclusivity in every pair.

[](#layer-product-list)

The bolder, the better. The Mega Eyewear Collection takes influence from 80’s fashion that is sure
to make a statement.

[](#layer-product-list)

We’ve taken the frames you know and love and given them an upgrade for comfortable and easy wearing.

8 Products        
Showing 8
1. [](https://www.oscarwylee.com.au/mesa-optical.html)
[Mesa](https://www.oscarwylee.com.au/mesa-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/mesa-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/mesa-optical.html)
2. [](https://www.oscarwylee.com.au/parker-optical.html)
[Parker](https://www.oscarwylee.com.au/parker-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/parker-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/parker-optical.html)
3. [](https://www.oscarwylee.com.au/marlow-sunglasses.html)
[Marlow](https://www.oscarwylee.com.au/marlow-sunglasses.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/marlow-sunglasses.html)
[3 pairs from $249](https://www.oscarwylee.com.au/marlow-sunglasses.html)
4. [](https://www.oscarwylee.com.au/zac-optical.html)
[Zac](https://www.oscarwylee.com.au/zac-optical.html)
$199    
[2 pairs from $249](https://www.oscarwylee.com.au/zac-optical.html)
5. [](https://www.oscarwylee.com.au/alya-optical.html)
[Alya](https://www.oscarwylee.com.au/alya-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/alya-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/alya-optical.html)
6. [](https://www.oscarwylee.com.au/martha-optical.html)
[Martha](https://www.oscarwylee.com.au/martha-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/martha-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/martha-optical.html)
7. [](https://www.oscarwylee.com.au/aaron-optical.html)
[Aaron](https://www.oscarwylee.com.au/aaron-optical.html)
$199    
[2 pairs from $249](https://www.oscarwylee.com.au/aaron-optical.html)
8. [](https://www.oscarwylee.com.au/marco-optical.html)
[Marco](https://www.oscarwylee.com.au/marco-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/marco-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/marco-optical.html)
8 Products        
Showing 8