# Source: https://www.oscarwylee.com.au/glasses/collection/serge-family

# Oscar Wylee Serge Family
Our Serge frame has stood the test of time, becoming a renowned and ever
popular frame of ours - for good reason! The bold, square frame offers a
modern statement piece ready to make your outfit pop. Check out what makes
our Serge frame so special, and how it has evolved over the years!
## Serge: The one that started it all.
[](https://www.oscarwylee.com.au/serge-optical.html)
[](https://www.oscarwylee.com.au/serge-optical.html)
[](https://www.oscarwylee.com.au/serge-optical.html)
[](https://www.oscarwylee.com.au/serge-optical.html)
[](https://www.oscarwylee.com.au/serge-optical.html)
[](https://www.oscarwylee.com.au/serge-optical.html)
[](https://www.oscarwylee.com.au/serge-optical.html)

[](https://www.oscarwylee.com.au/serge-optical.html)
[](https://www.oscarwylee.com.au/serge-optical.html)
[](https://www.oscarwylee.com.au/serge-optical.html)
[](https://www.oscarwylee.com.au/serge-optical.html)
[](https://www.oscarwylee.com.au/serge-optical.html)
[](https://www.oscarwylee.com.au/serge-optical.html)
[](https://www.oscarwylee.com.au/serge-optical.html)
[](https://www.oscarwylee.com.au/serge-optical.html)
[](https://www.oscarwylee.com.au/serge-optical.html)
[](https://www.oscarwylee.com.au/serge-optical.html)
[](https://www.oscarwylee.com.au/serge-optical.html)
## Serge 2: Bold with added comfort? Yes please.
[](https://www.oscarwylee.com.au/serge-2-optical.html)
[](https://www.oscarwylee.com.au/serge-2-optical.html)
[](https://www.oscarwylee.com.au/serge-2-optical.html)
[](https://www.oscarwylee.com.au/serge-2-optical.html)
Oscar Wylee Serge
Serge is named after the French musician, Serge Gainsbourg, drawing upon
modern aesthetics as opposed to a more vintage look. With a pronounced
square shape, Serge has remained a long-standing favourite, showing that
statement frames are always in style! 
Wherever you wear your
Serge glasses, make sure to book an eye test with us to get an up to
date prescription for your frames.
[Book an eye test](https://www.oscarwylee.com.au/booking)
## Serge Large: Because sometimes bigger is better.
[](https://www.oscarwylee.com.au/serge-l-optical.html)
[](https://www.oscarwylee.com.au/serge-l-optical.html)
[](https://www.oscarwylee.com.au/serge-l-optical.html)
[](https://www.oscarwylee.com.au/serge-l-optical.html)
## Serge Small: Smaller frames, same bold impact.
[](https://www.oscarwylee.com.au/serge-s-optical.html)
[](https://www.oscarwylee.com.au/serge-s-optical.html)
[](https://www.oscarwylee.com.au/serge-s-optical.html)
[](https://www.oscarwylee.com.au/serge-s-optical.html)
Customise Your Serge
Set your Serge frames apart from the rest by customising your lenses to
suit your vision needs and personality! Whether a tinted add-on for a
pop of colour, or a blue light filter for protection from digital
screens, we have lens add-ons made to suit your everyday.
[Learn More](https://www.oscarwylee.com.au/customise-your-frames)
## Serge Sunglasses: Yes, they come in sunglasses too.
[](https://www.oscarwylee.com.au/serge-sunglasses.html)
[](https://www.oscarwylee.com.au/serge-sunglasses.html)
[](https://www.oscarwylee.com.au/serge-sunglasses.html)
[](https://www.oscarwylee.com.au/serge-sunglasses.html)
[](https://www.oscarwylee.com.au/serge-sunglasses.html)
## Styled by You
[](https://www.oscarwylee.com.au/serge-l-optical.html)
[](https://www.oscarwylee.com.au/serge-optical.html)
[](https://www.oscarwylee.com.au/serge-optical.html)
[](https://www.oscarwylee.com.au/serge-optical.html)
[](https://www.oscarwylee.com.au/serge-optical.html)
[](https://www.oscarwylee.com.au/serge-2-optical.html)
Show All
## Which Serge frame is best for me?
The best Serge frame for you will depend on factors such as your
features, personal style, and how it looks when you try it
on.
Read more on how to pick the best Serge frame for you below.
* Features: Consider your facial features and
characteristics when selecting a Serge frame. For those with a
low nose bridge, where the midline of your nose rests below the
eyeline, you may prefer the more secure comfort of the Serge 2
with adjustable nosepads. If you have a larger face, the Serge
Large will likely be a more accommodating fit. Comfort is key!
* Personal Style: Your personal style will
determine what colour frames you lean toward. For those who want
an even more bold Serge frame, colours such as blue lagoon and
speckled bluebird will make you pop! Alternatively, those who
want a more subtle take on the Serge frames may prefer more
subdued colours such as clear crystal or a timeless
tortoiseshell.
* Try it on: Try your frames on to ensure they
complement your features well, and most importantly, fit
comfortably! Ensure the bridge sits comfortably along the
midline of your nose, and the temples are secure over your ears.
## Can I include lens add-ons to my Serge glasses?
Yes you can include lens add-ons to your Serge glasses! We have
plenty of add-ons to personalise your frames. Our premium
anti-reflective lenses reduce reflection in your lenses and allow
for scratch and static resistance, while our blue light filter
reduces exposure to blue light that comes from digital screens.
### How much does the Serge frame cost?
All iterations of the Serge frames have the same price points: 1
pair from $169, 2 pairs from $199 and 3 pairs from $249.
#### Which face shapes are best suited to Serge frames?
The face shapes that are best suited to Serge frames are round and
oval faces. The Serge is a square frame, which adds definition and
a pleasing contrast to the natural curve and softness of round and
oval faces.