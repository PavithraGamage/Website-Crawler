# Source: https://www.oscarwylee.com.au/faq-sunglasses.html

* [POPULAR FAQS](https://www.oscarwylee.com.au/faq-popular.html)
* [ORDERING](https://www.oscarwylee.com.au/faq-ordering.html)
* [PRESCRIPTIONS](https://www.oscarwylee.com.au/faq-prescriptions.html)
* [SUNGLASSES](https://www.oscarwylee.com.au/faq-sunglasses.html)
* [RETURNS &amp; WARRANTIES](https://www.oscarwylee.com.au/faq-returns.html)
* [PAYMENT](https://www.oscarwylee.com.au/faq-payment.html)
* [HEALTH FUNDS](https://www.oscarwylee.com.au/faq-healthfund.html)
* [LENSES](https://www.oscarwylee.com.au/glasses/eye/types-of-lenses)
* [FRAMES](https://www.oscarwylee.com.au/faq-frames.html)
* [SHIPPING](https://www.oscarwylee.com.au/faq-shipping.html)
* [EYEWEAR STYLING TIPS](https://www.oscarwylee.com.au/faq-eyewear-styling-tips.html)
POPULAR
ORDERING
PRESCRIPTIONS
SUNGLASSES
RETURNS &amp; WARRANTIES
PAYMENT
HEALTH FUNDS
LENSES
FRAMES
SHIPPING
EYEWEAR STYLING TIPS
### SUNGLASSES
Do you sell prescription sunglasses?
Yes, we do! You can upgrade to prescription sunglasses for an additional cost per pair.
There are 7 colours to choose from, red, yellow, blue, pink, brown, grey and green.
If you are unsure, please visit your local [store](https://www.oscarwylee.com.au/locations.html) to check the samples.
All prescription sunglasses ordered online will come with polarised lenses as standard, unless otherwise stated. This is an additional $100 per pair.
Are prescription sunglasses included in the two pairs from $199?
You can order 1 pair of optical glasses and have sunglasses as the second pair.
All prestcription sunglasses ordered online will come with polarised lenses as standard, unless otherwise stated. This is an additional $100 per pair.
In-store, you will be able to add polarised or tinted lenses at an additional cost.
Are non prescription sunglasses included in the two pairs from $199?
If a frame has a non-prescription option online, you can use this with the two pairs from $199.
This offer is available in store but is subject to availability.
Can I choose the colour of lens for my sunglasses?
If you are purchasing prescription sunglasses in the store, you can customise the colour of the lens. This is considered a custom order so additional charges may occur. Speak to a member of the team in [store](https://www.oscarwylee.com.au/locations.html) and they will be able to show you the different options available.
When placing an order online, the lens colour will match the lens colour of the frame image, unless otherwise stated and cannot be altered.
What type of lenses are used in your sunglasses?
We are able to order two different sunglass lenses. Most of our in-store non-prescription sunglasses come with approved category 3 – polarised, UVA and UVB protecting lenses.
We also offer a standard tint that is category 2 – with UVA and UVB protection. For prescription sunglasses, the lens material depends on your choice of add ons.
Are high-index lenses available for prescription sunglasses?
Yes, high-index lenses are available for prescription sunglasses in 1.61 and 1.67. In-store you can order tinted lenses in every colour available or polarised lenses in grey.