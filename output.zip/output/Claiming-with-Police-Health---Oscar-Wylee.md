# Source: https://www.oscarwylee.com.au/health-funds/police-health.html

# Police Health at Oscar Wylee
As a member of Police Health, you can claim on optical extras using your
health fund’s coverage for optical services, such as prescription
frames, lenses or glasses.
Police Health lets you roll over unclaimed annual limits from one
calendar year to the next on optical benefits.
With Oscar Wylee, you can have up to 80% coverage on select optical
purchases when you shop with us. Look at the table below to see your
Police Health policies name and the amount of coverage that policy gives
when you shop at Oscar Wylee.Your coverage might change or
not apply to extras such as add-ons, coatings or tinting.
## Worried about your sight?
Taking care of your eyes can be done in only 30 minutes with Oscar
Wylee.
[Book today](https://www.oscarwylee.com.au/booking)
#### Waiting Period
2 Months
#### Benefit Limits Reset
1st of January
#### Claimable Benefits %
100% for Frames and 80% for Lenses
To learn whether your plan includes single-vision lenses, bifocal lenses
and/or multifocal lenses, talk to your health insurance provider.
| Your Extras Package Annual Limit:* | Rolling Extras1 | SINGLES COVER | 1 Standard OW Pair
from $169^ | 2 Standard OW Pairs
from $199^ | 3 Standard OW Pairs
from $249^ |
| --- | --- | --- | --- | --- | --- |
| $350 |
| Partial Cover |
| Partial Cover |
| Partial Cover |
^Excludes add-ons. Standard frames and lenses only. Oscar Wylee’s
standard product inclusions are calculated based on the optical
allowances under each health fund package and may vary. If unsure,
please confirm with your provider. Our two pair and three pair deals are
only available per person and cannot be split between two people. Only
one prescription can be used per offer. If you have a distance and a
reading prescription, this is included in the offer as this is
considered to be one prescription. Any prescriptions must have the full
name of the person claiming and a valid expiry date to be able to order.
If you have two different prescribed prescriptions, you will need to
visit a store to be eligible for our two pair and three pair deals.
| FAMILY COVER | 1 Standard OW Pair
from $169^ | 2 Standard OW Pairs
from $199^ | 3 Standard OW Pairs
from $249^ |
| --- | --- | --- | --- |
| $350 per person |
| Partial Cover |
| Partial Cover |
| Partial Cover |
^Excludes add-ons. Standard frames and lenses only. Oscar Wylee’s
standard product inclusions are calculated based on the optical
allowances under each health fund package and may vary. If unsure,
please confirm with your provider. Our two pair and three pair deals are
only available per person and cannot be split between two people. Only
one prescription can be used per offer. If you have a distance and a
reading prescription, this is included in the offer as this is
considered to be one prescription. Any prescriptions must have the full
name of the person claiming and a valid expiry date to be able to order.
If you have two different prescribed prescriptions, you will need to
visit a store to be eligible for our two pair and three pair deals.
## Due for an eye test?
We recommend that everyone should have an eye test with an
optometrist at least once every 2 years.
[Book an an eye test](https://www.oscarwylee.com.au/booking)
*Based on Phoenix Health Fund’s
[Cover Guide](https://policehealth.com.au/rolling-extras)
and product factsheet as presented to the Commonwealth Ombudsman
[1](https://www.policehealth.com.au/health-insurance/rolling-extras/).1 At Police Health, Rolling Extras don’t have
to reset on the renewal date. They can be saved up into a new calendar
year for up to $700 per person. 
Information correct as of November 2024.
## Your eye test explained
Routine eye test appointments are quick and painless. Find out
what to expect during an eye exam and how to understand your eye
test results.
[Find out more](https://www.oscarwylee.com.au/eye-health/your-eye-test-explained.html)
## Bulk Billing
Find out what bulk billing is and whether you're eligible to
receive an eye test free of charge.
[Find out more](https://www.oscarwylee.com.au/eye-health/eye-test-info/bulk-billing.html)
## What is Pupillary Distance? (PD)
Do you know your PD? It's something you'll need to know when
ordering glasses online. Find out what Pupillary Distance is and
how you can measure your own.
[Read more](https://www.oscarwylee.com.au/eye-care/eye-test/what-is-pupillary-distance.html)
## Book an eye test
Oscar Wylee eye tests are bulk billed through Medicare. This
means there will be no out-of-pocket expense for eligible
Medicare cardholders.
[Book online](https://www.oscarwylee.com.au/booking/)
## Find a store near you
Contact or visit your nearest store for a full quote.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)