# Source: https://www.oscarwylee.com.au/logan-l-optical.html

Out of stock        
# Logan Large
## About Logan Large Glasses
Logan sized up. Ladies, look out! A comfortable wear for wider faces while still remaining ultra-light. Our modern take on the classic rectangular eyewear design.
| Frame fit | Measurements |
| --- | --- |
| WIDE | 60 - 19 - 146 |
These measurements mean lens width, bridge, and temple length in millimetres (mm). They can be found on the inside of the temple arm. If you already have a pair that you like, you can compare it to these measurements.
### Made from Ultem
Oscar Wylee’s Logan Large frame is a men’s rectangle glasses frame that is perfect for those with round and oval face shapes. The Logan Large frame is an intellectual, striking frame that can be worn every day. The main specs of Oscar Wylee’s Logan Large glasses frame, including dimensions, shape, materials, lenses, nose fit and hinges are listed below.
| Logan Large Frame Features | Logan Large Frame Description | Dimensions | Shape | Materials | Lenses | Nose Fit | Hinges |
| --- | --- | --- | --- | --- | --- | --- | --- |
| The dimensions of the Logan Large frame are measured in millimetres (mm) and are 60 - 19 - 146, meaning the lens width is 60 mm, the bridge is 19 mm, and the temple length is 146 mm. |
| Logan Large is a rectangle shape, well-suited to wide faces. |
| Logan Large is made from Ultem, with rubber temple tips. |
| The lenses that can be used in the Logan Large frame include optical lenses, such as single-vision and multifocal, and non-prescription lenses, which are plain and can have a filter, such as a blue light filter applied. |
| The nose fit for Logan Large is characterised by a high nose bridge. |
| The hinges in Logan Large are spring hinges, which are more flexible than other types of hinges and can extend past 90 degrees. |
Show All
### What Inspired the Frame Design of Oscar Wylee’s Logan Large Glasses?
The Oscar Wylee Logan Large frame design was inspired by current fashion trends, as rectangle glasses are a timeless style.
## What to Know About Oscar Wylee’s Logan Large Glasses?
There are many aspects of the Oscar Wylee Logan Large frames that customers should know about to decide whether this is the right frame for them. The Logan Large frame is a men’s rectangle-shaped frame. Oscar Wylee’s Logan Large frame is suitable for many face shapes, but particularly compatible with round and oval face shapes. The Logan Large frame’s simple design makes them fashionable all year round. Logan Large features the standard [parts of glasses](https://www.oscarwylee.com.au/glasses/eye/part-of-glasses), such as a rim, temples, lenses and spring hinges.
### What are the Types of Temple Tips or Earpieces Included with Oscar Wylee’s Logan Large Glasses?
The type of temple tips or earpieces included in Oscar Wylee’s Logan Large Glasses are made from rubber.
### What Type of Nose Bridge do Oscar Wylee’s Logan Large Glasses Have?
The type of nose bridge included in Oscar Wylee’s Logan Large frame is a high nose bridge fit.
### What Type of Nose Pads are Included with Oscar Wylee’s Logan Large Glasses?
Oscar Wylee’s Logan Large frame does not include adjustable nose pads.
### What Type of Lenses do Oscar Wylee’s Logan Large Glasses Have?
The type of lenses that typically come with the Oscar Wylee Logan Large [glasses frame](https://www.oscarwylee.com.au/glasses.html) are optical lenses. Optical lenses are glasses lenses that have a prescription within the lens to help correct vision issues such as myopia, hyperopia, and astigmatism. Logan Large frames can also come as sunglasses and with non-prescription lenses and add-ons such as a blue light filter. Logan Large frames can be customised into sunglasses in-store or online with add-on tints or polarisation.
### What Material is Used for the Rim of Oscar Wylee’s Logan Large Glasses?
The material used for the rim of Oscar Wylee’s Logan Large glasses frames is Ultem. The rim refers to the part of a glasses frame that holds the lenses.
### What Type of Hinges are Included with Oscar Wylee’s Logan Large Glasses?
The type of hinges included with Oscar Wylee’s Logan Large frames are spring hinges. A spring hinge in a glasses frame refers to hinges that are more flexible than normal hinges and can go slightly beyond 90 degrees. Spring hinges can provide a closer fit to the face.
## What Face Types are Most Suitable for Oscar Wylee’s Logan Large Glasses?
The face types that are most suitable for Oscar Wylee’s Logan Large frame are round and oval face types. The Logan Large frame is a rectangle shape, meaning that it complements the structure of round and oval faces particularly well. The rectangle Logan Large frames help balance the features of [round faces](https://www.oscarwylee.com.au/glasses/face-shapes/round) and [oval faces](https://www.oscarwylee.com.au/glasses/face-shapes/oval), and bring the eyes and brows forward in a flattering way. Although there are many [glasses for face shapes](https://www.oscarwylee.com.au/glasses/face-shapes) that may be considered more aesthetically suitable, it is important that people also choose frames that make them feel most comfortable and represent their personal style.
## What Size Options are Available for Oscar Wylee’s Logan Large Glasses?
The size options available for Oscar Wylee’s Logan Large frame are a wide-frame fit across all colours.
## What Materials are Used to Create Oscar Wylee’s Logan Large Glasses?
The primary material used to create the Oscar Wylee Logan Large frame is Ultem. Ultem is a high-performing thermoplastic, perfect for glasses frames as it is tough and flexible, with the ability to bend and return to its original shape.
## What’s Included
## OW Case &amp; Cloth
Protective Case and Lens Cloth
Our high-quality glasses case and lens cloth are included with every purchase of an Oscar Wylee frame. The stylish, magnetic case is made from a hard shell. This sturdy and durable material keeps your glasses protected and safe, wherever you go. Ensure your lenses are clean and scratch-free with our OW microfibre cloth, specifically designed to ensure you have comfortable vision through your lenses.
Oscar Wylee offers:
* Free Shipping for Australian Orders
* 1 Year Warranty on frames and lenses
* Scratch resistance lens coating on all prescriptions
* UV-proof coating on all prescriptions
Health fund rebate: Once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. Learn more about [health funds](https://www.oscarwylee.com.au/health-funds.html).
## Make and Materials
The frames then go through cleaning and strict quality control, and many pairs of crafting hands to be hand-assembled and polished. After your frames have gone through the production process, they are individually examined and packed before making their way to you!We love our Ultem frames! They are super comfortable and very durable. Our Ultem frames are heat resistant, with high dielectric strength and flexible. The material is widely used in medical and chemical instruments. It is currently available in a range of colours for both matte and gloss finish.
## Warranty Information
### Warranty Information
### Warranty Information
Oscar Wylee provides a 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects. We will repair or replace faulty or defective frames or lenses free of charge for warranty claims made within 1 year of the delivery. We also offer repairs or replacement for problems experienced with vision during everyday use for claims made within 30 days of delivery. If the same product has been discontinued or is no longer available, then we may offer an exchange for a similar product or a refund.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Find a Store Location](https://www.oscarwylee.com.au/locations/full-store-list.html)