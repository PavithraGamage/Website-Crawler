# Source: https://www.oscarwylee.com.au/glasses/eye/blue

# Blue Eyes: Meaning for People with Blue Eyes, Characteristics and Styling
Published on February 27th, 2025
Updated on August 23rd, 2024  
Australia
Australia
New Zealand
Canada
Canadian French

Blue eyes are a distinctive and striking eye colour, making up approximately 8-10% of the population according to My Vision Organisation. Blue eyes carry particular characteristics and symbolism that set them apart from other eye colours. Read on for all there is to where blue eyes come from, their symbolism within various cultures, and how to make them truly pop.
[Definition of Blue Eyes](#Definition) [Blue Eye Health Concerns](#Concerns) [Glasses Frame Colours for Blue Eyes](#Frame) [UV Protection](#Protection)
Book an Eye Test With Oscar Wylee Today
We have knowledgeable optometrists at all our stores ready to help.
[Book an eye test](https://www.oscarwylee.com.au/booking)
## Different Types of Eye Colours
There are several different types of eye colours including blue, brown, amber, green, hazel, and grey.&nbsp;Comment end
## What are Blue Eyes?
Blue eyes refer to the iris of the eye, which appear blue in colour. The shades of blue eyes can range from a light blue-grey to a rich, medium blue. [Blue eyes](https://www.oscarwylee.com.au/glasses/eye/colour) lack pigmentation in the front layer of the iris, which is called the stroma. The iris holds multiple melanocytes which contain melanin. Blue eyes contain minimal amounts of melanin compared to brown eyes. This means that people with blue eyes do not have a blue pigment. They just have less brown pigment than people with darker eyes. Due to blue eyes having less melanin to absorb light, more light is scattered across the iris by collagen fibres to make eyes appear blue.
### Are Blue Eyes Rare?
Blue eyes can be considered rare. People with blue eyes make up approximately 8-10% of the population according to My Vision Organisation. Though it is the second most common eye colour in the world, its frequency pales in comparison to brown eyes which make up around 70-80% of the population. Blue eyes are most frequently found in Northern European countries such as Finland and Sweden.
### Where did Blue Eyes Come From?
Blue eyes are said to have first emerged around 6,000 to 10,000 years ago due to a genetic alteration. HERC2, which affects the function of the melanin producing OCA2, goes through a mutation which leads to reduced melanin production in the iris, creating the blue eye colour according to the National Institute of Health.
#### Are Blue Eyes More Sensitive to Light?
Blue eyes may be more sensitive to light. According to All About Vision, more melanin in the iris helps to prevent UV radiation from damaging the back of the eye. Blue eyes contain less melanin than eye colours such as brown, making them more [sensitive to light](https://www.oscarwylee.com.au/glasses/eye/light-sensitivity). Those with blue eyes may want to use sunglasses to ensure protection when entering sunny conditions.
Update Your Prescription Today
See our team in-store for help with updating your prescription. We offer bulk billed eye tests and quality eye care assistance.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
### What are the Health Concerns for those with Blue Eyes?
The health concerns for those with blue eyes include their higher risk of conditions such as macular degeneration and UV related eye damage. This is due to the lessened presence of melanin in the irises, which makes them more sensitive to UV rays. To mitigate these concerns, it is good for those with blue eyes to regularly wear sunglasses on sunny days as UV rays modify lens proteins and can worsen eyesight and potentially lead to eye conditions such as cataracts, according to the National Eye Institute.
#### Do Blue Eyes Have Any Cultural or Symbolic Meaning?
Blue eyes have cultural and symbolic meaning in Hinduism. Their colour is attributed to divine or spiritual beings, suggesting beauty and otherworldliness. For example, the Hindu deity Lord Krishna is often depicted with blue eyes, symbolizing his divine nature. The Turkish Blue Eye, popularly known as the Evil Eye, is an iconic symbol of Turkey since ancient times. It is a talisman that is believed to ward off evil and bring good luck.
### What Personality Traits are Linked to Blue Eyes?
Personality traits that are linked to blue eyes include calmness, wisdom and a gentle demeanour. However, these associated character traits are highly subjective. There is no concrete scientific evidence that suggests eye colour influences personality traits.
#### Can Blue Eyes Change Colour Over Time?
Blue eyes can appear to change colour depending on lighting, as certain lighting conditions can make them seem lighter or darker in colour. However, a permanent change in eye colour completely is rare and could be an indication of underlying health issues such as iris inflammation or a condition such as Horner’s Syndrome or Pigment Dispersion Syndrome. If the colour change is significant or sudden, it’s important to consult an eyecare professional.
### What Glasses Frame Colours are Best for Blue Eyes?
The [glasses frame colours](https://www.oscarwylee.com.au/glasses/hair-colour-and-hairstyle) that are best for blue eyes are tortoiseshell, brown, silvers and grey. Tortoiseshell and brown frames provide a warm frame to truly make blue eyes pop. The contrasting brown hues will bring extra focus to your blue irises. Contrastingly, you may want a glasses frame that also embodies the cool hues of blue. Silver or grey frames will compliment your blue eyes well. Silver and grey are more subtle, minimalist shades that won’t detract from the striking blue hues of your iris.
### What Makeup Suits Blue Eyes Best?
To enhance blue eyes, warm shades like copper, bronze, and peach eyeshadows provide a stunning contrast to the cool blue irises. Soft purples or mauves also provide a matching cooler colour palette to highlight blue eyes seamlessly. You may want to consider your glasses colour as well when applying makeup for blue eyes. For bolder frames, stick with more subdued eye makeup. For neutral frame colours, bold eye makeup will bring forward an interesting focal point on your face.
### How do Blue Eyes Compare to Other Colours in UV Protection?
Blue eyes provide less natural [UV protection](https://www.oscarwylee.com.au/glasses/eye/uv-blocking) compared to other eye colours. This is because blue eyes have less melanin which makes them more vulnerable to UV damage and eye conditions such as macular degeneration. It would benefit those with blue eyes to wear polarized lenses and sunglasses regularly to protect their eyes from UV radiation.
Read Blue Eyes: Meaning for People with Blue Eyes, Characteristics and Styling in other Oscar Wylee regions and their languages.
Australia
Australia
New Zealand
Canada
Canadian French
 
Look After Your Eyes At Oscar Wylee
We offer bulk billed eye tests for all eligible Medicare card holders.
[Book an eye test](https://www.oscarwylee.com.au/booking)
Major Health Funds Accepted In-store
For the purchase of frames and lenses, use your private health fund insurance to minimise how much you pay from your own pocket.
[Explore Health funds](https://www.oscarwylee.com.au/health-funds.html)