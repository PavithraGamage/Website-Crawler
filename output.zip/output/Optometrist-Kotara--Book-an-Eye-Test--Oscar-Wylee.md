# Source: https://www.oscarwylee.com.au/locations/optometrist-kotara.html

# Optometrist Kotara
Westfield Level 2, Shop 2040Corner Park Ave &amp; Northcott DrKotara NSW 2289
* Near OPSM
Opening hours
Monday9:00am - 5:30pm
Tuesday9:00am - 5:30pm
Wednesday9:00am - 5:30pm
Thursday9:00am - 9:00pm
Friday9:00am - 5:30pm
Saturday9:00am - 5:00pm
Sunday10:00am - 4:00pm
*Store hours reflect local standard trading hours and exclude public holidays
[Visit our Kotara Google Business page for directions, reviews, and updates.](https://g.page/r/CWBeg_V4y4z6EAE)
Book Appointment
[Call us: (02) 4041 2828](tel:(02) 4041 2828)
[Leave a Review!](https://g.page/r/CWBeg_V4y4z6EAg/review)
Our Reviews
Nicole Plummer
2 days ago
Great Service ???? Everyone was very helpful!
Tim Ford
1 week ago
Great service. Very helpful and attentive staff.
Paul Coxon
1 week ago
The team were extremely helpful, friendly and informative.
Anna Sharpe
2 weeks ago
Jeneva Partridge
2 weeks ago
Very happy with the service provided by the whole team on Saturday 15th Aug 2026 at Kotara Westfield... Store. Optometrist explained perscription clearly and staff happily booked me in for an eyetest even though i accidently booked online at Tuggerah Westfield.
See more
Phil C
2 weeks ago
Very good service.
Amy Hurrell
2 weeks ago
Fantastic and professional service at Kotara, every time.
Amanda Brigden
2 weeks ago
Had a wonderful experience, very helpful with any concerns I may have had and very helpful when choo...sing my eye wear as there was so much too choose from.
See more
Prem
2 weeks ago
Optometrist David was amazing. And all staffs were so nice and helpful.
Debbie Kennaugh
3 weeks ago
Awesome service and awesome frames ????
Kellie Carleton
3 weeks ago
tom furey
3 weeks ago
Went for an eye test for driving licence and for regular check. The staff were very friendly. Excell...ent communication before, during and after exam. Thank you.
See more
Michelle Maffione
1 month ago
Always professional, very speedy service , never disappointed!
Mark Collins
1 month ago
Great professional service, very friendly and helpful staff and a great range of frames. 10 out of 1...0
See more
Stuart Webb
1 month ago
Adrian Smith
1 month ago
Excellent customer service, friendly and helpful staff
jason higgerson
1 month ago
Was great
lena barber
1 month ago
Always a pleasure going to Kotara and seeing the lovely lady optometrist. She is so pleasant and kno...wledgeable with anything you ask. All the ladies are so helpful
See more
Linda Alcorn
1 month ago
Louisa conducted my eye test. She was thorough, warm and friendly. I am going back to check on my ma...cular vision and very pleased that she is being thorough and listening to my concerns. I would definitely recommend her to test your eyes. Staff in the front of the store were friendly and helpful and also gave me all the space and time I wanted to choose frames. Very happy customer.
See more
Stephen Sills
1 month ago
Tracy Metcalfe
1 month ago
Excellence service - friendly . Helpful . Professional
Ashley Moore
2 months ago
Lovely team, great service.
Mandi Drury
2 months ago
Simon was great, very informative and helpful. Recommended 100%
karla eastwood
2 months ago
Michelle Roach
2 months ago
We were so well taken care of by Jakayla. Thank you so much for your friendly advice and support wit...h our purchase!
See more
Melissa G
2 months ago
I want to sincerely thank Eleyna and her team at Kotara for going above and beyond to help me with a...n issue I was having with a pair of glasses. The lenses weren’t quiet correct, and although the glasses hadn’t been purchased from her store, Eleyna took the time to listen, offer advice, and make me feel completely comfortable about
returning them to get the problem resolved.
The level of professionalism, kindness, and genuine customer care shown was exceptional. There was no obligation for them to assist me, yet they were more than willing to help and point me in the right direction. It’s rare to come across service like this, and I truly appreciated their support.
Thank you, Eleyna and the team, for your understanding and for making what could have been a stressful situation so much easier.
See more
Afifah Intanjudin
2 months ago
Always a top notch customer service here. Post purchase care is first class.
ian hanbury
2 months ago
Barry Rees
2 months ago
highly recommended . Staff friendly and competent
David Powers
2 months ago
I had the most thorough and considerate eye test today from the staff and Simon at Oscar Wylee. Very... reasonable quotes on their range too, with no upselling, which was refreshing.
See more
Bron L
2 months ago
I had an excellent experience at Oscar Wylee Kotara.
My eye test was right on time, I didn’t have to... wait. The optometrist was patient, kind, took the time to understand my needs and explained the change to my prescription.
The staff were friendly, provided an upfront quote and help me pick out my frames. Thanks!
See more
Sharlene Dobbins
2 months ago
Friendly , attentive personalized service , no ask was too hard !
Amanda Homard
2 months ago
In comparison to other stores I have visited lately. Oscar Wylee Kotara were the best by far. They w...ere genuinely helpful, and their after sales service was brilliant- making sure everything was comfortable and "just right". Will be going back next time for sure.
See more
Carly James
2 months ago
Professional staff and optometrist was knowledgeable and professional.
R. Krajewski
2 months ago
I'm very happy with the appointment. The optometrist was very nice, thorough and didn't rush through... the check-up like I experienced somewhere else. I strongly recommend Oscar Wylee Optometrist in Kotara
See more
Vicki Howard
3 months ago
Very professional
Lana Johnston
3 months ago
Very friendly and attentive staff.
Clare Brinkley
3 months ago
Simon was very thorough and explained all my options clearly. Friendly and helpful service from all ...the staff.
See more
Ping
3 months ago
The staff were warm, friendly, and always willing to help. The optometrist demonstrated great profes...sional knowledge and explained everything clearly in a way that was easy to understand. Overall, it was a positive and reassuring experience.
See more
Veronika Edwards
3 months ago
Great service and consultation, love the selection of frames. Thanks all.
Susan Geoghegan
3 months ago
Fantastic experience having my annual eye check at Oscar Wylee at Kotara. Staff are very courteous, ...informative and helpful preparing quotes and processing my health cover claim direct so I only had to pay the gap.
The optometrist made me feel completely at ease and talked me through my eye health, at home actions to improve my eye health as well as options regarding eyewear. I felt I had choices and was part of the process.
Won’t hesitate to go back next year!
See more
Jodi McCarter
3 months ago
I spoke to a girl on the Wednesday who was amazing really great service honest opinions on frames an...d my face . Made appointment for the Thursday . The optometrist was fantastic and the staff on the day great . I don’t buy another glasses but Oscar Wylee
See more
Liz Arnold
3 months ago
All done very professionally
Lovely staff
ANTB Anthony
3 months ago
Oscar Wylie is the best optometry in NSW
Janet Wallace
3 months ago
Friendly, prompt. efficient service.
Explanation and advice provided.
Assistance provided with cho...osing new frames.
Great variety of frame options.
See more
Grace M
3 months ago
Faye Hayes
4 months ago
My experience was very positive
Simon was great he made me feel comfortable and relaxed
10/10
Sheree Painter
4 months ago
Gary J
4 months ago
Great service and Simon, the Optometrist, was everything I'd hoped for. Very communicative and thoro...ugh in his assessment and explanation.
See more
Lauren Munro
4 months ago
## Find an Optometrist in Kotara With Oscar Wylee
Visit us in Kotara, one of Newcastle’s largest retail destinations. You can book an appointment with your local optometrist in Kotara Westfield Shopping Centre. You'll find us on level 2, right near the Westfield Concierge. Our Oscar Wylee Kotara optometrists carry out bulk billed eye health tests for those with a valid Medicare card. There is ample onsite parking within the centre plus, the bus stops right outside the centre and the train station is a 20-minute walk away. 
If you’ve got some extra time, you can explore 182 hectares of amazing natural bush at the Blackbutt Nature Reserve, only a 5-minute drive from Kotara Westfield. Book an appointment with our on-site optometrists at Oscar Wylee Kotara to get a new or updated prescription and order your new pair of glasses on the same day! Choose from a wide range of frames in colourful styles with a touch of vintage.        
Meet Our Team
* Optometrist Partner
B.Optom
P.G.CertOcTher
Therapeutically Endorsed
* Retail Partner
Our Services
* Bulk Billed Eye Examinations
* Professional Frame Styling
* Frame adjustments and Repairs
* Visual Fields Testing
* Digital Retinal Scanning
Show All
## Find an Optometrist in Kotara, Newcastle for an Eye Health Test
An optometrist in Kotara, Newcastle can provide residents with essential eye care services and a wide selection of prescription and non-prescription eyewear. When you visit Oscar Wylee, you can look forward to services such as an eye health test in Kotara and assistance with your eyewear thanks to our optical dispenser, who can help you find a pair of prescription sunglasses or prescription glasses. Certain eye diseases can often go unnoticed until the condition worsens, so it is important to maintain regular eye tests, which we can help with.
Our team at Oscar Wylee Kotara cares about your vision and we have qualified optometrists in-store who can diagnose a range of eye conditions. If the optometrist detects any concerns, they will be happy to refer you to an eye doctor in the Kotara, Newcastle area. Be sure to bring an eligible Medicare card to make sure you can access our services for a bulk billed price as part of Australia’s Medicare system. The average price range for an optometrist in Kotara will vary depending on specific factors such as the patient’s overall health and visual needs.
## How to Find an Optometrist in Kotara, Newcastle?
To find an optometrist in Kotara, Newcastle, you can take certain steps that can help make it easier for you such as searching online, assessing the store’s opening hours and finding the directions to your chosen location. The steps on how to find an optometrist in Kotara are listed below.
1. Search online using the phrase, Kotara optometrist near me. This can also be done here on the website via our locations page.
2. Click on the Oscar Wylee link, which will take you directly to our Kotara optometrist store page.
3. See the store’s opening hours and where the store is located specifically.
4. Use the Kotara Google Business page link located under store hours to see the directions on how to get to the store.
You can also find an optometrist in Kotara by searching the keywords optometrist near me. If you have locations enabled on your smartphone and you’re in the Kotara area, our Kotara store page should appear easily for you to click on.
### Is it Hard to Get an Eye Appointment in Kotara, Newcastle?
No, it is not hard to get an eye appointment in Kotara. You can easily book an appointment to see an Oscar Wylee optometrist in Kotara right here on this page. At Oscar Wylee we have highly qualified optometrists available for bulk billed eye appointments, which can be booked online or in-store.
#### How to Compare Optometrists in Kotara to Each Other?
To compare optometrists in Kotara, you can use factors such as eye tests offered, health fund coverage, lens types and add-ons and eyewear offered. To take care of your vision and eye health, it is important to receive an eye test at least once every two years. There are different types of tests that can be performed in an eye test and not all optometrists may offer the same tests. Health funds can be used to help cover some of the cost of your frames and lenses. To find out if your health fund is accepted at Kotara optometrist in Newcastle, visit their website. In the case of Oscar Wylee, we accept all major health funds and provide on-the-spot claims in-store. There are many different lens options available for prescription glasses such as single vision, multifocal and high index lenses. Most optometrists in Kotara will offer these lenses although it is good to make sure. There are also lens add-ons available to enhance your glasses such as anti-reflective and blue light filters. Finally, if you are looking to purchase a pair of glasses after your eye test, you can compare the different styles and colours you are interested in from Kotara optometrists in Newcastle. Oscar Wylee offers a wide range of frames with vintage and modern inspirations in bold colours and subtle designs.
#### How to Find an Eyeglasses Shop in Kotara, Newcastle?
To find a glasses store in Kotara, you can try to follow these simple steps including searching online, selecting a convenient location and looking at their health insurance policies. The steps on how to find a glasses store in Kotara, Newcastle are listed below.
1. Search online using the phrase, glasses store in Kotara. This will provide you with various options for glasses stores in the whole Kotara, Newcastle area.
2. Select a glasses store that is most convenient for you to travel to.
3. Click the link to find out more information such as opening hours, exact location and directions to the glasses store in Kotara.
4. Read their health insurance policies to ensure you know what health benefits you have access to.
Our Oscar Wylee glasses store in Kotara, Newcastle offers primary eye care services such as comprehensive eye tests as well as other services performed by an optometrist and offers prescription and non-prescription eyewear.
##### Is it Possible to Purchase Prescribed Sunglasses in Kotara, Newcastle Without Seeing an Optometrist?
Yes and no, it is possible to [purchase prescribed sunglasses](https://www.oscarwylee.com.au/sunglasses.html) in Kotara, Newcastle without seeing an optometrist if you already have a prescription that has not expired. If your prescription is expired, you can book an eye test to receive an updated or new prescription which will require you to see an optometrist. This will ensure your prescription sunglasses are appropriate for your visual needs.
## Where is the Oscar Wylee Kotara Optometrist in Newcastle Located?
The Oscar Wylee Kotara optometrist is located at the Westfield Shopping Centre on level 2 near OPSM. Westfield Kotara can be found at Corner Park Avenue &amp; Northcott Drive.
### What is the Phone Number of the Oscar Wylee Kotara Store?
The Oscar Wylee Kotara optometrist store phone number is [(02) 4041 2828](tel:(02) 4041 2828). You can contact the Oscar Wylee Kotara store between the hours of 9 am and 5:30 pm on Monday, Tuesday, Wednesday and Friday, between 9 am and 9 pm on Thursdays, 9 am and 5 pm on Saturdays and 10 am and 4 pm on Sundays.
### What are the Reviews for Oscar Wylee Kotara Optometrist in Newcastle?
The many reviews for Oscar Wylee Kotara in Newcastle left by our various customers can be found here on the website and online when you search for Oscar Wylee Kotara. The reviews for Oscar Wylee Kotara are listed below.
* Justin Woweries:  Super impressed with all levels of service from having eyes tested to arranging new glasses - everyone was friendly and welcoming!
* Kate Winn-Clare:  I've been coming to Oscar Wylee now for several years. The staff are so friendly and helpful, always happy to help me out with what frames best suit my face. The optometrist is also very friendly and fantastic at his job. Always talks you through the steps and makes you feel very at ease and comfortable. Job well done Oscar Wylee, 5 stars from me.
* Paul McLean:  Eleyna and the staff at Kotara couldn't have been more helpful. We had an emergency eye issue that required immediate attention. The staff worked around accommodating our needs. Thanks so much!
* Vicki O'Beirne:  Simon is a very caring and thorough optometrist. I would highly recommend anyone to attend his practice. The staff were wonderful and very friendly. Thank you for a very pleasant experience.
#### What Treatments or Eye Care Processes are Done in the Oscar Wylee Kotara Optometrist Location?
The treatments or eye care processes done in the Oscar Wylee Kotara optometrist in Newcastle location include a tonometry test, a digital photograph, a slit lamp exam and a refraction test. Additional tests that may also be performed can include a visual field test and a dilated fundus exam. The treatments or eye-care processes that are done in the Oscar Wylee Kotara optometrist in Newcastle location are listed below.
* A Tonometry Test: An optometrist or optical dispenser will conduct a tonometry test which involves the use of a machine that will release small puffs of air into your eyes. This will assist with measuring pressure in the eye.
* A Digital Photograph: An optometrist or optical dispenser may take a digital photograph of your eye which can be kept on record to use in future appointments to evaluate any changes to your eye.
* Slit Lamp Test: A slit lamp test can be used to evaluate your eye health, by examining your cornea and iris which are the anterior and posterior of the eye.
* Refraction Test: During a refraction test, an optometrist will have you view an image through different lenses and ask you to confirm which helps you see the image clearer.
* Visual Field Test: A visual field test can assist with assessing your peripheral vision, which may be beneficial for identifying any signs of glaucoma.
* Dilated Fundus Exam: A dilated fundus exam can help an optometrist assess your health in more detail by getting a clear view of the retina. This test is typically carried out for patients with diabetes and those who may be at risk of developing retinal damage.
## How Many Optometrists Exist in Newcastle?
There are many optometrists that exist in Kotara, Newcastle that perform eye tests and provide glasses, including Oscar Wylee. The number of optometrists in Newcastle may depend on the number of residents and the possible demand for eye care services. However, there may not be an exact reason for the current number of Kotara, Newcastle optometrists. If you are in search of high-quality eye care services conducted by a passionate team, look no further than Oscar Wylee Kotara.
### What are the Other Closest Optometrist Locations to Kotara, Newcastle in Australia?
The other closest Oscar Wylee optometrist location to Kotara in Australia is Charlestown with 4 km in between stores and can be found at the Charlestown Square Shopping Centre on level 2, near Apple. The [Oscar Wylee Charlestown](https://www.oscarwylee.com.au/locations/optometrist-charlestown.html) store is a great option for locals to receive bulk billed eye tests and try on a wide range of modern and vintage-inspired frames.
### Come Get Your Eyes Tested at Oscar Wylee Kotara
You can have your comprehensive eye test performed by our Oscar Wylee Kotara optometrists with bulk billing offered for valid Medicare cardholders. Oscar Wylee has fully trained optometrists who can update your prescriptions or issue new ones if required. Oscar Wylee optometrists recommend getting regular eye tests once every year to two years to ensure your vision and eye health are at their best. Oscar Wylee has some of the best optometrists in Kotara, so come see our team for your primary eye care services!
### Oscar Wylee Accepts Major Health Funds
Our optometrists in Oscar Wylee Kotara have got you covered for prescription sunglasses and prescription glasses. Our team are happy to process your health fund claim at our eyeglasses shop, so ensure that you bring your eligible health fund card during your visit. If you have any questions regarding what your health fund can offer you, let us know.
### Expert Advice in Kotara
Oscar Wylee Kotara’s optometrists can offer their expert assistance to help you find prescription sunglasses and glasses as well as non-prescription, every time. Our team can get you fitted for glasses frames, you can then choose from our different lens options for your visual needs. If you want to know more about multifocal lenses or blue light lenses and whether they are right for you, you can ask our optometrists at Oscar Wylee Kotara.
Book Appointment
[Call us: (02) 4041 2828](tel:(02) 4041 2828)
[Leave a Review!](https://g.page/r/CWBeg_V4y4z6EAg/review)