# Source: https://www.oscarwylee.com.au/glasses/eye/chalazion

# Chalazion: Symptoms, Causes, Diagnosis, and Treatments
Published on October 23rd, 2023
Updated on May 7th, 2025
Australia
[Australia](https://www.oscarwylee.com.au/glasses/eye/chalazion)
[New Zealand](https://www.oscarwylee.co.nz/glasses/eye/chalazion)
[Canada](https://oscarwylee.ca/glasses/eye/chalazion)
[Canadian French](https://oscarwylee.ca/fr/glasses/eye/chalazion)
A chalazion is defined as inflammation of the eyelid that can turn into a
bump, caused by blocked oil glands in the eyelid. The symptoms of a chalazion include a bump on the eyelid that is red and
swollen, a feeling of scratchiness on the eyelid and a very large
chalazion can result in blurry vision. The main cause of a chalazion is a
blocked oil gland and other inflammatory conditions such as blepharitis,
ocular rosacea and seborrheic dermatitis. Some chalazion treatments can be done at home such as performing a gentle massage and
using a warm compress on the area. For more serious cases, medication or eye surgery may be recommended. If
you are wondering, how to get rid of a chalazion, keep reading and you
will learn about the chalazion symptoms, causes, diagnosis and
treatments.
How’s Your Eyesight?
If you are due for an eye test, book yours at Oscar Wylee to receive bulk
billing for valid Medicare cardholders.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Definition](#Definition) [Prevalence](#Prevalence)
[Symptoms](#Symptoms)
[Causes and Risk Factors](#Risk)
[Treatments](#Treatments)
## What is a Chalazion?
A chalazion is an eye condition that is characterised by swelling or inflammation on
the
eyelid
that can evolve into an enlarged bump that typically has a spot of pus
in the centre. A chalazion is caused by blocked oil glands in the eye
and may start out as a stye. This eye condition is sometimes difficult
to notice at first as it is painless, however, if it becomes infected
it can cause pain and redness around the area. According to the
American Academy of Ophthalmology, a chalazion may affect a person’s
vision as it can grow large enough to press on the eyeball, leading to
blurred eyesight.
### What is a Chalazion Also Known as?
A chalazion is also known as a chronic sterile lipogranuloma, according to an article published in the National Library of
Medicine. Other terms for chalazia, the plural of a chalazion,
include eyelid cyst and meibomian cyst. The meibomian gland is an
oil gland found along the edge of the eyelid.
### What Part of the Eye Does a Chalazion Affect?
The part of the eye that a chalazion affects is the eyelid just behind
the eyelashes, most commonly the upper eyelid. A chalazion looks like a bump on the eyelid that may have a spot of
pus at the centre and can look red and swollen. A chalazion can
start as a small amount of swelling and turn into a noticeable bump.
A chalazion can grow quite large, so much so that it can affect a
person’s vision as it presses on the eyeball.
#### Does a Chalazion Affect Both Eyes?
Yes, a chalazion can affect both eyes, however, it is more common to occur in one eye and can appear
on the upper eyelid and the lower eyelid. A chalazion can form on
both eyelids at the same time and can grow to a large enough size
to disrupt a person’s vision by pressing on the eyeball.
## How Common is a Chalazion?
While a chalazion is a [common eye problem](https://www.oscarwylee.com.au/glasses/eye/common-problems), according to an article published in the National Library of
Medicine that was last updated in July 2023, the exact&nbsp; incidence of it in the US or worldwide has not been
documented.
A chalazion is more common on the upper lid than the lower lid and
typically occurs in one eye. Chalazion is not a common eye problem in
children. According to the Cleveland Clinic, chalazions are common in
adults between the age of 30-50.
## What are the Symptoms of a Chalazion?
The symptoms of a chalazion include a painless bump on the eyelid, a pus spot in the centre of the bump, a
feeling of scratchiness in the eye and irritation that can cause
watery eyes and blurred vision.
If a chalazion is infected it can cause additional symptoms such as
pain, swelling and redness around the bump. According to Medical News
Today, a chalazion will start out as a small, painless inflammation or
bump on the eyelid which may slowly grow into a bigger lump as it
progresses.
## What are the Causes and Risk Factors of a Chalazion?
The causes and risk factors of a chalazion include a blocked oil gland in the eyelid, rosacea, seborrheic dermatitis and
blepharitis.
The causes of a chalazion and their definitions are listed
below.
* Blocked oil gland in the eyelid: The
main cause of a chalazion is a blocked or clogged oil gland in the
eyelid, called a meibomian gland.
* Rosacea:
Rosacea is a skin inflammation condition that can affect the eye,
which is called ocular rosacea, and can lead to a chalazion due to
meibomian gland dysfunction.
* Seborrheic dermatitis:
Seborrheic dermatitis is a skin condition that causes inflammation
of the eyelid, affecting the meibomian glands which can result in a
chalazion.
* Blepharitis: If a person has blepharitis they are more at risk of developing
chalazion along with other eye conditions such as a stye or chronic
conjunctivitis.
### 1. Blocked Oil Gland in the Eyelid
The main cause of a chalazion is a blocked or clogged oil gland in the
eyelid, called meibomian glands.
Meibomian glands, also known as glandulae tarsales, are glands found
in eyelids directly behind the eyelashes and they form the
superficial layer of the tear film by secreting lipids, according to
the American Academy of Ophthalmology. A blocked oil gland may be
caused by many eye conditions and diseases such as allergic
conjunctivitis, rosacea and bacterial infection.
### 2. Rosacea
Rosacea is a skin inflammation condition that can affect the eye, referred to
as ocular rosacea, and can lead to a chalazion due to meibomian
gland dysfunction. According to the National Rosacea Society, a study found that 85%
of patients with ocular rosacea had meibomian gland dysfunction
which causes the glands to become blocked which causes a chalazion
and inflammation of the eyelid. Ocular rosacea specifically targets
the eyes and can cause redness, itching or inflammation around the
eyes, as well as blepharitis which is another eye condition.
### 3. Seborrheic Dermatitis
Seborrheic dermatitis is
a skin condition that causes inflammation of the eyelid, affecting
the meibomian glands which can result in a chalazion.
Seborrheic dermatitis can cause dandruff in the eyebrows and eyelids
and can lead to blepharitis, which is another risk factor for a
chalazion. Seborrheic dermatitis is a chronic form of eczema with
symptoms such as flaking skin, rash and itchiness, according to the
National Eczema Association.
### 4. Blepharitis
If a person has blepharitis they are more at risk of developing a
chalazion along with other eye conditions such as a stye or chronic
conjunctivitis, according to the Mayo Clinic. [Blepharitis](https://www.oscarwylee.com.au/glasses/eye/eyelids-inflammation) is an eye condition characterised by eyelid inflammation caused by
bacteria and/or issues with the oil glands in the eyes. The symptoms of blepharitis include swollen eyelids, red eyelids,
and itchy, sore or burning eyes. Blepharitis can be caused by dry
eyes, allergies, eyelid mites as well as skin conditions that also
cause a chalazion including seborrheic dermatitis and ocular
rosacea. Like a chalazion, blepharitis is not contagious and can
occur in both eyes.
Find Your Nearest Oscar Wylee Store
Come in and see the team. We are dedicated to helping answer your
questions and find your perfect pair of glasses.
[Find a store](https://www.oscarwylee.com.au/locations/)
## How is a Chalazion Diagnosed?
A chalazion can be diagnosed by an optometrist or ophthalmologist, also known as
an eye doctor, through an eye test. According to the Cleveland Clinic, the way a chalazion is diagnosed
is through a health history, an external eye examination and an eyelid
examination. A health history will allow the eye care professional to
identify any underlying issues that may be causing or contributing to
the chalazion. An external eye examination looks at the outside of the
eye including the eyelid, eyelashes and skin texture. Finally, an
optometrist or ophthalmologist will perform a thorough eyelid exam to
look at the base of the eyelashes and the opening of the oil glands in
the patient's eyes.
### How Serious is a Chalazion?
A chalazion is not typically a serious eye condition, rather it is an inflammatory lump on the eyelid that will
typically clear with proper treatment or sometimes by itself.
According to the Royal Victorian Eye and Ear Hospital,
if a chalazion is persistently recurring in the same spot, it may be
a sign of a serious condition and should be examined by a healthcare
professional.
#### Can a Chalazion be Cancerous?
No, a chalazion can not be cancerous, however, it is very similar in
appearance to sebaceous carcinomas which is one of the rarest eye
cancers. According to an article published in the National Library of
Medicine titled, Differentiation between chalazion and sebaceous carcinoma by
noninvasive meibography, sebaceous carcinomas of the eyelid is known for masquerading
clinically as a chalazion or other benign lesions. Sebaceous
carcinomas can be treated with surgery and radiotherapy.
## What are the Best Chalazion Treatments?
The treatments for a chalazion in the eyelid include a gentle massage, warm compress, eye surgery and medication.
Treatments can vary depending on the severity of the chalazion and
whether there is a suspected infection. The treatments for a chalazion
and their definitions are listed below.
* Gentle massage: Gently massaging a
chalazion can be used as an initial treatment to encourage a blocked
oil gland to open and drain. Make sure to use clean hands when
massaging to reduce the risk of infection.
* Warm compresses:
A warm compress can be used to treat a chalazion as a way of helping
the blocked oil gland in the eye open up. This can be done multiple
times a day for 10-15 minutes at a time.
* Eye surgery:
Eye surgery is a treatment option for a chalazion which is required
with more severe or persistent cases. This is performed to drain the
chalazion so it can heal.
* Medication:
Chalazion medication may be prescribed if your healthcare provider
believes the chalazion is infected. The medication used to treat an
infected chalazion includes antibiotics and steroid shots.
### 1. Gentle Massage
Gently massaging a chalazion can be used as an initial treatment to encourage a blocked oil
gland to open and drain. To perform the massage, apply light to medium pressure to the
affected area, which is a small bump on the lid, using clean hands
to reduce the risk of infection. An eyelid massage can be performed
several times a day for several minutes to promote drainage,
according to Medical News Today.
### 2. Warm Compresses
A warm compress can be used to treat a chalazion as a way of helping the blocked
oil gland in the eye open up and drain.
The cloth's warmth helps soften the oil that has turned hard and
blocked the ducts, allowing for easy drainage and healing, according
to the American Optometric Association. A warm compress is comprised
of a cloth or washer and warm, clean water. Simply soak the cloth in
warm water, ring out the excess water and rest over the affected eye
for approximately 10-15 minutes, multiple times a day.
### 3. Eye Surgery
Eye surgery is a treatment option for a chalazion which is required with more
severe or persistent cases.
A severe case of chalazia can include if the bump is affecting a
person’s vision. According to an article published in the National
Library of Medicine, recurring and persistent chalazia require
surgical intervention. Eye surgery typically occurs at an
ophthalmologist's office using local anesthesia and is performed to
remove the fluid from the chalazion so it can drain and heal. For
recurring cases, an ophthalmologist may take a biopsy of the
chalazion to test if there is a more serious issue occurring,
according to the American Academy of Ophthalmology.
### 4. Medication
Medication may be prescribed for a chalazion if your healthcare provider
believes it is infected. The medication used to treat an infected chalazion includes
antibiotics, which can be in the form of ointments, eye drops or
tablets as well as steroid shots which, according to the American
Academy of Ophthalmology, can help reduce swelling if the chalazion
is very swollen. An infected chalazion will typically be painful and
appear red and swollen. According to Medscape, a recurring or
chronic chalazion may be treated long-term with oral tetracycline,
doxycycline, or metronidazole.
### How Long Can a Chalazion Take to Heal?
How long a chalazion takes to heal can depend on whether it is
treated. According to the Cleveland Clinic, an untreated chalazion can take approximately four to six weeks to
heal.
If treated, a chalazion can take up to a week to heal.
It is important to seek assessment from an eye care professional if
you suspect you have a chalazion as they can provide proper
diagnosis and treatment.
#### Does a Chalazion Go Away on its Own?
Yes, a chalazion may go away on its own.
Most chalazia will clear up within a few weeks to a month or may
require minimal medical treatment, according to the American
Optometric Association. If your chalazion is not clearing up, book
an appointment with an optometrist or another eye care
professional.
## What Might Happen if a Chalazion Gets Infected?
A chalazion may occasionally become infected as a result of bacteria entering the
oil gland in the eye. According to Medical News Today, signs of an infected chalazion
include pain, swelling, redness and soreness. If you suspect your
chalazion has become infected, seek medical attention from a doctor or
another healthcare professional for treatment. Treatments for the
infection include antibiotics which may be in the form of tablets, eye
drops or ointment. If an infected chalazion is left untreated, it may
damage a person’s eyesight. Medical News Today also recommends you do
not squeeze or try and pop a chalazion as it can increase your risk of
infection.
### What to do to Prevent a Chalazion Infection?
The most important aspect of preventing a chalazion infection is
good hygiene. According to the Cleveland Clinic, the four essential components of good hygiene for preventing a
chalazion include hand-washing, face-washing, contact lens hygiene
and make-up hygiene. Contact lens hygiene and care requires handling the contacts with
clean hands and making sure to thoroughly wash and disinfect them
with contact lens solution. Make-up hygiene involves disposing of
products when they are past their expiration date, regularly washing
make-up brushes and beauty blenders and properly cleansing the face
of makeup at night.
#### Can Wearing Glasses Reduce the Chance of a Chalazion Infection?
No, wearing glasses cannot reduce the chance of a chalazion
infection.
Glasses have no bearing on treating or not treating a chalazion,
according to the American Academy of Ophthalmology. However,
contact lenses may increase a person’s risk of developing a
chalazion if they are not cleaned and cared for properly.
### When to Call a Doctor about a Chalazion?
It is important to call a doctor or another healthcare professional
about a chalazion if it shows signs of infection, it is causing extreme pain or if it
persists longer than a few weeks. Signs of an infected chalazion include pain, swelling and
redness. In general, it is important to have a chalazion looked at
by an eye care professional no matter the circumstances as they can
provide treatment and assess the health of the eye.
#### What is the Difference Between a Chalazion and a Stye?
While a chalazion and a stye may appear visually similar as they
are both lumps on the edge of a person’s eyelid, they are
different eye conditions. One of the differences between a
chalazion and a stye is pain. A stye is typically painful whereas
a chalazion is not unless it becomes infected. They also have different causes as a chalazion is caused by a blocked oil
gland and a stye typically develops due to a bacterial
infection. A chalazion and stye have similar treatments including using a
warm compress or surgery to drain the area if they affect a
person’s vision.
#### Does Chalazion Affect the Lower or Upper Eyelid?
A chalazion can affect both the lower and upper eyelid, but is more common on
the upper eyelid. According to the Royal Victorian Eye and Ear Hospital, not only
can a chalazion affect both the lower and upper eyelid, it is also
possible that a person may have multiple lesions.
### When is Surgery Necessary to Treat a Chalazion?
Surgery is typically only necessary to treat a chalazion if it is persistent
or more severe. If a chalazion is persistent and has not gone away after 6-8
weeks, or if it is severe and impacting vision, it may be surgically
drained by an ophthalmologist, according to the Royal Victorian Eye
and Ear Hospital.
Read Chalazion: Symptoms, Causes, Diagnosis, and Treatments in other
Oscar Wylee regions and their languages.
Australia
[Australia](https://www.oscarwylee.com.au/glasses/eye/chalazion)
[New Zealand](https://www.oscarwylee.co.nz/glasses/eye/chalazion)
[Canada](https://oscarwylee.ca/glasses/eye/chalazion)
[Canadian French](https://oscarwylee.ca/fr/glasses/eye/chalazion)
Are You in Need of an Eye Test?
We recommend everyone has a complete eye test at least once every two
years. Book yours at Oscar Wylee.
[Book your eye test](https://www.oscarwylee.com.au/booking)
Claim In-store at Oscar Wylee
Come in and see the team for a new pair of frames and your health fund
may help cover the cost.
[Explore Health Funds](https://www.oscarwylee.com.au/health-funds.html)