# Source: https://www.oscarwylee.com.au/locations/optometrist-craigieburn.html

# Optometrist Craigieburn
Craigieburn CentralShop D32, 340 Craigieburn RoadCraigieburn VIC 3064
* Near Coles
Opening hours
Monday9:00am - 5:30pm
Tuesday9:00am - 5:30pm
Wednesday9:00am - 5:30pm
Thursday9:00am - 7:00pm
Friday9:00am - 5:00pm
Saturday9:00am - 5:00pm
Sunday10:00am - 5:00pm
*Store hours reflect local standard trading hours and exclude public holidays
[Visit our Craigieburn Central Google Business page for directions, reviews, and updates.](https://g.page/r/CYw90-ORWm2DEBM)
Book Appointment
[Call us: (03) 8313 5814](tel:(03) 8313 5814)
[Leave a Review!](https://g.page/r/CYw90-ORWm2DEBM/review)
Our Reviews
Emma Khoury
22 hours ago
Professional and knowledgable
Korkut isik
2 days ago
Fantastic customer service
SHALINI SONI
2 weeks ago
Amazing experience… optometrist was incredibly informative and tested my 5 year old daughter’s eye w...ith so accuracy!
See more
Ario Leaosavaii
2 weeks ago
Pleasant experience thank you
Niki S
2 weeks ago
I’ve always enjoyed visiting the Craigieburn store as the staff always provide a positive and warm e...xperience. Lisa is wonderful and she has been my optometrist for the last 3-4 years. Vineet assited me front of house and he is wonderful and professional. The entire process was seamless. Friendly staff and great service. Thank you for your customer care.
See more
Harneet Kaur
3 weeks ago
Tearoa Tangianau
1 month ago
Vinit provides good ccs service
Glory Edgell
1 month ago
I had an excellent experience. Staffs are well educated and make me feel comfortable with the option...s available. I highly recommend this place.
See more
Md Nasar
1 month ago
Jagath Herath
1 month ago
Great experiance and 100% care I recomend their service is above expectation.
Gurpreet Singh Mander
1 month ago
Ed
1 month ago
I saw Li Sang optometrist she was extremely careful  and really good
Mia De Belen
1 month ago
Excellent
Raboy Mendez
1 month ago
Jacintah Mcvean
1 month ago
First time at Oscar Wylee and the service was impeccable. So in depth and caring, they seem to reall...y care for their customers and not just about sales like the other place ive been going for years for my eye care.
100% recommended
See more
Lisa DiFalco
1 month ago
Great service. Jim was wonderful and friendly, conducted a thorough eye test. Vinit was helpful when... choosing and purchasing frames. Highly recommend.
See more
Rubina Mayar
2 months ago
Valma Roach
2 months ago
Lovely staff at Oscar Wylee in Craigieburn who go out of their way to make sure that you are happy w...ith your choice of frames etc for your new glasses.
See more
Dylan Lai
2 months ago
I had a wonderful experience at Oscar Wylee, the people that work there are very experienced at what... they do, like helping me pick out my frames and showing me which ones fit my face. The Optometrist that helped me with my eye test is an expert and very professional, meaning she knows what she's doing, her name is Li Sang Lay. So I'm thankful for the people at Oscar Wylee Craigieburn for helping me.
See more
Baan Sako
2 months ago
Visited Oscar Wylee Craigieburn today &amp; was served by Sharmane, Lisce and Vinit. The customer servic...e was amazing by Sharmane &amp; Vinit and really appreciated the education and care Lisce gave. Will be coming here from now on :)
See more
Jim
2 months ago
John and the team are absolutely amazing!!! Next-level testing service and I just love the glasses h...ere; so stylish and very affordable!
See more
Ramita Shahi
2 months ago
Visited to get my glasses adjusted, and the process was fast and efficient. The staff were friendly ...and took the time to assist with all my enquiries.
See more
Shyanakie
3 months ago
Great service &amp; good frame designs. Staff are helpful &amp; great to deal with. A special thanks to Vini...t for an excellent service, always helpful &amp; good customer service. Thank you.
See more
Joanna Brown
3 months ago
Vinit helped me get my glasses fixed after they snapped, and even took the extra effort to get them ...cleaned and resized so they fit better than before. Quick and friendly service thank you :)
See more
Carol Ingham
3 months ago
Excellent quick polite service :) thank you ;)
Deirdre Riley
3 months ago
Staff were amazing.  So helpful and great customer service. Would recommend to anyone.
Gulhan Arslan
3 months ago
(Translated by Google) Vinit is good dispenser
(Original)
Vınıt ıs good dıspenser
Marisa Ierino
3 months ago
Always very friendly &amp; helpful.  Great service.
Zury
3 months ago
I had a great experience with the optometrist, I believe her name was  Karina in craigieburn . She w...as very professional, patient, and made me feel comfortable throughout the whole appointment. My overall experience was excellent.
See more
Caitlin Wright
3 months ago
Great experiance at this store. My eye exam with Lisa was very thoughtful and thorough. John did an ...amazing job at helping me with my lenses and checking to make sure I maximised my insurance benefits- which I greatly appreciate.
Would highly recommend ????
See more
Bhawna Sharma
3 months ago
Very nice experience there . I enjoy customer service and doctors treatment also . They both are rea...lly good.
See more
RAMIS ISSAC
3 months ago
Friendly staff and outstanding communication and understanding
Karina Lama
3 months ago
Excellent service from John at Oscar wylee. He was very helpful, professional, and friendly. Made th...e whole experience smooth and enjoyable. Really appreciate the great customer service!
See more
Romee Sresta
3 months ago
Very kind and supportive and friendly as you can be open about all of your issues and queries. Thank...you for your service Li Sang and Vinit
See more
Dan B
3 months ago
I recently switched to Oscar Wylee after years of going to Specsavers, and the difference was honest...ly night and day. From the moment I walked in, the customer service, professionalism, and overall experience were on a completely different level.
The staff at Oscar Wylee were welcoming, knowledgeable, and genuinely took the time to help me choose the right frames without any pressure. The optometrist was extremely thorough and explained everything clearly, making the eye test feel professional and personalised rather than rushed.
Compared directly to Specsavers, Oscar Wylee is better in every way, better customer service, better quality frames, better attention to detail, better store presentation, and a much more premium experience overall. At Specsavers I often felt like just another number, but at Oscar Wylee the care and attention given to customers was outstanding.
The frame quality feels far superior, the styles are modern and stylish, and the staff actually care about making sure you leave happy. Pricing was also very reasonable considering the level of service and quality received.
I can confidently say Oscar Wylee has completely won me over, and I honestly wish I made the switch earlier. Anyone looking for new glasses or an eye test should seriously consider using Oscar Wylee instead of Specsavers. Highly recommended and easily one of the best optometrist experiences I’ve had in Australia.
See more
Padma Mohan Raj
3 months ago
The staff and optometrist are very polite and  helpful. I recommend this Oscar wylee.
Jashan Preet
3 months ago
Vinit provides good cx service
Swati
3 months ago
Mathew Ford
3 months ago
Very friendly and quick service by two very polite ladies
Karen Dick
3 months ago
John you are amazing, very professional, friendly and a great help. You made my experience easy and ...fun.  Could not have asked for better service. Highly recommend.
See more
Hatice Rifat
4 months ago
I had a great experience during my eye checkup today. Huge thanks to Vinit and Lisa for being so pro...fessional and welcoming. They made the whole process smooth and comfortable. Highly recommend this team for their excellent care!
See more
Will Gallon
4 months ago
Vinit is a great customer service and support!
Kiyan Ranjbakhsh
4 months ago
I love this place I always get all my glasses here and the staff are very nice today my glasses were... loose and we got it fixed and they didn’t charge us the staff are very nice and I highly recommend this place for everyone
See more
Elham Ahmadi
4 months ago
Vinit thank you so much for your support.
Tiana Feo
4 months ago
Vinit was very friendly and helpful
Hilal Ozcan
4 months ago
John and Vinit were very helpful and provided me with styling advice which was a plus in service tha...nk you so much.
See more
Marc Dobber
4 months ago
Great service, from optometrist to front of store staff. Very happy with glasses and with the advice... from all staff. Highly recommended.
See more
Rola shamoukh
4 months ago
Excellent  service, thank you to Lisa and vinit
Naru Lafaele
4 months ago
Nancy tauu
4 months ago
Wonderful service from Vinit at the craigieburn branch
I recommend all to come here and seek assist...ance from Vinit
See more
## Find an Optometrist in Craigieburn With Oscar Wylee
Our Oscar Wylee store in Craigieburn Central Shopping Centre is situated in the heart of Craigieburn and offers a modern shopping experience, combining the best elements of both indoor and outdoor shopping. Our fully qualified and registered Craigieburn optometrist is ready and able to offer you a Medicare bulk billed eye health test. Speak to our friendly staff and they can help you find the perfect pair of glasses for you by browsing through our affordable and fashion-forward frames. Craigieburn Centre has over 2,600 parking spaces for your shopping convenience as well as multiple bus stops close by. 
Craigieburn Centre offers a wide variety of stores and services with over 160 stores including Woolworths, Aldi, Kmart, TK Maxx, and United Cinemas as well as plenty of dining options, all conveniently located on the ground level. Why not go exploring the mall after your eye test with Oscar Wylee Craigieburn? Plan a visit to Oscar Wylee today and experience some of the best optometrist services in Craigieburn, Australia.        
Meet Our Team
* Optometrist
BVisSci, MOptom
* Store Manager
Our Services
* Bulk Billed Eye Examinations
* Professional Frame Styling
* Frame Adjustments and Repairs
* Visual Fields Testing
Show All
## Find an Optometrist in Craigieburn, Melbourne for an Eye Health Test
An optometrist can be found in Craigieburn, Melbourne for an eye health test as well as for other eye care services. Oscar Wylee Craigieburn offers bulk billed eye tests for valid cardholders, courtesy of Australia’s Medicare system. The average price range for an optometrist in Craigieburn can vary depending on factors such as the patient’s overall health and visual needs.
Eye tests in Oscar Wylee Craigieburn, Melbourne, will assess a patient’s vision as well as check for signs of eye disease. If a patient requires more advanced treatment, they will be referred to an eye doctor, known as an ophthalmologist in Australia. For an eye health test, choose Oscar Wylee Craigieburn in Melbourne as we have dedicated optometrists and optical dispensers in-store to help with all your eye care needs. You can also browse our great selection of stylish frames for your optical glasses or prescription sunglasses.
## How to Find an Optometrist in Craigieburn, Melbourne?
To find an optometrist in Craigieburn, Melbourne, you can take certain steps that can help make it easier for you such as searching online, assessing the store’s opening hours and finding the directions to your chosen location. The steps on how to find an optometrist in Craigieburn are listed below.
1. Search online using the phrase, Craigieburn optometrist near me. This can also be done here on the website via our locations page.
2. Click on the Oscar Wylee link, which will take you directly to our Craigieburn optometrist store page.
3. See the store’s opening hours and where the store is located specifically.
4. Use the Craigieburn Google Business page link located under store hours to see the directions on how to get to the store.
You can also find an optometrist in Craigieburn, Melbourne by searching the keywords optometrist near me. If you have locations enabled on your smartphone and you’re in the Craigieburn area, our Oscar Wylee Craigieburn store page should appear easily for you to click on.
### Is it Hard to Get an Eye Appointment in Craigieburn, Melbourne?
No, it is not hard to get an eye appointment in Craigieburn. You can easily book an appointment to see an Oscar Wylee optometrist in Craigieburn right here on this page. At Oscar Wylee we have highly qualified optometrists available for bulk billed eye appointments, which can be booked online, over the phone, or in-store.
#### How to Compare Optometrists in Craigieburn to Each Other?
To compare optometrists in Craigieburn, you can use factors such as eye tests offered, health fund coverage, lens types and add-ons and eyewear offered. To take care of your vision and eye health, it is important to receive an eye test at least once every two years. There are different types of tests that can be performed in an eye test and not all optometrists may offer the same tests. Health funds can be used to help cover some of the cost of your frames and lenses. To find out if your health fund is accepted at a Craigieburn optometrist in Melbourne, visit their website. In the case of Oscar Wylee, we accept all major health funds and provide on-the-spot claims in-store. There are many different lens options available for prescription glasses such as single vision, multifocal and high index lenses. Most optometrists in Craigieburn will offer these lenses although it is good to make sure. There are also lens add-ons available to enhance your glasses such as anti-reflective and blue light filters. Finally, if you are looking to purchase a pair of glasses after your eye test, you can compare the different styles and colours you are interested in from the optometrists in Craigieburn, Melbourne. Oscar Wylee offers a wide range of frames with vintage and modern inspirations in bold colours and subtle designs.
#### How to Find an Eyeglasses Shop in Craigieburn, Melbourne?
To find a glasses store in Craigieburn, you can try to follow these simple steps including searching online, selecting a convenient location and looking at their health insurance policies. The steps on how to find a glasses store in Craigieburn, Melbourne are listed below.
1. Search online using the phrase, glasses store in Craigieburn. This will provide you with various options for glasses stores in the whole Craigieburn, Melbourne area.
2. Select a glasses store that is most convenient for you to travel to.
3. Click the link to find out more information such as opening hours, exact location and directions to the glasses store in Craigieburn.
4. Read their health insurance policies to ensure you know what health benefits you can access.
Our Oscar Wylee glasses store in Craigieburn, Melbourne offers primary eye care services such as comprehensive eye tests as well as other services performed by an optometrist and offers prescription and non-prescription eyewear.
##### Is it Possible to Purchase Prescribed Sunglasses in Craigieburn, Melbourne, Without Seeing an Optometrist?
Yes and no, it is possible to [purchase prescribed sunglasses](https://www.oscarwylee.com.au/sunglasses.html) in Craigieburn, Melbourne without seeing an optometrist if you already have a prescription that has not expired. If your prescription is expired, you can book an eye test to receive an updated or new prescription which will require you to see an optometrist. This will ensure your prescription sunglasses are appropriate for your visual needs.
## Where is the Oscar Wylee Craigieburn Optometrist Located in Melbourne?
The Oscar Wylee Craigieburn optometrist is located in Craigieburn Central Shopping Centre near Coles. The Craigieburn Central Shopping Centre is located in the heart of Craigieburn on Craigieburn Road.
### What is the Phone Number of Oscar Wylee Craigieburn Optometrist Store?
The Oscar Wylee Craigieburn optometrist store phone number is (03) 8313 5814. You can contact the Oscar Wylee Craigieburn store between the hours of 9 am and 5:30 pm from Monday to Wednesday, 9 am and 9 pm on Thursdays and Fridays, 9 am and 5 pm on Saturdays and 10 am and 5 pm on Sundays.
### What are the Reviews for Oscar Wylee Craigieburn Optometrist in Melbourne?
The many reviews for Oscar Wylee Craigieburn optometrist in Melbourne, left by our various customers can be found here on the website and online when you search for Oscar Wylee Craigieburn optometrist. The reviews for Oscar Wylee Craigieburn optometrist are listed below.
* Sujith De Silva:  Great service, good quality frames for a good price. Li Sang Lay was a very thorough optometrist, would highly recommend going here due to the very experienced staff such as John at Craigieburn Oscar Wylee!
* Sandra Lewis-Hamilton:  I rated my experience attending Oscar Wylee for my eye test 5 stars because the staff were efficient, thorough and attentive.
* Sadek Rashed:  Great service all round! Friendly staff who were helpful with every question I had. Well done Oscar Wylee team!
* Furqan Mahmud: Good facility and excellent staff.
#### What Treatments or Eye Care Processes are Done in the Oscar Wylee Craigieburn Optometrist Location?
The treatments or eye care processes done in the Oscar Wylee Craigieburn optometrist Melbourne location include a tonometry test, a slit lamp exam and a refraction test. Additional tests that may also be performed can include a visual field test and a dilated fundus exam. The treatments or eye-care processes that are done in the Oscar Wylee Craigieburn optometrist Melbourne location are listed below.
* A Tonometry Test: An optometrist or optical dispenser will conduct a tonometry test which involves the use of a machine that will release small puffs of air into your eyes. This will assist with measuring pressure in the eye.
A Digital Photograph: An optometrist or optical dispenser
may take a digital photograph of your eye which can be kept on
record to use in future appointments to evaluate any changes to
your eye.

* Slit Lamp Test: A slit lamp test can be used to evaluate your eye health, by examining your cornea and iris which are the anterior and posterior of the eye.
* Refraction Test: During a refraction test, an optometrist will have you view an image through different lenses and ask you to confirm which helps you see the image clearer.
* Visual Field Test: A visual field test can assist with assessing your peripheral vision, which may be beneficial for identifying any signs of glaucoma.
* Dilated Fundus Exam: A dilated fundus exam can help an optometrist assess your health in more detail by getting a clear view of the retina. This test is typically carried out for patients with diabetes and those who may be at risk of developing retinal damage.
## How Many Optometrists Exist in Craigieburn, Melbourne?
There are many optometrists that exist in Craigieburn, Melbourne to provide eye tests and glasses, including Oscar Wylee. The number of optometrists available in an area will typically depend on the population. At Oscar Wylee Craigieburn, we offer excellent optometry services including eye tests performed by skilled optometrists using high-quality equipment. We also have a wide range of fashion-forward frames that customers can browse in a large selection of sizes and colours. If you’re looking for an optometrist in Craigieburn, choose Oscar Wylee and we will take care of your optometry and eyewear needs.
### What are the Other Closest Optometrist Locations to Craigieburn, Melbourne in Australia?
The other closest Oscar Wylee optometrist locations to Craigieburn in Australia are Epping, Broadmeadows and Plenty Valley. The locations and their distance from Craigieburn are listed below.
* Epping:  Epping is a suburb approximately 16 km away from Craigieburn where you can find optometrists including Oscar Wylee. [Oscar Wylee Pacific Epping](https://www.oscarwylee.com.au/locations/optometrist-epping.html) is located on the ground floor of the Pacific Epping Shopping Centre, where our team are available to provide a range of eye care services.
* Broadmeadows:  Broadmeadows is close to Craigieburn, around 13 km. The [Oscar Wylee Broadmeadows](https://www.oscarwylee.com.au/locations/optometrist-broadmeadows.html) store is located in Broadmeadows Central, next to My Chemist. An Oscar Wylee optometrist in Broadmeadows can provide bulk billed eye tests and prescription updates.
* Plenty Valley:  Plenty Valley is close to Craigieburn, around 20 km. The [Oscar Wylee Plenty Valley](https://www.oscarwylee.com.au/locations/optometrist-plenty-valley.html) store is located in Westfield Plenty Valley, near Kmart. Here you will find excellent eye care and eyewear services including eye tests and frame styling.
### Bulk Billed Eye Tests in Craigieburn
Oscar Wylee Craigieburn offers optometrist-led eye tests and eye care processes in-store for valid Medicare cardholders. Come in and have your vision tested, your eye health checked for certain diseases and your prescription updated. Book an eye test with our trusted optometrist and Oscar Wylee in Craigieburn Central can keep you up-to-date on your eyesight and eye health needs.
### Oscar Wylee Accepts Health Funds
Oscar Wylee in Craigieburn accepts leading health funds including Medibank, Bupa and NIB. Bring a valid health fund card to your next appointment in-store and our friendly staff can provide an on-the-spot quote and process your claim. Trust our Oscar Wylee eyeglasses shop in Craigieburn to ensure you get the best price every single time for all of your prescription glasses needs.
### Fashion-Forward Glasses at Oscar Wylee
Here at our Oscar Wylee store in Craigieburn Central, you can browse a wide range of prescription glasses and prescription sunglasses in a variety of modern and vintage-inspired styles. Our experts can find a frame that suits your face shape and compliments your personal style. You can also choose to optimise your lenses from our selection of add-ons such as a blue light filter or anti-reflective coating. Visit Oscar Wylee Craigieburn for all your eyewear needs.
Book Appointment
[Call us: (03) 8313 5814](tel:(03) 8313 5814)
[Leave a Review!](https://g.page/r/CYw90-ORWm2DEBM/review)