# Source: https://www.oscarwylee.com.au/glasses/eye/anatomy/crystalline-lens

# Crystalline Lens: Anatomy, Function, and Associated Eye Problems
Published on Monday, March 11
Updated on March 21st, 2025  
Australia   
[Australia](https://www.oscarwylee.com.au/glasses/eye/anatomy/crystalline-lens)
New Zealand

[Canada](https://oscarwylee.ca/glasses/eye/anatomy/crystalline-lens)
Canadian French

The crystalline lens, also known as the eye lens, refers to the clear disk that sits behind the iris and helps a person see. The function of the crystalline lens of the eye is to help focus light onto the retina. The anatomy of the lens includes the nucleus, capsule, cortex and epithelium. The lens is one of the most important parts of the eye, playing a crucial role in how a person sees. It is therefore important to take care of the eyes, including the lens, so that issues with the lens can be avoided and vision is maintained. Issues or eye problems associated with the lens include cataracts, presbyopia and astigmatism. It is important to have a regular eye test with an optometrist, so they can assess the lens of the eye, and detect any issues with it.
Take Care of Your Vision
Our Oscar Wylee optometrists can help care for your vision with a comprehensive eye test in-store
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Definition](#definition) [Function](#function) [Related Eye Problems](#problems) [Care](#care) [Diagnostic Exams](#exams)
## What is the Crystalline Lens?
The crystalline lens or the lens, is a part of the eye that helps light to focus on the retina. The lens is a clear, curved disk located at the front of the eye, behind the pupil, according to the National Institute of Cancer. The purpose of the lens is to bend the light that the eye sees and direct it towards the retina. The retina is the light-sensitive layer at the back of the eye that turns light into electrical signals to send to the brain, which then perceives these signals as images.
## What is the Structure of the Crystalline Lens?
The structure of the crystalline lens, or the lens of the eye, includes the nucleus, capsule, cortex and epithelium. According to Ruan X, Liu Z, Luo L and Liu Y in the paper, The Structure of the Lens and Its Associations with the Visual Quality, the lens is suspended on the ciliary body by the lens zonules.
### What is the Crystalline Lens Made of?
The crystalline lens or eye lens is made up of mostly protein, with up to 60 % of the lens’ total mass coming from proteins, according to Hejtmancik JF and Shiels A in the paper, Overview of the Lens.
#### What is the Colour of the Crystalline Lens?
A healthy crystalline lens or eye lens does not have a colour, it is transparent. The crystalline lens or eye lens is transparent or clear, to allow light to pass through and focus on the retina.
### Where is the Crystalline Lens Located in the Eye?
The crystalline lens or lens of the eye is located in the front of the eye. The lens sits behind the pupil and the iris, in front of the vitreous body.
## What is the Function of the Crystalline Lens in the Eye?
The function of the crystalline lens or the eye lens, is to direct light onto the retina. The retina is the light-sensitive layer at the back of the eye. The ciliary muscles that surround the lens help to change the shape of the lens to ensure light hits the retina correctly, according to Aliancy JF and Mamalis N. in the paper, Crystalline Lens and Cataract. The retina takes light that the eye receives and turns this into electrical signals. These electrical signals are then taken to the brain via the optic nerve and turned into images.
### How Does the Crystalline Lens Help the Human Eye See?
The crystalline lens or lens of the eye, helps the human eye see by focusing light on the retina. The retina is the light-sensitive layer at the back of the eye that takes light the eye sees and turns it into electrical signals that are sent to the brain. The crystalline lens works by focusing light so it hits the retina. The ciliary muscles surrounding the lens help focus this light by changing the shape of the lens so it can focus on objects at varying distances. The process of the lens changing shape to see at different focal lengths is called accommodation.
## What are the Eye Problems Associated with Crystalline Lenses?
The eye problems associated with the crystalline lens or the eye lens include cataracts, presbyopia and astigmatism. The eye problems associated with the lens of the eye are listed below.
* Cataracts:  Cataracts is an eye condition in which the lens of the eyes becomes clouded and affects vision, generally due to ageing.
* Presbyopia:  Presbyopia is an age-related condition in which the lens of the eye becomes hard and less flexible, affecting near vision.
* Astigmatism:  Astigmatism is a refractive error in which a misshapen cornea or lens causes blurry vision.
### 1. Cataracts
Cataracts refers to an eye condition in which the lens of the eyes becomes cloudy, which can impact vision. [Cataracts](https://www.oscarwylee.com.au/glasses/eye/cataracts) are most commonly caused by age-related changes in the eye, where the proteins in the lens cloud together, which can make vision blurry.
### 2. Presbyopia
Presbyopia is an age-related refractive error, in which the eye loses its ability to focus on objects up close. According to Health Direct, the eye's lens becomes harder and less flexible as a person ages, restricting its accommodation powers. This leads to [presbyopia](https://www.oscarwylee.com.au/glasses/eye/presbyopia), in which it is difficult for the eye to focus on close-up objects.
### 3. Astigmatism
Astigmatism is a refractive error in which the cornea or the lens of the eye is misshapen, which causes issues with vision at all distances. According to the American Academy of Ophthalmology, if [astigmatism](https://www.oscarwylee.com.au/glasses/eye/astigmatism) is caused by an irregularity in the lens, it means that light does not bend or refract properly which causes blurred vision at all distances.
Find a Store Near You
Come and visit your local Oscar Wylee store for Medicare bulk billed eye tests and new frames from our stylish range.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
## How Important are Regular Visits to an Optometrist for Taking Care of the Crystalline Lens?
A regular visit to an optometrist is hugely important in taking care of the crystalline lens as it ensures a person will get an eye test, which can detect issues with the lens. An eye test is a process in which an optometrist will assess vision and the health of the eye, including the lens. If there is an issue with the lens or other parts of the eye, [regular visits to an optometrist](https://www.oscarwylee.com.au/eye-care/optometrist) for an eye test will help diagnose this issue and determine the appropriate treatment. Other ways to care for the lens include looking after your overall health, which includes eye health, by eating a balanced diet, exercising frequently and not smoking.
### What Eye Exams are Used by Optometrists to Diagnose Issues with the Crystalline Lens?
The eye exams used by optometrists to diagnose issues with the crystalline lens include a slit lamp examination, a retinoscopy, an auto-refraction test and visual acuity test. The eye exams used by an optometrist to diagnose issues with the lens are listed below.
* Slit-Lamp Examination:  A slit lamp examination involves an optometrist using a slit lamp, which is a microscope with a light attached, to examine the structures at the front of the eye, according to the American Academy of Ophthalmology. The pupil may be dilated using eye drops for a slit lamp exam, so the optometrist can see the inner structures of the eye more clearly.
* Retinoscopy:  A retinoscopy refers to an eye testing technique that measures the refractive error of an eye by looking at how light is reflected in the pupil, according to the American Academy of Ophthalmology. Refractive errors can be caused by issues with the lens as well as the shape of the eyeball.
* Auto-Refraction:  Auto-refraction refers to a machine that can determine a refractive error. Refractive errors such as astigmatism and presbyopia may be caused by issues with the lens.
* Visual Acuity Test:  A visual acuity test will measure how clear and sharp a person’s vision is. Visual acuity can be affected by refractive errors, which can be caused by issues with the lens.
### What Can the Crystalline Lens Be Replaced With?
The crystalline lens or eye lens, can be replaced with an artificial lens if there has been damage, or the lens is not working properly due to an eye condition such as cataracts. The artificial lens used to replace the eye lens is called intraocular lens (IOL).
#### Can You Still See Without a Crystalline Lens?
No, a person will not be able to see properly without a lens, whether that is a natural or artificial lens, with sight likely to be blurry. The lens of the eye helps focus light onto the retina, allowing a person to see. If there is no lens present in the eye to focus light, sight will be blurry, according to the Cleveland Clinic. Aphakia is a term that refers to a missing eye lens.
#### Does Crystalline Lens Regenerate?
There is evidence to suggest that the crystalline lens may be able to regenerate. According to Liu Z, Wang R, Lin H and Liu Y in the paper, Lens regeneration in humans: using regenerative potential for tissue repairing, lens epithelial cells (LECs), may be able to achieve lens regeneration to a certain extent, due to its ability to proliferate and differentiate.
#### What is the Difference Between a Crystalline Lens and a Retina?
There are several differences between the crystalline lens and the retina as they are different structures within the eye, however, both the lens and the retina work together to help a person see. The crystalline lens is the clear disk and the front of the eye that helps focus light onto the retina. The [retina](https://www.oscarwylee.com.au/glasses/eye/anatomy/retina) is the light-sensitive layer at the back of the eye that turns light into electrical signals to send to the brain, which then perceives an image.
Read Crystalline Lens: Anatomy, Function, and Associated Eye Problems in other Oscar Wylee regions and their languages.
Australia   
[Australia](https://www.oscarwylee.com.au/glasses/eye/anatomy/crystalline-lens)
New Zealand

[Canada](https://oscarwylee.ca/glasses/eye/anatomy/crystalline-lens)
Canadian French

Are You Due for an Eye Test?
Oscar Wylee offers bulk billed eye tests, so there are no out-of-pocket expenses for eligible Medicare cardholders.
[Book an eye test](https://www.oscarwylee.com.au/booking)
Oscar Wylee Accepts Major Health Funds In-store
Visit Oscar Wylee in-store for eye care services and your health fund may help cover some of the cost.
[Discover Health Funds](https://www.oscarwylee.com.au/health-funds.html)