# Source: https://www.oscarwylee.com.au/glasses/eye/infection

# Eye Infection: Symptoms, Treatment and Types
Published on July 17th, 2026
An eye infection refers to eye conditions that are caused by viruses, fungi or bacteria, according to Health Direct. The most common types are conjunctivitis, keratitis, blepharitis, stye, chalazion, uveitis, endophthalmitis and orbital cellulitis. Depending on the type of infection, treatments will vary, whether through applying warm compresses or antibiotic eye drops.
Prioritise Your Eye Health
Our team can help you stay up to date with regular eye tests to keep your eyes healthy!
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Common Types](#common-types) [Checking Severity](#severity) [Prevention](#prevention)
## What is an Eye Infection?
An eye infection is a condition of the eye that is caused by viruses, fungi or bacteria, according to Health Direct. There are various types of eye conditions that fall under eye infections, such as conjunctivitis, keratitis, and blepharitis, among others.
### What are the Most Common Types of Eye Infections?
The most common types of eye infections are conjunctivitis, keratitis, blepharitis, stye, chalazion, uveitis, endophthalmitis, and orbital cellulitis. Read more about these common types of eye infections below.
#### 1. Conjunctivitis (Pink Eye)
Conjunctivitis, also known as pink eye, is when the white part of your eye becomes pink or red, leading to other symptoms such as puffiness, light sensitivity and irritation, according to Health Direct. [Conjunctivitis](https://www.oscarwylee.com.au/glasses/eye/conjunctivitis) can be caused by viral infections, bacterial infections, allergies and irritants.
#### 2. Keratitis
Keratitis is a potentially sight-threatening condition characterised by inflammation of the cornea, according to the Mayo Clinic. [Keratitis](https://www.oscarwylee.com.au/glasses/eye/keratitis) can be infectious and non-infectious. Infectious keratitis is most commonly caused by bacteria, but can also be caused by viruses, parasites, and fungi. Non-infectious keratitis is less common and is caused by physical trauma to the eye, dry eye, or contact lenses being left in too long. Symptoms of keratitis include pain, redness, irritation, light sensitivity, blurry vision, teary eyes, discharge, and a foreign object sensation, according to Visionare Eye Specialists. Keratitis is a medical emergency, and treatment involves antimicrobial eye drops, according to the Royal Australian College of General Practitioners (RACGP).
#### 3. Blepharitis
Blepharitis is a chronic condition leading to the inflammation of typically both eyelids. One of the most common causes of [blepharitis](https://www.oscarwylee.com.au/glasses/eye/eyelids-inflammation) is an infection of the eyelids caused by a bacterium called Staphylococcus, according to The Royal Victorian Eye and Ear Hospital. Other symptoms include dry eyes, light sensitivity, itchiness, and the feeling that a foreign object is in the eye.
#### 4. Stye (Hordeolum)
A [stye](https://www.oscarwylee.com.au/glasses/eye/anatomy/stye), formally known as an external hordeolum, is a small, painful cyst caused by an infection at the base of the eyelashes, according to Perth Children's Hospital. These are harmless and will go away without the need for treatment; however, you may want to try warm compresses to help with the inflammation.
#### 5. Chalazion
A [chalazion](https://www.oscarwylee.com.au/glasses/eye/chalazion) is a lump in the eyelid caused by the blockage of meibomian glands, which are the oil glands within the eyelid, according to Vision Eye Institute. A chalazion is not infectious and can sometimes be treated by doing regular hot compresses; however, if they are persistent, they need to be surgically removed.
#### 6. Uveitis
Uveitis refers to inflammation that can most commonly affect the front part of the eye or the middle layer and/or the back part of the eye, according to Macquarie University Health. There are four types of uveitis: anterior (front), intermediate (middle), posterior (back) and pan (all eye layers affected). [Uveitis](https://www.oscarwylee.com.au/glasses/eye/uveitis) leads to the inflammation of the eye, which causes loss of vision, pain, swelling and redness.
#### 7. Endophthalmitis
Endophthalmitis is an infection that affects the inside of your eye, namely the aqueous humour and vitreous humour, according to Cleveland Clinic. Endophthalmitis is caused by an infection, usually following an eye operation, procedure, or eye injury, according to Sunshine Eye Surgeons.
#### 8. Orbital Cellulitis
Orbital cellulitis is a potentially sight-threatening medical emergency referring to an infection of the tissues in the eye socket, according to the Royal Children's Hospital, Melbourne (RCH). Orbital cellulitis is most commonly caused by sinusitis, as the bacteria can travel through the thin bones of the eye socket, according to RCH. It can also be caused by other facial or eye infections, dental infections, and trauma. Orbital cellulitis requires immediate hospitalisation and is treated with intravenous antibiotics, according to RCH.
### Who is More Likely to Get an Eye Infection?
The people who are more likely to get an eye infection will vary depending on what the infection is. For example, those who wear contact lenses are at risk of developing contact lens-associated bacterial keratitis, according to the Royal Australian College of General Practitioners.
#### Are Eye Infections Contagious?
Yes, eye infections can be contagious depending on the condition.
## What are the Symptoms of an Eye Infection?
The symptoms of an eye infection will vary based on the condition. However, symptoms that are present among many eye infections include red eyes, dryness and sticky eyes. Read more about these symptoms of an eye infection below.
* Red eyes: Red eyes occur when the tiny blood vessels on the eye's surface become larger or inflamed, leading to the appearance of reddened or bloodshot eyes.
* Dryness: Dryness of the eyes occurs when the eyes do not produce enough tears, leading to a harsh, uncomfortable feeling as the eye surface is not properly lubricated.
* Sticky eyes: Sticky eyes occur when there is a build-up of mucus and discharge at the corners of the eye, common amongst those with an infection.
### How Can You Tell if an Eye Infection Is Serious?
You can tell an eye infection is serious if you have any loss of vision or experience light sensitivity, according to Health Direct, an Australian government-funded, not-for-profit organisation providing free, virtual health information and advice. You should seek medical attention immediately if you experience any of these symptoms.
#### Can an Eye Infection Affect Your Vision?
Yes, certain eye infections can affect your vision. Notably, conjunctivitis and keratitis can lead to blurred vision and light sensitivity.
Find Your Nearest OW Store!
We've got knowledgeable teams who are passionate about delivering high-quality care.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
## How is an Eye Infection Treated?
How an eye infection is treated will depend on the type of eye infection. Treatment methods should be discussed by an optometrist or other health professional.
### Which Treatments Work Best for Different Eye Infection Types?
The treatments that work best for different eye infection types will vary for each. Eye infections include conjunctivitis, keratitis, blepharitis, stye, chalazion, uveitis, endophthalmitis, and orbital cellulitis. Read more about these treatments for the eye infections listed below.
* Conjunctivitis: Bacterial conjunctivitis may be treated with antibiotic eye drops prescribed by a professional, while viral conjunctivitis typically requires different management.
* Keratitis: Keratitis is treated with antibiotic eye drops. In severe cases, individuals may be admitted to hospital for closer monitoring, according to Sydney Hospital &amp; Sydney Eye Hospital.
* Blepharitis: Blepharitis treatment mainly involves cleaning your eyelids. Artificial teardrops available over the counter will help mitigate dry eye symptoms, while in severe cases, you may be prescribed antibiotic drops or oral antibiotics, according to The Royal Victorian Eye and Ear Hospital.
* Stye: Styes can usually be treated at home with the regular application of warm compresses, according to Health Direct.
* Chalazion: Chalazions may be treated firstly through hot compresses, but in more severe, persistent cases, an antibiotic called doxycycline may be prescribed, according to Vision Eye Institute.
* Uveitis: Uveitis is treated through anti-inflammatory eye drops or corticosteroid eye drops, according to Singleton Eye Surgery.
* Endophthalmitis: Endophthalmitis treatment will entail an intravitreal injection of broad-spectrum antibiotics, according to Australian Family Physician.
* Orbital Cellulitis: Orbital Cellulitis will require immediate hospitalisation. Antibiotics will be prescribed.
#### Can an Eye Infection Go Away Without Treatment?
No, an eye infection will generally need a form of treatment to go away quickly. More serious conditions will need a consultation with an Optometrist.
#### Can You Treat an Eye Infection at Home?
Generally, you can treat an eye infection at home, depending on the condition. For example, a stye is usually treated at home by applying warm compresses regularly. However, a condition like keratitis will require a visit to the optometrist, where they will prescribe eye drops depending on the severity of your condition.
#### Are Eye Infections Contagious?
Yes, eye infections can be contagious depending on the condition. For example, styes are not contagious, but pink eye is.
### What Should You Avoid While Your Eye Is Healing?
You should avoid products that will irritate your eyes while they are healing from infection, such as makeup products like mascara and eyeliner.
#### Can You Wear Contact Lenses During an Eye Infection?
Generally, it is advised that you do not wear contact lenses during an eye infection. Contact lenses can potentially worsen symptoms of an eye infection.
## How Can You Prevent Future Eye Infections?
To prevent future eye infections, you should wash your hands, avoid sharing materials that touch the face and replace eye makeup regularly. Read more about how you can prevent future eye infections below.
* Wash your hands: Wash your hands thoroughly with warm, soapy water regularly, particularly if you are in public spaces.
* Avoid sharing materials that touch the face: Avoid sharing materials that touch the face, such as towels, face washers and make-up such as foundation and eyeshadow, as these can be points of infection.
* Replace eye makeup regularly: Replace eye makeup regularly, such as eyeliner, eyeshadow and mascara. This will ensure there is no bacterial buildup and accumulation.
### How Can Prescription Eyeglasses Help Protect Your Eyes From Infection?
[Prescription eyeglasses](https://www.oscarwylee.com.au/glasses/prescription) do not protect your eyes from infection. It is important to consult an eye doctor so they can provide medication to treat your eyes from infection.
### When Should You See a Doctor for an Eye Infection?
You should see a doctor immediately if you are exhibiting signs of an eye infection, namely, more severe signs such as changes in vision or light sensitivity.
#### Can Untreated Eye Infections Lead to Permanent Eye Damage?
Yes, untreated eye infections, and notably more severe ones, can lead to permanent eye damage. For example, keratitis, if left untreated, can go through the cornea and spread to other parts of the eye, leading to possible blindness, according to the Prevent Blindness Organisation.
Experience High Quality Eyecare Services From Our Team
Book an appointment online with an Oscar Wylee optometrist today.
[Book an eye test](https://www.oscarwylee.com.au/booking)
Major Health Funds Accepted In-store
For the purchase of frames and lenses, use your private health fund to limit how much you pay from your own pocket.
[Health Funds](https://www.oscarwylee.com.au/health-funds.html)