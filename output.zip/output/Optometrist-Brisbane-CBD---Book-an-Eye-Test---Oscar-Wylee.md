# Source: https://www.oscarwylee.com.au/locations/optometrist-albert-st.html

# Optometrist Brisbane - Albert St
136 Queen StreetBrisbane City QLD 4000
* Near Vans
Opening hours
Monday9:00am - 5:30pm
Tuesday9:00am - 5:30pm
Wednesday9:00am - 5:30pm
Thursday9:00am - 5:30pm
Friday9:00am - 5:30pm
Saturday9:00am - 5:00pm
Sunday10:00am - 4:00pm
*Store hours reflect local standard trading hours and exclude public holidays
[Visit our Albert St Google Business page for directions, reviews, and updates.](https://g.page/r/CfEUP0ZJ9SxQEAE)
Book Appointment
[Call us: (07) 3076 2860](tel:(07) 3076 2860)
[Leave a Review!](https://g.page/r/CfEUP0ZJ9SxQEBM/review)
Our Reviews
Alyssa Cooper
3 days ago
Staff are incredibly patient, knowledgeable and friendly! The range is excellent too.
Rochelle Jose
2 weeks ago
Excellent service at the optical clinic!
I had a smooth and comfortable eye‑test experience. The opt...ometrist explained everything clearly and made sure I understood my results. The staff at the front desk were welcoming, efficient, and very helpful in assisting me with frame options. I ended up purchasing not only for myself, but also for my two kids. Overall, a great visit — highly recommended!
See more
Patricia González
2 weeks ago
susan mcgrath
3 weeks ago
Knowledgeable eye check, fashionable variety of glasses to choose from and excellent help with choos...ing frames. Over all 10/10 experience
See more
Rita Cleveland
3 weeks ago
Responsive, personable and inviting atmosphere.
Rafaela Coelho
3 weeks ago
I really appreciated the girl who helped me before my eye exam and the doctor who performed the exam...ination. They were both kind, professional, and made me feel comfortable. I purchased my glasses and I’m now waiting for them to be ready.
Unfortunately, my experience with the other staff member was very different. I’m from another country, and the eye examination process is different where I’m from. I had a few questions, but every time I asked, she answered in a rude and impatient way.
After the exam, I was looking at other frames before making my final decision, and she didn’t offer any help or assistance. She only said that I could sit down if I wanted, but without being friendly or welcoming at all.
The only reason I went ahead with the purchase was because of the doctor’s kindness and because I really liked the frame I chose. Otherwise, I would have decided not to buy anything.
I hope this feedback is helpful, as customer service makes a big difference, especially for international customers who may not be familiar with how things work here.
See more
Grace Chen
1 month ago
Optometrist Mr An is very kind and professional. Thanks ????.
Jiny
1 month ago
The staff were polite, professional and had good energy. There were a lot of glasses frame choices a...vailable and the location was pleasant and clean. They know what they're doing:)
See more
Laura Nunes Seixas
1 month ago
I felt really welcome and confortable
Paola Maldonado Cortes
1 month ago
Christopher Evans
1 month ago
Staff were very friendly and helpful and the optometrist was professional and explained everything c...learly.
See more
Shayne Boogaard
2 months ago
Eye test was great and the advice of the person completing the test was also fantastic
KK XX
2 months ago
Ivy Alana, as soon as i walked in weren't annoying and trying to sell or upsell, they spotted my gla...sses in wrong position, fixed something, LISTENED, WERE WONDERFUL
The optomoterist was just as amazingly wonderful, tall young slim gentleman.
I have not had service like that possibly ever or for a long time.
Pls pass this onto all 3.
I will be back to pick up glasses.
I hope they know of my mega compliment  by then.
ALBERT ST STORE
Thankyou
See more
Karl Goulding
2 months ago
Still waiting for my prescription to be emailed to me...
Peter Myska
2 months ago
Kristie Renooy
2 months ago
Wonderful :) my optometrist here was great, super informative and very helpful! (A lovely gentleman ...I don’t remember his name sorry)
See more
Siang Tat “Rocky” Teoh
2 months ago
Jacinda Luong
3 months ago
Currently a customer of Oscar Wylee but today I stopped by their Albert St store as I had a pair of ...sunnies from a different brand that didn't sit quite right on my face. I was assisted by Macy who was able to adjust them for me at no cost and got them perfectly fitted! Always amazing service as usual - thanks Macy :)
See more
Shelbie
3 months ago
Service was great, everyone was friendly, the optometrist explained everything and didn’t oversell p...roducts.
See more
Naughtynattiegurl
4 months ago
Good experiences here, good services quick and many design to choose
Linda Vogel
4 months ago
I was seen promptly and appointment by optometrist was very thorough
Meagan Newsham
4 months ago
I had a fantastic experience at the Albert Street store in Brisbane City. The Optometrist was so tho...rough and explained things to me very clearly. A lovely kind person then helped me choose glasses that suited me - giving me lots of options but also being honest with her thoughts. It was a really positive experience. Thank you.
See more
Dawood jan Urozgani
4 months ago
The best team ever today I arrived needed to fix my glasses and didn’t have much time and they were ...super friendly and helpful next time I wll change my glasses with you guys . Keep up great work thanks again
See more
Jason Garrick
4 months ago
Mario Sand
4 months ago
Great service provided by Alana and Ernice, kindly appreciated and I highly recommend them, thank yo...u!
See more
Sandra Douglas
4 months ago
Fantastic experience ???? great customer service from the team. Informative, helpful and engaging.
Sarah Aspinall
4 months ago
Service was great. I'm still waiting on my email they said they would send with my result and detail...s/quite of advised prescription
See more
Denkar Lhamo
4 months ago
Bradley Freeman
4 months ago
Daniel was polite, professional and friendly. The examination room was clean and modern with plenty ...of room. Charlotte was very helpful with selecting frames and processing the order. Overall a very good experience.
See more
Brooke Murray
4 months ago
I had a really nice experience with optometrist Daniel. He listened to and addressed all my concerns..., he explained everything clearly so I understood my prescription and why he was recommending it. He was efficient and very kind.
See more
TikTok shopping mall
5 months ago
Dear partners:
Cross-border e-commerce has become the core engine of the Internet era.
[TikTok Shop ...Cross-border] As a cross-border e-commerce service platform, we now invite high-quality suppliers, brands and entrepreneurial partners to settle in the world.
We offer:
Omni-channel entry: official docking of platforms such as Amazon, TikTok Shop and SHEIN.
Growth and empowerment: product selection analysis+traffic delivery+brand packaging, one-stop to create explosions.
Win-win mechanism: open city partner program, sharing platform with tens of millions of streams.
You are cordially invited to visit and discuss cooperation, so that good goods can be sold all over the world!
Appointment inspection: reply "T"
See more
Kayla Richards
5 months ago
Fergus Rees
5 months ago
Great service! Replaced my sunglasses nose pads without any hassle (and free of charge)
Teck Hui Ng
5 months ago
Stephanie Zhang
5 months ago
They are professional and friendly! Definitely first option to go.
Graham Keys
5 months ago
Thank you to the team.  I found their service to be excellent.  Staff were polite, considerate and v...ery professional.  Highly recommended.
See more
Ricky Metran
6 months ago
The staff at the front was amazing and the eye doctor was great. The only downside is the payment sy...stem you have to pay all outstanding fees straightaway whilst waiting for your glasses to arrive. It is very hard for a lot of people to do this in one go. I used to get my glasses at Oscar Wylee indroopilly and they take half payment now and the rest when you pick up your glasses. Same as spicks saver and Taylor optical. They make it easy and affordable for all customers and that means more business for you. Considering how hard it is now to live in Australia.
See more
Nivedita Suresh
6 months ago
Had a great experience at Oscar Wylee, Brisbane City today. Jos kindly adjusted and tightened my gla...sses on the spot, and they fit perfectly now.
Friendly, professional service and no fuss at all. Really appreciate the care and attention.  highly recommend this store and Jos :)
See more
Kylie O'Driscoll
6 months ago
Very supportive of my son's first ever eye test/check up.  I was pleased with kindness and explanati...ons offered to him to understand eye health, and where he is at.
See more
Jordan Blinco
6 months ago
Christine was incredibly professional and efficient. The space she keeps is clean and tidy. She has ...a very calming bedside manner. My total appointment was only about 20 minutes. Will definitely come back.
See more
Adrian
6 months ago
Kelzang Lhamo
6 months ago
I would like to express my sincere appreciation to Ms. Emilly for her outstanding service and warm w...elcome every time I visit Oscar Wylee Store.
Ms. Emilly is incredibly prompt, professional, and genuinely caring. Despite being extremely busy, she never fails to provide the very best service to every customer. Her dedication, positive attitude, and attention to detail truly make a difference. She handles everything with such grace and efficiency, ensuring that each customer feels valued and respected.
She is truly the face of Oscar Wylee Store — a shining example of hard work, commitment, and excellence. Her passion for her job is clearly reflected in the exceptional service she delivers.
Thank you, Emilly for the best service ever. You truly deserve the highest appreciation and recognition for your dedication and tireless efforts!
Thank you Oscar Wylee.
See more
Joseph Trevathan
6 months ago
The staff are very friendly and accommodating. The only reason I can’t give 5 stars is due to the wa...it times. Otherwise it was a great experience.
See more
jane winnick
6 months ago
My partner and I called on the off chance for an appointment they were able to see us both in 20 min...s.   Service was good by Christine Maisy and Emily,  and Emily help me choose my glasses thank you to her.
See more
Lucy Hockham
6 months ago
I received fantastic service at Oscar Wylee on Monday 9th Feb. Christine was so professional and fri...endly during my eye test. Her manner was really person-focused and she resolved the issues I was having with my previous glasses.
Emily was so helpful and kind while supporting me to pick my frames. She did such a great job and I left really happy with my choices.
I would highly reccomend this store!
See more
RB Dental Redbank Plaza
6 months ago
George Silas
6 months ago
Darrel Doyle
6 months ago
Gina Cozzi
6 months ago
Nasly Real
7 months ago
Excellent service!! Doctor is really nice and answered all my questions related to my eyer surgery. ...She was really knowledgeable and quick in customer service.
See more
## Find an Optometrist in Brisbane - Albert St With Oscar Wylee
Located in the heart of the Brisbane CBD, our Oscar Wylee Brisbane - Albert St store sits across from Queen’s Street Mall. Here, our dedicated Oscar Wylee optometrists can provide you with a Medicare, bulk billed eye test and our friendly staff can help you shop our modern and vintage-inspired frames- all on the same day! Our staff care about your eye health and vision equally as much as your in-store experience. Close to areas such as Fortitude Valley and Spring Hill, you can reach our Oscar Wylee Brisbane - Albert St via bus or take the train to the nearby Brisbane Central Station. With our comprehensive eye tests, our optometrists are capable of testing for signs of an eye condition or eye disease 
If you are up for an adventurous outing, the Brisbane CBD is full of fun activities from segway tours to cruises along the Brisbane River. Come in and see the team at our Oscar Wylee store for some of the best eye care processes in Brisbane, Australia.         
Meet Our Team
* Optometrist Partner
* Retail Partner
* Optometrist
Masters of Optometry
Bachelor of Vision Science
Our Services
* Bulk Billed Eye Examinations
* Professional Frame Styling
* Frame Adjustments and Repairs
Show All
## Find an Optometrist in Brisbane - Albert St for an Eye Health Test
Find an optometrist in Brisbane - Albert St at Oscar Wylee for excellent eyewear and optometry services. Oscar Wylee Albert St in Queensland offers eye health tests, optical glasses and prescription sunglasses as well as other services you may need in a glasses store. At Oscar Wylee Brisbane - Albert St, you can also receive assistance from an optical dispenser for your eyewear needs and concerns.
With an optometrist in every store, you won't need to see an eye doctor for your check-up as our Oscar Wylee optometrists are qualified and trained so you can expect all the necessities of an eye health test in Brisbane - Albert St. An eye test typically involves checking eye movement, the health of a patient's vision and whether there are any signs of eye diseases. Our eye tests are available at a bulk billed price as part of Australia’s Medicare system so there are no out-of-pocket expenses for eligible Medicare cardholders. The average price range for an optometrist in Brisbane - Albert St can vary depending on factors such as the patient’s overall health, age and visual needs. Visit Oscar Wylee Albert St for all your eye care needs.
## How to Find an Optometrist in Brisbane - Albert St?
To find an optometrist in Brisbane - Albert St you can take certain steps that can help make it easier for you such as searching online, assessing the store’s opening hours and finding the directions to your chosen location. The steps on how to find an optometrist in Brisbane - Albert St are listed below.
1. Search online using the phrase, optometrist near me in Brisbane - Albert St. This can also be done here on the website via our locations page.
2. Click on the Oscar Wylee link, which will take you directly to our Brisbane - Albert St store page.
3. See the store’s opening hours and where the store is located specifically.
4. Use the Brisbane - Albert St Google Business page link located under store hours to see the directions on how to get to the store.
You can also find an optometrist in Brisbane - Albert St by searching the keywords optometrist near me. If you have locations enabled on your smartphone and you’re in the Brisbane - Albert St area, our Brisbane - Albert St store page should appear easily for you to click on.
### Is it Hard to Get an Eye Appointment in Brisbane - Albert St?
No, it is not hard to get an eye appointment in Brisbane - Albert St. You can easily book an appointment to see an Oscar Wylee optometrist in Brisbane - Albert St right here on this page. At Oscar Wylee we have highly qualified optometrists available for bulk billed eye appointments, which can be booked online or in-store.
#### How to Compare Optometrists in Brisbane - Albert St to Each Other?
To compare optometrists in Brisbane - Albert St, you can use factors such as eye tests offered, health fund coverage, lens types and add-ons and eyewear offered. To take care of your vision and eye health, it is important to receive an eye test at least once every two years. There are different types of tests that can be performed in an eye test and not all optometrists may offer the same tests. Health funds can be used to help cover some of the cost of your frames and lenses. To find out if your health fund is accepted at an optometrist in Brisbane - Albert St, visit their website. In the case of Oscar Wylee, we accept all major health funds and provide on-the-spot claims in-store. There are many different lens options available for prescription glasses such as single vision, multifocal and high index lenses. Most optometrists in Brisbane - Albert St will offer these lenses although it is good to make sure. There are also lens add-ons available to enhance your glasses such as anti-reflective and blue light filters. Finally, if you are looking to purchase a pair of glasses after your eye test, you can compare the different styles and colours you are interested in from the optometrists in Brisbane - Albert St. Oscar Wylee offers a wide range of frames with vintage and modern inspirations in bold colours and subtle designs.
#### How to Find an Eyeglasses Shop in Brisbane - Albert St?
To find a glasses store in Brisbane - Albert St, you can try to follow these simple steps including searching online, selecting a convenient location and looking at their health insurance policies. The steps on how to find a glasses store in Brisbane - Albert St are listed below.
1. Search online using the phrase, glasses store in Brisbane - Albert St. This will provide you with various options for glasses stores in the whole Brisbane - Albert St area.
2. Select a glasses store that is most convenient for you to travel to.
3. Click the link to find out more information such as opening hours, exact location and directions to the glasses store in Brisbane - Albert St.
4. Read their health insurance policies to ensure you know what health benefits you have access to.
Our Oscar Wylee glasses store in Brisbane - Albert St offers primary eye care services such as comprehensive eye tests as well as other services performed by an optometrist and offers prescription and non-prescription eyewear.
##### Is it Possible to Purchase Prescribed Sunglasses in Brisbane - Albert St Without Seeing an Optometrist?
Yes and no, it is possible to [purchase prescribed sunglasses](https://www.oscarwylee.com.au/sunglasses.html) in Brisbane - Albert St without seeing an optometrist if you already have a prescription that has not expired. If your prescription is expired, you can book an eye test to receive an updated or new prescription which will require you to see an optometrist. This will ensure your prescription sunglasses are appropriate for your visual needs.
## Where is the Oscar Wylee Brisbane - Albert St Optometrist Located?
The Oscar Wylee Brisbane - Albert St optometrist is located in the heart of the Brisbane CBD in Queensland, across from Queen Street Mall and next to Vans. Oscar Wylee Albert St is close to the Brisbane River which is the longest river in South East Queensland that empties into Moreton Bay.
### What is the Phone Number of Oscar Wylee Brisbane - Albert St Optometrist Store?
The Oscar Wylee Brisbane - Albert St optometrist store phone number is (07) 3076 2860. You can contact the Oscar Wylee Brisbane - Albert St store between the hours of 9 am and 5:30 pm from Monday to Thursday, 9 am and 8 pm on Fridays, 9 am and 5 pm on Saturdays and 10 am and 4 pm on Sundays.
### What are the Reviews for Oscar Wylee Brisbane - Albert St Optometrist?
The many reviews for Oscar Wylee Brisbane - Albert St optometrist, left by our various customers can be found here on the website as well online when you search for Oscar Wylee Brisbane - Albert St optometrist. The reviews for Oscar Wylee Brisbane - Albert St optometrist are listed below.
* Mehrnaz Hatami:  Professional and knowledgeable, no waiting time, recommend this place.
* S James:  The customer service I received from Alana at Oscar Wylee recently was outstanding. Patient, kind and willing to go the extra mile. Could not recommend more!
* Gaye Evans:  Very professional eye test yesterday with Oscar Wylee. A lot of information on management and care from the optometrist and Alana out front was efficient, super helpful and kind. I highly recommend them.
* Stephane Malhomee:  Great service, friendly and competent. No/little wait time, great prices. Couldn’t fault them if I tried.
#### What Treatments or Eye Care Processes are Done in the Oscar Wylee Brisbane - Albert St Optometrist Location?
The treatments or eye care processes done in the Oscar Wylee Brisbane - Albert St optometrist location include a tonometry test, a slit lamp exam and a refraction test. Additional tests that may also be performed can include a dilated fundus exam. The treatments or eye-care processes that are done in the Oscar Wylee Brisbane - Albert St optometrist location are listed below.
* A Tonometry Test: An optometrist or optical dispenser will conduct a tonometry test which involves the use of a machine that will release small puffs of air into your eyes. This will assist with measuring pressure in the eye.
* Slit Lamp Test: A slit lamp test can be used to evaluate your eye health, by examining your cornea and iris which are the anterior and posterior of the eye.
* Visual Field Test: A visual field test can assist with assessing your peripheral vision, which may be beneficial for identifying any signs of glaucoma.
* Dilated Fundus Exam: A dilated fundus exam can help an optometrist assess your health in more detail by getting a clear view of the retina. This test is typically carried out for patients with diabetes and those who may be at risk of developing retinal damage.
## How Many Optometrists Exist in Brisbane - Albert St?
There are many optometrists that exist in Brisbane CBD to provide eye tests and glasses, including Oscar Wylee. The amount of optometrists available in an area will typically depend on the population. At Oscar Wylee Brisbane - Albert St located in the CBD, we offer excellent optometry services including eye tests performed by skilled optometrists using high-quality equipment. We also have a wide range of fashion-forward frames that customers can browse in a large selection of sizes and colours. If you’re looking for an optometrist in Brisbane - Albert St, choose Oscar Wylee and we will take care of your optometry and eyewear needs.
### What are the Other Closest Optometrist Locations to Brisbane - Albert St in Australia?
The other closest Oscar Wylee optometrist locations to Brisbane - Albert St in Australia are Indooroopilly, Carindale, Chermside, Mt Gravatt and Capalaba Park. The locations and their distance from Brisbane Albert-St are listed below.
* Indooroopilly:  Indooroopilly is close to Brisbane - Albert St, around 8-9 km. The [Oscar Wylee Indooroopilly](https://www.oscarwylee.com.au/locations/optometrist-indooroopilly.html) store is in the Indooroopilly Shopping Centre near Coles. Oscar Wylee Indooroopilly offers bulk billed eye tests for eligible Medicare cardholders, professional frame styling and visual field testing.
* Carindale:  Carindale is close to Brisbane - Albert St, around 14-15 km. The [Oscar Wylee Carindale](https://www.oscarwylee.com.au/locations/optometrist-carindale.html) store is located in Brisbane’s South Eastern suburbs in Westfield Carindale. Oscar Wylee Carindale offers excellent eyewear and optometry services including comprehensive eye tests and frame adjustments and repairs.
* Chermside: Chermside is close to Brisbane - Albert St, around 10-12 km. The [Oscar Wylee Chermside](https://www.oscarwylee.com.au/locations/optometrist-chermside.html) store is located in Westfield Chermside on level 1 near Coles. Visit Oscar Wylee Chermside for eye tests performed by skilled optometrists and fashion-forward frames.
* Mt Gravatt: Mt Gravatt is close to Brisbane - Albert St, around 10-12 km. The [Oscar Wylee Mt Gravatt](https://www.oscarwylee.com.au/locations/optometrist-mt-gravatt.html) store is located in Westfield Mt Gravatt shopping centre next to Specsavers. Oscar Wylee Mt Gravatt provides primary eye care processes including digital retinal scanning and visual field testing.
* Capalaba Park: Capalaba Park is close to Brisbane - Albert St, around 20-23 km. The [Oscar Wylee Capalaba Park store](https://www.oscarwylee.com.au/locations/optometrist-capalaba.html) is located in the Capalaba Park Shopping Centre near Kmart. For bulk billed eye tests and on-trend frames, visit Oscar Wylee Capalaba Park.
### Bulk Billed Eye Tests at Brisbane - Albert St
We offer eye tests for general eye health check ups and vision testing in-store at Oscar Wylee Brisbane - Albert St, conducted by our qualified optometrists. We can also look out for any signs of eye diseases and eye conditions through our comprehensive eye testing. Come into our eyeglasses shop and get an updated prescription for your glasses and shop for a new pair on the same day. Make Oscar Wylee Brisbane - Albert St your first choice for optometry services and we can help you stay up to date with your regular eye tests.
### Health Funds Accepted at Brisbane - Albert St
Our Oscar Wylee Brisbane store on Albert St accepts major health funds. We’ll be able to process your health fund claim at our eyeglasses shop, as well as help you navigate the ins and outs of your insurance to ensure you’re receiving the best price for your prescription glasses. So visit Oscar Wylee Brisbane - Albert St for quality eye care processes.
### Find Fashionable Frames at Oscar Wylee
Here at our store on Oscar Wylee Brisbane - Albert St, we have a wide range of modern and vintage-inspired frames for prescription sunglasses and prescription glasses. Oscar Wylee Brisbane - Albert St also offers different options for lenses such as our blue light filters, multifocal lenses or photochromic lenses. Our optometrists offer some of the best optometry services at Oscar Wylee Brisbane - Albert St as they are experts who will help you choose what’s best for you, whether that’s a pair of prescription glasses or prescription sunglasses.
Book Appointment
[Call us: (07) 3076 2860](tel:(07) 3076 2860)
[Leave a Review!](https://g.page/r/CfEUP0ZJ9SxQEBM/review)