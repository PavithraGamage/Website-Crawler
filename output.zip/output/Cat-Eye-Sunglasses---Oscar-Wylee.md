# Source: https://www.oscarwylee.com.au/sunglasses/silhouette/cat-eye.html

9 Products        
Showing 9
1. [](https://www.oscarwylee.com.au/sunglasses/materials/gaby-sunglasses.html)
[Gaby](https://www.oscarwylee.com.au/sunglasses/materials/gaby-sunglasses.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/sunglasses/materials/gaby-sunglasses.html)
[3 pairs from $249](https://www.oscarwylee.com.au/sunglasses/materials/gaby-sunglasses.html)
2. [](https://www.oscarwylee.com.au/sunglasses/silhouette/mona-sunglass.html)
[Mona](https://www.oscarwylee.com.au/sunglasses/silhouette/mona-sunglass.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/sunglasses/silhouette/mona-sunglass.html)
[3 pairs from $249](https://www.oscarwylee.com.au/sunglasses/silhouette/mona-sunglass.html)
3. [](https://www.oscarwylee.com.au/sunglasses/materials/aida-sunglasses.html)
[Aida](https://www.oscarwylee.com.au/sunglasses/materials/aida-sunglasses.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/sunglasses/materials/aida-sunglasses.html)
[3 pairs from $249](https://www.oscarwylee.com.au/sunglasses/materials/aida-sunglasses.html)
4. [](https://www.oscarwylee.com.au/fleur-sunglasses.html)
[Fleur](https://www.oscarwylee.com.au/fleur-sunglasses.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/fleur-sunglasses.html)
[3 pairs from $249](https://www.oscarwylee.com.au/fleur-sunglasses.html)
5. [](https://www.oscarwylee.com.au/aminah-sunglasses.html)
[Aminah](https://www.oscarwylee.com.au/aminah-sunglasses.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/aminah-sunglasses.html)
[3 pairs from $249](https://www.oscarwylee.com.au/aminah-sunglasses.html)
6. [](https://www.oscarwylee.com.au/shae-sunglasses.html)
[Shae](https://www.oscarwylee.com.au/shae-sunglasses.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/shae-sunglasses.html)
[3 pairs from $249](https://www.oscarwylee.com.au/shae-sunglasses.html)
7. [](https://www.oscarwylee.com.au/sunglasses/silhouette/peggy-sunglasses.html)
[Peggy](https://www.oscarwylee.com.au/sunglasses/silhouette/peggy-sunglasses.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/sunglasses/silhouette/peggy-sunglasses.html)
[3 pairs from $249](https://www.oscarwylee.com.au/sunglasses/silhouette/peggy-sunglasses.html)
8. [](https://www.oscarwylee.com.au/amelia-sunglasses.html)
[Amelia](https://www.oscarwylee.com.au/amelia-sunglasses.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/amelia-sunglasses.html)
[3 pairs from $249](https://www.oscarwylee.com.au/amelia-sunglasses.html)
9. [](https://www.oscarwylee.com.au/christina-sunglasses.html)
[Christina](https://www.oscarwylee.com.au/christina-sunglasses.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/christina-sunglasses.html)
[3 pairs from $249](https://www.oscarwylee.com.au/christina-sunglasses.html)
9 Products        
Showing 9
Choosing Cat Eye Sunglasses
Colour, Suitability and Functionality
Pricing and Shipping
## How to Choose the Best Cat Eye Sunglasses for Women?
You can choose the best cat eye sunglasses for women by
knowing what frame shape suits you, choosing the most
comfortable frame and selecting the right size.
The factors for the
[best women's sunglasses](https://www.oscarwylee.com.au/glasses/sunglasses/best-for-women)
will be dependent on each individual's personality, preference
and any potential requirements for their vision. The ways to
choose the best cat eye sunglasses for women are listed below.
* Knowing what frame shape suits you: Knowing
what frame shape suits you is important when choosing the best
cat eye sunglasses for women, as it helps create visual
harmony and balance. Some frame shapes are considered to be
better suited for certain face shapes; for example, cat eye
sunglasses are typically recommended for heart and round face
shapes.
* Choosing the most comfortable frame: Choosing
the most comfortable frame for the best cat eye sunglasses for
women is a key factor for optimal daily wear. Try your
sunglasses on to make sure they do not slip down when looking
downwards or feel like they're pinching your nose bridge or
around the temples.
* Select the right size: Select the right size
of frame when choosing the best cat eye sunglasses for women,
as the width of the frame can also affect how they will look
on you.
[](https://www.oscarwylee.com.au/sunglasses/materials/arabella-sunglasses.html)
[](https://www.oscarwylee.com.au/elsie-sunglasses.html)
[](https://www.oscarwylee.com.au/sunglasses/materials/gaby-sunglasses.html)
[](https://www.oscarwylee.com.au/sunglasses/silhouette/mona-sunglass.html)
[](https://www.oscarwylee.com.au/sunglasses/materials/arabella-sunglasses.html)
[](https://www.oscarwylee.com.au/elsie-sunglasses.html)
[](https://www.oscarwylee.com.au/sunglasses/materials/gaby-sunglasses.html)
[](https://www.oscarwylee.com.au/sunglasses/silhouette/mona-sunglass.html)
### How to Choose the Best Cat Eye Sunglasses According to Face Shape?
Choose the best cat eye sunglasses according to face shape.
You will need to determine what face shape you have, whether
you have a round face shape, a pear face shape, an oval face
shape, a heart face shape or a square face shape.
The list below can be general recommendations, which you can
read in greater detail in the
[best glasses for different face shapes](https://www.oscarwylee.com.au/glasses/face-shapes). However, it is ultimately your choice, and what you like that
matters most. The ways to choose the best cat eye sunglasses
according to face shape are listed below.
* Round face shapes: [Round face shapes](https://www.oscarwylee.com.au/glasses/face-shapes/round)
are characterised by a round, softer look. Round face shapes
are well-suited to rectangular or square-shaped frames, as
they help to bring structure to the face.
* Pear face shapes: Pear face shapes are
characterised by a narrow forehead and fuller jaw. Rectangular
and
[square glasses](https://www.oscarwylee.com.au/glasses/silhouette/square.html)
are well-suited to
[pear face shapes,](https://www.oscarwylee.com.au/glasses/face-shapes/pear)
as they add width to the forehead and help balance the face.
* Oval face shape: [Oval face shapes](https://www.oscarwylee.com.au/glasses/face-shapes/oval)
resemble an oblong shape and have smooth curves. Frames that
suit an oval face shape include rectangular and square-shaped
frames, as they help to balance the roundness of the face and
bring balance to features.
* Heart face shape: A heart-shaped face is
characterised by a wider forehead and a smaller chin. Frames
that suit a
[heart-shaped face](https://www.oscarwylee.com.au/glasses/face-shapes/heart)
are round and square, as these shapes help to balance out the
wider forehead.
* Square Faces: [Square face shapes](https://www.oscarwylee.com.au/glasses/face-shapes/square)
are characterised by an angular forehead and chin, and a face
that is mostly in proportion.
[Round glasses](https://www.oscarwylee.com.au/glasses/silhouette/round-glasses.html)
or oval glasses are good for square faces, as they soften the
naturally sharp angles.
### Which Material is Best for Cat Eye Sunglasses?
The material that may be best for Cat Eye sunglasses can include
acetate, acetate combined with metal and bio-acetate.
[Acetate](https://www.oscarwylee.com.au/glasses/acetate-frame)
frames are often hypoallergenic and are a good choice of
material for glasses due to their versatility.
[Bio-acetate](https://www.oscarwylee.com.au/glasses/bio-acetate)
provides individuals with a more sustainable option through its
use of less oil-based plasticisers compared to regular acetate.
There isn't necessarily one material that is best for cat eye
sunglasses, as this comes down to preference and what is
available. Here at Oscar Wylee, we offer a broad variety of cat
eye sunglasses that can cater to all sorts of face types and
individual style preferences.
[](https://www.oscarwylee.com.au/aminah-sunglasses.html)
[Aminah](https://www.oscarwylee.com.au/aminah-sunglasses.html)
$169    
Add to Cart
[Shop Aminah](https://www.oscarwylee.com.au/aminah-sunglasses.html)
[2 pairs from $199](https://www.oscarwylee.com.au/aminah-sunglasses.html)
[3 pairs from $249](https://www.oscarwylee.com.au/aminah-sunglasses.html)
[](https://www.oscarwylee.com.au/sunglasses/materials/gaby-sunglasses.html)
[Gaby](https://www.oscarwylee.com.au/sunglasses/materials/gaby-sunglasses.html)
$169    
Add to Cart
[Shop Gaby](https://www.oscarwylee.com.au/sunglasses/materials/gaby-sunglasses.html)
[2 pairs from $199](https://www.oscarwylee.com.au/sunglasses/materials/gaby-sunglasses.html)
[3 pairs from $249](https://www.oscarwylee.com.au/sunglasses/materials/gaby-sunglasses.html)
[](https://www.oscarwylee.com.au/sunglasses/materials/aida-sunglasses.html)
[Aida](https://www.oscarwylee.com.au/sunglasses/materials/aida-sunglasses.html)
$169    
Add to Cart
[Shop Aida](https://www.oscarwylee.com.au/sunglasses/materials/aida-sunglasses.html)
[2 pairs from $199](https://www.oscarwylee.com.au/sunglasses/materials/aida-sunglasses.html)
[3 pairs from $249](https://www.oscarwylee.com.au/sunglasses/materials/aida-sunglasses.html)
[](https://www.oscarwylee.com.au/amelia-sunglasses.html)
[Amelia](https://www.oscarwylee.com.au/amelia-sunglasses.html)
$169    
Add to Cart
[Shop Amelia](https://www.oscarwylee.com.au/amelia-sunglasses.html)
[2 pairs from $199](https://www.oscarwylee.com.au/amelia-sunglasses.html)
[3 pairs from $249](https://www.oscarwylee.com.au/amelia-sunglasses.html)
[](https://www.oscarwylee.com.au/shae-sunglasses.html)
[Shae](https://www.oscarwylee.com.au/shae-sunglasses.html)
$169    
Add to Cart
[Shop Shae](https://www.oscarwylee.com.au/shae-sunglasses.html)
[2 pairs from $199](https://www.oscarwylee.com.au/shae-sunglasses.html)
[3 pairs from $249](https://www.oscarwylee.com.au/shae-sunglasses.html)
### What are Cat Eye Sunglasses?
Cat eye sunglasses
refer to a trendy style of frame that is characterised by
upswept outer edges or corners of the frame.
The distinctive upper frame design closely resembles the
appearance of cat's eyes, hence its name. They were invented in
the 1930s by a designer, Altina Schinasi, and were made popular
during the 1950s and 1960s and were designed specifically for
women, according to Vogue Scandinavia. Cat eye frames can make
both stylish sunglasses and
[prescription glasses](https://www.oscarwylee.com.au/glasses.html)
with their elevated upper rim design for an effortless flair.
## How to Buy Cat Eye Sunglasses According to Width?
You can buy cat eye sunglasses according to bridge width;
however,
you will need to determine what is best suited to your face
size and face shape.
If you have a wider face, you may want to opt for wide frames,
or if you have a smaller or narrower face, you may want to wear
narrow frames, for example. At Oscar Wylee, we offer cat eye
sunglasses in narrow, medium and wide widths. The ways to buy
cat eye sunglasses according to width are listed below.
* Narrow: Narrow width frames are available at
Oscar Wylee. Our narrow frames are suitable for petite and
narrow faces.
* Medium: Medium frames are available at Oscar
Wylee in a wide selection of shapes and styles. Medium frames
are well-suited to those with average or medium sized faces.
* Wide: Wide frames are available at Oscar
Wylee. Wide frames are good for those with wider, larger
faces.
### Which Colour Pattern is Best for Cat Eye Sunglasses?
The colour pattern that may be best for cat eye sunglasses can
include solid, tortoise and
transparent. It is important to note that the
best colour pattern for cat eye sunglasses is completely up to
you, and the options provided are general recommendations that
are often trending. The available colour patterns for cat eye
sunglasses are listed below.
* Solid Cat Eye Sunglasses: A solid colour
pattern can be a great choice for cat eye sunglasses as it
allows more attention to the details and overall design of the
frame.
* Tortoise Cat Eye Sunglasses: A tortoise
colour pattern is quite a popular choice for cat eye
sunglasses as it offers wearers a versatile way to step up
their usual acetate glasses rotation.
* Transparent Cat Eye Sunglasses: A transparent
colour pattern offers individuals the perfect subtle and
minimalist elevation that can be easily paired with any outfit
due to its versatility.
## How does Nose Shape Affect Wearing Cat Eye Sunglasses?
Nose shapes can affect the wearing of
cat eye sunglasses as they can contribute to the fit of the
frame.
[There are many different types of nose shapes](https://www.oscarwylee.com.au/glasses/nose-types); therefore, it is important to try on different styles of cat
eye sunglasses to ensure your sunglasses align well according to
your facial features.
### Are Clear Frames Suitable for Cat Eye Sunglasses?
Yes, clear frames
can be suitable for cat eye sunglasses. Just like with any
other clear frame for sunglasses, they can make a perfectly
versatile eyewear that can enhance your overall look in the
most minimal and yet significant way.
Their transparent appearance makes
[clear frame glasses](https://www.oscarwylee.com.au/glasses/clear-glasses.html)
especially easy to pair with a wide range of outfit styles.
#### Can Cat Eye Sunglasses be Used for Outdoor Sports?
Yes, cat eye sunglasses
can be used for outdoor sports, depending on the type of
sport. However, cat eye sunglasses may be better for more
casual types of sports
and/or physical activities, rather than sports that involve a
lot of fast and spontaneous movement. You can get specifically
designed sunglasses, optimal for outdoor sports, from our
[active collection.](https://www.oscarwylee.com.au/sunglasses/collection/active-collection.html)
### Can you adjust Cat Eye Sunglasses' Nose Pads?
Yes, you can adjust the nose pads on cat eye sunglasses,
depending on the type of nose pads they have. If they have
the adjustable silicone nose pads, they can be adjusted to
specifically fit your nose bridge. However, fixed or standard nose pads on cat eye sunglasses
cannot be adjusted, since they are permanently moulded onto the
frame.
### Which Lens Options Work Best with Cat Eye Sunglasses?
Many different lens types can work best with cat eye
sunglasses; however, you should consult with your optometrist
on
which lens type may be the most suitable for cat eye sunglasses.
They will be able to provide their professional opinion on the
most appropriate frame for your vision requirements and personal
preferences. Here at Oscar Wylee, we have many different options
available to choose from, learn more about our
[8 different types of lenses](https://www.oscarwylee.com.au/glasses/eye/types-of-lenses)
and how they might benefit you and your vision.
### How Durable are Cat Eye Sunglasses Frames?
Cat eye sunglasses frames
can be optimally durable frames as they are crafted from
high-quality materials such as acetate, bioacetate and
metal.
Cat eye sunglasses frames from Oscar Wylee are durable for daily
wear; however, it is important to always handle your frames with
care to ensure you get the most wear out of them.
## What Factors Affect the Price of Cat Eye Sunglasses?
The factors that affect the price of cat eye sunglasses at Oscar
Wylee can differ based on elements such as the glasses range,
add-ons and lens types.
One pair of cat eye sunglasses starts from our range price of
$169, 2 pairs from $199 and 3 pairs from $249. It should be noted that prescription lens thickness and other
add-ons will affect overall pricing. See our full
[price guide](https://www.oscarwylee.com.au/price-guide/)
for more information.
### What is the Duration of Shipment for Cat Eye Sunglasses?
You can expect to get your cat eye sunglasses
within 7-10 business days from the date of purchase when
collecting in-store. A team member will contact you once your glasses have passed
through all the quality control checks and are ready for
collection.
If your order is being shipped to your home, it may take up
to 2 weeks
to arrive. This includes the production time of 7-10 business
days and additional time for shipping.
[Prescription Glasses](https://www.oscarwylee.com.au/glasses.html)
[Women’s Glasses](https://www.oscarwylee.com.au/glasses/collection/womens-glasses.html)
[Men’s Glasses](https://www.oscarwylee.com.au/glasses/collection/mens-glasses.html)
[Senior Glasses](https://www.oscarwylee.com.au/glasses/collection/seniors.html)
[Glasses for Kids](https://www.oscarwylee.com.au/glasses/collection/kids-collection.html)