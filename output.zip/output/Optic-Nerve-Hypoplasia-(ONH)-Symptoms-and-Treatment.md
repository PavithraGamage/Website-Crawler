# Source: https://www.oscarwylee.com.au/glasses/eye/optic-nerve-hypoplasia-onh

# Optic Nerve Hypoplasia (ONH): Symptoms and Treatment
Published on August 17th, 2026
Optic nerve hypoplasia (ONH) is a congenital disorder that is characterised by the underdevelopment of the optic nerves. The optic nerve sends signals from the retina’s ganglion cells to the brain and therefore is crucial for vision. According to the National Organisation for Rare Disorders, individuals with optic nerve hypoplasia typically present symptoms such as vision loss ranging from mild blurry vision to blindness. As children grow, optic nerve hypoplasia may affect their physical growth and development depending on the extent of their condition.
Prioritise your eye health!
See us for your next eye check-up! Our optometrists can help you stay up to date.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Definition](#definition)
[Causes](#causes)
[Symptoms](#symptoms)
[Support](#support)
## What is Optic Nerve Hypoplasia?
Optic nerve hypoplasia is when one or both optic nerves are underdeveloped or smaller at birth. Optic nerves are what enable your vision by transmitting signals from the retina to the brain. ONH can cause impaired vision from mild blurriness to total blindness and can cause abnormal eye movements.
### What Causes Optic Nerve Hypoplasia?
The causes of optic nerve hypoplasia remain unknown. While the exact causes of this condition cannot be confirmed, it may generally stem from a combination of genetic and/or environmental factors.
#### Is Optic Nerve Hypoplasia Present in One or Both Eyes?
Yes, optic nerve hypoplasia can present in one or both eyes. Whether one or both eyes are affected may depend on the severity of your condition.
## What are the Symptoms of Optic Nerve Hypoplasia?
The symptoms of optic nerve hypoplasia are reduced vision, nystagmus, strabismus, light sensitivity and blindness. The symptoms of optic nerve hypoplasia are listed below.
* Reduced Vision:
Reduced vision can be a symptom of optic nerve hypoplasia as a result of an underdeveloped or smaller optic nerve. [Vision may be impaired](https://www.oscarwylee.com.au/glasses/eye/visual-impairment) in one or both eyes and to varying degrees.
* Nystagmus:
[Nystagmus](https://www.oscarwylee.com.au/glasses/eye/nystagmus) can be a symptom of bilateral optic nerve hypoplasia and can develop in the first three months from birth. This condition causes the eyes to involuntarily and rapidly move in up-and-down, circular, or side-to-side motions.
* Light Sensitivity:
[Light sensitivity](https://www.oscarwylee.com.au/glasses/eye/light-sensitivity) from optic nerve hypoplasia can occur if the optic nerve is underdeveloped and can depend on the severity of vision loss. According to Kaur et al. (2013) in their paper for the Oman Journal of Ophthalmology, assessment of the light reflex is important, as there may be an extent of poor light response.
* Blindness:
Blindness can occur from optic nerve hypoplasia as a result of the optic nerve not being fully developed before birth. The optic nerve transmits the visual signals from the retina directly to the brain, enabling sight.
### How does ONH Affect Visual Acuity?
ONH can affect visual acuity as the optic nerve is not completely developed and therefore hinders the transmission of visual signals from the retina’s ganglion cells to the brain. Impaired visual acuity from optic nerve hypoplasia can range from mild blurriness to total blindness.
#### Does ONH Cause Abnormal Eye Movements?
Yes, ONH can cause abnormal eye movements, also known as nystagmus. An underdeveloped or smaller optic nerve may disrupt clear signals from being sent to the brain during the early stages of infancy. This can then impair the stabilisation of the eye’s fixation system.
## How is Optic Nerve Hypoplasia Diagnosed?
Optic nerve hypoplasia may be diagnosed through an eye test with an optometrist. Different methods that are part of a routine eye test can help the optometrist examine the necessary parts of the eye, including the optic nerve.
### What Does an Eye Exam Show in ONH?
An [eye exam](https://www.oscarwylee.com.au/glasses/eye/test-glossary) for ONH may show a smaller or paler optic nerve. An optometrist will be able to distinguish between a normal and healthy optic nerve based on the appearance and/or size.
#### Can an MRI Detect Abnormalities Linked to ONH?
Yes, an MRI can detect abnormalities linked to ONH. According to ScienceDirect, an MRI will be able to identify thinning and size abnormalities of the optic nerve. While an MRI can visualise the appearance of the optic nerve, you will still need to see an optometrist for a proper diagnosis of your eye and vision condition.
Find Your Nearest OW Store!
We've got knowledgeable teams who are passionate about delivering
high-quality care.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
## How is Optic Nerve Hypoplasia Treated?
Optic nerve hypoplasia may be treated with vision therapy, hormone replacement or mobility training. It is important to note that there is currently no treatment that will cure optic nerve hypoplasia. Vision therapy, hormone replacement or mobility training may aid in treating the symptoms, according to Vision Australia.
### What Vision Support is Used for People With ONH?
Vision support for people with ONH may include low-vision aids and early intervention. Low vision aids can include magnifiers of different forms to help enlarge text and images. Talking aids can help by verbalising the needed information and are incorporated with household and/or kitchen appliances. Early intervention should start soon after diagnosis to help build vision and sensory skills as needed. [Prescription glasses](https://www.oscarwylee.com.au/glasses.html) may only provide support for people with ONH who also have nearsightedness, farsightedness or astigmatism, depending on the severity of vision impairment.
#### Is There a Cure for Optic Nerve Hypoplasia?
No, there is no cure for optic nerve hypoplasia. Vision loss from an underdeveloped or smaller optic nerve cannot be restored. However, early intervention may help with managing the impact of vision loss and building sensory skills.
## How can ONH Affect Hormone and Pituitary Function?
Optic nerve hypoplasia may affect hormone levels; the pituitary gland and hypothalamus all form together during early brain development. When optic nerve hypoplasia occurs, these neighbouring structures may also be underdeveloped, hindering the pituitary gland’s ability to release important signals. This disruption can cause shortages in hormones that contribute to your cortisol levels.
## How does ONH Affect Children as They Grow?
ONH may affect children as they grow, as it can cause brain malformations and pituitary issues. According to the National Organisation for Rare Disorders, some affected children may have no issues with their intellect, and some children may have learning disabilities or developmental delays.
### Does ONH Get Worse Over Time?
ONH may not get worse over time. It is considered a stable condition, so it typically remains the same over time. In some cases, vision or nystagmus can improve.
## How Does Optic Nerve Hypoplasia Affect Daily Life?
Optic nerve hypoplasia may affect daily life as it causes vision loss, blindness and potential growth delays. This may make it difficult to conduct regular tasks; however, the impact of any vision loss will depend on the extent of your condition and vary between individuals. Early intervention from the age of diagnosis may help patients cope with the effects better later in life.
### What Support Can Help Children With Vision Loss?
The support that may help children with vision loss includes 
early intervention, low-vision services, educational accommodations, orientation and mobility training and family support. The different forms of support that can help children with vision loss are listed below.
* Early Intervention:
Early intervention can help children with vision loss as it provides specialised therapy to help infants and toddlers meet crucial cognitive, motor, language, and sensory milestones.
* Low-Vision Services:
Low vision services improve functional vision through optical aids such as magnifiers and practical strategies that make the most of a child's remaining sight.
* Educational Accommodations:
Educational accommodations include adjustments for classroom activities, such as using tailored learning tools like Braille, tactile kits, and large-print text.
* Orientation and Mobility Training:
Orientation and mobility training can help build safe movement skills by teaching children spatial awareness, how to use their cane, and navigating independently in home, school, and community settings.
* Family Support:
Family support may involve helping children develop more independence by providing parents with coaching, emotional support, and advocacy tools.
#### Can Early Intervention Improve Outcomes for Children With ONH?
Yes, early intervention can improve outcomes for children with ONH. Early intervention prioritises developing strong visual skills, learning and managing daily tasks and should begin soon after diagnosis and identifying which developmental skills are needed.
Experience High-Quality Eyecare Services From Our Team
Book an appointment online with an Oscar Wylee optometrist today.
[Book an eye test](https://www.oscarwylee.com.au/booking)
Major Health Funds Accepted In-store
For the purchase of frames and lenses, use your private health fund to limit how much you pay from your own pocket.
[Health Funds](https://www.oscarwylee.com.au/health-funds.html)