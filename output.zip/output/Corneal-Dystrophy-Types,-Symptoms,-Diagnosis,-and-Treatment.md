# Source: https://www.oscarwylee.com.au/glasses/eye/corneal-dystrophy

# Corneal Dystrophy: Types, Symptoms, Diagnosis, and Treatment
Published on February 12th, 2024
Updated on March 5th, 2024 
Australia
[Australia](https://www.oscarwylee.com.au/glasses/eye/corneal-dystrophy)
[Canada](https://oscarwylee.ca/glasses/eye/corneal-dystrophy)
[Canadian French](https://oscarwylee.ca/fr/glasses/eye/corneal-dystrophy)
Corneal dystrophy refers to a group of eye diseases that impact the cornea,
which is the clear layer at the front of the eye. Corneal dystrophies are
progressive, may worsen over time. Corneal dystrophies are also often
hereditary, meaning if a family member has corneal dystrophy, a person is
more at risk for developing the condition. Types of corneal dystrophy
include keratoconus, Fuchs’ dystrophy and Lattice corneal dystrophy.
Treatment for corneal dystrophies includes eye drops, laser treatment and
corneal transplant.
Prioritise Your Eye Health
Taking good care of your eyes is important, which is why you need to have
regular eye tests. Book yours today with an Oscar Wylee optometrist.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Definition](#definition) [Types](#types)
[Symptoms](#symptoms) [Treatment](#treatment)
[Prevention](#prevention)
## What is Corneal Dystrophy?
Corneal dystrophy refers to
a collection of eye diseases that affect the cornea, the clear window
at the front of the eye.
Corneal dystrophy is characterised by changes to the cornea, such as a
build-up of material. A build-up in the cornea can affect corneal
transparency and in turn how the cornea refracts light, according to
Moshirfar M, Bennett P and Ronquillo Y. in the paper
Corneal Dystrophy. Corneal dystrophies are often hereditary and
progressive, meaning that they worsen over time. Corneal dystrophies are
also non-inflammatory, meaning they do not cause inflammation to the
cornea.
### What is the Other Term for Corneal Dystrophy?
There is no other term for corneal dystrophy. However, there
are different types of corneal dystrophies known by their own names
such as Fuchs’ Corneal Dystrophy.
#### Is Corneal Dystrophy the Same as Keratoconus?
Keratoconus is a type of corneal dystrophy.
[Keratoconus](https://www.oscarwylee.com.au/glasses/eye/keratoconus)
is an eye condition in which the cornea changes shape into a cone.
According to Arne JL and Fournié P in the article
Keratoconus, the most common corneal dystrophy. Can keratoplasty
be avoided?
Keratoconus is the most common form of corneal dystrophy, occurring
when the cornea thins, leading to corneal ectasia.
## What are the Types of Corneal Dystrophy?
There are many different types of corneal dystrophies, which are defined
as a group of genetic diseases that affect corneal transparency and
refraction. Certain types of corneal dystrophy include
keratoconus, Fuchs’ dystrophy and lattice corneal dystrophy.
These types of corneal dystrophy and their definitions are listed below.
* Keratoconus:  Keratoconus is a type of
corneal dystrophy that causes the centre of the cornea to thin and
become cone-shaped.
* Fuchs’ dystrophy:  Fuchs’ dystrophy
causes the endothelial cells in the cornea to stop working, leading
the cornea to become thicker and swell.
* Lattice corneal dystrophy:  Lattice
dystrophy, or lattice corneal dystrophy, is an inherited disorder that
results in progressive vision loss.
### 1. Keratoconus
Keratoconus is a type of corneal dystrophy that
causes the centre of the cornea to thin and become cone-shaped.
As the cornea thins, the pressure in the eye causes the cornea to
distort which leads to a cone-shaped bulge. Symptoms of keratoconus
include blurry vision, double vision, sensitivity to light and halos
around light. This eye condition can be treated with prescription
glasses, contact lenses, a corneal transplant and corneal
cross-linking.
### 2. Fuchs’ Dystrophy
Fuchs’ dystrophy
causes the endothelial cells in the cornea to stop working, leading
the cornea to become thicker and swell.
According to the National Library of Medicine, the symptoms of Fuchs’
dystrophy include cloudy corneas, blurry vision, glare and haloes in
your vision and sensitivity to light. This eye condition may be
treated with medications and other therapies including soft contact
lenses, or through surgery such as a corneal transplant.
### 3. Lattice Dystrophy
Lattice dystrophy, or lattice corneal dystrophy, is an inherited
disorder, according to an article published in the National Library of
Medicine, and is
characterised by deposits of amyloid into the cornea leading to
vision loss.
Symptoms of lattice dystrophy include corneal erosions, dry eyes and
irregular astigmatism. This eye condition may be treated with surgery
with penetrating keratoplasty being the treatment of choice.
## What are the Corneal Dystrophy Risk Factors?
The main risk factor for developing corneal dystrophy
is a family history of the disease. According to the American
Academy of Ophthalmology, most corneal dystrophies are genetic, meaning
if you have a family member who has the condition, you are more likely
to develop the condition.
### How Common is Corneal Dystrophy?
Corneal dystrophy
can be common depending on which layer of the cornea is
affected.
In Australia, Fuchs’ dystrophy is the most common form of corneal
dystrophy that affects 1 in every 25 individuals in the country,
according to the Lions Eye Institute. However, according to the
American Academy of Ophthalmology, other types of corneal dystrophy
are generally considered rare.
#### Is Corneal Dystrophy a Common Corneal Disease?
Yes and no, certain types of
corneal dystrophy may be common, such as Fuchs’ dystrophy, which
affects the corneal endothelial cells.
However, other forms of corneal dystrophy are not considered a
common corneal disease. According to the National Eye Institute, the
most
[common forms of corneal disease](https://www.oscarwylee.com.au/glasses/eye/corneal-diseases)
may be
[corneal abrasions](https://www.oscarwylee.com.au/glasses/eye/corneal-abrasion), inflammation and eye infections.
#### Is Corneal Dystrophy Common For Kids?
No, corneal dystrophy may not be common for kids. According
to the National Organisation for Rare Disorders, the incidence rate
for corneal dystrophy is not established due to many individuals
presenting as asymptomatic. Therefore, it may be too difficult to
accurately confirm how common corneal dystrophy is for kids and
other age groups.
## What are the Symptoms of Corneal Dystrophy?
The exact symptoms of corneal dystrophy will largely depend upon what
type of dystrophy a person has or the severity of the condition.
Possible symptoms of corneal dystrophy can include
eye pain, light sensitivity (photophobic), tearing eyes, glare, dry
eyes, corneal abrasion or erosion, feeling something in the eye and
blurry vision.
The possible symptoms of corneal dystrophy are listed below.
* Eye pain:  Eye pain, which may include
a shooting, throbbing or aching pain, can be a symptom of corneal
dystrophy.
* Light sensitivity (Photophobia): 
Light sensitivity refers to a feeling or discomfort or pain when
looking at light, and may be a symptom of corneal dystrophy.
* Tearing eyes:  Tearing eyes or watery
eyes can be a symptom of corneal dystrophy.
* Glare:  Glare refers to light that
disturbs the vision and may be a symptom of corneal dystrophy.
* Feeling of something in the eye:  The
feeling of something in the eye can be a symptom of corneal dystrophy,
caused by a build-up of materials in the eye or corneal abrasion.
* Blurry vision:  Blurry vision is a
common symptom of corneal dystrophy, caused by changes to the cornea
such as a build-up of materials in the cornea.
### 1. Eye Pain
Eye pain
refers to a feeling of throbbing, aching or shooting pain in the
eye and can be a symptom of corneal dystrophy, especially if corneal
erosion has occurred.
According to the National Organisation for Rare Diseases, corneal
erosion can occur as a result of multiple corneal dystrophies. Corneal
erosion occurs when the outer layer of the cornea, the epithelium,
does not stick to the eye properly, which can lead to
[eye pain](https://www.oscarwylee.com.au/glasses/eye/pain-definition).
### 2. Light Sensitivity (Photophobia)
Light sensitivity, also known as photophobia,
refers to a sensitivity to light that may cause pain or discomfort
in the eyes and the head.
[Light sensitivity (photophobia)](https://www.oscarwylee.com.au/glasses/eye/light-sensitivity)
may be a symptom of corneal dystrophy, particularly if corneal
abrasion or erosion has occurred.
According to Digre KB and Brennan KC. in the article,
Shedding light on photophobia, any painful stimulus to the
cornea, such as corneal abrasion caused by certain corneal
dystrophies, can lead to photophobia.
### 3. Tearing Eyes
Tearing eyes refers to an excess of tears, which can occur as a symptom of
multiple corneal dystrophies such as Lattice Corneal Dystrophy and
Meesmann Corneal Dystrophy. [Tearing eyes](https://www.oscarwylee.com.au/glasses/eye/watery)
or watery eyes can be caused by several factors including [dry eyes](https://www.oscarwylee.com.au/glasses/eye/dry-eyes), which may lead to the eyes producing an excess amount of tears to
compensate, or blocked tear ducts. Tearing eyes can also be caused
by corneal abrasions, occurring as a result of corneal
dystrophies.
### 4. Glare
Glare
refers to light that interferes with a person’s vision and may be a
symptom of corneal dystrophy.
Glare may occur as a symptom of Fuchs’ dystrophy, as a result of the
way this condition affects the cornea and the way it refracts light.
Halos around light may also be a symptom of corneal dystrophy, in
which a person sees circles of light around a light source.
### 5. Feeling of Something in the Eye
The feeling of something in the eye
can be a symptom of corneal dystrophy, especially if corneal
erosion has occurred.
The feeling of something in the eye, also known as a foreign body
sensation or gritty eyes, refers to the feeling that there is an
object in the eyes that is not supposed to be there. The feeling of
something in the eye may present as a symptom of corneal dystrophies
such as Lattice Corneal Dystrophy, where there is a build-up of
material in the cornea or corneal abrasion.
### 6. Blurry Vision
Blurry vision is
a common symptom of multiple corneal dystrophies, caused by the
impact this condition has on the cornea and it’s ability to refract
light.
The cornea is the clear layer at the front of the eye that helps a
person see by focusing light onto the retina. If a person has a
corneal dystrophy, this means that the cornea is being affected in
some way. A build-up of material in the cornea, for example, may limit
the transparency of the cornea, which in turn affects how light is
reflected and can cause blurry vision.
## How is Corneal Dystrophy Diagnosed?
An optometrist typically
diagnoses corneal dystrophy during an eye test. During an eye
test, an optometrist will examine the structures of the eyes and assess
visual acuity. An eye test can involve the use of a slit lamp
microscope, which allows an optometrist to assess the structures of the
eye including the cornea. According to the American Academy of
Ophthalmology, some corneal dystrophies may be identified through
genetic testing.
Find an Oscar Wylee Store Near You
Come and visit your local Oscar Wylee store where our friendly team
will help you shop our range of stylish and affordable frames, and
assist with your eye care needs.
[Find an Oscar Wylee store](https://www.oscarwylee.com.au/locations/full-store-list.html)
### Which Eye Doctor Diagnoses Corneal Dystrophy?
The eye care professional who typically diagnoses corneal dystrophies
is an optometrist. In Australia, an optometrist is not an eye
doctor. In Australia, an eye doctor is referred to as an
ophthalmologist. Ophthalmologists are medical doctors with a
specialisation in eye care. An optometrist is a primary eye care
professional, who is the first point of contact for vision and eye
care needs. Optometrists are trained to provide eye tests, write
prescriptions and treat eye conditions.
#### Can an Optometrist Diagnose Corneal Dystrophy?
Yes, an optometrist can diagnose corneal dystrophy.
[Optometrists](https://www.oscarwylee.com.au/eye-care/optometrist)
are primary eye care providers that are trained to diagnose and
treat eye conditions such as corneal dystrophy.
### How Dangerous is Corneal Dystrophy?
Corneal dystrophy is
not a dangerous eye condition that will lead to serious health
complications, however, depending on the type of corneal dystrophy
present and the severity, corneal dystrophy may cause reduced vision
or pain,
according to the National Eye Institute.
#### Does Corneal Dystrophy Lead to Vision Loss?
Yes,
some forms of corneal dystrophy can lead to vision loss.
Corneal dystrophies describe a range of eye conditions that cause a
build-up of material in the cornea, that can lead to loss of corneal
transparency, according to the American Academy of Ophthalmology.
This corneal transparency can affect how the eye sees and refracts
light, and can lead to vision loss.
#### Is Corneal Dystrophy an Autoimmune Disease?
No, corneal dystrophy is not an autoimmune disease. Corneal
dystrophy is an eye disease that impacts the cornea, often
hereditary.
## What are the Treatments for Corneal Dystrophy?
The treatments for corneal dystrophy will be dependent upon what type of
corneal dystrophy a person has and the severity of their condition.
Treatments for corneal dystrophy may include
eye drops, laser treatment and corneal transplant.
* Eye drops:  Eye drops refer to a type
of medication applied to the eyes via a dropper, that may help in the
treatment of corneal dystrophy. Lubricating eye drops may be used to
help with dry eyes caused by corneal dystrophy.
* Laser treatment:  Laser treatment,
specifically an excimer laser may be used in the treatment of corneal
dystrophy. According to Columbia University, excimer lasers remove the
outermost layer of the corneal tissue to help limit issues associated
with corneal dystrophy.
* Corneal Transplant:  A corneal
transplant may be used to help treat corneal dystrophy if the
condition is severe. A corneal transplant refers to removing the
cornea tissue and replacing it with tissue from a donor.
### How Long Does Corneal Dystrophy Take to Heal?
The length of time it will take for corneal dystrophy to heal or for
symptoms to improve
will depend on the type of corneal dystrophy a person has and the
severity of their condition.
If a person has a corneal transplant, it may take 1 to 3 weeks to
recover and heal, according to the Centre for Eye Research Australia.
#### Can Corneal Dystrophy be Fixed Permanently?
Corneal dystrophy
may be fixed permanently if treatment like an excimer laser or
corneal transplant is undertaken.
Other treatment for corneal dystrophy such as eye drops, will not
fix the condition permanently, but may help to alleviate symptoms.
#### Does Corneal Dystrophy Heal Overnight?
No, corneal dystrophies will not heal overnight. Corneal
dystrophy is caused by a progressive buildup of material in the
cornea or a change to the function or shape of the cornea. This
buildup of material can cause changes to corneal transparency and
how the cornea refracts light. Treatments for corneal dystrophy can
include eye drops, ointments and in severe cases surgery. Depending
on the treatment used for corneal dystrophy, it may take several
days to several weeks to be effective.
#### Do Eye Drops Help Treat Corneal Dystrophy?
Eye drops
may be able to help treat some types of corneal dystrophy, such
as Fuchs’ dystrophy, however most treatments for corneal dystrophy
are dependent upon the type, and how severe the condition is.
For those with Fuchs’ dystrophy, in which there is a decline or
deterioration of the endothelial cells in the cornea, eye drops may
be prescribed for treatment. Lubricating eye drops may also be
prescribed for those who have corneal erosion, as a result of
corneal dystrophy, according to the American Academy of
Ophthalmology.
### How Can Oscar Wylee Help with your Corneal Dystrophy?
Oscar Wylee’s dedicated optometrists
can help patients with corneal dystrophy by providing eye tests for
diagnosing and monitoring the condition,
as well as helping with treatment. If you believe you may have corneal
dystrophy, visit an Oscar Wylee store near you and our optometrists
can help you with your concerns.
#### How can Glasses Correct Corneal Dystrophy?
Glasses are not typically used to help treat or correct corneal
dystrophy, but
certain contact lenses may be used to help treat this
condition. [Glasses](https://www.oscarwylee.com.au/glasses) are a
type of eyewear that help people to see better by correcting vision
issues such as myopia, hyperopia or astigmatism. Whilst some people
with corneal dystrophy may have glasses to help improve visual
acuity, they are not necessarily used as treatment for this
condition. According to the National Eye Institute, special contact
lenses may be used in the treatment of corneal dystrophy to stop the
eyelid from rubbing against the affected cornea.
## What are the Ways to Prevent Corneal Dystrophy?
As most corneal dystrophies are often hereditary, according to the
American Academy of Ophthalmology, there are no specific ways to prevent
corneal dystrophy. However, getting a regular eye test and taking steps
to maintain the health of the eyes such as
eating a healthy, balanced diet, and getting regular exercise can
help with the management of symptoms. The ways to maintain good eye
health are listed below.
* Regular eye test:  Regular eye tests
with your optometrist ensure that eye conditions such as corneal
dystrophy are detected early on and can be treated promptly to prevent
the worsening of symptoms.
* Eating a healthy, balanced diet: 
Eating a balanced, healthy diet including omega-3 fats, leafy greens,
fruits and protein can help maintain overall health, including the
health of the eyes.
* Getting regular exercise:  Getting
regular exercise can improve overall health, including the health of
the eyes.
### What is the Difference Between Corneal Dystrophy and Cataracts?
The difference between corneal dystrophy and cataracts is
the part of the eye these conditions affect. Corneal dystrophy
refers to a group of eye diseases that affect the cornea part of the
eye. Cataracts are a condition in which the lens of the eye becomes
clouded.
[Cataracts](https://www.oscarwylee.com.au/glasses/eye/cataracts)
and certain corneal dystrophies such as Fuchs’ Dystrophy may present
similar symptoms such as blurred or cloudy vision.
### What is the Difference Between Corneal Dystrophy and Corneal
Degeneration?
Although both corneal dystrophy and corneal degeneration are eye
conditions that impact the cornea part of the eye, there are some
distinct differences between the two conditions, mainly concerning
the causes of each.
According to Moshirfar M, Bennett P and Ronquillo Y in their paper
Corneal Dystrophy corneal degeneration is a broad term for
issues that alter the structure of the cornea, caused by a range of
factors such as infection, age and trauma. Corneal dystrophy is a more
specific term referring to issues with the cornea that are caused by
hereditary or genetic factors.
Read Corneal Dystrophy: Types, Symptoms, Diagnosis, and Treatment in
other Oscar Wylee regions and their languages.
Australia
[Australia](https://www.oscarwylee.com.au/glasses/eye/corneal-dystrophy)
[Canada](https://oscarwylee.ca/glasses/eye/corneal-dystrophy)
[Canadian French](https://oscarwylee.ca/fr/glasses/eye/corneal-dystrophy)
Major health funds accepted in-store
Your health fund may help cover some of the cost of your Oscar Wylee
eye test or new frames.
[Discover Health Funds](https://www.oscarwylee.com.au/health-funds.html)
Need to have your eyes tested?
We recommend that everyone should have an eye test with an optometrist
at least once every 2 years.
[Book an eye test](https://www.oscarwylee.com.au/booking)