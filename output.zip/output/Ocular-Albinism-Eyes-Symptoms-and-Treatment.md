# Source: https://www.oscarwylee.com.au/glasses/eye/ocular-albinism

# Ocular Albinism Eyes: Symptoms and Treatment
Published on June 26th, 2026
Australia
Australia
New Zealand
Canada
Canadian French

Ocular albinism is a form of albinism, a genetic condition that affects
the body's ability to produce melanin, according to Vision Australia. Ocular albinism solely affects the eyes,
giving them a pale appearance. Symptoms of ocular albinism can include
blurred vision, sensitivity to light, nystagmus, and poor depth perception,
according to the Mayo Clinic. There is no cure; however, it is important to
seek treatment for vision-related issues that emerge as a result of ocular
albinism.
Ready to book an eye test?
At Oscar Wylee we offer bulk billed eye tests for eligible Medicare card
holders.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Definition](#definition)
[Symptoms](#symptoms)
[Diagnosis](#diagnosis)
[Treatments](#treatments)
## What is Ocular Albinism?
Ocular albinism is a
type of albinism that involves only the eyes, in which there will be
no or very little pigment present, according to Health Direct. The skin and hair are unaffected by this
lack of pigment, unlike the other form of albinism, which is called
oculocutaneous albinism.
### How does Ocular Albinism Affect the Eyes?
Ocular albinism affects the eyes as it leads to a
reduced or lack of melanin in the retina and foveal
hypoplasia, according to the Albinism Fellowship of Australia, a national
non-profit organisation run by volunteers who have albinism. Those
with ocular albinism will have light coloured and even violet-hued
irises due to a lack of pigment inside the eye. Foveal hypoplasia is
common among those with ocular albinism. The fovea is a tiny pit
located in the back of the eye, which is part of the retina. This
condition involves an underdevelopment of the fovea, leading to
reduced visual acuity and visual processing.
### How is Ocular Albinism Different from Oculocutaneous Albinism?
Ocular albinism is different from oculocutaneous albinism as it
solely affects the eyes, which are deficient in
melanin, while in oculocutaneous albinism, there is a lack of pigment
in the skin, hair, and eyes, according to Vision of Children
Organisation.
#### Are These Two Types of Albinism the Same?
No, these two types of albinism are not the same.
While both affect the eyes, ocular albinism solely affects the eyes,
while oculocutaneous albinism affects the skin, hair and eyes.
## What do Ocular Albinism Eyes Look Like?
Ocular albinism eyes can vary in colour from
light grey or violet, blue and in some cases brown,
according to the Albinism Fellowship of Australia.
### What Eye Colours Can People With Ocular Albinism Have?
The eye colours that people with ocular albinism can have include
light grey,
[blue](https://www.oscarwylee.com.au/glasses/eye/blue)
and
[hazel](https://www.oscarwylee.com.au/glasses/eye/hazel),
although they can also look pink in the light, according to Health
Direct.
#### Do People With Albinism People Have Red Eyes?
No, people with albinism do not have red eyes. It
is a common myth that people with albinism have red eyes when, in
reality, it is only certain lighting conditions that can give this
appearance, as the blood vessels at the back of the eye can be seen,
according to the National Organisation for Albinism and
Hyperpigmentation.
## What Symptoms are Common in Ocular Albinism Eyes?
The symptoms that are common in ocular albinism eyes are
reduced visual acuity, nystagmus, light sensitivity, strabismus and
poor depth perception. Read more about the symptoms that are common in Ocular Albinism eyes
below.
* Reduced visual acuity: Reduced visual
acuity, also referred to as blurry vision will occur as those with
ocular albinism will struggle to see fine details and shapes in
clarity.
* Nystagmus: Nystagmus refers to the
involuntary movement of the eyes that causes them to flicker. This is
common among those with ocular albinism.
* Light sensitivity: Light sensitivity
is common among those with ocular albinism as individuals will have
problems adjusting to bright settings and glare.
* Strabismus: Strabismus refers to the
misalignment of the eyes, resulting in low or double vision, common
amongst those with Ocular Albinism.
* Poor depth perception: Poor depth
perception can occur as the nerve signals from the retina to the brain
do not follow the usual nerve routes, according to the Albinism
Fellowship of Australia. Because of this abnormality, the primary
visual cortex receives some inaccurate output, resulting in visual
impairments such as a lack of depth perception.
### Why do Ocular Albinism Eyes Shake or Move Involuntarily?
Ocular albinism eyes shake or
move involuntarily as one of the symptoms of this condition is
nystagmus,
which is involuntary movement of the eyes, according to Vision
Australia Organisation. Nystagmus will affect those with ocular
albinism to varying degrees, and it typically declines with age,
according to Vision for Tomorrow Foundation.
### Why are People With Ocular Albinism Sensitive to Bright Light?
People with ocular albinism are
sensitive to bright light due to the lack of pigment or melanin in
the retina, according to the Albinism Fellowship of Australia. This lack of
melanin means stray light is not absorbed, leading to light
sensitivity, formally known as
[photophobia](https://www.oscarwylee.com.au/glasses/eye/light-sensitivity).
#### Do All People With Ocular Albinism Have Nystagmus?
Yes, people with ocular albinism will highly likely have
[nystagmus](https://www.oscarwylee.com.au/glasses/eye/nystagmus). However, it will present to varying degrees in people with
albinism, according to Vision for Tomorrow.
Find Your Local Oscar Wylee Store
Use our store locator page to find your nearest Oscar Wylee store and
come see the team for all your eyewear and eyecare needs.
[Find a store](https://www.oscarwylee.com.au/locations)
## How Does Ocular Albinism Affect Vision?
Ocular albinism affects vision as it
leads to
[blurred vision](https://www.oscarwylee.com.au/glasses/eye/blurred-vision)
and depth perception. It can also lead to light sensitivity, nystagmus, strabismus and
refractive errors such as myopia, according to the School of Special
Needs Australia.
### Why Does Low Pigment in the Eyes Cause Vision Problems?
Low pigment in the eyes causes vision problems, as a lack of pigment
leads to a
decreased ability to process visual input and absorb stray
light,
leading to reduced visual acuity and light sensitivity, according to
Vision for Tomorrow Organisation.
#### Can People With Ocular Albinism See Normally?
No, people with ocular albinism typically do not see
normally.
They will have varying degrees of blurred vision, light sensitivity
and nystagmus. Vision levels for those with ocular albinism will
depend on the individual.
##### Can Ocular Albinism Cause Night Blindness?
Ocular albinism is
not directly correlated with
[night blindness](https://www.oscarwylee.com.au/glasses/eye/night-blindness).
However, it is more than likely that those with ocular albinism do
not have sufficient night vision.
## How is Ocular Albinism Diagnosed?
Ocular albinism is
diagnosed by an ophthalmologist or optometrist who will
be able to identify albinism in a person with no or very little melanin
by looking into the back of the eye, according to the
Albinism Fellowship of Australia.
### What Eye Tests are Used to Confirm Ocular Albinism?
An ophthalmologist or optometrist will be able to identify ocular
albinism by looking into the back of the eye, where there will be no or very little colour in the retina,
according to the Albinism Fellowship of Australia. Other traits
detected by these eye health professionals, such as nystagmus, blurry
vision, or lack of depth perception, will confirm the presence of
ocular albinism.
[Eye tests](https://www.oscarwylee.com.au/eye-care/eye-test)
such as a Snellen Chart will be able to gauge how
vision is impacted.
#### Can Doctors Detect Ocular Albinism Early?
Yes, doctors can detect ocular albinism early. It
is often obvious from a baby's appearance when they're born, meaning
ocular albinism will likely be diagnosed at birth, with genetic
testing undertaken, according to Health Direct.
##### Is Ocular Albinism One of the Rare Genetic Eye Diseases?
Yes, ocular albinism is
considered one of the rare genetic eye diseases,
reportedly affecting one male in 20,000 births, according to the
National Organization for Rare Disorders.
## What Treatments are Available for Ocular Albinism?
The treatments that are available for ocular albinism include
prescription glasses, low vision devices, polarised sunglasses and
transition lenses. It should be noted that these are not cures for ocular albinism, but
rather ways to manage vision issues. The treatments that are available
for ocular albinism are listed below.
* Prescription glasses: Prescription
glasses may be given to treat refractive errors that those with ocular
albinism may have.
* Low vision devices: Low vision devices
can be helpful for those with ocular albinism for easier completion of
daily tasks.
* Polarised sunglasses: Polarised
sunglasses reduce sun glare and block UV rays, which may be valuable
for those with ocular albinism, as they have light sensitivity.
* Transition lenses: Transition lenses
automatically darken in bright conditions for a convenient way to
manage light sensitivity in ocular albinism.
### Prescription Glasses
[Prescription glasses](https://www.oscarwylee.com.au/glasses.html)
can be prescribed by optometrists
for patients who are long-sighted or short-sighted.
These will correct refractive errors that those with ocular albinism
may have, to improve daily vision.
### Low Vision Devices
Low vision devices can be invaluable for those with ocular albinism.
Magnifiers, which can help with daily tasks such as reading, are a
common low vision device. They can come in many forms, such as handheld magnifiers,
telescopes and video camera magnifiers.
### Polarised Sunglasses
Polarised sunglasses are a good option for those with ocular albinism
when outdoors.
[Polarised sunglasses](https://www.oscarwylee.com.au/glasses/eye/polarised-lenses)
provide UV protection and reduce high levels of sun glare, perfect for those with light sensitivity.
### Transition Lenses
[Transitions® GEN S™ lenses](https://www.oscarwylee.com.au/transitions-lenses)
are a convenient option for those with ocular albinism. They
provide clarity for those with refractive errors if
they have a prescription, and
transition automatically to dark when in the sunlight.
This can help mitigate light sensitivity that typically emerges as a
result of ocular albinism.
##### Is There a Cure for Ocular Albinism?
No, there is currently no cure for ocular albinism.
## What is Life Like for People With Ocular Albinism Eyes?
Life for people with ocular albinism is generally similar to that of
those without ocular albinism.
However, those with ocular albinism will likely need regular eye care
throughout their life in order for their vision to be taken care of
effectively.
### How Can People Manage Daily Activities With Vision Loss?
People can manage daily activities with vision loss as a result of
ocular albinism using treatment measures recommended by health
professionals.
Prescription glasses, sunglasses, and low vision devices
are all equipment that can improve eyesight and help make daily
activities easier.
#### Can People With Ocular Albinism Live Independent Lives?
Yes, people with ocular albinism can definitely live independent
lives with vision
treatment equipment specific to their needs.
Read Ocular Albinism Eyes: Symptoms and Treatment in other Oscar Wylee regions and their languages.
Australia
Australia
New Zealand
Canada
Canadian French

Major Health Funds Accepted In-store
For the purchase of frames and lenses, use your private health fund
insurance to limit how much you pay from your own pocket.
[Explore Health Funds](https://www.oscarwylee.com.au/health-funds.html)
Are You Due for an Eye Test?
Regular eye tests are an important step in keeping eyes healthy. Book
now and an Oscar Wylee optometrist can provide a bulk billed eye test.
[Book an eye test](https://www.oscarwylee.com.au/booking)