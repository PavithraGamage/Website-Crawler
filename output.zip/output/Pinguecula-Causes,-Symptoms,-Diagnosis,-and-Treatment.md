# Source: https://www.oscarwylee.com.au/glasses/eye/pinguecula

# Pinguecula: Causes, Symptoms, and Treatment
Updated on June 18th, 2026
Published on May 12th, 2023
Australia    
[Australia](https://www.oscarwylee.com.au/glasses/eye/pinguecula)
[Canada](https://oscarwylee.ca/glasses/eye/pinguecula)
[Canadian French](https://oscarwylee.ca/fr/lunettes/oeil/pinguecula)
Pinguecula is a common, yellowish bump that forms on the white of the eye. Pinguecula is most commonly caused by exposure to ultraviolet (UV) light, wind, and dust. Most people have no symptoms other than the visible bump; however, if the pinguecula becomes inflamed, one may experience redness, dry eyes, eye irritation or discomfort, itchy eyes, a foreign body sensation, and blurry vision. Treatment for pinguecula involves various types of eye drops, protective eyewear, and, in severe cases, surgery.
It is important to note that Oscar Wylee offers optometry services only; this article is for educational purposes only and is not a substitute for professional medical advice, diagnosis, or treatment.
Prioritise Your Eye Health
Our team can help you stay up to date with regular eye tests to keep your eyes healthy!
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Definition](#definition) [Causes](#causes) [Symptoms](#symptoms) [Prevalence](#prevalence) [Treatments](#treatment) [Prevention](#prevention)
## What is Pinguecula?
Pinguecula is a small, yellowish growth that develops on the white part of the eye, according to ophthalmologist Dr. Nathan Kerr. Pinguecula commonly appears near the cornea, and is usually noncancerous and harmless. Long-term exposure to ultraviolet (UV) light, wind, and dust is a risk factor for developing pinguecula. Pinguecula is a common eye condition in adults, and most cases do not affect vision.
### What does Pinguecula Look Like?
Pinguecula looks like a small yellow or white bump on the white part of the eye. It is usually raised slightly above the surface. Pinguecula commonly appears on the side of the eye closest to the nose, according to The Australian Pterygium Centre.
### How does a Pinguecula Form on the White Part of the Eye?
Pinguecula forms when tissue on the conjunctiva, the clear, thin membrane covering the white part of the eye, thickens due to long-term irritation, according to the Better Health Channel, Victoria. Pinguecula develops as deposits of protein, fat, or calcium build-up, creating a raised, yellowish bump. The growth develops gradually and is usually benign.
Find Your Nearest OW Store!
We've got knowledgeable teams who are passionate about delivering high-quality care.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
## What Causes Pinguecula to Appear?
Several factors can cause pinguecula to appear, including sun exposure, environmental irritants, chronic dry eye, aging, and contact lens wear. Read more about these causes below.
* Sun Exposure: Sun exposure is the leading cause of pinguecula, as UV light can damage eye tissue.
* Environmental Irritants: Environmental irritants such as dry air, wind, dust, sand, or smoke can lead to pinguecula, causing friction and micro-inflammation on the eye's surface.
* Chronic Dry Eye: Chronic dry eye, which reduces proper tear lubrication, can accelerate tissue changes in the eye and cause pinguecula.
* Aging: Aging is a risk of developing a pinguecula from environmental damage over time.
* Contact Lens Wear: Contact lens wear (particularly rigid or hard lenses) can cause friction and minor inflammation over time and lead to pinguecula, according to ophthalmologists Anjana Somnath and Koushik Tripathy's medical article titled 'Pinguecula' published in 2023 in StatPearls in the National Center for Biotechnology Information.
### How does Sun Exposure Increase the Risk of Pinguecula?
Sun exposure increases the risk of pinguecula through long-term UV damage to the conjunctiva, which can cause the outer layer of the eye to degenerate and thicken, according to The Royal Australian and New Zealand College of Ophthalmologists (RANZCO). Long-term exposure to UV light has cumulative effects, and adults who engage in more outdoor activity may be more susceptible to pinguecula. Protective eyewear, such as sunglasses, may reduce the risk of developing pinguecula.
#### Can Wind, Dust, and Dry Air Trigger Pinguecula?
Yes, wind, dust, and dry air can trigger pinguecula development. These environmental irritants can cause dryness, friction, and micro-inflammation, which can accelerate tissue change and therefore pinguecula growth, according to ophthalmologist Dr. Nathan Kerr.
## What Symptoms Can Pinguecula Cause?
While many people experience no other symptoms apart from the raised growth on their eye, pinguecula can sometimes cause eye redness, dry eye, eye irritation or discomfort, itchy eyes, foreign body sensation, and blurry vision. These pinguecula symptoms are explained further below.
### 1. Eye Redness
[Eye redness](https://www.oscarwylee.com.au/glasses/eye/red-or-bloodshot) can occur when the area around the pinguecula growth becomes inflamed and bloodshot, often triggered by environmental irritants.
### 2. Dry Eye
[Dry eye](https://www.oscarwylee.com.au/glasses/eye/dry-eyes) can be caused by pinguecula, as the eye's surface is disrupted by the raised bump, which can interfere with tears spreading evenly, according to ophthalmologists Anjana Somnath and Koushik Tripathy's medical article titled 'Pinguecula' published in 2023 in StatPearls in the National Center for Biotechnology Information.
### 3. Eye Irritation or Discomfort
[Eye irritation](https://www.oscarwylee.com.au/glasses/eye/irritation-causes) or discomfort can occur due to the uneven distribution of tear film on the eyes caused by a pinguecula.
### 4. Itchy Eyes
[Itchy eyes](https://www.oscarwylee.com.au/glasses/eye/itchy-eye-causes) can be caused by pinguecula, mostly due to dryness caused by disruption to tear production. Dryness in the eyes can lead to itching, burning, or a foreign body sensation in the eye.
### 5. Foreign Body Sensation
A foreign body sensation in the eyes can be caused by the bump's texture. This can often feel like there is grit, sand, or an eyelash stuck in the eye.
### 6. Blurry Vision
Blurry vision may be caused by a pinguecula due to dry eye, which may temporarily blur eyesight. Pinguecula does not grow over the cornea, unlike a related condition called pterygium.
## When does Pinguecula Become Inflamed?
Pinguecula becomes inflamed when irritation affects the growth and surrounding tissue, according to the Better Health Channel, Victoria. This condition is called pingueculitis and can cause the area to become red and swollen, and a foreign body sensation may occur. Inflammation commonly occurs due to environmental irritants, severe dry eyes, and allergies.
### How does Pingueculitis Differ From a Normal Pinguecula?
A normal pinguecula differs from pingueculitis as it is usually painless, while pingueculitis involves inflammation and irritation. Pingueculitis often causes more noticeable symptoms such as redness and discomfort.
## How Common is Pinguecula?
Pinguecula is a common eye condition, particularly in adults. Pinguecula affects up to 10% of Australian adults, and prevalence increases with age, according to The Australian Pterygium Centre. Pinguecula occurs more often in adults exposed to sunlight and outdoor environments.
### What Age does Pinguecula Usually Appear?
Pinguecula usually appears during adulthood and becomes more common with age. The prevalence of pinguecula increases notably after 40, and by 80, almost all individuals will show some evidence of pinguecula, according to ophthalmologists Anjana Somnath and Koushik Tripathy's medical article titled 'Pinguecula' published in 2023 in StatPearls in the National Center for Biotechnology Information.
#### Is it Possible for Kids to Develop Pinguecula?
Yes, it is possible for kids to develop pinguecula, although it is less common. Environmental exposure increases the risk of developing pinguecula in children. The use of protective eyewear may help reduce the risk.
## How is Pinguecula Different From Pterygium?
Pinguecula is a growth on the conjunctiva, while [pterygium](https://www.oscarwylee.com.au/glasses/eye/pterygium-definition) grows toward the cornea and can affect vision, according to The Royal Australian and New Zealand College of Ophthalmologists (RANZCO). Other differences are that pinguecula is yellowish, whereas pterygium is more pinkish, often with prominent blood vessels. Both pinguecula and pterygium develop in response to similar environmental factors, including UV exposure, wind, and dust, according to the Better Health Channel, Victoria.
#### Can a Pinguecula Turn Into a Pterygium?
Yes, a pinguecula can turn into a pterygium in some cases, according to Clarity Eye Surgeons, Australia. A pinguecula can turn into a pterygium due to continued exposure to environmental irritants such as UV exposure, wind, and dust, leading to the growth crossing onto the cornea and developing visible blood vessels, becoming a pterygium.
## What Treatments are Available for Pinguecula?
There are several treatments available for pinguecula, including eye drops such as lubricating eye drops and anti-inflammatory drops, protective eyewear, and, in severe cases, surgery. Read more about these treatments available for pinguecula below.
* Lubricating Eye Drops: Lubricating eye drops, such as over-the-counter artificial tears, can help to relieve dryness and irritation.
* Anti-Inflammatory Drops: Anti-inflammatory drops may be prescribed by your doctor for pingueculitis to reduce inflammation in the short-term.
* Protective Eyewear: Protective eyewear, such as sunglasses, is an effective way to prevent pinguecula from worsening as they block UV rays.
* Surgery: [Surgery](https://www.oscarwylee.com.au/glasses/eye/surgery) for a pinguecula is typically a last resort treatment reserved for severe cases.
#### Do Over the Counter Eye Drops Help Manage Pinguecula Symptoms?
Yes, over-the-counter [eye drops](https://www.oscarwylee.com.au/glasses/eye/types-of-eye-drops) can help manage pinguecula symptoms. Over-the-counter eye drops can reduce dryness and irritation associated with pinguecula. Options include lubricating drops, preservative-free drops, and eye ointments.
#### Can Pinguecula be Prevented or Removed?
Yes, pinguecula can often be prevented through eye protection and may be removed surgically when necessary. Eye protection is highly effective at preventing pinguecula growth. Most cases of pinguecula do not require removal, and it is generally reserved for severe cases. Removal involves an ophthalmologist surgically cutting away the growth. Surgery is the only way to remove a pinguecula, but it can potentially return after surgical removal.
### When is Pinguecula Removal or Surgery Considered?
Pinguecula removal or surgery is considered when a pinguecula causes significant discomfort, cosmetic concerns, or persistent inflammation. Most cases of pinguecula do not need surgery, and doctors prefer non-surgical treatments first. These factors that affect surgery consideration are explained below.
* Significant Discomfort: Significant discomfort can refer to the pinguecula, causing a chronic foreign body sensation that cannot be treated with medication.
* Cosmetic Concerns: Cosmetic concerns may be a factor in pinguecula removal, as a patient may wish to restore the natural white of the eye.
* Persistent Inflammation: Persistent inflammation of the pinguecula (pingueculitis) that does not respond to medication can be grounds for surgical removal.
#### Does Pinguecula Go Away on Its Own?
No, a pinguecula will not go away on its own. The only treatment option that will remove a pinguecula completely is surgery.
#### Can Pinguecula Cause Blindness?
No, a pinguecula does not cause blindness. However, if a pinguecula progresses into a pterygium and starts to grow over the cornea, this may cause issues with vision.
## How to Prevent Pinguecula?
The best way to prevent pinguecula is by protecting the eyes from environmental elements such as UV rays, wind, and dust. Wearing sunglasses when outside can help protect the eyes from UV radiation emitted from the sun. Sunglasses and other protective eyewear, such as goggles, should also be worn in windy, dusty environments to protect the eyes.
It is important to note that Oscar Wylee offers optometry services only; this article is for educational purposes only and is not a substitute for professional medical advice, diagnosis, or treatment.
Read Pinguecula: Causes, Symptoms, and Treatment in other Oscar Wylee regions and their languages.
Australia    
[Australia](https://www.oscarwylee.com.au/glasses/eye/pinguecula)
[Canada](https://oscarwylee.ca/glasses/eye/pinguecula)
[Canadian French](https://oscarwylee.ca/fr/lunettes/oeil/pinguecula)
Experience High Quality Eyecare Services From Our Team
Book an appointment online with an Oscar Wylee optometrist today.
[Book an eye test](https://www.oscarwylee.com.au/booking)
Major Health Funds Accepted In-store
For the purchase of frames and lenses, use your private health fund to limit how much you pay from your own pocket.
[Health Funds](https://www.oscarwylee.com.au/health-funds.html)