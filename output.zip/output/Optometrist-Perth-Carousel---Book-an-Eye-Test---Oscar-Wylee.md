# Source: https://www.oscarwylee.com.au/locations/optometrist-carousel.html

# Optometrist Carousel
Westfield Ground Level, Shop 1131A1382 Albany HwyCannington WA 6107
* Near Dusk
Opening hours
Monday9:00am - 5:30pm
Tuesday9:00am - 5:30pm
Wednesday9:00am - 5:30pm
Thursday9:00am - 8:00pm
Friday9:00am - 5:30pm
Saturday9:00am - 5:00pm
Sunday11:00am - 5:00pm
*Store hours reflect local standard trading hours and exclude public holidays
[Visit our Carousel Google Business page for directions, reviews, and updates.](https://g.page/r/CQj7ufocNLvSEBA)
Book Appointment
[Call us: (08) 6249 4721](tel:(08) 6249 4721)
[Leave a Review!](https://g.page/r/CQj7ufocNLvSEAg/review)
Our Reviews
Tek Bahadur Samal
2 days ago
I have a great experience. Service was outstanding
jenn clark
4 days ago
Jennine Haymes
4 days ago
Zara Lys-Mathews
5 days ago
Thank you to the lovely lady who fixed my glasses today. My favourite pair have been discontinued an...d she took extra time to fix them for me! So sweet and made my day.
See more
Tshewang Romeo Norbu
1 week ago
It was really great, the doctor was very gentle and kind. She was very kind and soft spoken.
Vanessa Dos Santos
1 week ago
Thank you for excellent Customer Service. Walking into your store is a reflection of the service you... offer.
See more
Judy Buising
1 week ago
Felix was polite and professional in his manner.  I was given information on my options regarding ne...w glasses.   He was able to send a new referral to my Eye Surgeon.
See more
Tom TJ Murray
2 weeks ago
Very helpful, friendly &amp; professional.
Jacob Van De Water
2 weeks ago
Very efficient and friendly service
Nina S
2 weeks ago
Sophie, Nicole and Kaipin created such a warm and welcoming customer service experience, from eye te...st to getting help selecting a pair of glasses. Felt so seamless! I will be back.
See more
Hazel Marshall
4 weeks ago
Such a thorough exam, I felt totally at ease. The optometrist took care to explain every aspect of t...he test. Best experience ever. I will be booking my husband in for his test/ glasses.
Thank you so much.
See more
Tarzara Kelly
1 month ago
Amazing the staff were realty great and helpful!!
Dechen Wangmo
1 month ago
Chowdhury Faria Haque Richi 1831841630
1 month ago
Dorene Cox
1 month ago
Professional service
Chrissie Austin
1 month ago
Wonderful staff, extremely helpful and have great advise
Nicole Pavlos
1 month ago
From my eye test to picking out my frames, the staff at Oscar Wylee Carousel are extremely helpful, ...friendly and professional! I have visited other Oscar Wylee locations, but this store is now my go to.
See more
Perth Ghostrider
1 month ago
Very friendly &amp; professional team.
No bs or hard sell on items I didn’t need.
Will definitely use ag...ain in the future. Thanks guys, keep doing what you’re doing &lt;3
See more
Park Hansol
1 month ago
I had a fantastic experience here. I previously had issues with the focus of my glasses from another... place, but the team here fixed it perfectly. Kaipin provided an incredibly professional and thorough eye exam, and she was so kind throughout the process. I’m enjoying my vision so much now—everything is so clear, and it feels great. I will definitely return to Kaipin for my future glasses!
See more
Raman Bhangu
2 months ago
It was a good experience at Cannington Oscar Wylee
Ian Munro
2 months ago
I found the staff at Oscar-Wylee very friendly and professional.
Jasmine V
2 months ago
The young Optician lady was very helpful and informative. The staff are also super helpful with pick...ing out frames
See more
henry nwosa
2 months ago
Detailed and professional
Echa Wijaya
2 months ago
Ellenie angel Paradeza
2 months ago
They Guide you all through out the test and by picking what frame glasses suites on you as well as w...hats the best pick for your vision
See more
Vanessa Baker
2 months ago
Vivienne Michal
3 months ago
Thankyou for helping my daughter and three glasses absolute bargains and great service and she feels... super stylish
See more
Haiderali Jamshed
3 months ago
Yasmine Tabbalo
3 months ago
Sanju Thakur
3 months ago
Excellent service
Khandu Omo
3 months ago
Serene Tan
3 months ago
Very detailed with checks
Jorden Worthington
3 months ago
Such a good optometrist!
The Optometrist Ms Kaipin is so lovely and explained everything that was g...oing on with my eyes and prescription.
The ladies at the desk were also so lovely and helpful with picking new frames. Highly recommend
See more
Samnn Kumar
3 months ago
The Service was superb , I haven’t seen this type of Service of optics , love to visit again and aga...in.
See more
Alan Samayoa
3 months ago
Great service ????????
Belinda Stocker
4 months ago
Everything was thoroughly explained.
Front of house /manager was brilliant.   Taking her time to hel...p choose my frames and their suitability for the purposes I  was wanting them for.  Service so far was second to none.  Thankyou, I look forward to collecting my new glasses.
See more
Natalie Chong
4 months ago
Such amazing customer service. I’ve been with them for a few years, and when I recently broke my gla...sses, I brought them into the store. The manager was incredibly kind and offered to replace them with a brand-new pair for free.
See more
Panrada Taylor
4 months ago
Great experience at this optometrist clinic. The staff were friendly and welcoming, and the optometr...ist was thorough, professional, and took the time to explain everything clearly. The clinic was clean and well-organised, with a good selection of frames. I felt well looked after and would highly recommend their services.
See more
Dee Auburn
4 months ago
Not only great value for money on frames. The staff are enthusiastic and friendly.
Nurhidayah Refulus (Sage)
4 months ago
Will definitely be my go to place to get my glasses from now on! Staff was very helpful and friendly... ???? Can't wait for my glasses to arrive!!
See more
Ryannn
4 months ago
Nickson Tarno
5 months ago
Amazing experience, really friendly staff and very helpful
Ivan Nge
5 months ago
Great experience at Oscar Wylee! Bernadette and Nicole were both incredibly friendly and helpful. Th...ey took the time to recommend frames that suited me well and were honest about what looked good rather than just trying to make a sale. I really appreciated their advice and service. I’m very happy with the frames I chose and will definitely come back for my next pair. Thanks again!
See more
Mark Reynald Digal
5 months ago
Overall service and check up went easy and worthwhile!
Arif Rahman
5 months ago
Great service!
Christine Marie Opeña
5 months ago
The whole experience was great! Approachable staff and thorough eye examination. Eyewear selection w...as cool too. Would definitely recommend to friends.
See more
Robert Coll
5 months ago
Great optometrist and very friendly professional service. First time, absolutely recommend!
christine tsakaris
5 months ago
Excellent very thorough explained everything ???? ????
Tony Lau
6 months ago
Mikkel Fernandez
6 months ago
Friendly staff and very informative/helpful :)
## Find an Optometrist in Carousel With Oscar Wylee
You can find our Oscar Wylee Cannington store on the ground floor of the Westfield Carousel Shopping Centre. The centre is located in one of the busiest areas of Perth, with several large universities and Perth airport nearby. This means public transport is readily available to help you make your appointment with us. You can take the train to Cannington Station with a short bus ride to the centre. You could also use Westfield's 2-hour free car parking. 
Once you are here, our Oscar Wylee optometrists can provide Medicare bulk billed eye tests and our store team members can help you shop our range of fashionable glasses at affordable prices- all on the same day! If you have time after your appointment, you can also explore the many retail, dining and entertainment options that Westfield Carousel has to offer. If you live close to the Ferndale or Queens Park areas, come in and see us at Oscar Wylee Westfield Carousel for your eye care needs.        
Meet Our Team
* Optometrist
* Retail Partner
Our Services
* Bulk Billed Eye Examinations
* Professional Frame Styling
* Frame Adjustments and Repairs
* Visual Fields Testing
* Digital Retinal Scanning
Show All
## Find an Optometrist in Carousel, Perth for an Eye Health Test
Find an Oscar Wylee optometrist in Westfield Carousel, Perth for all your eye care needs including an eye health test. Westfield Carousel is located in the suburb of Cannington, Victoria, where our optometrists are equipped to provide our customers with eye health tests to test vision and assist in the diagnosing and management of eye diseases such as age-related macular degeneration. Our Oscar Wylee optometrists can also provide eye care advice and prescription updates and refer patients to an eye doctor, known in Australia as an ophthalmologist, for specialised care if needed. In Cannington, Perth, the average cost for an optometrist often depends on factors such as a person's age, health and eye care needs. At Oscar Wylee, our eye tests are conducted at a bulk billed price under Australia’s Medicare system.
At Oscar Wylee, our team is passionate about ensuring our customers find eyewear that is right for their vision and lifestyle needs. Visit our Oscar Wylee glasses shop in Westfield Carousel and our dedicated retail team, including our optical dispensers, are available to help customers shop our stylish range of prescription glasses, prescription sunglasses and non-prescription glasses. If you require high-quality eye care services such as new frames or eye health tests in Carousel, Perth, come and visit our Oscar Wylee team.
## How to Find an Optometrist in Carousel, Perth?
To find an optometrist in Carousel, Perth you can take certain steps that can help make it easier for you such as searching online, assessing the store’s opening hours and finding the directions to your chosen location. The steps on how to find an optometrist in Carousel, Perth are listed below.
1. Search online using the phrase, optometrist near me in Carousel. This can also be done here on the website via our locations page.
2. Click on the Oscar Wylee link, which will take you directly to our Carousel optometrist store page.
3. See the store’s opening hours and where the store is located specifically.
4. Use the Carousel Google Business page link located under store hours to see the directions on how to get to the store.
You can also find an optometrist in Carousel, Perth by searching the keywords optometrist near me. If you have locations enabled on your smartphone and you’re in the Carousel, Perth area, our Carousel store page should appear easily for you to click on.
### Is it Hard to Get an Eye Appointment in Carousel, Perth?
No, it is not hard to get an eye appointment in Carousel. You can easily book an appointment to see an Oscar Wylee optometrist in Carousel, Perth right here on this page. At Oscar Wylee we have highly qualified optometrists available for bulk billed eye appointments, which can be booked online or in-store.
#### How to Compare Optometrists in Carousel, Perth to Each Other?
To compare optometrists in Carousel, Perth, you can use factors such as eye tests offered, health fund coverage, lens types and add-ons and eyewear offered. To take care of your vision and eye health, it is important to receive an eye test at least once every two years. There are different types of tests that can be performed in an eye test and not all optometrists may offer the same tests. Health funds can be used to help cover some of the cost of your frames and lenses. To find out if your health fund is accepted at an optometrist in Carousel, Perth visit their website. In the case of Oscar Wylee, we accept all major health funds and provide on-the-spot claims in-store. There are many different lens options available for prescription glasses such as single-vision, multifocal and high-index lenses. Most optometrists in Carousel, Perth will offer these lenses although it is good to make sure. There are also lens add-ons available to enhance your glasses such as anti-reflective and blue light filters. Finally, if you are looking to purchase a pair of glasses after your eye test, you can compare the different styles and colours you are interested in from the optometrists in Carousel, Perth. Oscar Wylee offers a wide range of frames with vintage and modern inspirations in bold colours and subtle designs.
#### How to Find an Eyeglasses Shop in Carousel, Perth?
To find a glasses store in Carousel, Perth you can try to follow these simple steps including searching online, selecting a convenient location and looking at their health insurance policies. The steps on how to find a glasses store in Carousel, Perth are listed below.
1. Search online using the phrase, glasses store in Carousel, Perth. This will provide you with various options for glasses stores in the whole Carousel, Perth area.
2. Select a glasses store that is most convenient for you to travel to.
3. Click the link to find out more information such as opening hours, exact location and directions to the glasses store in Carousel.
4. Read their health insurance policies to ensure you know what health benefits you have access to.
Our Oscar Wylee glasses store in Carousel, Perth offers primary eye care services such as comprehensive eye tests as well as other services performed by an optometrist and offers prescription and non-prescription eyewear.
##### Is it Possible to Purchase Prescribed Sunglasses in Carousel, Perth Without Seeing an Optometrist?
Yes and no, it is possible to [purchase prescribed sunglasses](https://www.oscarwylee.com.au/sunglasses.html) in Carousel, Perth without seeing an optometrist if you already have a prescription that has not expired. If your prescription is expired, you can book an eye test to receive an updated or new prescription which will require you to see an optometrist. This will ensure your prescription sunglasses are appropriate for your visual needs.
## Where is the Oscar Wylee Carousel, Perth Optometrist Located?
The Oscar Wylee Carousel optometrist is located in the Carousel Westfield Shopping Centre, in the suburb of Cannington. The Westfield Carousel Shopping Centre is located at 1382 Albany Highway, Cannington, Perth.
### What is the Phone Number of Oscar Wylee Carousel, Perth Optometrist Store?
The phone number for our Oscar Wylee Carousel, Perth optometrist store is (08) 6249 4721. Our Oscar Wylee Carousel, Perth store is open, and our staff are available to be contacted between 9 am and 5.30 pm from Monday to Wednesday, 9 am to 8 pm on Thursdays, 9 am to 5.30 pm on Fridays, 9 am to 5 pm on Saturdays and 11 am to 5 pm on Sundays.
### What are the Reviews for Oscar Wylee Carousel, Perth Optometrist?
The customer reviews for our Oscar Wylee Carousel, Perth optometrist, can be found here on the website and online when you search for Oscar Wylee Carousel optometrist. The reviews for our Oscar Wylee Carousel optometrist are listed below.
* Kim Baker:  Oscar Wylee has such an amazing range of frames, there is a style to suit everyone. The optometrist was very professional and helpful. He explained everything to me in detail and was extremely helpful. Very friendly staff too. I wouldn't go anywhere else.
* Zoe Cross:  Excellent knowledge, took extra time with the concerns that I had with my eyes, not too much trouble and took the time to make the children feel comfortable. Highly recommend!
* Suzanne Dowsett:  Excellent service from all of the friendly staff. Great choice of frames and very quick delivery time.
#### What Treatments or Eye Care Processes Are Done in the Oscar Wylee Carousel, Perth Optometrist Location?
The treatments or eye care processes done in the Oscar Wylee Carousel, Perth optometrist location include a tonometry test, a digital photograph, a slit lamp exam and a refraction test. Additional tests that may also be performed can include a visual field test and a dilated fundus exam. The treatments or eye-care processes that are done in the Oscar Wylee Carousel optometrist location are listed below.
* A Tonometry Test: An optometrist or optical dispenser will conduct a tonometry test which involves the use of a machine that will release small puffs of air into your eyes. This will assist with measuring pressure in the eye.
* A Digital Photograph: An optometrist or optical dispenser may take a digital photograph of your eye which can be kept on record to use in future appointments to evaluate any changes to your eye.
* Slit Lamp Test: A slit lamp test can be used to evaluate your eye health, by examining your cornea and iris which are the anterior and posterior of the eye.
* Refraction Test: During a refraction test, an optometrist will have you view an image through different lenses and ask you to confirm which helps you see the image clearer.
* Visual Field Test: A visual field test can assist with assessing your peripheral vision, which may be beneficial for identifying any signs of glaucoma.
* Dilated Fundus Exam: A dilated fundus exam can help an optometrist assess your health in more detail by getting a clear view of the retina. This test is typically carried out for patients with diabetes and those who may be at risk of developing retinal damage.
## How Many Optometrists Exist in Carousel, Perth?
Many optometrists exist in Cannington, Perth and in the Westfield Carousel shopping centre, including Oscar Wylee. The amount of optometrists available in an area will typically depend on the population and the eye care needs of those in the area. At Oscar Wylee Carousel, Perth, our team is passionate about providing our customers with high-quality, dedicated eye care services. Our optometrists are available to provide bulk billed eye tests with our dedicated optometrists, prescription updates and new frames. If you are looking for an optometrist in Carousel, Perth, Oscar Wylee is available to provide all your eye care and eyewear needs.
### What are the Other Closest Optometrist Locations to Carousel, Perth in Australia?
The closest Oscar Wylee Optometrist locations to Carousel, Perth are Booragoon, Fremantle, and Morley Galleria. The closest Oscar Wylee optometrist locations to Carousel, Perth are listed below.
* Booragoon:  Booragoon is a suburb approximately 14 km from Westfield Carousel where you can find an Oscar Wylee optometrist for Medicare bulk billed eye tests. [Oscar Wylee Booragoon](https://www.oscarwylee.com.au/locations/optometrist-booragoon.html) is located in the Booragoon Westfield Shopping Centre on Riseley Street.
* Fremantle:  Fremantle is a suburb located approximately 21 km away from Westfield Carousel, where you can find an Oscar Wylee optometrist. [Oscar Wylee Fremantle](https://www.oscarwylee.com.au/locations/optometrist-fremantle.html) is located in the Manning Buildings, where our optometrists can perform bulk billed eye tests for eligible Medicare cardholders.
* Morley Galleria:  Morley Galleria is a shopping centre approximately 19 km from Westfield Carousel, Cannington, where our Oscar Wylee optometrists and retail staff are available for your eye care needs. Come and visit the team at [Oscar Wylee Morley Galleria](https://www.oscarwylee.com.au/locations/optometrist-morley-galleria.html) for eye tests, prescription updates and new frames.
### Optometrist Eye Tests at Oscar Wylee Westfield Carousel
Our Oscar Wylee eyeglasses shop in Carousel Westfield offers Medicare bulk billed eye health tests with our in-store optometrists. Our Oscar Wylee optometrists are dedicated to providing our customers with high-quality eye care processes, including vision testing and eye examinations for possible eye diseases. With same-day prescriptions and efficient service from our retail team, you’ll be able to pick out and order a new pair of prescription frames after your appointment. For some of the best optometrists in Cannington, Australia, come and visit Oscar Wylee Westfield Carousel today!
### Oscar Wylee Westfield Carousel Accepts Leading Health Funds
Visit our Oscar Wylee Cannington store in Westfield Carousel for eye care services such as new prescription glasses, and your health fund may help cover some of the cost. Bring your valid health fund card and our team will help process your claim, as well as answer questions about your eligibility at Oscar Wylee.
### Stylish Frames at Oscar Wylee Carousel
Oscar Wylee Carousel has a range of stylish and affordable frames on offer including prescription glasses, prescription sunglasses and non-prescription glasses. At Oscar Wylee, our frames take design inspiration from a range of modern trends, as well as older, more vintage stylings. With frames in a variety of colours, shapes and sizes, Oscar Wylee has a pair of glasses to suit anyone’s personal style, as well as face shape and vision needs!
Book Appointment
[Call us: (08) 6249 4721](tel:(08) 6249 4721)
[Leave a Review!](https://g.page/r/CQj7ufocNLvSEAg/review)