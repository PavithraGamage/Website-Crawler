# Source: https://www.oscarwylee.com.au/locations/optometrist-bondi-junction.html

# Optometrist Bondi Junction
Oscar Wylee Bondi Junction is moving!Need to book in for
an eye test?No problem. Our nearest stores will gladly see
you!
[The Galeries, Sydney CBD](https://www.oscarwylee.com.au/locations/optometrist-sydney-galeries.html)
[Broadway Shopping Centre](https://www.oscarwylee.com.au/locations/optometrist-broadway.html)
[Westfield Eastgradens](https://www.oscarwylee.com.au/locations/optometrist-eastgardens.html)
[Newtown](https://www.oscarwylee.com.au/locations/optometrist-newtown.html/)
Westfield Bondi Junction
Level 3, Shop 3022
500 Oxford
Street
Bondi Junction NSW 2022
Opposite McDonalds
Opening hours
Monday9:30am - 6:00pm
Tuesday9:30am - 6:00pm
Wednesday9:30am - 6:00pm
Thursday9:30am - 9:00pm
Friday9:30am - 6:00pm
Saturday9:30am - 6:00pm
Sunday10:00am - 6:00pm
*Store hours reflect local standard trading hours and exclude public
holidays

[Visit our Bondi Junction Google Business page for directions,
reviews, and updates.](https://g.page/r/CZv8RY8mgKFSEAE)


Book Appointment
[Call us: 1300 164 990](tel:1300 164 990)
Our Reviews
Ana Acevedo
1 year ago
Eloise Honeyman
1 year ago
Dr Wan Ling Goh is a very kind and knowledgeable optometrist. I would recommend her for any eye conc...erns.
See more
Ngaire Booth
1 year ago
It was my first visit to Oscar Wylee. Overall the experience was excellent. Great customer service f...rom the team in the shop, and the optometrist was extremely thorough which engenders a real confidence. I'm thrilled with my two new pairs of fabulous glasses.
See more
Neve Storey
1 year ago
Lovely people
So friendly so happy to help
Charlie Pigrome
1 year ago
Laura
1 year ago
The optometrist was very thorough and helpful.
Ad Stack
1 year ago
Problem with booking as online portal only permits eye test not one that includes diabetes test/long...er test. This meant having to cancel first appointment after visiting shop and reattaching for 2nd time. Once booked in service professional
See more
Tech Sydney
1 year ago
Rose Kennedy
1 year ago
My experience with( oscar wylee.) store the stuff was very friendly .helpful .and quite understandin...g the optometrist gave me a lot of information  about my eye site what I needed to know and shared it  with my eye doctor .a referral  was also given . I was so grateful it was easy to find the store location .and they had a verity  of selection on glasses  that would suit you .I  am happy  I've chosen oscar wylee.as my optometrist.
Reg R.k.
See more
ash
1 year ago
Chris Hill
1 year ago
The eye testing and frame selection were thorough, efficient and enjoyable.  The staff were very ple...asant and the whole experience was good. I look forward to getting my new glasses soon.
See more
jgd
2 years ago
friendly, fast, and informative!
Stephen Oliver
2 years ago
Really efficient and friendly service. Recommended!
Michelle Markuse
2 years ago
I received great service here and was very pleased with my glasses. I casually popped in on a Sunday... and saw a frame that I liked. My partner popped in with me and she ended up buying a pair of glasses as well. She has a small face and they offer a great range of glasses called petite that really suited her. The staff were very friendly and helpful and even gave each of us a mini eye check to see that the lenses were suitable for our new glasses, considering we were investing, in a new pair. They were very knowledgeable quick and efficient. I ended up getting three pairs of progressive glasses for a great price. They have such a great range of groovy frames. It was very hard to choose. They swiped my private health cover card on the spot and I got $200 off. I will be back ????
See more
Sophie Dalgleish
2 years ago
Very knowledgeable optician ,helpful and informative staff .Great experience
Meaghan Legaspi
2 years ago
Linda Dean
2 years ago
Always great service at Bondi Junction. Very happy with my eye test they are very thorough and helpf...ul advice. Thank you ☺️
See more
Emma
2 years ago
Such a wonderful experience at Bondi Junction!
For the past 3 years I just used specsavers for eye t...ests and new glasses but decided to mix it up.
The optometrist was great, very caring and attentive. She then had Holly help me pick out frames and sunglasses.
To say Holly was exception at her job would be an understatement. It felt like I had my best girlfriend with me trying on glasses. She was honest when they didn’t suit, and always had an explanation as to why, backing it with her extensive knowledge. I walked out feeling confident and excited by my choices. Having her help me and providing a second unbiased opinion was gold. Thank you Holly, you are a gem.
See more
Tiana Dupesov
2 years ago
Thomas Gottlieb
2 years ago
Friendly, personalised and highly professional service. It is a delight to come to Oscar Wylee as th...e service is outstanding
See more
Hobie Spice
2 years ago
Best optometrist experience. From the warm and sincere greeting, and the careful advice and informat...ive eye test with the absolutely charming optometrist, it was a seamless experience from start to finish. Everyone was super professional and knew their stuff and were only to happy to help.
See more
Jebelle Gaha
2 years ago
The staff and optometrist here far exceeded my expectations. I went in just to ask if a pair of sung...lasses I had could be fixed and the staff went above and beyond to help.
I ended up leaving with a new pair of sunglasses that I was able to claim through my health insurance, thanks to the great advice and assistance of the sales staff and on-site optometrist. It hadn’t even occurred to me that using my private cover for sunglasses could be an option and I was very grateful for their advice and assistance.
The on-site optometrist (sadly I don’t recall her name) was excellent. She explained everything in detail and was so kind and friendly. She has a wonderful manner.
Thanks team, my experience was 10/10.
See more
Anastasia
2 years ago
Very nice experience!
Tony Sernack
2 years ago
Montserrat Mayorga
2 years ago
Jennifer Lyster
2 years ago
Appt online was easy and reminder messages were received. Shop staff friendly and helpful. Optometri...st was knowledgeable and professional and kind. Happy to recommend this service.
See more
matthew keane
2 years ago
A really nice feeling in this store ! Went in for my first eye test and the optometrist was one of t...he nicest people I’ve come across ! Helpful friendly and genuine ????
See more
Bianca Tini Brunozzi
2 years ago
Luke
2 years ago
Terrific service adjusting the frames until they were absolutely perfect. Thanks.
Christopher Robin
2 years ago
The online booking process was easy and the team that worked at Bondi Junction were super friendly a...nd helpful. It was actually a fun experience and I'm comfortable with the choices I made.
See more
Jonathan Tidball
2 years ago
Always a helpful team when I get my eyes checked every year!  Informative consultation explaining wh...at each test is for . Always a great selection of frames if I do need new glasses!
See more
Shaz Af
2 years ago
My first ever best experience at Oscar Wylee. The guy Subham is so amazing, he was so helpful. A 5 s...tar for him
See more
Stuart Muirhead
2 years ago
Excellent service for both the Optometry and glasses sales.
Candelaria Toro
2 years ago
Margaret McHatton
2 years ago
Extremely professional, best I have ever had
Martin Orrock
2 years ago
very professional and helpful
Andy Roberts
2 years ago
Experience was great. Professional and fun. On time and didn’t take very long.
Wendi Pontey
2 years ago
Exceptional service. Friendly efficient and professional . Would highly recommend and am looking for...ward to my new glasses
See more
Christine Arrevado
2 years ago
Suzanne Clarke
2 years ago
Great friendly service
Ben Bain
2 years ago
Fast and wonderful service. Highly recommend
R GB
2 years ago
On the hunt for some new ‘facial architecture’ (glasses) and can’t decide which pair suits your skin... and eye  colour, and that frames your face and overall balance?  Go see Holly and Bernie - the difference between loving and liking the right pair for you.  Best I’ve experienced in many many years
See more
Matthew Arrowsmith
2 years ago
I was impressed by the end-to-end eye test process.  Managed to secure a booking within the hour and... chose frames while I waited.  The person who tested my eyes was efficient, communicative and made the whole process interesting and fun!  Looking forward to receiving my glasses!
See more
Liz Mitchell
2 years ago
fantastic service and wide selection of different fitting fun glasses
Claire Richards
2 years ago
Great experience. Quick but still felt thorough, from front desk to optometrist. Felt in good hands ...and optometrist was happy to discuss any questions I had.
See more
Andy Dobosz
2 years ago
Nancy Zhu
2 years ago
I’m extremely satisfied with Mirna who has gone above and beyond of normal eye test. I would recomme...nd Mirna’s services to anyone.
See more
leeorah hursky
2 years ago
Excellent service
Tim T
2 years ago
Had the chance to get my Oscar wylee prescription glasses strength re calibrated, both the optometri...st and Shabu have been amazing help and given
good customer services!
See more
Julian Zamora
2 years ago
## Find an Optometrist in Bondi Junction With Oscar Wylee
Only a stone’s throw from Bondi Junction station, you can book
online or visit our Oscar Wylee store on the 3rd floor of Westfield Bondi
Junction for your annual eye check-up. Close to areas like Waverley and
Woollahra, Oscar Wylee Bondi Junction offers prescription glasses and
sunglasses inspired by vintage styles, as well as Medicare bulk billed
comprehensive eye tests in-store. So you can update your prescription and shop
for your new glasses on the same day! For those who live in the Bondi area,
Oscar Wylee optometrists near you also include Oscar Wylee at The Galeries.
If you’ve got time before your eye test appointment, why
not explore the many stores inside Westfield Bondi Junction? When you’re done
shopping, it’s only a 30-minute walk to the iconic Bondi Beach. You can also
explore the cliff-top coastal walk from Coogee to Bondi which has stunning
views of the ocean, rock pools and beaches, but don’t forget to bring your
sunnies!         
Our Services
* Bulk Billed Eye Examinations
* Professional Frame
Styling
* Frame adjustments and Repairs
* Visual Fields Testing
* Digital Retinal
Scanning
* Staff with over 10 years of optics experience
Show All
## Find an Optometrist in Bondi, Sydney for an Eye Health Test
You can see an optometrist in Bondi for essential services for
all things eye care. If you’re in need of prescription
sunglasses or non-prescription sunglasses, the Oscar Wylee
Bondi, Sydney glasses store is the place for you. Eye diseases
can be detected through an eye health test in Bondi, Sydney,
which you can have access to for a bulk billed price through
Australia’s Medicare system. So be sure to bring your eligible
Medicare card to your next appointment with us. Like at all our
store locations, we do not have an eye doctor but our
highly-trained optometrists and optical dispensers will help you
with your optometry needs.
The price for an optometrist in Bondi, Sydney may differ from
other optometrists in Bondi due to factors such as the facility
they operate in, the type of equipment used and the visual
requirements of patients.
## How to Find an Optometrist in Bondi, Sydney?
To find an optometrist in Bondi, Sydney, you can take certain
steps that can help make it easier for you such as
searching online, assessing the store’s opening hours and
finding the directions to your chosen location.
The steps on how to find an optometrist in Bondi are listed
below.
1. Search online using the phrase, optometrist near me in Bondi.
This can also be done here on the website via our locations
page.
2. Click on the Oscar Wylee link, which will take you directly to
our Bondi optometrist store page.
3. See the store’s opening hours and where the store is located
specifically.
4. Use the Bondi Google Business page link located under store
hours to see the directions on how to get to the store.
You can also find an optometrist in Bondi by searching the
keywords optometrist near me. If you have locations enabled on
your smartphone and you’re in the Bondi area, our Bondi store
page should appear easily for you to click on.
### Is it Hard to Get an Eye Appointment in Bondi, Sydney?
No, it is not hard to get an eye appointment in Bondi. You can
easily book an appointment to see an Oscar Wylee optometrist in
Bondi right here on this page. At Oscar Wylee we have highly
qualified optometrists available for bulk billed eye
appointments, which can be booked online or in-store.
#### How to Compare Optometrists in Bondi to Each Other?
To compare optometrists in Bondi, you can use factors such as
eye
tests offered, health fund coverage, lens types and add-ons
and eyewear offered.
To take care of your vision and eye health, it is important to
receive an eye test at least once every two years. There are
different types of tests that can be performed in an eye test
and not all optometrists may offer the same tests. Health funds
can be used to help cover some of the cost of your frames and
lenses. To find out if your health fund is accepted at Bondi
optometrist in Sydney, visit their website. In the case of Oscar
Wylee, we accept all major health funds and provide on-the-spot
claims in-store. There are many different lens options available
for prescription glasses such as single vision, multifocal and
high index lenses. Most optometrists in Bondi will offer these
lenses although it is good to make sure. There are also lens
add-ons available to enhance your glasses such as
anti-reflective and blue light filters. Finally, if you are
looking to purchase a pair of glasses after your eye test, you
can compare the different styles and colours you are interested
in from Bondi optometrists in Sydney. Oscar Wylee offers a wide
range of frames with vintage and modern inspirations in bold
colours and subtle designs.
#### How to Find an Eyeglasses Shop in Bondi, Sydney?
To find a glasses store in Bondi, you can try to follow these
simple steps including
searching online, selecting a convenient location and looking
at their health insurance policies.
The steps on how to find a glasses store in Bondi, Sydney are
listed below.
1. Search online using the phrase, glasses store in Bondi. This
will provide you with various options for glasses stores in
the whole Bondi, Sydney area.
2. Select a glasses store that is most convenient for you to
travel to.
3. Click the link to find out more information such as opening
hours, exact location and directions to the glasses store in
Bondi.
4. Read their health insurance policies to ensure you know what
health benefits you have access to.
Our Oscar Wylee glasses store in Bondi, Sydney offers primary
eye care services such as comprehensive eye tests as well as
other services performed by an optometrist and offers
prescription and non-prescription eyewear.
##### Is it Possible to Purchase Prescribed Sunglasses in Bondi, Sydney
Without Seeing an Optometrist?
Yes and no, it is possible to
[purchase prescribed sunglasses](https://www.oscarwylee.com.au/sunglasses.html)
in Bondi, Sydney without seeing an optometrist if you already
have a prescription that has not expired. If your prescription
is expired, you can book an eye test to receive an updated or
new prescription which will require you to see an optometrist.
This will ensure your prescription sunglasses are appropriate
for your visual needs.
## Where is the Oscar Wylee Bondi Optometrist in Sydney Located?
The Oscar Wylee Bondi optometrist in Sydney is located at Bondi
Junction Westfield, on level 3, opposite McDonalds. Bondi
Junction Westfield can be found at 500 Oxford Street and is only
6 km from the Sydney CBD.
### What is the Phone Number of Oscar Wylee Bondi Optometrist Store?
The phone number of Oscar Wylee Bondi optometrist store is (02)
8283 2800. You can contact the Oscar Wylee Bondi store between
the hours of 9:30 am and 6 pm on Monday, Tuesday, Wednesday,
Friday and Saturday. On Thursday between 9:30 am and 9 pm and on
Sunday between 10am and 6 pm.
### What are the Reviews for Oscar Wylee Bondi Optometrist in Sydney?
We encourage our customers to leave reviews about their in-store
experiences which can be found here on our website or online.
The reviews for Oscar Wylee Bondi, Sydney are listed below.
* Sophie Turnbull:  Excellent service from all the staff
at OW Bondi Junction, especially the optometrist Wan Ling. She
was so patient and kind, answered all my questions
knowledgeably and thoroughly, and was able to put my fears to
rest over worries I had regarding my script. Very capable team
all around! Thank you very much.
* Birendra Basnet:  Bondi branch was the best friendly
environment that I experienced when I got my eyes checked.
Staff are friendly and attentive as well as respectful. Had a
great and lovely service from the Bondi branch.
* Emma Valette:  Such a lovely experience coming to this
shop! Jack was so helpful with finding the perfect frames for
my face and my style! Thanks again.
* Jenny Miles:  Jack &amp; Tristy ( Bondi Westfield) were
so helpful, polite and a fun experience choosing specs with
them.
#### What Treatments or Eye Care Processes are Done in the Oscar Wylee
Bondi, Sydney Optometrist Location?
The treatments or eye care processes done in the Oscar Wylee
Bondi optometrist location Sydney include
a tonometry test, a digital photograph, a slit lamp exam and
a refraction test.
Additional tests that may also be performed can include
a visual field test and a dilated fundus exam. The
treatments or eye-care processes that are done in the Oscar
Wylee Bondi optometrist Sydney location are listed below.
* A Tonometry Test: An optometrist or optical dispenser
will conduct a tonometry test which involves the use of a
machine that will release small puffs of air into your eyes.
This will assist with measuring pressure in the eye.
* A Digital Photograph: An optometrist or optical
dispenser may take a digital photograph of your eye which can
be kept on record to use in future appointments to evaluate
any changes to your eye.
* Slit Lamp Test: A slit lamp test can be used to
evaluate your eye health, by examining your cornea and iris
which are the anterior and posterior of the eye.
* Refraction Test: During a refraction test, an
optometrist will have you view an image through different
lenses and ask you to confirm which helps you see the image
clearer.
* Visual Field Test: A visual field test can assist with
assessing your peripheral vision, which may be beneficial for
identifying any signs of glaucoma.
* Dilated Fundus Exam: A dilated fundus exam can help an
optometrist assess your health in more detail by getting a
clear view of the retina. This test is typically carried out
for patients with diabetes and those who may be at risk of
developing retinal damage.
## How Many Optometrists Exist in Bondi, Sydney?
There are numerous optometrists that exist in Bondi which
include Oscar Wylee. The amount of optometrists available in an
area will typically depend on the population.
### What are the Closest Other Optometrist Locations to Bondi, Sydney
in Australia?
The other closest Oscar Wylee optometrist location to Bondi is
The Galeries, Broadway, Newtown and Eastgardens. The
locations and their distance from Bondi are listed below.
* The Galeries: The Galeries is close to Bondi with a 5
km distance between stores. The
[Oscar Wylee in The Galeries](https://www.oscarwylee.com.au/locations/optometrist-sydney-galeries.html)
can be found along Pitt Street, opposite ANZ Tower. Here you
can receive high-standard eye tests at a bulk billed price
along with excellent service from our team.
* Broadway:  Broadway is close to Bondi with 6-8 km
between stores. The
[Oscar Wylee Broadway](https://www.oscarwylee.com.au/locations/optometrist-broadway.html)store offers essential optometry services, whether it is for
a prescription update or for general enquiries about eyecare,
the Oscar Wylee Bondi team is happy to help. You can find the
Broadway store on the ground floor of the Broadway Shopping
Centre in Ultimo.
* Newtown: Newtown is close to Bondi, around 7 km in
distance. The
[Oscar Wylee Newtown](https://www.oscarwylee.com.au/locations/optometrist-newtown.html)
store can be found along King Street near Big Daddy’s Burger
Bar. The team at Newtown are trained and committed to
providing you with quality service and care.
* Eastgardens: Eastgardens is close to Bondi with 7-8 km
in between stores and is located at Westfield Eastgardens on
level 2, next to Specsavers. The
[Oscar Wylee Eastgardens](https://www.oscarwylee.com.au/locations/optometrist-eastgardens.html)
store is the optometrist for you if you’re in search of your
next pair of stylish frames.
### Eye Tests with Oscar Wylee’s Bondi Junction Optometrists
Visit Oscar Wylee’s eyeglasses shop in Bondi Junction for Medicare
bulk billed eye health tests. Oscar Wylee’s optometrists at Bondi
Junction Westfield are dedicated to providing customers with
high-quality eye care. Equipped with modern optometry equipment, our
optometrists will carry out eye care processes including vision
assessment and diagnosing possible eye diseases. For some of the best
optometrist services in Bondi, Australia, visit Oscar Wylee Bondi
Junction.
### Using Your Health Fund at Oscar Wylee
At Oscar Wylee Bondi Junction, our team will help you navigate the ins
and outs of making a health fund claim for glasses or eye tests. Oscar
Wylee can process your health fund claim in-store with a valid health
fund card. At Oscar Wylee Bondi Junction, our team of retail staff and
optometrists are dedicated to ensuring that you get the best
prescription glasses and sunglasses you need at affordable prices.
### Frames for Everyone at Oscar Wylee Bondi Junction
Oscar Wylee Bondi Junction offers a range of affordable and stylish
eyewear including prescription glasses and prescription sunglasses as
well as non-prescription glasses. Come into Oscar Wylee Bondi Junction
today to chat with one of our experts and find the perfect frames for
your face shape or size. Oscar Wylee has frames in a range of sizes,
from oversized to petite, and shapes, from cat-eye to square and
round. Oscar Wylee’s eyewear collection caters for all face shapes and
sizes!
Book Appointment
[Call us: 1300 164 990](tel:1300 164 990)