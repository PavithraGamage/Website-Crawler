# Source: https://www.oscarwylee.com.au/health-funds/navy-health.html

# Navy Health at Oscar Wylee
As a member of Navy Health, you can claim on optical extras using your health fund’s coverage for optical services, such as prescription frames, lenses or glasses. You’ll have up to two years to submit service claims and your product benefits will reset every financial year. With Oscar Wylee, you can have up to 100% coverage on select optical purchases when you shop with us. Look at the table below to see your Navy Health policy’s name and the amount of coverage that policy gives when you shop at Oscar Wylee.Your coverage might change or not apply to extras such as add-ons, coatings or tinting.
## Take care of your eyes today
Oscar Wylee offers no-gap bulk billed eye exams. Book yours today!
[Get your eyes tested](https://www.oscarwylee.com.au/booking)
#### Waiting Period
6 Months
#### Benefit Limits Reset
1st of July
#### Claimable Benefits %
100% for Budget Extras, Healthy Living Extras and Premium Extras, 65% for Saver Bronze + Hospital &amp; Extras 65
To learn whether your plan includes single-vision lenses, bifocal lenses and/or multifocal lenses, talk to your health insurance provider.
| Your Extras Package Annual Limit:* | Budget Extras | Healthy Living Extras | Premium Extras | Saver Bronze + Hospital &amp; Extras 65 | SINGLES COVER | 1 Standard OW Pair from $169^ | 2 Standard OW Pairs from $199^ | 3 Standard OW Pairs from $249^ |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| $170 | $260 | $350 | $200 |
| Covered | Covered | Covered | Partial Cover |
| Partial Cover | Covered | Covered | Partial Cover |
| Partial Cover | Covered | Covered | Partial Cover |
^Excludes add-ons. Standard frames and lenses only. Oscar Wylee’s standard product inclusions are calculated based on the optical allowances under each health fund package and may vary. If unsure, please confirm with your provider. Our two pair and three pair deals are only available per person and cannot be split between two people. Only one prescription can be used per offer. If you have a distance and a reading prescription, this is included in the offer as this is considered to be one prescription. Any prescriptions must have the full name of the person claiming and a valid expiry date to be able to order. If you have two different prescribed prescriptions, you will need to visit a store to be eligible for our two pair and three pair deals.
| FAMILY COVER | 1 Standard OW Pair from $169^ | 2 Standard OW Pairs from $199^ | 3 Standard OW Pairs from $249^ |
| --- | --- | --- | --- |
| $170 per person | $260 per person | $350 per person | $200 per person |
| Covered | Covered | Covered | Partial Cover |
| Partial Cover | Covered | Covered | Partial Cover |
| Partial Cover | Covered | Covered | Partial Cover |
^Excludes add-ons. Standard frames and lenses only. Oscar Wylee’s standard product inclusions are calculated based on the optical allowances under each health fund package and may vary. If unsure, please confirm with your provider. Our two pair and three pair deals are only available per person and cannot be split between two people. Only one prescription can be used per offer. If you have a distance and a reading prescription, this is included in the offer as this is considered to be one prescription. Any prescriptions must have the full name of the person claiming and a valid expiry date to be able to order. If you have two different prescribed prescriptions, you will need to visit a store to be eligible for our two pair and three pair deals.
## Due for an eye test?
We recommend that everyone should have an eye test with an optometrist at least once every 2 years.
[Book an an eye test](https://www.oscarwylee.com.au/booking)
*Based on Navy Health’s [Cover Guide](https://navyhealth.com.au/cover/extras-cover/) and product factsheet as presented to the Commonwealth Ombudsman [1](https://navyhealth.com.au/cover/extras-cover/budget-extras-cover/) [2](https://navyhealth.com.au/cover/extras-cover/silver-extras-cover/) [3](https://navyhealth.com.au/cover/extras-cover/premium-extras-cover/) [4](https://navyhealth.com.au/cover/saver-bronze-hospital-bronze-extras/). Navy Health offers many policies in combination with these 3 extras packages. No combo offer changes the amount of coverage each policy provides. Additionally, benefits are not available for additional lens coatings and features such as anti-reflection.Information correct as of November 2024.
## Your eye test explained
Routine eye test appointments are quick and painless. Find out what to expect during an eye exam and how to understand your eye test results.
[Find out more](https://www.oscarwylee.com.au/eye-health/your-eye-test-explained.html)
## Bulk Billing
Find out what bulk billing is and whether you're eligible to receive an eye test free of charge.
[Find out more](https://www.oscarwylee.com.au/eye-health/eye-test-info/bulk-billing.html)
## What is Pupillary Distance? (PD)
Do you know your PD? It's something you'll need to know when ordering glasses online. Find out what Pupillary Distance is and how you can measure your own.
[Read more](https://www.oscarwylee.com.au/eye-care/eye-test/what-is-pupillary-distance.html)
## Book an eye test
Oscar Wylee eye tests are bulk billed through Medicare. This means there will be no out-of-pocket expense for eligible Medicare cardholders.
[Book online](https://www.oscarwylee.com.au/booking/)
## Find a store near you
Contact or visit your nearest store for a full quote.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)