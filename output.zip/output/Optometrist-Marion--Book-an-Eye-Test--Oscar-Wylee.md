# Source: https://www.oscarwylee.com.au/locations/optometrist-marion.html

# Optometrist Marion
Westfield Level 1, Shop 1015297 Diagonal RoadOaklands Park SA 5046
* Near Big W
Opening hours
Monday9:00am - 5:30pm
Tuesday9:00am - 5:30pm
Wednesday9:00am - 5:30pm
Thursday9:00am - 9:00pm
Friday9:00am - 5:30pm
Saturday9:00am - 5:00pm
Sunday9:00am - 5:00pm
*Store hours reflect local standard trading hours and exclude public holidays
[Visit our Marion Google Business page for directions, reviews, and updates.](https://g.page/r/CWK3DowlbGdhEAE)
Book Appointment
[Call us: (08) 8296 3098](tel:(08) 8296 3098)
[Leave a Review!](https://g.page/r/CWK3DowlbGdhEAg/review)
Our Reviews
Angela Walsh
2 days ago
chris foxton
3 days ago
Always good. Friendly helpful staff
Toni Mylonas
3 days ago
Prefer getting my glasses from this company. Excellent service given at each store ive been to and t...he optomotrists are very good.
See more
Ewa Jurasz
1 week ago
Tami Flamank
1 week ago
I seriously rate my experience as 10 out of 10. The staff at the front counter were absolutely amazi...ng. They helped support everything that I spoke about and made me feel completely comfortable and the  optometrist also was 10 out of 10 very caring, kind and understanding and explained everything perfectly. I highly recommend the Marion store Oscar Wiley .
See more
Martin Johnson
1 week ago
Really good went well
Patricia Gardiner
2 weeks ago
I was very happily pleased to be examined by a really pleasant and efficient optician.  I was very s...atisfied with my appointment
See more
heather portway
2 weeks ago
Bev Firgaira
2 weeks ago
The ophthalmologist was so great with my 6 years old. And one of the male staff was so friendly and ...explained to him how not to scratch his glasses when he gets them. Best experience we had.
See more
Amanda Polain
3 weeks ago
All of the staff were fantastic. Super friendly and made it so easy for me to select new glasses. Th...ey went above and beyond to make sure I could get what I wanted. Great service.
See more
Tihui Cervantes
4 weeks ago
My experience at Oscar Wylee Optometrist was unexpectedly outstanding! The staff took the time to un...derstand my needs and I felt in a very friendly environment at all times. Affordable prices and beautiful frames, the staff helped me to sort out my concerns and Theresa the Optometrist is super professional and knowledgeable. As a GP, I highly recommend Oscar Wylee Optometrist for your next eye check!
See more
Colleen Lovegrove
1 month ago
Glasses, sign said one thing you pay another. But still cheaper than other outlets
Farley Briggs
1 month ago
Excellent care and expertise.  Very happy with the service I was given.
Stefania Pianciamore
1 month ago
Very professional. Excellent service
George Rudinsky
1 month ago
Fantastic  business, thanks to John for professionalism.
Elizabeth Petersen
1 month ago
Excellent service and expertise from the optometrist and the staff. A very positive experience
Nguyen Hung Thinh
1 month ago
Simon Best
1 month ago
Believe it was Therese who conducted my eye test and very professional and knowledgeable. I had inte...nded to purchase 2 pairs of glasses while there but disappointed with options for men’s wide  pairs so didn’t purchase any glasses.
See more
Jessica Lam
1 month ago
It was our 1st time attendance at Oscar Wylee Optometrist @ Marion after reading great reviews onlin...e.  Optometrist, Theresa was fantastic with the kids (primary &amp; high school age).  Theresa was very thorough, comforting &amp; made the kids felt at ease &amp; has some great advice for them.
Great customer service from Receptionists &amp; Optometrist, very helpful ????????.  Thankyou!
We highly recommend Oscar Wylee Optometrist @ Marion.  Great team of staff ????.
See more
Megan Gray
1 month ago
Everyone was super friendly and helpful they showed genuine care for myself and my eyes!
Jadranka Stojanac
1 month ago
Wendy
1 month ago
I am a repeat customer at OW Marion - I booked a last minute Saturday morning appointment, arrived e...arly and was seen straight away.
The eye test showed no difference in my prescriptions so I was not required or pushed into buying new frames, but I felt it was time for a refresh so I picked some frames out with 1 on 1 assistance, had them written up, my private health applied and was on my way.
I have always felt I get honest, friendly service in this store, and I really feel the range of frames are affordable, comfortable and always come with compliments, hence this would have been my 4th or 5th visit &amp; purchase.
See more
Di Caught
1 month ago
Great experience - friendly knowledgeable optometrist John and no upselling in the sales experience ...- yay!
See more
Mick Evans
1 month ago
Cait Min
2 months ago
Really helpful staff, the test was quick and easy and they gave me advice for finding glasses when I... never had to do so before.
They were also super helpful with fitting the appointment into my schedule when I had some unexpected changes so I appreciated it very much.
See more
Muhammad Ahsan Ullah
2 months ago
It was a great experience for me to be there and have their services
Lin Harrison
2 months ago
Luvly as always- optometric is so caring as are all the staff
Laura Wiseman
2 months ago
Christine Paxton
2 months ago
Very friendly, courteous and professional thank you
Gordon Ram
2 months ago
Very professional service.
Paul Sturges
2 months ago
Girls on the floor were great and the student girl that did the tests was awesome
lisa aldridge
2 months ago
Steven Ng
2 months ago
Nothing else but great service
Dolores Paul
2 months ago
Thyridi was excellent. I think I’ll get the best prescription that I’ve had. I had previously been a...t Soecsavers but was attracted to your glasses. I found the team completely lovely and helpful.
See more
Colin Ed
2 months ago
Brilliant service, tested everything
Kim Chapman
2 months ago
Great service from all of the team. On time and on point with what I was after. Simple but professio...nal
See more
Jackie Saunders
2 months ago
My experience was such a good one yesterday from the moment I walked  into the Marion store. The sta...ff were very helpful and it was refreshing and appreciated to have honest feedback on styles to suit my face.  The optometrist helped with lenses that were perfect for my needs, also helping with information for my dry eyes. Such a great team  left me leaving with a smile on my dial. Thanks very much! ????
See more
Kalu James
3 months ago
Truly the service here is so friendly. They truly do care and take the time to help. Each time I've ...been here has been the same, so friendly, informative and helpful. The glasses I purchased are great and so affordable but you can get that at most places, its the people that will have me coming back here.
See more
Gillian Starr
3 months ago
Wendy Dicks
3 months ago
Hayly Shillabeer
3 months ago
Daniela Britto
3 months ago
Sally Strawbridge
3 months ago
I had an eye exam as it has been just over 12 months. I was seen by a student who was lovely and got... it all right....but it took sooooo long! I was expecting the usual 15 min appt. But it blew out to over an hour.....which i didn't have as I had another appt to get to. Apart from that it was ok. Maybe check in for the future to see how the student is going and if the client has the time ☺️
See more
Matthew Brown
3 months ago
Went in on Sunday for an eye test, bought some new glasses and they helped me out with a repair of a... current pair and the service in all facets was absolutely outstanding.
Highly recommend.
See more
Jane Prideaux
3 months ago
The staff were very efficient and helpful
Lindsay Hutton
3 months ago
Debra Canino
3 months ago
I had a fantastic experience at the Marian store with a beautiful lady optometrist. She was lovely a...nd caring professional and very thorough. She advised me on single vision lenses. And I walked out happy. Also the two guys on the front desk were amazing. Especially Jeremy was super nice and they were both helpful. I'd recommend anyone to go there. I havnt received my glasses yet but I hope I'll be happy with them.
See more
Mark Goode
3 months ago
Friendly, fast &amp; thorough.
Anika Taka
3 months ago
I loved my experience at sunglass hut in Marion, my twin and I came in to Mother’s Day shop for our ...mum and the two workers at the front, (one with blonde hair and one with brown hair with tattoos) were the best help and were so lovely and kind, they helped us get the best deals and thankyou so much!! I highly recommend them and this place
See more
Baz Wildlife writer and photographer
3 months ago
The staff were professional and efficient and added a light hearted touch in their approach. A great... experience and I would always return to this Marion Shopping Centre branch.
See more
## Find an Optometrist in Marion With Oscar Wylee
Book online or visit our Oscar Wylee Marion store in Oaklands Park for your annual eye check-up. Close to Brighton and Seacombe Gardens and a 7-minute walk from Oaklands railway station, we offer prescription glasses and sunglasses inspired by modern and vintage styles. Oscar Wylee Marion provides Medicare bulk billed comprehensive eye tests in-store, so you can update your prescription and shop for your new glasses on the same day! 
You can find our Oscar Wylee eyeglasses shop in Westfield Marion, the largest shopping centre in South Australia, with parking onsite. If you’re looking for something to do after your appointment, just a 2-minute walk from Westfield is the Cultural Centre. Here you can admire local and touring art exhibitions at Gallery M or browse the Cultural Centre library. Plan a visit to Oscar Wylee today and experience some of the best optometrist eye care processes in Marion, Australia.        
Meet Our Team
* Optometrist Partner
B.Optom
Therapeutically Endorsed
* Store Manager
* Optometrist
B.VisSc M.Optom (TPA Endorsed)
Our Services
* Bulk Billed Eye Examinations
* Professional Frame Styling
* Frame Adjustments and Repairs
* Visual Fields Testing
* Optical Coherence Tomography (OCT)
* High Index Dispensing
Show All
## Find an Optometrist in Marion, Oaklands Park for an Eye Health Test
For optometry services, such as eye tests and prescription updates, you can visit an optometrist in Marion, Oaklands Park. The Oscar Wylee Marion store has dedicated optometrists who can provide comprehensive testing which includes vision and eye health assessments to detect eye diseases. For patients with more complex eye issues, our optometrists can refer them to an eye doctor, known in Australia as an ophthalmologist.
Oscar Wylee Marion provide eye tests at a bulk billed price for Medicare cardholders, however, the average price range for an optometrist in Marion can vary depending on factors such as the patient’s overall health. While at our store, customers can try on our range of stylish frames available as prescription and non-prescription glasses and sunglasses. Visit Oscar Wylee Marion where our great staff, including an optometrist and optical dispenser, can help with your eye care and eyewear needs.
## How to Find an Optometrist in Marion, Oaklands Park?
To find an optometrist in Marion, Oaklands Park, you can take certain steps that can help make it easier for you such as searching online, assessing the store’s opening hours and finding the directions to your chosen location. The steps on how to find an optometrist in Marion are listed below.
1. Search online using the phrase, Marion optometrist near me. This can also be done here on the website via our locations page.
2. Click on the Oscar Wylee link, which will take you directly to our Marion optometrist store page.
3. See the store’s opening hours and where the store is located specifically.
4. Use the Marion Google Business page link located under store hours to see the directions on how to get to the store.
You can also find an optometrist in Marion, Oaklands Park by searching the keywords optometrist near me. If you have locations enabled on your smartphone and you’re in the Marion area, our Oscar Wylee Marion store page should appear easily for you to click on.
### Is it Hard to Get an Eye Appointment in Marion, Oaklands Park?
No, it is not hard to get an eye appointment in Marion. You can easily book an appointment to see an Oscar Wylee optometrist in Marion right here on this page. At Oscar Wylee we have highly qualified optometrists available for bulk billed eye appointments, which can be booked online, over the phone, or in-store.
#### How to Compare Optometrists in Marion to Each Other?
To compare optometrists in Marion, you can use factors such as eye tests offered, health fund coverage, lens types and add-ons and eyewear offered. To take care of your vision and eye health, it is important to receive an eye test at least once every two years. There are different types of tests that can be performed in an eye test and not all optometrists may offer the same tests. Health funds can be used to help cover some of the cost of your frames and lenses. To find out if your health fund is accepted at a Marion optometrist in Oaklands Park, visit their website. In the case of Oscar Wylee, we accept all major health funds and provide on-the-spot claims in-store. There are many different lens options available for prescription glasses such as single vision, multifocal and high index lenses. Most optometrists in Marion will offer these lenses although it is good to make sure. There are also lens add-ons available to enhance your glasses such as anti-reflective and blue light filters. Finally, if you are looking to purchase a pair of glasses after your eye test, you can compare the different styles and colours you are interested in from the optometrists in Marion, Oaklands Park. Oscar Wylee offers a wide range of frames with vintage and modern inspirations in bold colours and subtle designs.
#### How to Find an Eyeglasses Shop in Marion, Oaklands Park?
To find a glasses store in Marion, you can try to follow these simple steps including searching online, selecting a convenient location and looking at their health insurance policies.  The steps on how to find a glasses store in Marion, Oaklands Park are listed below.
1. Search online using the phrase, glasses store in Marion. This will provide you with various options for glasses stores in the whole Marion, Oaklands Park area.
2. Select a glasses store that is most convenient for you to travel to.
3. Click the link to find out more information such as opening hours, exact location and directions to the glasses store in Marion.
4. Read their health insurance policies to ensure you know what health benefits you have access to.
Our Oscar Wylee glasses store in Marion, Oaklands Park offers primary eye care services such as comprehensive eye tests as well as other services performed by an optometrist and offers prescription and non-prescription eyewear.
##### Is it Possible to Purchase Prescribed Sunglasses in Marion, Oaklands Park Without Seeing an Optometrist?
Yes and no, it is possible to [purchase prescribed sunglasses](https://www.oscarwylee.com.au/sunglasses.html) in Marion, Oaklands Park without seeing an optometrist if you already have a prescription that has not expired. If your prescription is expired, you can book an eye test to receive an updated or new prescription which will require you to see an optometrist. This will ensure your prescription sunglasses are appropriate for your visual needs.
## Where is the Oscar Wylee Marion Optometrist Located in Oaklands Park?
The Oscar Wylee Marion optometrist is located in Westfield Marion Shopping Centre, near Big W. Westfield Marion is in the City of Oaklands Park and is the largest shopping centre in Adelaide.
### What is the Phone Number of Oscar Wylee Marion Optometrist Store?
The Oscar Wylee Marion optometrist store phone number is (08) 8296 3098. You can contact the Oscar Wylee Marion store between the hours of 9 am and 5:30 pm from Monday to Wednesday, 9 am and 9 pm on Thursdays, 9 am and 5:30 pm on Fridays and 9 am and 5 pm on Saturdays and Sundays.
### What are the Reviews for Oscar Wylee Marion Optometrist in Oaklands Park?
The many reviews for Oscar Wylee Marion optometrist in Oaklands Park, left by our various customers can be found here on the website and online when you search for Oscar Wylee Marion optometrist. The reviews for Oscar Wylee Marion optometrist are listed below.
* Marites Kelly:  Very pleasant and excellent service.
* Helena Blackburn:  The whole experience was great…from booking an appointment, the session with the optometrist to choosing the right frames (helpful staff member picked out a frame that I would not have done, and they were brilliant!) Thank you, can’t wait to get the glasses.
* Jessica Baker:  Super friendly and helpful staff, optometrist is incredibly thorough also. Highly recommend the Marion store.
* Renuka Karupiah:  Was a very good experience. Front counter staff and the optometrist were excellent.
#### What Treatments or Eye Care Processes are Done in the Oscar Wylee Marion Optometrist Location?
The treatments or eye care processes done in the Oscar Wylee Marion optometrist Oaklands Park location include a tonometry test, a digital photograph, a slit lamp exam and a refraction test. Additional tests that may also be performed can include a visual field test and a dilated fundus exam. The treatments or eye-care processes that are done in the Oscar Wylee Marion optometrist Oaklands Park location are listed below.
* A Tonometry Test: An optometrist or optical dispenser will conduct a tonometry test which involves the use of a machine that will release small puffs of air into your eyes. This will assist with measuring pressure in the eye.
* A Digital Photograph: An optometrist or optical dispenser may take a digital photograph of your eye which can be kept on record to use in future appointments to evaluate any changes to your eye.
* Slit Lamp Test: A slit lamp test can be used to evaluate your eye health, by examining your cornea and iris which are the anterior and posterior of the eye.
* Refraction Test: During a refraction test, an optometrist will have you view an image through different lenses and ask you to confirm which helps you see the image clearer.
* Visual Field Test: A visual field test can assist with assessing your peripheral vision, which may be beneficial for identifying any signs of glaucoma.
* Dilated Fundus Exam: A dilated fundus exam can help an optometrist assess your health in more detail by getting a clear view of the retina. This test is typically carried out for patients with diabetes and those who may be at risk of developing retinal damage.
## How Many Optometrists Exist in Marion, Oaklands Park?
There are many optometrists that exist in Marion, Oaklands Park to provide eye tests and glasses, including Oscar Wylee. The number of optometrists available in an area will typically depend on the population. At Oscar Wylee Marion, we offer excellent optometry services including eye tests performed by skilled optometrists using high-quality equipment. We also have a wide range of fashion-forward frames that customers can browse in a large selection of sizes and colours. If you’re looking for an optometrist in Marion, choose Oscar Wylee and we will take care of your optometry and eyewear needs.
### What are the Other Closest Optometrist Locations to Marion, Oaklands Park in Australia?
The other closest Oscar Wylee optometrist locations to Marion in Australia are Rundle Mall, West Lakes and Colonnades. The locations and their distance from Marion are listed below.
* Rundle Mall:  Rundle Mall is close to Marion, around 14 km. The [Oscar Wylee Rundle Mall](https://www.oscarwylee.com.au/locations/optometrist-rundle-mall.html) store is located in Oaklands Park. Visit Oscar Wylee Rundle Mall for excellent eye care and eyewear services.
* West Lakes:  West Lakes is close to Marion, around 19 km. The [Oscar Wylee West Lakes](https://www.oscarwylee.com.au/locations/optometrist-west-lakes.html) store is located in Westfield West Lakes opposite the Universal Store. For fashion-forward frames and comprehensive eye tests, visit Oscar Wylee West Lakes.
* Colonnades:  Colonnades is close to Marion, around 19 km. The [Oscar Wylee Colonnades](https://www.oscarwylee.com.au/locations/optometrist-colonnades.html) store is located in Noarlunga Centre in the Colonnades Shopping Centre, near Cotton On. Our Colonnades store offers many optometry services including bulk billed eye tests, visual field testing and red eye examination.
### Optometrist-led Eye Tests at Oscar Wylee Marion
Oscar Wylee offers bulk-billed eye health tests for Medicare cardholders performed by our skilled optometrists. Book an eye test with Oscar Wylee Marion to have your vision assessed and your eye health checked for certain eye diseases. Here at Oscar Wylee Marion, you can take care of your eyesight with our trusted optometrists and excellent retail staff.
### Major Health Funds Accepted
Our in-store experts at Oscar Wylee Marion will help you navigate your health fund with in-store claims and on-the-spot quotes. Plus our staff are available to answer any questions you may have about what your health fund plan makes you eligible for. Here at Oscar Wylee Marion, we want to make sure you get the best prescription eyeglasses and sunglasses you need at affordable, competitive prices.
### Stylish Frames at Oscar Wylee Marion
Oscar Wylee Marion offers prescription glasses and prescription sunglasses for everyone! Inspired by vintage and modern styles, our frames are both fashionable and affordable. Come into the Oscar Wylee Marion store today to chat with one of our experts to find the perfect frames for your face shape. Oscar Wylee Marion has bold shapes, contemporary colours and frames for all occasions!
Book Appointment
[Call us: (08) 8296 3098](tel:(08) 8296 3098)
[Leave a Review!](https://g.page/r/CWK3DowlbGdhEAg/review)