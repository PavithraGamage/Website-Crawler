# Source: https://www.oscarwylee.com.au/reading_glasses.html

# Reading Glasses
Everyone’s eyesight is different, but usually, we start to really notice a difference when we get to our 40’s and beyond. As part of the ageing process, the lens inside the eye becomes more rigid and less flexible, making it harder to focus on objects near the eye. When reading up close starts to become difficult but you can see things far away just fine, it could be a sign to have your eyes tested and consider some prescription reading glasses. To choose the best reading glasses for yourself you should identify your reading magnification by consulting an optometrist, consider face shape and factor in your personal style. To see our range of varied and stylish reading glasses, check out our [Reading Glasses](https://www.oscarwylee.com.au/glasses/collection/reading.html)
## What are reading glasses?
Reading glasses, also known as readers, are a solution to an age-related eye condition known as presbyopia. They magnify nearby objects, giving you the ability to read a book or do close range activities comfortably without blurry vision or eye strain.
### How do reading glasses work?
Reading glasses are fitted with different strengths of lenses, depending on a person’s prescription. These lenses act as a magnifying glass, enlarging objects close to your eyes, helping with blurred vision and squinting. They are different from distance glasses as distance glasses are made to help focus objects far away as opposed to objects up close.
### When to wear your reading glasses?
You should wear your readers when you want to see things up close. This could be when reading a menu, working on your computer or another digital device.
### Where to wear your reading glasses?
Most people wear their reading glasses at home and occasionally at work. It is not recommended to wear your reading glasses when driving or playing sports as they are not made with that visual demand in mind. If you find you are using your reading glasses to watch tv, it could be a sign that you may also need distance glasses, and that your reading may have worsened overall.
## How can you tell if you need reading glasses?
An Optometrist can check if you need reading glasses with a simple eye test. There are also common signs that indicate if you need reading glasses. These include:
* You find that reading up close is getting more difficult
* Squinting and straining to see small print
* You’re holding things further away to read
* Constantly straining your eyes to focus gives you headaches or tired eyes
## Are reading glasses and prescription glasses the same?
While reading glasses and prescription glasses are often considered to be the same thing, they have differences. Over-the-counter reading glasses come with a preset magnification strength and have the same prescription in both lenses. You would typically find these in chemists and even some department stores. They are less expensive and do not provide a full correction for individuals which can include astigmatism. They are also not made for long term use as they can cause eyestrain and discomfort. Prescription eyeglasses can be custom-made to give the proper prescription your eyes need. Not all people have the same prescription in both eyes, and frames sit differently on each person’s face so by being able to custom make the lenses, we can provide the best quality of vision for each person. You also might find that different styles of eyewear suit you better than others.
### What if I have trouble seeing things near and far away?
If you find you have difficulty seeing near and distant objects, you might need both reading and distance glasses or a pair of multifocal glasses. We recommend that everyone should have an eye test with an optometrist at least once every 2 years to check their eye health.
## Types of reading glasses
There are many different eye conditions that can determine the type of reading glasses you need. The main categories of reading glasses include multifocal lenses, single vision lenses, bifocal glasses, and blue light glasses.
### Multifocal lenses
[](https://www.oscarwylee.com.au/glasses/collection/reading.html)[Multifocal lenses](https://www.oscarwylee.com.au/multifocal-lenses.html), also called progressive lenses, are for people who are both nearsighted and farsighted. They are the perfect solution for anyone who doesn't want to switch between reading glasses and distance glasses.
### Single vision lenses
Single vision lenses are lenses with a single power over the lens. As a result, they correct vision over a single distance, for only one vision type. When it comes to single vision lens reading glasses, they help you see up close by enlarging what you see allowing you to focus with ease. They come in different strengths depending on your prescription and are very beneficial for activities such as sewing and reading.
### Bifocal glasses
Bifocal glasses provide nearsighted and farsighted vision correction, split between the top and bottom half of the lens. Often confused with multifocal lenses, bifocals include just two vision correction powers, rather than multiple for reading, intermediate and distance vision correction. Bifocals also have a visible line on the lens between the prescriptions, whereas multifocals have a seamless transition.
### Blue light glasses
[Blue light glasses](https://www.oscarwylee.com.au/blue-light-glasses.html) contain a filter that is added to your lenses to help protect your eyes from the blue light emitted from digital screens that may adversely affect you. This filter can be added to both prescription glasses and non-prescription glasses. Browse our complete [range of glasses](https://www.oscarwylee.com.au/glasses.html) and find a pair that suits you!
## How do I know what strength reading glasses to buy?
After an eye test, your optometrist will provide you with your exact prescription which will have the strength of reading glasses you need. Once you have picked out your eyeglasses, they will be fitted with your prescription lenses, helping you see clearly up close. There are a number of factors that can influence the strength of your prescription such as age and visual demand. To determine the right strength needed for your reading glasses, you can [book an eye](https://www.oscarwylee.com.au/booking) test with Oscar Wylee.
## Can I wear reading glasses all the time?
Many people enjoy wearing their reading glasses all the time as they are always on hand when they need to see things up close. In most instances, this can cause unwanted eyestrain for you as the glasses are not being used appropriately. Generally, people use reading glasses when reading things up close to prevent eye strain, especially for things that can’t be zoomed in on (e.g. your phone, computer, or other digital device, as opposed to a book or magazine). If you are unsure whether you should be using your reading glasses all the time, speak to your optometrist, they will give you instructions on how long you should be wearing them.
## Looking for your next pair of reading glasses?
Find your nearest Oscar Wylee store and our friendly staff can assist you.
All major health funds accepted in store.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
## Due for an eye test?
We recommend that everyone should have an eye test with an optometrist at least once every 2 years.
Oscar Wylee offers bulk billed eye test, so there are no out-of-pocket expenses for eligible Medicare card holders.
[Book an eye test](https://www.oscarwylee.com.au/booking)