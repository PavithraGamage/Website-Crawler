# Source: https://www.oscarwylee.com.au/neal-optical.html

# Neal
1
## Frame Design of Neal Glasses
The frame design of Oscar Wylee’s Neal glasses is characterised by its rectangle shape, metal frame and spring hinges. Neal glasses are a men’s frame that will work for any occasion, whether the wearer wants to liven up their work style or complement a fun outfit for a night out.
$169    
In stock
Only %1 left
2 pairs from $199
Discount auto-applied at checkout
3 pairs from $249
Discount auto-applied at checkout
Qty
Add to cart
Book an eye test
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
excluding prescription lenses
## About Neal Frames
Meet Neal, a sleek rectangular frame, perfect for round and oval face shapes. Neal emphasises a quiet sophistication with its subtly pronounced browline for sharp yet stylish eyewear.
| Frame fit | Measurements |
| --- | --- |
| WIDE | 55 - 17 - 145 |
Frame fit
WIDE
Measurements
55 - 17 - 145

These measurements mean lens width, bridge, and temple length in millimetres (mm). They can be found on the inside of the temple arm. If you already have a pair that you like, you can compare it to these measurements.
### Made from Stainless Steel
Oscar Wylee’s Neal frame is a men’s rectangle glasses frame that is suited for wide faces and those with round and oval face shapes. The Neal frame is a widely wearable frame that can be worn every day. The main specs of Oscar Wylee’s Neal glasses frame including dimensions, shape, materials, lenses, nose fit and hinges are listed below.
| Neal Frame Features | Neal Frame Description | Dimensions | Shape | Materials | Lenses | Nose Fit | Hinges |
| --- | --- | --- | --- | --- | --- | --- | --- |
| The dimensions of the Neal frame are measured in millimetres (mm) and are 55 - 17 - 145, meaning the lens width is 55 mm, the bridge is 17 mm and the temple length is 145 mm. |
| The Neal frame is a rectangular shape, well suited to wide faces. |
| Neal glasses are made mainly from a mixture of metal and acetate. |
| The lenses that can be used in the Neal frame are optical lenses, which include single vision and multifocal lenses and non-prescription lenses, which are plain and can have a filter like a blue light filter applied. |
| Neal frames are fitted with adjustable nose pads. |
| The hinges in Neal glasses are spring hinges, which are more flexible than other types of hinges and can extend past 90 degrees. |
Show All
### What Inspired the Frame Design of Oscar Wylee’s Neal Glasses?
The Oscar Wylee Neal frame design was inspired by current fashion trends as rectangle frames have continued to prove as a staple silhouette in eyewear. Rectangle glasses are a simple and essential shape so you can never go wrong with this classic frame in your glasses rotation.
## What to Know About Oscar Wylee’s Neal Glasses?
There are many aspects of the Oscar Wylee Neal frames that customers should know about, so they can decide whether this is the right frame for them. The Neal frame is a men’s rectangle-shaped frame. Oscar Wylee’s Neal frame is suitable for many face shapes but is particularly compatible with round and oval face shapes. The Neal frame’s simple design means that they are fashionable all year round. Neal glasses feature the standard [parts of glasses](https://www.oscarwylee.com.au/glasses/eye/part-of-glasses) such as a rim, temples, lenses, spring hinges and nose pads.
### What are the Types of Temple Tips or Earpieces Included with Oscar Wylee’s Neal Glasses?
The type of temple tips or earpieces included in Oscar Wylee’s Neal Glasses are made from acetate and the temples are made from brass.
### What Type of Nose Bridge do Oscar Wylee’s Neal Glasses Have?
The type of nose bridge included in Oscar Wylee’s Neal frame is nose pads.
### What Type of Nose Pads are Included with Oscar Wylee’s Neal Glasses?
Oscar Wylee’s Neal frame includes standard nose pads. Nose pads are great for comfort and can also be adjusted for the perfect fit.
### What Type of Lenses do Oscar Wylee’s Neal Glasses Have?
The type of lenses that typically come with the Oscar Wylee Neal [glasses frame](https://www.oscarwylee.com.au/glasses.html) are optical lenses. Optical lenses are glasses lenses that have a prescription within the lens to help correct vision issues such as myopia, hyperopia and astigmatism. Neal glasses can also come with non-prescription lenses, with add-ons such as a blue light filter. Neal frames are currently unavailable, however, customers can customise in-store and add on tint or polarisation.
### What Material is Used for the Rim of Oscar Wylee’s Neal Glasses?
The material used for the rim of Oscar Wylee’s Neal glasses frames is stainless steel. The rim refers to the part of a glasses frame that holds the lenses.
### What Type of Hinges are Included with Oscar Wylee’s Neal Glasses?
The type of hinges included with Oscar Wylee’s Neal frames are spring hinges. A spring hinge in a glasses frame refers to hinges that are more flexible than normal hinges and can go slightly beyond 90 degrees. Spring hinges can provide a closer fit to the face.
## What Face Types are Most Suitable for Oscar Wylee’s Neal Glasses?
The face types that are most suitable for Oscar Wylee’s Neal frame are round and oval face shapes. The Neal frame is a rectangular shape, meaning that it complements the structure of round and oval faces particularly well. The rectangular Neal frames help to balance the features of a [oval face shape](https://www.oscarwylee.com.au/glasses/face-shapes/oval) and [oval face shape](https://www.oscarwylee.com.au/glasses/face-shapes/oval), bringing the eyes and brows forward in a flattering way. rectangle frames help to enhance round and oval face shapes as they add sharp lines and angles, highlighting without overemphasising them. Although there are many [glasses for face shapes](https://www.oscarwylee.com.au/glasses/face-shapes) that may be considered more aesthetically suitable, it is important that people also choose the frames that make them feel most comfortable, and represent their personal style.
## What Size Options are Available for Oscar Wylee’s Neal Glasses?
The size options available for Oscar Wylee’s Neal frame are a wide-frame fit across all colours.
## What Materials are Used to Create Oscar Wylee’s Neal Glasses?
The materials used to create the Oscar Wylee Neal frame are a mixture of stainless steel, high nickel, brass and acetate. The nose bridge is made from high nickel, the rims are stainless steel and the temples are made from brass with acetate temple tips. Acetate, also known as cellulose acetate, is a bioplastic, made from cotton fibres or wood pulp.
## What’s Included
## What's Included
Each pair of glasses comes with a stylish frame case and lens cloth. We offer free shipping across Australia and 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects.
* Free Shipping for Australian Orders
* 1 Year Warranty on frames and lenses
* Scratch resistance lens coating on all prescriptions
* UV-proof coating on all prescriptions
* Stylish case and cloth
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
## Make and Materials
The frames then go through cleaning and strict quality control, and many pairs of crafting hands to be hand-assembled and polished. After your frames have gone through the production process, they are individually examined and packed before making their way to you!As part of our durable frame family, some of our most popular styles, are now in stainless steel. These frames are hypoallergenic, corrosion resistant, light weight, and not sensitive to temperature changes.
                            
## Warranty Information
### Warranty Information
### Warranty Information
Oscar Wylee provides a 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects. We will repair or replace faulty or defective frames or lenses free of charge for warranty claims made within 1 year of the delivery. We also offer repairs or replacement for problems experienced with vision during everyday use for claims made within 30 days of delivery. If the same product has been discontinued or is no longer available, then we may offer an exchange for a similar product or a refund.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Find a Store Location](https://www.oscarwylee.com.au/locations/full-store-list.html)