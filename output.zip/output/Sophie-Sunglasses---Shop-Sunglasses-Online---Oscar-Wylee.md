# Source: https://www.oscarwylee.com.au/sophie-sunglasses.html

# Sophie
1
## Frame Design of Sophie Sunglasses
The frame design of Oscar Wylee’s Sophie sunglasses is characterised by their oval and round shape, adjustable nose pad fit, and stainless steel frame. Sophie is a stylish women's glasses frame that will work for any occasion, whether the wearer wants to liven up their everyday style or complement a fun outfit for a day out.
$169    
In stock
Only %1 left
2 pairs from $199
Discount auto-applied at checkout
3 pairs from $249
Discount auto-applied at checkout
* 2 &amp; 3 Pair pricing applies to non-prescription sunglasses only. Prescription sunglasses incur additional charges.    
[Non-Prescription](https://www.oscarwylee.com.au/sophie-sunglasses.html#)
Qty
Prescription
Book an eye test
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
excluding prescription lenses
## About Sophie Sunglasses
Our highly coveted Cruz frame inspired Sophie - an understated, contemporary frame made for the modern girl.
| Frame fit | Measurements |
| --- | --- |
| WIDE | 55 - 21 - 140 |
These measurements mean lens width, bridge, and temple length in millimetres (mm). They can be found on the inside of the temple arm. If you already have a pair that you like, you can compare it to these measurements.
### Made from Stainless Steel with Acetate Tips
Oscar Wylee's Sophie frame is a women's oval and round sunglasses frame that is perfect for those with square, oval, heart, pear, and diamond face shapes. The Sophie frame is a modern and versatile frame that blends well with your outfits while making the perfect statement. The main specs of Oscar Wylee's Sophie glasses frame, including dimensions, shape, materials, lenses, nose fit, and hinges, are listed below.
Filter category 3 - General purpose sunglasses. High protection against sunglare. Good UV Protection. Not suitable for driving in twilight, at night or under dull conditions
This frame comes with tinted lenses. An additional $30 will be added to your order total for prescription orders.
| Sophie Frame Features | Sophie Frame Description | Dimensions | Shape | Materials | Lenses | Nose Fit | Hinges |
| --- | --- | --- | --- | --- | --- | --- | --- |
| The dimensions of the Sophie frame are measured in millimetres (mm) and are 55 - 21 - 140, meaning the lens width is 55 mm, the bridge is 21 mm, and the temple length is 140 mm. |
| The Sophie frame is an oval and round shape, well suited to wide faces. |
| Sophie is made from stainless steel, with acetate temple tips. |
| The lenses that can be used in the Sophie frame are sunglass lenses, which provide UV protection. Prescription lenses are also available to purchase for the Sophie sunglass frame, both online and in-store. |
| The nose fit of the Sophie frame is characterised by adjustable nose pads. |
| The hinges in Sophie glasses are normal hinges, also known as standard or barrel hinges. |
Show All
### What Inspired the Frame Design of Oscar Wylee's Sophie Glasses?
The Oscar Wylee Sophie frame design was inspired by current fashion trends, as oval and round shapes are often in fashion. An oval and round glasses shape is timeless; it remains popular throughout the decades while other trends come and go.
## What to Know About Oscar Wylee's Sophie Sunglasses?
There are many aspects of the Oscar Wylee Sophie frames that customers should know about, so they can decide whether this is the right frame for them. The Sophie frame is a women's oval and round sunglasses frame. Oscar Wylee's Sophie frame is suitable for many face shapes, but particularly compatible with square, oval, heart, pear, and diamond face shapes. The Sophie frame's simple design means that they are fashionable all year round. Sophie features the standard [parts of glasses](https://www.oscarwylee.com.au/glasses/eye/part-of-glasses), such as a rim, temples, lenses, hinges, and adjustable nose pads.
### What are the Types of Temple Tips or Earpieces Included with Oscar Wylee's Sophie Glasses?
The type of temple tips or earpieces included in Oscar Wylee's Sophie Glasses are made from acetate.
### What Type of Nose Bridge do Oscar Wylee's Sophie Glasses Have?
The type of nose bridge included in Oscar Wylee's Sophie frame is characterised by adjustable nose pads.
### What Type of Nose Pads are Included with Oscar Wylee's Sophie Glasses?
Oscar Wylee's Sophie frame includes adjustable silicone nose pads. Nose pads are adjustable for a perfect fit.
### What Type of Lenses do Oscar Wylee's Sophie Sunglasses Have?
The lenses that can be used in the Sophie frame are sunglass lenses, which provide UV protection. UV protection lenses block harmful ultraviolet rays, safeguarding eyes from damage. The Sophie frame comes in Filter Category 3. These are general purpose sunglasses that provide high protection against sunglare and good UV protection. They are not suitable for driving in twilight, at night, or under dull conditions. Prescription lenses are also available for the Sophie frame, both online and in-store.
### What Material is Used for the Rim of Oscar Wylee's Sophie Glasses?
The material used for the rim of Oscar Wylee's Sophie glasses frames is stainless steel. The rim refers to the part of a glasses frame that holds the lenses.
### What Type of Hinges are Included with Oscar Wylee's Sophie Glasses?
The type of hinges included with Oscar Wylee's Sophie frames are normal hinges, also known as standard or barrel hinges. These provide strength and smooth movement connecting the frame's arms and lenses.
## What Face Types are Most Suitable for Oscar Wylee's Sophie Glasses?
The face types most suitable for Oscar Wylee's Sophie frame are square, oval, heart, pear, and diamond face types. The Sophie frame is an oval and round shape, meaning it complements the structure of square, oval, heart, pear, and diamond faces particularly well. The oval and round Sophie frames help to balance the features of a [square face shape](https://www.oscarwylee.com.au/glasses/face-shapes/square), an [oval face shape](https://www.oscarwylee.com.au/glasses/face-shapes/oval), a [heart face shape](https://www.oscarwylee.com.au/glasses/face-shapes/heart), a [pear face shape](https://www.oscarwylee.com.au/glasses/face-shapes/pear), and a [diamond face shape](https://www.oscarwylee.com.au/glasses/face-shapes/diamond), bringing the eyes and brows forward in a flattering way. Although there are many different [glasses for face shapes](https://www.oscarwylee.com.au/glasses/face-shapes) that may be considered more aesthetically suitable, it is important that people also choose frames that make them feel most comfortable and represent their personal style.
## What Size Options are Available for Oscar Wylee's Sophie Glasses?
The size option available for Oscar Wylee's Sophie frame is a wide-fit frame.
## What Materials are Used to Create Oscar Wylee's Sophie Glasses?
The primary material used to create the Oscar Wylee Sophie frame is stainless steel. Stainless steel is a type of metal commonly used for glasses that is lightweight, durable and corrosion-resistant.
## What’s Included
## OW Case &amp; Cloth
Protective Case and Lens Cloth
Our high-quality glasses case and lens cloth are included with every purchase of an Oscar Wylee frame. The stylish, magnetic case is made from a hard shell. This sturdy and durable material keeps your glasses protected and safe, wherever you go. Ensure your lenses are clean and scratch-free with our OW microfibre cloth, specifically designed to ensure you have comfortable vision through your lenses.
Oscar Wylee offers:
* Free Shipping on all orders
* 1 Year Warranty on frames and lenses
* Scratch resistance lens coating on all prescriptions
* UV-proof coating on all prescriptions
Health fund rebate: Once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. Learn more about [health funds](https://www.oscarwylee.com.au/health-funds.html).
## Make and Materials
As part of our durable frame family, some of our most popular styles, are now in stainless steel. These frames are hypoallergenic, corrosion resistant, light weight, and not sensitive to temperature changes. The frames go through cleaning and strict quality control, and many pairs of crafting hands to be hand-assembled and polished. After your frames have gone through the production process, they are individually examined and packed before making their way to you!
## Warranty Information
### Warranty Information
### Warranty Information
Oscar Wylee provides a 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects. We will repair or replace faulty or defective frames or lenses free of charge for warranty claims made within 1 year of the delivery. We also offer repairs or replacement for problems experienced with vision during everyday use for claims made within 30 days of delivery. If the same product has been discontinued or is no longer available, then we may offer an exchange for a similar product or a refund.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Find a Store Location](https://www.oscarwylee.com.au/locations/full-store-list.html)