# Source: https://www.oscarwylee.com.au/glasses/sunglasses-for-suits

# Sunglasses For Suits
Published on August 28th, 2026
Australia
Australia
New Zealand
Canada
Canadian French

Sunglasses paired with suits are
a sleek, classic aesthetic that can be achieved when choosing the correct
pair of frames. The
best sunglasses for suits are square frames, aviators, browline frames,
rectangular frames, and round metal frames. Sunglasses should match the classic style of a suit and look great when
they coordinate with your shoes, belt, or watch. Aviators may be the best
choice for a tailored suit, creating an elegant aesthetic, whereas square or
round metal frames may complement a tuxedo better. It is important to note
your face shape when choosing sunglasses for a suit; for example, the best
glasses for round faces are rectangular, square and geometric glasses, as
the angular lines help to offset the soft curves of this face shape.
Prioritise Your Eye Health
Our team can help you stay up to date with regular eye tests to keep your
eyes healthy!
[Book an eye test](https://www.oscarwylee.com.au/booking)
[What Sunglasses Work Best](#what-sunglasses)
[How Should Sunglasses Match](#how-match)
[Formal Wear](#formal-wear)
[Tuxedo Styling](#tuxedo-styling)
## What Sunglasses Work Best With a Suit?
The
[sunglasses](https://www.oscarwylee.com.au/sunglasses.html)
that work best with a suit are
square frames, aviators, browline frames, rectangular frames, and
round metal frames.
These frames and how they complement a suit are explained in more detail
below.
### 1. Square frames
Square frames are a great choice to pair with a suit, as their
angular lines match the sharp, tailored silhouette of a classic
suit.
[Square frames](https://www.oscarwylee.com.au/glasses/silhouette/square.html)
work well to contrast softer, round facial features, which can make
you appear more masculine. These frames work particularly well with
navy, grey, or charcoal suits. Popular Oscar Wylee square sunglasses
frames are Bobby, Nolan, and Serge.

[](https://www.oscarwylee.com.au/bobby-sunglasses.html)
[](https://www.oscarwylee.com.au/nolan-sunglasses.html)
[](https://www.oscarwylee.com.au/serge-sunglasses.html)
[](https://www.oscarwylee.com.au/bobby-sunglasses.html)
[](https://www.oscarwylee.com.au/nolan-sunglasses.html)
[](https://www.oscarwylee.com.au/serge-sunglasses.html)
### 2. Aviators
[Aviators](https://www.oscarwylee.com.au/sunglasses/silhouette/aviator.html)
are
a classic choice to pair with a suit, providing a confident,
polished look. Aviators can work well to soften angular facial features, and metal
frames can be coordinated with your belt and watch. These frames look
particularly good with navy, black, or dark grey suits. Popular Oscar
Wylee aviator sunglasses are Murphy, Atomix, and Duckworth.

[](https://www.oscarwylee.com.au/murphy-sunglasses.html)
[](https://www.oscarwylee.com.au/atomix-sunglasses.html)
[](https://www.oscarwylee.com.au/duckworth-sunglasses.html)
[](https://www.oscarwylee.com.au/murphy-sunglasses.html)
[](https://www.oscarwylee.com.au/atomix-sunglasses.html)
[](https://www.oscarwylee.com.au/duckworth-sunglasses.html)
### 3. Browline frames
[Browline frames](https://www.oscarwylee.com.au/glasses/browline)
can
provide a sophisticated, intellectual appearance, and work
particularly well with tailored suits. Browline sunglasses offer a vintage 1950's look that can complement
more classic vintage-style suits perfectly. Stick to neutral shades
and ensure the top brow bar of the glasses fits your face correctly
without hiding your eyebrows.
### 4. Rectangular frames
[Rectangular frames](https://www.oscarwylee.com.au/sunglasses/silhouette/rectangle.html)
exude a clean and modern aesthetic, ideal for contemporary or
slim-cut suits.
Rectangular frames have sharp angles and clean lines, which complement
the structured look of a classic suit. These frames are also highly
versatile, pairing nicely with a range of different suit styles.
Popular Oscar Wylee rectangular sunglasses are Jett, Loretta, and
Stevo.
### 5. Round metal frames
[Round metal frames](https://www.oscarwylee.com.au/sunglasses/silhouette/round.html)
can deliver a subtle vintage or retro-inspired vibe to a classic
suit.
Round metal frames paired with a suit may suit more creative
environments like fashion events or summer weddings. Metal frames can
pair nicely with your jewellery or belt. Popular Oscar Wylee round
metal sunglasses are Cruz, Haskell, and Kato.

[](https://www.oscarwylee.com.au/cruz-sunglasses.html)
[](https://www.oscarwylee.com.au/haskell-sunglasses.html)
[](https://www.oscarwylee.com.au/kato-sunglasses.html)
[](https://www.oscarwylee.com.au/cruz-sunglasses.html)
[](https://www.oscarwylee.com.au/haskell-sunglasses.html)
[](https://www.oscarwylee.com.au/kato-sunglasses.html)
Find Your Nearest OW Store!
We've got knowledgeable teams who are passionate about delivering
high-quality care.
[Find a store](https://www.oscarwylee.com.au/locations)
## How Should Sunglasses Match a Suit?
[Sunglasses](https://www.oscarwylee.com.au/glasses/eye/sunglasses)
should complement a suit's colour, formality, and overall
style. Choose simple frames, balanced proportions, and neutral lenses.
Classic shapes such as square, aviator and browline frames will look
appealing with a range of suit types. Stick to a neutral colour palette,
choosing staple colours such as black, brown, tortoiseshell, navy, grey,
gold, and silver. A coordinated pair of sunglasses can make formal
clothing look more polished and put together.
### Do Classic Sunglasses Work Better With Formal Suits?
Yes,
classic sunglasses usually work better with formal suits. Classic styles such as square, aviator, and browline frames better
complement the elegant aesthetic of suits. When pairing sunglasses
with suits, avoid loud colours or sport sunglasses, which can clash
with the simplicity of a suit outfit and throw off the look entirely.
## Can you Wear Sunglasses With Formal Wear?
Yes,
you can wear sunglasses with formal wear if you are outside in bright
sunlight, but it is best to opt for classic styles and remove them
indoors.
Classic sunglasses shapes such as square and aviator styles in neutral
colours like black, dark brown, or sleek metallic finishes like gold and
silver will work best with formal wear. Avoid sporty or overly thick
sunglasses styles, which can draw attention away from your outfit
instead of complementing it. It is best practice to remove your
sunglasses when indoors or when talking to someone new.
### When are Sunglasses Suitable for Business and Formal Occasions?
Sunglasses are suitable for business and formal occasions for
outdoor business settings, daytime formal occasions, or
commuting.
Sunglasses are acceptable to wear during sunny outdoor business events
and outdoor formal gatherings, such as garden weddings or receptions.
Sunglasses are also acceptable when you are commuting to and from
business and formal occasions. Ensure you remove your sunglasses when
conducting business or talking to someone new, and remove them when
you step indoors.
#### Are Sunglasses Appropriate for Weddings and Other Formal Events?
Yes,
sunglasses are appropriate for weddings and other formal
events, provided they are outside, and you remove them during key parts
of the ceremony, such as the processional walk and exchanging vows.
Wearing sunglasses at weddings and formal events is completely
acceptable when it is sunny outside, and is recommended to protect
your eyes from harmful UV rays.
## What Sunglasses Should You Wear With a Tuxedo?
The sunglasses you should wear with a tuxedo
depend on your face shape and personal style.
Generally, dark-framed square sunglasses with clean, sharp lines will
look great with a tuxedo, particularly square, aviator, and rectangular
shapes. For the best look, match your sunglasses with your suit and keep
the frame shape simple and angular.
### How can you Keep Tuxedo Eyewear Looking Formal?
To keep tuxedo eyewear looking formal,
it is best to avoid bright, mirrored, or sports sunglasses, which
can clash with a tuxedo.
Ensure your frames fit you correctly and remain smudge-free to retain
formality. Choose frames that are not too thick, as this can be
unappealing when paired with formal wear. If in doubt, opt for classic
eyewear colours such as black, gold, or silver frames.
#### Can you Wear Sunglasses With a Tuxedo at a Formal Event?
Yes,
you can wear sunglasses with a tuxedo at a formal event, provided
you are outside in bright sunlight.
It is best to remove your sunglasses when indoors or if it is
nighttime. When wearing a tuxedo, pick simple, elegant frames in
simple colours.
## Where Should you Put Sunglasses When you are Not Wearing Them?
You should put your sunglasses in a hard-shell protective case when
you are not wearing them.
If you are on the go or removing them temporarily, you can hook your
sunglasses over the collar of your shirt or slip them in your breast
pocket, but this is not as safe as using a case. Avoid putting them on
top of your head, which can stretch the arms, or putting them loose in a
bag, which can cause scratches.
### Should You Remove Sunglasses When Speaking to Someone?
Yes,
you should generally remove your sunglasses when speaking to
someone.
If you are talking closely with someone, talking to someone new, or
discussing business, it is best practice to remove your sunglasses.
However, if you are talking to someone you are close with, or in an
informal conversation or setting, it may not be necessary to. It is
best to read the room and judge if it is appropriate to be wearing
sunglasses yourself. If in doubt, it is best to just remove them to
show courtesy.
## Which Sunglasses Suit Different Face Shapes and Suit Styles?
The main
[face shapes](https://www.oscarwylee.com.au/glasses/face-shapes)
are round, square, oval, and heart shaped, and different sunglasses
shapes will suit these accordingly. Formal suits work best with
classic, understated frames.
The best sunglasses for different face shapes, and which work best with
formal suits, are explained further below.
### 1. Round Face
For
[round faces](https://www.oscarwylee.com.au/glasses/face-shapes/round), square and rectangular sunglasses are best suited,
as they can add definition with their sharp angles and balance the
natural curves of these face types.
### 2. Square Face
[Square faces](https://www.oscarwylee.com.au/glasses/face-shapes/square)
will suit round, oval, and curved aviator frames the
best. These frame shapes have smooth curves that will contrast the
stronger facial features of square faces.
### 3. Oval Face
[Oval face shapes](https://www.oscarwylee.com.au/glasses/face-shapes/oval)
will suit a variety of sunglasses, but particularly
rectangle, square, and aviator styles. Rectangle and
square frames will add contrast to the softer curves of oval faces,
and aviator frames can add definition to your cheekbones.
### 4. Heart Shaped Face
[Heart shaped faces](https://www.oscarwylee.com.au/glasses/face-shapes/heart)
will look best in square, classic, and aviator sunglasses. These
shapes help to balance the face by drawing attention away from the
forehead and creating more width in the eye area, which helps create
better proportions.
### 5. Formal Suit
The best sunglasses for a formal suit are
simple, classic shapes such as square, aviator, and browline
frames. These styles will complement tailored suiting and offer clean lines
that match formal wear attire.
#### Can the Right Sunglasses Make a Suit Look More Polished?
Yes,
the right sunglasses can make a suit look more polished.
Choose classic shapes, quality materials, and neutral colours to
create a refined, fresh look. Ensure your sunglasses fit your face
correctly, and follow guidelines on when to remove them.
Read Sunglasses For Suits in other Oscar Wylee regions and their
languages.
Australia
Australia
New Zealand
Canada
Canadian French

Experience High Quality Eyecare Services From Our Team
Book an appointment online with an Oscar Wylee optometrist today.
[Book an eye test](https://www.oscarwylee.com.au/booking)
Major Health Funds Accepted
In-store
For the purchase of frames and lenses, use your private health fund to
limit how much you pay from your own pocket.
[Health Funds](https://www.oscarwylee.com.au/health-funds.html)