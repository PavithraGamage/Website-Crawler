# Source: https://www.oscarwylee.com.au/glasses/eye/dry-eyes

# Dry Eyes: Causes, Treatment, and Prevention
Published on June 6th, 2023
Updated on December 6th, 2024
Australia
[Australia](https://www.oscarwylee.com.au/glasses/eye/dry-eyes)
[Canada](https://oscarwylee.ca/glasses/eye/dry-eyes)
[Canadian French](https://oscarwylee.ca/fr/glasses/eye/dry-eyes)
The dry eyes definition states this is a common
condition that can be described as a lack of tears produced or an
inadequate quality of tears.
This hinders the eye from retaining moisture, which is vital in protecting
the eye from infections and debris. According to the American Optometric
Association, dry eyes symptoms can include watery eyes, redness, and
sensation of stinging, burning and scratching. Other vision-related symptoms
may include sensitivity to light, blurry vision and stringy eye mucus.
Treating dry eyes may involve using artificial tears or special eye drop
solutions that help generate more tears. Another form of dry eyes treatment
is intentionally blocking your tear ducts to retain your tears. Dry eyes
cause may be due to reduced tear production from factors such as hormonal
changes and certain medications. The other cause may be a result of tears
drying out too quickly due to a decreased blink rate, contact lenses and
certain medications. Dry eyes are diagnosed by an optometrist through a slit
lamp biomicroscope, using sodium fluorescein dye or by measuring your tear
production.
[Definition](#Definition) [Causes](#Causes)
[Associated Medical Conditions](#Conditions)
[Accompanying Symptoms](#Symptoms)
## What are Dry Eyes?
Dry eyes are defined as having an insufficient amount of moisture in your eyes to maintain
their health and is one of the many [common eye problems](https://www.oscarwylee.com.au/glasses/eye/common-problems)
that can easily develop from a range of causes.
Tears are produced by glands in the eye and blinking throughout the
day coats your eyes with a thin layer of tear film. The tear film aids
in keeping the eyes safe from a build-up of foreign matter and
maintaining moisture. When there is not enough moisture in the eye,
you may experience irritation, itchiness and a gritty sensation.
Do you need an eye test?
Book an eye test with one of our dedicated Oscar Wylee optometrists
today.
[Book an eye test](https://www.oscarwylee.com.au/booking)
## How Common Are Dry Eyes?
Dry eyes are common across all age groups and it is reported that most
Australians have experienced dry eyes according to the 2022 Vision
Index.
Respondents who experienced dry eye symptoms in this study amounted
to 85%.
## How Dry Eyes Developed?
Dry eyes are developed
when the eyes are producing tears but they evaporate before
effectively lubricating the eye. The quality of the tears that are
produced is essential due to how they particularly moisturise the
eye.
The lacrimal (tear) glands produce tears consisting of a combination of
water, mucus and oil. Each of these substances contributes to creating
moisture in the eye, while the mucus layer aids in evenly distributing
the tears over the eye. The oil that is produced prevents the water
layer from evaporating too quickly. Poor-quality tears can result from
factors like meibomian gland dysfunction, a reduced blink rate, contact
lens wear, and certain medications. Meibomian gland dysfunction is when
the meibomian (oil) glands in the eyelid do not produce enough or
quality oil according to the National Institutes of Health. Meibomian
gland dysfunction can be managed through a warm compress over the eyes,
antibacterial eye drops and artificial tears.
The amount of tears that can be generated is also vital in
maintaining the health of the eye.
As you age, you tend to generate fewer tears or as a side effect of some
medications. According to the American Optometric Association, during
dry or windy climates, your tears are more vulnerable to tear
evaporation, which can increase the risk of dry eye.
### What Do Dry Eyes Feel Like?
Dry eyes can feel like there is
foreign material in your eye and a sensation of grittiness.
Other symptoms related to the feeling of dry eyes are
pain, burning, itching and light sensitivity.
## What are the Causes of Dry Eyes?
The causes of dry eyes can be a consequence of many factors such as
aging, medical conditions, wearing contact lenses, hormonal changes,
eye surgery, frequent eye-rubbing, phone and computer screen time and
infrequent blinking.
The different causes of dry eyes and their definitions are listed below.
* Aging: Aging can be a cause of dry
eyes as you naturally produce fewer tears as you get older.
* Medical conditions: Medical conditions
such as diabetes, thyroid and rheumatoid arthritis can increase the
risk of developing dry eye.
* Wearing contact lenses: Wearing
contact lenses may cause dry eye due to the thin disk of the contact
lens allowing less oxygen to flow to the eye.
* Hormonal changes: Hormonal changes can
affect the glands in and around the eye which can disrupt tear
production.
* Eye surgery: Types of eye surgeries
such as cataract surgery can affect the stability of your tears which
may trigger dry eye.
* Eye-rubbing frequently: Eye-rubbing
frequently can worsen the feeling of dryness in your eyes.
* Looking at a phone or computer screen for long periods:
Looking at a phone or computer screen for long periods can cause you
to blink less, which may lead to dry eye.
* Not blinking regularly: Not blinking
regularly can cause fewer tears to coat your eyes which may lead to
dry eyes.
### 1. Aging
Aging
can significantly contribute to developing dry eye as a result of
the lacrimal gland changing as you get older.
According to Stefano Barabino in a paper published in BMC
Ophthalmology, the increased use of topical and systemic medications,
changes to eyelid structure and menopause are factors that can cause
the lacrimal gland to generate fewer tears. Other major causes of
reduced tear production as a result of tear film deterioration are
eyelid abnormalities, meibomian gland dysfunction and reduced
reactions to corneal stimulation. An optometrist may prescribe eye
drops, warm compress or cleaning solution for eyelids to relieve
symptoms of dry eye and any inflammation.
### 2. Medical Conditions
Medical conditions such as autoimmune diseases can result in the
development of dry eyes due to their impact on the essential regions
of the eye. Diabetes may lead to dry eyes as high insulin levels can
damage nerves in the lacrimal glands. These nerves allow for the tears
to stick to the eye according to the American Diabetes Association.
Thyroid conditions may lead to dry eye as it can cause lacrimal gland
inflammation and affect the cells around the eye. According to Mayo
Clinic, rheumatoid arthritis can affect the tissues around your eyes,
which can cause unusual tear production.
It is important to consult with your optometrist if you have any of
these conditions as they will be able to determine the cause of your
dry eye.
### 3. Wearing Contact Lenses
Wearing contact lenses may increase the risk of developing dry eye as
it reduces the amount of oxygen that can flow to the eye.
According to the National Library of Medicine, wearing contact lenses
can result in tear film separation, creating pre and post-lens film.
This may lead to complications in the distribution of the outer layer
of the tear film, tear evaporation and instability of the tear film.
The three layers in the tear film also include an outer lipid layer
which functions to stabilise the tear film. It is advised to consult
with an optometrist if you have dry eyes and use contact lenses as
they may recommend using lubricating eye drops.
### 4. Hormonal Changes
Hormonal changes can be a factor in developing dry eyes, especially
for women who may be on birth control pills, going through pregnancy
or menopause. According to the Wellington Eye Centre, hormone
receptors are found in the lacrimal glands and meibomian glands. These
glands are responsible for producing tears and oils within the eye.
Changes in hormones may also result in inflammation around the eye,
which may cause symptoms of dry eye. An optometrist can assist with prescribing eye drops or gels to
relieve these symptoms and determine the underlying cause.
### 5. Eye Surgery
Eye surgery such as cataract surgery or laser eye surgery may trigger
symptoms of dry eyes as they can mainly affect the tear film. Cataract
surgery may cause the lipid layer to become thinner, which can impair
the tear film and trigger dry eye symptoms. The other effects of
cataract surgery that can link to dry eyes include corneal nerve
damage, inflammation, light exposure and eye drop medications. The
changes to your cornea shape from laser eye surgery can cause unusual
tear distribution when blinking. This occurs due to the surgery’s
impact on the relationship between the ocular surface and the eyelids
according to the National Library of Medicine.
### 6. Eye-Rubbing Frequently
Eye-rubbing frequently
can worsen symptoms of dry eyes as it may cause damage to the
surface of the eye.
Damage or scratches to the surface of the eye can increase the risk of
dryness occurring. You may need to rub your eye due to itching or
irritation which may be triggered by eye allergies or debris. In this
case, it may be best to use eye drops to help alleviate itching or to
wash out any debris according to the Vision Eye Institute.
### 7. Looking at a Phone or Computer Screen for Long Periods
Looking at a phone or computer screen for long periods
may cause you to blink less, causing incomplete blinking, tears to
dry out quickly and dry eye.
According to the National Library of Medicine, extended periods of
screen time weakens the spread of tears on the eye's surface. This
results in tears drying out too quickly, causing dry eyes. Actively
remembering to blink more while looking at computer screens and taking
regular breaks may help.
### 8. Not Blinking Regularly
Not blinking regularly can
prevent your tears from coating your eyes with the moisture it
needs to stay healthy.
The eyelid’s main purpose of protecting the health of the cornea is
achieved by retaining the tear film. Ensuring frequent blinking can
help strengthen the lipid layer that sits on top of the aqueous layer,
according to the National Library of Medicine. A stronger lipid layer
can reduce the evaporation of tears.
#### Can Dry Eyes Cause Vision Loss?
Yes and no.
Most cases of dry eyes are not vision threatening  and while
it cannot be cured, the symptoms can be managed with treatment such
as using lubricating eye drops. According to the Mayo Clinic, a
complication of severe untreated dry eyes may cause eye inflammation
and vision loss.
If you are experiencing dry eye symptoms, it is recommended you
have your eye health assessed by an optometrist by booking an eye
test.
#### Can Medications Cause Dry Eyes?
Yes, in some cases, certain medications may cause dry eyes.
According to Penn Medicine,
the medications that may cause dry eyes include diuretics, birth
control pills, certain heart medications, tranquilisers and ulcer
medications.
## What Medical Conditions Cause Dry Eyes?
The medical conditions that can cause dry eyes include
diabetes, autoimmune diseases, thyroid conditions and rheumatoid
arthritis.
Autoimmune diseases impact the essential regions of the eye which can
lead to dry eyes. High insulin levels as a result of diabetes can damage
certain nerves in the eyes leading to dry eyes. Thyroid conditions may
cause dry eyes as it can affect the cells around the eyes. Finally,
rheumatoid arthritis may cause unusual tear production as it affects the
tissues around the eyes, causing dry eyes.
### Can Dry Eyes be a Result of Wearing Contact Lenses?
Yes, dry eyes can be a result of wearing contact lenses due to less
oxygen flowing through to the eye. [Wearing contact lenses](https://www.oscarwylee.com.au/glasses/eye/contact-lenses/problem)
may increase the risk of developing dry eye as it reduces the amount
of oxygen that can flow to the eye. According to the National
Library of Medicine, wearing contact lenses can result in tear film
separation, creating pre and post-lens film. This may lead to
complications in the distribution of the outer layer of the tear
film, tear evaporation and instability of the tear film. The three
layers in the tear film also include an outer lipid layer which
functions to stabilise the tear film. It is advised to consult with
an optometrist if you have dry eyes and use contact lenses as they
may recommend using lubricating eye drops.
Find your nearest Oscar Wylee store
Our capable team can help you with any concerns about your vision
health and eyewear needs.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
## What are the Symptoms of Dry Eyes?
The symptoms of dry eyes may include a sensation of grittiness, stinging
and burning, itchiness, redness, blurred vision and tearing according to
Better Health. These dry eye symptoms are common, however, you may not
experience all of them. The symptoms of dry eyes are listed below.
* Sensation of grittiness: Sensation of
grittiness is a symptom of dry eye that can be described as a scratchy
or rough feeling in the eye.
* Stinging and burning: Stinging or
burning is a dry eye symptom that can occur when your eyes are
excessively dry.
* Itchiness: Itchiness is a symptom of
dry eye that can occur when your eyes do not have enough moisture.
* Redness: Redness is a symptom of dry
eye that can be caused when not enough tears are being produced to
cover the eye.
* Blurred vision: Dry eyes may cause
blurred vision as the eye’s tear film is not able to wash away foreign
matter in the eye.
* Tearing: Tearing can occur as a result
of dry eye as it triggers the lacrimal gland to generate tears.
### What are the Dry Eyes Complications?
If dry eyes are untreated they can lead to complications which can
further affect the eyes. According to BetterHealth, complications of
untreated dry eyes include
fluctuations in a person’s vision which can affect visual clarity,
eye discomfort and damage to the cornea, which in extreme cases can
lead to permanent scarring.
Another complication of dry eyes discussed by the Mayo Clinic is an
increased risk of eye infections due to the eyes’ lack of tear
production.
#### Can Dry Eyes Cause Eye Pain When Blinking?
Yes, dry eyes can cause eye pain when blinking as the lack of
moisture in the eye may leave a gritty or rough feeling in the
eye. When the eye doesn’t have optimal levels of tear film which
serves as a protective barrier and provides ocular comfort, your
eyes may feel discomfort and pain when blinking according to the
Dean Mcgee Eye Institute. If you are wondering [why your eyes hurt when you blink](https://www.oscarwylee.com.au/glasses/eye/why-does-my-eye-hurt-when-i-blink), you can see professional advice from your optometrist so they
examine your eyes.
## How are Dry Eyes Diagnosed?
Dry eyes are commonly diagnosed by an eye care professional, typically
an optometrist. If a person is experiencing dry eye symptoms, it is
recommended that they book an eye test so that a professional can assess
their eye health. According to the Mayo Clinic,
to diagnose dry eyes, an optometrist will perform a comprehensive eye
test to determine the health of a patient’s eyes.
Next, an optometrist will typically perform a test to measure the volume
of tears the patient is producing. This can help determine if the eyes
are producing enough tears to lubricate the surface of the eye. You can
read more helpful information in our [how to detect eye disease](https://www.oscarwylee.com.au/glasses/eye/how-to-detect-diseases) article.
### Can Dry Eyes be Diagnosed Just by Their Symptoms?
No,
dry eyes are not only diagnosed just by their symptoms, there are
other tests typically involved to reach a diagnosis.
While the diagnosis will include an evaluation of the patient’s symptoms
and medical history, there are commonly additional tests performed such
as a comprehensive eye test.
### Can a Slit Lamp Exam Diagnose Dry Eyes?
Yes, a slit lamp exam can diagnose dry eyes as it can help the
optometrist examine different structures of the eye including the
conjunctiva, cornea, eyelids, iris, lens and sclera. As a result, the [slit lamp examination](https://www.oscarwylee.com.au/glasses/eye/slit-lamp-exam)
can identify signs of not only dry eyes but also cataracts, macular
degeneration, inflammation and retinal detachment.
## What are the Treatments for Dry Eyes?
The treatments for dry eyes
typically involve adding moisture to the surface of the eyes.
According to BetterHealth, common dry eye treatments include using
lubricating eye drops, also known as artificial tears, trying to blink
more often, using a humidifier or placing bowls of water around a room to
make the air less dry, using medication after consulting with an eye care
professional and, for severe cases, treatment may include surgery. Dry
eyes cannot be cured permanently, therefore, there is no answer to the
question, how to cure dry eyes permanently.
### What is the Best Type of Eye Drop for Dry Eyes?
The best
[type of eye drop](https://www.oscarwylee.com.au/glasses/eye/types-of-eye-drops)
for dry eyes are artificial tears. Also known as lubricating eye drops,
artificial tears can be purchased over the counter for relief from
dry eye symptoms.
Artificial tears work by bringing moisture back to the eye to reduce
dryness. They add lubrication to the surface of the eye in place of
tears as the eyes may not be producing enough. For more severe dry eye,
a person can use prescription eye drops when recommended by an eye care
professional.
### Does Dry Eyes Heal Itself?
No,
dry eyes do not heal themselves as there is no cure for this eye
condition,
rather its symptoms can most often be easily managed with treatment.
Therefore, dry eye condition does not go away but can become less
prominent with treatment.
### How Long Does it Take for Dry Eyes to Heal?
As mentioned above,
there is no specific time it takes for dry eyes to heal as this eye
condition cannot be cured, rather its symptoms can be managed.
Dry eye management typically involves using eye drops regularly to add
moisture to the surface of the eye and avoiding situations that trigger
dry eye symptoms.
## How are Dry Eyes Prevented?
According to the Mayo Clinic, dry eyes can be prevented by paying
attention to the situations that trigger the symptoms and attempting to
find ways to avoid these situations. Some common ways to prevent dry eyes
include
taking breaks from tasks, wearing sunglasses, using artificial tears,
quitting smoking and avoiding air blowing on the eyes.
The different ways dry eyes may be prevented are listed below.
* Take breaks from tasks: It is important
to give the eyes a rest by taking breaks from long tasks that require
the eyes to concentrate intensely. These activities can include reading,
working on a computer and driving.
* Wear sunglasses: Sunglasses should be
worn to protect the eyes from the harmful UV rays emitted by the sun.
Sunglasses can also help prevent dry eyes as they shield the eyes from
aggravating environmental factors such as wind and dust.
* Use artificial tears: Artificial tears,
also known as lubricating eye drops, help bring moisture to the eyes and
reduce dryness. They are available over the counter and mimic the tears
produced by the eyes.
* Quit smoking: Quitting smoking can
potentially improve overall eye health and eyesight as tobacco has been
proven to cause damage to various parts of the eye. Smoking can also
worsen dry eye symptoms, therefore, it is beneficial to quit smoking.
* Avoid air blowing on the eyes: To help
prevent dry eyes, a person should avoid air blowing directly in the eyes
as this can dry out the eyes causing irritation and other dry eye
symptoms.
### Can Blue Light Glasses Help Prevent Dry Eyes?
Blue light glasses may help prevent dry eyes. The purpose of [blue light glasses](https://www.oscarwylee.com.au/glasses/eye/blue-light)
is to protect the eyes from the potential effects of blue light from
digital devices. Some of the effects of high blue light exposure
include eye strain and dry eyes. However, the effectiveness of blue
light glasses may vary from individual to individual.
### Does Drinking Enough Water Help Prevent Dry Eyes?
Yes,
drinking enough water can help to prevent dry eyes as it aids the
eyes in producing an adequate amount of tears.
According to the Canadian Association of Optometrists, staying hydrated
helps to keep the eyes moisturised, avoiding dry eye symptoms.
Dehydration affects the whole body, not just the eyes, but some
eye-related signs that indicate you need to drink more water include
sensitivity to light, a gritty feeling in the eyes and a burning
sensation in the eyes. It is important to stay hydrated by drinking
plenty of water throughout the day to help prevent dry eyes.
### Is Wearing Sunglasses Outside Helpful in Preventing Dry Eyes?
Yes, wearing sunglasses outside can be helpful in preventing dry eyes.
Sunglasses have tinted lenses that protect the eyes against ultraviolet
radiation emitted from the sun. People often suffer from dry eyes due to
environmental factors such as wind and dry climates.
Wearing sunglasses can protect the eyes from aggravating environments
as they block wind and dust from entering the eye which can cause dry
eyes.
Sunglasses are also beneficial in preventing certain eye diseases as,
according to UPMC HealthBeat, prolonged exposure to the sun can increase
a person’s risk of developing cataracts and macular degeneration. Read
our article on the
[best UV sunglasses for eye protection](https://www.oscarwylee.com.au/glasses/best-uv-sunglasses-for-eye-protection)
to find a pair that suits your needs.
### Does Lutein Help Prevent Dry Eyes Symptoms?
Lutein can help prevent dry eye symptoms. [Lutein](https://www.oscarwylee.com.au/glasses/eye/best-vitamin/benefits-of-lutein)
is a fat-soluble antioxidant nutrient in the carotenoid family that
can be found in dark green, leafy vegetables such as spinach and kale.
A study done by Frontiers Organisation showed the beneficial effects
of 6 months of lutein and zeaxanthin supplementation were done by
regular users of electronic screens. There were improvements in
several ophthalmic examinations done for dry eyes and visual
health.
## How Can Presbyopia Patients Experience Dry Eyes?
Patients with presbyopia may experience dry eyes
as age can significantly contribute as a risk factor for developing both [presbyopia conditions](https://www.oscarwylee.com.au/glasses/eye/presbyopia) and dry eyes.
As you get older, the eye’s ability to produce a sufficient amount of
tears to sustain moisture declines and can therefore lead to dry eyes.
The same can be said for developing presbyopia, with increased age, the
lens becomes less flexible, making it more difficult for the lens of the
eye to focus on objects.
### Does Smoking Make Dry Eyes Worse?
Yes, smoking can make dry eyes worse. It can lead to Dry Eye
Syndrome, an eye condition that can be aggravated or caused by
smoking. Tobacco is a known eye irritant and can worsen [dry eye](https://www.oscarwylee.com.au/glasses/eye/how-smoking-affect-eye-health)
symptoms. Tobacco smoke breaks down the lipid layer of the tear film,
making it a potential factor in dry eyes.
Read Dry Eyes: Causes, Treatment, and Prevention in other Oscar Wylee
regions and their languages.
Australia
[Australia](https://www.oscarwylee.com.au/glasses/eye/dry-eyes)
[Canada](https://oscarwylee.ca/glasses/eye/dry-eyes)
[Canadian French](https://oscarwylee.ca/fr/glasses/eye/dry-eyes)
Major Health Funds accepted at Oscar Wylee
Come in-store and our team will happily assist you in using your health
fund to cover some of the cost of your frames and lenses.
[Health Funds](https://www.oscarwylee.com.au/health-funds.html)
Have you had your eyes tested recently?
Make an appointment on our website to see one of our optometrists today.
[Book an eye test](https://www.oscarwylee.com.au/booking)