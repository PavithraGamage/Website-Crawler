# Source: https://www.oscarwylee.com.au/eye-care/eye-conditions/glaucoma

# Glaucoma - Definition, Types, Symptoms, Treatment
Glaucoma is a group of eye problems that can cause irreversible vision loss, caused by damage to the optic nerve. It is the world’s leading cause of blindness and often has no symptoms to begin with, which makes regular eye tests crucial for diagnosis and early detection. Keep reading to learn more about glaucoma and how it is treated.
## What is glaucoma?
According to Glaucoma Australia, 300,000 Australians are affected by glaucoma and 50% of people with glaucoma don’t know they have it. This eye disease causes a loss of peripheral vision (visual field loss) through damage to the optic nerve, resulting from issues with the eye’s intraocular fluid drainage system. It can eventually lead to complete vision loss and it can occur in either one eye or both eyes.
Source: Glaucoma Australia
## Due for an eye check-up?
Stay on top of your eye health by booking regular eye tests. Our Oscar Wylee optometrists perform bulk billed eye tests with no gap or out-of-pocket expenses for eligible Medicare cardholders.
[Book an eye test](https://www.oscarwylee.com.au/booking)
## What causes glaucoma?
Glaucoma is caused by damage to the optic nerve which is often associated with high eye pressure. There are certain risk factors that can make a person more likely to develop glaucoma. Common risk factors of glaucoma are listed below.
* Older age
* Family history of glaucoma, especially siblings
* Thin corneas
* Corticosteroid medication
* Ethnicity
* Are near or far sighted
* Has had an eye injury or operation
* Diabetes
## What are the symptoms of glaucoma?
For most people, there are usually no symptoms at all for glaucoma which makes early detection quite difficult, that is why regular eye tests are extremely important in taking care of your eye health. In advanced, severe glaucoma, tunnel vision can occur which results in misjudging or missing objects off to the side as well as mobility issues. In acute angle closure glaucoma, symptoms include pain, red eyes, headaches, blurry vision, halos around lights and nausea.
### What is the first sign of glaucoma?
The first sign of glaucoma is the loss of peripheral vision, which is what you can see out of the sides of your vision. Other signs include seeing halos, developed sensitivity to light or sudden vision loss.There are many other common eye conditions such as [hay fever](https://www.oscarwylee.com.au/eye-care/eye-conditions/hay-fever) that can affect a person’s vision. Read more about hay fever and it’s symptoms.
## What is the treatment for glaucoma?
Glaucoma can be treated in four main ways, anti-glaucoma medication, prescription eye drops, laser treatment and surgery. The benefits of these treatments are listed below.
* Anti-glaucoma medication - Includes tablets and eye drops and can be used to treat open-angle glaucoma, although effectiveness can reduce over time.
* Prescription eye drops - A common treatment that prevents optic nerve damage by lowering eye pressure.
* Laser treatment - Laser can be used to make the fluid in the eye flow more effectively, reducing pressure on the optic nerve.
* Surgery - May be suggested if the previous methods, laser and medication, are not effective for the patient. It is also a treatment for more advanced or aggressive glaucoma.
Source: Glaucoma Australia
## How to detect/test glaucoma?
It is thought that 50% of people with glaucoma don’t know that they have it, so having regular eye examinations is important for early detection. Your optometrist can perform the following tests to assess for glaucoma:
* Eye pressure test:  Conducted during pretesting with an NCT (non-contact tonometer).
* Eye health check: Includes an assessment of your optic nerve.
* Visual field test: Your vision is mapped with a visual field machine, checking periphery vision.
If your optometrist suspects that you have glaucoma, you will be referred to an ophthalmologist for treatment.
### How to prevent glaucoma?
While glaucoma is not preventable, there are certain measures you can take to stop the damage and protect your vision, diminishing its effects. These include getting regular eye test as early detection for glaucoma is extremely important, wearing eye protection, especially when using power tools, and being aware of your family history as glaucoma can run in the family.
Source: Mayo Clinic
## The different types of glaucoma
* Open angle glaucoma: Is most commonly seen and makes up 90% of cases. It is usually slowly progressive, caused by a blockage in the eye’s intraocular fluid drainage system resulting in elevated eye pressure.
* Acute angle closure glaucoma: A sudden narrowing of the eye’s intraocular fluid drainage system causes a build-up of eye pressure. It needs urgent treatment as there is a high risk of vision loss
* Normal tension glaucoma: Eye pressure is normal, but optic nerve damage is still observed.
* Congenital glaucoma: Is rare, present at birth and early childhood, and due to the incomplete development of the eye’s intraocular fluid drainage system. It is often associated with other medical conditions.
* Traumatic glaucoma: Develops due to a direct injury to the eye which causes glaucoma.
* Secondary glaucoma: Occurs when another problem or disorder in the eye causes glaucoma, includes surgery, injury or other ocular diseases.
* Pseudo-Exfoliation: Caused by the deposition of pigment granules and white flakes in the eye which interferes with the drainage of fluid in the eye, causing increased eye pressure.
* Uveitic glaucoma: A term used to describe inflammation within the eye which can cause glaucoma.
Source: Glaucoma Australia
## How fast does glaucoma progress?
The rate at which glaucoma progress is different for everyone and can depend on many factors. For untreated glaucoma, it can potentially cause blindness within several years.
## Frequently asked questions about glaucoma
### Can you have glaucoma without going blind?
Yes, if glaucoma is caught early by an eye care professional, it doesn’t have to lead to blindness. There are also factors outside of your control that determine how quickly or if blindness occurs.
### Can you have high eye pressure and not have glaucoma?
Yes, glaucoma is not always caused by high eye pressure. Even people with normal eye pressure can still develop glaucoma. Eye pressure can also vary from person to person, someone’s normal eye pressure could be high for another.
### Is glaucoma hereditary?
Yes, glaucoma is hereditary. While you can still develop glaucoma without a family history, according to Glaucoma Australia, you are ten times more likely to develop glaucoma if a direct member of your family has this eye disease. You also have an almost 1 in 4 chance of developing glaucoma if you have first-degree relatives with glaucoma.
### Is glaucoma curable?
No, unfortunately, there is no cure for glaucoma. While glaucoma cannot be cured, there are still ways you can manage this disease such as with medication or surgery.
## Find your nearest location
Visit our friendly staff in-store and they can assist you with all your optometry and glasses needs.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
## Are you in need of an eye test?
We recommend everyone has a complete eye examination at least once every two years. Book yours today with Oscar Wylee.
[Book an eye test](https://www.oscarwylee.com.au/booking)