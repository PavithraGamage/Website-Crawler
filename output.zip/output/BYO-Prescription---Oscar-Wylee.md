# Source: https://www.oscarwylee.com.au/byo-prescription

# BYO Prescription at Oscar Wylee
Loving our selection of frames but had your eyes tested somewhere else? No problem! We accept all valid optical prescriptions at our stores. It’s easy to get your prescription. Simply call the optometrist who provided the prescription and they can email you a copy. Ordering glasses online? We make it easy at Oscar Wylee with three different options. You can either email us your prescription after checkout, we can call your optometrist for you, or upload a photo of your prescription.
Email us your prescription after checkout
We can call your optometrist for you
Upload a picture of your prescription
At Oscar Wylee, we do not accept expired prescriptions so make sure yours is in date! We also do not offer warranty coverage for incorrect outside prescriptions. If you need a new prescription, we can easily book you in for an eye test with one of our skilled and friendly optometrists.
Outside Prescriptions Welcome!
Find a store near you and bring your valid prescription to order a new pair of glasses on the same day.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
Expired Prescription? No Stress!
With an optometrist in every Oscar Wylee store, you can receive a Medicare bulk billed eye test for a new prescription.
[Book an eye test](https://www.oscarwylee.com.au/booking)