# Source: https://www.oscarwylee.com.au/glasses/nose-bridge-types

# Nose Bridge Types for Glasses and Sunglasses
Published on July 28th, 2025
Updated on August 23rd, 2024  
Australia
Australia
New Zealand
Canada
Canadian French

A nose bridge for glasses and sunglasses refers to the piece of the glasses that sits across the top of the nose, helping the glasses stay in place on the face. There is a range of different nose bridge types for glasses and sunglasses, including a keyhole nose bridge, saddle nose bridge, double nose bridge, wide nose bridge and narrow nose bridge. Keep reading to learn more about the types of nose bridges for glasses and sunglasses.
* Keyhole Nose Bridge: A keyhole nose bridge refers to a slightly rounded, wider nose bridge, the shape of a keyhole.
* Saddle Nose Bridge: A [saddle nose bridge for glasses and sunglasses](https://www.oscarwylee.com.au/glasses/nose-bridge-types/saddle) sits higher up on the nose and distributes wait evenly.
* Double bridge: [Double bridge glasses](https://www.oscarwylee.com.au/glasses/nose-bridge-types/double-nose-bridge) often refers to an aviator shaped frame, with two bars: one across the nose bridge, and one across the brow.
* Wide Nose Bridge: A wide nose bridge slightly wider than the usual nose bridge fit.
* Narrow Nose Bridge: A narrow nose bridge on glasses frames refers to a bridge that is smaller than normal.
Book an Eye Test With Oscar Wylee Today
Our highly trained optometrists are available to provide bulk billed eye tests to eligible Medicare card holders.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Bridge Definition](#Definition) [Bridge Width](#Width) [Choosing Nose Bridge Fit](#Choosing)
## 1. Keyhole Nose Bridge
A keyhole nose bridge describes a slightly rounded, wider nose bridge fit. A keyhole nose bridge is visually inspired by the keyholes in old fashion doors.
[](https://www.oscarwylee.com.au/humphrey-optical.html)
[Humphrey](https://www.oscarwylee.com.au/humphrey-optical.html)
$169    
Add to Cart
[Shop Humphrey](https://www.oscarwylee.com.au/humphrey-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/humphrey-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/humphrey-optical.html)
[](https://www.oscarwylee.com.au/heba-optical.html)
[Heba](https://www.oscarwylee.com.au/heba-optical.html)
$169    
Add to Cart
[Shop Heba](https://www.oscarwylee.com.au/heba-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/heba-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/heba-optical.html)
[](https://www.oscarwylee.com.au/francis-optical.html)
[Francis](https://www.oscarwylee.com.au/francis-optical.html)
$169    
Add to Cart
[Shop Francis](https://www.oscarwylee.com.au/francis-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/francis-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/francis-optical.html)
## 2. Saddle Nose Bridge
A saddle nose bridge describes a glasses nose bridge that distributes weight on either side of the nose and sits higher up, and is shaped like an upside down U. Saddle nose bridges on glasses are common.
[](https://www.oscarwylee.com.au/serge-optical.html)
[Serge](https://www.oscarwylee.com.au/serge-optical.html)
$169    
Add to Cart
[Shop Serge](https://www.oscarwylee.com.au/serge-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/serge-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/serge-optical.html)
[](https://www.oscarwylee.com.au/jinky-optical.html)
[Jinky](https://www.oscarwylee.com.au/jinky-optical.html)
$169    
Add to Cart
[Shop Jinky](https://www.oscarwylee.com.au/jinky-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/jinky-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/jinky-optical.html)
[](https://www.oscarwylee.com.au/byron-optical.html)
[Byron](https://www.oscarwylee.com.au/byron-optical.html)
$169    
Add to Cart
[Shop Byron](https://www.oscarwylee.com.au/byron-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/byron-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/byron-optical.html)
## 3. Double Bridge
A double bridge on glasses usually refers to an aviator frame. Double nose bridges on glasses will refer to two parallel horizontal bars above the nose bridge, connecting the lenses.
[](https://www.oscarwylee.com.au/duckworth-optical.html)
[Duckworth](https://www.oscarwylee.com.au/duckworth-optical.html)
$169    
Add to Cart
[Shop Duckworth](https://www.oscarwylee.com.au/duckworth-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/duckworth-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/duckworth-optical.html)
[](https://www.oscarwylee.com.au/atomix-optical.html)
[Atomix](https://www.oscarwylee.com.au/atomix-optical.html)
$169    
Add to Cart
[Shop Atomix](https://www.oscarwylee.com.au/atomix-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/atomix-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/atomix-optical.html)
[](https://www.oscarwylee.com.au/dusty-optical.html)
[Dusty](https://www.oscarwylee.com.au/dusty-optical.html)
$169    
Add to Cart
[Shop Dusty](https://www.oscarwylee.com.au/dusty-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/dusty-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/dusty-optical.html)
## 4. Wide Nose Bridge
A wide nose bridge on glasses is slightly wider than the usual nose bridge fit, accommodating those with a broader space across the top of the nose.
[](https://www.oscarwylee.com.au/harris-optical.html)
[Harris](https://www.oscarwylee.com.au/harris-optical.html)
$169    
Add to Cart
[Shop Harris](https://www.oscarwylee.com.au/harris-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/harris-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/harris-optical.html)
[](https://www.oscarwylee.com.au/billy-optical.html)
[Billy](https://www.oscarwylee.com.au/billy-optical.html)
$169    
Add to Cart
[Shop Billy](https://www.oscarwylee.com.au/billy-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/billy-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/billy-optical.html)
Visit a Store Near You
Come in and see our friendly staff for all your optical and eyewear needs
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
## 5. Narrow Nose Bridge
A narrow nose bridge on glasses refers to a bridge that is smaller than normal to accommodate those with a smaller or narrower nose bridge.
[](https://www.oscarwylee.com.au/frieda-optical.html)
[Frieda](https://www.oscarwylee.com.au/frieda-optical.html)
$169    
Add to Cart
[Shop Frieda](https://www.oscarwylee.com.au/frieda-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/frieda-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/frieda-optical.html)
[](https://www.oscarwylee.com.au/amanda-optical.html)
[Amanda](https://www.oscarwylee.com.au/amanda-optical.html)
$169    
Add to Cart
[Shop Amanda](https://www.oscarwylee.com.au/amanda-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/amanda-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/amanda-optical.html)
[](https://www.oscarwylee.com.au/parker-optical.html)
[Parker](https://www.oscarwylee.com.au/parker-optical.html)
$169    
Add to Cart
[Shop Parker](https://www.oscarwylee.com.au/parker-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/parker-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/parker-optical.html)
### What Is The Bridge of Glasses?
The bridge of a glasses frame refers to the piece of the glasses that sits over the nose. There are a variety of different glasses bridges to suit different noses. Picking the correct one ensures a secure and comfortable fit. In addition to different types of nose bridges such as keyhole, saddle and double nose bridge, there are also [nose pads for glasses](https://www.oscarwylee.com.au/glasses/nose-pad), for a secure and comfortable fit.
### What is Bridge Width On Glasses?
Bridge width on glasses refers to how wide the bridge of the glasses are. Glasses bridges are can come in several widths including narrow for smaller or narrower nose bridges, normal for standard size nose bridges, or wide nose bridges. The second number printed on the inner side of a frame temples is the bridge width. Read the [Parts of Glasses: A Guide to the Anatomy of Glasses](https://www.oscarwylee.com.au/glasses/eye/part-of-glasses) for more information on the construction of optical glasses.
### Does The Bridge Width On The Glasses' Frame Matter?
Yes, the bridge width on glasses frames matters, as a person will need to choose a bridge width that suits their nose size and [nose shape](https://www.oscarwylee.com.au/glasses/nose-types). If a person chooses a nose bridge that is not correct, they risk glasses being too big and sliding down the nose. If the bridge is too narrow the frames sit too high on the nose. There are also low and [high bridge fit glasses and sunglasses](https://www.oscarwylee.com.au/glasses/nose-bridge-types/high-nose) to accommodate further nose bridge needs.
### How does The Double Bridge Design Affect Glasses Fit and Style?
The double bridge design does not typically affect glasses fit and style, as the second bar is for aesthetic purposes. The double bridge design frame has two parallel horizontal bars connecting the lenses above the nose bridge, rather than the typical single bridge present in glasses. Double bridge designed glasses stylistically provide a retro statement and are commonly found in aviator glasses.
ReadNose Bridge Types for Glasses and Sunglasses in other Oscar Wylee regions and their languages.
Australia
Australia
New Zealand
Canada
Canadian French
 
Are you due for an eye test?
At Oscar Wylee we offer bulk billed eye tests for eligible medicare card holders.
[Book an eye test](https://www.oscarwylee.com.au/booking)
Major Health Funds Accepted In-store
For the purchase of frames and lenses, use your private health fund insurance to minimise how much you pay from your own pocket.
[Explore Health Funds](https://www.oscarwylee.com.au/health-funds.html)