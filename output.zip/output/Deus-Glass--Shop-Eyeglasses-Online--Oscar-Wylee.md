# Source: https://www.oscarwylee.com.au/deus-optical.html

# Deus
1
## Frame Design of Deus Glasses
The frame design of Oscar Wylee’s Deus glasses is characterised by their aviator shape, adjustable nose pads, and an ultra-light stainless steel frame. Deus is a unisex, statement glasses frame that will complement any outfit, day to night.
$169    
In stock
Only %1 left
2 pairs from $199
Discount auto-applied at checkout
3 pairs from $249
Discount auto-applied at checkout
Qty
Add to cart
Book an eye test
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
excluding prescription lenses
## About Deus Frames
Besides their classic appeal, aviators are a must-have in anyone’s glasses collection. A true Oscar Wylee vintage signature, Deus is designed for those who seek an easy-to-wear frame with a vibrant style.
| Frame fit | Measurements |
| --- | --- |
| WIDE | 59 - 14 - 140 |
These measurements mean lens width, bridge, and temple length in millimetres (mm). They can be found on the inside of the temple arm. If you already have a pair that you like, you can compare it to these measurements.
### Made from Stainless Steel and Acetate
Oscar Wylee’s Deus frame is a unisex aviator glasses frame that is perfect for those with heart, oval, or pear face shapes. The Deus frame is a stylish, widely wearable frame that can be worn every day. The main specs of Oscar Wylee’s Deus glasses frame, including dimensions, shape, materials, lenses, nose fit, and hinges, are listed below.
| Deus Frame Features | Deus Frame Description | Dimensions | Shape | Materials | Lenses | Nose Fit | Hinges |
| --- | --- | --- | --- | --- | --- | --- | --- |
| The dimensions of the Deus frame are measured in millimetres (mm) and are 59 - 14 - 140, meaning the lens width is 59 mm, the bridge is 14mm, and the temple length is 140 mm. |
| Deus is an aviator shape, well-suited to wide faces. |
| Deus is made from stainless steel and acetate. |
| The lenses that can be used in the Deus frame include optical lenses, such as single-vision and multifocal, and non-prescription lenses, which are plain and can have a filter, such as a blue-light filter applied. Deus also comes as sunglasses. |
| The nose fit for Deus is characterised by adjustable nose pads. |
| The hinges in Deus are normal hinges, also known as standard or barrel hinges. |
Show All
### What Inspired the Frame Design of Oscar Wylee’s Deus Glasses?
The Oscar Wylee Deus frame design was inspired by current fashion trends, as aviator glasses are a timeless style.
## What to Know About Oscar Wylee’s Deus Glasses?
There are many aspects of the Oscar Wylee Deus frames that customers should know about to decide whether this is the right frame for them. The Deus frame is a unisex aviator-shaped frame. Oscar Wylee’s Deus frame is suitable for many face shapes, but particularly compatible with heart, oval, and pear face shapes. The Deus frame’s classic design makes it fashionable all year round. Deus features the standard [parts of glasses](https://www.oscarwylee.com.au/glasses/eye/part-of-glasses), such as a rim, temples, lenses, normal hinges, and adjustable nose pads.
### What are the Types of Temple Tips or Earpieces Included with Oscar Wylee’s Deus Glasses?
The type of temple tips or earpieces included in Oscar Wylee’s Deus Glasses are made from acetate.
### What Type of Nose Bridge do Oscar Wylee’s Deus Glasses Have?
The type of nose bridge included in Oscar Wylee’s Deus frame is characterised by adjustable nose pads.
### What Type of Nose Pads are Included with Oscar Wylee’s Deus Glasses?
Oscar Wylee’s Deus frame includes adjustable nose pads for an optimal fit for many faces.
### What Type of Lenses do Oscar Wylee’s Deus Glasses Have?
The type of lenses that typically come with the Oscar Wylee Deus [glasses frame](https://www.oscarwylee.com.au/glasses.html) are optical lenses. Optical lenses are glasses lenses that have a prescription within the lens to help correct vision issues such as myopia, hyperopia, and astigmatism. Deus frames also come as sunglasses, and with non-prescription lenses and add-ons such as a blue-light filter.
### What Material is Used for the Rim of Oscar Wylee’s Deus Glasses?
The material used for the rim of Oscar Wylee’s Deus glasses frames is stainless steel. The rim refers to the part of a glasses frame that holds the lenses.
### What Type of Hinges are Included with Oscar Wylee’s Deus Glasses?
The type of hinges included with Oscar Wylee’s Deus frames are normal hinges, also known as standard or barrel hinges. These provide strength and smooth movement connecting the frame's arms and lenses.
## What Face Types are Most Suitable for Oscar Wylee’s Deus Glasses?
The face types that are most suitable for Oscar Wylee’s Deus frame are heart, oval, and pear face types. The Deus frame is an aviator shape, meaning that it complements the structure of heart, oval and pear faces particularly well. The aviator Deus frames help balance the features of [square face shapes](https://www.oscarwylee.com.au/glasses/face-shapes/square), [oval face shapes](https://www.oscarwylee.com.au/glasses/face-shapes/oval) and [pear face shapes](https://www.oscarwylee.com.au/glasses/face-shapes/pear), bringing the eyes and brows forward in a flattering way. Although there are many [glasses for face shapes](https://www.oscarwylee.com.au/glasses/face-shapes) that may be considered more aesthetically suitable, it is important that people also choose frames that make them feel most comfortable and represent their personal style.
## What Size Options are Available for Oscar Wylee’s Deus Glasses?
The size option available for Oscar Wylee’s Deus frame is a wide fit frame.
## What Materials are Used to Create Oscar Wylee’s Deus Glasses?
The primary material used to create the Oscar Wylee Deus frame is stainless steel. The rim, nose bridge and temples are made from stainless steel. The temple tips are made from acetate. Stainless steel is a durable iron-based alloy.
## What’s Included
## What's&nbsp;Included
Each pair of glasses comes with a stylish frame case and lens cloth. We offer free shipping across Australia and 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects.
* Free Shipping for Australian Orders
* 1 Year Warranty on frames and lenses
* Scratch resistance lens coating on all prescriptions
* UV-proof coating on all prescriptions
* Stylish case and cloth
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
## Make and Materials
The frames then go through cleaning and strict quality control, and many pairs of crafting hands to be hand-assembled and polished. After your frames have gone through the production process, they are individually examined and packed before making their way to you!As part of our durable frame family, some of our most popular styles, are now in stainless steel. These frames are hypoallergenic, corrosion resistant, light weight, and not sensitive to temperature changes.
## Warranty Information
### Warranty Information
### Warranty Information
Oscar Wylee provides a 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects. 
We will repair or replace faulty or defective frames or lenses free of charge for warranty claims made within 1 year of the delivery.
We also offer repairs or replacement for problems experienced with vision during everyday use for claims made within 30 days of delivery. If the same product has been discontinued or is no longer available, then we may offer an exchange for a similar product or a refund.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Find a Store Location](https://www.oscarwylee.com.au/locations/full-store-list.html)
Recommended
1. [](https://www.oscarwylee.com.au/taku-optical.html)
[Taku](https://www.oscarwylee.com.au/taku-optical.html)
Gold