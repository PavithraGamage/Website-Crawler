# Source: https://www.oscarwylee.com.au/glasses/eye/reading-in-the-dark-bad

# Is Reading in The Dark Bad for Your Eyes? Risk and Protection
Published on September 10th, 2024
Updated on August 20th, 2024 
Reading in the dark is often believed to cause damage to the eyes, however,
this may not be the case.
Many late-night readers may wonder if it is bad to read in the dark.
While it can lead to eye strain, reading in the dark does not lead to
long-term eye damage. According to Zeiss, reading in the dark won’t affect long-term eye health
due to the nature of how the eye functions. The photoreceptor cell in the
eye, known as a rod cell, helps the eyes to see in low-light conditions.
When the eyes are exposed to darkness, the pupils widen to allow more light
in. After some time in either low-light conditions or darkness, the eyes are
able to adjust as a result of dark adaptation. Dark adaptation is the
process in which the retina adapts to the minimal levels of light which
involves a change between cone and rod activity according to Science Direct.
Experiencing Any Changes to Your Vision?
Book an eye test at Oscar Wylee for quality eye care and eye test services
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Risks](#Risks)
[Protection](#Protection)
[Common Myths](#Common-Myths)
[Permanent Damage](#Permanent-Damage)
## Is Reading in the Dark Bad for Your Eyes?
Yes, reading in the dark is bad for your eyes since
it can lead to eye strain. Eye strain can occur during or after
reading in the dark as it forces the pupil to widen, allowing as much
light in as possible. Photoreceptor cells in the retina known as rod cells enable vision
when in low-light conditions. Rods are able to work effectively in low
light while the other type of photoreceptor known as cone cells work
better in more light. While eye strain can be unpleasant, it won’t
likely cause permanent damage to your eyes and may only require taking a
rest from near-vision activities.
## What are the Risks of Reading in Low Light?
The risks of reading in low light are
eye strain, headaches, dry eyes, blurred vision, neck and shoulder
pain, reduced reading efficiency and increased fatigue. The potential risks of reading in low light are listed below.
* Eye Strain:  Eye strain is defined as
an eye condition that can lead to symptoms such as eye redness, watery
eyes, dry eyes, irritation and tired or aching eyelids.
* Headaches:  Headaches are a possible
risk of reading in low light and essentially develop from eye strain.
* Dry Eyes: 
Dry eyes can be a common risk of reading in low-light due to a
decreased blinking rate when performing near-vision required tasks.
* Blurred Vision: 
Blurred vision can occur as a result of the eye muscles exerting more
effort and causing strain on the eyes.
* Neck and Shoulder Pain: 
Neck and shoulder pain may arise from sitting in awkward positions for
long periods when trying to read text better.
* Increased Fatigue: 
Increased fatigue is another possible risk of reading in low-light
that can occur in the eyes and can often feel like heavy eyelids and
dry eyes.
### 1. Eye Strain
Eye strain occurs as
a result of concentrating on certain activities for long periods
such as reading, driving and digital screen time. Symptoms of
[eye strain](https://www.oscarwylee.com.au/glasses/eye/strain)
include redness, watery eyes, irritation, tired or aching eyelids,
blurred vision and a mild headache according to John Hopkins Medicine.
When reading in low-light or in the dark, the eye muscles exert more
effort to make out the words and therefore can be strenuous on the
eyes.
### 2. Headaches
Headaches are characterised as pain felt around the head or in certain
areas of the head and may be a risk of reading in low-light
conditions.
Headaches are a common consequence of reading in low light but can
initially stem from developing eye strain. Headaches can occur from eye strain due to fatigued eye muscles and
irritation. However, taking a break in between and blinking regularly
may provide some relief.
### 3. Dry Eyes
Dry eyes can also be
a risk of reading in low light due to blinking less and focusing
more on the text. The reduced rate of blinking can lead to having less moisture on
the eye's surface, causing
[dryness in the eyes](https://www.oscarwylee.com.au/glasses/eye/dry-eyes)
and discomfort. According to a 2017 study published in the National
Library of Medicine, when carrying out near-vision tasks, individuals
typically blink less. Therefore dry eyes are a common risk of reading
in low light.
### 4. Blurred Vision
Blurred vision may occur from reading in low light as
a result of putting more strain on the eyes when reading text under
insufficient light.
[Blurred vision](https://www.oscarwylee.com.au/glasses/eye/blurred-vision)
can be described as vision that lacks clarity, sharpness and detail.
However, blurred vision while reading text up close may be an
indication of an underlying eye condition. It may be helpful to see an
optometrist to ensure symptoms are not caused by a more complex eye
condition.
### 5. Neck and Shoulder Pain
Neck and shoulder pain may develop when reading in low-light
conditions
as individuals may sit or lie in awkward positions to read text
better. Neck and shoulder pain may last longer than other symptoms,
however, they may be prevented by taking regular breaks to move around
or even move to a different position when reading.
### 6. Increased Fatigue
Increased fatigue
may be experienced in the eyes while reading in low light and is
also a symptom of eye strain. Increased
[eye fatigue](https://www.oscarwylee.com.au/glasses/eye/fatigue-definition)
may result in the feeling of heavy eyelids and dry eyes.
## How Can You Protect Your Eyes While Reading in Dim Light?
You can protect your eyes while reading in dim light by following these
steps;
use a reading light, take regular breaks, adjust text size, maintain
good posture, blink frequently and use proper glasses. The ways to protect your eyes while reading in dim light are listed
below.
* Use a Reading Light:  Use a reading
light to ensure more room lighting when reading in dim light, to
prevent your eyes from having to exert more effort.
* Take Regular Breaks:  Take regular
breaks when reading in dim light to give your eyes rest.
* Adjust Text Size: 
Adjust text size if you are reading from your smartphone, computer or
laptop to avoid having to read small text.
* Maintain Good Posture: 
Maintain good posture to prevent neck and shoulder pain and ensure you
move to different positions after some time.
* Blink Frequently: 
Blink frequently to maintain moisture in your eyes, which can help
prevent dry eyes.
* Use Proper Glasses: 
Use proper glasses such as your prescription reading glasses or blue
light filter glasses if you are reading from a device.
### 1. Use a Reading Light
Use a reading light when reading in dim light
to minimise overexertion of the eyes. Using a reading light can
help ensure more room lighting and prevent the pupils from having to
widen. The pupils control how much light enters the eye by increasing or
decreasing in size and can therefore tire out when they remain exposed
to dim light or darkness or overly bright light for too long. Position
the light correctly so it directly hits the page of your book and if
you are reading from your device, place the light so that it brightens
more of the room.
### 2. Take Regular Breaks
Take regular breaks while reading
in dim light to give your eyes a chance to rest. When performing
tasks that require near-vision and concentration, the eyes can
easily become fatigued and strained. It is typically recommended to follow the 20-20-20 rule, which is
an exercise that involves taking a 20-second break, every 20 minutes
to look at something 20 feet away (6 metres).
### 3. Adjust Text Size
Adjust text size so that the words are bigger if you are reading from
your device
to help prevent the eye muscles from having to focus on small
text. Adjusting the text size when reading from your smartphone, laptop
or computer may be helpful in reducing the need for your pupils to
widen and avoid strain. You can go to the display or font/text tab in
the settings menu of most devices and adjust text size according to
your preferences.
### 4. Maintain Good Posture
Maintain good posture when reading in dim light to
avoid hurting your neck, shoulder or back. Sitting or lying still
in awkward positions can also lead to the development of knots in
the muscles
according to Kett (2021) in the National Institutes of Health. It is
important to move around or move to a different position every now and
then to prevent muscle pains and stiffness.
### 5. Blink Frequently
Blink frequently
to maintain moisture in the eyes when reading in dim light.
Blinking helps to protect the eyes from debris and irritants and
helps maintain comfort
according to the Cleveland Clinic. Performing near-vision tasks
typically leads to decreased blinking according to Abushara (2017),
which can cause dry or irritated eyes.
### 6. Use Proper Glasses
Use proper glasses when reading in dim light for clear vision or blue
light protection.
Using prescription glasses or blue light filter glasses may improve
how well you can read the text and prevent disrupted sleep later. If you usually use reading glasses then it may be best to continue
wearing them when reading in dim light.
### What are Some Common Myths About Reading in the Dark?
A common myth about reading in the dark can include
damaged eyesight. It is common to believe the myth that reading in
the dark causes damage to your eyesight as it causes strain on the
eyes. However, this may not be the case as the eyes can rest and recover
when taking a break according to Zeiss.
Looking For Your Next Pair of Glasses?
Find your nearest Oscar Wylee store and our friendly staff can assist
you.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
#### Does Reading in the Dark Cause Permanent Eye Damage?
No, reading in the dark does not cause permanent eye damage.
Reading in the dark can lead to eye strain, however, as the eyes
can adjust to limited levels of light, they can also easily adjust back to normal in sufficient
lighting. Eye strain is unpleasant and a common
[eye problem](https://www.oscarwylee.com.au/glasses/eye/common-problems), therefore, it is important to give your eyes regular rest and
minimise the frequency of reading in the dark.
#### Are There Any Benefits to Reading in Low Light?
No, there are no benefits to reading in low light.
Reading in low light causes the pupils of the eyes to increase in
size in order to allow as much light in as possible to see text
better. This can cause the eyes to tire out and develop fatigue and
discomfort.
#### Does Reading in the Dark Hurt Your Eyes
Yes, reading in the dark can hurt your eyes
as they need to exert more effort to be able to read the words in
poor lighting. The eye muscles can become tired and irritated
resulting in eye strain. However, any pain or discomfort can be
alleviated when stopping to take a break.
#### Can Glasses Help You Read in the Dark?
No, glasses do not help you read in the dark.
Glasses help to provide clear vision, however, you will need to
use a lamp or attachable book light to help you read in the
dark. If you normally use
[prescription glasses](https://www.oscarwylee.com.au/glasses.html)
for reading due to being farsighted, it is important to use your
glasses to prevent causing strain on the eyes.
Renew Your Prescription
Don’t let your eye health get away from you. Renew your glasses
prescription with our optometrist at Oscar Wylee today.
[Book an eye test](https://www.oscarwylee.com.au/booking)
Get a Full Quote in Store
Get fitted for your multifocal glasses at Oscar Wylee by visiting us
in-store and talk to our friendly staff for a complete quote.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)