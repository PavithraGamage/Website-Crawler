# Source: https://www.oscarwylee.com.au/free-eye-test

# Free Eye Test at Oscar Wylee
Published on August 30th, 2024
Updated on August 20th, 2024 
At Oscar Wylee Australia,
eye tests are not free, they are bulk-billed, meaning there will be no
out-of-pocket payment for eligible Medicare cardholders. Medicare bulk billing refers to a process in which healthcare providers
bill Medicare, Australia’s universal healthcare system, for an eye test and
not the customer. At Oscar Wylee you can book a Medicare bulk billed eye
test by calling your local store, booking online, or visiting our team
in-store and asking about availabilities. Oscar Wylee does not charge for
additional testing such as general visual field testing for eligible
medicare card holders. An eye test is a hugely important procedure as it
allows an optometrist to assess your eye health and diagnose any eye
conditions. It is recommended a person under 65 gets an eye test once every
2 years, or as otherwise advised by an optometrist. For those over 65, it is
recommended that they get an eye test once a year. However, some symptoms
indicate a person should get an eye test outside of this recommendation
including blurry vision, double vision, trouble with peripheral vision, eye
floaters, halos around lights, cloudy vision, flashes of lights, difficulty
seeing distant objects and trouble reading up close. Keep reading to learn
more about free eye testing at Oscar Wylee.
Are you Due for an Eye Test?
Book a Medicare bulk billed eye test with our in-store Oscar Wylee
optometrists and stay on top of your eye health.
[Eye test near me](https://www.oscarwylee.com.au/booking)
[Definition](#Definition) [Eligibility](#Eligibility)
[How to Book](#How-to-Book) [Symptoms](#Symptoms)
[What to expect](#What-to-expect)
## What Does a Free Eye Test at Oscar Wylee Mean?
Eye tests at Oscar Wylee Australia are
not technically free, as they are bulk-billed under Medicare.
Bulk billing means that the customer does not pay any out-of-pocket
expenses on the day, if they have an eligible Medicare card. Eye tests
are not technically free, as Medicare is still paying for the eye test.
Medicare bulk billed eye tests cover general eye tests with our
optometrist, and will not cover eye tests to assess sight for driving.
### What is Medicare Bulk Billing?
Medicare bulk billing refers to
a process in which healthcare providers bill Medicare, Australia’s
universal healthcare system, instead of the customer, meaning they do not have to pay for their health service.
### Who is Eligible for a Medicare Bulk Billed Eye Test?
Those
with a valid Medicare card are eligible for a bulk billed eye test
at Oscar Wylee. Those who do not have a valid Medicare card will need to pay for
their eye test at Oscar Wylee which will be $70.
### How Often Can You Get a Free Eye Test?
Oscar Wylee does not provide free eye tests, however some optometry
businesses may. Under the current Medicare scheme, those with an
eligible Medicare card can get
one bulk billed eye test every three years if they are under 65. Those over 65 can get one bulk billed eye test every year.
### How to Book a Free Eye Test?
At Oscar Wylee you
can book a Medicare bulk billed eye test by calling your local
store, booking online, or visiting our team in-store and asking
about availabilities. To
[book an eye test online](https://www.oscarwylee.com.au/booking), go to the Oscar Wylee website and click the book an eye test
button, located at the top right of the screen, in the bottom menu or
various places on the home screen. After clicking book an eye test,
you will be taken to the book an eye test page where you will be asked
to select a location from the list or search your postcode or suburb
for your nearest store. You will then be directed to pick a date and
time at your chosen Oscar Wylee store. You will then be prompted to
fill in your name, contact number and email to confirm your eye test
appointment. To book an eye test over the phone, you can call 1300 164
990. Medicare bulk billed eye tests are not free eye tests.
### What is the Importance of an Eye Test?
An eye test is a
hugely important procedure to have done as it allows an optometrist
to assess the health of your eyes. An eye test will help in the detection of
[common eye problems](https://www.oscarwylee.com.au/glasses/eye/common-problems), monitoring general eye health and vision correction. Eye tests can
also allow an optometrist to identify any signs of serious eye
conditions or eye problems early on, which can help minimise damage
and potential complications.
## What Symptoms Indicate that You Should Get an Eye Test?
There are several symptoms that indicate a person should book in to get
an eye test, including
blurry vision, double vision, trouble with peripheral vision, eye
floaters, halos around lights, cloudy vision, flashes of lights,
difficulty seeing distant objects and trouble reading up close. In general, a person should get an eye test once every two years if
they are under 65 unless otherwise advised by an optometrist. If you are
over 65, it is recommended that you have an eye test once a year. Some
eye conditions do not show symptoms until the condition has progressed,
so it is important to get an eye test regardless of if you have the
symptoms below. The symptoms that may indicate that a person needs an
eye test are listed below.
* Blurry or Cloudy Vision:  Blurry or
cloudy vision refers to vision that is not sharp or clear and can be
caused by a variety of eye conditions and diseases including
refractive errors and glaucoma.
* Double vision:  Double vision refers
to seeing two different or overlapping images of the same objects.
Double vision can be caused by eye conditions, nerve-related problems
and brain-related conditions.
* Trouble with peripheral vision: 
Trouble with peripheral vision often refers to tunnel vision, in which
a person cannot see objects properly unless they are directly in front
of them.
* Eye Floaters:  Eye floaters refer to
spots or lines in a person’s vision caused by changes to the vitreous
inside the eye.
* Halos Around Lights:  Halos around
light refers to a person seeing circles of rings around light sources
and can be caused by eye conditions that affect the cornea.
* Flashes of Light:  Flashes of light
refer to a person seeing flashes of light or streaks of light across
their vision, usually caused by the vitreous gel pulling against the
retina.
* Difficulty Seeing Distant Objects: 
Difficulty seeing distant objects is generally a symptom of the
refractive error myopia or nearsightedness.
* Trouble Reading Up Close: Trouble
reading up close is generally a symptom of hyperopia or
farsightedness. Trouble reading up close is also a symptom of the
age-related condition presbyopia.
### 1. Blurry or Cloudy Vision
Blurry or cloudy vision
refers to vision that is not sharp or clear.
[Blurry vision](https://www.oscarwylee.com.au/glasses/eye/blurred-vision)
or cloudy vision can be caused by a variety of eye conditions
including refractive errors such as
[astigmatism](https://www.oscarwylee.com.au/glasses/eye/astigmatism),
[cataracts](https://www.oscarwylee.com.au/glasses/eye/cataracts#symptoms), dry eyes,
[glaucoma](https://www.oscarwylee.com.au/glasses/eye/glaucoma#symptoms)
or an eye injury. If you have noticed your vision getting blurrier, it
is important to see an optometrist for an eye test. If blurry vision
occurs suddenly, with other symptoms such as eye pain, dizziness, loss
of balance or slurred speech, seek medical help as soon as possible.
### 2. Double vision
Double vision, also known as diplopia,
refers to an eye condition in which a person sees two different or
overlapping images of the same object.
[Double vision](https://www.oscarwylee.com.au/glasses/eye/double-vision)
can be caused by several things including eye conditions,
nerve-related problems and brain-related conditions. If you have
noticed double vision developing over time, it is important to see an
optometrist to get this assessed. If you have a sudden onset of double
vision, it is important to seek medical help as soon as possible.
### 3. Trouble with Peripheral Vision
Trouble with peripheral vision, or side vision, usually
refers to a person losing peripheral vision. This condition is also
known as tunnel vision. If someone has tunnel vision, it means they struggle to see things
in their periphery. People will struggle to see objects clearly unless
they are right in front of them. Tunnel vision can be caused by
glaucoma, retinitis pigmentosa or optic neuritis. If a person has
started to notice that they cannot see objects in their periphery
well, they should visit an optometrist for an eye test. An optometrist
may use a
[visual field test](https://www.oscarwylee.com.au/visual_field.html)
to assess issues with peripheral vision.
### 4. Eye Floaters
Eye floaters
refer to specks or spots that appear in a person’s vision, due to
changes in the vitreous fluid that fills the eye.
[Eye floaters](https://www.oscarwylee.com.au/glasses/eye/floaters-definition)
can be caused by retinal detachment, eye disease,
[diabetic retinopathy](https://www.oscarwylee.com.au/glasses/eye/diabetic-retinopathy), eye injury, ageing, bleeding in the eye, and migraines. If a person
starts to see eye floaters, they should book an eye test with an
optometrist. Floaters are not always a sign for concern and may become
more common as a person ages.
### 5. Halos Around Lights
Seeing halos around lights is
a condition in which a person may see circles or rings around
lights. Seeing halos around lights can be caused by several eye conditions,
usually those that affect the cornea and how it bends light, according
to Optometrists Network. It is important to get an eye test if a
person sees halos around light, especially if it is accompanied by
pain or blurred vision as this could be a sign of a serious eye
problem, according to Optometrists Network.
### 6. Flashes of Light
Flashes of light
refer to a person seeing flashes of light or streaks of light
across their vision at random. Flashes of light are caused by the vitreous gel inside the eye
rubbing against, or pulling on the retina, according to the University
of Michigan’s Kellog Eye Centre.
[Posterior vitreous detachment (PVD)](https://www.oscarwylee.com.au/glasses/eye/posterior-vitreous-detachment)
is an eye condition that can cause flashes of light, as well as eye
floaters. Flashes of light are not usually a reason to be concerned
and they can become more common as a person ages. However, it is
important to get an eye test if a person notices flashes of light to
ensure there are no issues present.
### 7. Difficulty Seeing Distant Objects
Difficulty seeing distant objects is
generally a symptom of myopia or nearsightedness.
[Myopia](https://www.oscarwylee.com.au/glasses/eye/nearsightedness)
is a refractive error commonly caused by a misshapen eye, which
disrupts the eyes’ ability to bend light properly. Myopia can
generally be corrected by getting prescription glasses or contact
lenses from an optometrist. If a person is having difficulty seeing
distant objects, they should get an eye test with an optometrist so
they can diagnose and correct the error.
### 8. Trouble Reading Up Close
Trouble reading up close
can be a symptom of both hyperopia or farsightedness, as well as
presbyopia.
[Presbyopia](https://www.oscarwylee.com.au/glasses/eye/presbyopia)
is an age-related eye condition in which the eye struggles to focus on
nearby objects, due to changes in the eye's focusing ability as a
person ages.
[Hyperopia](https://www.oscarwylee.com.au/glasses/eye/hyperopia)
or farsightedness is a refractive error, generally caused by a
shortness in the length of the eyeball from front to back, according
to the Cleveland Clinic. Both hyperopia and presbyopia are generally
corrected with prescription glasses or contact lenses. If a person is
having trouble reading up close, or seeing objects up close, they
should have an eye test with an optometrist to get a diagnosis.
Find an Oscar Wylee Store Near You
Come and visit your local Oscar Wylee store where our friendly team
will help you shop our range of stylish and affordable frames, and
assist with your eye care needs.
[Optometrist near me](https://www.oscarwylee.com.au/locations/full-store-list.html)
### Where Can You Get a Free Eye Test?
Oscar Wylee does not provide free eye tests, but some optometry
businesses may. At Oscar Wylee, you
can get a medicare bulk billed eye test at any of our Australian
stores. Visit our store locator page and find your nearest store for an eye
test, with no out-of-pocket expenses for eligible Medicare card
holders.
### What to Expect in an Eye Checkup Test?
With an Oscar Wylee optometrist,
you can
[expect your eye test](https://www.oscarwylee.com.au/glasses/eye/check-up)
to be carried out in a professional, friendly, and time-efficient
manner. At Oscar Wylee, you will first undergo pre-testing with a member of
our staff, before our optometrists take over to conduct the eye test.
The type of tests you can expect to get at Oscar Wylee will depend on
the optometrist and the location, but may include a retinal exam,
visual field test, tonometry test, refraction test, dilated pupil
exam, slit-lamp exam and OCT (optical coherence tomography).
Book an Oscar Wylee Eye Test
We recommend that everyone should have an eye test with an optometrist
at least once every 2 years or as otherwise advised.
[Eye test near me](https://www.oscarwylee.com.au/booking)
Oscar Wylee Accepts Major Health Funds In-store
Visit Oscar Wylee in-store for eye care services and your health fund
may help cover some of the cost.
[Discover Health Funds](https://www.oscarwylee.com.au/health-funds.html)