# Source: https://www.oscarwylee.com.au/locations/optometrist-orange.html

# Optometrist Orange
You may have noticed our Oscar Wylee Orange store has closed, but
your eye care journey with us continues.
You can still visit another Oscar Wylee store for eye health
services, we have your details on file, or browse our latest frames
online. We apologise for any inconvenience and appreciate
your continued support.
Orange Central Square
Shop 35, 227-239 Summer St
Orange NSW
2800

Next to Coffee Club
Opening hours
MondayClosed
Tuesday9:00am - 5:30pm
Wednesday9:00am - 5:30pm
Thursday9:00am - 5:30pm
Friday9:00am - 5:00pm
Saturday9:00am - 4:00pm
SundayClosed
*Store hours reflect local standard trading hours and exclude public
holidays
Visit our Orange Google Business page for directions,
reviews, and updates.

Book Appointment
Our Reviews
Ann Maree Barber
4 months ago
Christine Davies
4 months ago
Fabulous experience at Oscar Wylee I have used a different optometrist in previous time and was appa...lled with the business.  I went and checked OW and was very satisfied with the entire service and would like to thank the young lady that made this a very pleasant experience i think if my memory serves me her name was Kayla
See more
Isabelle Britt
4 months ago
Very positive
Shelby C
4 months ago
The optometrist and staff were very helpful and lovely.
bev press
4 months ago
Sharlene P
5 months ago
Place was awesome. Was able to fit me in for an eye exam on the same day and Dr Vincent was incredib...ly helpful in ensuring that my eye test was thorough and accurate.
See more
Annita Devine
5 months ago
Friendly and professional service. Wonderful with kids!
Tracei Ansdell
5 months ago
All good thanks!
Victoria Godwin
5 months ago
Found my yearly eye health check easy to arrange online ,due to my Diabeties.It was easy to arrange ...on the Oscar Wylee App. Found staff and Optometrist at Orange NSW  very welcoming and extremely knowledgeable and informative. Had to be refrered on for further extensive testing. Needed update on my reading glasses and staff very helpful. Didnt feel pushed in to buying multiple pairs of the same glasses, just ordered fitted correctly. Thank You
See more
Harriette Williams
7 months ago
Good informative eye test/optometrist and great customer service ????
Ella de Cruz
7 months ago
Bec Kennedy
7 months ago
Amazing customer service. Had a broken arm on my glasses on New Years Eve and was promptly helped by... the lovely gentleman on shift. Saved the day! Best after sale service.
See more
julie Riquelme
8 months ago
Justin Gersbach
8 months ago
Very knowledgeable, very fast
Carol Starr
10 months ago
Best customer service, Justin the Manager of the Orange store was amazing.  Thank you
Christine Mas-Fitzell
11 months ago
Jingle Sarmiento
11 months ago
Alix Roots
11 months ago
Leonie Rogers
11 months ago
They were lovely and explained everything. The people who served us were understanding and patient.
...Would go back again.
See more
Sasha Pauline
1 year ago
Vincent the optometrist was an absolute gem! Lots of frames to pick from. Very happy to be a returne...d customer.
See more
Jacqui Schofield
1 year ago
Great!!
Ellie Morrissey
1 year ago
The optometrist here is wonderful!
Samone Vennard
1 year ago
The professionalism and service were amazing.  Very grateful for assistance received.
Elly Haynes
1 year ago
My eye test was quick and efficient.
Rhiannon Smith
1 year ago
Exceptional service and a beautiful range of glasses to choose from.
Rodney Wright
1 year ago
The staff were extremely helpful and service was impeccable.
Sally O’Donnell
1 year ago
The staff were professional, made me feel valued, and treated me with respect. They didn’t pressure ...me into buying anything but provided clear, helpful information so I could make an informed decision.
See more
Vanessa Thompson
1 year ago
Sally Coady
1 year ago
I didn’t take in the names of the lovely man in the ship or the optometrist but they were both incre...dibly kind and helpful.
Makes the eye test experience so much more pleasant.
Plus I got a figurative gold star for the air puff in the eyeball test so I felt like an A student.
See more
Lo Tink
1 year ago
This was my first time at Oscar Wylee, and everything about my appointment was lovely; from being gr...eeted friendly upon walking in, to the help from both the Optometrist &amp; staff. I can't fault them at all. I have found my new Optometrist!
See more
Garry Robinson
1 year ago
Easy to book. Friendly service, staff were very helpful. Glad I switched from previous optometrist.
Amanda Glassop
1 year ago
The whole process was very smooth and thorough. Abigail was very knowledgeable and was not there jus...t to recommend glasses, she gave me a couple of options in my best interests. A very pleasant experience
See more
K
1 year ago
entire experience felt rushed and unhelpful
Margie Barton
1 year ago
Optometrist Alan informative and thorough. His assistant Dakota  lovely gentle nature with clients. ... Just beautiful.  A real credit to your company.
See more
Bec C
1 year ago
The optometrist was very thorough and professional. So many options for sunglasses and frames.
Julie Gordon
1 year ago
Everything was great and staff was very friendly from the minute I walked in the door till the minut...e I walked out and did not take long.
See more
Tony Cavanagh
1 year ago
Very professional and easy to deal with.  Overall good experience.
Anne Wangui
2 years ago
Kathleen Lawson
2 years ago
Dave Beadle
2 years ago
Very good and thorough
Renee Cargill
2 years ago
Fantastic optometrist and lovely staff highly recommend.
Gaz “Big G” S
2 years ago
Professional, pleasant and efficient service !
Anita Rutherford
2 years ago
Both staff members were very helpful. Able to understand my needs. Would highly recommend.
Karen Carfi
2 years ago
Awesome service all round. I would recommend them to everyone. I will definitely go back again.
Allyssia Fisher
2 years ago
The eye test was quick and efficient and the staff were nice and professional. The frame choices wer...e nice and the overall experience was good
See more
Ash Timbs
2 years ago
Great place and lovely staff members. We're so helpful to me throughout the whole appointment and al...so helping choose my glasses
See more
morangos pizzol
2 years ago
Really good experience.
Rajeesh Kurian
2 years ago
Nidhi Vashist
2 years ago
Tessa Barrett
2 years ago
All the staff were lovely! From beginning to end the whole process was fantastic! Super easy and a h...uge range of beautiful glasses to choose from. Couldn't recommend then enough.
See more
## Find an Optometrist in Orange With Oscar Wylee
Come visit our Oscar Wylee Orange store in the thriving country
town of Orange. We are located inside Orange Central Square on Summer Street
and are close to areas such as Glenroi, with only an 8-minute walk from Orange
station. Oscar Wylee Orange offers in-store eye tests for same-day
prescriptions and a variety of different frames and lenses to suit your needs.
Our optometrists in Oscar Wylee Orange are qualified and committed to caring
for your eye care needs; we offer eye health tests to ensure your vision is
healthy along with many other essential optometry services.
Orange is found in the Central Tablelands region of New
South Wales and is famous for its award-winning restaurants, boutique shops,
magnificent gardens, bustling markets and cool climate wines. While in Orange
Central Square, you can explore the large selection of retailers and for the
best parking for Oscar Wylee, use the upper-level parking and enter through
Anson Street. Stop by our Oscar Wylee Orange store to find your perfect pair
of glasses for either prescription sunglasses or glasses from our wide
collection of high-quality eyewear.        
Meet Our Team
Our Services
* Bulk
Billed Eye Examinations
* Professional Frame Styling
* Frame Adjustments and
Repairs
* Visual Fields Testing
* Digital Retinal Scanning
Show All
## Find an Optometrist in Orange, NSW for an Eye Health Test
An optometrist in Orange, NSW is where you can receive excellent
assistance and care for all things optometry. You can make an
appointment at Oscar Wylee Orange here online or in-store to get
an eye health test in Orange, which is important for checking
vision health and signs of any eye diseases. Our team will refer
you to an eye doctor in the area if they do identify any signs
of a more serious condition. We offer eye tests for a bulk
billed price as part of Australia’s Medicare System. Make Oscar
Wylee your go-to for primary eye care services, eyewear
assistance from our optical dispenser and a wide range of
prescription glasses and even prescription sunglasses.
For the average price of optometrists in Orange, you may find
that they can all differ from each other. However, some factors
that may contribute to the average price can include how many
other optometrists there are in the area, the equipment used and
the health of your vision.
## How to Find an Optometrist in Orange, NSW?
To find an optometrist in Orange, NSW you can take certain steps
that can help make it easier for you such as
searching online, assessing the store’s opening hours and
finding the directions to your chosen location. The steps on how to find an optometrist in Orange are listed
below.
1. Search online using the phrase, Orange optometrist near me.
This can also be done here on the website via our locations
page.
2. Click on the Oscar Wylee link, which will take you directly to
our Orange optometrist store page.
3. See the store’s opening hours and where the store is located
specifically.
4. Use the Orange Google Business page link located under store
hours to see the directions on how to get to the store.
You can also find an optometrist in Orange by searching the
keywords optometrist near me. If you have locations enabled on
your smartphone and you’re in the Orange area, our Orange store
page should appear easily for you to click on.
### Is it Hard to Get an Eye Appointment in Orange, NSW?
No, it is not hard to get an eye appointment in Orange. You can
easily book an appointment to see an Oscar Wylee optometrist in
Orange right here on this page. At Oscar Wylee we have highly
qualified optometrists available for bulk billed eye
appointments, which can be booked online or in-store.
#### How to Compare Optometrists in Orange to Each Other?
To compare optometrists in Orange, you can use factors such as
eye
tests offered, health fund coverage, lens types and add-ons
and eyewear offered. To take care of your vision and eye health, it is important
to receive an eye test at least once every two years. There are
different types of tests that can be performed in an eye test
and not all optometrists may offer the same tests. Health funds
can be used to help cover some of the cost of your frames and
lenses. To find out if your health fund is accepted at Orange
optometrist in NSW, visit their website. In the case of Oscar
Wylee, we accept all major health funds and provide on-the-spot
claims in-store. There are many different lens options available
for prescription glasses such as single vision, multifocal and
high index lenses. Most optometrists in Orange will offer these
lenses although it is good to make sure. There are also lens
add-ons available to enhance your glasses such as
anti-reflective and blue light filters. Finally, if you are
looking to purchase a pair of glasses after your eye test, you
can compare the different styles and colours you are interested
in from Orange optometrists in NSW. Oscar Wylee offers a wide
range of frames with vintage and modern inspirations in bold
colours and subtle designs.
#### How to Find an Eyeglasses Shop in Orange, NSW?
To find a glasses store in Orange, you can try to follow these
simple steps including
searching online, selecting a convenient location and looking
at their health insurance policies. The steps on how to find a glasses store in Orange, NSW are
listed below.
1. Search online using the phrase, glasses store in Orange. This
will provide you with various options for glasses stores in
the whole area of Orange.
2. Select a glasses store that is most convenient for you to
travel to.
3. Click the link to find out more information such as opening
hours, exact location and directions to the glasses store in
Orange.
4. Read their health insurance policies to ensure you know what
health benefits you have access to.
Our Oscar Wylee glasses store in Orange, NSW offers primary eye
care services such as comprehensive eye tests and other services
performed by an optometrist and offers prescription and
non-prescription eyewear.
##### Is it Possible to Purchase Prescribed Sunglasses in Orange, NSW
Without Seeing an Optometrist?
Yes and no, it is possible to
[purchase prescribed sunglasses](https://www.oscarwylee.com.au/sunglasses.html)
in Orange, NSW without seeing an optometrist if you already have
a prescription that has not expired. If your prescription is
expired, you can book an eye test to receive an updated or new
prescription which will require you to see an optometrist. This
will ensure your prescription sunglasses are appropriate for
your visual needs.
## Where is the Oscar Wylee Orange Optometrist in NSW Located?
The Oscar Wylee Orange optometrist is located at the Orange
Central Square Shopping Centre at 227-239 Summer St. You can
find the Oscar Wylee Orange store next to the Coffee Club.
What is the Phone Number of Oscar Wylee Orange Optometrist Store?
The Oscar Wylee Orange optometrist store phone number is
(02) 6318 8061. You can contact
the Oscar Wylee Orange store between the hours of 9 am and 5:30
pm on Monday, Tuesday, Wednesday, Thursday and Friday, between 9
am and 4 pm on Saturday and between 9 am and 2 pm on Sunday.

### What are the Reviews for Oscar Wylee Orange Optometrist in NSW?
The many reviews for Oscar Wylee Orange optometrist in NSW, left
by our various customers can be found here on the website and
online when you search for Oscar Wylee Orange optometrist. The
reviews for Oscar Wylee Orange optometrist are listed below.
* T:  Asked all the right questions and didn't muck
around, quick and thorough. Very professional.
* Anthony Gersbach:  Thank you for a great experience
during my eye test and purchase. Keep up the great work.
* Rebecca Milne:  The optometrist was great.
* Cameron Carter:  Experience was great, the optometrist
Raymond was able to tell me exactly what was wrong, the only
place I would ever go to.
* Liz Carey:  I would recommend Oscar Wylee Orange as the
staff are knowledgeable, friendly and professional.
#### What Treatments or Eye Care Processes are Done in the Oscar Wylee
Orange Optometrist Location?
The treatments or eye care processes done in the Oscar Wylee
Orange optometrist NSW location include
a tonometry test, a digital photograph, a slit lamp exam and
a refraction test. Additional tests that may also be performed can include
a visual field test and a dilated fundus exam. The
treatments or eye-care processes that are done in the Oscar
Wylee Orange optometrist NSW location are listed below.
* A Tonometry Test: An optometrist or optical dispenser
will conduct a tonometry test which involves the use of a
machine that will release small puffs of air into your eyes.
This will assist with measuring pressure in the eye.
* A Digital Photograph: An optometrist or optical
dispenser may take a digital photograph of your eye which can
be kept on record to use in future appointments to evaluate
any changes to your eye.
* Slit Lamp Test: A slit lamp test can be used to
evaluate your eye health, by examining your cornea and iris
which are the anterior and posterior of the eye.
* Refraction Test: During a refraction test, an
optometrist will have you view an image through different
lenses and ask you to confirm which helps you see the image
clearer.
* Visual Field Test: A visual field test can assist with
assessing your peripheral vision, which may be beneficial for
identifying any signs of glaucoma.
* Dilated Fundus Exam: A dilated fundus exam can help an
optometrist assess your health in more detail by getting a
clear view of the retina. This test is typically carried out
for patients with diabetes and those who may be at risk of
developing retinal damage.
## How Many Optometrists Exist in Orange, NSW?
Many optometrists exist in Orange, NSW that offer high-quality
eye tests and prescription eyewear. The factors that may
influence the number of optometrists in the area of Orange may
be due to the number of residents in the area, the potential
demand for optometry services and the geographical size of the
location. Choose Oscar Wylee Orange for professionally conducted
services and care from a team that is passionate about eye
health.
### What are the Other Closest Optometrist Locations to Orange, NSW in
Australia?
There are no other Oscar Wylee optometrist locations close to
Orange in Australia, however, we have many stores in New South
Wales, Queensland, Western Australia and Victoria. If you are
looking for an optometrist near you, you can find the locations
of our many stores on our full
[store locations page](https://www.oscarwylee.com.au/locations/full-store-list.html).
### Eye Tests Available at Oscar Wylee Orange
Our eye tests are optometrist-led at our Oscar Wylee Orange store. You
can come in-store to have your prescription updated and to shop for
either a pair of prescription glasses or prescription sunglasses. Our
trained optometrists can update your prescription or issue a new one
in just under 30 minutes. Our eyeglasses shop is passionate about eye
care and eye health, so we can help you stay on top of your annual eye
tests!
### Health Funds Accepted at Oscar Wylee Orange
Oscar Wylee Orange accepts leading health funds such as HCF and Bupa.
Our team at the Oscar Wylee Orange store will be able to process your
claim as well as assist you with all the ins and outs of your health
fund. Our team will strive to ensure you are getting the best price
for your new pair of prescription glasses.
### Glasses Perfect for Fashionable Individuals
Here at our store in Orange Central Square, we offer prescription
sunglasses and prescription eyeglasses in a variety of
vintage-inspired and modern styles. You can choose to add on
anti-reflective lenses, blue light filter lenses, and more. Our team
at Oscar Wylee Orange will help inform you of what may work best for
your prescription. We’re confident you will walk away with glasses
that make you look and feel your best, so make Oscar Wylee Orange your
next visit for eyewear and eyecare!
Book Appointment