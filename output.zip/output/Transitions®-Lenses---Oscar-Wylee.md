# Source: https://www.oscarwylee.com.au/transitions-lenses

# Transitions® Lenses
Updated on April 15th, 2026
Published on June 2nd, 2025
Updated on March 27th, 2025 
Australia
Australia
Canada

Transitions®
lenses are a brand of photochromic lenses available at Oscar Wylee for an
additional price on top of your prescription frames. Transitions®
lenses are designed to provide improved vision and optimal sun protection
all in one frame, ensuring significant convenience for people who want
smooth and fast adapting photochromic lenses. Oscar Wylee offers Transitions®
GEN S™ lenses in-store!
## Experience the dynamic lens technology of
Transitions® at Oscar Wylee
The fastest dark lens* in the clear-to-dark photochromic category.
GEN S™ activates in 25 seconds1 when you go
outdoors. Fading back to clear lenses in less than 2
minutes2.
Transitions® GEN S™ lenses
adapt to the speed of life, so whether it’s dark or bright,
indoors, or outdoors, it all becomes by essence, seamless and
smooth.
When fully darkened,
Transitions® GEN S™ lenses
are category 3 sun lenses, blocking 100% UVA and UVB rays and
filtering up to 85% of blue-violet light outdoors3.
Shop&nbsp;Transitions®&nbsp;In-Store Today!
Transitions® GEN S™ is
available for all glasses. Ask our team about
Transitions® lenses in-store
for more information.
[Shop Transitions®](https://www.oscarwylee.com.au/glasses.html)
## Price of Transitions® at Oscar
Wylee
Pricing per pair in addition to the price of your frames*
Standard 1.5 index
$160
Extra Thin 1.61 index
$270^
Super Thin 1.67 index
$320^
*Multifocal lenses available at an additional charge. ^Basic
anti-reflective coating and cost of thinner lenses included.
## What are Transitions® Lenses?
Transitions® lenses are smart lenses that
automatically darken when you're in the sun and quickly return to
clear when you're indoors. They protect your eyes from UV rays and
reduce glare, so you don’t need to switch between glasses and
sunglasses.
## How Do Transitions® Lenses
Work?
Transitions® GEN S™
lenses work just like all other photochromic lenses by shifting to a dark lens tint when exposed to sunlight
outdoors. When you move indoors or into the shade,
the lenses will revert to clear lenses. Transitions®
lenses are coated with a chemical that darkens in response to
direct ultraviolet light exposure from the sun. These lenses may
be suitable for people who need the vision correction provided by
normal prescription glasses but do not want to switch between
prescription glasses and sunglasses when moving inside and
outside.
## How Fast Does
Transitions® GEN S™ Achieve
Full Darkness?
Transitions® GEN S™
lenses respond quickly to light, reaching full activation in 25
seconds¹. All colours darken to category 3 levels², matching the
darkness of standard sunglasses.
### What are the Different
Transitions® GEN S™ Lens
Colours available?
The different Transitions® GEN S™
lens colours available include grey, brown, sapphire, graphite
green, ruby, emerald, amethyst and amber. This array of colour
options are able to suit a variety of tastes, from subtle to
statement lenses!
GREY
BROWN
SAPPHIRE
GRAPHITE GREEN
RUBY
EMERALD
AMETHYST
AMBER
### Do Transitions® Lenses Block
Blue Light?
Yes, Transitions® GEN S™ lenses can block blue light from the sun when outdoors3. Transitions® GEN S™
filter up to 85% of blue-violet light outdoors. When clear, Transitions® GEN S™
filters up to 32% of blue-violet light indoors.
### Do Hot and Cold Temperatures Affect
Transitions® Lenses?
Photochromic performance depends on UV exposure and
temperature. Transitions® GEN S™
performs better than previous generation in cold temperatures,
fading back up to 2x faster at 10°C4. The lenses also perform better than previous generation in
hot temperatures, fading back up to 1.8x faster at 35°C4.
### Do Transitions® Lenses Work
in Cars?
Transitions® GEN S™ lenses
may be limited in the car as the windshield can block UVB light
and a certain amount of UVA light.
They activate up to category 1 levels of darkness behind the
windshield.
### Are
Transitions® GEN S™ Lenses
Clear Indoors?
Yes, Transitions® GEN S™ lenses are fully clear indoors. The lenses are category 0 when unactivated.
Get Help From Our Team In-Store
We have dedicated teams at all store locations.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
#### How Much do
Transitions® Lenses Cost?
At Oscar Wylee,
Transitions® GEN S™ Lenses
are an additional $160 on top of the price of your
prescription frames.
#### Can you wear
Transitions® Lenses at
Night?
Yes, 
Transitions® GEN S™
Lenses can be worn at night and while driving at night as they will
only activate to a darker tint when exposed to UV light. Transitions®
Lenses will remain completely clear during these times while
providing vision correction.
#### Can Transitions® Lenses
Replace Sunglasses?
Yes, Transitions®
GEN S™
Lenses may be used as sunglasses for the purpose of UV
protection when you’re out and about and frequently moving
between indoor and outdoor settings. Transitions®
lenses are designed to shift from clear to dark when exposed
to ultraviolet light. Transitions®
lenses are essentially glasses that turn into sunglasses when
in the sun. The darkened lens will work in the same way as the tint on
regular sunglasses, helping to protect the eyes from UV
radiation emitted from the sun. Transitions® GEN S™
lenses offer level category 3 protection when the lenses are
at their darkest, making them suitable to function as
sunglasses.
### What's the Difference Between Photochromic Lenses and
Transitions® Lenses?
Transitions® lenses are a brand of photochromic lenses
that we offer at Oscar Wylee along with our in-house brand,
which we refer to as adaptive lenses. While Transitions®
is a brand of photochromic lenses, they perform distinctly due
to their quick and seamless shift from clear to dark lenses.
Read How to Flush the Eye Safely in other Oscar Wylee regions and
their languages.
Australia
Australia
Canada

Have You Had a Recent Eye Test?
Don’t wait any longer to prioritise your eye health.
[Book an eye test](https://www.oscarwylee.com.au/booking)
Find an Oscar Wylee Store Near You
Our knowledgeable and friendly team can help you find a pair of
stylish and affordable frames.
[Find your nearest location](https://www.oscarwylee.com.au/locations/full-store-list.html)
Transitions® GEN S™ is fully clear indoors and darkens in seconds.
For polycarbonate &amp; CR39 lenses across colours achieving 18% transmission
at 23°C outdoors. Transitions and the Transitions logo are
registered trademarks of Transitions Optical, Inc. used under license by
Transitions Optical Limited. GEN S is a trademark of Transitions Optical
Limited. ©2026 Transitions Optical Limited. Photochromic performance may
vary across colours and lens material and is influenced by temperature and
UV exposure. Frame by Ray-Ban®, Transitions® GEN S™ lenses in
Sapphire. Frame is not available at Oscar Wylee. *For grey
lenses in the clear to dark (category 3) photochromic category.
Transitions® GEN S™ lenses fade back faster to 70% transmission
while achieving less than 14% transmission when activated at @ 23°C.
1For grey CR39 lenses, achieving 18% transmission
at 23°C.&nbsp; 2For grey CR39 lenses with a premium
anti-reflective coating fading back to 70% transmission @ 23°C.
3Block 100% UVA &amp; UVB rays, darken outdoors
&amp; filter up to 32% of blue-violet light indoors &amp; up to 85%
outdoors. Blue-violet light is between 400 and 455nm (ISO TR 20772:2018).
4For grey CR39 lenses fading back to 70%
transmission.