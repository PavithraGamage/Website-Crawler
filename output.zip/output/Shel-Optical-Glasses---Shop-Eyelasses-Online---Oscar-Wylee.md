# Source: https://www.oscarwylee.com.au/shel-optical.html

# Shel
1
## Frame Design of Shel Glasses
The frame design of Oscar Wylee’s Shel glasses is characterised by a subtle cat-eye shape, nose pads and a frame made of both metals and acetate. Shel glasses are a feminine frame, with the curves of the frame accentuating the best features of the face.
$169    
In stock
Only %1 left
2 pairs from $199
Discount auto-applied at checkout
3 pairs from $249
Discount auto-applied at checkout
Qty
Add to cart
Book an eye test
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
excluding prescription lenses
## About Shel Frames
A cat eye that lasts all day! Make your eyes pop with Shel, the
perfect frames to complement your features. Its modest, pointed
corners make it a must-have for makeup lovers.
| Frame fit | Measurements |
| --- | --- |
| MEDIUM | 52 - 19 - 145 |
These measurements mean lens width, bridge, and temple length in
millimetres (mm). They can be found on the inside of the temple
arm. If you already have a pair that you like, you can compare it
to these measurements.
### Made from metal
Oscar Wylee’s Shel frame is a subtle cat-eye frame that is perfect
for heart and square face shapes. The Shel frame is a stylish
frame that will bring a touch of femininity to any outfit. The
main specs of Oscar Wylee’s Shel glasses frame including
dimensions, shape, materials, lenses, nose fit and hinges
are listed below.
| Shel Frame Features | Shel Frame Description | Dimensions | Shape | Materials | Lenses | Nose Fit | Hinges |
| --- | --- | --- | --- | --- | --- | --- | --- |
| The dimensions of the Shel frame are measured in millimetres
(mm) and are 52 - 19 - 145, meaning the lens width is 52 mm,
the bridge is 19 mm and the temple length is 145 mm. |
| The Shel frame is a cat-eye shape suitable for medium-width
faces. |
| Shel glasses are made from a mix of metals and acetate. |
| The lenses that can be used in the Shel frame are optical
lenses, which include single-vision and multifocal lenses, and
non-prescription lenses, which are plain and can have a filter
like a blue light filter applied. |
| The nose fit of Shel frames is characterised by nose pads. |
| The hinges in Shel glasses are spring hinges, which are more
flexible than other types of hinges and can extend past 90
degrees. |
Show All
### What Inspired the Frame Design of Oscar Wylee’s
Shel Glasses?
The Oscar Wylee Shel frame design is inspired by the classic
cat-eye frame. First popularised in the 1950s and 1960s by
actresses such as Marilyn Monroe and Audrey Hepburn, the
cat-eye frame has been an enduring statement glasses frame.
The Shel glasses take design inspiration from the cat-eye
frame in a subtle way, with pointed upper corners.
## What to Know About Oscar Wylee’s Shel Glasses?
There are many aspects of the Oscar Wylee Shel frames that
customers should know about, so they can decide whether this
is the right frame for them. The Shel frame is a feminine
cat-eye-shaped. Oscar Wylee’s Shel frame is suitable for many
face shapes but particularly compatible with heart and
square-shaped faces. The Shel frame’s subtle, yet fashionable
design means that they can be worn all year round, to a range
of casual and formal events. Shel glasses feature standard
[parts of glasses](https://www.oscarwylee.com.au/glasses/eye/part-of-glasses)
such as a rim, temples, lenses, spring hinge and nose pads.
### What are the
Types of Temple Tips or Earpieces Included with
Oscar Wylee’s Shel Glasses?
The type of temple tips or earpieces included in Oscar Wylee’s
Shel Glasses are made from acetate.
### What Type of Nose Bridge do Oscar Wylee’s Shel
Glasses Have?
The type of nose bridge included in Oscar Wylee’s Shel frame
is characterised by nose pads.
### What Type of Nose Pads are Included with Oscar
Wylee’s Shel Glasses?
Oscar Wylee’s Shel frame includes nose pads. Nose pads can be
adjusted for a closer, more comfortable glasses fit.
### What Type of Lenses do Oscar Wylee’s Shel Glasses
Have?
The type of lenses that typically come with the Oscar Wylee
Shel
[glasses frame](https://www.oscarwylee.com.au/glasses.html)
are optical lenses. Optical lenses are glasses lenses that
have a prescription within the lens to help correct vision
issues such as myopia, hyperopia and astigmatism. Shel glasses
can also come with non-prescription lenses, with add-ons such
as a blue light filter. Shel frames are currently unavailable
as sunglasses online, however, customers can customise
in-store and add on tint or polarisation.
### What Material is Used for the Rim of Oscar Wylee’s
Shel Glasses?
The material used for the rim of Oscar Wylee’s Shel glasses
frames is stainless steel. The rim refers to the part of a
glasses frame that holds the lenses.
### What Type of Hinges are Included with Oscar Wylee’s
Shel Glasses?
The type of hinges included with Oscar Wylee’s Shel frames are
spring hinges. A spring hinge in a glasses frame refers to
hinges that are more flexible than normal hinges and can go
slightly beyond 90 degrees. Spring hinges can provide a closer
fit to the face.
## What Face Types are Most Suitable for Oscar Wylee’s
Shel Glasses?
The face types most suitable for Oscar Wylee’s Shel frame are
square and heart-shaped faces. The Shel frame is a subtle
cat-eye shape, meaning it helps to balance the features of a
[square face shape](https://www.oscarwylee.com.au/glasses/face-shapes/square)
or a heart face shape, bringing the eyes and brows forward in
a flattering way. Although there are many
[glasses for face shapes](https://www.oscarwylee.com.au/glasses/face-shapes)
that may be considered aesthetically suitable, it is important
that people also choose the frames that make them feel most
comfortable, and represent their personal style.
## What Size Options are Available for Oscar Wylee’s
Shel Glasses?
The size options available for Oscar Wylee’s Shel frame are a
medium-frame fit across all colours.
## What Materials are Used to Create Oscar Wylee’s
Shel Glasses?
The primary material used to create the Oscar Wylee Shel frame
is metal with acetate temple tips. The rim is made from
stainless steel, the nose bridge is made from high nickel and
the temples are made from brass.
## What’s Included
## What's Included
Each pair of glasses comes with a stylish frame case and lens cloth. We offer free shipping across Australia and 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects.
* Free Shipping for Australian Orders
* 1 Year Warranty on frames and lenses
* Scratch resistance lens coating on all prescriptions
* UV-proof coating on all prescriptions
* Stylish case and cloth
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
## Make and Materials
The frames then go through cleaning and strict quality control, and many pairs of crafting hands to be hand-assembled and polished. After your frames have gone through the production process, they are individually examined and packed before making their way to you!As part of our durable frame family, some of our most popular styles, are now in stainless steel. These frames are hypoallergenic, corrosion resistant, light weight, and not sensitive to temperature changes.
## Warranty Information
### Warranty Information
### Warranty Information
Oscar Wylee provides a 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects. We will repair or replace faulty or defective frames or lenses free of charge for warranty claims made within 1 year of the delivery. We also offer repairs or replacement for problems experienced with vision during everyday use for claims made within 30 days of delivery. If the same product has been discontinued or is no longer available, then we may offer an exchange for a similar product or a refund.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Find a Store Location](https://www.oscarwylee.com.au/locations/full-store-list.html)