# Source: https://www.oscarwylee.com.au/glasses/eye/watery

# Watery Eyes: Causes, Tests, Symptoms, Treatment and Prevention
Published on July 9th, 2024
Updated on May 29th, 2025
Australia    
[Australia](https://www.oscarwylee.com.au/glasses/eye/watery)
[New Zealand](https://www.oscarwylee.co.nz/glasses/eye/watery)
[Canada](https://oscarwylee.ca/glasses/eye/watery)
Watery eyes occur when your eyes are producing excessive tears or if an issue is preventing your tears from draining correctly. Watery eyes, also known medically as epiphora, can be a temporary issue that stems from a range of causes. However, it may also indicate that you have an eye infection according to the Cleveland Clinic. If you find your eyes constantly watering, you should see an optometrist or your local health provider as they can help with identifying the cause and determine the most suitable treatment. The symptom of teary eyes may not be harmful itself but can be unpleasant and may accompany other symptoms depending on the initial cause.
Need to Have Your Eyesight Checked?
We recommend everyone has a complete eye examination at least once every two years. Book yours today with Oscar Wylee.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Definition](#definition) [Causes](#causes) [Home Remedies](#remedies) [Accompanying Symptoms](#symptoms) [Treatment](#treatment)
## What are Watery Eyes?
Watery eyes occur when the eyes produce too much tears or when the tears that are produced are not able to drain properly. The eyes generate tears through the lacrimal glands to keep the eyes lubricated and protected. However, this process can be disrupted when there is an issue that affects the eyes or your lacrimal apparatus (tear system). Common issues that can contribute to developing a teary eye or teary eyes include eye infections, allergies, blocked tear ducts, dry eyes, styes and eye injuries.
## What Causes Watery Eyes?
The causes of watery eyes can include eye infections, eye allergies, blocked tear ducts, eyelid problems, dirt, debris and chemicals getting into the eyes and dry eyes. The causes of watery eyes are listed below.
* Eye Infections: Eye infections can cause watery eyes as a form of defence against the virus, bacteria or fungus present in the eye. The eyes may likely become watery during an infection to remove the infection source with its tears.
* Eye Allergies: Eye allergies can trigger watery eyes due to the body’s response system to allergens, which causes it to produce histamine. Histamine is a chemical that is released in the body and is responsible for allergy symptoms such as itchiness, redness, pain and watery eyes. Common allergens can include pollen, animal dander, mould and dust mites.
* Blocked Tear Ducts:  Blocked tear ducts can develop as a result of eye infections or eye injuries and can lead to watery eyes as your tears are not able to drain properly. Tears normally flow into the small opening (nasolacrimal duct) located in the corner of your eyes near your nose.
* Eyelid Problems: Eyelid problems such as not being able to open or close your eyelids properly or blepharitis can cause inflammation of the ocular surface and can lead to watery eyes among other common symptoms such as redness, swelling and pain as well as dry eyes.
* Dirt, Debris and Chemicals: Dirt, debris and chemicals can get into the eye and cause irritation triggering the eye’s natural response to try to eliminate the foreign body or substance from the eye by generating more tears.
* Dry Eyes:  Dry eyes can elicit watery eyes to try to compensate for the insufficient amount or quality of tears. The sensation of scratchiness, grit and sand can commonly take place during dry eye along with symptoms such as burning, stinging, light sensitivity, blurry vision and discharge.
### Why Do My Eyes Keep Watering?
Your eyes may keep watering for many different reasons, however, this can commonly occur from allergies, dry eye and/or viral infections. It is recommended to see an optometrist as they may be able to identify the underlying cause and prescribe the right treatment. Eyes constantly watering can be a sign of minor issues or other, more complex issues that may require medical intervention. Therefore, it is important to have your eyes examined if you are experiencing this symptom.
#### Is Excessive Eye Watering Serious?
No, excessive eye watering is not serious, however, it can be very uncomfortable and potentially disrupt your normal activities. Therefore, you should see an optometrist so they can identify the possible cause and the most suitable treatment according to your condition.
#### Do Eye Injuries Cause Watery Eyes?
Yes, eye injuries can cause watery eyes as part of their protective response. The eyes can become watery after sustaining an injury as the eyes are triggered to produce tears for relief. Eye injuries may also lead to watery eyes if they become infected or inflamed.
## What Eye Test Can Determine the Cause of Watery Eyes?
A standard eye test conducted by an optometrist can determine the cause of watery eyes as it examines different regions of the eye and how well your eyes are functioning. However, the optometrist may refer you to an ophthalmologist after [testing your watery eyes](https://www.oscarwylee.com.au/glasses/eye/check-up) depending on the severity of your condition and any other symptoms you may be presenting.
### What are Home Remedies for Watery Eyes?
The home remedies for watery eyes are artificial tears, using a warm, damp cloth and taking regular breaks from certain tasks. It is important to always seek professional advice first before attempting any form of treatment on yourself to prevent further damage. The home remedies for watery eyes are listed below.
* Artificial Tears: Artificial tears may be helpful for watery eyes caused by dry eyes. Lubricating eye drops can be purchased over the counter, however, it is recommended to see an optometrist first so they can prescribe the correct eye drops.
* Warm Damp Cloth: Wiping your affected eye(s) with a warm, damp cloth may help with providing relief to other symptoms that may accompany watery eyes.
* Regular Breaks: Taking regular breaks from certain tasks such as watching television, smartphone use and reading are typically recommended to help rest your eyes. This can help prevent further eye strain, which may exacerbate watery eyes.
## What are the Common Symptoms That Accompany Watery Eyes?
The common symptoms that can accompany watery eyes are redness, eye pain, itchiness, foreign body sensation and swelling. The common symptoms that can accompany watery eyes are listed below.
* Redness: Redness in the white portion of the eye (sclera) is a common symptom that may accompany watery eyes as a result of the small blood vessels enlarging. This can occur when the eyes become irritated or are affected by certain conditions.
* Eye Pain: Eye pain can develop when the eye is infected, irritated or injured and can range in intensity levels depending on the type of condition you have.
* Itchiness: Itchiness can commonly occur along with watery eyes during conditions such as dry eye or from allergies.
* Foreign Body Sensation: Foreign body sensation can stem from various forms of eye problems and is defined as the feeling of having something stuck in your eye.
* Swelling: Swelling may arise in addition to having watery eyes if you have an infection, allergies or as a result of an injury to the eye. Swelling can develop in either your eyelid or lower lid and the general eye area.
### When Should You See a Doctor for Watery Eyes?
You should see a doctor for watery eyes if it is occurring constantly and affecting normal activities. However, you will need to see an optometrist first before [visiting the eye doctor](https://www.oscarwylee.com.au/glasses/eye/doctors) (ophthalmologist) as optometrists can conduct a complete examination of your eyes and treat any of your minor conditions but an ophthalmologist will be able to treat your condition if it is more serious.
Visit a Store Near You
We have highly qualified teams dedicated to helping with your eye care needs.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
## What Are the Treatment Options for Watery Eyes?
The treatment options for watery eyes are artificial tears, antibiotic eye drops, antihistamines and removing the foreign body from your eye. Watery eyes may not always require treatment if they are not causing any more problems to your eyes, vision or daily activities. However, it is always recommended to see an optometrist when experiencing any symptoms to ensure there is no underlying condition and so they can prescribe the right type of treatment. The treatment options for watery eyes are listed below.
* Artificial Tears: Artificial tears also known as lubricating eye drops can help with watery eyes as they can help restore moisture in the eyes. Artificial tears are commonly used when the eyes are dry, not producing enough tears to lubricate the surface of the eye or when the tears that are produced are poor quality.
* Antibiotic Eye Drops: Antibiotic eye drops may be helpful for watery eyes if your symptoms are caused by a bacterial infection. If bacteria comes into contact with the eye, it can cause bacterial infections such as bacterial conjunctivitis or pink eye. Antibiotic eye drops are applied to the eye to help fight the bacteria that are causing infection.
* Antihistamine: Antihistamine in either the form of oral tablets or eye drops can help alleviate watery eyes brought on by allergic conjunctivitis. Antihistamine relieves your allergic reaction to substances such as pollen, animal dander, dust and mould.
* Remove the Foreign Object: An optometrist or healthcare professional can remove the foreign object that may be stuck in your eye and causing excessive tears. It is important to have a professional carry this out to ensure safe and proper removal.
### How Long Can Watery Eyes Last Without Medication?
Watery eyes may only last for a few days to a few weeks without medication, however, this will depend on what condition may be causing your symptoms. Watery eyes may often not require medical treatment but your optometrist will be able to let you know what will be best for your condition.
## How to Prevent Teary Eyes from Recurring?
To prevent teary eyes from recurring, ensure your eyes have sufficient moisture, take antihistamine medication if recommended and regularly wash your hands. Dry eye is a common condition, therefore, using artificial tears after long periods of screen time, reading or during cold and dry weather can help with prevention. If you react to common allergens, you can prevent teary eyes by taking your antihistamine medication on time and as advised by your doctor. Regularly washing your hands can help eliminate bacteria or viruses that you may pick up from surfaces, which can prevent developing eye infections.
### Why is Only My Right Eye Watering?
Your right eye may be watering due to allergies, an eye infection, eye injury or a foreign body stuck in your eye. These eye problems can occur in both eyes but do commonly affect just one eye and therefore can cause just one eye to water. If your eyes are constantly watering, you should see an optometrist or your local healthcare provider so they can further examine the possible cause.
### How Do Allergies Contribute to Watery Eyes?
Allergies contribute to watery eyes due to the body’s response to allergens which causes the body to produce a chemical known as histamine. [Watery eyes caused by allergies](https://www.oscarwylee.com.au/glasses/eye/allergies) stem from the compound chemical, histamine, which is responsible for communicating between different cells and primarily triggering allergic and anaphylactic symptoms such as itchiness, redness, pain, swelling and watery eyes according to the Cleveland Clinic.
#### Can Environmental Factors Lead to Watery Eyes?
Yes, environmental factors can lead to watery eyes. Common substances found in the environment that can cause watery eyes are pollen, mould, dust, animal dander and air pollution. These substances can get into the eye and cause irritation, triggering the eye to release more tears for relief.
Read Watery Eyes: Causes, Tests, Symptoms, Treatment and Prevention in other Oscar Wylee regions and their languages.
Australia    
[Australia](https://www.oscarwylee.com.au/glasses/eye/watery)
[New Zealand](https://www.oscarwylee.co.nz/glasses/eye/watery)
[Canada](https://oscarwylee.ca/glasses/eye/watery)
Let Us Take Care of Your Eye and Vision Health
Book an appointment online with a qualified Oscar Wylee optometrist today.
[Book an eye test](https://www.oscarwylee.com.au/booking)
Major Health Funds Accepted In-store
For the purchase of frames and lenses, use your private health fund to limit how much you pay from your own pocket.
[Health Funds](https://www.oscarwylee.com.au/health-funds.html)