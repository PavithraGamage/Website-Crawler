# Source: https://www.oscarwylee.com.au/locations/optometrist-mandurah.html

# Optometrist Mandurah
Mandurah ForumG-048, 330 Pinjarra RdMandurah WA 6210
* Next to Zamels
Opening hours
Monday9:00am - 5:30pm
Tuesday9:00am - 5:30pm
Wednesday9:00am - 5:30pm
Thursday9:00am - 7:00pm
Friday9:00am - 5:30pm
Saturday9:00am - 5:00pm
Sunday10:00am - 4:00pm
*Store hours reflect local standard trading hours and exclude public holidays
[Visit our Mandurah Google Business page for directions, reviews, and updates.](https://g.page/r/Cfw7kbpjKipoEBM)
Book Appointment
[Call us: (08) 9567 5094](tel:(08) 9567 5094)
[Leave a Review!](https://g.page/r/Cfw7kbpjKipoEBM/review)
Our Reviews
Steve P
6 days ago
Booked an eye test then ordered my transition glasses and sunglasses.  So impressed with the service... from the manager and the quality of the frames and lenses. Best service and prices in mandurah town.
See more
Darryl Reed
1 week ago
Very professional service was excellent took the time to understand your medical condition and follo...wed up with phone call later that day
See more
annahlou
1 week ago
Samantha Jubb
2 weeks ago
All of the ladies at Oscar Wylee Mandurah are helpful, kind and like rays of sunshine ????
Steve P
1 month ago
Very easy and fully comprehensive testing, the assistant was professional and knowledgeable.
Allison Johnson
1 month ago
I had great experience staff were very helpful &amp; friendly
Tim Coles
1 month ago
Found staff very friendly and very professional eyesight testing specialist looking forward to new g...lasses arriving.
See more
Liesel Silulu
1 month ago
The ladies at the Mandurah store are very professional and assisted me with all I needed. Thank you ...for your patience and professionalism
See more
Marlene Pearce
1 month ago
Great place good strong frames lovely staff all good experience
Julie Hobbs
1 month ago
Very comfortable experience
Sandra Megaritis
2 months ago
Very punctional and professional.
Wendy Thetford
2 months ago
Fantastic friendly staff, great experience from start to finish ????
Janice Alfrey
2 months ago
Very pleasant staff and the testing and discussion about my needs were all met very professionally. ...Choice of glasses are good.
See more
katey jane
2 months ago
The girl at the counter was lovely, as was the optometrist. Testing was quick and thorough. I bought... glasses but there was no pushy selling at all, very pleasant experience overall.  ????
See more
Matt Salvador
3 months ago
The young lady optometrist, I cannot recall her name, is so professional, friendly, and kind. Also, ...the assistant optometrist who performed some preliminary testing was friendly and professional too.  Thanks, from Matt Salvador
See more
James Trewin
3 months ago
I would recommend this business.
Friendly and professional staff. The customer experience was very g...ood.
Thank you.
See more
Wendy Spackman
3 months ago
Excellent service, lovely staff.
Kara-Lee Vaninetti
3 months ago
Siegi Eyre
3 months ago
Both the receptionist and optometrist at Mandurah WA store were both friendly and professional. Will... be confident to use there services again.
See more
Peter McMahon
3 months ago
Excellent service friendly staff, whole experience was very pleasing
Kirsty-lee Horley
3 months ago
Very friendly and professional. Definitely worth consideration if you're thinking about changing opt...ometrist brands
See more
Daniela Anke
4 months ago
Thank you. Had a good experience x
Lauren Batson
4 months ago
The team at Oscar Wylee Mandurah were absolutely great. The girls were very welcoming and helpful wi...th my frames and the optometrist was super knowledgable. Will be back 100%
See more
marliyn mclachlan
4 months ago
I was very impressed with all that occurred to me on my visit on friday.Firstly the counter staff we...re very thorough and polite in informing me of what products you had also what was available,and then insisted on an eye test.THankfully they did as the specialist I had was most thorough and told me that I needed to see Peel Vision to have cataracts removed.He then sent a referral off and now am waiting an appointment with them.This diagnosis was very contary to my previous supplier (Specsavers) who I have been going to for years and they told me I had no problems even though I knew something was not quite right and my vision was getting weaker.So what a great day when I walked through your doors and a very big thank you to all your staff at Mandurah shop.
Yours faithfully
Marilyn Mclachlan
See more
Roland Hofmann
4 months ago
Very professional and the expertise was great.
Dianne Hall
5 months ago
Happy with staff.friendly, helpful    and please to assist
litcha56
5 months ago
Very thorough and extra time given for explaining eye care
Time In a Bottle
5 months ago
Yasmin Bell
6 months ago
It was an absolute please having Lily take care of me. She was caring, so polite, charming and commu...nicated professionally with a touch of her personality!! Well done Lily.
See more
Bill Dunn
7 months ago
I was impressed with the courteous, efficient treatment I received. I was seeking affirmation that a... large floater in my right eye was not a portent of a more sinister problem. I was thoroughly examined by a cheerful, friendly, personable professional, who took the time to explain my symptoms to me, and there was absolutely no suggestion to explore purchasing new glasses.
I would highly recommend Oscar Wylee to anyone.
See more
Molly I
7 months ago
Fantastic service, no waiting time, and great selection of frames!
I found the cost quite a bit bett...er than other providers also and the best part was they were empathetic and understanding towards anxiety and claustrophobia. Will definitely be back next time.
See more
Edwina Stowers
7 months ago
I was served by gorgeous Maria today and she always gives fantastic customer service ????and goes ab...ove and beyond to help &amp; Thankyou ????again for helping me with my much needed Glasses ???? your an Angel ???? ⭐️⭐️⭐️⭐️⭐️
See more
Derren Den-Ridder
7 months ago
From the moment we walked in we were greeted warmly by what friendly staff.  The ladies were very he...lpful, professional and Knowledgeable on all their products and procedures. I would not hesitate to recommend Oscar Wylee Optometrist's to anyone who is in need for an eye test or new glasses.
See more
Brett Judd
8 months ago
Great service, helpful and knowledgeable staff. Highly recommended.
Fiona Putt
8 months ago
Visiting WA and had to stop instore to get my glasses fixed. Sarah was so lovely and quickly repaire...d them for me. Great service Sarah. Thanks
See more
Jennie Nicolle
8 months ago
Eye tests have been easy to arrange &amp; always carried out in a comfortable &amp; professional manner.  Fr...iendly &amp; attentive staff, lots of options to choose from for new glasses. I find they are very reasonably priced for multifocal glasses and have been very happy with the quality of the lenses over the years that I have been a customer.
See more
jacque Pass
8 months ago
Very lovely service the girls are all amazing and very helpful.
Barbara
9 months ago
Very caring lady . Explained everything in detail . What to expect and results . Very professional
Iain
9 months ago
After a poor experience a few years back at my previous optometrist and hearing positive reviews by ...other family members I decided to give Oscar Wylee in Mandurah a go.
The staff were  very friendly, communicative and professional in their approach, providing options that met my needs at a very reasonable price.
Still waiting for the glasses to be delivered however first impressions have been outstanding.
See more
Sheri Safari
9 months ago
Dee, Alyssa and Bonnie made my experience so much more than just getting a pair of glasses. I’ve nev...er looked forward to getting my next eye check before but every time I go I don’t want to leave ????
They greeted me with the brightest smile and I left with a smile on my face. They really understand how to give the best customer experience and I hope their efforts will be recognised.
By the time I left I had the exact glasses frame I had in mind. They found it within 5 minutes. They fit comfortably and are so much more affordable than any other optometrist store.
Two years ago, I had my eyes tested and the prescription gave me headaches all the time. Bonnie did such a great job with my prescription my eyes adjusted to the prescription within the first hour. I’ve never had such comfortable glasses. The prescription was higher but exactly what my eyes needed. It was like seeing with new eyes. She caught all the last problems I had with no previous history available to her but took her time and paid attention to every detail. Leaving a very satisfied and happy customer.
See more
Mark
9 months ago
Staff were really friendly and helpful
harmeet kaur
9 months ago
Great service
Julauna Taylor
9 months ago
The ladies working there are amazing helped me out with everything I needed. Thanks
Louise Young
10 months ago
I was very happy with the service. Staff were friendly and helpful.
Delia Howe
10 months ago
A wonderful experience at Oscar Wylee, very thorough and profession.  All done with a welcoming atti...tude
See more
Chloe Dyke
10 months ago
Amazing experience as always, in every aspect.
John K
10 months ago
Great optometrist. Very thorough, very friendly and professional. Would highly recommend for eye tes...t lol
See more
YeetGodObama
10 months ago
They were really polite and the test was really simple
Lynn McGregor (Gapsawind)
10 months ago
I had my eye test and prescription glasses sorted out. The staff were very helpful and curtious.
Karen
11 months ago
## Find an Optometrist in Mandurah With Oscar Wylee
Located on the picturesque coast of Southern WA, you can find our Oscar Wylee store in the Mandurah Forum Shopping Centre. Here, our Oscar Wylee optometrists can provide you with bulk billed Medicare eye health tests, and our friendly staff can help you shop our range of stylish and affordable frames. To get here, you can take the train to Mandurah station, a 15-minute walk away, or a bus to Pinjarra Road. If you are driving in, the centre has free parking for up to five hours.
Whilst here, why not enjoy the local area. The Mandurah Foreshore is less than a 10-minute drive away. Enjoy the stunning views of the water or try out some of the seafood cuisine. If you live close to Coodanup, Dudley Park or Greenfields areas, come and see the team at Oscar Wylee Mandurah!        
Meet Our Team
* 
Our Services
* Bulk Billed Eye Examinations
* Professional Frame Styling
* Frame Adjustments and Repairs
* Visual Fields Testing
Show All
## Find an Optometrist in Mandurah, Perth for an Eye Health Test
Find an Oscar Wylee optometrist in Mandurah, Perth, for high-quality eye care services including eye health tests. Located in the Mandurah Forum Shopping Centre, our Oscar Wylee optometrists can provide vision testing, and conduct processes such as slit lamp testing to help diagnose eye diseases. Our optometrists can also refer patients with complex eye conditions like advanced glaucoma, to an ophthalmologist or known as an eye doctor in Australia. The cost for optometry or ophthalmology services in Mandurah, Perth can be dependent upon a person’s eye care needs as well as their age and any underlying health conditions. At Oscar Wylee, our eye tests are conducted at a bulk billed price under Australia’s Medicare system.
At our Oscar Wylee glasses shop in Mandurah, Perth, we are passionate about our customers finding the eyewear that is right for their vision and lifestyle needs, with frame adjustments, lens add ons and styling advice available in-store with our retail team and optical dispensers. Customers can find their new frames from our stylish range of prescription glasses, prescription sunglasses and non-prescription glasses. Visit Oscar Wylee for eye care services including new frames and eye health tests in Mandurah, Perth.
## How to Find an Optometrist in Mandurah, Perth?
To find an optometrist in Mandurah, Perth you can take certain steps that can help make it easier for you such as searching online, assessing the store’s opening hours and finding the directions to your chosen location. The steps on how to find an optometrist in Mandurah, Perth are listed below.
1. Search online using the phrase, optometrist near me in Mandurah. This can also be done here on the website via our locations page.
2. Click on the Oscar Wylee link, which will take you directly to our Mandurah optometrist store page.
3. See the store’s opening hours and where the store is located specifically.
4. Use the Mandurah Google Business page link located under store hours to see the directions on how to get to the store.
You can also find an optometrist in Mandurah, Perth by searching the keywords optometrist near me. If you have locations enabled on your smartphone and you’re in the Mandurah, Perth area, our Mandurah store page should appear easily for you to click on.
### Is it Hard to Get an Eye Appointment in Mandurah, Perth?
No, it is not hard to get an eye appointment in Mandurah. You can easily book an appointment to see an Oscar Wylee optometrist in Mandurah, Perth right here on this page. At Oscar Wylee we have highly qualified optometrists available for bulk billed eye appointments, which can be booked online or in-store.
#### How to Compare Optometrists in Mandurah, Perth to Each Other?
To compare optometrists in Mandurah, Perth, you can use factors such as eye tests offered, health fund coverage, lens types and add-ons and eyewear offered. To take care of your vision and eye health, it is important to receive an eye test at least once every two years. There are different types of tests that can be performed in an eye test and not all optometrists may offer the same tests. Health funds can be used to help cover some of the cost of your frames and lenses. To find out if your health fund is accepted at an optometrist in Mandurah, Perth visit their website. In the case of Oscar Wylee, we accept all major health funds and provide on-the-spot claims in-store. There are many different lens options available for prescription glasses such as single-vision, multifocal and high-index lenses. Most optometrists in Mandurah, Perth will offer these lenses although it is good to make sure. There are also lens add-ons available to enhance your glasses such as anti-reflective and blue light filters. Finally, if you are looking to purchase a pair of glasses after your eye test, you can compare the different styles and colours you are interested in from the optometrists in Mandurah, Perth. Oscar Wylee offers a wide range of frames with vintage and modern inspirations in bold colours and subtle designs.
#### How to Find an Eyeglasses Shop in Mandurah, Perth?
To find a glasses store in Mandurah, Perth you can try to follow these simple steps including searching online, selecting a convenient location and looking at their health insurance policies. The steps on how to find a glasses store in Mandurah, Perth are listed below.
1. Search online using the phrase, glasses store in Mandurah, Perth. This will provide you with various options for glasses stores in the whole Mandurah, Perth area.
2. Select a glasses store that is most convenient for you to travel to.
3. Click the link to find out more information such as opening hours, exact location and directions to the glasses store in Mandurah.
4. Read their health insurance policies to ensure you know what health benefits you have access to.
Our Oscar Wylee glasses store in Mandurah, Perth offers primary eye care services such as comprehensive eye tests as well as other services performed by an optometrist and offers prescription and non-prescription eyewear.
##### Is it Possible to Purchase Prescribed Sunglasses in Mandurah, Perth Without Seeing an Optometrist?
Yes and no, it is possible to [purchase prescribed sunglasses](https://www.oscarwylee.com.au/sunglasses.html) in Mandurah, Perth without seeing an optometrist if you already have a prescription that has not expired. If your prescription is expired, you can book an eye test to receive an updated or new prescription which will require you to see an optometrist. This will ensure your prescription sunglasses are appropriate for your visual needs.
## Where is the Oscar Wylee Mandurah, Perth Optometrist Located?
The Oscar Wylee Mandurah optometrist is located in the Mandurah Forum Shopping Centre, in the suburb of Mandurah. The Mandurah Forum is located on Pinjarra Road in Mandurah, Perth.
### What is the Phone Number of Oscar Wylee Mandurah, Perth Optometrist Store?
The phone number for our Oscar Wylee Mandurah, Perth optometrist store is (08) 9567 5094. Our Oscar Wylee Mandurah, Perth store is open, and our staff are available to be contacted between 9 am and 5.30 pm from Monday to Wednesday, 9 am to 8 pm on Thursdays, 9 am to 5.30 pm on Fridays, 9 am to 5 pm on Saturdays and 10 am to 4 pm on Sundays.
### What are the Reviews for Oscar Wylee Mandurah, Perth Optometrist?
The customer reviews for our Oscar Wylee Mandurah, Perth optometrist, can be found here on the website and online when you search for Oscar Wylee Mandurah optometrist. The reviews for our Oscar Wylee Mandurah optometrist are listed below.
* Sandra Battersby:  First time using Oscar Wylee and so happy I did. The whole experience was wonderful. Everyone was so helpful and friendly at Mandurah, WA. Can’t wait to get my glasses.
* Sue Blackwood:  My optometrist, Andrew, was excellent and extremely thorough. Helped me by prescribing solutions for my eye dryness too. Highly recommended.
* Rhonda Plunkett:  Great customer service and fantastic optom. Would recommend Oscar Wylee in Mandurah without hesitation.
#### What Treatments or Eye Care Processes Are Done in the Oscar Wylee Mandurah, Perth Optometrist Location?
The treatments or eye care processes done in the Oscar Wylee Doncaster, Perth optometrist location include a tonometry test, a slit lamp exam and a refraction test. Additional tests that may also be performed can include a visual field test and a dilated fundus exam. The treatments or eye-care processes that are done in the Oscar Wylee Doncaster optometrist location are listed below.
* A Tonometry Test: An optometrist or optical dispenser will conduct a tonometry test which involves the use of a machine that will release small puffs of air into your eyes. This will assist with measuring pressure in the eye.
* Slit Lamp Test: A slit lamp test can be used to evaluate your eye health, by examining your cornea and iris which are the anterior and posterior of the eye.
* Refraction Test: During a refraction test, an optometrist will have you view an image through different lenses and ask you to confirm which helps you see the image clearer.
* Visual Field Test: A visual field test can assist with assessing your peripheral vision, which may be beneficial for identifying any signs of glaucoma.
* Dilated Fundus Exam: A dilated fundus exam can help an optometrist assess your health in more detail by getting a clear view of the retina. This test is typically carried out for patients with diabetes and those who may be at risk of developing retinal damage.
## How Many Optometrists Exist in Mandurah, Perth?
Many optometrists exist in Mandurah, Perth and in the Mandurah Shopping Centre, including Oscar Wylee. The amount of optometrists available in an area will typically depend on the population and the eye care needs of those in the area. At Oscar Wylee Mandurah, Perth, our team is passionate about providing our customers with high-quality, dedicated eye care services. Our optometrists are available to provide bulk billed eye tests with our dedicated optometrists, prescription updates and new frames. If you are looking for an optometrist in Mandurah, Perth, Oscar Wylee is available to provide all your eye care and eyewear needs.
### What are the Other Closest Optometrist Locations to Mandurah, Perth in Australia?
There are no other Oscar Wylee optometrist locations close to Mandurah, Perth, in Australia. However, we have many stores in New South Wales, Queensland, Western Australia and Victoria. If you are looking for an optometrist near you, you can find the locations of our many stores on our [full store locations page](https://www.oscarwylee.com.au/locations.html).
### Bulk Billed Eye Tests
At our Oscar Wylee eyeglasses shop in Mandurah, our optometrists are dedicated to providing customers with high-quality eye care processes. Book online and our optometrists can conduct Medicare bulk billed eye health tests which include vision testing, and an examination of the eyes to detect possible eye diseases or conditions. For some of the best optometrists in Mandurah, Australia, visit Oscar Wylee at the Mandurah Forum.
### Health Funds Accepted at Oscar Wylee Mandurah Forum
Oscar Wylee in Mandurah Forum is dedicated to ensuring that our customers are receiving the best price for their prescription frames. Come and visit our store for an eye test, a prescription update and your health fund may help cover some of the cost of your prescription glasses. Bring your valid health fund card to Oscar Wylee Mandurah Forum and our team can help out with your health fund needs.
### Fashion-Forward Glasses Frames At Oscar Wylee
Here at Oscar Wylee Mandurah, there is a frame to suit everyone. Our Oscar Wylee glasses come in a range of styles, sizes and colours. We offer prescription glasses, prescription sunglasses and non-prescription glasses in a variety of modern and vintage-inspired styles. Come to Oscar Wylee Mandurah and our team can help you pick the frame that best fits your style, your vision needs and your face shape!
Book Appointment
[Call us: (08) 9567 5094](tel:(08) 9567 5094)
[Leave a Review!](https://g.page/r/Cfw7kbpjKipoEBM/review)