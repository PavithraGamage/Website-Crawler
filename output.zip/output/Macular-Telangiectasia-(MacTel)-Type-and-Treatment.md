# Source: https://www.oscarwylee.com.au/glasses/eye/macular-telangiectasia-mac-tel

# Macular Telangiectasia (MacTel): Type and Treatment
Published on August 13th, 2026
Macular telangiectasia (MacTel) is a type of disease that affects the macula and can lead to central vision loss. It stems from abnormal blood vessels near the fovea, which is the centre of the macula. There are two types of macular telangiectasia: type 1 and type 2, which may not present symptoms in early stages, according to the Macular Disease Foundation.
Stay on top of your regular eye tests!
Our team can help you stay up to date so you never miss an eye check-up.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Definition](#definition)
[Causes](#causes)
[Effect](#effect)
[Management](#management)
## What is Macular Telangiectasia?
Macular telangiectasia is a disease that can cause central vision loss due to its effect on the macula. Macular telangiectasia affects the blood vessels and nerve cells in the macula. It is considered rare, with type 1 and type 2 forms, and currently has no effective treatment, according to the Macular Disease Foundation.
### Why does Macular Telangiectasia Occur?
The exact cause of macular telangiectasia is unknown; however, a combination of genetic predisposition, changes in the small blood vessels, and aging may contribute.
#### Is Macular Telangiectasia a Common Eye Disease?
No, macular telangiectasia is not a common [eye disease](https://www.oscarwylee.com.au/glasses/eye/rare-genetic-eye-diseases). It is considered rare, with around 5 to 23 cases per 100,000 people found to have type 2 macular telangiectasia in Australia, according to Aung et al., (2010) in their publication for the National Library of Medicine.
## What Causes Macular Telangiectasia?
The causes of macular telangiectasia may include potential factors such as genetics, changes in the tiny blood vessels and increased age. However, the exact cause of this condition remains unknown.
### How does Macular Telangiectasia Affect the Retina?
Macular telangiectasia affects the [retina](https://www.oscarwylee.com.au/glasses/eye/anatomy/retina)  as it can change the small blood vessels around the fovea. If you have macular telangiectasia type 1, the blood vessels in your eye increase in size and cause bulging blood vessels to form. With type 2 macular telangiectasia, your blood vessels may enlarge and leak, resulting in swelling of the macula.
#### Can Blood Vessel Changes Damage Central Vision?
Yes, changes in the blood vessels can damage central vision. If the macula or retinal blood vessels grow abnormally or leak, it can hinder your ability to see clearly, drive or read.
## What are the Types of Macular Telangiectasia?
The types of macular telangiectasia include type 1 and type 2. The types of macular telangiectasia are listed below.
* Type 1: Type 1 macular telangiectasia is considered a rare condition that affects one eye as a result of abnormal blood vessels that leak, causing macular swelling. Treating this form may involve laser or injection methods.
* Type 2: Type 2 macular telangiectasia occurs in both eyes and is typically a progressive deterioration of the nerve cells in the retina due to increased age.
### What is Macular Telangiectasia Type 2?
Macular telangiectasia type 2 is the more common form and causes leaky blood vessels leading to macular swelling. According to the Macular Disease Foundation, in some cases, new blood vessels can form under the retina and can also break or leak. This can lead to scarring over the macula and may affect vision. Type 2 affects both eyes but may affect each eye differently.
#### Is Type 2 the Most Common Form?
Yes, Type 2 is considered the most common form of macular telangiectasia. However, with an incidence rate of 5 to 23 cases per 100,000 people in Australia, it is considered rare.
## What Symptoms Can Macular Telangiectasia Cause?
The symptoms of macular telangiectasia may include blurred vision, distorted vision, difficulty reading, blind spots and reduced contrast. The symptoms that macular telangiectasia may cause are listed below.
* Blurred Vision: [Blurred vision](https://www.oscarwylee.com.au/glasses/eye/blurred-vision) can be a symptom of macular telangiectasia due to the tiny blood vessels leaking, causing fluid to accumulate, which can hinder the macula's ability to provide detailed vision.
* Distorted Vision: Distorted vision can be a symptom of macular telangiectasia as a result of the fluid leakage.
* Difficulty Reading: Difficulty reading can be a symptom of macular telangiectasia because damage to the central macula impairs the sharp details of recognising letters and words.
* Blind Spots: Blind spots can be a symptom of macular telangiectasia and are characterised as small blank areas in your central vision.
### How does Vision Change Over Time During Macular Telangiectasia?
Macular telangiectasia may change vision over time as patients may gradually lose their central vision. According to the Macular Disease Foundation, patients may experience distorted vision, blurriness and retinal changes.
### How is Distorted Vision (Metamorphopsia) Related to Macular Telangiectasia?
Distorted vision, known as metamorphopsia, can be related to macular telangiectasia, as it can be one of the first clinical symptoms individuals diagnosed with type 2 experience after some time. [Distorted vision](https://www.oscarwylee.com.au/glasses/eye/distorted-vision) is characterised as a symptom rather than an eye condition itself and causes objects with straight edges to appear bent or distorted. According to Issa et al. (2009), in their paper for the National Library of Medicine, metamorphopsia was present in cases even without the formation of new abnormal blood vessels.
Find Your Nearest OW Store!
We’ve got knowledgeable teams who are passionate about delivering high-quality care.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
#### Can Macular Telangiectasia Affect Both Eyes?
Yes, macular telangiectasia may affect both eyes if you have type 2. Type 2 macular telangiectasia is considered the more common form and can affect both [eyes](https://www.oscarwylee.com.au/glasses/eye/anatomy) differently.
## How is Macular Telangiectasia Diagnosed?
Macular telangiectasia is diagnosed through a standard eye test. An optometrist will typically be the first eye care professional to see changes in your vision and eyes. They will be able to examine all regions of the eye to identify signs of any other issues. An OCT can examine the layers of the retina and check for loss of photoreceptors.
### What Does an OCT Scan Show in Macular Telangiectasia?
An OCT scan may show vascular changes and atrophy of the retina, according to Moir et al. (2022). An [OCT](https://www.oscarwylee.com.au/glasses/eye/oct-fundus-test) scan may display retinal thinning and tissue damage, which can help optometrists identify the condition and its level of severity.
#### Can OCT Confirm Macular Telangiectasia?
Yes, an OCT can confirm macular telangiectasia. It is often referred to as the first diagnostic option for identifying macular telangiectasia. It is also important for structural evaluation for monitoring purposes, according to Beuran et al. (2026).
## What Treatments are Available for Macular Telangiectasia?
The treatments that may be available for macular telangiectasia can include injections of anti-vascular endothelial growth factor (anti-VEGF) addressing new abnormal blood vessels under the retina. This therapy can help stop the VEGF proteins from growing these new blood vessels to prevent fluid leakage and help central vision. It may be important to note that this option may only be considered in the proliferative phase of macular telangiectasia.
### How is Macular Telangiectasia Type 2 Treated?
Macular telangiectasia type 2 may be treated with anti-VEGF injections and intravitreal implants depending on the stage of the condition. A milestone in treating macular telangiectasia involves the use of an intravitreal implant that helps provide aid directly into the retina, known as a neurotrophic factor. Neurotrophic factor is a therapeutic molecule that can help delay the degeneration of retinal cells to preserve central vision, according to the Lions Eye Institute. Anti-VEGF injections help target the growth of new abnormal blood vessels under the retina.
#### Can Treatment Restore Lost Vision from Macular Telangiectasia?
No, treatment does not restore lost vision from macular telangiectasia. Any treatments for this condition and many other conditions typically focus on preserving or protecting remaining vision and delaying the disease’s progression.
### What Vision Aids Can Help With Macular Telangiectasia?
The vision aids that may help with macular telangiectasia include magnifiers, talking aids, lighting, reading aids and computer aids. The vision aids that may help with macular telangiectasia are listed below.
* Magnifiers:
Magnifiers of different forms, such as hand-held magnifiers, clip-on magnifiers, fixed-stand magnifiers or desktop magnifiers, can help with enlarging text and objects.
* Talking Aids:
Talking aids can help by verbalising the needed information and are incorporated with household and/or kitchen appliances. Those with macular telangiectasia may benefit from using scales, clocks, microwaves, watches, calculators or thermometers with talking aids built-in.
* Reading Aids:
Reading aids can help in different forms such as making text appear larger or text-to-speech scanners.
* Computer Aids:
Computer aids can use built-in screen magnifiers, text-to-speech software/settings, high-contrast colour settings or special large print keyboards.
### When are Prism Lenses Recommended for Vision Problems?
Prism lenses are recommended for vision problems when they cause double vision or misaligned eyes. During an eye test, an optometrist will be able to evaluate how much prism correction is needed in your prescription and will show up as 0.5, 1.0 or 2.0, measured in diopters. [Prism in your glasses](https://www.oscarwylee.com.au/guides/lenses/prism-glasses.html) helps by bending incoming light before reaching your eyes so one clear image is seen.
### Can Blue Light Glasses Reduce Visual Discomfort?
No, blue light glasses may not necessarily reduce visual discomfort as they are primarily designed to filter blue light emitted from digital screens. They may be helpful in reducing eye strain and improving overall sleep quality. However, research around whether blue light is actually harmful to your eyes and whether [blue light glasses](https://www.oscarwylee.com.au/glasses/eye/blue-light) are effective remains limited.
## How can you Manage Macular Telangiectasia Long Term?
Managing macular telangiectasia long term will ultimately depend on your condition. An optometrist or ophthalmologist will assess the stage and progression and treat you based on that evaluation. It is important to stay on top of your regular eye tests, especially when noticing any changes to your vision, to ensure early detection and therefore early treatment of any eye problems and conditions.
### Can Early Diagnosis Help Preserve Vision?
Yes, early diagnosis can help preserve vision. However, this may also depend on the severity of your condition, genetics and other factors. It is always recommended to get regular eye tests, once every 1-2 years or every year for those at higher risk.
Experience High-Quality Eyecare Services From Our Team
Book an appointment online with an Oscar Wylee optometrist today.
[Book an eye test](https://www.oscarwylee.com.au/booking)
Major Health Funds Accepted In-store
For the purchase of frames and lenses, use your private health fund to limit how much you pay from your own pocket.
[Health Funds](https://www.oscarwylee.com.au/health-funds.html)