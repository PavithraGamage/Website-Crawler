# Source: https://www.oscarwylee.com.au/glasses/face-shapes/square

# Best Glasses for Square Face (Male and Female): Frames, Shapes and Types
Updated on August 14th, 2024
Published on February 9th, 2023
Australia
[Australia](https://www.oscarwylee.com.au/glasses/face-shapes/square)
[New Zealand](https://www.oscarwylee.co.nz/glasses/face-shapes/square)
[Canada](https://oscarwylee.ca/glasses/face-shapes/square)
[Canadian French](https://oscarwylee.ca/fr/glasses/face-shapes/square)
Canadian French
The best glasses for a square shaped face are round glasses, browline glasses, square glasses, aviator glasses, crystal glasses and cat-eye glasses. These glasses suit square faces because they contrast the square faces' angular features with roundness, emphasise the sharp lines of the face and add greater definition to a square face's best attributes. A square shaped face is a face that is as broad as it is long and has a flat chin and flat cheekbones. A square face has the same width measurements across the forehead, jawline and cheekbones and has most of its features in line with each other. [Women’s glasses](https://www.oscarwylee.com.au/glasses/collection/womens-glasses.html) and [men’s glasses](https://www.oscarwylee.com.au/glasses/collection/mens-glasses.html) that fit a square face must add a contrast to the sharp and angular qualities of the square face shape. Square face glasses must play up and highlight these sharper features for a more noticeable profile. Round glasses for square faces are ideal.
The best glasses for a square face are&nbsp;round glasses, browline glasses, square glasses, aviator glasses, crystal glasses and cat-eye glasses.
* Round glasses:&nbsp;Round glasses offset the strong angles and
structure of a square face by providing curves.
* Browline glasses:&nbsp;Browline glasses highlight the angles and
lines of a square face in a simple way, that does not overemphasise these strong features.
* Square glasses:&nbsp;Square glasses for a square face emphasise the
strong and linear features of a square shape, creating a bolder and more intense profile.
* Aviator glasses:&nbsp;Aviator glasses for a square face highlight
strong attributes, shining a light on the more subtle ones.
* Crystal glasses:&nbsp;Crystal glasses for a square face change the
features as little as possible, letting a square face's natural features shine through.
* Cat-eye glasses:&nbsp;Cat-eye glasses for a square face draw
attention to the powerful brow and forehead of a square shape, giving the face roundness beneath the browline.
Prioritise your eye health and book an eye test today
Our Oscar Wylee optometrists perform bulk billed eye tests for eligible Medicare
cardholders.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Best Glasses](#Glasses) [Best Colours](#Colours) [Square Face Shape](#Square)
[Other Face Shapes](#Other)
## 1. Round Glasses for Square Face
Round glasses for a square face are&nbsp;glasses that are circular and lack angles across the entire frame.&nbsp;Round glasses are completely spherical lenses. Round glasses fit a square face because they add gentleness and contrast to the angular features of the square faces shape. Round glasses change a square face's proportions by adding a more round and circular appearance to the face's shape. Round glasses shape for a square face soften the jawline and brow of the wearer's face.
Round glasses frames are one of the oldest and most classic shapes in the world. Round glasses are versatile for any style. Round glasses for a square face suit casual events and night events, as they bring out the square faces softer features. Round glasses for men with a square face soften and exaggerate the striking features of an angular face. Round glasses for women with a square face dulls the pointed edges of the face and highlights more beautiful features. Round eyeglasses for a square face are fashionable for any season.
### The pros of round glasses for square face are as follows:
* Round glasses soften harsh features
* Highlight bold and striking aspects of the face
* Round glasses give balance to a square face
* Give the wearer an air of sophistication.
### The con of round glasses for a square face is as follows:
* Round glasses that are wider than the face overpower the square faces' positive features without improving them.
Do round glasses suit a square face?Round glasses suit a square face shape because they contrast and soften the sharp features of the face while emphasising the striking beauty of others.
[](https://www.oscarwylee.com.au/celeste-optical.html)
[](https://www.oscarwylee.com.au/alya-optical.html)
[](https://oscarwylee.com.au/odette-optical.html)
[](https://www.oscarwylee.com.au/celeste-optical.html)
[](https://www.oscarwylee.com.au/alya-optical.html)
[](https://oscarwylee.com.au/odette-optical.html)
## 2. Browline Glasses for Square Face
Browline glasses for a square face are glasses that have a frame thicker and bolder at the top than at the bottom. [Browline glasses](https://www.oscarwylee.com.au/glasses/silhouette/browline.html) fit a square face by bringing attention to a square face's eyebrows, one of the shapes most attractive features. Browline glasses shape for square face change the proportions by tying together the face shapes’ more symmetrical features. Browline glasses on a square face put forward the face's balanced and bold attributes. Discover more about [browline glasses: origin, style, types and popularity](https://www.oscarwylee.com.au/glasses/browline) to help you choose browline glasses for your face shape.
Browline glasses are named after the bigger and wider top half of the rims, which look like an exaggerated brow. Browline glasses frames have been a trendy eyewear piece for many years and are a good fit for both formal and casual events. Browline eyeglasses for square face are good for night events and business bringing striking appeal they bring to the face shape. Browline glasses for women with a square face present the square faces softer features while emphasising natural beauty. Browline glasses for men with a square face lend an air of intelligence and thought to the square face shape. Browline glasses brighter and more contemporary look makes them a perfect fit for summer styles.
### The pros of browline glasses for a square face are listed below:
* Browline glasses play up the square faces best features
* The more subtle bottom rims soften the edges of the angular face
* Browline glasses for&nbsp; a square face give the wearer an air of intelligence
* Browline glasses are a trendy and current design that grabs attention
### The Cons of browline glasses for a square face are as follows:
* Reliance on a symmetrical browline won’t be suitable for all square faces
* Browline glasses will block the browline of the wearer, meaning a striking or attractive forehead is tampered with or out of view wearing these glasses
Do browline glasses suit a square face?Browline glasses suit a square face because they soften the face shapes harsher features, putting forward the well put together browline of a square face.
[](https://oscarwylee.com.au/neal-optical.html)
[](https://www.oscarwylee.com.au/bentley-optical.html)
[](https://www.oscarwylee.com.au/marco-optical.html)
[](https://oscarwylee.com.au/neal-optical.html)
[](https://www.oscarwylee.com.au/bentley-optical.html)
[](https://www.oscarwylee.com.au/marco-optical.html)
## 3. Square Glasses for Square Face
Square glasses for a square face are glasses that are blocky and even along their length and width. [Square glasses](https://www.oscarwylee.com.au/glasses/silhouette/square.html) are glasses that are angular and linear and have rims and lenses that are equal in length, vertically and horizontally. Square glasses fit a square face by heavily exaggerating the square faces' distinct and unmistakable features. Square glasses shape for a square face do not change the face's proportions but instead highlights them, without overemphasising. Square glasses for a square face put forward the angular, sharp and striking features of the face's shape.
Square glasses frames are named after the precise linear geometric shape they resemble. Square glasses are a vintage shape that has stood the test of time to maintain their popularity. Square glasses on a square face give the wearer a prominent and attention grabbing look that is well suited for professional styles. Square glasses' boldness makes them a great fit for business events and makes a strong appearance. Square glasses for men with a square face emphasises an imposing profile. Square glasses for women with a square face lends a powerful air of cutting beauty to the wearer. Square eyeglasses for a square face are a good fit for all seasons.
### The pros of square glasses for a square face are as follows:
* Highlights angular features
* Square glasses strike an imposing profile on a square face
* Trendy and fashionable in all seasons
* Square glasses are a classic and timeless design
### The cons of square glasses for a square face are as follows:
* Overemphasising angular features create an overly strong profile
* Square glasses stretch the flatter features of the square face out
* A square frame on a square face won’t change the square features in any noticeable way
Do square glasses suit a square face?Square glasses suit a square face because they are versatile glasses that put forward boldness and strength in the square face shape.
[](https://oscarwylee.com.au/jinky-optical.html)
[](https://www.oscarwylee.com.au/serge-optical.html)
[](https://www.oscarwylee.com.au/parker-optical.html)
[](https://oscarwylee.com.au/jinky-optical.html)
[](https://www.oscarwylee.com.au/serge-optical.html)
[](https://www.oscarwylee.com.au/parker-optical.html)
## 4. Aviator Glasses for Square Face
Aviator glasses for a square face are lightweight glasses that have a metal frame. Aviator eyeglasses for a square face have teardrop shaped lenses with an angular top at the rims. Aviator glasses fit the square face by drawing out the square shapes' softer features.
Aviator glasses shape for a square face bring focus towards the square shapes striking and angular lines. Aviator glasses on a square face put forward the faces exact and sharp features.
Aviator glasses frames were first made to protect pilots' eyes in the early 40s. Aviator glasses are a vintage frame that retains a constantly stylish look. Aviators are suitable for any style. Aviator glasses are trendy and bright, making them a better fit for casual and day events. Aviator glasses for women with a square face adds a casual and joyful sense of flair to the square shape. Aviator glasses for men with a square face adds an effortless sense of class to a square face look. Aviator sunglasses are a warm and vibrant style of eyewear, and they are well suited for the summer weather.
### The following are pros of aviators glasses for a square face:
* Aviator glasses soften the harsher characteristics of a square face
* Are a trendy and timeless design
* Aviator glasses are effortlessly cool and suitable for any square face
* Perfectly draw the attractive features of the square face
### The con of aviator glasses for a square face is an follows:
* The trendy and lighter style of the aviator frames won’t suit bolder or bigger square faces.
Do aviator glasses suit a square face?Aviator glasses suit a square face because they emphasise the attractive features of the face shape and give a casual and calm style to the wearer.
[](https://oscarwylee.com.au/dusty-optical.html)
[](https://www.oscarwylee.com.au/deus-optical.html)
[](https://www.oscarwylee.com.au/duckworth-optical.html)
[](https://oscarwylee.com.au/dusty-optical.html)
[](https://www.oscarwylee.com.au/deus-optical.html)
[](https://www.oscarwylee.com.au/duckworth-optical.html)
Find your nearest Oscar Wylee store
Come in and see our friendly team for your optometry needs including eye tests.
All major health funds are accepted in store.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
## 5. Crystal Glasses for Square Face
Crystal glasses for a square face are glasses that are made from a clear, see through material. Crystal glasses refer to a material and they take the shape of the glasses the material is applied to.
Crystal glasses fit the square face shape by letting its distinct facial features naturally shine through. Crystal glasses' frames' greatest benefit is that they do not change the face shape at all. Crystal glasses for a square face put forward the face shapes bold and powerful features by changing them as little as possible.
Crystal glasses are named for the clear and transparent material they are made from. Crystal eyeglasses for a square face do not have a shape and fit the style and vintage of the frames the material is applied to. Crystal glasses' natural appearance make them perfect for casual and friendly styles. Crystal glasses' bare and clear presentation gives the wearer a softer presence, making them better for casual events than for business. Crystal glasses for men with a square face and crystal glasses for women with a square face have the same effect on the face shape's distinct features, they don’t interfere with the raw appeal of the face. Crystal glasses shape for a square face is an excellent fit for summer due to its clear and bright design.
### The pros of crystal glasses for a square face are as follows:
* Crystal glasses lend a shining quality to the square face
* Crystal glasses do not interfere with natural beauty
* They are perfect for casual occasions and days out
* The clear material of crystal frames match any glasses style
### The cons of crystal glasses for a square face are as follows:
* The clear material of crystal based frames means any changes in the square face depend on the frames types and shape
* Clear frames do not change or bring forward any features of the face in any meaningful way
* Crystal glasses do not soften or lessen the harsher attributes of the square face
Do crystal glasses suit a square face?Crystal glasses suit the square face by letting the face’s unaltered features shine through, presenting a softness to the square face's genuine and raw shape.
[](https://oscarwylee.com.au/drew-optical.html)
[](https://www.oscarwylee.com.au/arlia-optical.html)
[](https://www.oscarwylee.com.au/frieda-optical.html)
[](https://oscarwylee.com.au/drew-optical.html)
[](https://www.oscarwylee.com.au/arlia-optical.html)
[](https://www.oscarwylee.com.au/frieda-optical.html)
## 6. Cat-eye Glasses for Square Face
Cat-eye glasses for a square face are glasses that are rounded at the bottom but come to a sharp point towards the top corner of the frame. Cat-eye glasses frames are designed to mimic the eye of a cat. Cat-eye glasses fit a square face by creating a perfect balance for the square faces' symmetrical features. Cat-eye glasses shape for a square face change the features by making the wearer’s face appear longer and more linear, emphasising the face's balance. Cat-eye glasses bring forward and help to define the wearer's cheekbones.
Cat-eye glasses are named for the unique and sharp edge the glasses have at the tip of the rims, which resemble the eyes of a cat. Cat-eye glasses frames are a classic shape. They were created in the 1930s when Altina Schinisi noticed the lack of trendy or fashionable glasses for women.
Cat-eye glasses are versatile for any occasion, event or style. Cat-eye glasses for women with a square face round out the face's angular features while creating a sense of gentleness underneath the brows. Cat-eye glasses for men with a square face lend a more dashing profile to the eyebrows. Cat-eye eyeglasses for a square face are suitable for any season of the year.
### The pros of cat-eye glasses for a square face are as follows:
* Elongates the wearers face
* Creates boldness and softness in the face
* Cat-eye glasses are a classic and trendy shape
* Cat-eye glasses draws attention to the cheekbones
### The con of cat-eye glasses for a square face is as follows:
* Cat-eye glasses angular and sharp ending on the rims of the glasses add to the more intimidating, strong
features of the square face shape.
Do cat-eye glasses suit a square face?Cat-eye glasses suit a square face because they heighten the shape's most attractive features while downplaying a square face's more intimidating shapes.
[](https://oscarwylee.com.au/toby-optical.html)
[](https://www.oscarwylee.com.au/mona-optical.html)
[](https://www.oscarwylee.com.au/ana-optical.html)
[](https://oscarwylee.com.au/toby-optical.html)
[](https://www.oscarwylee.com.au/mona-optical.html)
[](https://www.oscarwylee.com.au/ana-optical.html)
## What are the Best Glasses Colours for Square Faces?
The best colour glasses for square faces depends on multiple factors, such as the frames, the skin tone of the square face, eye colour, hair colour and hair style. A square face’s most defining features are its sharp and bold features, it’s strong cheekbones and its angular shape. The best colours for glasses for a square face shape must be&nbsp;bright and lighter colours if the intention is to dull and softer the square faces sharper features, or the colours must be bold and dark to highlight the square faces more striking features.
Book in to have your eyes tested at Oscar Wylee
Book an eye test with our Oscar Wylee optometrists, bulk billed for eligible
Medicare card holders.
[Book an eye test](https://www.oscarwylee.com.au/booking)
## What are the Best Glasses Styles for Square Faces?
The best glasses styles for a square face are&nbsp;glasses, browline glasses, square glasses, aviator glasses, crystal glasses and cat-eye glasses.&nbsp;These glasses heighten or draw forward the square face shape into bolder features.
[](https://www.oscarwylee.com.au/drew-optical.html) [](https://www.oscarwylee.com.au/marco-optical.html)
[](https://www.oscarwylee.com.au/taku-optical.html) [](https://www.oscarwylee.com.au/juniper-optical.html) [](https://www.oscarwylee.com.au/soma-optical.html)
[](https://www.oscarwylee.com.au/lincoln-optical.html) [](https://www.oscarwylee.com.au/jinky-optical.html)
[](https://www.oscarwylee.com.au/drew-optical.html)
[](https://www.oscarwylee.com.au/marco-optical.html) [](https://www.oscarwylee.com.au/taku-optical.html) [](https://www.oscarwylee.com.au/juniper-optical.html) [](https://www.oscarwylee.com.au/soma-optical.html)
[](https://www.oscarwylee.com.au/lincoln-optical.html) [](https://www.oscarwylee.com.au/jinky-optical.html)
### What are the Best Glasses Types for Women with Square Faces?
The best glasses types for women with square faces are&nbsp;browline glasses, cat-eye glasses and round glasses.&nbsp;These glasses bring out the square face’s best attributes, softening any edges or angular lines that can interfere with the shape's beauty.
[](https://www.oscarwylee.com.au/hunter-optical.html)

 


[](https://www.oscarwylee.com.au/aries-optical.html)
[](https://www.oscarwylee.com.au/bentley-optical.html)
[](https://www.oscarwylee.com.au/mona-optical.html) [](https://www.oscarwylee.com.au/haskell-optical.html)
[](https://www.oscarwylee.com.au/hunter-optical.html)

 


[](https://www.oscarwylee.com.au/aries-optical.html) [](https://www.oscarwylee.com.au/bentley-optical.html)
[](https://www.oscarwylee.com.au/mona-optical.html) [](https://www.oscarwylee.com.au/haskell-optical.html)
### What are the Best Glasses Types for Men with Square Faces?
The best glasses types for men with square faces are&nbsp;square glasses, aviator glasses and browline glasses.&nbsp;These glasses give a square face a powerful and strong profile without compromising the shape's softer features.
[](https://www.oscarwylee.com.au/hugh-optical.html) [](https://www.oscarwylee.com.au/atomix-optical.html)
[](https://www.oscarwylee.com.au/marco-optical.html) [](https://www.oscarwylee.com.au/serge-optical.html) [](https://www.oscarwylee.com.au/deus-optical.html)
[](https://www.oscarwylee.com.au/arnaud-optical.html) [](https://www.oscarwylee.com.au/taku-optical.html)
[](https://www.oscarwylee.com.au/hugh-optical.html)
[](https://www.oscarwylee.com.au/atomix-optical.html) [](https://www.oscarwylee.com.au/marco-optical.html) [](https://www.oscarwylee.com.au/serge-optical.html) [](https://www.oscarwylee.com.au/deus-optical.html) [](https://www.oscarwylee.com.au/arnaud-optical.html) [](https://www.oscarwylee.com.au/taku-optical.html)
## What are the Best Sunglasses for a Square Face?
The best sunglasses for a square face are&nbsp;round sunglasses, aviator sunglasses, cat-eye sunglasses and browline sunglasses.&nbsp;Sunglasses for a square face shape should be rounded, non-linear and not have sharp angles. Sunglasses for square face shape should not just match the facial attributes, but also be well suited for the tinting of the sunglasses and match the fashion and function that sunglasses uniquely have. The following are the best sunglasses for a square face:
* Round sunglasses: Round sunglasses for a square face contrast the intense angles of the face shape, creating a gentler profile.
* Aviator sunglasses: Aviator sunglasses for a square face have tear shape lenses, adding roundness to the square shape. They are also a classic and trendy design that greatly suits sunglasses.
* Cat-eye sunglasses: Cat-eye sunglasses for a square face adds spherical shape to the face. Cat-eye sunglasses also strengthen the browline.
* Browline sunglasses: Browline sunglasses for a square face adds attractive definition to the square faces eyebrows and cheekbones.
## What are the Glasses that are not Good for a Square Face?
The glasses that are not good for a square face are&nbsp;glasses that are too blocky or angular, or too wide and long for the face.&nbsp;These types of glasses add too many linear and sharp lines to the face, resulting in an unattractive appearance. Glasses that are too big for the face shape draw too much attention away from the face's attractive features. The following glasses shapes are not suitable for a square face:
* Oversized frames: Oversized frames for a square face negatively affect the shape's good balance and symmetry.
* Block and angular frames: Block frames overemphasise the square faces' sharp features, creating an attractive and intimidating appearance.
## What are the Prices of Glasses for Square Face Shape?
A standard pair of prescription glasses at Oscar Wylee start from $169. Customers may also purchase two pairs for $199 or three pairs deals for $249.
### Where to buy glasses for square faces?
At Oscar Wylee, we have a wide range of glasses suitable for square shaped faces. Find rectangle glasses, cat-eye glasses and aviator glasses with a great selection of colours and add-ons in-store or&nbsp;[online](https://www.oscarwylee.com.au/).
## How to Understand whether you have a Square face or not?
To understand whether you have a square face, you need to measure the face and consider
the facial features. On a square face shape, the measurements of the face, forehead, jawline and cheekbones are
all similar. Square faces seem flat from a certain angle, and the jawline and forehead are more pronounced than
the other features of the face, whilst still sharing a similar measurement. A square face has little roundness
and many angles in its shape. The way to measure your face to find out if it is square shaped, is explained
below.
1. Measure Face Length: On a square face, the face's length can be of any size. The length however should
still be even with the other measurements
2. Measure Forehead Width: On a square face, the foreheads width is similar or exactly the same as the face's length.
3. Measure Cheekbone Width: On a square face, the cheekbone's width is slightly longer than the face's other attributes but still shares very similar measurements.
4. Measure Jawline: A square face shape is defined by its strong, powerful and angular jawline.
## How to Choose Best Glasses for Different Face Shapes?
To find the best glasses for different face shapes, it is advisable to look up the features of that face which can be done using a [face shape guide](https://www.oscarwylee.com.au/face-shape-guide.html) for glasses. These facial features include things a person may want to highlight or correct. The best glasses for these shapes highlight or contrast these features to create a more balanced face. For square faces, glasses must contrast or compliment the shapes' angular, linear and wide facial features. To find the best kind of glasses to suit a specific face shape, the following actions are recommended:
1. Search for the positive and negative features of the face shape.
2. Find out the type of glasses that bring forward the positive traits and prevent or downplay the negative ones.
3. Walk to a store, online or in person to find the most fitting frames colour and style.
4. Look for a staff or an online forum recommend a style similar to the one desired
5. Judge the chosen glasses once they have been purchased, or tried on in-store.
Need a new pair of glasses?
Shop our range of stylish frames, inspired by vintage and modern designs, online or
in-store.
[Shop glasses](https://www.oscarwylee.com.au/glasses.html)
## What are the Other Accessories for Square Faces along with Glasses?
Other accessories for a square face include earrings, necklaces and hats. Accessories for a square face must be selected carefully and match the faces positive attributes or else the faces features may be tampered with and be less attractive.
Earrings for a square face shape should be rounded and spherical in shape. Earrings for square faces should be long and oversized. Earrings that are wide, angular or square create a less attractive overall profile. Necklaces for square faces should be long and collar length, including chokers. Hat’s for square faces should be wide brimmed, including derby hats, fedora’s and berets. Square face hats should sit high on the head or at an angle. Hat’s that do not suit&nbsp; a square face include short brimmed or brimless hats, flat top hats or angular hats.
## Do the Best Glasses for Square Faces Change from Year to Year?
The best glasses for square faces do not change from year to year. The best glasses for square faces in 2022 including round glasses, browline glasses, square glasses, aviator glasses, crystal glasses and cat-eye glasses, are timeless classics that retain an air of trendiness no matter what the current fashion style is.
## Example Images of People with Glasses for Square Faces
Browline glasses for a square face
Cat-eye glasses for a square face
Round glasses for a square face
Browline glasses for a square face
Cat-eye glasses for a square face
Round glasses for a square face
## What are the Other Face Shapes for Glasses Besides Square?
There are many types of face shapes besides square, each with their own group of frames that are the most suitable for that face type. The four most common face shapes besides square include&nbsp;round, pear, oval and diamond.&nbsp;The best glasses for these face shapes are listed below.
* Round face: A round face shape refers to a face that is spherical in appearance, with gentle features and rounded lines. Round faces also have full cheeks and wide cheekbones. The[best glasses for a round
face](https://www.oscarwylee.com.au/glasses/face-shapes/round)are rectangle glasses, square glasses and geometric glasses. These glasses suit a round face shape because they are angular and wide, giving the face greater contouring and contrast.
* Pear face: A pear-shaped face has a tapered forehead, with cheekbones wider than the forehead and a full jawline. The&nbsp;[best glasses for a pear-shaped
face](https://www.oscarwylee.com.au/glasses/face-shapes/pear)&nbsp;are cat-eye glasses, rectangle glasses and round glasses. These glasses are good for this face shape because they balance out the jawline, draw attention to the eyes and add width to the forehead.
* Oval face: An oval face shape refers to a round and lengthy face that is longer than it is wide. The&nbsp;[best glasses for an oval
face](https://www.oscarwylee.com.au/glasses/face-shapes/oval)&nbsp;are rectangle glasses, square glasses and aviator glasses. These glasses add width to the oval face and highlight the faces naturally good balance.
* Diamond face: A diamond face refers to a face that has a sharp chin, prominent cheekbones, a narrow forehead and a powerful bone structure. The[best glasses for a
diamond
face](https://www.oscarwylee.com.au/glasses/face-shapes/diamond)are round glasses, oval glasses and cat-eye glasses. These classes help soften the sharp and precise features of the face shape.
Read Best Glasses for Square Face (Male and Female): Frames, Shapes and Types in other
Oscar Wylee regions and their languages.
Australia
[Australia](https://www.oscarwylee.com.au/glasses/face-shapes/square)
[New Zealand](https://www.oscarwylee.co.nz/glasses/face-shapes/square)
[Canada](https://oscarwylee.ca/glasses/face-shapes/square)
[Canadian French](https://oscarwylee.ca/fr/glasses/face-shapes/square)
Canadian French
Ready For an Eye Test?
Book an eye test at Oscar Wylee, bulk billed for if you are an eligible Medicare Card
holder.
[Book an eye test](https://www.oscarwylee.com.au/booking)
Find an Oscar Wylee Store Near You
Our friendly team can help you shop our range of stylish and affordable frames.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)