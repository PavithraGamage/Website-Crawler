# Source: https://www.oscarwylee.com.au/locations/optometrist-tweed-city.html

# Optometrist Tweed City
Tweed City Shopping CentreShop 47, 54 Minjungbal DrTweed Heads South NSW 2486
* Near Kmart
Opening hours
Monday9:00am - 5:30pm
Tuesday9:00am - 5:30pm
Wednesday9:00am - 5:30pm
Thursday9:00am - 6:30pm
Friday9:00am - 5:30pm
Saturday9:00am - 4:00pm
Sunday10:00am - 3:00pm
*Store hours reflect local standard trading hours and exclude public holidays
[Visit our Tweed City Google Business page for directions, reviews, and updates.](https://g.page/r/CeJ2IhAEq8McEBM)
Book Appointment
[Call us: (07) 5645 7565](tel:(07) 5645 7565)
[Leave a Review!](https://g.page/r/CeJ2IhAEq8McEBM/review)
Our Reviews
Carly Lancaster
1 day ago
Terry Roux
4 days ago
Everything was perfect  thankyou .
XxPreppy_ Blissxx
1 week ago
Great experience thank you!
Vicki Kenzig
1 week ago
Staff very friendly and very helpful would gladly share my experience with other friends an family m...embers.  Best experience I've ever had. Thanks Oscar Wylee.
See more
Girlie Taia
2 weeks ago
Very pleased with my appointment and staff are amazing... Thank you so much
John Roberts
2 weeks ago
Very friendly staff, affordable prices. Thankyou so much.
Peter Cullen
3 weeks ago
A good experience, updating my glasses here. Vicki was efficient and very helpful, with colours and ...frame shapes to suit my face. Thank you! Liz Cullen
See more
kelly Rositano
4 weeks ago
The optometrist is absolutely amazing
Maureen Durney
4 weeks ago
Yesterday, I had the absolute pleasure of meeting two amazing ladies at Oscar Wylee Tweed City. I ha...d come in search of new frames for my prescription glasses, but I had no idea exactly what I wanted. I was met by Vicki as soon as I walked in and she immediately put me at ease. I don’t know about you, but I find the process of getting new glasses a bit stressful. Vicki was refreshingly honest in her opinion of which frames looked best. Just when I thought I’d found the right ones, Vicki said ‘wait a minute, I have one more that I want you to see’. It was love at first sight! The frames were exactly what I wanted without even knowing what I wanted. And that’s when the lovely Rachel joined us to confirm that the frames were a great choice. I have never felt more comfortable when grappling with the big decision of which frames to buy. I walked out of the store with two new friends and an amazing pair of graduated lens glasses on order. I can’t wait to get them. Thank you Vicki and Rachel for making my first order with Oscar Wylee so special. You are both amazing! And thank you Oscar Wylee for employing such amazing ladies to guide me through the minefield of buying the right frames. I already had my prescription this time, but next time I’ll start the whole process in this store. Thank you Vicki and Rachel ❤️❤️
See more
Rich jensen
4 weeks ago
Great prices and quick and easy to deal with
Lauren Sing
1 month ago
Carole Manley
1 month ago
I have been going to a different brand for many years but thought I would try an alternative I am ve...ry glad I did the service the choice and the cost 100% better thank you
See more
Julie
1 month ago
Brilliant staff! Vicki was incredibly helpful in helping me choose new sunglasses and everyday glass...es. She was honest with her advice and made sure I found frames that genuinely suited me. She’s fantastic at her job, thank you!
See more
chetan parekh
1 month ago
Personally I'm not a huge fan of product after 1st &amp; last experience with pair of reading glasses. C...heap product way expensive prices. However customer service from Bruno (pacific fair Oscar Wylee) was extraordinary. Thursday night 8:55pm she's about to shut the door and I asked favour to fixing left side of the glass screw came off. She welcome me with smile and fixed broken glasses without saying sorry store closed.
See more
samara stepanenko
1 month ago
I had to change my review because the lens i ordered are not working, they offered me office lens bu...t the lenses they made just work for a very short distance I cannot look up look side ways or anywhere rather than 30cm further. I am a receptionist I cant not even look to ppl faces, I picked up a big frame just because I thought they will put the prescription down and ill have nothing up but I am about to throw up when I look ahead.
See more
Simone Mulheron
1 month ago
Such a friendly and helpful team! The ladies there went above and beyond!
Maighsi Bryant
1 month ago
Lovely customer service, Vicky was an angel. So pleased with my new glasses! Thank you Oscar Wylee.
James Mayne
1 month ago
Lee was Awesome
Made the whole experience easy
Did it on a Sunday with the family
Four of us done in... 90 mins
Thank you Lee
See more
Jimmy Harry
1 month ago
Amazing, I had never had an eye test before and the ladies were absolutely fabulous
Emma
1 month ago
All staff were amazing and friendly. Eye checks for both my daughter and I. Great range of frames.
Brooke Kerr
1 month ago
Super helpful and efficient. I was in a rush and they just kept cool, worked out everything I needed... and welcomed me to return when I had more time.
See more
brendan white
1 month ago
The optometrist was very knowledgeable and friendly. Would highly recommend. The staff behind the co...unter was very nice also.
See more
malcolm McLeod
1 month ago
I work as a conference speaker for corporate events, have done many of your competitors store manage...r conferences, over many years, never for your company.
My partner used your Tweed Heads store a few years ago &amp; recommended I try you out &amp; now I feel like a family member every time I walk in the store or walk past
Rachelle is exceptionally friendly, knowledgeable &amp; efficient &amp; Fiona, the optom the same.
Love your variety of product options, price but it’s your people that have Anna &amp; I as now long term fans
Don’t tell my other optical clients!
See more
Ingrid Lundstrom
1 month ago
The optometrist was thorough with her tests and explained the results clearly. Overall a satisfactor...y examination.
See more
Warren Saxby
1 month ago
staff were efficient and pleasant
Lisa Galea
1 month ago
The care and expertise shown by all team members in the store was fantastic.
Ian Duff
3 months ago
mark rabjones
3 months ago
Easy online booking and friendly helpful staff.
Jane Manson
3 months ago
The staff were very pleasant helpful polite respectful great knowledge. Answered my questions fully ...and easy to understand.
I fully recommend them.
May great Happiness fill you all Forevermore allowing you to share it with all your clients.
Cheers ????????????  Jane
See more
Kim Newling
3 months ago
Great experience with the team at Oscar Wylee. Great deal on 3 pairs of readers all covered by HCF. ...Highly recommend.
See more
Niel Mackay
3 months ago
Excellant
Jan Roberts
3 months ago
Narelle Hodges
3 months ago
I had a wonderful experience at Tweed City OW. It was my first time getting glasses at this particul...ar store but my 4th time getting new specs. I have been to other optometrists in the centre and just been told to find the frames I want and let them know. At OW, Rachel was so helpful and friendly and walked around with me, giving me advice on colours and frames. I’m extremely grateful for her guidance.
See more
peter Jan van Batenburg
3 months ago
All good,on time and friendly experience.
Thank you.
Ma Di
4 months ago
Had the pleasure of visiting the Tweed City centre. So glad I went. Fantastic, friendly service and ...easy booking online too. The optometrist. thankfully, identified the need for me to see a specialist and  so very grateful for that as well. Highly recommend.
See more
Georgie Taylor
4 months ago
Experienced and friendly staff, made the whole appointment easy and comfortable. All of the consulta...nts and the Optometrist, Fiona, were helpful and I felt comfortable with all aspects of the appointment.
I would happily recommend the Oscar Wylee team at Tweed City to assist with anyone's eyecare requirements.
See more
Michelle Cawthorne
4 months ago
The staff are friendly relaxed and helpful
Milton Quigley
4 months ago
Professional and helpful optometrist and staff.
Margo Robertson
4 months ago
Staff were great but the pricing structure is very misleading
Sue and Malcolm Dorey
4 months ago
Excellent customer service from the team at Oscar Wylie in Tweed Mall.
Leanne Noble
5 months ago
Booking Easy!! Appointment minimal waiting and went smoothly!! New glasses choice- excellent showed ...my old glasses said I wanted something a little different and bolder. 2 new frames chosen in under 5 minutes!!! First time at Oscar Wylee and will definitely be back
See more
brea serone
5 months ago
I had such an amazing experience at Oscar Wylee! The team were incredibly helpful in guiding me thro...ugh finding the perfect new pair of glasses, and I couldn’t be happier.
A special thank you to Lee, who was absolutely lovely. She was so bubbly, warm and easy to chat to, and really took the time to help me choose frames that suited my face. She made me feel completely confident and comfortable in my choices, which made the whole experience so enjoyable.
I walked out feeling refreshed, excited and counting down the days until my new glasses arrive. Highly recommend!
See more
Cyr Pilapil
5 months ago
The staff are friendly and professional.
Nicole
5 months ago
Had a really pleasant experience ☺️
The 2 ladies at the front counter were so kind, gentle and patie...nt when it came to choosing frames, explaining the cost and the benefits of blue light + polarised lenses.
The optometrist was also so kind and was very honest with her responses after my questions which I really appreciate.
The Optometrist was very thorough and gave me so good feedback.
Overall - highly recommend ????
See more
Keelz Boreham
5 months ago
Rachel ( i think the manager) is amazing she really helped me even via the phone with my predicament... with my prescription.  Everyone involved was very kind and helpful.
everyone was awesome and personalised and very helpful very pleased with Oscar wylie. And all the team members ☺️ thank you so much!
See more
ma angelica martha m. carballo
5 months ago
Lisa
6 months ago
Jennifer Butler
6 months ago
Candice Davis-Taylor
6 months ago
From the moment I arrived to the time I left was a great experience,all the lady’s were lovely and k...nowledgeable. I couldnt be more happy with my experience,thank you.
See more
Michelle Dermody
6 months ago
The optometrist was able to answer all the questions I had regarding my degenerating eye sight with ...clear responses. I was fitted for two pairs of basic reading glasses - no frills sale. I was attended to by two store assistants who were extremely busy but very polite and considerate. One was in training making the job of the experienced worker all that much harder on a busy Saturday morning. They did brilliantly.
See more
## Find an Optometrist in Tweed City With Oscar Wylee
Our Oscar Wylee store is located in Tweed Heads’ Tweed City Shopping Centre and is close to areas such as Coolangatta and Banora Point. In our eyeglasses shop, we offer eye tests for same-day prescriptions and a variety of different glasses frames and lenses to suit your needs. Our eye tests at Oscar Wylee Tweed City are bulk billed through Medicare meaning there are no out-of-pocket costs. 
We offer both prescription and non-prescription eyewear with an option for polarised sunglasses or simply clear frames. The Tweed City shopping centre is an Indoor mall with big chain retailers, fashion boutiques, an ample food court and a movie theatre. Located on the Tweed River in northeastern New South Wales, there is much to do in Tweed Heads after your Oscar Wylee appointment such as exploring the scenic beaches that run along the coast. We can diagnose eye diseases and eye conditions! Come visit our capable team at Oscar Wylee Tweed City for all the essential eye care services.        
Meet Our Team
* Store Manager
Certificate IV in Optical Dispensing
Our Services
* Bulk Billed Eye Examinations
* Professional Frame Styling
* Frame Adjustments and Repairs
Show All
## Find an Optometrist in Tweed City, NSW for an Eye Health Test
An optometrist in Tweed City, NSW has eye health services available such as an eye health test in Tweed City. We have a wide selection of frames for prescription sunglasses or prescription glasses for any and every occasion. You can have your eyes tested at a bulk billed price courtesy of Australia’s Medicare system. Eye tests are paramount for the early detection of eye diseases and making sure everything is in order with your vision. Our optometrist is highly qualified in diagnosing and treating a range of minor eye conditions and typically follows the procedure of conducting several tests to check different regions of the eye. If we think you need an eye doctor, we’ll be happy to refer you to one in the area.
The average price for an optometrist in Tweed City may depend on factors such as the number of other optometrists in Tweed City, the facility they operate in and the required equipment.
## How to Find an Optometrist in Tweed City, NSW?
To find an optometrist in Tweed City, NSW you can take certain steps that can help make it easier for you such as searching online, assessing the store’s opening hours and finding the directions to your chosen location. The steps on how to find an optometrist in Tweed City are listed below.
1. Search online using the phrase, Tweed City optometrist near me. This can also be done here on the website via our locations page.
2. Click on the Oscar Wylee link, which will take you directly to our Tweed City optometrist store page.
3. See the store’s opening hours and where the store is located specifically.
4. Use the Tweed City Google Business page link located under store hours to see the directions on how to get to the store.
You can also find an optometrist in Tweed City by searching the keywords optometrist near me. If you have locations enabled on your smartphone and you’re in the Tweed City area, our Tweed City store page should appear easily for you to click on.
### Is it Hard to Get an Eye Appointment in Tweed City, NSW?
No, it is not hard to get an eye appointment in Tweed City. You can easily book an appointment to see an Oscar Wylee optometrist in Tweed City right here on this page. At Oscar Wylee we have highly qualified optometrists available for bulk billed eye appointments, which can be booked online or in-store.
#### How to Compare Optometrists in Tweed City to Each Other?
To compare optometrists in Tweed City, you can use factors such as eye tests offered, health fund coverage, lens types and add-ons and eyewear offered. To take care of your vision and eye health, it is important to receive an eye test at least once every two years. There are different types of tests that can be performed in an eye test and not all optometrists may offer the same tests. Health funds can be used to help cover some of the cost of your frames and lenses. To find out if your health fund is accepted at Tweed City optometrist in NSW, visit their website. In the case of Oscar Wylee, we accept all major health funds and provide on-the-spot claims in-store. There are many different lens options available for prescription glasses such as single vision, multifocal and high index lenses. Most optometrists in Tweed City will offer these lenses although it is good to make sure. There are also lens add-ons available to enhance your glasses such as anti-reflective and blue light filters. Finally, if you are looking to purchase a pair of glasses after your eye test, you can compare the different styles and colours you are interested in from Tweed City optometrists in NSW. Oscar Wylee offers a wide range of frames with vintage and modern inspirations in bold colours and subtle designs.
#### How to Find an Eyeglasses Shop in Tweed City, NSW?
To find a glasses store in Tweed City, you can try to follow these simple steps including searching online, selecting a convenient location and looking at their health insurance policies. The steps on how to find a glasses store in Tweed City, NSW are listed below.
1. Search online using the phrase, glasses store in Tweed City. This will provide you with various options for glasses stores in the whole area of Tweed City.
2. Select a glasses store that is most convenient for you to travel to.
3. Click the link to find out more information such as opening hours, exact location and directions to the glasses store in Tweed City.
4. Read their health insurance policies to ensure you know what health benefits you have access to.
Our Oscar Wylee glasses store in Tweed City, NSW offers primary eye care services such as comprehensive eye tests as well as other services performed by an optometrist and offers prescription and non-prescription eyewear.
##### Is it Possible to Purchase Prescribed Sunglasses in Tweed City, NSW Without Seeing an Optometrist?
Yes and no, it is possible to [purchase prescribed sunglasses](https://www.oscarwylee.com.au/sunglasses.html) in Tweed City, NSW without seeing an optometrist if you already have a prescription that has not expired. If your prescription is expired, you can book an eye test to receive an updated or new prescription which will require you to see an optometrist. This will ensure your prescription sunglasses are appropriate for your visual needs.
## Where is the Oscar Wylee Tweed City Optometrist in NSW Located?
The Oscar Wylee Tweed City optometrist is located at the Tweed City Shopping Centre, which is located at 54 Minjungbal Drive. The Oscar Wylee Tweed City store can be found near Kmart.
### What is the Phone Number of Oscar Wylee Tweed City Optometrist Store?
The Oscar Wylee Tweed City optometrist store phone number is [(07) 5645 7565](tel:(07) 5645 7565). You can contact the Oscar Wylee Tweed City store between the hours of 9 am and 5:30 pm on Monday, Tuesday, Wednesday and Friday, on Thursdays between 9 am and 6:30 pm, on Saturdays between 9 am and 4 pm and on Sundays between 10 am and 3 pm.
### What are the Reviews for Oscar Wylee Tweed City Optometrist in NSW?
The many reviews for Oscar Wylee Tweed City optometrist in NSW, left by our various customers can be found here on the website and online when you search for Oscar Wylee Tweed City optometrist. The reviews for Oscar Wylee Tweed City optometrist are listed below.
* Chaz Online:  Good customer experience.
* Colin Hinds:  Great service and prices, lovely helpful staff. Highly recommended.
* Sue Atkins:  Lovely people, great experience.
* Katie O’Rourke:  The OW team at Tweed City are lovely and professional, both when having my eyes tested, and when I am searching for the perfect pair of glasses.
* Ann McCormack:  Very kind and helpful staff, in fact the most conscientious staff I have ever experienced during many years of eye tests. Thank you so much.
#### What Treatments or Eye Care Processes are Done in the Oscar Wylee Tweed City Optometrist Location?
The treatments or eye care processes done in the Oscar Wylee Tweed City optometrist NSW location include a tonometry test, a slit lamp exam and a refraction test. Additional tests that may also be performed can include a dilated fundus exam. The treatments or eye-care processes that are done in the Oscar Wylee Tweed City optometrist NSW location are listed below.
* A Tonometry Test: An optometrist or optical dispenser will conduct a tonometry test which involves the use of a machine that will release small puffs of air into your eyes. This will assist with measuring pressure in the eye.
* Slit Lamp Test: A slit lamp test can be used to evaluate your eye health, by examining your cornea and iris which are the anterior and posterior of the eye.
* Refraction Test: During a refraction test, an optometrist will have you view an image through different lenses and ask you to confirm which helps you see the image clearer.
* Dilated Fundus Exam: A dilated fundus exam can help an optometrist assess your health in more detail by getting a clear view of the retina. This test is typically carried out for patients with diabetes and those who may be at risk of developing retinal damage.
## How Many Optometrists Exist in Tweed City, NSW?
Many Oscar Wylee optometrists exist in Tweed City, NSW to provide eye tests and glasses, including Oscar Wylee. The number of optometrists in Tweed City may be due to the number of residents in the area and the geographical size of the suburb. If you need essential eye services such as a comprehensive eye test, a wide selection of prescription eyewear and more, then choose Oscar Wylee as your first choice for optometry services.
### What are the Other Closest Optometrist Locations to Tweed City, NSW in Australia?
There are no other Oscar Wylee optometrist locations close to Tweed City in Australia, however, we have many stores in New South Wales, Queensland, Western Australia and Victoria. If you are looking for an optometrist near you, you can find the locations of our many stores on our [full store locations page](https://www.oscarwylee.com.au/locations/full-store-list.html).
### Bulk billing at Oscar Wylee Tweed City
Our Oscar Wylee Tweed City store provides eye health tests and vision testing which are available for bulk billing as part of the Australian Medicare system. Our optometrists at Oscar Wylee Tweed City are capable of conducting your regular eye tests, updating your prescription or issuing you a new one if needed. Our team and optometrists run high-quality eye care processes, so make our store your first choice to receive excellent optometry services.
### Health Funds Accepted at Oscar Wylee Tweed City
Here at Oscar Wylee Tweed City, we accept major health funds. You’ll just need a valid health fund card and our staff at Oscar Wylee Tweed City can easily process your health fund claim at our eyeglasses shop. We can also walk you through each step of your health fund so we can see to it that you’re getting the best price for your prescription glasses needs.
### Fashionable Frames to Suit Your Style
Visit Oscar Wylee if you’re in search of prescription glasses or prescription sunglasses that are vintage or modern-inspired. You can also add an anti-reflective coating, a blue light filter, and more. Our experts at Oscar Wylee Tweed City will help you choose what’s best for you, and you’ll leave our store with a pair of prescription glasses or prescription sunglasses that will look and feel specifically made for you. So make Oscar Wylee Tweed City your go-to for high-quality eye care services
Book Appointment
[Call us: (07) 5645 7565](tel:(07) 5645 7565)
[Leave a Review!](https://g.page/r/CeJ2IhAEq8McEBM/review)