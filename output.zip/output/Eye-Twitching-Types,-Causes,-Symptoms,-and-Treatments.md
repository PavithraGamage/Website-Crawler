# Source: https://www.oscarwylee.com.au/glasses/eye/twitching-definition

# Eye Twitching: Causes, Symptoms, and Treatments
Updated on on June 4th, 2026
Published on March 14th, 2023
Australia
[Australia](https://www.oscarwylee.com.au/glasses/eye/twitching-definition)
New Zealand

[Canada](https://oscarwylee.ca/glasses/eye/twitching-definition)
[Canadian French](https://oscarwylee.ca/fr/glasses/eye/twitching-definition)
Eye twitching, also known as eyelid myokymia, is
an eye condition that causes the eyelid to spasm and twitch
sporadically. Eye twitching is a term used to describe muscle spasms that occur in the
eyelid and can be categorised into three main types: eyelid myokymia,
blepharospasm and hemifacial spasm. The common causes of an eye twitch
include stress, fatigue, too much caffeine, eye strain, dry eyes,
nutritional deficiencies, and light sensitivity. The symptoms associated
with eye twitching may include eye irritation, vision problems and facial
spasms. Eye twitching treatments include rest, drinking less caffeine, and a
low-stress lifestyle in some cases, and for other types, surgery or eye
injections may be prescribed.
It is important to note that Oscar Wylee offers optometry services only;
this article is for educational purposes only and is not a substitute for
professional medical advice, diagnosis, or treatment.
Prioritise Your Eye Health
Our team can help you stay up to date with regular eye tests to keep your
eyes healthy!
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Definition](#definition)
[Causes](#causes)
[Symptoms](#symptoms)
[Treatments](#treatments)
[Prevention](#prevention)
[Commonly Confused Conditions](#confused)
## What is Eye Twitching?
Eye twitching
can be defined as both an eye condition in itself and a symptom of
other eye conditions. The occurrence of eye twitching may be categorised into different
types, and eye twitching describes the general occurrence, which is the
rippling contractions of the eyelid, most often the lower one. When eye
twitching is mentioned, or people ask what eye twitching is, it is most
often in relation to eyelid myokymia, as it is the most common and
general form of eye twitch.
Eyelid myokymia is a very common yet generally benign condition that
may be caused by stress, fatigue and caffeine,
according to Abd Alkader, Jafer Chardoub, and Bhupendra C. Patel's
research article titled 'Eyelid Myokymia', published in 2023. Occasional
eye twitching is different from chronic eye twitching, where the spasms
are frequent and persistent. Chronic conditions that can cause eye
twitching include Benign Fasciculation Syndrome, neurological disorders
and systemic diseases.
### What are the Different Types of Eye Twitching?
There are three main types of eye twitching:
eyelid myokymia, blepharospasm and hemifacial spasm.
These types of eye twitching and their definitions are listed below.
* Eyelid myokymia: Myokymia is the
most common type of eye twitching and is a benign eye condition
brought on mainly by stress and fatigue.
* Benign Essential Blepharospasm (BEB): This type of eye twitching is defined as uncontrollable eye
movements, such as blinking and twitching.
* Hemifacial Spasm: This type of eye
twitching is a nervous system disorder that causes the muscles on
the side of the face to twitch, including the eye.
## What are the Causes of Eye Twitching?
There are many different causes of eye twitching, which can often be
solved through lifestyle changes. The main causes of eye twitching
include
stress, fatigue, too much caffeine, eye strain, dry eyes, nutritional
deficiencies, and light sensitivity. Some causes of eye twitching and their definitions are listed below.
* Stress: Stress is the most common
cause of eye twitching and often manifests as sporadic spasms.
* Fatigue: Fatigue may be the reason
your eye is twitching.
* Too much caffeine: Too much caffeine
is known to cause eye twitching as it overstimulates the nervous
system, making your eyes twitch.
* Eye strain: When muscles are
overworked, they can twitch, which can also occur in the eyes when you
are straining your eyes.
* Dry eyes: Dry eyes can cause eye
twitching due to irritation and poor surface lubrication, leading to
excessive blinking, which can overstimulate the eyelid muscles.
* Nutritional deficiencies: Nutritional
deficiencies can disrupt nerve and muscle function, potentially
leading to eye twitching.
* Light sensitivity: Light sensitivity
and eye twitching often occur together.
### 1. Stress
Stress is
a common cause of eye twitching, especially eyelid myokymia. Stress may cause a sporadic spasm that is not harmful and will
usually go away within a few days. Having a low-stress lifestyle,
while not always easy, is a solution to this. Stress can be reduced
through meditation, body movement and breathing exercises, which may
reduce or prevent eye twitching. Stress can not only cause eye
twitching, but it can also manifest as other health problems.
### 2. Fatigue
Fatigue caused by insufficient sleep can often trigger eye twitching
as
the body does not have enough time to rest and recover
from the previous day. According to Good Vision for Life, an Optometry
Australia initiative, insufficient sleep can cause eye twitches or
spasms as well as other eye-related symptoms such as blurry vision,
dry eyes and sensitivity to light due to eye fatigue. The eyes may
twitch when a person is tired, as the neurotransmitters in the brain
that control muscle movement are affected due to fatigue, leading to
eye twitching. Prioritising 7-9 hours of sleep at night can be
extremely beneficial not only for eye twitching but also for overall
health.
### 3. Too much caffeine
Too much caffeine can increase your risk of eye twitching, as
it is a stimulant that can cause involuntary muscle movement that
can occur in many places on the body, including the eyelids. Caffeine also tires out the eyes due to the extra stimulation.
Reducing your intake of caffeine can prevent and limit your eye
twitching. Caffeine is not only present in coffee but also in tea and
soft drinks.
### 4. Eye strain
Eye strain is a known cause of eye twitching.
If your eyes are focusing for long periods of time on certain
tasks, such as computer work, it can put a strain on your eyes,
causing the muscles to spasm and twitch.
[Strained eyes](https://www.oscarwylee.com.au/glasses/eye/strain)
may also be the result of uncorrected vision problems; therefore,
prescription glasses are a possible treatment for eye twitching as
they correct your vision and allow your eye muscles to relax.
### 5. Dry eyes
[Dry eyes](https://www.oscarwylee.com.au/glasses/eye/dry-eyes)
can
trigger eye twitching as the eyelids lack lubrication, leading
people to overcompensate by blinking excessively. This, in turn, can fatigue and spasm the surrounding muscles,
leading to possible eye twitching.
### 6. Nutritional Deficiencies
Nutritional deficiencies, particularly in magnesium, vitamin B12,
vitamin D, and potassium, can lead to eye twitching. This is because specific minerals and vitamins are crucial for
correct nerve signalling and muscle contractions. When there is a
vitamin imbalance, eye twitching may occur.
### 7. Light Sensitivity
[Light sensitivity](https://www.oscarwylee.com.au/glasses/eye/light-sensitivity)
often accompanies eye twitching.
Bright lights can act as sensory triggers, leading to eye strain,
causing the eyelid muscles to spasm
and the eyes to twitch. Extra effort used to strain the eyes in bright
environments can also lead to eye twitching.
### Why Does Left Eye Twitching Happen?
Left eye twitching is
usually harmless and linked to stress, fatigue, caffeine, eye
strain, and dry eye syndrome, like general eyelid twitching, according to Dr. Yoshinori Abe. In some Asian cultures, left eye
twitching is thought to bring good fortune, but in parts of Africa and
Europe, it can be seen as a warning of bad luck. There is no
scientific link between eyelid twitching and future events, according
to Dr. Yoshinori Abe.
### Why Does Right Eye Twitching Happen?
Right eye twitching is
usually harmless and linked to stress, fatigue, caffeine, eye
strain, and dry eye syndrome, like general eyelid twitching. There is no medical difference between a left eye twitch and a
right eye twitch, as it is a muscle spasm, according to All About
Vision.
Find Your Nearest OW Store!
We've got knowledgeable teams who are passionate about delivering
high-quality care.
[Find a store](https://www.oscarwylee.com.au/locations)
## What Symptoms Can Occur Alongside Eye Twitching?
There are many symptoms people may experience as a result of eye
twitching, including
eye irritation, vision problems, facial spasms and an increased rate
of blinking. The common eye twitching symptoms and their definitions are listed
below.
* Eye irritation: Eye irritation is
often the first symptom of eye twitching and is
caused by the muscles in the eye twitching and spasming, making the eyes irritated and uncomfortable. Eye irritation may be
relieved with eye drops to add moisture to the eyes.
* Vision problems: Vision problems are a
symptom of eye twitching. The
contracting and convulsing of the eyelid muscles caused by eye
twitching can affect vision, leading to blurred vision and eye
strain. If you are experiencing vision problems alongside eye twitching,
you should see an optometrist for a comprehensive eye test so they can
assess your vision and eye health.
* Facial spasms: Facial spasms are
a common symptom of hemifacial spasms, which is a type of eye
twitching. Hemifacial spasms cause the muscles on the sides of the face to
contract or spasm involuntarily, and it is often caused by a blood
vessel pressing or pulsating on a facial nerve. Not only does this
condition cause eye twitching, but it also causes facial spasms around
the mouth. If you have any type of facial spasms, it is important to
seek medical attention.
* Increased rate of blinking: An
increased rate of blinking is
a common symptom of blepharospasm, which is a type of eye
twitching. Blepharospasm causes involuntary blinking caused by muscle spasms
in the eye. Abnormal blinking of the eye can happen multiple times
throughout the day, and this condition can also force the eyelids to
close in some cases. If this occurs, seek attention from an eye care
professional so they can recommend treatment options.
### When Should Eye Twitching Become a Medical Concern?
Eye twitching should become a medical concern
if you experience it consistently for over a week, experience lid
closure, involve other facial muscles, redness, swelling, or eye
discharge, or droopy eyelids. If you experience these symptoms along with your eye twitch, it may
be indicative of something more serious and should be further
investigated, according to the Vision Eye Institute, Australia.
## What Treatments Help Relieve Eye Twitching?
The treatments available for eye twitching vary depending on the type of
eye twitching. For eyelid myokymia, lifestyle changes can treat it,
whereas others require more involved treatment. Eye twitching treatments
include
rest, drinking less caffeine, injections and surgery.
The treatments available for eye treatment are listed below.
* Rest: Rest is important to treat eye
twitching, as fatigue is a common cause of this eye condition.
Allowing the eye muscles to relax can be very beneficial for eye
twitching.
Prioritising 7-9 hours of sleep each night may resolve an eye
twitch. It can also be helpful to take short breaks from screens and rest
your eyes, as well as create a consistent sleep schedule.
* Drinking less caffeine: Drinking less
caffeine is
an effective way to reduce eyelid twitching. Caffeine
is a stimulant that can contribute to eyelid muscle spasms, so
reducing your intake of caffeine is recommended to relieve eyelid
twitching. This includes coffee, tea, soft drinks, and energy drinks.
* Injections: Certain injections
can disrupt nerve signals to muscles and cause paralysis, which can
be used to treat eyelid twitching, according to the Better Health Channel, Victoria. Usually, multiple
injections are given to a patient above and below the eye, and the
complete effect usually takes about a week and lasts approximately 4
months, according to the Better Health Channel, Victoria.
* Surgery: Surgery for eyelid twitching,
known as myectomy, is
an operation where some or all of the eyelid and eyebrow muscles
responsible for squinting are weakened or removed, according to the Better Health Channel, Victoria. Myectomy can
improve eye twitching symptoms in up to 80% of patients, according to
the Better Health Channel, Victoria.
### How can Lifestyle Changes Reduce Eye Twitching?
Lifestyle changes, including stress management, adequate sleep, and
caffeine reduction, can reduce eye twitching effectively, according to
All About Vision. Stress is a common trigger of eye twitching. Taking
steps such as calming activities like
meditation, yoga, and deep breathing may reduce
symptoms. Aiming for 7-9 hours of sleep is also highly recommended to
reduce eye twitching.
Creating a consistent sleep schedule is an actionable
lifestyle change you can make to improve sleep quality. Reducing
caffeine intake is also recommended; perhaps
switch to decaf.
### How can Screen Habits help Prevent Eyelid Twitching?
Eyelid twitching can be triggered by digital eye strain, meaning
creating healthy screen habits can improve or prevent
symptoms. According to Irfan B. Gunes's 2024 research article titled
'Association Between Eyelid Twitching and Digital Screen Time,
Uncorrected Refractive Error, Intraocular Pressure, and Blood
Electrolyte Imbalances', a significant association was found between
increased daily digital screen time and the occurrence of eyelid
twitching. To combat this,
healthy screen habits include following the 20-20-20 rule, which involves taking a 20-second break every 20 minutes to look at
an object at least 20 feet away (about 6 metres).
Trying to consciously blink more while looking at screens
can also help prevent eyelid twitching, as well as ensure your screen
is not too close. It may also help to
dim your brightness, keeping it at the same level as your
environment.
### How do Prism Lenses Help Eye Twitching?
[Prism lenses](https://www.oscarwylee.com.au/guides/lenses/prism-glasses.html)
may help indirectly with eye twitching
by correcting misaligned eyes and reducing eye strain. While prism lenses are not a direct treatment for the twitch
itself, they help reduce the severe muscle strain caused by misaligned
eye muscles, which can often be an underlying trigger for eyelid
spasms, by properly aligning light before it enters the eye.
#### Does Wearing Blue Light Glasses Reduce Eye Twitching?
Yes and no. It is important to distinguish between prescription
glasses and non-prescription blue light filters.
While wearing blue light glasses has not been proven to directly
reduce eye twitching on its own, it may help with digital eye
strain, which is a common aggravating factor for eye
twitching. If you spend much of your time in front of a digital screen for
work or school, you may benefit from
[blue light blocking glasses](https://www.oscarwylee.com.au/blue-light-glasses.html), as they may potentially protect your eyes from artificial blue
light and reduce glare. At Oscar Wylee, we offer a blue light filter
for an additional $85 on top of a standard pair of optical glasses.
However, if your twitching is caused by an uncorrected prescription,
standard prescription lenses will be needed to truly resolve the
strain.
#### Is it Possible Eye Twitching is Caused by Contact Lenses?
Yes,
it is possible that eye twitching is caused by contact
lenses.
[Contact lenses](https://www.oscarwylee.com.au/glasses/eye/contact-lenses)
can cause eye dryness and irritation, and possibly eye strain if
your prescription is outdated. If you are experiencing eye
twitching, try switching to glasses temporarily, using lubricating
contact lens-safe eye drops, and always ensure proper hygiene when
handling contact lenses.
## How can Eye Twitching be Prevented?
Eyelid myokymia, a common type of eye twitching,
may be prevented through a low-stress lifestyle. Also,
by maintaining a healthy diet and engaging in regular exercise, you may
be able to prevent eyelid myokymia. Other forms of eye twitching, such
as blepharospasm, cannot be prevented, although the symptoms can be
managed using injections.
## What Conditions are Commonly Confused with Eye Twitching?
The conditions commonly confused with eye twitching include
blepharitis, dry eye syndrome, allergies, and neurological
disorders. See the table below for more information about these conditions.
| Condition | Symptoms | Causes | Severity | Treatment |
| --- | --- | --- | --- | --- |
| Blepharitis | * Red, swollen, or itchy eyelids
* A gritty or burning sensation
* Crusty or greasy eyelashes | * Bacterial overgrowth
* Clogged oil glands
* Skin conditions
* Dermatitis | * Mild (grittiness and redness) to severe (corneal damage,
lash loss, and deformity) | * Eyelid hygiene
* Warm compresses
* Gentle massage |
| Dry eye syndrome | * Stinging, burning, or redness
* Gritty sensation
* Excessive watering | * Aging
* Meibomian Gland Dysfunction (MGD)
* Screen time
* Medications | * Mild (episodic discomfort) to most severe (intense burning,
stickiness, corneal erosions/ulcers) | * Lubricating eye drops
* Warm compresses |
| Allergies | * Itchy, red, and watery eyes
* Swollen eyes
* Watery or gritty eyes
* Temporary blurred vision | * Immune system overreaction to environmental allergens such
as pollen and animal dander | * Mild (no daily impact) to moderate-severe (impaired sleep,
difficulty working) | * Nasal sprays
* Antihistamines |
| Neurological disorders | * Double vision
* Involuntary eyeball movements (such as nystagmus, which is
distinct from an eyelid twitch)
* Partial vision loss | * Structural, biochemical, or electrical abnormalities in the
brain, spinal cord, or nerves | * Debilitating but non-fatal (migraines, sleep disorders) to
acute and catastrophic (strokes, severe spinal cord
injuries) | * Medication
* Targeted therapies
* Psychological support
* Surgical interventions |
It is important to note that Oscar Wylee offers optometry services
only; this article is for educational purposes only and is not a
substitute for professional medical advice, diagnosis, or
treatment.
Read Eye Twitching: Causes, Symptoms, and Treatments in other Oscar
Wylee regions and their languages.
Australia
[Australia](https://www.oscarwylee.com.au/glasses/eye/twitching-definition)
New Zealand

[Canada](https://oscarwylee.ca/glasses/eye/twitching-definition)
[Canadian French](https://oscarwylee.ca/fr/glasses/eye/twitching-definition)
Experience High Quality Eyecare Services From Our Team
Book an appointment online with an Oscar Wylee optometrist today.
[Book an eye test](https://www.oscarwylee.com.au/booking)
Major Health Funds Accepted
In-store
For the purchase of frames and lenses, use your private health fund to
limit how much you pay from your own pocket.
[Explore health funds](https://www.oscarwylee.com.au/health-funds.html)