# Source: https://www.oscarwylee.com.au/glasses/clear-glasses.html

# Clear glasses
Clear frames glasses are perfect for refreshing your look. Shop Oscar Wylee clear transparent glasses collection in-store and online for a modern, stylish, yet subtle look.
44 Products        
Showing 15 of 44
1. [](https://www.oscarwylee.com.au/martha-optical.html)
[Martha](https://www.oscarwylee.com.au/martha-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/martha-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/martha-optical.html)
2. [](https://www.oscarwylee.com.au/ruthie-optical.html)
[Ruthie](https://www.oscarwylee.com.au/ruthie-optical.html)
$169
3. [](https://www.oscarwylee.com.au/odette-optical.html)
[Odette](https://www.oscarwylee.com.au/odette-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/odette-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/odette-optical.html)
4. [](https://www.oscarwylee.com.au/brosque-optical.html)
[Brosque](https://www.oscarwylee.com.au/brosque-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/brosque-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/brosque-optical.html)
5. [](https://www.oscarwylee.com.au/celeste-optical.html)
[Celeste](https://www.oscarwylee.com.au/celeste-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/celeste-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/celeste-optical.html)
6. [](https://www.oscarwylee.com.au/elodie-optical.html)
[Elodie](https://www.oscarwylee.com.au/elodie-optical.html)
$199    
[2 pairs from $249](https://www.oscarwylee.com.au/elodie-optical.html)
7. [](https://www.oscarwylee.com.au/francis-optical.html)
[Francis](https://www.oscarwylee.com.au/francis-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/francis-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/francis-optical.html)
8. [](https://www.oscarwylee.com.au/fenn-optical.html)
[Fenn](https://www.oscarwylee.com.au/fenn-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/fenn-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/fenn-optical.html)
9. [](https://www.oscarwylee.com.au/harris-optical.html)
[Harris](https://www.oscarwylee.com.au/harris-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/harris-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/harris-optical.html)
10. [](https://www.oscarwylee.com.au/luca-optical.html)
[Luca](https://www.oscarwylee.com.au/luca-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/luca-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/luca-optical.html)
11. [](https://www.oscarwylee.com.au/cyrus-optical.html)
[Cyrus](https://www.oscarwylee.com.au/cyrus-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/cyrus-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/cyrus-optical.html)
12. [](https://www.oscarwylee.com.au/peggy-s-optical.html)
[Peggy Small](https://www.oscarwylee.com.au/peggy-s-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/peggy-s-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/peggy-s-optical.html)
13. [](https://www.oscarwylee.com.au/aries-optical.html)
[Aries](https://www.oscarwylee.com.au/aries-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/aries-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/aries-optical.html)
14. [](https://www.oscarwylee.com.au/louie-optical.html)
[Louie](https://www.oscarwylee.com.au/louie-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/louie-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/louie-optical.html)
15. [](https://www.oscarwylee.com.au/peyton-optical.html)
[Peyton](https://www.oscarwylee.com.au/peyton-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/peyton-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/peyton-optical.html)
44 Products        
Showing 15 of 44