# Source: https://www.oscarwylee.com.au/glasses/eye/makeup-eye-hygiene

# 8 Tips for Eye Makeup Hygiene
Published on June 26th, 2024
Updated on March 21st, 2024  
Australia
Australia
Canada

Eye makeup hygiene is very important as it can prevent the development of eye infections such as conjunctivitis, blepharitis and styes. Applying products to the face should be done with care as makeup in the eyes can cause irritation, leading to issues such as a scratched cornea. An eye infection from makeup can often be treated with eye drops or antibiotics, depending on the type and severity.
Tips for proper eye makeup hygiene include never sharing makeup or brushes, keeping track of expiration dates, not applying makeup if you have an eye infection, removing makeup before bed, not applying makeup inside the lash line, not applying makeup in the car or on the train, reading the ingredients label and regularly washing makeup brushes. These tips and their definitions are listed below.
1. Never share your makeup or makeup brushes: A person should not share their makeup or makeup brushes with another as it can increase the risk of developing an eye infection.
2. Keep track of expiration dates of makeup: All makeup products contain an expiration date clearly stated on the packaging based on when they are opened which should be adhered to.
3. Don’t apply eye makeup if you have an infection: It is advised by eye care professionals to cease wearing makeup if you have an eye infection such as conjunctivitis to prevent further irritation.
4. Remove all your makeup before bed: Wearing makeup to bed is poor makeup hygiene and can increase the risk of developing eye infections like blepharitis and conjunctivitis.
5. Don’t apply makeup inside your lash line: It is recommended to not apply makeup to the inside of your lash line, as it can block oil glands that are located on the edge of the eyelid.
6. Don’t apply makeup in the car or on the train: Applying your makeup in the car or on the train can be very dangerous and can lead to eye injuries such as a corneal abrasion.
7. Read the ingredients label: Reading the ingredients label of makeup is very important for people prone to allergic reactions, especially if they have had reactions to makeup before.
8. Regularly wash your makeup brushes and applicators: It is very important to regularly wash your makeup brushes and any other applicators such as beauty blenders to prevent eye infections.
Due for an Eye Test?
With an optometrist in every store, you can receive a bulk billed eye test to assess your vision and the health of your eyes.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Tips](#tips) [Benefits](#benefits) [Risks](#risks) [Treatment](#treatment)
## 1. Never Share your Makeup or Makeup Brushes
A person should not share their makeup or makeup brushes with another as it can increase the risk of developing an eye infection. According to Optometrists.org, sharing makeup can cause harmful microbes such as fungus and bacteria to enter the eye, potentially leading to viral or bacterial eye infections such as conjunctivitis, certain types of which can be highly contagious.
## 2. Keep Track of Expiration Dates of Makeup
All makeup products contain an expiration date clearly stated on the packaging based on when they are opened which should be adhered to. Makeup can be easily contaminated and should be replaced regularly, especially eye makeup. According to the American Academy of Ophthalmology, infection-causing bacteria grow easily in liquid or creamy eye products. The expiration date for makeup products will typically be seen as a number inside a jar symbol, such as 6, 12 or 18. According to Mecca, these numbers indicate how many months after opening, the product can fight off bacteria with maximum strength.
## 3. Don’t Apply Eye Makeup if You Have an Infection
It is advised by eye care professionals to cease wearing makeup if you have an eye infection such as conjunctivitis or blepharitis to prevent further irritation. According to the American Academy of Ophthalmology, in addition to not applying makeup, they recommend you throw out all eye makeup products if you have an eye infection as they could be contaminated and cause repeat infections.
## 4. Remove all Your Makeup Before Bed
Wearing makeup to bed is poor makeup hygiene and can increase the risk of developing eye infections like blepharitis and conjunctivitis. According to the American Academy of Ophthalmology, it is extremely important to remove all eye makeup before sleeping as it can cause irritation, especially mascara. To properly remove eye makeup from around the eyes, use a cotton pad with a gentle cleanser and hold it on the eye to begin breaking down the makeup. Next, gently wipe away the makeup. Do not harshly rub the eyes as it can cause eye irritation and pain.
## 5. Don’t Apply Makeup Inside your Lash Line
It is recommended to not apply makeup to the inside of your lash line, often referred to as the waterline, as it can block oil glands that are located on the edge of the eyelid, according to the American Academy of Ophthalmology. These glands are called meibomian glands and should not be blocked as they secrete oils that protect the surface of the eye, maintain good eye health and prevent certain eye problems such as dry eyes. It is also important to not apply makeup to the inside of the lash line as it risks introducing bacteria directly into the eye.
## 6. Don’t Apply Makeup in the Car or on the Train
Applying your makeup in the car or on the train can be very dangerous and can lead to eye injuries such as a corneal abrasion. Cars and trains can be unpredictable in their movements not only making makeup application difficult but also dangerous. Makeup applicators such as mascara wands, eyelash curlers and eyeliners should be used with care, not in a moving vehicle but when you can devote your full attention to it.
## 7. Read the Ingredients Label
Reading the ingredients label of makeup is very important for people who are prone to allergic reactions, especially if they have had reactions to makeup before. For people who are sensitive to makeup products, hypoallergenic makeup may be a great option as it claims to produce fewer allergic reactions than other cosmetic products, according to the U.S. Food and Drug Administration. If you have experienced an allergic reaction to makeup, it is recommended by the American Academy of Ophthalmology to let a healthcare professional know so they can suggest gentler alternatives.
## 8. Regularly Wash your Makeup Brushes and Applicators
It is very important to regularly wash your makeup brushes and any other applicators such as beauty blenders. Unwashed makeup brushes can house bacteria leading to eye infections such as a stye or conjunctivitis. According to research conducted by Optometry Australia in 2020, many Australians are not washing their makeup brushes enough, putting their eyes at risk. The study found that 40% of Australians clean their makeup brushes less than twice a year. Not only should you be washing your brushes regularly, but you should also ensure you wash your hands thoroughly before putting on makeup to stop the spread of bacteria.
Find an Oscar Wylee Store Near You
Come and visit your local Oscar Wylee store where our friendly team will help you shop our range of stylish and affordable frames.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
## Why is Eye Hygiene Important?
Eye hygiene is very important as it maintains healthy eyes by lowering your risk of developing eye infections and other eye conditions that can be caused by poor eye hygiene. Practicing good eye hygiene includes washing your hands before touching in or around your eyes, following proper instructions when using contact lenses and safely using makeup around your eyes such as washing makeup brushes regularly and not sleeping in makeup.
### What are the Benefits of Good Eye Hygiene?
The main benefit of practising good eye hygiene is it lowers the risk of developing an eye infection. Good eye hygiene such as washing your hands before touching your eyes and following proper eye makeup practices can prevent eye infections such as conjunctivitis, blepharitis and styes.
### Can Makeup Affect Your Eyes?
Yes, makeup can affect your eyes, especially if not used properly and unhygienically. According to Alabama Family Eye Care, particles from makeup products can migrate to the surface of the eye, destabilising the tear film and resulting in irritation and damage to the eye. Makeup can also affect a person’s eyes if they are allergic to the ingredients used in the product. To prevent allergic reactions to makeup, try only using one new makeup product at a time. Patch testing for skincare products is also recommended to ensure they do not irritate your skin before applying large amounts.
## What Happens if Makeup Gets in Your Eye?
If makeup gets into the eyes it can cause redness and irritation which can lead to a scratched cornea or an eye infection, according to the University of Rochester Medical Center. They recommend not using metallic, sparkle or glitter makeup as flakes can fall into the eye, causing irritation or infection. Makeup applied to the inside of a person’s lash line should also be avoided as it can block important oil glands that protect the surface of the eye.
### What are the Risks of Poor Makeup Hygiene?
Poor makeup hygiene can lead to the development of certain eye infections that can live in the makeup or be caused by not removing makeup. The risks of poor makeup hygiene include pink eye (conjunctivitis), a scratched cornea, blepharitis and styes. These eye infections and their definitions are listed below.
* Pink eye (conjunctivitis): Conjunctivitis, colloquially known as pink eye, is an eye infection that can be caused by poor eye makeup hygiene.
* Scratched cornea: A scratched cornea, also known as a corneal abrasion, can be caused by certain makeup products such as false eyelashes and glitter.
* Blepharitis: Blepharitis is an eye infection characterised by inflammation of the eyelids that can be caused by sleeping in eye makeup.
* Styes: A stye is an eye infection that can be caused by makeup due to products clogging eyelash follicles.
#### 1. Pink Eye (Conjunctivitis)
Conjunctivitis, colloquially known as pink eye, is an eye infection that can be caused by poor eye makeup hygiene. Conjunctivitis is the inflammation, irritation or infection of the conjunctiva, which is the clear membrane that sits over the white parts of the eyes and the inner eyelids. [Conjunctivitis (pink eye)](https://www.oscarwylee.com.au/glasses/eye/conjunctivitis) symptoms include red eyes, tearing, scratchy and stinging eyes and eye discharge. To help prevent conjunctivitis, do not share makeup as the bacteria or virus causing the pink eye can be spread by using infected products.
#### 2. Scratched Cornea
A scratched cornea, also known as a corneal abrasion, can be caused by certain makeup products such as false eyelashes and glitter. A [corneal abrasion](https://www.oscarwylee.com.au/glasses/eye/corneal-abrasion) occurs when the cornea of the eye is scratched or tears which can lead to pain, sensitivity to light and blurry vision. According to the American Academy of Ophthalmology, some makeup cleaners can potentially scratch the eye if they contain scrubbing beads or gritty additions and, therefore, should be avoided.
#### 3. Blepharitis
Blepharitis is an eye infection characterised by inflammation of the eyelids that can be caused by sleeping in eye makeup. Blepharitis causes inflamed eyelids due to bacteria and/or problems with the oil glands in the eyes. Not removing makeup overnight can cause a buildup of dead skin cells leading to the growth of bacteria, resulting in [blepharitis](https://www.oscarwylee.com.au/glasses/eye/eyelids-inflammation). According to Health Direct, blepharitis can reoccur in people who have already had it and ways to potentially prevent it from returning is not using make-up around the eyes.
#### 4. Styes
A stye is an eye infection that can be caused by makeup due to products clogging eyelash follicles. A stye is characterised by a red swollen lump on or near the eyelid, generally caused by a bacterial infection of an eyelash follicle. A [stye](https://www.oscarwylee.com.au/glasses/eye/anatomy/stye) may look like a pimple and may be internal, meaning it is located inside the eyelid or external, located on the base of the eyelash. It is not recommended to wear eye makeup when you have a stye as it could irritate or spread the stye. Using makeup brushes when you have a stye can introduce the stye-causing bacteria into the makeup products, leading to another infection when these products are reused later.
## How to Treat an Eye Infection From Makeup?
Treatment for eye infections caused by makeup or other reasons will be prescribed by an optometrist or another healthcare professional such as a GP (general practitioner) and according to HealthDirect, often includes eye drops and antibiotics. A makeup eye infection or irritation such as blepharitis or conjunctivitis can commonly be treated with eye drops or antibiotics.
### Can You Treat an Eye Infection From Makeup at Home?
It is not advised to treat an eye infection at home without first consulting an eye care professional. Eye infections can be quite serious and require treatment such as antibiotics or ointments which is why at-home treatment without any guidance is discouraged. Once you have seen an optometrist for an eye infection such as a stye, they may recommend treating the issue with a warm compress which can be done at home.
### When Should I See an Eye Doctor?
If you suspect you have an eye infection or eye injury caused by makeup, visit a healthcare professional, whether that be an optometrist or GP (general practitioner). They can perform an [eye test](https://www.oscarwylee.com.au/glasses/eye/test-glossary) to examine your eyes and provide any necessary treatment to maintain their health.
Read Top 25 Common Eye Problems in other Oscar Wylee regions and
their languages.
Australia
Australia
Canada
 
Are You Worried About Your Eyesight?
Come get your next eye test done with us at Oscar Wylee and receive bulk billing for valid Medicare cardholders.
[Book an eye test](https://www.oscarwylee.com.au/booking)
Major Health Funds Accepted In-store
Your health fund may help cover some of the cost of your Oscar Wylee eye test or new frames.
[Discover Health Funds](https://www.oscarwylee.com.au/health-funds.html)