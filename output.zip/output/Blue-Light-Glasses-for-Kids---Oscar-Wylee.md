# Source: https://www.oscarwylee.com.au/guides/lenses/kids-blue-light-glasses

# Blue Light Glasses for Kids
Blue light glasses are used to block artificial blue light emitted from digital screens such as a computer or phone. With children spending more time on screens, whether that’s due to remote learning or using tablets and phones at a younger age, the use of blue light glasses has become very popular for kids.
## What are blue light glasses?
Blue light glasses, also known as blue light blocking glasses and anti-blue light glasses, are worn to block artificial blue light produced by digital screens. The glasses are able to block the blue light as they have an add-on filter applied to the lens, which may help protect your eyes. Other add-ons you can apply to lenses include an [anti-glare or anti-reflective coating](https://www.oscarwylee.com.au/guides/lenses/anti-glare).
## What is blue light?
Blue light is emitted from the sun which is known as natural blue light and is found in the electromagnetic spectrum. The blue light that is produced by screens is artificial and can also come from LED light bulbs, potentially affecting your sleep and causing eye strain. The blue light that is naturally occurring from the sun is used by your body to help regulate its sleep-wake cycle. It does this by producing the hormone melatonin at night in the absence of natural light.
## Looking for a pair of blue light glasses?
Visit our friendly Oscar Wylee staff in-store and they can assist you with all your glasses and optometry needs.
[Find a store near you](https://www.oscarwylee.com.au/locations/full-store-list.html)
## Can kids wear blue light glasses?
Yes! Kids can wear [blue light glasses](https://www.oscarwylee.com.au/blue-light-glasses.html), especially if they are spending prolonged periods of time in front of digital screens. It is completely safe for children and may help with sleep.
## Where to buy blue light glasses for kids?
At Oscar Wylee, you can add a BLULite filter to any pair of optical glasses for an additional $85, or a BLULite filter premium for $95, which includes a Premium Anti-reflective coating. We also offer our frames in a petite size, perfect for kids!
## Do blue light glasses work for kids?
While blue light glasses are effective at blocking artificial blue light that is emitted from screens, the research is still early to conclusively say they are successful in protecting your eyes from harm. Although there is strong evidence that it is beneficial for sleep regulation. According to the Centers for Disease Control and Prevention (CDC), exposure to blue light can make it difficult to fall and stay asleep by affecting your circadian rhythm.
Source: Centers for Disease Control and Prevention 
There are also many related vision problems your child could experience that can instead fall under a term called Computer Vision Syndrome.
## Additional ways to reduce or prevent eye strain and Computer Vision Syndrome for your child
Kids' blue light glasses are only one way to possibly prevent the symptoms of Computer Vision Syndrome. Other ways to prevent your child's discomfort from Computer Vision Syndrome are listed below.
* Limit their screen time where possible
* Tell your child to blink often to moisten their eyes
* Ensure they take frequent breaks from screens to rest their eyes
* Enlarge the text on your child’s screen when reading
## Does my kid need blue light glasses?
If your child is on a computer for much of their day, whether that’s for school or entertainment, they could benefit from blue light glasses. There is research that supports artificial blue light interfering with sleep. Sleep is extremely important for a child’s healthy development, therefore, it may be a good idea to invest in a pair of blue light glasses for your child if much of their day is spent on a screen. Oscar Wylee’s BLULite filter is available to add on top of your [kids’ glasses](https://www.oscarwylee.com.au/glasses/collection/kids-collection.html) for an additional $85 or $95 for BLULite Filter Premium.
## Benefits of blue light glasses for kids
Blue light glasses for kids can be worn to block the artificial blue light that is produced by digital screens. They may offer benefits such as:
* Improve quality and quantity of sleep
* Reduce visual fatigue
* Ease eye strain
## Do you need a prescription for blue light glasses?
No! At Oscar Wylee, your child can have a blue light filter applied to any pair of optical glasses, prescription or not.
## What to do if your child has eye and/or vision issues
If your child is experiencing any eye or vision symptoms such as eye strain, you should take them to an optometrist to get their eyes checked. Not all optometrists perform eye tests on children, call your local Oscar Wylee store to find out more.
## Find a store near you
Get fitted for your multifocal glasses at Oscar Wylee by visiting us in stores and talk to our friendly staff for a complete quote. All major health funds accepted.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
## Due for an eye test?
Oscar Wylee offers bulk billed eye tests, so there are no out-of-pocket expenses for eligible Medicare cardholders.
[Book an eye test](https://www.oscarwylee.com.au/booking)