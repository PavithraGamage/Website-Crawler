# Source: https://www.oscarwylee.com.au/locations/optometrist-karrinyup.html

# Optometrist Karrinyup
Karrinyup Shopping CentreShop SPO284, 200 Karrinyup Rd Karrinyup WA 6018
* Between Woolworths and Big W
Opening hours
Monday9:00am - 5:30pm
Tuesday9:00am - 5:30pm
Wednesday9:00am - 5:30pm
Thursday9:00am - 9:00pm
Friday9:00am - 5:30pm
Saturday9:00am - 5:00pm
Sunday11:00am - 5:00pm
*Store hours reflect local standard trading hours and exclude public holidays
[Visit our Karrinyup Shopping Centre Google Business page for directions, reviews, and updates.](https://g.page/r/CTfSbaIWNk7YEBM)
Book Appointment
[Call us: (08) 6249 4919](tel:(08) 6249 4919)
[Leave a Review!](https://g.page/r/CTfSbaIWNk7YEBM/review)
Our Reviews
Jo Jeakes
2 days ago
Hannah is an absolute delight, always willing to answer any questions,   Quinn was also very friendl...y, even when her equipment was 'having a moment' ! ????
See more
Kerry Bradford
2 weeks ago
My eye appointment was very good. They all were very professional and friendly and I felt in good ha...nds. Everything was explained clearly.
Thank you.
See more
Robyn Lamb
2 weeks ago
Excellent and timely service
Shelby Barten
3 weeks ago
The staff were very nice.
Yuvi Sassoon
3 weeks ago
A really good experience!
I went to get my eyes tested, the staff were polite and friendly throughou...t, the optometrist was knowledgeable and professional, and they had a really great range of glasses. I got exactly what I wanted!
See more
Jasmina Rixom
1 month ago
Jess Saunders
1 month ago
Great service, friendly staff and nice range of frames to choose from.
Grace Giglia
1 month ago
Laura was very friendly and helpful with the whole process! She was so patient when it came to me tr...ying on my different frames and provided me with genuine advice. She had me leaving my appointment with a big smile on my face!
See more
tamara
1 month ago
Loveliest staff!
Sharun Hangg
1 month ago
Cara M
1 month ago
Tashi Choki
1 month ago
Cho
1 month ago
Katie Cullinan
1 month ago
Very impressed with the care and quality of a first eye check for my 6year old daughter
Claire Liu
2 months ago
I visited the shop a few times and got a few pairs from them over years, they have excellent service... and beautiful frames, especially the manger Laura, she solved my problem and helped me, much appreciated and will definitely returning if I need to get another pair! Thanks guys!
See more
Emma Lockhart
2 months ago
Great experience. I’m 43 and have never had an eye checkup as I have always had great eyesight. I ha...ve noticed recently that reading can be a little less clear so my results came up that I needed reading glasses . Great help choosing glasses and all information was clear
See more
Megan Walsh
2 months ago
Really quick, friendly service &amp; explained everything simply
Chelsie Patrick
2 months ago
Very professional, the optometrist was lovely. A great range of frames to pick from
Vina Shah
3 months ago
Mena was  very very good at what she does. Laura was also very helpful.
Simon Watkins
3 months ago
I've bought 8 pairs of glasses from Karrinyup store over the last 2 years Demi and Laura service is ...friendly ,  helpful and genuine. The glass frames are the best value as I pay cash with no health fund . The girls are very help with making adjustments Demi gave me some little plastic ear hooks to stop them sliding.  Laura with my latest 2 pairs was quick in replacing a pair with no fuss . Well done Girls real service hard to find .
See more
Glenys Thomas
3 months ago
Excellent service, lovely staff.
Tashi WANGDI
3 months ago
Good service
S Rach
3 months ago
Great customer service from Oscar Wylee Karrinyup. I went instore without an appointment and they ma...naged to fit me in. All the staff there were great, efficient and welcoming.
Great range of stylish glasses to choose from and the process was quick and easy.
See more
marc cestrilli
3 months ago
Rumi K
4 months ago
It was very kind and helpful
Jigme Thinley
4 months ago
Sinyee Yen
4 months ago
yhkevo
4 months ago
Kate C
5 months ago
I can't remember the name of the optometrist who saw me today but she was absolutely amazing! Thank ...you for listening to my concerns and for all your help today.
See more
Luiza Barbosa
5 months ago
Sam Keam
5 months ago
Hazel didn’t ask me to write a review but I thought she was so fantastic, that I had to write one an...d acknowledge what an outstanding job she’s doing!
My Wife went in looking for her first pair of prescription sunnies, and she made it so effortless and fun. She was extremely knowledgable, patient and friendly, thank you Hazel.
It’s not very often these days that you come across people working in retail who bring so much personality and charisma to their role, who clearly love their job (and are very good at it)
The store also has a great range of lovely frames to try on, would highly recommend!
See more
Karen Brittain
5 months ago
You need to give Hazel at your Karrinyup store a massive raise -that girl is amazing with her custom...er service! She was so fun and so knowledgeable - what an asset to your team!
See more
Valentina Calderon
5 months ago
All perfect
Miss Joycurve
5 months ago
Abby and Chloe are wonderful great service and helping with a repair and clean, very warm and inviti...ng.
See more
Tamsyn Howard
5 months ago
I’m a returning customer. Great experience, very helpful staff members and a good selection of frame...s with competitive prices.
See more
Andrew Sturmer
5 months ago
Mina was excellent with great interpersonal skills and manner, she was also very thorough in testing...!! Her Assistant in the shop was great too!
See more
Mitch Concanen
5 months ago
For the last 15 years or so i've very much been locked into using another 'two for x price' supplier... and was too cautious to go anywhere else, until this year my wife recommended I check out Oscar Wylee and I'm so glad I did!
When compared to the company I had been going to since I was 18, quite literally every single element from eye test to picking up my new frames was worlds ahead. I got a new pair of sunglasses &amp; seeing glasses, the price was only a very small amount more than I was used to paying and the range/additions were much more desirable as well.
During my most recent visits (initial consult, then collection) I dealt with 3 different members of the team and all of them were kind, attentive and helpful, making the process smooth and comfortable.
I highly recommend the services of Oscar Wylee Karrinyup to anyone who may want to try someone new, it wasn't anywhere near as scary as I was expecting!
See more
Lorraine OBrien
5 months ago
I went into Oscar Wylee with some glasses that were broken and had been told they couldn't be fixed ...(at the Innaloo store). The lovely lady at the Karrinyup store fixed them and was more than happy to help. I offered to pay for the repair and she said no cost. I know where I'll be buying my next pair of glasses.
See more
Denise Clarke
6 months ago
Such helpful professionals made my appt very relaxed and i felt i was in good hands
Kimberley Nettle
6 months ago
Fantastic
Jessica Chisholm
6 months ago
Yesterday I had an eye test at Oscar Wylee Karrinyup store and it was one of the smoothest appointme...nts I've ever had.
The whole team was professional and knew their stuff, but the real standout was how genuinely friendly and awesome everyone was. No fuss, no awkwardness - just a great experience from start to finish.
Shoutout to Hazel and Hannah Lee. Their customer service was impressive and top tier! ⭐️ ⭐️ ⭐️ ⭐️ ⭐️ 12/10 - would happily come back even if I had perfect eyesight. Love your work ????????
See more
Richard Low
6 months ago
My first time in the care of Oscar Wylee. Have to say I was made to feel very welcome, and the staff... were wonderful ! (Chloe and Mina especially)
See more
Leon Franchina
6 months ago
My daughter had seen an optometrist at another establishment &amp; wasn’t happy so we went to Oscar Wyle...e for a second option. So many thorough tests &amp; a call from the ophthalmologist by the afternoon. So glad we went to Hannah &amp; got a second opinion.
See more
Mark “Captain” Nener
6 months ago
Excellent service all round, very professional staff, very happy.
joan morgan
7 months ago
I have seen Hannah a couple of times and find her a very experienced  thorough optometrist. She is v...ery efficient, friendly and helpful and I highly recommend her.
See more
Melanie Koch
7 months ago
The ladies were super helpful and kind, providing a professional service, as well as great help with... choosing from so many glasses!
See more
Mia D
7 months ago
Just picked up my prescription sunglasses  from Karrinyup store. Brilliant!
JayJay Tatin
7 months ago
I had the best service at Oscar Wylee thanks to Hazel. She’s incredibly knowledgeable, friendly, and... genuinely helpful.
She took the time to explain everything clearly and made the whole experience easy and enjoyable. Highly recommend asking for Hazel if you visit!
See more
Philip Mcconaghy
7 months ago
Both my current reading glass cases needed to be replaced.
I walked into Oscar Wylee and he (Ryan ) ...the shop assistant offered me 2 cases for free , which he didnt have to .
So again thank you again. Great service !!!
See more
Kaz Zaicz
7 months ago
Staff were lovely.  Great range of glasses.
## Find an Optometrist in Karrinyup With Oscar Wylee
On the ground floor of Karrinyup Shopping Centre, you can find our Oscar Wylee store, close to areas such as North Beach, Innaloo, and Gwelup. Our optometrists offer Medicare bulk billed eye tests for same-day prescriptions and a variety of different glasses frames and lens options to suit your needs. Here you can browse our large collection of modern and vintage frames where our staff can help you find the perfect pair.
Karrinyup Shopping Centre is newly built and one of the largest shopping centres in WA, with plenty of restaurants to explore and if you are looking for some entertainment, you can catch a movie, go bowling or have fun at the arcade. There is free parking and a bus stop right outside the centre. If you have time after your appointment, you can visit the centre’s library and community centre.         
Meet Our Team
* Store Manager
Our Services
* Bulk Billed Eye Examinations
* Professional Frame Styling
* Frame Adjustments and Repairs
* Visual Fields Testing
Show All
## Find an Optometrist in Karrinyup, Perth for an Eye Health Test
If you need high-quality eye care services such as eye health tests, prescription updates or new glasses, come and visit the Oscar Wylee team in Karrinyup, Perth. Here, our optometrists are available in-store at the Karrinyup Shopping Centre to provide eye testing processes including vision testing and the diagnosing and management of eye diseases. Our optometrists can also refer patients to an eye doctor, known in Australia as an ophthalmologist, for specialised care if needed. The cost for eye care services including optometrists and ophthalmologists in Karrinyup, Perth will be dependent upon a person’s individual eye care needs. At Oscar Wylee, our eye tests are conducted at a bulk billed price under Australia’s Medicare system.
At our Oscar Wylee glasses shop in Karrinyup, our retail team and optical dispensers are available to help customers shop our range of frames from prescription glasses, prescription sunglasses to non-prescription eyewear. At Oscar Wylee, we are passionate about our customers finding the eyewear that is right for their vision and lifestyle needs, with frame adjustments, lens add ons and styling advice available in-store to ensure your frames work for you. Visit Oscar Wylee for eye care services including new frames and eye health tests in Karrinyup, Perth.
## How to Find an Optometrist in Karrinyup, Perth?
To find an optometrist in Karrinyup, Perth you can take certain steps that can help make it easier for you such as searching online, assessing the store’s opening hours and finding the directions to your chosen location. The steps on how to find an optometrist in Karrinyup, Perth are listed below.
1. Search online using the phrase, optometrist near me in Karrinyup. This can also be done here on the website via our locations page.
2. Click on the Oscar Wylee link, which will take you directly to our Karrinyup optometrist store page.
3. See the store’s opening hours and where the store is located specifically.
4. Use the Karrinyup Google Business page link located under store hours to see the directions on how to get to the store.
You can also find an optometrist in Karrinyup, Perth by searching the keywords optometrist near me. If you have locations enabled on your smartphone and you’re in the Karrinyup, Perth area, our Karrinyup store page should appear easily for you to click on.
### Is it Hard to Get an Eye Appointment in Karrinyup, Perth?
No, it is not hard to get an eye appointment in Karrinyup. You can easily book an appointment to see an Oscar Wylee optometrist in Karrinyup, Perth right here on this page. At Oscar Wylee we have highly qualified optometrists available for bulk billed eye appointments, which can be booked online or in-store.
#### How to Compare Optometrists in Karrinyup, Perth to Each Other?
To compare optometrists in Karrinyup, Perth, you can use factors such as eye tests offered, health fund coverage, lens types and add-ons and eyewear offered. To take care of your vision and eye health, it is important to receive an eye test at least once every two years. There are different types of tests that can be performed in an eye test and not all optometrists may offer the same tests. Health funds can be used to help cover some of the cost of your frames and lenses. To find out if your health fund is accepted at an optometrist in Karrinyup, Perth visit their website. In the case of Oscar Wylee, we accept all major health funds and provide on-the-spot claims in-store. There are many different lens options available for prescription glasses such as single-vision, multifocal and high-index lenses. Most optometrists in Karrinyup, Perth will offer these lenses although it is good to make sure. There are also lens add-ons available to enhance your glasses such as anti-reflective and blue light filters. Finally, if you are looking to purchase a pair of glasses after your eye test, you can compare the different styles and colours you are interested in from the optometrists in Karrinyup, Perth. Oscar Wylee offers a wide range of frames with vintage and modern inspirations in bold colours and subtle designs.
#### How to Find an Eyeglasses Shop in Karrinyup, Perth?
To find a glasses store in Karrinyup, Perth you can try to follow these simple steps including searching online, selecting a convenient location and looking at their health insurance policies. The steps on how to find a glasses store in Karrinyup, Perth are listed below.
1. Search online using the phrase, glasses store in Karrinyup, Perth. This will provide you with various options for glasses stores in the whole Karrinyup, Perth area.
2. Select a glasses store that is most convenient for you to travel to.
3. Click the link to find out more information such as opening hours, exact location and directions to the glasses store in Karrinyup.
4. Read their health insurance policies to ensure you know what health benefits you have access to.
Our Oscar Wylee glasses store in Karrinyup, Perth offers primary eye care services such as comprehensive eye tests as well as other services performed by an optometrist and offers prescription and non-prescription eyewear.
##### Is it Possible to Purchase Prescribed Sunglasses in Karrinyup, Perth Without Seeing an Optometrist?
Yes and no, it is possible to [purchase prescribed sunglasses](https://www.oscarwylee.com.au/sunglasses.html) in Karrinyup, Perth without seeing an optometrist if you already have a prescription that has not expired. If your prescription is expired, you can book an eye test to receive an updated or new prescription which will require you to see an optometrist. This will ensure your prescription sunglasses are appropriate for your visual needs.
## Where is the Oscar Wylee Karrinyup, Perth Optometrist Located?
The Oscar Wylee Karrinyup optometrist is located in Karrinyup Shopping Centre, in the suburb of Karrinyup. The Karrinyup Shopping Centre is located at 200 Karrinyup Road in Karrinyup, Perth.
### What is the Phone Number of Oscar Wylee Karrinyup, Perth Optometrist Store?
The phone number for our Oscar Wylee Karrinyup, Perth optometrist store is (08) 6249 4919. Our Oscar Wylee Karrinyup, Perth store is open, and our staff are available to be contacted between 9 am and 5.30 pm Monday to Wednesday, 9 am to 9 pm on Thursdays, 9 am to 5.30 pm on Fridays, 9 am to 5 pm on Saturdays and 11 am to 5 pm on Sundays.
### What are the Reviews for Oscar Wylee Karrinyup, Perth Optometrist?
The customer reviews for our Oscar Wylee Karrinyup, Perth optometrist, can be found here on the website and online when you search for Oscar Wylee Karrinyup optometrist. The reviews for our Oscar Wylee Karrinyup optometrist are listed below.
* Anna Nugawela:  Wonderful experience, so simple and efficient. Outstanding customer service at the Karrinyup store. Lovely range of reading glasses as well as sunglasses.
* Carla Ball:  I was really impressed with how organised and thorough the optometrist was at Karrinyup, WA. Their equipment was also top rate, thank you!
* Steve Bowser:  Service was very good and very professional. I was very satisfied with the glasses selection and professional service.
#### What Treatments or Eye Care Processes Are Done in the Oscar Wylee Karrinyup, Perth Optometrist Location?
The treatments or eye care processes done in the Oscar Wylee Karrinyup, Perth optometrist location include a tonometry test, a slit lamp exam and a refraction test. Additional tests that may also be performed can include a visual field test and a dilated fundus exam. The treatments or eye-care processes that are done in the Oscar Wylee Karrinyup optometrist location are listed below.
* A Tonometry Test: An optometrist or optical dispenser will conduct a tonometry test which involves the use of a machine that will release small puffs of air into your eyes. This will assist with measuring pressure in the eye.
A Digital Photograph: An optometrist or optical dispenser
may take a digital photograph of your eye which can be kept on
record to use in future appointments to evaluate any changes to
your eye.

* Slit Lamp Test: A slit lamp test can be used to evaluate your eye health, by examining your cornea and iris which are the anterior and posterior of the eye.
* Refraction Test: During a refraction test, an optometrist will have you view an image through different lenses and ask you to confirm which helps you see the image clearer.
* Visual Field Test: A visual field test can assist with assessing your peripheral vision, which may be beneficial for identifying any signs of glaucoma.
* Dilated Fundus Exam: A dilated fundus exam can help an optometrist assess your health in more detail by getting a clear view of the retina. This test is typically carried out for patients with diabetes and those who may be at risk of developing retinal damage.
## How Many Optometrists Exist in Karrinyup, Perth?
Many optometrists exist in Karrinyup, Perth and in the Karrinyup Shopping Centre, including Oscar Wylee. The amount of optometrists available in an area will typically depend on the population and the eye care needs of those in the area. At Oscar Wylee Karrinyup, Perth, our team is passionate about providing our customers with high-quality, dedicated eye care services. Our optometrists are available to provide bulk billed eye tests with our dedicated optometrists, prescription updates and new frames. If you are looking for an optometrist in Karrinyup, Perth, Oscar Wylee is available to provide all your eye care and eyewear needs.
### What are the Other Closest Optometrist Locations to Karrinyup, Perth in Australia?
The closest Oscar Wylee Optometrist locations to Karrinyup, Perth are Joondalup, Claremont and Morley Galleria. The closest Oscar Wylee optometrist locations to Karrinyup, Perth are listed below.
* Joondalup:  Joondalup is a suburb approximately 19 km away from Karrinyup, Perth where you can find our Oscar Wylee optometrists. [Oscar Wylee Joondalup](https://www.oscarwylee.com.au/locations/optometrist-joondalup.html) is located in the Lakeside Joondalup Shopping Centre where our team can provide eye tests, prescription advice and new frames.
* Claremont:  Claremont is a suburb approximately 17 km away from Karrinyup Shopping Centre where you can find an Oscar Wylee optometrist for eye testing services. Our [Oscar Wylee Claremont](https://www.oscarwylee.com.au/locations/optometrist-claremont.html) store is located in the Claremont Quarter Shopping Centre. Here, our optometrists can provide Medicare bulk billed eye tests, prescription updates and eye care advice.
* Morley Galleria:  Morley Galleria is a shopping centre located approximately 13 km away from Karrinyup, Perth in which you can find an Oscar Wylee optometrist. Customers can find [Oscar Wylee Morley Galleria](https://www.oscarwylee.com.au/locations/optometrist-morley-galleria.html) on the ground floor of the Galleria Shopping Centre, where our optometrists provide Medicare bulk billed eye tests.
### Bulk Billed Eye Tests at Oscar Wylee Karrinyup
For some of the best optometrists in Karrinyup, Australia, visit our Oscar Wylee store in the Karrinyup Shopping Centre. Here, our optometrists are passionate about providing customers with high-quality eye care processes which can include vision testing and eye examinations for potential eye diseases or conditions. For eye health tests, bulk billed under Medicare, visit our Oscar Wylee optometrists in Karrinyup.
### Health Funds Accepted at Oscar Wylee Karrinyup
Oscar Wylee in Karrinyup Shopping Centre accepts major health funds. Come and visit us for new prescription glasses and our team can help process your claim in-store with a valid health fund card. Our team are also available to help you navigate questions about eligibility and insurance at Oscar Wylee to make sure you’re getting the best price for your prescription eyewear needs.
### Stylish and Affordable Frames at Oscar Wylee Karrinyup
Here at our Oscar Wylee eyeglasses shop in Karrinyup, we offer prescription eyeglasses, prescription sunglasses and non-prescription glasses in a variety of modern and vintage-inspired styles. Choose to add on a blue light filter or pick from our different lens options such as multifocals or lens thinning for an additional price, to get the most from your Oscar Wylee frames. Come and visit our Oscar Wylee team in Karrinyup who will help you choose the glasses that are best fit for you and your eye care needs.
Book Appointment
[Call us: (08) 6249 4919](tel:(08) 6249 4919)
[Leave a Review!](https://g.page/r/CTfSbaIWNk7YEBM/review)