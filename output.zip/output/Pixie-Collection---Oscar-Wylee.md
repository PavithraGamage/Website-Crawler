# Source: https://www.oscarwylee.com.au/glasses/collection/pixie-collection.html

The Pixie Collection is a sprinkle of fun with a pop of fairy dust running throughout. You’ll find frames in pastel colours and chic shapes, inspired by the Y2K aesthetic.
[](#layer-product-list) 
Pixie is a collection that speaks to whimsy and reckless abandon, where you may encounter grooving unicorns and laughing mermaids.
[](#layer-product-list) 
The colours in the Pixie Collection feature pastel pinks, purples, blues and greens, brightened with a dash of vibrancy.
[](#layer-product-list) 
Step into a Y2K dream full of frames inspired by the late 90s and early 2000s. This aesthetic is seen in Pixie’s unicorn colour palette.
11 Products        
Showing 11
1. [](https://www.oscarwylee.com.au/poppy-optical.html)
[Poppy](https://www.oscarwylee.com.au/poppy-optical.html)
$169.00    
[2 pairs from $199](https://www.oscarwylee.com.au/poppy-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/poppy-optical.html)
2. [](https://www.oscarwylee.com.au/andrew-optical.html)
[Andrew](https://www.oscarwylee.com.au/andrew-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/andrew-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/andrew-optical.html)
3. [](https://www.oscarwylee.com.au/serge-optical.html)
[Serge](https://www.oscarwylee.com.au/serge-optical.html)
$169.00    
[2 pairs from $199](https://www.oscarwylee.com.au/serge-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/serge-optical.html)
4. [](https://www.oscarwylee.com.au/jinky-optical.html)
[Jinky](https://www.oscarwylee.com.au/jinky-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/jinky-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/jinky-optical.html)
5. [](https://www.oscarwylee.com.au/evie-optical.html)
[Evie](https://www.oscarwylee.com.au/evie-optical.html)
$169.00    
[2 pairs from $199](https://www.oscarwylee.com.au/evie-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/evie-optical.html)
6. [](https://www.oscarwylee.com.au/mesa-optical.html)
[Mesa](https://www.oscarwylee.com.au/mesa-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/mesa-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/mesa-optical.html)
7. [](https://www.oscarwylee.com.au/parker-optical.html)
[Parker](https://www.oscarwylee.com.au/parker-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/parker-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/parker-optical.html)
8. [](https://www.oscarwylee.com.au/frieda-optical.html)
[Frieda](https://www.oscarwylee.com.au/frieda-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/frieda-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/frieda-optical.html)
9. [](https://www.oscarwylee.com.au/peyton-optical.html)
[Peyton](https://www.oscarwylee.com.au/peyton-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/peyton-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/peyton-optical.html)
10. [](https://www.oscarwylee.com.au/chiara-optical.html)
[Chiara](https://www.oscarwylee.com.au/chiara-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/chiara-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/chiara-optical.html)
11. [](https://www.oscarwylee.com.au/jessie-sunglasses.html)
[Jessie](https://www.oscarwylee.com.au/jessie-sunglasses.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/jessie-sunglasses.html)
[3 pairs from $249](https://www.oscarwylee.com.au/jessie-sunglasses.html)
11 Products        
Showing 11