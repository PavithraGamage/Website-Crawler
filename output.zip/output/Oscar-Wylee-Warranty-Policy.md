# Source: https://www.oscarwylee.com.au/legal/oscar-wylee-warranty.html

# Oscar Wylee Warranty
## Oscar Wylee will cover the cost of:
## Frame Damage
Factory caused damage or faults
Major failure of product*
Unacceptable quality of product*
Damage in transit
## Lens Damage
Factory caused damage or faults
Major failure of product*
Unacceptable quality of product*
Damage in transit
## Poor Fitting
Factory caused damage or faults
Major failure of product*
Unacceptable quality of product*
Damage in transit
## Lifetime Cleaning and Adjustment
Factory caused damage or faults
Major failure of product*
Unacceptable quality of product*
Damage in transit
* Customer rights guaranteed under the ACCC Consumer Rights and Guarantees. Consumer rights apply to gifts as well as purchases.
## Oscar Wylee does not cover the cost of:
* Damage after purchase
* Wear and tear after purchase
Be advised, warranty coverage is subject to Oscar Wylee’s and Oscar Wylee stores’ discretion.
## Our 12 month product guarantee
If within 12 months of delivery or purchase of your Oscar Wylee frames or lenses, you find possible production faults, such as material issues, defective frames or damage from the products manufacturing, Oscar Wylee’s satisfaction guarantee offers replacement or repair of your purchase, completely free of charge.Oscar Wylee also offers a repair or replacement for problems experienced with vision during everyday use for claims made within 30 days of delivery or receipt of purchase. Goods damaged in transit also fall under our 12 month guarantee and will entitle you to the same actions as a faulty product. If you wish to replace a faulty product that has been discontinued or is no longer available, we may offer you an exchange for a similar product or a refund.We also recommend you immediately inspect any goods that we deliver to you or that you collect from an Oscar Wylee store, to ensure you are completely satisfied with the goods, including that the goods are of acceptable quality, and match the description we have provided to you.If you have any questions about this policy, please contact our [Customer Service](https://www.oscarwylee.com.au/contact/).
## Lifetime care policy
Oscar Wylee offers consumers lifetime cleaning and adjustment.
## Change of mind
At Oscar Wylee, we want your absolute satisfaction. You may exchange or refund non-prescription, over-the-counter sunglasses within 30 days of delivery if you change your mind. These should be in brand new, saleable condition and accompanied by the original packaging.
We do not offer change of mind returns and exchanges for any other Oscar Wylee product.
## How do I make a claim?
To claim with Oscar Wylee, simply return your glasses to your nearest store. Please be sure to have proof of purchase ready and available. Any returns will be performed at your own expense.
## Your consumer rights at Oscar Wylee
At Oscar Wylee, there are several guarantees we give to our consumers:
* The product will be of acceptable quality.
* The product will fit its specific purpose.
* The product matches its given description.
* The product matches the sample/demonstration model.
* Oscar Wylee will honour express warranties.
* Spare parts and repair facilities will be available for a reasonable time after product purchase.
* Guaranteed title to the product or goods.
* Undisturbed possession of the product or goods.
* No undisclosed security on the product or goods.
These guarantees are in addition to and under the Australian Consumer Law and cannot be limited or excluded. You are entitled to a replacement or refund for a major failure and compensation for any other reasonably foreseeable loss or damage. You are also entitled to have the goods repaired or replaced if the goods fail to be of acceptable quality and the failure does not amount to a major failure.
## What we don’t offer:
Oscar Wylee’s customer guarantees do not apply to any of the following:
* Wear, tear and ageing.
* Any modifications or repairs not made by Oscar Wylee.
* Damage caused by misuse, neglect or carelessness, such as scratches from dropping or crazing on lenses due to being left in high temperatures.
* Damage caused by natural disaster.
* Changes to designs and/or colour after purchase.
* Purchases or deliveries outside Australia.
* Accidental loss or accidental damage.
* Items or parts that were not purchased from Oscar Wylee (e.g. if only lenses were purchased, then the warranty does not cover any frame used for the lenses; if only frames were purchased, then the warranty does not cover any lenses used in the frames).
* Incorrect prescriptions provided to Oscar Wylee from external sources.
* Chipped 1.5 index lenses in half-rim styles purchased. As such, we recommend 1.6 index for greater durability.
## Contact
You can contact Oscar Wylee email via the [contact us form](https://www.oscarwylee.com.au/contact/) or post at 320 Sussex St, Sydney, NSW 2000.