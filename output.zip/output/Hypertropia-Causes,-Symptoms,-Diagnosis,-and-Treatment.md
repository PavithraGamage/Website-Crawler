# Source: https://www.oscarwylee.com.au/glasses/eye/hypertropia

# Hypertropia: Causes, Symptoms, Diagnosis, and Treatment
Published on August 31st, 2023
Updated on Month Date, 2025 
Australia
[Australia](https://www.oscarwylee.com.au/glasses/eye/hypertropia)
New Zealand

[Canada](https://oscarwylee.ca/glasses/eye/hypertropia)
Canadian French

Hypertropia is a type of vertical strabismus (crossed eyes), that is
caused by weak eye muscles. A hypertropia eye will be upwards turning,
meaning the affected eye is higher than the normal eye. The other types of
strabismus are esotropia, exotropia and hypotropia. Causes of hypertropia
include Brown’s syndrome, injury in the eye, stroke and fourth cranial
nerve palsy. The symptoms of hypertropia include double vision, head
tilting and eye strain. It can be diagnosed through an eye test with an
optometrist who will assess the vision and health of the eyes.
Hypertropia, like other types of strabismus, can be treated with glasses,
patching and eye surgery. Keep reading to learn more about
hypertropia.
Due for an Eye Test?
Choose Oscar Wylee for your regular eye test, performed by our skilled and
friendly optometrists.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Definition](#definition) [Causes](#causes)
[Symptoms](#symptoms)
[Treatment](#treatment)
## What is Hypertropia?
Hypertropia is one of the four types of strabismus, with the others being,
esotropia, exotropia and hypotropia. Hypertropia is
a form of vertical strabismus and is characterised by an upward-turning
eye or eyes, meaning the affected eye sits higher than the other.
Hypertropia is the least common type of strabismus and can occur
consistently or come and go when the person is tired or stressed. Like most
types of strabismus, hypertropia can be treated with glasses, patching and
surgery. In summary, the answer to what is hypertropia and the
hypertropia definition is; that it is a vertical form of strabismus that is
characterised by an upward-turning eye or eyes.
### What Does Hypertropia Look Like?
A person with hypertropia will have one eye higher than the other.
Hypertropia can affect one or both eyes and is described as upward
turning. This occurs due to the muscles in the eyes being imbalanced
meaning they don’t work together, leading one eye to look in a different
direction than the other.
### What Muscle is Involved in Hypertropia?
The muscles that are involved in hypertropia are the eye muscles.
According to the American Academy of Ophthalmology,
hypertropia is either caused by dysfunctional vertical recti muscles
(inferior and superior rectus) or the oblique muscles (inferior oblique
and superior oblique) in the eye.
In rare cases, hypertropia may be caused by irregular positioning of the
horizontal rectus muscles.
### How Common is Hypertropia?
Hypertropia is the least common type of strabismus according to the UC San
Diego Health.
According to a 2006 study published in the American Academy of
Ophthalmology Journal, approximately 1 in 391 children have
hypertropia.
This study was measured from children under the age of 19. hypertropia can
affect both children and adults but hypertropia in adults is less common.
#### Is Hypertropia Hereditary?
Yes,
hypertropia may be hereditary or it can be acquired later in life due
to other issues or conditions.
Causes of acquired hypertropia include a stroke, an injury to the eye
and Brown’s syndrome. According to Frontiers, it is recognised that
strabismus can run in a person’s family although it is complex with no
causative genes being identified.
#### Is Hypertropia a Disability
No, hypertropia is not a disability although, if it is not treated, it
may lead to complications that could result in vision loss which is a
disability
that can cause a decreased quality of life. If you or your child is
presenting with hypertropia symptoms, visit your eye care professional
for assessment and treatment.
### How Does Hypertropia Differ From Other Types of Strabismus?
Hypertropia differs from other types of strabismus as the affected eye or eyes
point upwards. The other types of [strabismus (crossed eyes)](https://www.oscarwylee.com.au/glasses/eye/crossed-definition)
are esotropia, exotropia and hypotropia. Esotropia describes the eyes
turning inwards towards the nose, exotropia occurs when the eyes turn
outwards towards the ears and hypotropia describes the affected eye
sitting lower than the other eye, meaning it is downward turning.
## What are the Causes of Hypertropia?
There are many different causes of hypertropia, which is a type of
strabismus. To determine what causes hypertropia, an optometrist will need
to assess the person’s eye. The causes of hypertropia include Brown’s syndrome, thyroid eye disease, injury to the eye, stroke, fourth
cranial nerve palsy, myasthenia gravis and Duane syndrome.
These causes and their definitions are listed below.
* Brown’s syndrome: Brown’s syndrome is a
condition that affects the eye muscles which can cause hypertropia as the
eyes do not move properly.
* Thyroid eye disease: Thyroid eye disease
is an autoimmune disease that affects the eye muscles due to inflammation
which can lead to hypertropia.
* Injury in the eye: An injury to the eye
can damage the nerves or muscles in the eye, resulting in hypertropia or
another type of strabismus.
* Stroke: A stroke may cause hypertropia as
this condition often affects a person’s vision due to nerve damage.
* Fourth cranial nerve palsy: Fourth cranial
nerve palsy causes a nerve in the eye to not work properly, making the
affected eye unable to move down.
* Myasthenia gravis: Myasthenia gravis is an
autoimmune disease that is characterised by muscle weakness, specifically
in the skeletal muscles which can affect eye movement.
* Duane syndrome: Duane syndrome is a rare
disorder that causes restrictions to eye movement, specifically upwards
and outwards.
### 1. Brown's Syndrome
Brown’s syndrome is a condition that affects the eye muscles which can cause hypertropia as
the eyes do not move properly.
According to the American Association for Pediatric Ophthalmology and
Strabismus, Brown’s syndrome is a problem with the superior oblique
muscle which is on the outside of the eye, causing limited movement in
the eyeball when looking up and towards the nose. With hypertropia
caused by Brown’s syndrome, it is the lower eye that is actually
affected not the upward-turning eye, as the lower eye is unable to look
up, causing it to stay looking forwards. Brown’s syndrome can cause
double vision and does not often respond to treatment.
### 2. Thyroid Eye Disease
Thyroid eye disease is an autoimmune disease that affects the eye muscles due to inflammation,
which can lead to hypertropia.
According to VeryWell Health, thyroid eye disease is also known as
Grave's disease and is associated with hyperthyroidism which is an
overactive thyroid gland. Thyroid eye disease can also cause other types
of strabismus and can be treated with surgery.
### 3. Injury in the Eye
An injury to the eye such as a hit or any type of trauma, can damage the nerves or muscles in the eye, resulting in hypertropia
or another type of strabismus.
A trauma-caused hypertropia can sometimes heal on its own, although it
is important to have your eyes assessed if you have an eye injury.
According to Burman &amp; Zuckerbrod Ophthalmology Associates,
hypertropia caused by trauma to the eye is uncommon.
### 4. Stroke
A stroke may cause hypertropia as this condition often affects a person’s vision
due to nerve damage.
According to VeryWell Health, a stroke can cause blood clots that lead
to damage to the nerves that are involved in eye movement, meaning it
can result in an upward-turning eye, which is known as hypertropia. A
stroke is a condition that occurs when there is not enough oxygen and
nutrients going to the brain, often due to a blood clot, according to
HealthDirect Australia.
### 5. Fourth Cranial Nerve Palsy
Fourth cranial nerve palsy is a condition where the superior oblique muscle is weak, causing the nerve
to not work properly, making the affected eye unable to move down. Fourth cranial nerve palsy is often diagnosed in infancy. According to
the Kellogg Eye Center, fourth cranial nerve palsy may be present at
birth or from a secondary cause such as trauma.
### 6. Myasthenia Gravis
Myasthenia gravis is an autoimmune disease that is characterised by muscle weakness,
specifically in the skeletal muscles which can affect eye movement.
According to the American Association for Pediatric Ophthalmology and
Strabismus, approximately 50% of people with myasthenia gravis present
with ocular symptoms such as eye misalignment and double vision.
### 7. Duane Syndrome
Duane syndrome is a rare disorder that causes restrictions to eye movement, specifically
upwards and outwards.
According to the American Academy of Ophthalmology, Duane syndrome can
cause hypertropia due to a restrictive lateral muscle or aberrant
innervation of vertical muscles. Duane Syndrome can be treated with
surgery on the affected eye muscle.
See the Team at Oscar Wylee
Come in and visit our dedicated Oscar Wylee team who can help you with
your eyewear and optometry needs.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
## What are the Symptoms of Hypertropia?
The symptoms of hypertropia are similar to the other types of strabismus
which are hypotropia, esotropia and exotropia. The symptoms of hypertropia
include eye strain, diplopia (double vision), head tilting and headaches.
These symptoms and their definitions are listed below.
* Eye strain: Eye strain may be a symptom of
hypertropia and other forms of strabismus due to the misalignment of the
eyes.
* Diplopia (double vision): Diplopia,
colloquially known as double vision, is a common symptom of strabismus,
including hypertropia.
* Head tilting: People with hypertropia, a
type of strabismus, may turn or tilt their heads to view objects due to
their misaligned eyes.
* Headaches: Headaches may be experienced by
people with hypertropia as a result of double vision.
### 1. Eye Strain
Eye strain
may be a symptom of hypertropia and other forms of strabismus due to the
misalignment of the eyes.
Eye strain, also known as eye fatigue, is very common and can feel like
eye irritation and discomfort. Eye strain may be managed by resting the
eyes or seeking treatment for hypertropia such as glasses and
patching.
### 2. Diplopia (Double Vision)
Diplopia, colloquially known as double vision, is a common symptom of
strabismus, including hypertropia. [Diplopia](https://www.oscarwylee.com.au/glasses/eye/double-vision) is caused by strabismus due to eye misalignment as the eyes are not
working together which results in a person seeing two distinct or
overlapping images of an object.
Double vision may lead to a feeling of nausea, dizziness and headaches.
If hypertropia, or another type of strabismus, is left untreated, the
brain corrects the symptom of double vision by ignoring the image seen
from the weaker eye; this condition is called lazy eyes (amblyopia).
Double vision (diplopia) may be a sign of a different medical condition,
therefore,
any acute onset double vision needs immediate attention.
### 3. Head Tilting
People with hypertropia, a type of strabismus, may turn or tilt their heads to view objects due to their misaligned
eyes.
Head tilting may be treated with patching to strengthen the weaker eye
that is not seeing straight, in the case of hypertropia, this would be
the eye that is upward turning. To manage this symptom, seek an
assessment from an optometrist who can provide options for
treatment.
### 4. Headaches
Headaches may be experienced by people with hypertropia as a result of double
vision which is described as pain in the head or face and a feeling of
pressure or constant throbbing. Double vision may cause headaches due to
the eyes seeing two different or overlapping images of an object.
Headaches may be managed with rest, medication and treating the
underlying cause by wearing prism glasses.
## How do Eye Doctors Diagnose Hypertropia?
An [eye doctor](https://www.oscarwylee.com.au/glasses/eye/doctors)
in Australia will not typically diagnose hypertropia, as they are medical
professionals with a specialisation in eye care, usually dealing with
issues such as advanced glaucoma. An optometrist can diagnose hypertropia in a routine eye exam using
various tests.
Tests and assessments for diagnosing strabismus include patient history,
visual acuity, refraction test, focusing and alignment test and an eye
health examination. At Oscar Wylee, our eye tests typically take 20
minutes although this may vary depending on the tests the optometrist
needs to perform.
### How Serious is Hypertropia?
Hypertropia may be serious if it is not addressed or treated by an optometrist but
in most cases, it is not serious and can be treated
with glasses, patching or surgery. Hypertropia should be assessed and
treated by an optometrist which is why regular eye tests are important
to detect and diagnose eye issues and diseases.
#### Is Hypertropia Contagious?
No, hypertropia is not contagious, it is an eye condition that is
characterised by eye misalignment.
Hypertropia can be congenital, meaning it is present at birth or
acquired such as through an eye injury or a medical condition.
### What are the Potential Complications of Hypertropia?
If left untreated, a complication that may arise from hypertropia is amblyopia (lazy
eyes).
Amblyopia occurs when a person’s eye has worse vision than the other,
due to development issues causing the brain to favour the unaffected
eye. If a person with strabismus, including hypertropia, does not
correct the issue, it can lead to amblyopia because the brain ignores
the images seen by the weaker eye. It is important to seek treatment if
you notice you or your child has strabismus instead of assuming it will
get better on its own.
## How is Hypertropia Treated?
Hypertropia can be treated similarly to the other types of strabismus,
which are hypotropia, esotropia and exotropia. According to the Kellogg
Eye Center, hypertropia is treated depending on the cause and age of the
patient as it is more common to treat this type of strabismus with
patching when in children to help with their development. The treatments for hypertropia include glasses, patching and surgery.
Prism glasses can be used to correct double vision and the lenses may also
include a prescription if the person has a refractive error. Patching
involves wearing an eye patch over the unaffected eye in order to force
the weaker eye to be the main source of vision. Over time, patching
assists in strengthening the vision and muscles of the weak eye,
therefore, treating hypertropia. Eye muscle surgery is a common treatment
that is used to treat hypertropia by changing the position and length of
the person’s eye muscles in order to align the eyes correctly.
### How Long Does it Take to Treat Hypertropia?
How long it takes to treat hypertropia depends on the type of treatment and the underlying cause of this type
of strabismus.
For example, following eye surgery, a patient may require vision therapy
to ensure the eyes do not become misaligned again. Patching for children
with strabismus may take from a month of wear to four months.
#### Can you Fix Hypertropia Without Surgery?
Yes, in some cases, hypertropia can be treated or fixed without surgery. The other
treatments for hypertropia include glasses and patching
which are often used for children to help their eyes develop normally.
Prism glasses can be worn to correct double vision, which is a vision
issue that is often caused by strabismus due to misaligned eyes.
Patching helps by covering the normal eye which then strengthens the
weaker eye as it is solely reliable for the person’s sight.
#### Do you Need Glasses if You Have Hypertropia?
Yes, you may need glasses if you have hypertropia for different
reasons.
If hypertropia is causing the symptom of double vision, prism glasses
may be prescribed to allow the wearer to perceive objects as a single
image. Prescription glasses may also be used to bring the eyes back
into alignment if there is a refractive error present. To find out if
you require glasses to treat hypertropia, book an appointment with an
optometrist as they will assess your eyes and provide a
diagnosis.
#### Can Hypertropia Go Away on its Own?
No, hypertropia does not go away on its own, rather it requires treatment
to address the misalignment of the eyes.
Hypertropia may be treated with glasses, patching and surgery. If you
believe you or your child are showing signs of hypertropia or any form
of strabismus, book an eye test with an optometrist.
#### Can Lasik Fix Hypertropia?
No, Lasik is not generally used to fix hypertropia.
LASIK, which stands for laser-assisted in situ keratomileusis, is most
often used to correct refractive errors such as hyperopia, myopia and
astigmatism. Rather than LASIK, eye muscle surgery is a common
treatment for strabismus. Eye muscle surgery is performed to fix
crossed eyes by changing the position and length of a person’s eye
muscles to correctly align their eyes. Following eye muscle surgery, a
patient may need to undergo vision therapy to ensure their eyes do not
revert to being misaligned.
### What Type of Strabismus Eye Exercise Helps Fix Hypertropia?
While there are not many eye exercises performed specifically for
hypertropia, there are general eye exercises advised for strabismus. These [strabismus eye exercises](https://www.oscarwylee.com.au/glasses/eye/strabismus-and-eye-exercises) include barrel cards, pencil pushups and brock string.
A barrel card is a tool used in certain eye exercises to help the eyes
turn and move at the same time. A barrel card is often used to help with
strabismus. Pencil push-ups are an eye exercise used to train the eyes
to converge when looking at an object close up. Finally, a Brock string
is a tool used to train the eyes in areas such as focusing and tracking
and may help with the symptoms of strabismus and amblyopia. Eye
exercises should not be performed as an alternative to seeing an eye
care professional for treatment.
#### What is the Difference Between Hypertropia and Hypotropia?
The main difference between hypertropia and hypotropia is the former is
characterised by the eyes turning upward and the latter occurs when
the eyes turn downward.
Other than the direction of the affected eye, there are not many other
differences between hypertropia and hypotropia. They are both types of
vertical strabismus and may be treated with patching, glasses and
surgery. Hypertropia and hypotropia have similar symptoms such as
double vision and headaches although they look different
visually.
Read Hypertropia: Causes, Symptoms, Diagnosis, and Treatment in other
Oscar Wylee regions and their languages.
Australia
[Australia](https://www.oscarwylee.com.au/glasses/eye/hypertropia)
New Zealand

[Canada](https://oscarwylee.ca/glasses/eye/hypertropia)
Canadian French

Leading Health Funds Accepted
Visit Oscar Wylee in-store for eye care services and your health fund
may help cover some of the cost.
[Explore health funds](https://www.oscarwylee.com.au/health-funds.html)
Prioritise Your Eye Health
You only have one pair of eyes so make sure you take care of them by
booking in for an eye test at Oscar Wylee!
[Book an eye test](https://www.oscarwylee.com.au/booking)