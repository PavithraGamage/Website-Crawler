# Source: https://www.oscarwylee.com.au/glasses/best/ray-ban/alternative

# Best 8 Ray-Ban Alternatives
Published on November 9th, 2023
Updated on July 22nd, 2024
Australia    
[Australia](https://www.oscarwylee.com.au/glasses/best/ray-ban/alternative)
[Canada](https://www.oscarwylee.ca/glasses/best/ray-ban/alternative)
[Canadian French](https://oscarwylee.ca/fr/glasses/best/ray-ban/alternative)
[OW Alternatives](#OW) [Shape Alternatives](#Shape) [Ray-Ban Glasses](#Glasses) [Ray-Ban Products](#Products)
Ray-Ban is a luxury eyewear brand founded by Bausch &amp; Lomb in 1937, famous for its Wayfarer and Aviator frame shapes. Now owned by Luxottica Group, the Ray-Ban brand is used on a range of eyewear from optical glasses to sunglasses, in a selection of shapes and sizes. Ray-Ban glasses are made from a variety of materials such as acetate, titanium, nylon and metal.
For those looking for a Ray-Ban alternative in Australia, Oscar Wylee carries frames that feature the shape of the Wayfarer and Aviator frames, as well as frames made in acetate and titanium. For Ray-Ban alternatives worldwide, eyewear companies such as Oakley and Warby Parker also carry frames similar to Ray-Ban’s Wayfarer and Aviator frames, as do Polarspex, Runners Athletics and Blenders. Ray-Ban carries a range of frames for which you can find alternatives, including&nbsp;Wayfarer, Aviator, round, rectangle and Clubmaster&nbsp;glasses. The possible Ray-Ban alternatives are listed below.
* Wayfarer glasses alternative for Ray-Ban:&nbsp;Oscar Wylee has a range of frames in a Wayfarer shape, which is a horizontal rectangle shape, including the Wilder frame and the Windsor frame.
* Aviator glasses alternative for Ray-Ban:&nbsp;Aviator glasses are characterised by teardrop lenses and a double bridge. Oscar Wylee has several frames that are similarly shaped to Aviators, including Duckworth.
* Round glasses alternative for Ray-Ban:&nbsp;Oscar Wylee has a range of round glasses, which are characterised by their circular shape, including the Blake frame.
* Rectangle glasses alternative for Ray-Ban:&nbsp;Rectangle glasses are characterised by their rectangular shape, with lenses wider than they are tall. Oscar Wylee has a range of rectangular frames including Francis.
* Clubmaster glasses alternative for Ray-Ban:&nbsp;Clubmaster frames are characterised by the top of the frame having a thicker, distinguishable material than the bottom of the frame. Oscar Wylee has a similar shaped frame called Rigby.
Oscar Wylee’s top three Ray-Ban alternatives are those that are of Wayfarer, Aviator and Clubmaster shapes. These are three of the top frame shapes that Ray-Ban is most famous for and Oscar Wylee also carries frames in these shapes including the Wilder, Duckworth and Rigby frames.
Oscar Wylee does not have the right to sell or distribute Ray-Ban products. We provide such information to aid the prospective consumer in finding an alternative should they need one.
[](https://www.oscarwylee.com.au/windsor-optical.html)
[Windsor](https://www.oscarwylee.com.au/windsor-optical.html)
$169    
Add to Cart
[Shop Windsor](https://www.oscarwylee.com.au/windsor-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/windsor-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/windsor-optical.html)
[](https://www.oscarwylee.com.au/wilder-optical.html)
[Wilder](https://www.oscarwylee.com.au/wilder-optical.html)
$169    
Add to Cart
[Shop Wilder](https://www.oscarwylee.com.au/wilder-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/wilder-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/wilder-optical.html)
[](https://www.oscarwylee.com.au/duckworth-optical.html)
[Duckworth](https://www.oscarwylee.com.au/duckworth-optical.html)
$169    
Add to Cart
[Shop Duckworth](https://www.oscarwylee.com.au/duckworth-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/duckworth-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/duckworth-optical.html)
[](https://www.oscarwylee.com.au/francis-optical.html)
[Francis](https://www.oscarwylee.com.au/francis-optical.html)
$169    
Add to Cart
[Shop Francis](https://www.oscarwylee.com.au/francis-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/francis-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/francis-optical.html)
### What are Oscar Wylee’s Ray-Ban Alternatives for Men?
Oscar Wylee is an eyewear brand that has a wide range of Ray-Ban alternatives for men. Men’s glasses may have a longer nose bridge, which may better fit their wider face structure. The style, shape and colour of men’s glasses come down to personal preference, however, round, square, rectangular and round square glasses are typically the popular choice of shape with solid colours and minimal designs. Men's glasses may differ from women’s glasses according to size and width. Oscar Wylee’s glasses for men come in a wide selection of shapes and styles to fit different face shapes. Oscar Wylee has styles such as&nbsp;Andy, Alexi and Kato. Ray-Ban’s Jim, Eagle Eye and Round Metal share similarities in style and colour.&nbsp; The Oscar Wylee possible alternatives are listed below.
* Andy by Oscar Wylee:&nbsp;&nbsp;Andy may be a suitable alternative to Ray-Ban’s Jim shape with its similarly rounded and rectangular shape and gold finish. Additionally, it is a good fit for broader face shapes with its wide frame fit and is available from $169.
* Alexi by Oscar Wylee:&nbsp;Alexi, which is available from $169, is crafted as an everyday style and is characterised by their square-round and solid frames. Alexi may be an alternative for Ray-Ban’s Eagle Eye as it is similarly shaped in silhouette.
* Kato by Oscar Wylee:&nbsp;&nbsp;Kato is a wide-fit frame that is in a similar fashion to Ray-Ban’s round metal frames with its minimal and metallic style and is available from $169.
When looking for&nbsp;[men’s glasses](https://www.oscarwylee.com.au/glasses/best-men-eyeglasses-for-every-face-shape), it may be helpful to consider your face shape,&nbsp; the colours you normally wear and your lifestyle. These elements may assist you with deciding what style of glasses to opt for as they will be more tailored to your style and preferences.
[](https://www.oscarwylee.com.au/kato-optical.html)
[Kato](https://www.oscarwylee.com.au/kato-optical.html)
$169    
Add to Cart
[Shop Kato](https://www.oscarwylee.com.au/kato-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/kato-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/kato-optical.html)
### What are Oscar Wylee’s Ray-Ban Alternatives for Women?
Oscar Wylee is an eyewear brand that has a wide range of Ray-Ban alternatives for women. Women’s glasses can be characterised by their shorter nose bridge and smaller size to fit smaller face structures. Colour, style and shape differ by individual choice, however, oversized, square, round and cat-eye shapes with soft, pastel to bold statement colours have proven to be a popular choice for women. Women’s glasses may differ from men’s glasses according to size and width. Oscar Wylee’s glasses for women come in a wide selection of shapes and styles to fit different face shapes. Oscar Wylee has styles such as&nbsp;Cullen&nbsp;which could be an alternative to Ray-Ban’s Round Double Bridge as they are similarly shaped. Some of Ray-Ban’s most popular frame shapes are the Wayfarer and Aviator, which Oscar Wylee may have suitable alternatives for including&nbsp;Serge and Deus. The potential Oscar Wylee alternatives for Ray-Ban are listed below.
* Cullen by Oscar Wylee:&nbsp;Cullen may be an alternative for Ray-Ban’s Round Double Bridge which is similarly shaped with a double bridge and classic round silhouette. Cullen is a modern, street casual style available from $169.
* Serge by Oscar Wylee:&nbsp;Serge is an Oscar Wylee frame similar in shape and style to Ray-Ban’s Wayfarer frames. Serge is a bold and wide-fit frame, available in 16 colours starting from $169.
* Deus by Oscar Wylee:&nbsp;Deus is an Oscar Wylee alternative for Ray-Ban’s aviator frames as it is similar in shape. This classic style stuns in a sleek gold finish and is a true Oscar Wylee vintage signature starting from $169.
When looking for&nbsp;[women’s glasses](https://www.oscarwylee.com.au/glasses/best-women), it is important to understand what your face shape is, know what colours you naturally gravitate towards and what your lifestyle entails. This will help ensure your glasses fit you and your personality.
[](https://www.oscarwylee.com.au/serge-optical.html)
[Serge](https://www.oscarwylee.com.au/serge-optical.html)
$169    
Add to Cart
[Shop Serge](https://www.oscarwylee.com.au/serge-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/serge-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/serge-optical.html)
[](https://www.oscarwylee.com.au/deus-sunglasses.html)
[Deus](https://www.oscarwylee.com.au/deus-sunglasses.html)
$169    
Add to Cart
[Shop Deus](https://www.oscarwylee.com.au/deus-sunglasses.html)
[2 pairs from $199](https://www.oscarwylee.com.au/deus-sunglasses.html)
[3 pairs from $249](https://www.oscarwylee.com.au/deus-sunglasses.html)
Are you due for an eye test?
Oscar Wylee offers directly billed eye exams for eligible insurance cardholders.
[Book an eye test](https://www.oscarwylee.com.au/booking)
## 1. Oscar Wylee’s Ray-Ban Alternative Glasses
Oscar Wylee has a wide range of products, some of which can be chosen as an alternative to Ray-Ban glasses. Oscar Wylee is an in-store and online optical company that offers both optometry and eyewear services in Australia, New Zealand and Canada. Oscar Wylee began in 2012 as an online eCommerce business based in Sydney, Australia. Ray-Ban is an international eyewear brand that was founded in 1937 by the American eye health company, Bausch &amp; Lomb. Ray-Ban has three iconic frame shapes which are the Ray-Ban Wayfarer, Aviator and Clubmaster. Alternatives for these three styles include Oscar Wylee’s&nbsp;Buddy, Taku&nbsp; and Marco&nbsp;which are listed below.
* Buddy by Oscar Wylee:&nbsp;Buddy is an Oscar Wylee alternative for Ray-Ban’s Wayfarer frame as it shares a similar shape. Named after the rock and roll classic Buddy Holly, this frame is straight out of the 50s with a classic square-round shape and comes in two colours, Obsidian Black and Storm Grey. Buddy can be purchased at Oscar Wylee starting from $169.
* Taku by Oscar Wylee:&nbsp;Taku is an Oscar Wylee alternative for Ray-Ban’s Aviator frame as it is a similar shape. It has a streamlined modern silhouette made from stainless steel and is available in the colours Black Matte and Gold. These Aviator-style frames are perfect for heart and oval face shapes. Taku can be purchased at Oscar Wylee from $169.
* Marco by Oscar Wylee:&nbsp;Marco is an Oscar Wylee alternative for Ray-Ban’s Clubmaster frame as it is similar in shape and style. Marco is a classic brow-line frame, reimagined. It has a wide fit, spring hinges and adjustable nose pads and is available in Clear Crystal and Obsidian Black Matte. Marco can be purchased at Oscar Wylee starting from $169.
[](https://www.oscarwylee.com.au/taku-optical.html)
[Taku](https://www.oscarwylee.com.au/taku-optical.html)
$169    
Add to Cart
[Shop Taku](https://www.oscarwylee.com.au/taku-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/taku-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/taku-optical.html)
[](https://www.oscarwylee.com.au/marco-optical.html)
[Marco](https://www.oscarwylee.com.au/marco-optical.html)
$169    
Add to Cart
[Shop Marco](https://www.oscarwylee.com.au/marco-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/marco-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/marco-optical.html)
## 2. Oakley’s Ray-Ban Alternative Glasses
The eyewear brand Oakley has a wide range of products, some of which can be chosen as an alternative to Ray-Ban glasses. Oakley is an American sport and lifestyle brand that offers sunglasses, goggles and apparel. Oakley was founded in 1975 by Jim Jannard and started with motorcycle grips. Oakley is known for their bold and innovative design of athletic sunglasses which are popular for sports such as cycling and snowboarding. Ray-Ban is an eyewear brand that is known for its iconic frame shapes such as the Ray-Ban Wayfarer, Aviator and Clubmaster. Alternatives for these three styles include Oakley’s&nbsp;Leffingwell, Contrail and Frogskins&nbsp;which are listed below.
* Leffingwell by Oakley:&nbsp;Leffingwell is an Oakley alternative for Ray-Ban’s Wayfarer frame as it is a similar shape. These frames are a full-rimmed square shape that has taken inspiration from the lifestyle around surfing. Leffingwell is a subtle but elevated design that is available in many colour options.
* Contrail by Oakley:&nbsp;Contrail is an Oakley alternative for Ray-Ban’s Aviator frame as it is a similar shape. This frame is a modern take on classic pilot sunglasses which were originally created by Ray-Ban. Contrail is a lightweight and durable alloy frame that has adjustable nose pads.
* Frogskins by Oakley:&nbsp;Frogskins is an Oakely alternative for Ray-Ban’s Clubmaster frame as it is a similar shape. These frames are a classic semi-rimless style that is influenced by pop culture and sport. Frogskins come in multiple colours and lens tints such as Matte Black and Prizm Sapphire Lenses.
## 3. Warby Parker’s Ray-Ban Alternative Glasses
Warby Parker has a wide range of products, some of which can be chosen as an alternative to Ray-Ban glasses. Warby Parker is an American eyewear company that provides optical glasses, sunglasses and contact lenses. Warby Parker was founded in 2010 by Jeffrey Raider, Andrew Hunt, Neil Blumenthal and David Gilboa. Ray-Ban is an eyewear brand offering sunglasses and optical glasses that is known for its iconic frame shapes such as Wayfarer, Aviator and Clubmaster. Alternatives for these three styles include Warby Parker’s&nbsp;Fletcher, Raider and Ames&nbsp;which are listed below.
* Fletcher by Warby Parker:&nbsp;Fletcher is a Warby Parker alternative for Ray-Ban’s Wayfarer frame as it is a similar shape. This frame has a flat brow which makes it a perfect modern style with a retro feel. Fletcher is available in Crystal, Antique Shale Fade, Black Matte Eclipse and Rye Tortoise.
* Raider by Warby Parker:&nbsp;Raider is a Warby Parker alternative for Ray-Ban’s Aviator frame as it is a similar shape. This is a vintage-inspired frame in a classic aviator shape. Raider is available in Brushed Ink, Polished Gold, Polished Silver and Rose Gold.
* Ames by Warby Parker:&nbsp;Ames is a Warby Parker alternative for Ray-Ban’s Clubmaster frame as it is a similar shape. This frame has a strong browline and a large width that is perfectly versatile. Ames is available in Whiskey Tortoise with Riesling and Jet Black Matte with Polished Silver.
## 4. Knockaround's Ray-Ban Alternative Glasses
Knockaround has a wide range of products, some of which can be chosen as an alternative to Ray-Ban glasses. Knockaround is an affordable sunglasses company founded in San Diego in 2005 by Adam Moyer. This company is known for its stylish and practical sunglasses that are high-quality. Ray-Ban is an eyewear brand known for its iconic and recognisable frame shapes such as Wayfarer, Aviator and Wings. Alternatives for these three styles include Knockaround’s Fort Knocks, Mount Evans and Campeones which are listed below.
* Fort Knocks by Knockaround:Fort Knocks is a Knockaround alternative for Ray-Ban’s Wayfarer frame as it is a similar shape. This frame is a classic square shape that is durable, high-quality and easy to pair with any outfit. Fort Knocks is available in a wide array of colours including Creek Bed, Coyote Calls, Rocket Pop and Woodland.
* Mount Evans by Knockaround:&nbsp;Mount Evans is a Knockaround alternative for Ray-Ban’s Aviator-shaped frame. These rectangular Aviators are a perfect fit for an adventure with a metal frame and teardrop lenses. Mount Evans is available in many colours including Golden Hour, Gold / Aviator Green and Black / Smoke.
* Campeones by Knockaround:&nbsp;Campeones is a Knockaround alternative for Ray-Ban’s Wings frame as it is a similar shape. This rubberised wraparound frame has adjustable nose grips and flexible, non-slip arms. Campeones is available in many colour options including Spring Break, Black on Black and Magma.
## 5. Polarspex’s Ray-Ban Alternative Glasses
Polarspex has a wide range of products, some of which can be chosen as an alternative to Ray-Ban glasses. Polarspex is an online eyewear business based in Los Angeles that offers affordable and quality sunglasses. Ray-Ban is an international eyewear brand recognised for its iconic frame shapes such as Wayfarer, Aviator and Clubmaster. Alternatives for these three styles include Polarspex’s&nbsp;80’s Retro, Classic Aviator and Classic Malcom Half Frame&nbsp;which are listed below.
* 80’s Retro by Polarspex:&nbsp;80’s Retro is a Polarspex alternative for Ray-Ban’s Wayfarer frame as it is a similar shape. These modern and casual sunglasses are great for outdoor activities such as hiking or going to the beach. 80’s Retro is available for both men and women in Aqua Blue, Wolf Grey, Scarlet Red and more.
* Classic Aviator by Polarspex:&nbsp;Classic Aviator is a Polarspex alternative for Ray-Ban’s Aviator frame as it is a similar shape. These frames are a classic pilot style and are made out of military-grade lightweight aluminium materials. The Classic Aviator is available in Aluminum Black, Aluminum Gold, Aluminum Pewter and more.
* Classic Malcom Half Frame by Polarspex:&nbsp;Classic Malcom Half Frame is a Polarspex alternative for Ray-Ban’s Clubmaster frame as it is a similar shape. These frames in the Malcom collection are available in a wide variety of colours including Gloss Black, Ocean Coral, Princess Pink and Wood Grain Brown.
## 6. Runners Athletics’ Ray-Ban Alternative Glasses
Runners Athletics has a wide range of products, some of which can be chosen as an alternative to Ray-Ban glasses. Runners Athletics is an American athletic gear company founded in 2018 in Texas. Ray-Ban is an eyewear brand that is known for its iconic frame shapes such as Wayfarer, Aviator and Clubmaster. Alternatives for these three styles include Runners Athletics’&nbsp;Sprinters, Maver and Yogi&nbsp;which are listed below.
* Sprinters by Runners Athletics:&nbsp;Sprinters is a Runners Athletics alternative for Ray-Ban’s Wayfarer-shaped frames. This frame takes inspiration from the classic wayfarer style that has a perfect balance of style and engineering. Sprinters is available in many colours including Midnight Marathoner, Tortoise and Blizzard.
* Maver by Runners Athletics:&nbsp;Maver is a Runners Athletics alternative for Ray-Ban’s Aviator frame as it is a similar shape. This frame is designed for protection and performance and includes anti-fog and scratch-resistant coatings. Maver is available in Smoke, Blackout, Rose Gold and Gold.
* Yogi by Runners Athletics:&nbsp;Yogi is a Runners Athletics alternative for Ray-Ban’s Clubmaster frame as it is a similar shape. This frame blends performance, style and functionality in a semi-rimless style. They are lightweight, making them ideal for workouts and outdoor activities. Yogi is available in Clear Lilac, Blackout and more.
## 7. Tomahawk Shades’ Ray-Ban Alternative Glasses
Tomahawk Shades has a wide range of products, some of which can be chosen as an alternative to Ray-Ban glasses. Tomahawk Shades is an online sunglasses company that offers high-quality men’s and women’s frames. Ray-Ban is an online and in-store eyewear brand known for iconic frame shapes including Wayfarer, Aviator and Clubmaster. Alternatives for these three styles include Tomahawk Shades’&nbsp;Neuralyzers, Troopers and The Skylars&nbsp;which are listed below.
* Neuralyzers by Tomahawk Shades:&nbsp;Neuralyzers is a Tomahawk Shades alternative for Ray-Ban’s Wayfarer frame as it is a similar shape. This frame is available in Matte Black with a Smoke lens colour. Neuralyzers are a classic shape that is flattering for many face shapes and styles.
* Troopers by Tomahawk Shades:&nbsp;Troopers is a Tomahawk Shades alternative for Ray-Ban’s Aviator-shaped frames. This frame is made out of stainless steel and comes in the colour Gunmetal. Troopers have the distinct aviator double nose bridge and teardrop shape.
* The Skylars by Tomahawk Shades:&nbsp;The Skylers is a Tomahawk Shades alternative for Ray-Ban’s Clubmaster frame as it is a similar shape. These glasses are available in Stone Tortoise Shell with Smoke lens colour and are made out of handmade Mazzucchelli acetate and stainless steel.
## 8. Blenders’ Ray-Ban Alternative Glasses
Blenders have a wide range of products, some of which can be chosen as an alternative to Ray-Ban glasses. Blenders is an American online and in-store eyewear company founded in San Diego in 2012 that offers sun, snow and prescription gear. Ray-Ban is an international sunglasses and optical glasses brand that is known for its iconic frame shapes such as Wayfarer, Aviator and Clubmaster. Alternatives for these three styles include Blenders’&nbsp;Charter, Shadow and Starlet&nbsp;which are listed below.
* Charter by Blenders:&nbsp;Charter is a Blenders alternative for Ray-Ban’s Wayfarer frame as it is a similar shape. This is a lightweight and durable frame that is designed with mixed materials. Charter is available in Sea Holiday, Rockabye, Day Cruiser and Clear Wonder.
* Shadow by Blenders:&nbsp;Shadow is a Blenders alternative for Ray-Ban’s Aviator frame as it is a similar shape. These brow bar frames are a robust and playful design for both men and women. Shadow is available in many colours including Assertive Style, Flying Pretty and Zero Gravity.
* Starlet by Blenders:&nbsp;Starlet is a Blenders alternative for Ray-Ban’s Clubmaster-shaped frames. These glasses have a matte black rubberised frame paired with a bronze matte metal rim. Starlet is a lux frame that is available as sunglasses and blue light frames.
## What are the Best Ray-Ban Alternatives According to Models?
The best Ray-Ban alternatives according to their models, refer to the frames that are the brand’s most popular shapes. These[types of glasses](https://www.oscarwylee.com.au/glasses/types)&nbsp;include Ray-Ban’s iconic&nbsp;Wayfarer, Aviator and Clubmaster&nbsp;frame shapes. The best alternatives according to model or shape can be found in a range of places including at Oscar Wylee. The models that may be considered alternatives to Ray-Ban frames include&nbsp;Aviator, Wayfarer, Clubmaster, Erika, rectangle glasses, oval glasses, oversized glasses and hexagonal glasses&nbsp;which are listed below.
* Aviator:&nbsp;The best Ray-Ban Aviator alternatives include Oscar Wylee’s Duckworth frame as it is a similar shape. The Aviator frame is characterised by its double nose bridge and teardrop shape.
* Wayfarer:&nbsp;The best Ray-Ban Wayfarer alternatives include Oscar Wylee’s Buddy frame as it is a similar shape. The Wayfarer frame is characterised by its rectangle frame and classic D-shaped lenses.
* Clubmaster:&nbsp;The&nbsp;best Ray-Ban Clubmaster alternatives include Oscar Wylee’s Marco frame as it is a similar shape. The Clubmaster frame’s most notable feature is its strong browline, with the rest of the frame thin by comparison.
* Erika:&nbsp;The best Ray-Ban Erika alternatives include Oscar Wylee’s Alya frame as it is a similar shape. The Erika frame is characterised by rounded lenses and a soft nose bridge.
* Rectangle glasses:&nbsp;The best Ray-Ban alternative rectangle glasses include Oscar Wylee’s Francis frame as it is a similar shape. Rectangle glasses have long and sharp lines which may complement and bring balance to rounder facial features.
* Oval glasses:&nbsp;The best Ray-Ban alternative oval glasses include Oscar Wylee’s Kato frame as it is a similar shape. Ray-Ban’s oval glasses are defined by their distinctively thin, round and metal frames with a contoured bridge and adjustable nose pads.
* Oversized glasses:&nbsp;The best Ray-Ban alternatives for oversized glasses include Oscar Wylee’s Serge frames as they are similar in shape. Oversized glasses are characterised by big, exaggerated proportions.
* Hexagonal glasses:&nbsp;The best hexagonal Ray-Ban alternatives are any glasses that have 6 sides and 6 angles, and include Oscar Wylee’s Arnold frame as it is a similar shape. Hexagonal glasses are also referred to as geometric.
### What are the Best Ray-Ban Aviator Alternatives?
The best Ray-Ban Aviator alternatives are the Oscar Wylee frames&nbsp;Duckworth, Dexter and Deus&nbsp;as they are similar in shape and style. Ray-Ban’s Aviators are characterised by their teardrop lenses and a classic double bridge. While originally intended for protection against glare for pilots in the Army Corps, it was later established in the market for public access in 1937. The list of the best Oscar Wylee Ray-Ban alternatives is found below.
* Duckworth by Oscar Wylee:&nbsp;Duckworth is a great alternative for Ray-Ban’s Aviator frames as it is a similar shape. It is available in Candy Brown, Citrus, Clear Crystal, Moonstone Grey and Obsidian Black Matte. Duckworth takes on the signature Aviator style with a modern-day upgrade going slightly oversized while still staying lightweight, starting from $169.
* Dexter by Oscar Wylee:&nbsp;Dexter offers a sleek acetate alternative to Ray-Ban’s popular Aviator frame shape featuring polished metal temples and adjustable nose pads. Dexter can sit perfectly on heart and oval face shapes with its medium-fit frame and is available from $169.
* Deus by Oscar Wylee:&nbsp;&nbsp;Deus, starting from $169, is an Oscar Wylee vintage-style signature that is easy to wear and an essential stainless steel frame for anyone’s collection.
[](https://www.oscarwylee.com.au/duckworth-optical.html)
[Duckworth](https://www.oscarwylee.com.au/duckworth-optical.html)
$169    
Add to Cart
[Shop Duckworth](https://www.oscarwylee.com.au/duckworth-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/duckworth-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/duckworth-optical.html)
[](https://www.oscarwylee.com.au/deus-sunglasses.html)
[Deus](https://www.oscarwylee.com.au/deus-sunglasses.html)
$169    
Add to Cart
[Shop Deus](https://www.oscarwylee.com.au/deus-sunglasses.html)
[2 pairs from $199](https://www.oscarwylee.com.au/deus-sunglasses.html)
[3 pairs from $249](https://www.oscarwylee.com.au/deus-sunglasses.html)
### What are the Best Ray-Ban Wayfarer Alternatives?
The best Ray-Ban Wayfarer alternatives are the Oscar Wylee frames&nbsp;Buddy, Jinky and Oliver&nbsp;as they are similar in shape and style. Wayfarer frames are characterised by a broad upper rim and rounded lenses. Wayfarer frames are one of Ray-Ban's most sought-after frame shapes and were popularised by Hollywood stars such as Audrey Hepburn in Breakfast at Tiffany's. The best Ray-Ban Wayfarer alternatives are listed below.
* Buddy by Oscar Wylee:&nbsp;Oscar Wylee’s Buddy frame is a Wayfarer alternative as it is similar in shape, featuring a bold brow line that tapers to a point and rounded lenses. Inspired by the fashion of the 50s, Buddy is a bold, retro acetate frame.
* Jinky by Oscar Wylee:&nbsp;Jinky is an Oscar Wylee frame that works as a Wayfarer alternative as it has a similar shape, featuring a strong upper rim, with D-shaped lenses.
* Oliver by Oscar Wylee:&nbsp;Oscar Wylee’s Oliver frame is a Wayfarer alternative as they are a similar shape, featuring a strong browline and bold frame. Oliver is a powerful yet playful rectangle frame with double bolt detailing.
[](https://www.oscarwylee.com.au/jinky-optical.html)
[Jinky](https://www.oscarwylee.com.au/jinky-optical.html)
$169    
Add to Cart
[Shop Jinky](https://www.oscarwylee.com.au/jinky-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/jinky-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/jinky-optical.html)
[](https://www.oscarwylee.com.au/oliver-optical.html)
[Oliver](https://www.oscarwylee.com.au/oliver-optical.html)
$169    
Add to Cart
[Shop Oliver](https://www.oscarwylee.com.au/oliver-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/oliver-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/oliver-optical.html)
### What are the Best Ray-Ban Clubmaster Alternatives?
The best Ray-Ban Clubmaster alternatives are Oscar Wylee’s&nbsp;Hunter, Bentley and Marco&nbsp;as they are similar in shape and style. Ray-Ban Clubmaster-shaped frames are characterised by their signature retro style with a distinctive thicker material on the top of the frame.&nbsp;&nbsp;The best Ray-Ban Clubmaster alternatives are listed below.
* Hunter by Oscar Wylee:&nbsp;Hunter is a strong contender for alternatives to Ray-Ban’s Clubmaster frame shape with their similar thicker upper rim and single nose bridge.
* Ellis by Oscar Wylee:&nbsp;Ellis offers a fresh take on a classic style. The frame is smart, sleek and lightweight made from a mix of materials including acetate and metal, and available in Obsidian Black Matte.
* Marco by Oscar Wylee:&nbsp;&nbsp;Marco sports a unique thick browline in a sunglasses style, helping you stay in style while protecting your eyes.
[](https://www.oscarwylee.com.au/hunter-sunglasses.html)
[Hunter](https://www.oscarwylee.com.au/hunter-sunglasses.html)
$169    
Add to Cart
[Shop Hunter](https://www.oscarwylee.com.au/hunter-sunglasses.html)
[2 pairs from $199](https://www.oscarwylee.com.au/hunter-sunglasses.html)
[3 pairs from $249](https://www.oscarwylee.com.au/hunter-sunglasses.html)
[](https://www.oscarwylee.com.au/marco-sunglass.html)
[Marco](https://www.oscarwylee.com.au/marco-sunglass.html)
$169    
Add to Cart
[Shop Marco](https://www.oscarwylee.com.au/marco-sunglass.html)
### What are the Best Ray-Ban Erika Alternatives?
The best Ray-Ban Erika alternatives include Oscar Wylee frames such as&nbsp;Alya, Aries and Luca&nbsp;as they are similar in shape and style. The Erika frame is characterised by rounded lenses and a soft nose bridge. The best Ray-Ban Erika alternatives are listed below.
* Alya by Oscar Wylee:&nbsp;Oscar Wylee’s&nbsp;Alya&nbsp;frame is a Ray-Ban Erika alternative frame shape, featuring a similar rounded shape and soft nose bridge.
* Aries by Oscar Wylee:&nbsp;Aries is a soft rounded Oscar Wylee frame with a delicate nose bridge that will work as an alternative for the Erika frame shape.
* Luca by Oscar Wylee: Oscar Wylee’s Luca frame is a Ray-Ban Erika alternative frame shape, featuring a similar soft rounded frame and a subtle, keyhole nose bridge.
[](https://www.oscarwylee.com.au/alya-optical.html)
[Alya](https://www.oscarwylee.com.au/alya-optical.html)
$169    
Add to Cart
[Shop Alya](https://www.oscarwylee.com.au/alya-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/alya-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/alya-optical.html)
[](https://www.oscarwylee.com.au/aries-optical.html)
[Aries](https://www.oscarwylee.com.au/aries-optical.html)
$169    
Add to Cart
[Shop Aries](https://www.oscarwylee.com.au/aries-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/aries-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/aries-optical.html)
[](https://www.oscarwylee.com.au/luca-optical.html)
[Luca](https://www.oscarwylee.com.au/luca-optical.html)
$169    
Add to Cart
[Shop Luca](https://www.oscarwylee.com.au/luca-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/luca-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/luca-optical.html)
### What are the Best Ray-Ban Alternative Rectangle Glasses
The best Ray-Ban alternative rectangle glasses are Oscar Wylee’s&nbsp;Francis,&nbsp;Windsor&nbsp;and&nbsp;Miles&nbsp;frames as they are similar in shape and style. Rectangle glasses have long and sharp lines which may complement and bring balance to rounder facial features. The best Ray-Ban alternative rectangle glasses are listed below.
* Francis by Oscar Wylee:&nbsp;Francis is a Ray-Ban rectangle frame alternative as it is similar in shape with its modern and universally flattering style.
* Windsor by Oscar Wylee:&nbsp;Windsor is a striking rectangular frame shape with a prominent acetate finish and is available in four different colours.
* Miles by Oscar Wylee:&nbsp;Miles is an essential frame, perfect for everyday wear with its lightweight feel and versatile style.
[](https://www.oscarwylee.com.au/francis-optical.html)
[Francis](https://www.oscarwylee.com.au/francis-optical.html)
$169    
Add to Cart
[Shop Francis](https://www.oscarwylee.com.au/francis-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/francis-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/francis-optical.html)
[](https://www.oscarwylee.com.au/windsor-optical.html)
[Windsor](https://www.oscarwylee.com.au/windsor-optical.html)
$169    
Add to Cart
[Shop Windsor](https://www.oscarwylee.com.au/windsor-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/windsor-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/windsor-optical.html)
[](https://www.oscarwylee.com.au/miles-optical.html)
[Miles](https://www.oscarwylee.com.au/miles-optical.html)
$169    
Add to Cart
[Shop Miles](https://www.oscarwylee.com.au/miles-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/miles-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/miles-optical.html)
### What are the Best Ray-Ban Alternative Oval Glasses?
The best Ray-Ban alternative oval glasses are Oscar Wylee’s&nbsp;Kato,&nbsp;Alya&nbsp;and&nbsp;Luca&nbsp;as they are similar in shape and style. Ray-Ban’s oval glasses are defined by their distinctively thin, round and metal frames with a contoured bridge and adjustable nose pads. The best Ray-Ban alternative oval glasses are listed below.
* Kato by Oscar Wylee:&nbsp;Kato is a minimalist, modern and sleek style that would work as an ideal alternative to Ray-Ban’s oval glasses shapes.
* Alya by Oscar Wylee:&nbsp;Alya is a durable, comfortable and lightweight oval frame and is a suitable complement to angular face features.
* Luca by Oscar Wylee:&nbsp;Luca features spring hinges, a distinctive keyhole nose bridge and a medium frame fit, which all make for a staple and comfortable pair in anyone’s collection.
[](https://www.oscarwylee.com.au/kato-optical.html)
[Kato](https://www.oscarwylee.com.au/kato-optical.html)
$169    
Add to Cart
[Shop Kato](https://www.oscarwylee.com.au/kato-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/kato-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/kato-optical.html)
[](https://www.oscarwylee.com.au/alya-optical.html)
[Alya](https://www.oscarwylee.com.au/alya-optical.html)
$169    
Add to Cart
[Shop Alya](https://www.oscarwylee.com.au/alya-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/alya-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/alya-optical.html)
[](https://www.oscarwylee.com.au/luca-optical.html)
[Luca](https://www.oscarwylee.com.au/luca-optical.html)
$169    
Add to Cart
[Shop Luca](https://www.oscarwylee.com.au/luca-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/luca-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/luca-optical.html)
### What are the Best Ray-Ban Alternative Oversized Glasses?
The best Ray-Ban alternatives for oversized glasses are Oscar Wylee’s&nbsp;Serge, Mesa and Lincoln&nbsp;frames as they are similar in shape and style. Oversized glasses are characterised by big, exaggerated frames. The best Ray-Ban alternatives for oversized glasses are listed below.
* Serge by Oscar Wylee:&nbsp;Serge is an alternative to Ray-Ban oversized glasses shapes. Serge is a bold, oversized frame, suitable for a range of face shapes.
* Mesa by Oscar Wylee:&nbsp;Oscar Wylee’s Mesa frame is an alternative to oversized Ray-Ban glasses shapes. Mesa is a slightly oversized frame that comes in a variety of colours.
* Poppy by Oscar Wylee:&nbsp;Poppy is an alternative to Ray-Ban oversized glasses shapes. Poppy is a perfectly oversized frame with a sweeping square shape, ideal for those with oval and round faces.
[](https://www.oscarwylee.com.au/serge-optical.html)
[Serge](https://www.oscarwylee.com.au/serge-optical.html)
$169    
Add to Cart
[Shop Serge](https://www.oscarwylee.com.au/serge-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/serge-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/serge-optical.html)
[](https://www.oscarwylee.com.au/mesa-optical.html)
[Mesa](https://www.oscarwylee.com.au/mesa-optical.html)
$169    
Add to Cart
[Shop Mesa](https://www.oscarwylee.com.au/mesa-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/mesa-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/mesa-optical.html)
[](https://www.oscarwylee.com.au/poppy-optical.html)
[Poppy](https://www.oscarwylee.com.au/poppy-optical.html)
$169    
Add to Cart
[Shop Poppy](https://www.oscarwylee.com.au/poppy-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/poppy-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/poppy-optical.html)
### What are the Best Hexagonal Ray-Ban Alternatives?
The best hexagonal Ray-Ban alternatives are any glasses that have 6 sides and 6 angles and include Oscar Wylee’s&nbsp;Arnold, Kasia and Farrell&nbsp;frames as they are similar in shape and style. The best hexagonal Ray-Ban alternatives are listed below.
* Arnold by Oscar Wylee:&nbsp;Arnold is an Oscar Wylee alternative to Ray-Ban hexagonal frame shapes. Arnold is characterised by its 6 distinct sides and angles, adjustable nose pads and a matte finish.
* Kasia by Oscar Wylee:&nbsp;Oscar Wylee’s Kasia frame is a Ray-Ban alternative for hexagonal-shaped frames. Kasia is a chic geometric frame with six sides, featuring a bold upper rim.
* Farrell by Oscar Wylee:&nbsp;Farrell is an Oscar Wylee frame that works as an alternative to Ray-Ban’s hexagonal frame shapes. Farrell has unique and fun hexagonal features, a matte finish and adjustable nose pads.
[](https://www.oscarwylee.com.au/farrell-optical.html)
[Farrell](https://www.oscarwylee.com.au/farrell-optical.html)
$169    
Add to Cart
[Shop Farrell](https://www.oscarwylee.com.au/farrell-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/farrell-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/farrell-optical.html)
### What are the Best Ray-Ban Alternatives in Terms of Quality of Material?
Ray-Ban glasses are made from a range of materials including&nbsp;acetate, metal and titanium. Acetate is a type of bio-plastic that is soft, flexible and hypoallergenic. Metal can include a range of materials such as stainless steel. Stainless steel frames can be lightweight, comfortable and long-lasting. Titanium is a type of metal that is both lightweight, strong and durable. The best Oscar Wylee Ray-Ban alternatives in terms of material are listed below.
* Acetate:&nbsp;Oscar Wylee has a range of frames made from acetate including Serge and Mesa.
* Metal:&nbsp;Oscar Wylee has a range of glasses in metal, specifically stainless steel, including Soma, Betty and Ford.
* Titanium:&nbsp;Oscar Wylee has a range of frames made from titanium material including Spence, Andy and Micah.
[](https://www.oscarwylee.com.au/serge-optical.html)
[Serge](https://www.oscarwylee.com.au/serge-optical.html)
$169    
Add to Cart
[Shop Serge](https://www.oscarwylee.com.au/serge-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/serge-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/serge-optical.html)
[](https://www.oscarwylee.com.au/mesa-optical.html)
[Mesa](https://www.oscarwylee.com.au/mesa-optical.html)
$169    
Add to Cart
[Shop Mesa](https://www.oscarwylee.com.au/mesa-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/mesa-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/mesa-optical.html)
[](https://www.oscarwylee.com.au/betty-optical.html)
[Betty](https://www.oscarwylee.com.au/betty-optical.html)
$169    
Add to Cart
[Shop Betty](https://www.oscarwylee.com.au/betty-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/betty-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/betty-optical.html)
#### Are Ray-Ban Glasses Worth it?
Yes,&nbsp;we believe that Ray-Ban glasses are worth it.&nbsp;Ray-Ban has a long history of supplying its customers with high-quality eyewear since it was founded in the 1930s. Ray-Ban is a reliable brand with fashionable sunglasses and optical glasses. However, Ray-Ban glasses may not be an affordable choice for consumers as their glasses come at a premium price which is why we believe Oscar Wylee may be an alternative to Ray-Ban.
Find your local Oscar Wylee store
Come in and see our friendly team at Oscar Wylee. All major health insurances are accepted in store.
[Find a store](https://www.oscarwylee.com.au/locations/)
## What To Know About Ray-Ban Glasses?
There are several key points to know about Ray-Ban Including&nbsp;their models, what materials their frames are made from and their popularity. Ray-Ban was founded by Bausch &amp; Lomb in 1937 and is now owned by Luxottica Group. Ray-Ban carry a variety of models in their frames including Wayfarer, Aviator and Clubmaster frames. Ray-Ban makes its frames from a variety of materials including acetate, metal and titanium.&nbsp; What to know about Ray-Ban is listed below.
* Models:&nbsp;Ray-Ban has a variety of models such as Erika and Wings but is most famous for their Wayfarer, Aviator and Clubmaster frame shapes.
* Materials:&nbsp;Ray-Ban uses a variety of materials to make their frames including acetate, metal and titanium.
* Popularity:&nbsp;Ray-Ban is a hugely popular glasses brand due to their fashionable frames, worn by many famous Hollywood faces including Audrey Hepburn in Breakfast at Tiffany’s and Tom Cruise in Top Gun.
### Who Founded Ray-Ban?
Ray-Ban was founded by&nbsp;Bausch &amp; Lomb in 1937. Bausch &amp; Lomb is an American company specialising in eye health products such as contact lenses. Ray-Ban was created by Bausch &amp; Lomb as a result of pilots in the US Air Force needing glasses that would protect their eyes from sun glare. Ray-Ban helped in creating these glasses, which would become the Aviator glasses, one of Ray-Ban's most famous frame shapes.
Oscar Wylee does not have the right to sell or distribute Ray-Ban products. We provide such information to aid the prospective consumer in finding an alternative should they need one.
#### Who is the Owner of Ray-Ban?
The owner of Ray-Ban is the Luxottica Group which is an eyewear conglomerate founded in 1961 by Leonardo Del Vecchio with its headquarters based in Milan, Italy. This company also owns other eyewear brands such as Oakley, Persol and Costa Del Mar.
##### Where is the Headquarters of Ray-Ban?
The headquarters of Ray-Ban are located in Milan, Italy. The Luxottica Group, which is the owner of Ray-Ban, has its headquarters located in Italy but also has multiple international offices
##### What are the Product Lines of Ray-Ban?
Ray-Ban has many iconic product lines, some of which were staples from the beginning and some that have been added in the past few decades. The product lines of Ray-Ban include&nbsp;Wayfarer, Aviator, Clubmaster, Erika, Wings and Jack.
* Wayfarer by Ray-Ban:&nbsp;Wayfarer frames are an iconic Ray-Ban style first released in 1952. The Wayfarer style is characterised by a trapezoidal shape and is one of the most recognisable styles in sunglasses.
* Aviator by Ray-Ban:&nbsp;Aviator frames are another iconic style made by Ray-Ban which was originally designed for military pilots. The Aviator shape typically has a double nose bridge, metal frame and teardrop shape.
* Clubmaster by Ray-Ban:&nbsp;Clubmaster frames are a very distinct Ray-Ban style, characterised by a rimless or thin rim base and a thick upper part of the frame. According to Ray-Ban, Clubmaster was inspired by the 1960s counterculture and embodies a retro intellectual style.
* Erika by Ray-Ban:&nbsp;Ray-Ban’s Erika frames are one of the most popular male styles and have an oversized, round shape. Erika has a rubber front with metal temples and tips as well as a soft nose bridge.
* Wings by Ray-Ban:&nbsp;The Wings Ray-Ban style is straight out of the 80s with flat temples and a flat double bridge with a one-piece nose pad. Wings have an iconic slick, square shape that can be customised with different colour combinations.
* Jack by Ray-Ban:&nbsp;The Jack frame is a modernised round shape with a slim metal structure. Ray-Ban describes Jack as leading tradition on a new adventure. Jack is available in many colours and lens options.
Oscar Wylee does not have the right to sell or distribute Ray-Ban products. We provide such information to aid the prospective consumer in finding an alternative should they need one.
###### What to Know about Wayfarer Glasses?
Ray-Ban Wayfarer glasses are an iconic sunglasses shape that was first released by Ray-Ban in 1952 when moldable plastics became popular. This style of sunglasses is a shift from functionality to style. The Wayfarer is a trapezoidal shape that is a versatile style and available in multiple colour combinations. According to Ray-Ban, Wayfarers capture the spirit of adventure and are great for expressing your unique personality. The average cost of Ray-Ban Wayfarer glasses ranges due to promotions and also the different customisations a customer can choose such as lens options and colour combinations.
###### What to Know about Aviator Glasses?
Aviator glasses are one of Ray-Ban's most popular styles and were their first ever style of glasses which were designed as pilot sunglasses for the US military in 1937. The iconic Aviator style is characterised by a double nose bridge, teardrop lenses and metal frame. Aviators are a timeless classic in an American style that has endured in popularity since it was first created. Ray-Ban has Aviator glasses for both men and women and different lens options including polarisation and tints. There are also many colour combinations customers can choose from. The average cost of Ray-Ban Aviator glasses ranges due to promotions and also the different customisations a customer can choose such as lens options and colour combinations.
###### What to Know about Erika Glasses?
Erika glasses are a style of Ray-Ban frame that is one of their most popular styles for men. Erika is an oversized frame with a round shape that is sophisticated and sleek with a vintage feel. The frame has a rubber front with metal temples and tips as well as a soft bridge. Erika comes in a selection of different colours including classic and vibrant options so the wearer can find a combination that will compliment their style. The average cost of Ray-Ban Erika glasses ranges due to promotions and also the different customisations a customer can choose such as colour combinations and lens options.
#### What are the Ray-Ban Smart Glasses?
Ray-Ban smart glasses are wearable technology that has built-in camera and audio capabilities allowing the wearer to take photos and videos, listen to music and directly post content to their social media. Ray-Ban smart glasses come in three different shapes, available in both optical glasses and sunglasses. The features of Ray-Ban smart glasses include a dual 5MP camera for high-quality photos, open-ear speakers with three built-in microphones, voice and touch control to play music or take a photo and a portable charging case that provides a full charge that lasts for 6 hours.
Read Best 8 Ray-Ban Alternatives in other Oscar Wylee regions and their languages.
Australia    
[Australia](https://www.oscarwylee.com.au/glasses/best/ray-ban/alternative)
[Canada](https://www.oscarwylee.ca/glasses/best/ray-ban/alternative)
[Canadian French](https://oscarwylee.ca/fr/glasses/best/ray-ban/alternative)
Get a Full Quote in Store
Get fitted for your multifocal glasses at Oscar Wylee by visiting us in store and talk to our friendly staff for a complete quote.
[Find a store](https://www.oscarwylee.com.au/locations/)
Renew Your Prescription
Don’t let your eye health get away from you. Renew your glasses prescription with an Oscar Wylee optometrist today.
[Book an eye test](https://www.oscarwylee.com.au/booking)