# Source: https://www.oscarwylee.com.au/glasses/eye/lazy-definition

# Lazy Eye (Amblyopia): Causes, Symptoms, Diagnosis, and Treatment
Published on February 14th, 2023
Updated on May 7th, 2025
Australia    
[Australia](https://www.oscarwylee.com.au/glasses/eye/lazy-definition)
[Canada](https://oscarwylee.ca/glasses/eye/lazy-definition)
[Canadian French](https://oscarwylee.ca/fr/glasses/eye/lazy-definition)
Lazy eye, also known as amblyopia, is an eye condition where one of the eyes has worse vision than the other, due to development issues. Lazy eye occurs when one eye does not develop the same level of vision skills as the other, causing the brain to favour the unaffected eye.
What causes lazy eye?
Lazy eye is caused&nbsp;by genetic issues, injury, birth defect, or&nbsp;by other types of eye conditions, such as strabismus. Lazy eye makes the brain ignore the visual images from the lazy eye, causing further eye issues. Lazy eye is most commonly cured by blocking or reducing the stronger eye’s ability to see with an eyepatch, glasses filters or eye drops. This forces the lazy eye to undergo development and eventually improve in vision.
Lazy eye is most commonly diagnosed and treated in childhood, but it also occurs in adults and any other stage of life. Lazy eyes that are untreated have a risk of causing permanent blindness in the affected eye.
See our optometrists
Don’t let your eyes' health get away from you. Renew your glasses prescriptions with an Oscar Wylee optometrist today.
[Book your appointment](https://www.oscarwylee.com.au/booking)
[Definition](#Definition) [Symptoms](#Symptoms) [Causes](#Causes) [Treatments](#Treatments)
## What is Lazy Eye (Amblyopia)?
Lazy eye (amblyopia), is an eye condition where&nbsp;one eye has poorer, weaker vision than the other due to developmental issues, such as unusual nerve pathways to the retina resulting in fewer visual signals from the eye being sent to the brain. Other eye conditions that cause lazy eye include misaligned eyes or crossed eyes resulting in one eye being favoured by the brain, creating poorer vision in the other.
What does a lazy eye look like?
A Lazy eye can look like a crossed eye or turned eye. However, as the condition is the result of a weak eye it can look many other ways as well, such as misaligned eyes, one eye that doesn’t move with focus, or an eye that turns or shakes when the other eye moves. A lazy eye can also look entirely normal as well.
### What Does a Lazy Eye (Amblyopia) Look Like?
A Lazy eye can change appearance depending on the cause, such as the eyes appearing turned due to strabismus, or the lazy eye being covered by the eyelid due to ptosis. In the following image of a lazy eye, the cause is strabismus, which has caused the eye to turn inward.
### How Common is Lazy Eye (Amblyopia)?
Lazy eye is a common condition that&nbsp;affects 3 in 100 children, according to the National Eye Institute, an institute of the American government. Lazy eye is most commonly noticed and treated in childhood, and lazy eye is the number one cause of blindness in children.
Lazy eye affects approximately 1 in 33 people, and affects 5% of the adult population as well, according to Optometrists Network, an optometry and eye health organisation based in America.
## What are the Symptoms of Lazy Eye (Amblyopia)?
The symptoms of lazy eye (amblyopia) may include&nbsp;eye misalignment, either nearsightedness or farsightedness, repeated squinting and closing of the eyes&nbsp;and&nbsp;crossed eyes.
The following list details the symptoms and how to tell if you may have a lazy eye (amblyopia).
* Eye misalignment (Strabismus):&nbsp;Eye misalignment is when both eyes do not face the same direction.
* Either near or farsightedness:&nbsp;Either near or farsightedness is when the eye cannot see or focus on either up-close or far away distances. Farsightedness is more often the cause of lazy eye than nearsightedness.
* Repeated squinting and closing of the eyes:&nbsp;Repeated squinting and closing of the eyes is when the eyes keep trying to adjust by squinting or closing in a constant fashion.
* Crossed eyes:&nbsp;Crossed eyes, or strabismus is when one eye is constantly and noticeably facing in a single, different direction to the other eye.
It is often that lazy eyes have no symptoms at all in cases of anisometropia - a difference in prescription between the eyes.
### 1. Eye Misalignment, Often Known as Strabismus
Eye misalignment, often known as strabismus, is a completely separate eye development condition to lazy eye, in which the eyes are misaligned due to a variety of reasons, including head injuries and abnormal development of the eye muscles.&nbsp;[Strabismus](https://www.oscarwylee.com.au/glasses/eye/crossed-definition)&nbsp;precedes amblyopia and is often noticed first. Amblyopia typically has no symptoms.
Although strabismus and amblyopia are completely different conditions, untreated strabismus can result in lazy eye developing due to the misaligned eye not being able to see, meaning the brain will eventually favour the working eye.
Treatments for strabismus are corrective prescriptions, surgery on the eye muscles, strengthening the eye muscles with exercises and, in some cases, covering the strong eye with an eye patch to develop the weak eye further.
Symptoms of strabismus to be on the lookout include crossed eyes, only one eye having vision and eye movements with poor coordination.
### 2. Either Nearsightedness or Farsightedness
Nearsightedness and farsightedness refers to refractive errors where the eye does perceive objects at a certain distance, due to light not focusing properly on the retina.&nbsp;[Nearsightedness](https://www.oscarwylee.com.au/glasses/eye/nearsightedness), also called myopia, is a separate condition to amblyopia and refers to eyes not being able to focus on objects far away. Farsightedness, also known as&nbsp;[hyperopia](https://www.oscarwylee.com.au/glasses/eye/hyperopia), is a separate condition to amblyopia in which the eyes struggle to focus on objects nearby.
Excessive far-sightedness in amblyopia causes the eyes to be unable to work in sync, severely decreasing or negating the eye's binocular vision and ability to perceive depth with clarity. Nearsightedness won’t cause amblyopia unless there is an extreme difference in the prescription between the 2 eyes.
Near or farsightedness is treated most predominantly through prescription glasses and contact lenses. Near or farsightedness as it relates to amblyopia may be treated through corrective prescriptions, covering the strong eye with an eye patch and cycloplegic eye drops in the strong eye.
Symptoms of near or far sightedness can be spotted by blurry vision, squinting and holding objects up close or far away.
### 3. Repeated Squinting or Closing of the Eyes
Repeated squinting or closing of the eyes is a symptom of both amblyopia and strabismus, and is a major symptom of an unrelated disorder called blepharospasm. Repeated squinting and closing of the eyes in amblyopia occurs because the working eye is becoming exhausted or the lazy eye is interfering with vision and a person with lazy eye is trying to shut it or create more focus on it.
‘Squinting’ is also used as an alternative term for strabismus. Squinting because of strabismus is caused by different factors than squinting because of Amblyopia, and the exact reason for the squinting must be diagnosed and will have different treatments, depending on the condition.
Treatments for repeated squinting or closing of the eyes for amblyopia are prescription glasses, eye exercises to strengthen the affected eye’s muscles, and an eye patch over the stronger eye to force the weaker eye to develop.
Symptoms of repeated or squinting eyes refers to how often a child or adult is consistently closing their eyes or squinting when looking at near or distant objects.
### 4. Crossed Eyes
Crossed eyes are a symptom of amblyopia and strabismus, but most commonly and notably strabismus, where the eyes don’t face the same direction or are visibly not focusing on the same object.&nbsp;[Crossed Eyes](https://www.oscarwylee.com.au/glasses/eye/crossed-definition)&nbsp;could be caused by genetics, injury or a variety of medical conditions.
Crossed eyes in amblyopia are not as common and often connected more to strabismus, but a crossed eye can still be a lazy eye and amblyopia may be a result of an untreated crossed eye.
Crossed eyes are treated by prescription glasses, exercising the muscles of the eyes and an eye patch temporarily placed over the strong eye to force the weaker eye to re-adjust.
Symptoms of crossed eyes can be spotted by the visual appearance of one eye not moving, being out of sync with the other eye or constant squinting, especially in sunlight.
## What are the Causes of Lazy Eye (Amblyopia)?
The causes of lazy eye are&nbsp;deprivation, glaucoma, refractive amblyopia, a trauma that causes damage to one of your eyes, strabismus amblyopia, one of your eyelids is dropping, corneal scarring or ulcer&nbsp;and&nbsp;surgery on the eyes.
How do you get lazy eye (amblyopia)?
The causes of lazy eye (amblyopia) are listed below.
* Deprivation:&nbsp;Deprivation occurs when the eyes are deprived of vision such as in congenital cataracts or similar conditions which prevent light from entering the eye.
* Refractive amblyopia:&nbsp;Refractive amblyopia occurs when the eyes focus at different levels, causing the brain to favour the better focusing eye.
* A trauma that causes damage to one of your eyes:&nbsp;A trauma that causes damage to one of your eyes will result in the eye favouring one eye over the other, leading to lazy eye.
* Strabismus amblyopia:&nbsp;Strabismus amblyopia occurs when strabismus/eye turn results in the associated eye becoming lazy.
* One of your eyelids is dropping:&nbsp;One of your eyelids causes a blocking of one eye and affect’s it’s development, possibly resulting in lazy eye.
* Corneal scarring or ulcer:&nbsp;Corneal scarring or ulcer causes lazy eye through deprivation making the brain favour the stronger, undamaged eye.
* Unsuccessful surgery on the eyes:&nbsp;Surgery on the eyes causes lazy eye by due to damage or mislalignment caused by the surgery.
### 1. Deprivation Amblyopia
Deprivation amblyopia is the term for&nbsp;amblyopia that develops because of cataracts or other issues with the lens of one eye&nbsp;preventing the eye from developing its visual acuity. Drooping eyelids, or ptosis, may also be a noticeable symptom of deprivation amblyopia and will appear like a falling or drooping eyelid that is partially covering one eye.
### 2. Refractive Amblyopia
Refractive amblyopia is&nbsp;amblyopia that is caused by a difference in focusing between the two eyes&nbsp;due to other eye conditions such as hyperopia or myopia. It is also possible for there to be an eye condition in both eyes and the brain is simply choosing to focus on the least affected eye, neglecting development of the lazy eye.
### 3. A Trauma that Causes Damage to One of Your Eyes
A trauma that causes damage to one of your eyes refers to injuries and traumatic damage that has left short or long term damage to the head and eyes. A trauma that causes damage to one of your eyes is a cause of amblyopia because it&nbsp;disrupts one eye's full ability to see,&nbsp;leading to possible lazy eye due to the brain favouring the undamaged eye.
### 4. Strabismus Amblyopia
Strabismus amblyopia is the most common cause for lazy eye. Strabismus amblyopia is&nbsp;lazy eye that is caused by weakness or imbalance in the muscles of one of the eyes.&nbsp;The eye turn then causes the brain to favour the stronger, unaffected eye leading to amblyopia in the eye with strabismus.
### 5. One of your Eyelids is Dropping
One of your eyelids is dropping refers to eye conditions, such as ptosis, affecting one of the eyelids enough that it is uncontrollably hanging over one eye. One of your eyelids dropping causes&nbsp;lazy eye because by blocking one eye,&nbsp;it affects the development of the other eye.
### 6. Corneal Scarring or Ulcer
Corneal scarring or a corneal ulcer refers to damage, trauma, or other conditions that prevent the cornea of the eye from functioning properly. Corneal scarring or ulcer causes lazy eye because&nbsp;the condition may make one eye weaker,&nbsp;resulting in the brain favouring the stronger eye.
### 7. Unsuccessful Surgery on the Eyes
Surgery is often performed to treat amblyopia, particularly strabismus, however can sometimes be unsuccessful.&nbsp;This leaves amblyopia untreated and causes a lazy eye to remain.
### What Causes a Lazy Eye (Amblyopia) in Adults?
Lazy eye in adults doesn't usually happen. If an adult develops sudden onset strabismus later in life, urgent investigation is required for nerve palsy.
## How to Diagnose a Lazy Eye (Amblyopia)?
A healthcare professional such as an optometrist, will diagnose a lazy eye (amblyopia). Visiting an optometrist is how you will know if you have a lazy eye as they will conduct several diagnostic tests. First, they will&nbsp;perform a standard eye test. During this exam, they will&nbsp;check the visual acuity in both eyes. If symptoms of lazy eye are found, or if one eye is diagnosably weaker than the other, then&nbsp;the difference in vision between the eyes will be tested. This may involve covering one eye and seeing how well the other follows a moving object. If the lazy eye is confirmed, then the eye doctor will move on to treatments and treatment options.
Tests for lazy eye are most commonly performed on children, as that is when the symptoms are most common and is the best time to begin treatment of lazy eye if it is found.
Please be advised not all Oscar Wylee stores have children's vision testing available.
Find a store near you
Get in touch with your nearest store for a full quote.
[Find a store](https://www.oscarwylee.com.au/locations/)
## What are the Treatments for Lazy Eye (Amblyopia)?
Lazy eye (amblyopia) treatments are&nbsp;corrective eyeglasses or contact lenses, patches for the eyes, bangerter filter, eye drops, surgery in the eye,&nbsp;and&nbsp;eye training.&nbsp;The treatments for lazy eye are listed below.
* Corrective eyeglasses or contact lenses:&nbsp;corrective eyeglasses or contact lenses can treat lazy eye by treating eye conditions that are behind the amblyopia.
* Patches for the eyes:&nbsp;patches for the eyes can treat lazy eye by covering the stronger, more favoured eye, which forces the lazy eye to develop the strength and acuity it may have been lacking, and be recognized as a source of sight by the brain.
* Bangerter filter:&nbsp;A bangerter filter is a glasses filter that will decrease vision in the strong eye, which treats lazy eye by forcing the affected, weaker eye to develop.
* Eye drops:&nbsp;Eye drops, specifically cycloplegic eye drops, can be used to treat lazy eye by affecting the strong eye’s vision, forcing more usage of the lazy eye and helping it’s development.
* Surgery in the eye:&nbsp;surgery in the eye can treat lazy eye by treating any possible health conditions that may result in amblyopia.
* Eye training:&nbsp;Eye training can treat lazy eye by using drills and exercises to strengthen the weaker eye.
### 1. Corrective Eyeglasses or Contact Lenses
Corrective eyeglasses or contact lenses for lazy eye (amblyopia) are prescription glasses and corrective lenses that are&nbsp;used to correct the eye affected with amblyopia and allow it to see as well as the stronger eye.
Corrective eyeglasses or contact lenses to treat amblyopia is most commonly used for children. The symptoms of the lazy eye must be monitored clearly for an extended period of time to examine if the glasses are correcting the issue or if further treatment is needed.
According to the Lion’s Eye Institute, corrective eyeglasses or contact lenses treats amblyopia by correcting the root cause behind the lazy eye's inability to develop correctly, such as myopia, hyperopia or astigmatism, allowing the eye to function properly and develop to the same level as the stronger eye.
### 2. Patches for the Eyes
Patches for the eyes treat amblyopia by&nbsp;making the lazy eye to be the only source of sight,&nbsp;which forces the affected eye to develop the skills and acuity needed to be a functional eye.
Patches for the eyes are made of any comfortable and safe material that is placed over the stronger eye in order to force the weaker eye to be used more, working to solve issues related with poor eye development. The patch is typically applied for up to two or more hours a day.
### 3. Bangerter Filter
A bangerter filter is a clear, see-through plastic filter that reduces light and visual acuity by a controlled amount and is attached to the back of a glasses lens using only water. Bangerter filters are&nbsp;used as an alternative to treating amblyopia with an eye patch.&nbsp;Bangerter filters placed over the strong eye can remain there indefinitely instead of just the 2 hours or so an eye patch treatment uses.
Bangerter filters treat the lazy eye by&nbsp;being placed over the stronger, more functional eye,&nbsp;decreasing that eye’s ability to see or making both eyes have an equal degree of disability, which&nbsp;forces the lazy eye to strengthen and develop.
### 4. Eye Drops
Eye drops for lazy eye (amblyopia) are medicinal drops applied to the eye in order to correct or begin treatment of the lazy eye.
[Eye drops](https://www.oscarwylee.com.au/glasses/eye/types-of-eye-drops)&nbsp;for amblyopia are commonly cycloplegic eye drops, a type of eye drop that freezes the ciliary body for a short amount of time. Cycloplegic eye drops cause the eyes to lose the ability to focus for the duration of the drops’ effects.
Eye drops treat amblyopia by&nbsp;causing the stronger eye to become blurry and unable to focus, forcing the lazy eye to develop vision and be recognised for its ability to see by the brain.&nbsp;Eye drops for amblyopia are often used in conjunction with patching.
### 5. Surgery in the Eye
Surgery in the eye is not a currently existing procedure, and is often confused with eye surgery for strabismus, which can help to correct amblyopia once the misaligned eyes have been surgically fixed.
### 6. Eye Training
Surgery in the eye is not a currently existing procedure, and is often confused with eye surgery for strabismus, which can help to correct amblyopia once the misaligned eyes have been surgically fixed.
#### What Complications Could Lazy Eye (Amblyopia) Have if Left Untreated?
The complications that may result from lazy eye (amblyopia) if it is left untreated include permanent vision loss in the eye affected by amblyopia. Permanent loss of vision due to lazy eye that has not been treated for an extremely extended period is a result of the eye eventually losing its ability to function and see at all. Treating lazy eye as early as possible will result in greater vision and severely reduce the risk of going blind in one eye.
##### When is it Too Late to Treat Lazy Eye (Amblyopia)?
Amblyopia is typically more responsive to treatment under the age of 7, however improvements in vision have been observed in 12 years old patients.
## What are the Risk Factors of Lazy Eye (Amblyopia)?
The risk factors of lazy eye (amblyopia) are a&nbsp;history of lazy eye in the family, having small size at birth, premature birth delivery&nbsp;and&nbsp;disability in development.&nbsp;The risk factors of lazy eye are listed below.
* History of lazy eye in the family:&nbsp;History of lazy eye in the family is a risk factor of lazy eye because it shows that a child may develop or share genetic traits with a parent or family member who also developed lazy eye at some point in their life.
* Having small size at birth:&nbsp;Having small size at birth is a risk factor for lazy eye because the smaller size puts the child at risk of other eye conditions that could result in lazy eye.
* Premature birth delivery:&nbsp;premature birth delivery, also known as premature birth, is a risk factor of lazy eye because the earlier birth may result in less development for the child and the child’s eyes.
* Disability in development:&nbsp;SDisability in development is a risk factor for lazy eye because developmental disabilities may show that a person has a genetic propensity towards developing lazy eye or other eye conditions that cause it.
### 1. History of Lazy Eye in the Family
History of lazy eye in the family means that one or more of a child's relatives or parents have had a lazy eye at some point in their life.
A history of lazy eye in the family is a risk factor of lazy eye because it&nbsp;shows a genetic propensity towards developing amblyopia.
### 2. Having a Small Size at Birth
Having small size at birth, also referred to as SGA: small for gestational age. SGA may occur from premature birth, genetic reasons or issues in pregnancy.
Having small size at birth is at risk of&nbsp;developing strabismus,&nbsp;which&nbsp;could result in lazy eye if it is not treated.
### 3. Premature Birth Delivery
Premature birth delivery is when a child is born before 9 months of pregnancy have passed.
premature birth delivery is a risk factor of lazy eye because&nbsp;there is a chance that the eyes do not fully develop&nbsp;or&nbsp;have a genetic defect&nbsp;if a baby is born prematurely.
### 4. Disability in development
Disability in development are genetic or birth defects that interfere with the body's natural development at any stage of life.
Disability in development is a risk factor of lazy eye because they show that a person may&nbsp;have a genetic propensity to develop lazy eye,&nbsp;or to&nbsp;develop a different condition that result in lazy eye.&nbsp;Amblyopia itself is classified as a developmental disability because of how it affects visual learning.
#### How does Lazy Eye (Amblyopia) affect children?
Lazy eye affects children by&nbsp;decreasing the child's ability to see and properly develop visual acuity in both of their eyes.
By affecting a child’s ability to process visual information, untreated lazy eye will negatively affect a child’s ability to learn and develop in general as a majority of how a child learns is through visual processing. They also will not develop depth perception which is important in hand-eye coordination and other tasks.
#### Can an Adult Develop Lazy Eye (Amblyopia)?
Adults are unable to develop a lazy eye (amblyopia). Sudden lazy eye in adults can be caused as a reaction to other eye health conditions that affect one eye's ability to see. Acute strabismus in adults need urgent attention and is never amblyopia/lazy eye.
#### Can you Prevent Lazy Eye (Amblyopia)?
Lazy eye (amblyopia) cannot be prevented as a condition or as a result or other eye conditions affecting one eye's ability to see clearly. Early diagnosis and treatment of lazy eye can reduce any possible harm the condition could cause and guarantee a stronger, healthier eye for a longer period of time.
#### Can Astigmatism Cause Lazy Eye (Amblyopia)?
Lazy eye (amblyopia) can be caused by&nbsp;[astigmatism](https://www.oscarwylee.com.au/glasses/eye/astigmatism). Lazy eye can be caused by astigmatism if&nbsp;the difference between focus in each eye is too extreme, or if one eye has astigmatism while&nbsp;the other eye is suffering from a completely different vision condition, such as myopia. This type of lazy eye is called refractive amblyopia.
#### Is Lazy Eye (Amblyopia) Something to Worry About?
A lazy eye that is undiagnosed and untreated has a risk of developing blindness and permanent vision loss, according to Epping Eye. If a lazy eye goes untreated for too long,the brain will begin to favour the healthier eye over the disabled eye, and the development of the lazy eye will stagnate and may reach the point where it cannot be treated anymore.
##### How Does Knowing Which Eye is Dominant Help with Lazy Eye?
Knowing which eye is dominant&nbsp;may help with lazy eye as it can help provide the optometrist or eye care professional with all the related information. However, using a&nbsp;[dominant eye test](https://www.oscarwylee.com.au/glasses/eye/dominant-eye-test)&nbsp;is not necessary for the treatment of lazy eye (amblyopia) as it normally requires prescription glasses.
Read Lazy Eye (Amblyopia): Causes, Symptoms, Diagnosis, and Treatment in other Oscar Wylee regions and their languages.
Australia    
[Australia](https://www.oscarwylee.com.au/glasses/eye/lazy-definition)
[Canada](https://oscarwylee.ca/glasses/eye/lazy-definition)
[Canadian French](https://oscarwylee.ca/fr/glasses/eye/lazy-definition)
Book an eye test at Oscar Wylee and prioritise your eye health.
Our skilled optometrists perform bulk billed eye tests for eligible Medicare Card Holders.
[Book your eye test](https://www.oscarwylee.com.au/booking)
At Oscar Wylee all major health funds are accepted in-store
Come and see your local Oscar Wylee team for your eye care needs and your health fund may help cover some of the cost
[Explore Health Funds](https://www.oscarwylee.com.au/health-funds.html)