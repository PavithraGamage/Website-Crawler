# Source: https://www.oscarwylee.com.au/eye-test/medicare

# Does Medicare Cover Eye Tests and How Often?
Published on September 5th, 2024
Updated on August 23rd, 2024 
Australia
Australia
New Zealand
Canada
Canadian French

Medicare, Australia’s universal health care system,
will generally cover eye tests conducted by qualified optometrists. Under
Medicare, eye tests can be bulk billed, meaning an optometrist bills the
Medicare system, not the customer. Medicare requires a person to be an eligible medicare card holder to be
bulk billed. Valid medicare card holders are entitled to a bulk billed eye
test, however it is best to contact your local store to ensure you are
eligible. For those over 65, Medicare will cover 1 test every year. Bulk
billed eye tests or eye exams are the most common eye care coverage under
Medicare. Other eye care coverage can include ophthalmologist consultations,
eye surgery and treatment for eye conditions. The exact eye care Medicare
cover will be dependent upon the patient and care needed, so it is important
to check with your eye care professional regarding Medicare bulk billing for
eye care. At Oscar Wylee, our eye tests are Medicare bulk billed for
eligible Medicare card holders. Keep reading to learn more about Medicare
and eye care services.
Due for an eye test?
It is recommended that everyone should have an eye exam with an
optometrist at least once every 2 years.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Medicare Eye Test](#Medicare) [How Often](#How)
[Additional Coverage](#Coverage)
[Health Insurance vs Medicare](#InsurancevsMedicare)
## Does Medicare Cover Eye Tests?
Yes, Medicare can cover eye tests carried out by an optometrist. An eye test is a procedure in which an [optometrist](https://www.oscarwylee.com.au/eye-care/optometrist#:~:text=Diagnose%20eye%20problems%20and%20diseases%3A%20Through%20various%20tests%20in%20a,as%20hyperopia%2C%20myopia%20or%20astigmatism.)
or eye care professional will assess a person’s vision and examine the
health of the eyes. Medicare is Australia’s universal healthcare
system. Under Medicare, eye tests can be bulk billed, meaning an
optometrist bills the Medicare system for the eye test, and not the
customer. The customer must be an eligible cardholder to be bulk
billed. However, not all optometrists will choose to bulk bill. It is
important to check with your optometry provider on whether they bulk
bill before booking. At Oscar Wylee, eye tests are bulk billed for
eligible Medicare card holders.
## How Often Does Medicare Pay for Eye Exams?
How often Medicare will cover eye exams depends on the patient's age. For those under 65, Medicare will cover 1 test every 3 years
however there may be exceptions to this for those who have more
serious eye conditions. For those 65 and over, Medicare will cover 1
test every year.
### Does Medicare Cover Eye Surgery?
Medicare does not cover all eye surgeries. It is important to discuss payment with your doctor and eye care
professional before getting eye surgery, as some procedures will not
be covered or may only be partially covered by the Medicare system.
Medicare does not cover elective surgeries, which include procedures
such as laser eye surgery. Other surgeries may be eligible for some
Medicare rebate, such as cataract surgery. It is important to check
with your healthcare provider and Medicare on what surgeries are
covered.
### Can Children Have an Eye Exam Through Medicare?
Yes, children enrolled with Medicare can have a bulk billed eye test. According to Services Australia, when a person enrols their child
in Medicare, the child has access to the same benefits as them. This
means that an [eye test for children](https://www.oscarwylee.com.au/glasses/eye/exam-for-children) can be bulk billed.
Are You in Need of New Glasses?
Come see our staff in-store for assistance with your vision and to
browse our range of fashionable glasses.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
## What Eye Care Coverage Does Medicare Provide?
Medicare may cover several aspects of eye care including eye examinations or eye tests, ophthalmologist consultations, eye
surgery and treatment for eye conditions. However, whether Medicare will cover, and the amount they cover,
can vary. It is always important to check with your eye care
professional about what coverage Medicare can provide before
proceeding. The possible Medicare eye care coverage is listed
below.
* Eye examinations: Eye examinations, or
eye tests, are generally covered by Medicare for eligible cardholders.
* Ophthalmologist consultations: Medicare may provide some cover for ophthalmologist consultations
if a referral from a doctor or optometrist is made.
* Eye surgery:
Eye surgery is not always covered by Medicare. Medicare does not
cover elective surgeries, including cosmetic eye surgery, but may
cover surgery such as cataract surgery.
* Treatment for eye conditions:
Treatment for eye conditions may be covered to some degree by
Medicare, depending on what treatment is needed.
### 1. Eye Examinations
Medicare will cover eye examinations or eye tests with qualified
optometrists for eligible cardholders. [Eye tests](https://www.oscarwylee.com.au/glasses/eye/test-glossary)
can be bulk billed under Medicare, meaning there are no
out-of-pocket expenses for customers. Not all optometrists will bulk
bill, so it is important to check with your optometrist about the
cost before getting an eye test. [Find an optometrist near you](https://www.oscarwylee.com.au/find-optometrist)
to get an eye test. At Oscar Wylee, all eye tests are Medicare bulk
billed for eligible card holders.
### 2. Ophthalmologist Consultations
Medicare may provide some cover for ophthalmologist consultations. An [ophthalmologist](https://www.oscarwylee.com.au/glasses/eye/doctors)
is a medical doctor who has a specialisation in eye care and is
qualified to provide treatment for advanced eye conditions such as
cataract surgery. According to the Australian Government’s
Department of Health and Aged Care, patients referred to an
ophthalmologist from an optometrist, may get Medicare benefits for
ophthalmologist services at a referred rate. It is important to
check with your optometrist and ophthalmologist on whether Medicare
will cover the cost of your eye care.
### 3. Eye Surgery
Medicare may cover the cost of some eye surgeries, depending on what eye
surgery it is and what type of hospital the surgery is taking place
in. Medicare does not cover the cost of elective surgeries, including
cosmetic eye surgery. Medicare may cover a certain amount of the
cost on [eye surgeries](https://www.oscarwylee.com.au/glasses/eye/surgery)
such as cataract surgery, but the exact amount may change depending
on whether this surgery is conducted in a private or public
hospital.
### 4. Treatment for Eye Conditions
Medicare may cover some costs regarding [eye condition](https://www.oscarwylee.com.au/glasses/eye/common-problems) treatment such as treatment for macular disease. According to the Macular Disease Foundation, macular disease may
be treated with eye injections and Retina photocoagulation or laser
eye treatment. Medicare may provide some rebates for items related
to these procedures.
#### Are Prescription Glasses and Contact Lenses Not Covered by Medicare?
The purchase of prescription glasses and contact lenses are not covered by Medicare. Depending on the optometrist you are purchasing lenses and
glasses from, there may be payment plans or systems set up to help
with the costs of frames. Private health funds may also help cover
some of the cost of frames and lenses. At Oscar Wylee, we have
Afterpay and Zip pay to help with frame payment. We also accept
all major health funds in-store.
### How Much is an Eye Test If I Have Medicare?
If a person is an eligible Medicare card holder and their optometrist bulk bills,
there will be no out-of-pocket expenses for an eye test. This does not mean that [eye tests at Oscar Wylee are free](https://www.oscarwylee.com.au/free-eye-test), instead, they are bulk-billed to the Medicare healthcare system.
This means there will be no out-of-pocket payment for eligible
Medicare cardholders, but the optometrist will bill the medicare
system for the test. If a person is not enrolled with Medicare, they
will generally have to pay for an eye test. Eye tests for those not
covered by Medicare at Oscar Wylee cost $70.
#### Can I Use Medicare for Cosmetic Eye Procedures?
Medicare may not cover elective or cosmetic eye procedures, which may include surgeries such as blepharoplasty. A
blepharoplasty is a surgery that aims to improve the appearance of
the eyelids, according to the Better Health Channel.
#### Can I Claim for Macular Disease Treatment Using Medicare?
Medicare may be able to provide a certain amount of coverage for
procedures carried out during macular disease treatment. Macular disease refers to eye conditions affecting the macula
part of the eye, including [age-related macular degeneration](https://www.oscarwylee.com.au/glasses/eye/age-related-macular-degeneration)
(AMD). According to the Macular Disease Foundation, Medicare
provides some rebates for items related to eye injections and
laser surgery, which can be used to treat macular disease. It is
important to check with your health care or eye care professional
in regards to treatment for macular disease and how much it will
cost.
#### Does Medicare Cover Eye Refraction Tests?
Yes, Medicare covers eye refraction tests, as eye refraction tests are
typically performed during a regular eye test. An [eye refraction test](https://www.oscarwylee.com.au/glasses/eye/refraction-test)
refers to a test in which an optometrist or eye care professional
will assess whether a person needs a prescription for glasses or
contact lenses. A refraction test will allow an optometrist to
determine how well a patient's eye is refracting light and whether
they have any refractive errors like myopia or hyperopia. If a
person has a refractive error, it will need to be corrected with a
prescription.
#### Does Medicare Pay for Cataract Surgery?
Yes, Medicare can help pay a certain amount towards cataract surgery,
depending on where the surgery takes place. According to the Australian Government’s Department of Health
and Aged Care’s Medical Costs Finder, there is generally no cost
for a patient getting [cataract surgery](https://www.oscarwylee.com.au/glasses/eye/surgery/cataract)
in a public hospital with Medicare. If a person gets cataract
surgery in a private hospital, they may have out-of-pocket
costs.
#### Does Private Health Insurance Provide More than Medicare for Eye
Care?
The difference in coverage between Medicare and private health
insurance regarding eye tests is generally dependent on the
private health fund. Most health funds do not cover eye tests but will usually cover
some of the cost of frames and lenses. Whereas Medicare covers eye
tests and some additional eye care services but does not cover the
cost of frames.
Read Does Medicare Cover Eye Tests and How Often? in other Oscar Wylee regions and their languages.
Australia
Australia
New Zealand
Canada
Canadian French

Major Health Funds Accepted In-store
For the purchase of frames and lenses, use your private health fund to
limit how much you pay from your own pocket.
[Discover Health Funds](https://www.oscarwylee.com.au/health-funds.html)
Do You Have Any Eye Concerns?
Come see our team for professional assistance with your optometry
needs.
[Book an eye test](https://www.oscarwylee.com.au/booking)