# Source: https://www.oscarwylee.com.au/locations/optometrist-mt-druitt.html

# Optometrist Mt Druitt
Westfield Mt DruittShop 149/50, Cnr Carlisle Avenue &amp; Luxford RoadMt Druit NSW 2770
* Next to Prouds
Opening hours
Monday9:00am - 5:30pm
Tuesday9:00am - 5:30pm
Wednesday9:00am - 5:30pm
Thursday9:00am - 7:00pm
Friday9:00am - 5:30pm
Saturday9:00am - 5:00pm
Sunday10:00am - 5:00pm
*Store hours reflect local standard trading hours and exclude public holidays
[Visit our Mt Druitt Google Business page for directions, reviews, and updates.](https://g.page/r/CdM9RPtPClLMEBM)
Book Appointment
[Call us: 02 8809 5041](tel:02 8809 5041)
[Leave a Review!](https://g.page/r/CdM9RPtPClLMEBM/review)
Our Reviews
Huriata Rhind
3 weeks ago
Excellent service as always. Needed a new script happy got to choose my frame’s and finally transiti...ons glasses
See more
Shahzad Rafique
3 weeks ago
Ta Glassie
3 weeks ago
It was my first visit and the service was very good especially with the Optician who was looking aft...er me.  Highly recommended.
See more
tusipepa tuigamala
1 month ago
Jodie McQuillen
1 month ago
Wonderful, experienced staff and very helpful
A Google User
1 month ago
Mikee Defiesta
1 month ago
I went to Oscar Wyler Mount Druitt on Thursday, 16th of July and Elyse did an amazing job helping me... through the glasses that would suit my facial composition. She explained the types of glasses and what would suit best for different types of usage. Moreover, the optometrist was so lovely and squeezed an on the spot appointment for me and I was able to confidently pick what I needed. And a lovely customer who also helped pick my glasses for me. Oscar Wylee has been very good with picking the right people to work for them no matter the location. Well done to the Mount Druitt team!
See more
Louise P
1 month ago
Dianne Firman
1 month ago
I found everyone at Oscar’s Wylie very kind helpful caring and professional.
Norzki
2 months ago
Quick and no hassle during my appointment.The customer service ladies that were helping me and my mo...m on Sunday were fantastic, very attentive and helpful.
See more
Rey Lacson
2 months ago
Paula Gray
2 months ago
The team were very good. They listened to my concerns and helped me with choosing frames to suit. I ...couldn’t get the sun glasses I wanted as they only were available via a script and I don’t need a script to drive. Otherwise I would have given 5 stars. Would recommend them.
See more
Naveed Zaidi
2 months ago
Very friendly and professional staff
Sarah Tomkins
3 months ago
The lady’s were amazing and helpful ????????
Girlie Long
3 months ago
The Manager and the Optometrist at Oscar Wylee are both very pleasant and knowledgeable. It was a gr...eat experience.
See more
Kesaia Railigi
3 months ago
Very efficient and prompt all the way through. Staff are top norch  in customer service.  Very happy... customer here. Thank you kindly for looking after me.
See more
Menaly Villacorte
4 months ago
The staff who assisted me are friendly. Very helpful and explained every details.
Michael Shenouda
4 months ago
I had an excellent experience with Shanna at Oscar Wylee. She was professional, friendly, and incred...ibly knowledgeable throughout the entire process. Shanna took the time to explain my prescription clearly, helped me choose frames that suited me perfectly, and made the whole experience easy and stress-free.
Her customer service was outstanding, and you can tell she genuinely cares about her work and her customers. Highly recommend asking for Shanna if you’re visiting. she’s fantastic!
See more
Joefrey Pinano
4 months ago
Saira Razzaq
4 months ago
Amazing service.  Staff was really gentle and polite.
D G
4 months ago
I have been telling everyone to switch over. I loved the Optometrist there. She was very thorough &amp; ...informative. Very happy with my appointment.
Thank you
See more
Roberta Upu
5 months ago
Thank you to the lovely girl who assisted me in choosing frames and organising tests. I was in and o...ut in no time with no fuss!
See more
LI JIA RAN
5 months ago
Imran Hassan
6 months ago
Friendly team with great service!
Gurpreet Kaur
6 months ago
I have been wearing specks from years and this is the first tym i had my specks done from them and t...he experience is wonderful. I search 5 of the optics to find a unique specks and i got one here and they are of good quality and the prescription fits so well. I am going to them every-time i need new specks.
See more
Bryan Mendonsa
6 months ago
I recently had an eye exam, and it was a pleasant experience. The optometrist Sophie was very profes...sional and took the time to explain everything thoroughly. I felt comfortable and confident in the care I received. Thank you for providing such great service!
See more
Quinia Mendez
6 months ago
Satisfied of the job done by the lady optometrist . Shes friendly and can talk openly when questions... are asked.
See more
Yan Blazevic (Yan classic)
7 months ago
Mariana Abdelsayed
7 months ago
MOHAMMAD HABIBUR RASHID ISMAIL
7 months ago
The experience was positive and the staff were helpful.
Sheena Norris
7 months ago
Inben Pather
7 months ago
Jackie was very helpful and easy to talk to. She also helped me choose the most useful features for ...my new frame.
See more
Michelle Kyle
7 months ago
Experienced and friendly staff. Nice range of frames.
Blessmore Chitsamba
7 months ago
Jeff Lorbes (Jklorbes)
7 months ago
Optometrist &amp; staff who assisted us for our eye test &amp; purchasing glasses has been very helpful, imf...ormative &amp; friendly. Overall great experience in store!
See more
Kris
8 months ago
I had a very positive experience with the staff and Sophie Dang. The optometrist was professional, f...riendly, and thorough, taking the time to explain the eye test results clearly and providing comprehensive information. Highly recommended.
See more
Uli Orhan
8 months ago
Was a very nice experience as first time goer to an optometrist very smiley and friendly crew
Narelle King
8 months ago
cheryl lynn
8 months ago
All the staff were very welcoming.  I felt in good hands,  well done
Stephen Gurney
8 months ago
Very nice staff and very knowledgeable. Thanks to Sophie who did my test. Excellent experience.
Walter de Leon
9 months ago
Kelly Mae Cacnio
9 months ago
Ernest Jack Purificacion
9 months ago
Good experience the eye doctor lady took out eyelashes that were poking my eye
Evan Wong
10 months ago
Daniel Matapo
10 months ago
It was truly amazing work and the exercise was simple.Im very grateful May God bless you and Peace b...e
See more
Dm Shahadath Hossain
10 months ago
Had a great  experience. Staff and Optometrist were very helpful and friendly. Eye check was thoroug...hly done with care.
Thanks ????
See more
Shannon Burnett
10 months ago
Very good
Marie Zumbo
10 months ago
Seth Opoku Mensah
10 months ago
I highly recommend Oscar Wylee Optometrist - Mt Druitt for their outstanding optometrists and friend...ly front desk staff. They provide such professional, caring, and welcoming services. Kudos to the team!
See more
Mariyah Hameed
11 months ago
The eye test was excellent, the staff were friendly and helpful❤️
## Find an Optometrist in Mt Druitt with Oscar Wylee
Oscar Wylee Mt Druitt is located in Westfield Mt Druitt and close to areas such as Rooty Hill, St Marys and Plumpton. Oscar Wylee Mt Druitt offers bulk billed eye exams to valid Medicare cardholders and with an optometrist on site to perform eye tests, you can have your vision checked, update your prescription, and find your new favourite pair of glasses on the same day! Offering modern and vintage-inspired prescription glasses including prescription sunglasses. 
Mt Druitt is located 43 kilometres west of the Sydney central business district, in the local government area of the City of Blacktown. We have a unique and diverse culture as well as a great shopping district. Our Oscar Wylee Mt Druitt store inside Westfield Mt Druitt has ample parking on site, is only a 5-minute walk from the Mt Druitt station and is also close to many bus stops. With our dedicated eye care professionals, high-quality customer service and fashion-forward frames, Oscar Wylee has some of the best optometrist services in Western Sydney.         
Meet Our Team
Our Services
* Bulk Billed Eye Examinations
* Professional Frame Styling
* Frame Adjustments and Repairs
* Visual Fields Testing
* Digital Retinal Scanning
Show All
## Find an Optometrist in Mt Druitt, Sydney for an Eye Health Test
An optometrist in Mt Druitt, Sydney is capable of providing prescription eyewear, eye tests and many other services you may need. These services include an eye health test in Mt Druitt which is available at a bulk billed price at Oscar Wylee, courtesy of Australia’s Medicare system. Getting regular eye tests is important for monitoring any changes to your vision and identifying signs of eye diseases. If your condition requires further assessment, we will refer you to an eye doctor in the area.
An eye test with us typically involves preliminary tests carried out by our trained staff followed by more examination processes done by our optometrist. For any assistance with your prescription eyewear as well as prescription sunglasses, our optical dispenser is available to help you out. The average price for an optometrist in Mt Druitt may be based on different factors such as the number of available optometrists in the area, the equipment used and your vision requirements.
## How to Find an Optometrist in Mt Druitt, Sydney?
To find an optometrist in Mt Druitt, Sydney you can take certain steps that can help make it easier for you such as searching online, assessing the store’s opening hours and finding the directions to your chosen location. The steps on how to find an optometrist in Mt Druitt are listed below
1. Search online using the phrase, Mt Druitt optometrist near me. This can also be done here on the website via our locations page.
2. Click on the Oscar Wylee link, which will take you directly to our Mt Druitt optometrist store page.
3. See the store’s opening hours and where the store is located specifically.
4. Use the Mt Druitt Google Business page link located under store hours to see the directions on how to get to the store.
You can also find an optometrist in Mt Druitt by searching the keywords optometrist near me. If you have locations enabled on your smartphone and you’re in the Mt Druitt area, our Mt Druitt store page should appear easily for you to click on.
### Is it Hard to Get an Eye Appointment in Mt Druitt, Sydney?
No, it is not hard to get an eye appointment in Mt Druitt. You can easily book an appointment to see an Oscar Wylee optometrist in Mt Druitt right here on this page. At Oscar Wylee we have highly qualified optometrists available for bulk billed eye appointments, which can be booked online or in-store.
#### How to Compare Optometrists in Mt Druitt to Each Other?
To compare optometrists in Mt Druitt, you can use factors such as eye tests offered, health fund coverage, lens types and add-ons and eyewear offered. To take care of your vision and eye health, it is important to receive an eye test at least once every two years. There are different types of tests that can be performed in an eye test and not all optometrists may offer the same tests. Health funds can be used to help cover some of the cost of your frames and lenses. To find out if your health fund is accepted at Mt Druitt optometrist in Sydney, visit their website. In the case of Oscar Wylee, we accept all major health funds and provide on-the-spot claims in-store. There are many different lens options available for prescription glasses such as single vision, multifocal and high index lenses. Most optometrists in Mt Druitt will offer these lenses although it is good to make sure. There are also lens add-ons available to enhance your glasses such as anti-reflective and blue light filters. Finally, if you are looking to purchase a pair of glasses after your eye test, you can compare the different styles and colours you are interested in from Mt Druitt optometrists in Sydney. Oscar Wylee offers a wide range of frames with vintage and modern inspirations in bold colours and subtle designs.
#### How to Find an Eyeglasses Shop in Mt Druitt, Sydney?
To find a glasses store in Mt Druitt, you can try to follow these simple steps including searching online, selecting a convenient location and looking at their health insurance policies. The steps on how to find a glasses store in Mt Druitt, Sydney are listed below.
1. Search online using the phrase, glasses store in Mt Druitt. This will provide you with various options for glasses stores in the whole area of Mt Druitt.
2. Select a glasses store that is most convenient for you to travel to.
3. Click the link to find out more information such as opening hours, exact location and directions to the glasses store in Mt Druitt.
4. Read their health insurance policies to ensure you know what health benefits you have access to.
Our Oscar Wylee glasses store in Mt Druitt, Sydney offers primary eye care services such as comprehensive eye tests as well as other services performed by an optometrist and offers prescription and non-prescription eyewear.
##### Is it Possible to Purchase Prescribed Sunglasses in Mt Druitt, Sydney Without Seeing an Optometrist?
Yes and no, it is possible to [purchase prescribed sunglasses](https://www.oscarwylee.com.au/sunglasses.html) in Mt Druitt, Sydney without seeing an optometrist if you already have a prescription that has not expired. If your prescription is expired, you can book an eye test to receive an updated or new prescription which will require you to see an optometrist. This will ensure your prescription sunglasses are appropriate for your visual needs.
## Where is the Oscar Wylee Mt Druitt Optometrist in Sydney Located?
The Oscar Wylee Mt Druitt optometrist is located in Westfield Mt Druitt Shopping Centre at Shop 149/50, Cnr Carlisle Avenue &amp; Luxford Road. The Oscar Wylee Mt Druitt store can be found next to Prouds.
### What is the Phone Number of Oscar Wylee Mt Druitt Optometrist Store?
The Oscar Wylee Mt Druitt optometrist store phone number is [(02) 8809 5041](tel:(02) 8809 5041). You can contact the Oscar Wylee Mt Druitt store between the hours of 9:30 am and 5:30 pm on Monday, Tuesday, Wednesday and Friday, on Thursdays between 9:00 am and 9 pm, on Saturday between 9 am and 5 pm and on Sunday between 10 am and 5 pm.
### What are the Reviews for Oscar Wylee Mt Druitt Optometrist in Sydney?
The many reviews for Oscar Wylee Mt Druitt optometrist in Sydney, left by our various customers can be found here on the website and online when you search for Oscar Wylee Mt Druitt optometrist. The reviews for Oscar Wylee Mt Druitt optometrist are listed below.
* Dominique Zaragoza:  The staff members at the front on Thursday, 8th of September 2023, between 5:10 PM - 6:10 PM were wonderful. So helpful. The optometrist was great; he was straight to the point. I highly recommend this branch.
* Amit Sethi:  I recently got my eyes examined by David in Oscar Wylee Optometrist - Mt Druitt. My eye testing experience was amazing. David is very knowledgeable and accurate in eye testing. I would highly recommend him for eye testing to everyone.
* Courtney Knapp:  David is an amazing optometrist, who saved my eyesight…literally. So I couldn't recommend him enough. All staff are friendly &amp; such amazing service.
* Sadaf Mohammad:  Loved my eye test experience. The optometrist was great, thorough and explained everything in detail. He was really accommodating and understanding.
#### What Treatments or Eye Care Processes are Done in the Oscar Wylee Mt Druitt Optometrist Location?
The treatments or eye care processes done in the Oscar Wylee Mt Druitt optometrist Sydney location include a tonometry test, a digital photograph, a slit lamp exam and a refraction test. Additional tests that may also be performed can include a visual field test and a dilated fundus exam. The treatments or eye-care processes that are done in the Oscar Wylee Mt Druitt optometrist Sydney location are listed below.
* A Tonometry Test: An optometrist or optical dispenser will conduct a tonometry test which involves the use of a machine that will release small puffs of air into your eyes. This will assist with measuring pressure in the eye.
* A Digital Photograph: An optometrist or optical dispenser may take a digital photograph of your eye which can be kept on record to use in future appointments to evaluate any changes to your eye.
* Slit Lamp Test: A slit lamp test can be used to evaluate your eye health, by examining your cornea and iris which are the anterior and posterior of the eye.
* Refraction Test: During a refraction test, an optometrist will have you view an image through different lenses and ask you to confirm which helps you see the image clearer.
* Visual Field Test: A visual field test can assist with assessing your peripheral vision, which may be beneficial for identifying any signs of glaucoma.
* Dilated Fundus Exam: A dilated fundus exam can help an optometrist assess your health in more detail by getting a clear view of the retina. This test is typically carried out for patients with diabetes and those who may be at risk of developing retinal damage.
## How Many Optometrists Exist in Mt Druitt, Sydney?
Many optometrists exist in Mt Druitt, Sydney to provide eye tests and glasses, including Oscar Wylee. If you need essential eye services such as a comprehensive eye test, a wide selection of prescription eyewear and more, then choose Oscar Wylee as your first choice for optometry services. The number of optometrists in Mt Druitt may be due to the number of residents in the area, the number of available optometrists and the geographical size of the suburb.
### What are the Other Closest Optometrist Locations to Mt Druitt, Sydney in Australia?
The other closest Oscar Wylee optometrist locations to Mt Druitt, Sydney in Australia are Blacktown, Wetherill Park, Winston Hills and Penrith. The other closest optometrist locations to Mt Druitt are listed below.
* Blacktown:  Blacktown is close to Mt Druitt with a 10 km distance between stores. The [Oscar Wylee Blacktown](https://www.oscarwylee.com.au/locations/optometrist-blacktown.html) store is located at 17 Patrick Street and can be found near YD and Typo. Here you can receive primary eye care services such as comprehensive eye tests and assistance with eyewear.
* Wetherill Park:  Wetherill Park is close to Mt Druitt with 18 km in between stores and can be found at the Stockland Wetherill Park Shopping Centre. [Oscar Wylee Wetherill Park](https://www.oscarwylee.com.au/locations/optometrist-wetherill-park.html) is the destination for comprehensive eye tests, which help with identifying any eye problems or prescription eyewear. It can be found near Lee Massage &amp; Acupuncture.
* Winston Hills:  Winston Hills is close to Mt Druitt with 20-25 km in between stores. You can find the Oscar Wylee Winston Hills store at the Winston Hills Mall next to Terry White Pharmacy. At [Oscar Wylee Winston Hills](https://www.oscarwylee.com.au/locations/optometrist-winston-hills.html) , our team offers eye tests for prescribing glasses and diagnosing a range of eye conditions.
* Penrith:  Penrith is close to Mt Druitt with 15-19 km in between stores and can be found at 582-586 High Street next to ANZ Bank. The [Oscar Wylee Penrith](https://www.oscarwylee.com.au/locations/optometrist-penrith.html) store can provide assistance for those who require prescription eyewear or for those who want to prioritise their eye health.
### Oscar Wylee Mt Druitt optometrists perform bulk billed eye tests
With Oscar Wylee you can take the first step in prioritising your eye health and taking care of your vision. Just stop by our Oscar Wylee eyeglasses shop in Mt Druitt with eye care processes available including prescription updates, eye health tests to assess vision and detect certain eye diseases, as well as frame shopping. At Oscar Wylee Mt Druitt, eye tests are bulk billed for eligible Medicare card holders and performed by our dedicated and experienced Oscar Wylee optometrists.
### Oscar Wylee Mt Druitt accepts major health funds
At Oscar Wylee Mt Druitt our staff are there to help process your health fund claim in-store with a valid health fund card and answer any questions about what you’re eligible for with your health fund. At Oscar Wylee Mt Druitt, you don’t have to navigate the hardest parts of health insurance alone, as we are dedicated to making sure you get what you need at an affordable, competitive price
### Fashion-forward styles at affordable prices
Oscar Wylee Mt Druitt is committed to helping you find your perfect pair of frames, offering a wide range of modern and vintage-style glasses frames at an affordable cost. Our Oscar Wylee Mt Druitt optometrists help to provide prescription lenses to fit customer needs - whether it’s a blue light filter, multifocal lens, or a polarised lens for your prescription sunglasses, our experts in-store are ready to help you with any of your eyewear or optometry needs.
Book Appointment
[Call us: 02 8809 5041](tel:02 8809 5041)
[Leave a Review!](https://g.page/r/CdM9RPtPClLMEBM/review)