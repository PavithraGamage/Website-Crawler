# Source: https://www.oscarwylee.com.au/locations/optometrist-green-hills.html

# Optometrist Green Hills
Stockland Green Hills Shopping CentreTenancy 64, 1 Molly Morgan DrEast Maitland NSW 2323
* Near Woolworths
Opening hours
Monday9:00am - 5:30pm
Tuesday9:00am - 5:30pm
Wednesday9:00am - 5:30pm
Thursday9:00am - 8:00pm
Friday9:00am - 5:30pm
Saturday9:00am - 5:00pm
Sunday10:00am - 4:00pm
*Store hours reflect local standard trading hours and exclude public holidays
[Visit our Green Hills Google Business page for directions, reviews, and updates.](https://g.page/r/CefwAYZ0iKsGEAE)
Book Appointment
[Call us: (02) 4905 2105](tel:(02) 4905 2105)
[Leave a Review!](https://g.page/r/CefwAYZ0iKsGEAg/review)
Our Reviews
Lee-Anne Scruse
3 days ago
Georgie Kirkwood
1 week ago
Jordan White
1 week ago
Best optometrist i have been to have been coming back frequently and wonderful support and help with... eye care and help with frames as well
See more
Briony Thompson
1 week ago
Staff were very helpful, And all very polite
Daniel Roach
2 weeks ago
Good experience, great staff, excellent selection of frames ????
hayley murphy
3 weeks ago
⭐⭐⭐⭐⭐
Such an amazing experience at Oscar Wylee! The staff were incredibly helpful and made the whol...e process so easy and stress-free. They helped me with everything I needed, answered all my questions, and made me feel completely assured and comfortable with my choices.
I’m so grateful for the wonderful service and would definitely recommend Oscar Wylee to anyone looking for friendly, caring and professional service!
See more
Blake Harris
3 weeks ago
Kahlia Henderson
3 weeks ago
Helpful and friendly staff who fit me in and ensured my issue was resolved same day.
Mark Conroy
4 weeks ago
Excellent service, Optometrist explains information.
Fat Ma
4 weeks ago
All good ????
Mark Bradford
4 weeks ago
Janet Caruana
1 month ago
Very friendly efficient service.
Zoey Oliver
1 month ago
Very happy with the care and outcome of my appointment! 10/10 would recommend to everyone. All staff... are lovely and so much better than specsavers!
See more
Jarrah
1 month ago
Saw the optometrist Vincent here recently couldn’t recommend him highly enough. Great clinical advic...e and friendly staff members to help choose frames.
See more
kelly southgate
1 month ago
From the beginning reminding me of my appointment to finally choosing my glasses, which took 2 weeks... because of their amazing range, everything was so easy.
The optomitrist was very caring and asked if had any concerns or questions a number of times and when he showed me how I will be seeing things once I pick my glasses up, was like an Oprah moment. Ahhhhhh Ahhhhhh ????????????????????????????????  No waiting around either to have my test, to pick up my glasses like other places.
Thank you Oscar Wylee and the team at Green Hills ????
See more
robert glover
1 month ago
Excellent as usual
JOY Lewis
1 month ago
jessica weis
1 month ago
Sean Gillard
1 month ago
Through and enjoyable eye test experience with plenty of glasses to choose from afterwards. Great se...rvice as always.
See more
Christopher Sharpe
1 month ago
Stellar customer service
Kenneth Wosman
1 month ago
Very knowledgeable and courteous service provided by the whole team at the Greenhills branch. The op...tometrist was professional offering sound advise and issuing a referral to a specialist outside of the organisation.
See more
Shuxis
1 month ago
Excellent experience. Professional, courteous, very straightforward.
Gina Pittard
1 month ago
A great experience. Welcoming, helpful team who helped with choosing my glasses with honest opinions... and helpful suggestions.
See more
Wendy Anderson
1 month ago
Absolutely fantastic ! The optometrist was so helpful,  I have severe dry eye due to having syrogren...s.
He advised me to have a procedure that helps with it and wrote me a letter for the specialist.
Then put me on extra drops to help .
Then the girls were so helpful when it came time to choose my glasses.
Definitely will be going no where else ever !
Thank you Wendy Anderson
See more
Karen Liston
1 month ago
As always wonderful.  Ladies out front are very helpful &amp; friendly. Optometrist is the same man I al...ways see &amp; is very professional &amp; willing to answers any questions I have. I’ll never go anywhere else.
See more
Liane Murray
1 month ago
I am an old customer of Spec Savers but will never go back after going to Oscar Wylee the staff ther...e are amazing so lovely and caring and they don't charge you for unneccessary things, thank you Oscar Wylee for always making my appointments easy and pain free.
See more
Ann Morgan
1 month ago
Emma Sheridan
1 month ago
It was a great experience.  Everyone was super friendly. The optometrist was very informative re my ...options.  Booking was super easy. Definitely recommend.
See more
Julie Price
1 month ago
Great experience with professional staff that doesn’t cost the earth.
Highly recommend Oscar Wylee
Rhonda Mcnabb
2 months ago
Vincent was wonderful
Ann Thompson
2 months ago
Very professional and helpful.
Jackie O'Brien
2 months ago
The optometrist was very thorough, offering an extra exam for my 9 year old to better understand his... optical needs.
See more
Marz Salde
2 months ago
Amazing service and the optometrist is very helpful❤️
Would recommend.
warwick garnham
2 months ago
A great experience, staff and Optometrist were very helpful.
Jordan Laverick
3 months ago
front desk girls were lovely and helpful, eye exam was quick and easy and gentleman was great, thank... youuuuu ❤️❤️
See more
Lee Gannon
3 months ago
Great staff. Very helpful a .Great test with the optometrist  who was  very knowledgeable and help
Karen Black
3 months ago
Doug Dobson
3 months ago
My visit from start to finish was very pleasant. On arrival the staff were very polite and the optom...itrist was very knowledgeable.
See more
John &amp; Robyn Mckenzie
3 months ago
my appointment was on time. Very thorough and informative. The eye test to about 10mins. Highly reco...mmend.
See more
Lee Waine
3 months ago
Was a great experience to have my eyes tested and realised how bad my eyes were, to then be able to ...purchase some glasses there and then. Amazing customer service from Jess. Can't thank her enough for looking after me.
See more
MHERV
3 months ago
The staff at Greenhills store were very professional and welcoming during my appointment. Would high...ly recommend them.
See more
Peta Dzokoski
4 months ago
The customer service was fantastic this waa the first time I've been to the store, there was a lady ...who pushed in front of me and was extremely rude to the staff member who served her and the staff member was very pleasant and extremely helpful even though the customer was extremely rude.
See more
Michelle Whiting
4 months ago
The staff were lovely and the optometrist so helpful . Understood my urgency for the appointment and... were able to fit me in on the day.
Will definitely be going back.
See more
Laura Harvey
4 months ago
Tegan Hockey
4 months ago
Vincent is always thoroughly and kind. I only ever use OW now. They're friendly, honest, helpful, an...d - most importantly - they can share in a joke. Forever and always, I'll be coming here ????
See more
Sarah Monteith
4 months ago
Great service and they explained everything in detail.
wayne wilesmith
4 months ago
The eye exam was conducted professionally and was a good experience however when it comes to sales o...ffers and deals were not explained and felt I could have gotten a better deal.
See more
Brooke Morris
4 months ago
Our optometrist was awesome first time I have had someone explain the nitty gritty to me instead of ...just doing the test and sell me glasses. Hopefully he will stay for our next visit.
See more
Richard Horton
5 months ago
Great service thanks
Sue Joy
5 months ago
My experience with Oscar Wylee yesterday was excellent. Vincent picked up on a condition with my eye...s and straight away contacted a specialist for further testing while I was still in his examination room. He secured an appointment for the same day, which I attended. I recommend Oscar Wylee at Greenhills very much. Thank you.
See more
## Find an Optometrist in Green Hills with Oscar Wylee
Located just 4 kilometres from Maitland CBD, Oscar Wylee Green Hills can be found on the ground floor of Stockland Green Hills Shopping Centre, opposite Bakers Delight. Oscar Wylee Green Hills in-store optometrists can provide you with an eye test, bulk billed under Medicare. To reach your appointment for a vision test, there are several direct bus routes to the centre or you could drive in and use one of the centre’s 3000 parking spaces. Once there, the staff at Oscar Wylee can help you shop a range of stylish, affordable glasses including prescription and non-prescription sunglasses. 
If you are up for an adventure after your appointment with us, why not visit the Hunter Valley Gardens or Hunter Valley Vineyards both around a 40-minute drive away. If you live in the Maitland, Ashtonfield or Metford areas, come in and see the team at Oscar Wylee Green Hills at the Stockland Greenhills Shopping Centre for your optometry needs.         
Meet Our Team
* Optometrist Partner
B.Optom (Hons)/B.VisSc
* 
Our Services
* Bulk Billed Eye Examinations
* Professional Frame Styling
* Frame Adjustments and Repairs
* Visual Fields Testing
* Digital Retinal Scanning
Show All
## Find an Optometrist in Green Hills, East Maitland for an Eye Health Test
An optometrist in Green Hills Shopping Centre, East Maitland is available to provide expert advice and care for ocular health and issues. Oscar Wylee can help you care for your vision with an eye health test in Green Hills, which is important to complete regularly to look for any signs of eye diseases or any other minor changes. At Oscar Wylee Green Hills in East Maitland, our eye tests are available for a bulk billed price if you are on Australia’s Medicare system. For help with more complex eye problems, we will refer you to an eye doctor in the East Maitland area. Come in-store to browse our wide range of prescription sunglasses or if you need help with any eyewear issues, you can ask our highly skilled optical dispenser.
The average price range for optometrists in East Maitland may be based on different factors according to different optometry places, however, could include facility and equipment prices and the health of your vision.
## How to Find an Optometrist in Green Hills, Maitland?
To find an optometrist in Green Hills, Maitland, you can take certain steps that can help make it easier for you such as searching online, assessing the store’s opening hours and finding the directions to your chosen location. The steps on how to find an optometrist in Green Hills are listed below.
1. Search online using the phrase, Green Hills optometrist near me. This can also be done here on the website via our locations page.
2. Click on the Oscar Wylee link, which will take you directly to our Green Hills optometrist store page.
3. See the store’s opening hours and where the store is located specifically.
4. Use the Green Hills Google Business page link located under store hours to see the directions on how to get to the store.
You can also find an optometrist in Green Hills by searching the keywords optometrist near me. If you have locations enabled on your smartphone and you’re in the area of Green Hills, our Green Hills, East Maitland store page should appear easily for you to click on.
### Is it Hard to Get an Eye Appointment in Green Hills, East Maitland?
No, it is not hard to get an eye appointment in Green Hills, East Maitland. You can easily book an appointment to see an Oscar Wylee optometrist in Green Hills right here on this page. At Oscar Wylee we have highly qualified optometrists available for bulk billed eye appointments, which can be booked online or in-store.
#### How to Compare Optometrists in Green Hills to Each Other?
To compare optometrists in Green Hills, you can use factors such as eye tests offered, health fund coverage, lens types and add-ons and eyewear offered. To take care of your vision and eye health, it is important to receive an eye test at least once every two years. There are different types of tests that can be performed in an eye test and not all optometrists may offer the same tests. Health funds can be used to help cover some of the cost of your frames and lenses. To find out if your health fund is accepted at Green Hills optometrist in East Maitland, visit their website. In the case of Oscar Wylee, we accept all major health funds and provide on-the-spot claims in-store. There are many different lens options available for prescription glasses such as single vision, multifocal and high index lenses. Most optometrists in Green Hills will offer these lenses although it is good to make sure. There are also lens add-ons available to enhance your glasses such as anti-reflective and blue light filters. Finally, if you are looking to purchase a pair of glasses after your eye test, you can compare the different styles and colours you are interested in from Green Hills optometrists in East Maitland. Oscar Wylee offers a wide range of frames with vintage and modern inspirations in bold colours and subtle designs.
#### How to Find an Eyeglasses Shop in Green Hills, East Maitland?
To find a glasses store in Green Hills, you can try to follow these simple steps including searching online, selecting a convenient location and looking at their health insurance policies. he steps on how to find a glasses store in Green Hills, East Maitland are listed below.
1. Search online using the phrase, glasses store in Green Hills. This will provide you with various options for glasses stores in the whole Green Hills, East Maitland area.
2. Select a glasses store that is most convenient for you to travel to.
3. Click the link to find out more information such as opening hours, exact location and directions to the glasses store in Green Hills.
4. Read their health insurance policies to ensure you know what health benefits you have access to.
Our Oscar Wylee glasses store in Green Hills, East Maitland offers primary eye care services such as comprehensive eye tests as well as other services performed by an optometrist and offers prescription and non-prescription eyewear.
##### Is it Possible to Purchase Prescribed Sunglasses in Green Hills, East Maitland Without Seeing an Optometrist?
Yes and no, it is possible to [purchase prescribed sunglasses](https://www.oscarwylee.com.au/sunglasses.html) in Green Hills, East Maitland without seeing an optometrist if you already have a prescription that has not expired. If your prescription is expired, you can book an eye test to receive an updated or new prescription which will require you to see an optometrist. This will ensure your prescription sunglasses are appropriate for your visual needs.
## Where is the Oscar Wylee Green Hills Optometrist in East Maitland Located?
The Oscar Wylee Green Hills optometrist in East Maitland is located in the Green Hills Shopping Centre at 1 Molly Morgan Drive. The Oscar Wylee Green Hills optometrist can be found near Woolworths and is an ideal destination for high-quality eye care services.
### What is the Phone Number of Oscar Wylee Green Hills Optometrist Store?
The Oscar Wylee Green Hills optometrist store phone number is [(02) 4905 2105](tel: (02) 4905 2105). You can contact the Oscar Wylee Green Hills optometrist store between the hours of 9 am and 5:30 pm on Monday, Tuesday, Wednesday and Friday, on Thursday between 9 am and 9 pm, between 9 am and 5 pm on Saturdays and between 10 am and 4 pm on Sundays.
### What are the Reviews for Oscar Wylee Green Hills in East Maitland?
The many reviews for Oscar Wylee Green Hills optometrist in East Maitland, left by our various customers can be found here on the website and online when you search for Oscar Wylee Green Hills optometrist. The reviews for Oscar Wylee Green Hills optometrist are listed below.
* Margaret Lewis:  Greeted warmly on arrival, Vincent the optometrist was on time. I was there to have a checkup because of the annual checkup for a driving licence as I’m 81! Thought I was okay until I couldn’t read the top line in 3 of the charts! So I needed a full eye check up. Vincent explained the choices of glasses I would need for driving to increase clarity and long distance plus the sunglasses and the reading glasses! I was becoming anxious because of the cost however once Teachers Health gave a quote I was pleasantly surprised with the final cost! Staff were very patient and gave their undivided attention until I completed the transaction! Most impressed!
* Deborah Layton:  Loving the vibes at Oscar Wylee, Green Hills. The staff were amazing today. Friendly, knowledgeable, and well, they actually cared. No rush, no condescension, not even a hint.
* I Tinlin:  Needed urgent attention to an eye injury and was attended to by all staff in a friendly, professional manner. I can't speak more highly of Vincent and the team.
* Catherine Waterton:  I had almost given up on finding suitable frames but I stumbled upon Oscar Wylee at Green Hills. What an amazing choice of glasses! I had a complex prescription and the team went above and beyond to ensure they could provide me with the correct prescription. The turnaround time was so fast, the cost was unbelievably affordable and the quality of the product is excellent. But most of all the customer service was exceptional. Couldn’t be more impressed.
#### What Treatments or Eye Care Processes are Done in the Oscar Wylee Green Hills Optometrist Location?
The treatments or eye care processes done in the Oscar Wylee Green Hills optometrist East Maitland location include a tonometry test, a digital photograph, a slit lamp exam and a refraction test. Additional tests that may also be performed can include a visual field test and a dilated fundus exam. The treatments or eye-care processes that are done in the Oscar Wylee Green Hills optometrist East Maitland location are listed below.
* A Tonometry Test: An optometrist or optical dispenser will conduct a tonometry test which involves the use of a machine that will release small puffs of air into your eyes. This will assist with measuring pressure in the eye.
* A Digital Photograph: An optometrist or optical dispenser may take a digital photograph of your eye which can be kept on record to use in future appointments to evaluate any changes to your eye.
* Slit Lamp Test: A slit lamp test can be used to evaluate your eye health, by examining your cornea and iris which are the anterior and posterior of the eye.
* Refraction Test: During a refraction test, an optometrist will have you view an image through different lenses and ask you to confirm which helps you see the image clearer.
* Visual Field Test: A visual field test can assist with assessing your peripheral vision, which may be beneficial for identifying any signs of glaucoma.
* Dilated Fundus Exam: A dilated fundus exam can help an optometrist assess your health in more detail by getting a clear view of the retina. This test is typically carried out for patients with diabetes and those who may be at risk of developing retinal damage.
## How Many Optometrists Exist in Green Hills, East Maitland?
There are many optometrists that exist in Green Hills, Maitland that offer many services all to help you take care of your vision, including Oscar Wylee. Here you will find optometry services of the highest standard as we have a team that cares about quality eye care and values customer service. The number of optometrists in Green Hills, East Maitland can possibly depend on the residential demand for optometry services and the wider area size of the Green Hills location.
### What are the Other Closest Optometrist Locations to Green Hills, East Maitland in Australia?
The other closest Oscar Wylee optometrist locations to Green Hills, East Maitland are Kotara and Charlestown. Kotara is close to Green Hills, around 37 km in distance, located at Westfield Kotara Shopping Centre and can be found on level 2, near OPSM. At the [Oscar Wylee Kotara](https://www.oscarwylee.com.au/locations/optometrist-kotara.html) store, we guarantee excellence during our services as we prioritise providing customers with a great in-store experience. Charlestown is close to Green Hills with around 36 km in between stores and can be found at the Charlestown Square Shopping Centre, which is located at 30 Pearson St. The [Oscar Wylee Charlestown](https://www.oscarwylee.com.au/locations/optometrist-charlestown.html) store is located on level 2 of the shopping centre near Apple. If you’re in the Charlestown area, make a visit to our Oscar Wylee store to browse our wide range of fashionable frames for both prescription and non-prescription glasses.
### Oscar Wylee Green Hills optometrists perform bulk billed eye tests
Oscar Wylee can help you prioritise your eye health and take care of your vision. Our store in Green Hills is the place in Maitland to sort your eye care processes and needs including prescription updates, eye health tests to assess vision and detect certain eye diseases, and frame shopping. At Oscar Wylee Green Hills, eye tests are bulk billed for eligible Medicare card holders and performed by our dedicated and experienced Oscar Wylee optometrists.
### Oscar Wylee Green Hills accepts major health funds
At Oscar Wylee Green Hills, our staff can process your health fund claim in-store with a valid health fund card and help answer any questions about what you’re eligible for with your health fund. Some policies will include an ‘optical extras’ cover which you can use to pay towards the cost of your new glasses. Oscar Wylee Green Hills is dedicated to making sure you get what you need at an affordable, competitive price.
### Fashion-forward styles at affordable prices
Oscar Wylee Green Hills is committed to helping you find your perfect pair of frames, offering modern and vintage-style glasses frames at an affordable cost with the design team taking inspiration from the world around us and our home environment of the Australian landscape. Oscar Wylee Green Hills optometrists are there to help provide prescription lenses to fit all customer needs - whether it’s a blue light filter, multifocal lens, or a polarised lens for your prescription sunglasses, our experts in-store are ready to help you with any of your eyesight needs.
Book Appointment
[Call us: (02) 4905 2105](tel:(02) 4905 2105)
[Leave a Review!](https://g.page/r/CefwAYZ0iKsGEAg/review)