# Source: https://www.oscarwylee.com.au/hailey-optical.html

# Hailey
1
## Frame Design of Hailey Glasses
The frame design of Oscar Wylee’s Hailey glasses is characterised by its oval and round shape, low nose bridge and bio acetate frame. Hailey glasses are a feminine and chic women’s frame that will work for any occasion, whether the wearer wants to liven up their everyday style or complement a fun outfit for a day out.
$169    
In stock
Only %1 left
2 pairs from $199
Discount auto-applied at checkout
3 pairs from $249
Discount auto-applied at checkout
Qty
Add to cart
Book an eye test
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
excluding prescription lenses
## About Hailey Glasses
Hailey, as glasses? Groundbreaking. Say hello to your favourite Hailey Bieber-inspired frames in all their optical glory. That’s all!
| Frame fit | Measurements |
| --- | --- |
| Medium | 54 - 16 - 145 |
These measurements mean lens width, bridge, and temple length in millimetres (mm). They can be found on the inside of the temple arm. If you already have a pair that you like, you can compare it to these measurements.
### Made from Bio Acetate
Oscar Wylee’s Hailey frame is a women's oval and round glasses frame that is perfect for those with square, oval, heart, pear, or diamond face shapes. The Hailey frame is a chic, feminine frame that blends well with your outfits while making the perfect statement. The main specs of Oscar Wylee’s Hailey glasses frame, including dimensions, shape, materials, lenses, nose fit and hinges, are listed below.
Filter category 2 - General purpose sunglasses. Good protection against sunglare. Good UV Protection. Not suitable for driving in twilight, at night or under dull conditions 
This frame comes with tinted lenses. An additional $30 will be added to your order total for prescription orders. 

| hailey Frame Features | hailey Frame Description | Dimensions | Shape | Materials | Lenses | Nose Fit | Hinges |
| --- | --- | --- | --- | --- | --- | --- | --- |
| The dimensions of the Hailey frame are measured in millimetres (mm) and are 54 - 16 - 145, meaning the lens width is 54 mm, the bridge is 16 mm, and the temple length is 145 mm. |
| The Hailey frame is an oval and round shape, well-suited to medium faces. |
| Hailey glasses are made from bio acetate. |
| The lenses that can be used in the Hailey frame are optical lenses, which include single vision and multifocal lenses and non-prescription lenses, which are plain and can have a filter, such as a blue light filter, applied. Hailey also comes as sunglasses. |
| The nose fit for Hailey is a low nose bridge fit. |
| The hinges in Hailey are normal hinges, also known as standard or barrel hinges. |
Show All
### What Inspired the Frame Design of Oscar Wylee's Hailey Glasses?
The Oscar Wylee Hailey frame design was inspired by current fashion trends, as oval and round shapes are often in fashion.
## What to Know About Oscar Wylee's Hailey Sunglasses?
There are many aspects of the Oscar Wylee Hailey frames that customers should know about, so they can decide whether this is the right frame for them. The Hailey frame is a women's oval and round glasses frame. Oscar Wylee’s Hailey frame is suitable for many face shapes, but particularly compatible with square, oval, heart, pear, and diamond face shapes. The Hailey glasses feature the standard [parts of glasses](https://www.oscarwylee.com.au/glasses/eye/part-of-glasses), such as a rim, temples, lenses, normal hinges and a low nose bridge.
### What are the Types of Temple Tips or Earpieces Included with Oscar Wylee's Hailey Glasses?
The type of temple tips or earpieces included in Oscar Wylee’s Hailey Glasses are made from bio acetate.
### What Type of Nose Bridge do Oscar Wylee's Hailey Glasses Have?
The type of nose bridge included in Oscar Wylee’s Hailey frame is a low nose bridge.
### What Type of Nose Pads are Included with Oscar Wylee's Hailey Glasses?
Oscar Wylee’s Hailey glasses do not include adjustable nose pads.
### What Type of Lenses do Oscar Wylee's Hailey Sunglasses Have?
The type of lenses that typically come with the Oscar Wylee Hailey [glasses frame](https://www.oscarwylee.com.au/glasses.html) are optical lenses. Optical lenses are glasses lenses that have a prescription within the lens to help correct vision issues such as myopia, hyperopia and astigmatism. Hailey glasses can also come with non-prescription lenses, with add-ons such as a blue light filter. Hailey frames are also available as sunglasses with polarised lenses.
### What Material is Used for the Rim of Oscar Wylee's Hailey Glasses?
The material used for the rim of Oscar Wylee’s Hailey glasses frames is bio acetate. The rim refers to the part of a glasses frame that holds the lenses.
### What Type of Hinges are Included with Oscar Wylee's Hailey Glasses?
The type of hinges included with Oscar Wylee’s Hailey frames are normal hinges, also known as standard or barrel hinges. These provide strength and smooth movement connecting the frame's arms and lenses.
## What Face Types are Most Suitable for Oscar Wylee's Hailey Glasses?
The face types that are most suitable for Oscar Wylee’s Hailey frame are square, oval, heart, pear, and diamond face shapes. The Hailey frame is an oval and round shape, meaning it complements the structure of square, oval, heart, and pear faces particularly well. The Hailey frames help to balance the features of a [square face shape](https://www.oscarwylee.com.au/glasses/face-shapes/square), [oval face shape](https://www.oscarwylee.com.au/glasses/face-shapes/oval), [heart face shape](https://www.oscarwylee.com.au/glasses/face-shapes/heart), [pear face shape](https://www.oscarwylee.com.au/glasses/face-shapes/pear), or [diamond face shape](https://www.oscarwylee.com.au/glasses/face-shapes/diamond), bringing the eyes and brows forward in a flattering way. Although there are many [glasses for face shapes](https://www.oscarwylee.com.au/glasses/face-shapes) that may be considered more aesthetically suitable, it is important that people also choose the frames that make them feel most comfortable and represent their personal style.
## What Size Options are Available for Oscar Wylee's Hailey Glasses?
The size option available for Oscar Wylee’s Hailey frame is a medium-frame fit.
## What Materials are Used to Create Oscar Wylee's Hailey Glasses?
The material used to create the Oscar Wylee Hailey frame is bio acetate. Bio acetate is made mainly from eco-friendly, renewable plant matter with a lesser amount of plasticisers compared to regular acetate.
## What’s Included
## OW Case &amp; Cloth
Protective Case and Lens Cloth
Our high-quality glasses case and lens cloth are included with every purchase of an Oscar Wylee frame. The stylish, magnetic case is made from a hard shell. This sturdy and durable material keeps your glasses protected and safe, wherever you go. Ensure your lenses are clean and scratch-free with our OW microfibre cloth, specifically designed to ensure you have comfortable vision through your lenses.
Oscar Wylee offers:
* Free Shipping on all orders
* 1 Year Warranty on frames and lenses
* Scratch resistance lens coating on all prescriptions
* UV-proof coating on all prescriptions
Health fund rebate: Once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. Learn more about [health funds](https://www.oscarwylee.com.au/health-funds.html).
## Make and Materials
Eco-consciousness meets durability with bio-acetate. Replacing unbiodegradable plasticisers with plant based alternatives, bio-acetate allows a biodegradable lens frame, leaving a reduced carbon footprint on the environment.The frames go through cleaning and strict quality control, and many pairs of crafting hands to be hand-assembled and polished. After your frames have gone through the production process, they are individually examined and&nbsp;packed before making their way to you!
## Warranty Information
### Warranty Information
### Warranty Information
Oscar Wylee provides a 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects. We will repair or replace faulty or defective frames or lenses free of charge for warranty claims made within 1 year of the delivery. We also offer repairs or replacement for problems experienced with vision during everyday use for claims made within 30 days of delivery. If the same product has been discontinued or is no longer available, then we may offer an exchange for a similar product or a refund.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Find a Store Location](https://www.oscarwylee.com.au/locations/full-store-list.html)