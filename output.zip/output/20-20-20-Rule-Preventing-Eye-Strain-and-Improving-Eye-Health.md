# Source: https://www.oscarwylee.com.au/glasses/eye/20-20-20-rule

# 20-20-20 Rule: Preventing Eye Strain and Improving Eye Health
The 20-20-20 rule is an eye exercise that is performed to help prevent eye strain by giving the eyes a break and
having them change focus. The symptoms and side effects of eye strain include dry eyes, trouble concentrating,
blurred vision and headaches. The advantages of the 20-20-20 rule include preventing eye strain, giving the eyes
a break and preventing irritating symptoms. The 20-20-20 rule for eyes can be done when working on a computer or
other digital screens among other tasks to prevent eye strain such as taking breaks and adjusting the screen
brightness. Keep reading to learn more about the 20-20-20 rule and other ways to prevent eye strain.
When you burn your eye, immediate actions that may be recommended to take are to flush the eye with clean
lukewarm water for 15 minutes, do not rub your eyes, cover the eye with a clean cloth, avoid irritants,
don’t
put anything else in your eye and seek medical help. The immediate actions to take when you burn your
eye are
listed below.

## What is the 20-20-20 Rule?
The 20/20/20 method or rule is a type of eye exercise that is performed to relieve digital eye
strain,
according to the American Optometric Association. The eye exercise involves taking a 20-second break,
every 20 minutes to look at something 20 feet away (6 metres). This eye exercise can be performed when
watching, working or gaming on a digital screen or when doing other tasks that require significant
concentration from the eyes such as reading or writing. The 20-20-20 rule is an exercise for the eyes
that helps with eye strain, but in order to protect overall eye health, you should book an appointment
with an optometrist so they can assess your vision and eye health. In summary, the answer to, what is
the 20 20 20 rule, is it is an eye exercise performed to relieve or prevent eye strain.
When Was Your Last Eye Test?
At Oscar Wylee, we recommend you have an eye test at least once every two years to stay on top of
your eye health.
[Book
an eye test](https://www.oscarwylee.com.au/booking)
## Who Developed the 20-20-20 Rule?
An optometrist, Dr. Jeffrey Anshel, developed the 20-20-20 rule in 1991 according to an article
published in the Optometry Times by Brian Chou, OD, FAAO, FSLS. The article reports that Dr Anshel came
up with the idea for the 20-20-20 rule while he was lecturing on how to relieve computer vision stress
in the corporate world. Dr Anshel later published a novel on this topic in 1998 titled, Visual
Ergonomics in the Workplace.
## Why is it Called the 20-20-20 Rule?
The exercise is called the 20-20-20 rule as the name instructs how to perform the exercise. The
three
twenties correlate to 20 minutes, 20 feet and 20 seconds. To perform this rule, every 20 minutes, a
person will look at an object or spot on the wall 20 feet away, 6 metres in the metric system, for 20
seconds. This exercise can be performed when using a digital screen or when doing other tasks where the
eyes may become fatigued such as reading or writing.
### What is the Purpose of the 20-20-20 Rule?
The purpose of the 20-20-20 rule is to prevent eye strain and fatigue by giving the eyes a
regular
break while working on a computer or doing other work that requires intense concentration
from the
eyes. The 20-20-20 rule involves every 20 minutes looking at an object 20 feet away for 20 seconds.
## What are the Advantages of the 20-20-20 Rule?
There are many advantages of performing the 20-20-20 rule which can benefit the eyes when working on a
computer or doing other intense work. The advantages of the 20-20-20 rule include it may prevent eye
strain, it gives the eyes a break from intense concentration and it can prevent irritating symptoms
that
may cause pain or stop you from doing your work. These advantages and their definitions are
listed
below.
* Prevent eye strain:
The 20-20-20 rule is an eye exercise designed to prevent or reduce eye strain. This exercise
prevents eye strain by giving the eyes a break, having them look away from artificial light emitted
by the screen and having them change focus.
* Give the eyes a break:
Following the 20-20-20 rule means you give your eyes a break every 20 minutes which, other than
helping with eye strain, also allows the eyes and body to relax. These breaks can also be a good
time to get up and walk around to prevent your neck, shoulders or back from getting stiff or sore.
* Prevent irritating symptoms:
The 20-20-20 rule is used to prevent eye strain which can cause irritating symptoms that may cause
pain or stop you from doing your work. Symptoms of eye strain include dry eyes, headaches, trouble
concentrating, blurred vision and watery eyes.
### How Does the 20-20-20 Rule Help Reduce Eye Strain?
The 20-20-20 rule helps reduce eye strain by giving the eyes a break, typically from looking at a
digital screen, and allowing them to change focus. Looking at a digital screen for long
periods of
time can have a negative impact on the eyes due to the light emitted from the screen, a person also
tends to blink less when on a computer and the eyes are concentrating intensely which can cause
strain on the eyes. By giving the eyes a break every twenty minutes, it can help prevent or reduce
eye strain.
#### Can the 20-20-20 Rule Improve Overall Eye Health?
No, the 20-20-20 rule will not improve overall eye health, rather it is performed to help
prevent eye strain and reduce symptoms. To stay on top of your eye health, book regular
eye
tests so an optometrist can assess your vision and eye health. Other ways to improve your eye
health are to wear sunglasses, stay active, limit screen time and eat a healthy and balanced
diet.
## When Should I Start Using the 20-20-20 Rule During Screen Time?
A person should start using the 20-20-20 rule after the first 20 minutes of screen time and repeat
until
you have finished working or looking at a screen. For example, if you work for two hours on a
computer
screen, you can perform the 20-20-20 rule six times which is every 20 minutes. Because this eye exercise
only takes 20 seconds, it is easy to perform while using screens or when reading or writing. Whenever
your eyes are feeling strained or tired is a good time to perform the 20-20-20 rule or simply take a
break from your current screen or activity.
### Is it Necessary to Set a Timer to Remind Me to Take Breaks?
It may be necessary to set a timer to remind yourself to give your eyes a break from intense
concentration and prevent eye strain. Some may be able to remember when to take a break or
you can
time it with certain tasks. For example, switching tasks at work can be a reminder to take a break
and perform the 20-20-20 eye exercise.
## What are the Causes of Eye Strain?
Eye strain is caused by doing tasks that require a significant amount of concentration from the
eyes.
The main task that causes eye strain is working on digital screens which is known as digital eye strain
or computer vision syndrome. According to the American Optometric Association, people experience eye
strain when on a computer or digital screen as the eyes are often working harder as the contrast between
letters and the background is reduced and the reflections and glare from the screen can make looking at
the screen difficult. A person also tends to blink less when on a computer which can make the eyes dry
and irritated. Other tasks that may cause eye strain or fatigue include driving long distances and
writing or reading without breaks.
Get a Full Quote In-store
Get fitted for your glasses at Oscar Wylee by visiting us in store and talk to our friendly staff
for a complete quote.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
## What are the Symptoms of Eye Strain?
There are many symptoms of eye strain as well as other eye conditions that may be associated with eye
strain. The symptoms of eye strain include dry eyes, difficulty keeping eyes open, watery eyes,
trouble
concentrating, blurred or double vision, sensitivity to light, soreness in the neck, shoulders or
back
and headaches. These symptoms and their definitions are listed below.
* Dry eyes:
Dry eyes is an eye condition that can be associated with eye strain as people who spend long periods
of time in front of a digital screen tend to blink less which causes the eyes to become dry.
* Difficulty keeping eyes open:
Difficulty keeping eyes open may be a symptom of eye strain caused by sensitivity to light or pain
and irritation.
* Watery eyes:
Watery eyes can be a symptom of eye strain which is associated with dry eyes. Watery eyes is a
symptom of dry eyes as it is the body’s response to the irritation caused by the dryness.
* Trouble concentrating:
A person experiencing eye strain may have trouble concentrating as the eyes have been focusing for
too long, likely becoming tired and irritated.
* Blurred or double vision:
Blurred or double vision may be a symptom of eye strain especially if the underlying cause of the
eye strain is uncorrected refractive errors.
* Sensitivity to light:
Sensitivity to light may be a symptom of eye strain along with many other eye-related problems
caused by the bright light emitted from a digital screen.
* Soreness in the neck, shoulders or back:
Soreness in the neck, shoulders or back is not a direct symptom of eye strain but can be associated
with it, especially digital eye strain.
* Headaches:
Headaches can be one of the symptoms of eye strain due to the eyes concentrating intensely for long
periods of time. An eye strain headache causes the head or eyes to feel pain which can feel like
throbbing, constant pain.
### 1. Dry Eyes
Dry eyes is an eye condition that can be associated with eye strain as people who spend long
periods
of time in front of a digital screen tend to blink less which causes the eyes to become dry.
Dry
eyes is characterised by a lack of tear production which results in an insufficient amount of
moisture in the eyes, making it difficult to maintain their health. [Dry eyes](https://www.oscarwylee.com.au/glasses/eye/dry-eyes) can be treated with
lubricating eye drops, also known as artificial tears, which add moisture to the surface of the eye,
relieving pain and irritation.
### 2. Difficulty Keeping Eyes Open
Difficulty keeping your eyes open may be a symptom of eye strain caused by sensitivity to light
or
pain and irritation. If you are having difficulty keeping your eyes open due to eye strain,
take a
break to rest and relax the eyes until this feeling goes away. You can also try performing eye
exercises such as the 20-20-20 rule or palming. It is important to seek medical attention if you are
having difficulty keeping your eyes open for a prolonged period of time or cannot open them.
### 3. Watery Eyes
Watery eyes can be a symptom of eye strain which is associated with dry eyes. According to the Mayo
Clinic, watery eyes is a symptom of dry eyes as it is the body’s response to the irritation
caused
by the dryness. This occurs as it triggers the lacrimal gland in the eye to generate tears.
Watery
eyes caused by eye strain can be treated by giving the eyes a break so they can rest until the
tearing stops.
### 4. Trouble Concentrating
A person experiencing eye strain may have trouble concentrating as the eyes have been focusing
for
too long, likely becoming tired and irritated. Trouble concentrating can be caused by
decreased
blinking which often occurs when working on a digital screen. This occurs as the eyes become dry and
uncomfortable, making it more difficult to focus. To relieve this symptom of eye strain, take
frequent breaks from tasks that take significant concentration from the eyes such as when working on
a computer or reading.
### 5. Blurred or Double Vision
Blurred or double vision may be a symptom of eye strain especially if the underlying cause of the
eye strain is uncorrected refractive errors. A refractive error is a type of vision issue
that
causes blurry vision due to the shape of the eye stopping light from correctly focusing on the
retina. Types of refractive errors include myopia, hyperopia, astigmatism and presbyopia. [Blurred
vision](https://www.oscarwylee.com.au/glasses/eye/blurred-vision) associated with eye strain may be treated with prescription glasses or contact lenses
to give
the wearer clear and comfortable vision. [Double vision](https://www.oscarwylee.com.au/glasses/eye/double-vision) has been
associated with the refractive error
astigmatism and also with the eye condition dry eyes which is also associated with eye strain.
### 6. Sensitivity to Light
Sensitivity to light may be a symptom of eye strain along with many other eye-related problems
caused by the bright light emitted from a digital screen. Sensitivity to light, known
scientifically
as photophobia, is defined as the eyes struggling to look at bright light due to pain. To reduce
irritation caused by looking at a digital screen all day, you can adjust the brightness or turn on
the blue light filter if available.
Sensitivity to light (photophobia) may also indicate another medical condition. It is important
to have this symptom checked by a healthcare professional as soon as possible.
### 7. Soreness in the Neck, Shoulders, or Back
Soreness in the neck, shoulders or back is not a direct symptom of eye strain but can be
associated
with it, especially digital eye strain. A person can experience a sore neck, shoulders or
back due
to bad posture when sitting at a desk or due to the position of the computer or monitor. To minimise
these issues, the Queensland Government’s Health Department recommends a monitor should be
positioned arm-length away. The top of the monitor should also be at or just under eye level,
ensuring you don't have to strain upwards or downwards.
### 8. Headaches
Headaches can be one of the symptoms of eye strain due to the eyes concentrating intensely for
long
periods of time. An eye strain headache causes the head or eyes to feel like a concentrated,
throbbing pain. Headaches may be caused by uncorrected refractive errors such as farsightedness or
presbyopia which can be treated with prescription glasses or contact lenses. Headaches caused by eye
strain may also be treated by taking a break and allowing the eyes to rest from intense
concentration.
## How to Prevent Eye Strain?
The 20-20-20 rule is just one way of preventing eye strain and there are other activities a person can
employ when using a screen or doing work that requires intense concentration from the eyes. The ways to
prevent eye strain other than the 20-20-20 rule include other eye exercises, eye drops, prescription
glasses, limiting screen time and booking regular eye tests. These preventative measures and
their
definitions are listed below.
* Other eye exercises:
Performing other eye exercises alongside the 20-20-20 rule can help prevent eye strain. Eye
exercises ensure the muscles in the eyes are being properly worked and strengthened. Other eye
exercises include palming, figure eight and pencil push-ups.
* Eye drops:
Eye drops can help treat and prevent eye strain as they add moisture to the surface of the eye. Eye
strain, specifically digital eye strain, causes the surface of the eyes to become dry as you blink
less often when looking at a screen. The best eye drops for eye strain are lubricating eye drops,
also known as artificial tears.
* Prescription glasses:
Prescription glasses may help prevent eye strain as issues with vision could be an underlying cause.
Refractive errors such as farsightedness (hyperopia) and presbyopia can cause eye strain if they are
not corrected as the eyes have to compensate and work extra hard to see clearly.
* Limiting screen time:
Eye strain is most commonly associated with using computers or other digital devices, which is known
as digital eye strain. Therefore, limiting screen time can help reduce computer eye strain and can
also help with sleep.
* Booking regular eye tests:
Booking regular eye tests is important to stay on top of your eye health. An optometrist will assess
your vision and eye health using various tests such as a visual acuity test. This can help prevent
eye strain as an eye test can detect any underlying issues that may be causing it.
### Is Blinking Done Regularly to Keep the Eyes Moist?
Yes, blinking should be done regularly as it keeps the eyes moist by delivering tears to the
surface
of the eye and also keeps the eyes clean. When working on a computer or another digital
screen, a
person’s blinking rate is reduced according to an article published in the National Library of
Medicine. To ensure you add moisture to your eyes, try and remember to blink often when looking at a
screen as it can also help prevent eye strain.
### Can Good Ergonomics Help to Avoid Eye Strain?
Yes, good ergonomics can help a person avoid eye strain. Ergonomics is a practice in the
workplace
of having your environment set up to make your work more efficient, easier and better for your
health and well-being, according to Integrity Physiotherapy. Good ergonomics has many benefits
including high productivity, improved posture and improved mental health and overall health. Bad
ergonomics can lead to eye strain among other issues such as headaches and pain.
Get a Full Quote in Store
Get fitted for your multifocal glasses at Oscar Wylee by visiting us in store
and talk to our friendly staff for a complete quote.
Find a store 
Renew Your Prescription
Don’t let your eye health get away from you. Renew your glasses prescription with an Oscar Wylee
optometrist today.
Book an
eye test 

Oscar Wylee Accepts Major Health Funds
Use your private health fund to limit how much you pay from your own pocket to save big on frames
and lenses.
[Explore health funds](https://www.oscarwylee.com.au/health-funds.html)
Do You Have Sore Eyes?
You may need an eye test. Book yours today at Oscar Wylee for excellent eye care services.
[Book an
eye test](https://www.oscarwylee.com.au/booking)