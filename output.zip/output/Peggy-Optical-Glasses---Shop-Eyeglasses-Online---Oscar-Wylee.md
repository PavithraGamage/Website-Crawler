# Source: https://www.oscarwylee.com.au/peggy-optical.html

# Peggy
1
## Frame Design of Peggy Glasses
The frame design of Oscar Wylee’s Peggy glasses is characterised by a square-round shape, nose pads and a frame made from acetate and stainless steel. The Peggy frame is simple, sophisticated and stylish and will pair well with any outfit or occasion.
$169    
In stock
Only %1 left
2 pairs from $199
Discount auto-applied at checkout
3 pairs from $249
Discount auto-applied at checkout
Qty
Add to cart
Book an eye test
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
excluding prescription lenses
## About Peggy Frames
Slightly wider, slightly squarer, undeniably cuter. Perfect for wider faces and geared with super comfortable nose pads, Peggy is one charming lady.
| Frame fit | Measurements |
| --- | --- |
| WIDE | 53 - 21 - 145 |
These measurements mean lens width, bridge, and temple length in millimetres (mm). They can be found on the inside of the temple arm. If you already have a pair that you like, you can compare it to these measurements.
### Made from Metal and Acetate
Oscar Wylee’s Peggy frame is a women’s square-round glasses frame that is a wide fit, ideal for those with round and oval-shaped faces. The Peggy frame is a simple, stylish, widely wearable frame that is perfect for any day of the week. The main specs of Oscar Wylee’s Peggy glasses frame including dimensions, shape, materials, lenses, nose fit and hinges are listed below.
| Peggy Frame Features | Peggy Frame Description | Dimensions | Shape | Materials | Lenses | Nose Fit | Hinges |
| --- | --- | --- | --- | --- | --- | --- | --- |
| The dimensions of the Peggy frame are measured in millimetres (mm) and are 53 - 21 - 145, meaning the lens width is 53 mm, the bridge is 21 mm and the temple length is 145 mm. |
| The Peggy frame is a square-round shape, well suited to wide faces. |
| Peggy glasses are made from a metal material called stainless steel as well as acetate. |
| The lenses that can be used in the Peggy frame are optical lenses, which include single-vision lenses, multifocal lenses and non-prescription lenses, which are plain and can have a filter like a blue light filter applied. |
| The nose fit of Peggy frames is characterised by nose pads. |
| The hinges in Peggy glasses are normal hinges, also known as standard or barrel hinges. |
Show All
### What Inspired the Frame Design of Oscar Wylee’s Peggy Glasses?
The Oscar Wylee Peggy frame design was inspired by current fashion trends as square-around shaped glasses are often in fashion and widely wearable.
## What to Know About Oscar Wylee’s Peggy Glasses?
There are many aspects of the Oscar Wylee Peggy frames that customers should know about, so they can decide whether this is the right frame for them. The Peggy frame is a square-round shape, suitable for many face shapes but particularly compatible with round and oval shaped faces. The Peggy frame’s simple design means that they are fashionable all year round. Peggy features the standard [parts of glasses such as a rim, temples, lenses, normal hinges and nose pads.](https://www.oscarwylee.com.au/glasses/eye/part-of-glasses)
### What are the Types of Temple Tips or Earpieces Included with Oscar Wylee’s Peggy Glasses?
The type of temple tips or earpieces included in Oscar Wylee’s Peggy Glasses are made from acetate, with the temples made from stainless steel.
### What Type of Nose Bridge do Oscar Wylee’s Peggy Glasses Have?
The type of nose bridge included in Oscar Wylee’s Peggy frame is characterised by nose pads.
### What Type of Nose Pads are Included with Oscar Wylee’s Peggy Glasses?
Oscar Wylee’s Peggy frame includes standard nose pads. Nose pads can be adjusted to fit the glasses to the face as required.
### What Type of Lenses do Oscar Wylee’s Peggy Glasses Have?
The type of lenses that typically come with the Oscar Wylee Peggy [glasses frame are optical lenses. Optical lenses are glasses lenses that have a prescription within the lens to help correct vision issues such as myopia, hyperopia and astigmatism. Peggy glasses can also come with non-prescription lenses, with add-ons such as a blue light filter. Peggy frames are also available as sunglasses with polarised lenses.](https://www.oscarwylee.com.au/glasses.html)
### What Material is Used for the Rim of Oscar Wylee’s Peggy Glasses?
The material used for the rim of Oscar Wylee’s Peggy glasses frames is both acetate and stainless steel. The rim refers to the part of a glasses frame that holds the lenses.
### What Type of Hinges are Included with Oscar Wylee’s Peggy Glasses?
The type of hinges included with Oscar Wylee’s Peggy frames are normal hinges, also known as barrel hinges or standard hinges. Normal hinges have many interlocking loops that are stabilised with a small screw.
## What Face Types are Most Suitable for Oscar Wylee’s Peggy Glasses?
The face types that are most suitable for Oscar Wylee’s Peggy frame are round and oval face shapes. The Peggy frame is a square-round shape, meaning that it complements the structure of round and oval faces particularly well. The softly structured, square-round Peggy frame helps to balance the features of an [oval face shape or a](https://www.oscarwylee.com.au/glasses/face-shapes/oval)[round face shape, bringing the eyes and brows forward in a flattering way. A square-round shape can also bring balance to the face by providing some structure. Although there are many](https://www.oscarwylee.com.au/glasses/face-shapes/round)[glasses for face shapes that may be considered more aesthetically suitable than those mentioned above, it is important that people also choose the frames that make them feel most comfortable, and represent their style.](https://www.oscarwylee.com.au/glasses/face-shapes)
## What Size Options are Available for Oscar Wylee’s Peggy Glasses?
The size options available for Oscar Wylee’s Peggy frame are a wide-frame fit across all colours.
## What Materials are Used to Create Oscar Wylee’s Peggy Glasses?
The material used to create the Oscar Wylee Peggy frame is a mix of acetate and stainless steel. The rim is made from both acetate and stainless steel, the temples are made from stainless steel and the temple tips are made from acetate.
## What’s Included
## OW Case &amp; Cloth
Protective Case and Lens Cloth
Our high-quality glasses case and lens cloth are included with every purchase of an Oscar Wylee frame. The stylish, magnetic case is made from a hard shell. This sturdy and durable material keeps your glasses protected and safe, wherever you go. Ensure your lenses are clean and scratch-free with our OW microfibre cloth, specifically designed to ensure you have comfortable vision through your lenses.
Oscar Wylee offers:
* Free Shipping for Australian Orders
* 1 Year Warranty on frames and lenses
* Scratch resistance lens coating on all prescriptions
* UV-proof coating on all prescriptions
Health fund rebate: Once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. Learn more about [health funds](https://www.oscarwylee.com.au/health-funds.html).
## Make and Materials
Our frames go through numerous stages of production and are hand-polished to ensure a glorious lustre. Featuring a mix of high-quality acetate and polished metal, these mixed materials frames are sure to enhance your eyewear collection. The frames then go through cleaning and strict quality control, and many pairs of crafting hands to be hand-assembled and polished. After your frames have gone through the production process, they are individually examined and packed before making their way to you!
## Warranty Information
### Warranty Information
### Warranty Information
Oscar Wylee provides a 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects. 
We will repair or replace faulty or defective frames or lenses free of charge for warranty claims made within 1 year of the delivery.
We also offer repairs or replacement for problems experienced with vision during everyday use for claims made within 30 days of delivery. If the same product has been discontinued or is no longer available, then we may offer an exchange for a similar product or a refund.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Find a Store Location](https://www.oscarwylee.com.au/locations/full-store-list.html)
Recommended
1. [](https://www.oscarwylee.com.au/aries-optical.html)
[Aries](https://www.oscarwylee.com.au/aries-optical.html)
Champagne
2. [](https://www.oscarwylee.com.au/ford-optical.html)
[Ford](https://www.oscarwylee.com.au/ford-optical.html)
Rose Gold
3. [](https://www.oscarwylee.com.au/amber-optical.html)
[Amber](https://www.oscarwylee.com.au/amber-optical.html)
Rose Gold