# Source: https://www.oscarwylee.com.au/locations/optometrist-capalaba.html

# Optometrist Capalaba
Capalaba Park Shopping CentreShop 45, Corner Redland Bay &amp; Mt Cotton RoadsCapalaba Qld 4157
* Near Kmart
Opening hours
Monday9:00am - 5:30pm
Tuesday9:00am - 5:30pm
Wednesday9:00am - 5:30pm
Thursday9:00am - 7:30pm
Friday9:00am - 5:30pm
Saturday9:00am - 4:00pm
Sunday10:00am - 3:00pm
*Store hours reflect local standard trading hours and exclude public holidays
[Visit our Capalaba Google Business page for directions, reviews, and updates.](https://g.page/r/CWcnSlfNvIkrEBM)
Book Appointment
[Call us: (07) 3705 4132](tel:(07) 3705 4132)
[Leave a Review!](https://g.page/r/CWcnSlfNvIkrEBM/review)
Our Reviews
Pa Tor
1 week ago
I found the staff at the Capalaba store amazingly good. They were so sweet, so efficient and really ...seemed to go that extra mile for me. Thank you!
See more
Yashoda Pant
1 week ago
Luxe34
2 weeks ago
the optometrist was really great however the upselling at the end by the register staff was a little... overbearing.
See more
Deanna Dawson
2 weeks ago
We had such a great experience at Oscar Wylee last week. The optometrist explained everything really... well.
See more
wayne wissemann
3 weeks ago
Customer service was disappointing.
Eye test was nowhere near as thorough as other optometrists. Ove...rall disappointing experience.
See more
Sam
4 weeks ago
Quick tho thorough. Did all the tests needed and at the end they didn’t push me to buy new glasses. ...They actually said I could still go with my current prescription so it’s not all about making money but it’s truly caring!
See more
Samantha Quargnul
4 weeks ago
Quick tho thorough. Did all the tests needed and at the end they didn’t push me to buy new glasses. ...They actually said I could still go with my current prescription so it’s not all about making money but it’s truly caring!
See more
Cindy Bool
1 month ago
The staff at Capalaba Park store are always amazing, and so very helpful, especially Peter. Peter go...es above and beyond to help customers in every way possible, a true asset to the company…
Loganholme store, on the other hand, I would not waste my time again, extremely rude.
See more
Caren Fitch
1 month ago
Great shop with friendly and knowledgeable staff. Good selection of glasses with good prices.
Suzanne Christensen
1 month ago
They were very efficient and professional made my appointment very relaxing  thank you.
Denise Lewis
2 months ago
Very helpful and professional
Sandra Willie
2 months ago
Amazing service and help - very happy
Louise Denyer
2 months ago
Absolutely wonderful people, my daughter had to get her eyes tested and the staff were so kind. Than...ks so much guys.
See more
Bec Cooling
3 months ago
The annual eye test made all the better by Megan who helped us with the whole process. We had our li...ttle one in tow and she was so kind and accommodating to all 3 of us. Thanks Megan!
See more
Bob Martin-Williams
3 months ago
I found the whole thing to be rushed. They do not have the same equipment that Specsavers have and e...xpect you to go to another centre to get what Specsavers could do on the spot. I had to stop and tell the lady examining my eyes that she had not placed the device clearly in front of me so that I could see through it. She did the same thing for my wife who was getting a test at the same time. I wasn’t happy, although they were lovely people. They did their best to be helpful.
It’s not a place I will shop at again. I did enjoy their range though, they had a good selection of frames. The whole experience was, meh!
See more
John HANRAN
3 months ago
Staff were very helpful and did a great job with my eye test. Prices were very competitive and also ...plenty of choices for new glasses.
See more
Criss Zagaglioni
3 months ago
I was very pleased, very helpful and friendly service. I will see them again.
Brett Gerdtz
3 months ago
Extremely happy with the service that I received, the staff were very friendly and very helpful. I w...ould have no hesitation in recommending them to my friends.
See more
Dick Nuttugger
3 months ago
Very good
Kim Saunders
4 months ago
Couldn’t have been easier. I walked in with no appointment booked. I received  attention within a fe...w minutes of looking around. Was able to have a review immediately. Received great assistance and support with choosing the right frames to suit.
See more
Kazimierz Golka
4 months ago
I respond after I take my new glasses.
As the new glasses was checked - they must be corrected.
Plea...se let me know when I can collect them.
Regards
Kazimierz Golka
See more
Courtney Collenette
4 months ago
Such a nice and welcoming place and helped me find what i needed for my eyes
Michelle Winn
4 months ago
Stacey Austin-Kirsch
4 months ago
Always so helpful and knowledgeable when I have chronic health and autoimmune conditions. They’re th...e only ones I trust now to help after being fobbed off by some many others over the decades. Plus their range is super cute.
See more
Morgsxr6 (Morgs)
5 months ago
Made an appointment at short notice, nothing was too much trouble. Very professional and more than w...illing to go the extra step.
Happily recommend the great staff at OQ Capalaba.
See more
Sue Smith
5 months ago
Excellent service,  the staff took note of all my concerns.  The results are great,  I have two pair...s of new glasses in lightweight modern frames. Very happy with both pairs.
See more
Bill Dingli
5 months ago
Very friendly, patient staff.  We ordered prescription glasses for me and my wife.  My wife made a m...istake in ordering distance only, and not graded lenses (distance to close-up).  Peter the manager made new spectacles, charging only for the grading option, and included free all the other features of the previous set of lenses.  We are pleased to be future customers of Oscar Wylee.
See more
Azz Ziggy
5 months ago
Great service. Great selection of glasses. Highly recommend.
Denise H
5 months ago
Best optometrist we have come across.
My husband didn’t need glasses his prescription hadn’t changed... no pressure to
buy just honest and extremely thorough eye test. Mine had changed a lot and the optometrist was very thorough in making sure my new script would be OK before proceeding with my new glasses. Highly recommend this place. We’ll be back.
See more
Dee
5 months ago
Best optometrist we have come across.
My husband didn’t need glasses his prescription hadn’t changed... no pressure to
buy just honest and extremely thorough eye test. Mine had changed a lot and the optometrist was very thorough in making sure my new script would be OK before proceeding with my new glasses. Highly recommend this place. We’ll be back.
See more
Lauren Rowe
5 months ago
Excellent service 5 star
Jennifer Davey
5 months ago
I was very happy with Oscar Wylee
Ashleigh Kay
6 months ago
Karen Cox
6 months ago
Chelsea Honey
6 months ago
Great customer service, from both the optometrist and the front of store staff. Very happy with my n...ew glasses too ????
See more
Gabriella Marenco
6 months ago
Excellent customer service. Both the optician and the person assisting with my initial eye testing a...nd glass selection were amazing. Really happy I went there
See more
COLLIN
7 months ago
Phoebe B
7 months ago
The gentleman that works here is just delightful! He has assisted me on several occasions and is alw...ays friendly, welcoming and professional. Thank you for your service, I appreciate it and you.
See more
Debbie McMullan
7 months ago
Diane Bullpitt
7 months ago
FJ AMOS-MCLEAN
7 months ago
Great service and the staff are very helpful
Jodie Daly
7 months ago
The service is unbelievable. The help choosing glasses makes all the difference. And the optometrist... is excellent
See more
Malou Harvey
7 months ago
The staff attended me straight away and very helpful, very easy to talk. Ived asked to be tested now... even though I don’t have any appointments and they able to fit me in. They are so helpful
See more
Tenelle Ashcroft
7 months ago
Staff very attentive and helpful. Great range of glasses to choose from. Happy with my visit. Will r...ecommend friends and family.
See more
Kasia Rice
7 months ago
As usual the service is excellent. My appointment was to schedule, Michelle was extremely informativ...e explaining all aspects of my script changes and eye health.
Choosing my frames and lens was made easy with the friendly service. Love Oscar Wylee frames, the only ones I've used in over 15 years.
See more
Mark Lawson
7 months ago
Monroe
7 months ago
Alice was thoroughly professional.  Great experience
Lacey Healey
7 months ago
Absolutely brilliant experience. Peter and his crew were spectacular to deal with. So professional a...nd friendly and very helpful. The choice of glasses was also great with vibrant colours and shapes to fit all faces.
See more
Larry Sieler
7 months ago
Very thorough and knowledgeable.  listened to my requests and followed through was very pleased
Debbie King
7 months ago
Team at Oscar Wylee are pleasant and provided a very through test
## Find an Optometrist in Capalaba Park With Oscar Wylee
You can find our Capalaba Oscar Wylee store located in the Capalaba Park Shopping Centre food court. Our Capalaba Park optometrist offers bulk billed in-store eye tests to eligible Medicare cardholders and we accept all major health funds. We offer eye health tests and vision testing. Speak to our friendly staff to find plenty of stylish and affordable frames to choose from. Capalaba Park Shopping Centre has parking inside, and the mall is right next to two major bus stops. Our Capalaba Oscar Wylee store has optometrists qualified to diagnose eye conditions and eye diseases among other services and essential eye care processes. 
When you’re done getting your prescriptions renewed and browsing for a perfect pair of new glasses, take a look around the mall and its surroundings. Capalaba Park Shopping Centre has over 100 stores and services. A short drive out of the shopping centre you’ll find the Coolnwynpin Creek Corridor Koala Nature Refuge, as well as Tingalpa Creek and Capalaba regional park and its lush greenery. Make our eyeglasses shop at Oscar Wylee Capalaba your go-to for some of the best optometry services in Capalaba.         
Meet Our Team
* Optometrist
B.Vision Science
M.Optometry
TPA Endorsed
* Store Manager
Our Services
* Bulk Billed Eye Examinations
* Professional Frame Styling
* Frame Adjustments and Repairs
Show All
## Find an Optometrist in Capalaba, Queensland for an Eye Health Test
For eye health tests and optometry services, you can find an optometrist in Capalaba, Queensland. At Oscar Wylee Capalaba Park, you can receive high-quality eye care performed by dedicated optometrists as well as browse a wide range of stylish frames available in optical glasses and prescription sunglasses. At our glasses store in Capalaba Park, Queensland we have an optical dispenser that can provide professional frame styling and fitting.
For a comprehensive eye test, there’s no need to see an eye doctor in-store, as our Oscar Wylee optometrists are qualified and trained so you can expect all the necessities of an eye health test in Capalaba. We offer eye tests at a Medicare bulk billed price so there are no out-of-pocket expenses for eligible cardholders. The average price range for an optometrist in Capalaba will vary depending on specific factors such as the patient’s overall health, age and visual needs. An eye test typically involves assessing a patient's vision and checking the eye health, including looking for any signs of eye diseases.
## How to Find an Optometrist in Capalaba, Queensland?
To find an optometrist in Capalaba, Queensland you can take certain steps that can help make it easier for you such as searching online, assessing the store’s opening hours and finding the directions to your chosen location. The steps on how to find an optometrist in Capalaba are listed below.
1. Search online using the phrase, optometrist near me in Capalaba. This can also be done here on the website via our locations page.
2. Click on the Oscar Wylee link, which will take you directly to our Capalaba optometrist store page.
3. See the store’s opening hours and where the store is located specifically.
4. Use the Capalaba Google Business page link located under store hours to see the directions on how to get to the store.
You can also find an optometrist in Capalaba by searching the keywords optometrist near me. If you have locations enabled on your smartphone and you’re in the Capalaba area, our Capalaba Park store page should appear easily for you to click on.
### Is it Hard to Get an Eye Appointment in Capalaba, Queensland?
No, it is not hard to get an eye appointment in Capalaba. You can easily book an appointment to see an Oscar Wylee optometrist in Capalaba Park right here on this page. At Oscar Wylee we have highly qualified optometrists available for bulk billed eye appointments, which can be booked online or in-store.
#### How to Compare Optometrists in Capalaba to Each Other?
To compare optometrists in Capalaba, you can use factors such as eye tests offered, health fund coverage, lens types and add-ons and eyewear offered. To take care of your vision and eye health, it is important to receive an eye test at least once every two years. There are different types of tests that can be performed in an eye test and not all optometrists may offer the same tests. Health funds can be used to help cover some of the cost of your frames and lenses. To find out if your health fund is accepted at an optometrist in Capalaba, visit their website. In the case of Oscar Wylee, we accept all major health funds and provide on-the-spot claims in-store. There are many different lens options available for prescription glasses such as single vision, multifocal and high index lenses. Most optometrists in Capalaba will offer these lenses although it is good to make sure. There are also lens add-ons available to enhance your glasses such as anti-reflective and blue light filters. Finally, if you are looking to purchase a pair of glasses after your eye test, you can compare the different styles and colours you are interested in from the optometrists in Capalaba, Queensland. Oscar Wylee offers a wide range of frames with vintage and modern inspirations in bold colours and subtle designs.
#### How to Find an Eyeglasses Shop in Capalaba, Queensland?
To find a glasses store in Capalaba, you can try to follow these simple steps including searching online, selecting a convenient location and looking at their health insurance policies. The steps on how to find a glasses store in Capalaba, Queensland are listed below.
1. Search online using the phrase, glasses store in Capalaba. This will provide you with various options for glasses stores in the whole Capalaba, Queensland area.
2. Select a glasses store that is most convenient for you to travel to.
3. Click the link to find out more information such as opening hours, exact location and directions to the glasses store in Capalaba.
4. Read their health insurance policies to ensure you know what health benefits you can access.
Our Oscar Wylee glasses store in Capalaba Park, Queensland offers primary eye care services such as comprehensive eye tests as well as other services performed by an optometrist and offers prescription and non-prescription eyewear.
##### Is it Possible to Purchase Prescribed Sunglasses in Capalaba, Queensland Without Seeing an Optometrist?
Yes and no, it is possible to [purchase prescribed sunglasses](https://www.oscarwylee.com.au/sunglasses.html) in Capalaba without seeing an optometrist if you already have a prescription that has not expired. If your prescription is expired, you can book an eye test to receive an updated or new prescription which will require you to see an optometrist. This will ensure your prescription sunglasses are appropriate for your visual needs.
## Where is the Oscar Wylee Capalaba Optometrist in Queensland Located?
The Oscar Wylee Capalaba optometrist is located in the Capalaba Park Shopping Centre near Kmart. Capalaba is in the City of Redland in Queensland. Capalaba Park offers great shopping and has parking available inside.
### What is the Phone Number of Oscar Wylee Capalaba Optometrist Store?
The Oscar Wylee Capalaba optometrist store phone number is [(07) 3705 4132](tel:(07) 3705 4132). You can contact the Oscar Wylee Capalaba store between the hours of 9 am and 5:30 pm from Monday to Wednesday, 9 am and 7:30 pm on Thursdays, 9 am and 5:30 pm on Fridays, 9 am to 4 pm on Saturdays and 10 am and 3 pm on Sundays.
### What are the Reviews for Oscar Wylee Capalaba Park Optometrist in Queensland?
The many reviews for Oscar Wylee Capalaba Park optometrist in Queensland, left by our various customers can be found here on the website and online when you search for Oscar Wylee Capalaba Park optometrist. The reviews for Oscar Wylee Capalaba Park optometrist are listed below.
* Rositta:  Highly recommend Oscar Wylee Capalaba. Great, efficient and helpful service every time.
* Fiona Box:  The staff were professional, kind and helpful. My son asked so many questions during my visit but they happily included him in it all. Then to walk away with some fantastic glasses at such an affordable price, I’ll be back next year for my next pair.
* Karen Harding:  The staff are very friendly and provide excellent professional service. Would highly recommend them.
* Lyn Mayberry:  The staff were so friendly and helpful and spent a lot of time with me picking the right frames.
#### What Treatments or Eye Care Processes are Done in the Oscar Wylee Capalaba Park Optometrist Location?
The treatments or eye care processes done in the Oscar Wylee Capalaba Park, Queensland optometrist location include a tonometry test, a slit lamp exam and a refraction test. Additional tests that may also be performed can include a dilated fundus exam. The treatments or eye-care processes that are done in the Oscar Wylee Capalaba Park optometrist location are listed below.
* A Tonometry Test: An optometrist or optical dispenser will conduct a tonometry test which involves the use of a machine that will release small puffs of air into your eyes. This will assist with measuring pressure in the eye.
* Slit Lamp Test: A slit lamp test can be used to evaluate your eye health, by examining your cornea and iris which are the anterior and posterior of the eye.
* Refraction Test: During a refraction test, an optometrist will have you view an image through different lenses and ask you to confirm which helps you see the image clearer.
* Dilated Fundus Exam: A dilated fundus exam can help an optometrist assess your health in more detail by getting a clear view of the retina. This test is typically carried out for patients with diabetes and those who may be at risk of developing retinal damage.
## How Many Optometrists Exist in Capalaba, Queensland?
There are many optometrists that exist in Capalaba to provide eye tests and glasses, including Oscar Wylee. The amount of optometrists available in an area will typically depend on the population. At Oscar Wylee Capalaba in Capalaba Park Shopping Centre, we offer excellent optometry services including eye tests performed by skilled optometrists using high-quality equipment. We also have a wide range of fashion-forward frames that customers can browse in a large selection of sizes and colours. If you’re looking for an optometrist in Capalaba, choose Oscar Wylee and we will take care of your optometry and eyewear needs.
### What are the Other Closest Optometrist Locations to Capalaba, Queensland in Australia?
The other closest Oscar Wylee optometrist locations to Capalaba in Australia are Mt Gravatt and Carindale. The locations and their distance from Capalaba are listed below.
* Mt Gravatt:  Mt Gravatt is close to Capalaba Park, around 15-17 km. The [Oscar Wylee Mt Gravatt](https://www.oscarwylee.com.au/locations/optometrist-mt-gravatt.html) store is located in Westfield Mt Gravatt shopping centre next to Specsavers. Oscar Wylee Mt Gravatt provides primary eye care processes including digital retinal scanning and visual field testing.
* Carindale:  Carindale is close to Capalaba Park, around 10-12 km. The [Oscar Wylee Carindale](https://www.oscarwylee.com.au/locations/optometrist-carindale.html) store is located in Brisbane’s South Eastern suburbs in Westfield Carindale. Oscar Wylee Carindale offers excellent eyewear and optometry services including comprehensive eye tests and frame adjustments and repairs
### Bulk Billed Eye Tests at Oscar Wylee Capalaba Park
Our eye health tests and vision testing at Oscar Wylee Capalaba are carried out by our capable optometrists. They are also able to identify signs of eye conditions and eye diseases through comprehensive eye testing. Here at Oscar Wylee Capalaba, we encourage and can assist you with keeping up to date with your regular eye tests. Come to our eyeglasses shop and let our team update your prescription. Make Oscar Wylee Capalaba your first choice for quality eye care processes.
### Health Funds Accepted at Capalaba Park
You’ll be happy to know that major health funds are accepted at our Oscar Wylee Capalaba Park store. Our team can process your claim at our eyeglasses shop with a valid health fund card, as well as help you to understand your health fund. We think we are one of the best optometrists in Capalaba. Our Oscar Wylee Capalaba staff want to prioritise providing you with the best price for your prescription glasses needs.
### Oscar Wylee Capalaba Park Offers Fashionable Frames
Here at Oscar Wylee Capalaba, we offer modern and vintage-style frames for prescription glasses and prescription sunglasses at our eyeglasses shop. You can even customise your glasses with different lens options from our range. Our optometrists at Oscar Wylee Capalaba can offer expert advice in-store so you can choose what’s best for you. As part of our eyecare processes, you’ll leave our store with a pair of prescription glasses or prescription sunglasses that will suit your visual needs.
Book Appointment
[Call us: (07) 3705 4132](tel:(07) 3705 4132)
[Leave a Review!](https://g.page/r/CWcnSlfNvIkrEBM/review)