# Source: https://www.oscarwylee.com.au/glasses/eye/grey

# Grey Eye Colour: How Rare Are Grey Eyes?
Published on March 7th, 2025
Updated on Month Date, 2025  
Australia   
[Australia](https://www.oscarwylee.com.au/glasses/eye/grey)
[New Zealand](https://www.oscarwylee.co.nz/glasses/eye/grey)
[Canada](https://oscarwylee.ca/glasses/eye/grey)
Canadian French

Grey eyes are a distinct eye colour that can be described as having a light and almost silvery appearance. According to the Vision Centre, only 3% of the world population have this eye colour making it a rare genetic occurrence. The genetics for grey eyes typically result from having low melanin levels and a unique scattering of light in the iris. These eyes can appear to slightly change in colour, in some cases displaying shades of blue or green depending on lighting conditions. Grey eyes may be more likely found in Northern and Eastern European countries such as Ireland, Iceland, Norway, Sweden and Finland.
[Definition](#Definition) [Prevalence](#Prevalence) [Cause](#Cause) [Recommended Glasses Frames](#Recommended)
Do You Have Any Eye Health Concerns?
See one of our highly skilled and knowledgeable optometrists in-store.
[Book an eye test](https://www.oscarwylee.com.au/booking)
## Different Types of Eye Colours
There are several different types of eye colours including amber, brown, green, hazel, blue and grey.
## What is Grey Eye Colour?
Grey eyes are considered the rarest eye colour and can be characterised by their light, pale grey appearance. Grey eyes may stem from having low melanin levels in the iris, which allows for more light to scatter giving the eyes their grey appearance. Other [eye colours](https://www.oscarwylee.com.au/glasses/eye/colour) may have high levels of melanin present, causing more pigment in the eye and therefore presenting brown eyes. People with grey eyes can have a distinct look and appear as if their eye colour slightly changes depending on lighting.
### How Rare are Grey Eyes?
Grey eyes may be considered rare, making up only about 3% of the world's population according to the Vision Centre Organisation. Grey eyes may be most commonly found in individuals of European descent, particularly those from Northern and Eastern Europe. Due to the low melanin levels in the iris and the unique scattering of light in grey eyes, they are less common compared to other eye colours like brown or blue.
### What Causes Grey Eyes?
Grey eyes may be caused by a combination of having low melanin levels in the iris and the way light is scattered in the stroma of the eye. The iris contains a small amount of melanin, which gives the eye colour according to ScienceDirect. In grey eyes, the lesser amount of melanin allows for more scattering of light in the stroma, resulting in a light, grey appearance. This scattering effect can be referred to as Rayleigh scattering and is similar to the way the sky appears blue.
### Why do Grey Eyes Change Colour?
Grey eyes may appear as if they slightly change in colour primarily due to lighting. The low melanin content in grey eyes enables light to scatter in different ways, potentially making the eyes appear lighter or darker depending on the environment. For example,&nbsp; in bright light, they may appear lighter in colour, while in low light conditions, they may look darker.
### Do Grey Eyes Have Multiple Colours?
Yes, grey eyes may have multiple colours such as grey-green eyes, dark grey eyes, light grey eyes and grey-blue eyes. The multiple colours that grey eyes can have may be apparent under certain light conditions as a result of the unique light scattering in grey eyes.
## What are the Different Types of Grey Eyes?
The different types of grey eyes may include grey-green eyes, dark grey eyes, light grey eyes and grey-blue eyes. It is important to note that due to the unique light-scattering nature of grey eyes, they can be mistaken as having varied grey colours. However, this can be due to lighting conditions and not necessarily from having different types of grey eyes. The different types of grey eyes are listed below.
* Grey-green Eyes: Grey-green eyes may be characterised as a visual combination of a grey colour mixed with greenish hues. However, this may be a result of lighting circumstances.
* Dark Grey Eyes: Dark grey eyes may have a deeper shade of grey in lower light conditions.
* Light Grey Eyes: Light grey eyes may have a more silvery appearance and can get a light appearance in brightly lit conditions.
* Grey-blue Eyes: Grey-blue eyes may look like they possess a grey colour mixed with blueish hues. Grey eyes can often be mistaken as blue eyes, however, this can be influenced by lighting conditions.
### Why do Grey Eyes Look Different in Certain Lighting?
Grey eyes may look different in certain lighting due to how light is scattered in the stroma. Grey eyes may look lighter with green or blue hues, while under dimmer conditions, grey eyes may look deeper grey. The unique distribution of melanin combined with lower levels of melanin can affect how it interacts with light.
Find a Store Near You
Our team and optometrists are dedicated to providing you with high quality eye care.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
### How do Grey Eyes Differ from Brown Eyes?
Grey eyes may differ from brown eyes as they have lower levels of melanin present, resulting in a lighter appearance. Grey eyes possess less melanin, resulting in less pigment allowing light scattering in the eye and therefore presenting a grey appearance. This is similar to how green and blue colours are presented in some people’s eyes. However, people with [brown eyes](https://www.oscarwylee.com.au/glasses/eye/common-colour) have more melanin, meaning they have increased pigment, which causes the darker colour of brown to occur.
### How are Grey Eyes Different from Green Eyes?
Grey eyes are different from green eyes due to slightly different levels of melanin present in the stroma. According to the Cleveland Clinic, grey eyes have little to no melanin while [green eyes](https://www.oscarwylee.com.au/glasses/eye/green) may just have low levels of melanin.
### How do Grey Eyes Compare to Amber Eyes?
Grey eyes are different from Amber eyes based on their present melanin levels. Grey eyes can have low levels or no melanin present in the stroma while amber eyes have more melanin, resulting in a darker colour. [Amber eyes](https://www.oscarwylee.com.au/glasses/eye/amber) may be considered as a light brown colour with the addition of golden or copper hues.
#### Can Grey Eyes Have Blue in Them?
No, grey eyes don’t have blue in them, however, they are often mistaken for blue eyes due to the light that passes through the eyes, which can make them appear blue or green sometimes. According to the Vision Center,[blue eyes](https://www.oscarwylee.com.au/glasses/eye/blue) may typically feature yellow or gold flecks whereas grey eyes may have brown specks.
### What Makeup Can Enhance Grey Eyes?
The makeup that may enhance grey eyes can include eyeshadow in colours such as soft pinks, purples, cool blues and a smoky eyeshadow look. In addition to makeup, you can also wear certain clothing colours according to your eye colour and skin tone. You can also [match your glasses to your outfit](https://www.oscarwylee.com.au/glasses/match-your-outfit), which can further complete your overall look.
### What Glasses Frames Work Best for Grey Eye Colour?
The glasses frames that may work best for a grey eye colour can include neutral colours, tortoiseshell patterns, dark red shades, purple shades, blue and green. Neutral colours may be able to blend well with grey eye colours as they won’t disrupt the current colour palette. Tortoiseshell frames can make an ideal simple but elevated frame. Frames of dark red shades, purple shades, blues and greens may help with increasing the vibrancy and adding a pop of colour to your natural colour palette. Different [colour frames](https://www.oscarwylee.com.au/glasses/choose-frame-colour) can make a significant difference to your look, which is why it is important to consider factors such as your eye colour, outfit, skin tone and hair colour.
#### Are There Any Famous Celebrities with Grey Eyes?
Yes, there may be some celebrities with grey eyes such as Ian Somerhalder. Ian Somerhalder is an American actor who may be known for his distinct grey-blue eye colour.
Read Grey Eye Colour: How Rare Are Grey Eyes? in other Oscar Wylee regions and their languages.
Australia   
[Australia](https://www.oscarwylee.com.au/glasses/eye/grey)
[New Zealand](https://www.oscarwylee.co.nz/glasses/eye/grey)
[Canada](https://oscarwylee.ca/glasses/eye/grey)
Canadian French

Ready to book an eye test?
At Oscar Wylee we offer bulk billed eye tests for all eligible medicare card holders.
[Book an eye test](https://www.oscarwylee.com.au/booking)
Major Health Funds Accepted In-store
For the purchase of frames and lenses, use your private health fund insurance to limit how much you pay from your own pocket.
[Explore Health funds](https://www.oscarwylee.com.au/health-funds.html)