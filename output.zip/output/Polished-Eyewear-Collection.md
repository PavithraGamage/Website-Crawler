# Source: https://www.oscarwylee.com.au/glasses/collection/polished.html

# Polished Eyewear Collection
[](#layer-product-list)
[](#layer-product-list)
[](#layer-product-list)
[](#layer-product-list)
Discover the ‘Polished’ collection, precise design, and elevated styles for essential and statement metal glasses frames. Oscar Wylee’s eyewear collection, Polished, exudes quiet luxury and sophistication for those who appreciate elegant form and engineered functionality. Include these frames in your regular eyewear rotation for that perfect polished look.
Check out the [Polished Collection lookbook.](https://www.oscarwylee.com.au/pub/media/wysiwyg/pdf/Dec25-Polished-Collection-Public-Lookbook.pdf)
17 Products        
Showing 15 of 17
1. [](https://www.oscarwylee.com.au/cara-optical.html)
[Cara](https://www.oscarwylee.com.au/cara-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/cara-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/cara-optical.html)
2. [](https://www.oscarwylee.com.au/steph-sunglasses.html)
[Steph](https://www.oscarwylee.com.au/steph-sunglasses.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/steph-sunglasses.html)
[3 pairs from $249](https://www.oscarwylee.com.au/steph-sunglasses.html)
3. [](https://www.oscarwylee.com.au/evie-optical.html)
[Evie](https://www.oscarwylee.com.au/evie-optical.html)
$169.00    
[2 pairs from $199](https://www.oscarwylee.com.au/evie-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/evie-optical.html)
4. [](https://www.oscarwylee.com.au/jas-optical.html)
[Jas](https://www.oscarwylee.com.au/jas-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/jas-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/jas-optical.html)
5. [](https://www.oscarwylee.com.au/arnaud-optical.html)
[Arnaud](https://www.oscarwylee.com.au/arnaud-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/arnaud-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/arnaud-optical.html)
6. [](https://www.oscarwylee.com.au/clara-optical.html)
[Clara](https://www.oscarwylee.com.au/clara-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/clara-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/clara-optical.html)
7. [](https://www.oscarwylee.com.au/haskell-sunglasses.html)
[Haskell](https://www.oscarwylee.com.au/haskell-sunglasses.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/haskell-sunglasses.html)
[3 pairs from $249](https://www.oscarwylee.com.au/haskell-sunglasses.html)
8. [](https://www.oscarwylee.com.au/crane-optical.html)
[Crane](https://www.oscarwylee.com.au/crane-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/crane-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/crane-optical.html)
9. [](https://www.oscarwylee.com.au/neal-optical.html)
[Neal](https://www.oscarwylee.com.au/neal-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/neal-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/neal-optical.html)
10. [](https://www.oscarwylee.com.au/siena-optical.html)
[Siena](https://www.oscarwylee.com.au/siena-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/siena-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/siena-optical.html)
11. [](https://www.oscarwylee.com.au/becca-optical.html)
[Becca](https://www.oscarwylee.com.au/becca-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/becca-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/becca-optical.html)
12. [](https://www.oscarwylee.com.au/micah-optical.html)
[Micah](https://www.oscarwylee.com.au/micah-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/micah-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/micah-optical.html)
13. [](https://www.oscarwylee.com.au/gibbs-optical.html)
[Gibbs](https://www.oscarwylee.com.au/gibbs-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/gibbs-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/gibbs-optical.html)
14. [](https://www.oscarwylee.com.au/minh-optical.html)
[Minh](https://www.oscarwylee.com.au/minh-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/minh-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/minh-optical.html)
15. [](https://www.oscarwylee.com.au/aerin-optical.html)
[Aerin](https://www.oscarwylee.com.au/aerin-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/aerin-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/aerin-optical.html)
17 Products        
Showing 15 of 17
Theme The Frames Choosing Glasses From the Polished Collection Pricing and Shipping
## What is the Theme of the Polished Eyewear Collection?
The theme of Oscar Wylee’s eyewear collection ‘Polished’ revolves around a distinct metallic aesthetic, focusing on metal glasses frames, offering classic and statement style options. Polished captures the opulent elegance of metal eyewear and how it easily offers an elevated and “polished” finish to any look.
### What is the Fashion Inspiration Behind the Polished Eyewear Collection?
The fashion inspiration behind the Polished eyewear collection speaks to the timeless finesse of quiet luxury. Much like the concept of quiet luxury, which prioritises quality materials, precise craftsmanship and timeless designs, this collection stems from these core components to create elevated metal glasses frames for everyday and any outfit.
### What are the Frame Options from the Polished Collection?
The frame options that are available from the Polished collection include styles such as Becca, Clara, Steph, Fariza, Siena, Minh, and colour extensions for Evie, Aerin, Arnaud, Atomix, Cara, Crane, Evie, Gibbs, Haskell, Micah and Neal. The frame options from Oscar Wylee’s Polished collection are listed below.
* Becca: Becca emanates luxe femininity with a striking cat eye in a braided pattern, providing opulent beauty.
* Clara: Clara, featuring metal engraving on the frame alongside a striking combination of metal and acetate, provides an elevated take on square frames.
* Steph: Steph steps out into the sun with grace. Its geometric frame exudes a sophisticated presence, perfect for the Cosmopolitan individual.
* Fariza: Reflect sophisticated intellect with the geometric Fariza frame, ready to elevate your attire with its lustrous allure.
* Siena: The lustrous Siena showcases a sleek oval frame, exuding an IT girl energy and an effortlessly modern charm.
* Minh: The geometric Minh reflects the refined intellect in all of us. With its thin frame adorned in a subtle pattern on the outer rim, Minh will enrich any look.
* Jas: Jas imbues a quiet luxury, with its square frame shape and spring hinges perfect for bringing a refined, comfortable focal point look to your formalwear.
* Aerin: Aerin is a minimalist rectangular frame great for high prescriptions. This unassuming frame will elevate any look and provide maximum comfort, whether in the boardroom or at a fancy restaurant.
* Arnaud: Meet Arnaud, a flattering, rectangular-shaped frame. With its clean, sleek lines, Arnaud brings intrigue to the eyes and helps add sophistication to your look.
* Atomix: Atomix brings forward a luxe take on the aviator with a splay bridge for broader noses and a double bar for stability and edge.
* Cara: This unique, round frame combines acetate and metal for a luxurious, yet playful appeal. Cara’s tasteful two-tone colour way will take you effortlessly from day to night. Perfect for oval and square face shapes.
* Crane: Crane is a classic rectangular frame providing a minimalist look, taken to the next level by its lustrous finish. (P.S. The nose pads are super comfy.)
* Evie: Evie is an acetate frame that is perfect for higher prescriptions. The spring hinges and classic shape make Evie an elegant everyday companion.
* Gibbs: A sleek, sharp-looking frame fit for Agent Leroy Jethro Gibbs. Boasting spring hinges and an adjustable nose fit, this angular frame is perfect for the special agent in all of us.
* Haskell: Haskell is a subtle take on our most coveted round frame, Kato. In a slightly smaller fit Haskell comes with a stainless steel and metal finish for a refined, intellectual twist on the typical sunglass.
* Micah: Micah is a sleek, contemporary frame ideal for the modern sophisticate. This frame is endlessly accommodating to various head sizes with its flexible spring hinge.
* Neal: Meet Neal, a sleek rectangular frame, perfect for round and oval face shapes. Neal emphasises a quiet sophistication with its subtle pronounced browline for sharp yet stylish eyewear.
### What are the Materials of the Glasses From the Polished Collection?
The material of the glasses from the Polished collection is [metal](https://www.oscarwylee.com.au/glasses/materials/metal-frame.html), which is often a classic and popular material for glasses due to its distinct versatility, sleek and minimalist style and durability.
### How to Style Outfits with Glasses From Polished
Glasses from Oscar Wylee’s eyewear collection, Polished, can be paired with a range of different outfits. To create a harmonious look with the aesthetic and style of glasses from the Polished collection, keep it classy and subtle with key pieces such as tailored or straight leg trousers, button shirts, knitwear, leather shoes and outerwear cropped to your upper body proportions. Focus on quality materials and creating timeless silhouettes.
#### What are the Colours of the Frames From Polished?
The colours of the frames from Oscar Wylee’s Polished collection include silver, black, green, red, brown, pink, blue, purple and gold.
### How to Choose Glasses From the Polished Collection?
To choose glasses from Oscar Wylee’s Polished collection, choose the frame that fits you best by trying on different metal frame styles. To know if a frame fits you properly, the frame width typically shouldn’t exceed your temple width or extend above your eyebrows. They should sit comfortably on your nose without slipping, especially when looking downwards. Whether you want frames that can stand out or blend with your clothing aesthetic, Polished offers options for both.
### How to Choose Glasses from the Polished Collection According to the Nose Bridge?
To choose glasses from Oscar Wylee’s eyewear collection, Polished, according to nose bridge, determine your nose bridge type, choose frames for your nose bridge type and prioritise comfort. The Polished collection offers metal frame glasses for a low nose bridge and a high nose bridge. The steps on how to choose glasses according to the nose bridge are listed below.
1. Identify your nose bridge type: Identify your nose bridge type by assessing where your nose bridge is positioned. If the level of your nose bridge aligns with or is below your pupils, it may indicate a low nose bridge. If your nose bridge is elevated away from the face and more pronounced in appearance, then this is characteristic of a high nose bridge.
2. Choose frames for a low nose bridge: Choose frames for a low nose bridge by opting for frames that feature deeper nose pads, a narrower nose bridge to potentially avoid pinching at the bridge.
3. Choose frames for a high nose bridge:  Choose frames for a high nose bridge by opting for frames that sit high on the nose or closer to the browline.
4. Prioritise comfort: Prioritise comfort when choosing the best square glasses by ensuring your chosen frame sits securely on your nose bridge and doesn’t slide down your nose
## How to Choose Glasses from the Polished Collection According to Width?
Oscar Wylee’s eyewear collection, Polished, features glasses in varying widths to accommodate a range of face sizes. These width sizes include Narrow, Medium or Wide. Read on for the various glasses widths from this collection to consider before purchasing.
* Narrow: The Polished collection features the Minh frame, which is a narrow width option, good for petite and narrow faces.
* Medium: The Polished collection features Becca, Cara, Clara, Crane, Evie and Fariza, which are medium widths.
* Wide: Polished features Atomix, Gibbs, Neal, and Steph, which are wide-width options. Wide frames are good for those with wider, larger faces.
## What are the Price Factors For Glasses From Polished?
The price factors for glasses from Oscar Wylee’s eyewear collection, Polished, will vary depending on elements such as the range of glasses, add-ons and lens types. One pair of glasses at Oscar Wylee starts from $169, 2 pairs from $199 and 3 pairs from $249. It should be noted that lens thickness and other add-ons will affect overall pricing.
### What is the Duration of Shipment for Oscar Wylee Glasses?
The average shipping duration for glasses at Oscar Wylee is typically within 7-10 business days from the date of purchase when collecting in-store. An Oscar Wylee team member will contact you once your glasses have passed through all the quality control checks and are ready for collection. If your order is being shipped to your home, it may take up to 2 weeks to arrive. This includes the production time of 7-10 business days and additional time for shipping.
[Prescription Glasses](https://www.oscarwylee.com.au/glasses.html)
[Women’s Glasses](https://www.oscarwylee.com.au/glasses/collection/womens-glasses.html)
[Men’s Glasses](https://www.oscarwylee.com.au/glasses/collection/mens-glasses.html)
[Senior Glasses](https://www.oscarwylee.com.au/glasses/collection/seniors.html)
[Glasses for Kids](https://www.oscarwylee.com.au/glasses/collection/kids-collection.html)