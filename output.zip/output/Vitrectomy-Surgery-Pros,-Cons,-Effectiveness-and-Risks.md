# Source: https://www.oscarwylee.com.au/glasses/eye/surgery/vitrectomy

# Vitrectomy Surgery: Risks and Recovery Time
Updated on June 4th, 2026
Published on May 24th, 2024
Australia   
[Australia](https://www.oscarwylee.com.au/glasses/eye/surgery/vitrectomy)
New Zealand

[Canada](https://oscarwylee.ca/glasses/eye/surgery/vitrectomy)
[Canadian French](https://oscarwylee.ca/fr/lunettes/oeil/chirurgie/vitrectomie)
Vitrectomy surgery is a procedure performed by an ophthalmologist to treat problems affecting the retina and vitreous. A vitrectomy involves removing the vitreous to replace it with another solution. The eye conditions this kind of eye surgery treats include diabetic retinopathy, retinal detachment, macular hole or pucker, a serious eye injury and vitreous hemorrhage. The recovery time for vitrectomy surgery varies for each person, estimated to be around 2 to 8 weeks, according to Eagle Eye Surgeons. Keep reading to learn more about the effectiveness of vitrectomy surgery and the recovery process. It should be noted that Oscar Wylee optometrists do not perform Vitrectomy Surgery.
Take Care of Your Eye Health
Book an eye test with an Oscar Wylee optometrist for a Medicare bulk billed eye test.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Definition](#definition) [Recovery](#recovery) [Risks](#risks)
## What is Vitrectomy Surgery?
A vitrectomy is a type of eye surgery performed by an ophthalmologist to treat different problems with the vitreous and retina. Vitrectomy surgery is conducted if a patient has eye conditions such as diabetic retinopathy, a severe eye injury, a macular hole or pucker or an infection in the eye, among other eye problems. The surgery involves an ophthalmologist making a small incision in the sclera. The eye doctor may perform one or more of the following steps, according to the American Academy of Ophthalmology: remove cataracts, remove scar tissue on the retina, get rid of cloudy vitreous and remove any foreign objects from the eye. This [eye surgery](https://www.oscarwylee.com.au/glasses/eye/surgery) is considered a major surgery that can lead to certain complications such as infection, bleeding and rarely, vision loss.
### How does Vitreous Humour Affect Vision?
The vitreous humour affects vision as it helps the eye hold its 'spherical' shape and helps keep the retina in place by the pressure it places on it, according to Vision Eye Institute.
#### Can Damaged Vitreous Humour Cause Permanent Vision Loss?
A damaged vitreous humour can cause permanent vision loss. This damage is typically brought on by a vitreous hemorrhage, wherein a blood vessel within the retina breaks and bleeds into the vitreous cavity, according to Terrace Eye Centre. However, often this damage by a vitreous hemorrhage is not solely due to this, but also the underlying condition a patient may have, such as diabetic retinopathy.
## What Eye Conditions Require Vitrectomy Surgery?
The eye conditions that require vitrectomy surgery include retinal detachment, diabetic retinopathy, macular hole, macular pucker, severe eye trauma, endophthalmitis, and complicated cataract surgery. Read more about these eye conditions that require surgery below.
### 1. Retinal Detachment
For those who have a retinal detachment, a vitrectomy surgery will likely be undertaken. A retinal detachment is when the retina pulls away from the tissue around it, which supplies the retina with oxygen and nutrients, according to Better Health Channel. A vitrectomy surgery will be able to repair retinal tears and place gas or silicone oil to hold the retina in place, according to Eagle Eye Surgeons.
### 2. Diabetic Retinopathy
Diabetic retinopathy is an eye condition that can cause complications that will require vitrectomy surgery. Diabetic retinopathy is a complication of diabetes wherein the tiny blood vessels in the retina can slowly become damaged, causing problems such as retinal bleeding, blurry vision, light sensitivity, and gradual vision loss, according to Health Direct. Vitrectomy surgery may be undertaken to remove blood or scar tissue affecting vision as a result of this condition, according to Brisbane Bayside Eye Clinic.
### 3. Macular Hole
A macular hole refers to a small break in the macula, which is the part of the eye responsible for detailed, central vision, according to the Macular Disease Foundation Australia. Vitreous surgery removes traction on the retina, using a gas bubble to close the macular hole, according to Eagle Eye Surgeons.
### 4. Macular Pucker (Epiretinal Membrane)
A macular pucker refers to a layer of scar tissue that has formed on the retina, causing wrinkling and potentially blurred and distorted vision if the tissue hangs over the macula, according to Macular Disease Foundation Australia. If vision distorts as a result of a macular pucker, vitrectomy will be conducted, where the vitreous gel will be removed to prevent it from pulling on the retina, according to the Specialist Eye Centre. This will be replaced with a salt solution, and the scar tissue that caused wrinkling will be removed.
### 5. Severe Eye Trauma
Severe eye trauma can be a reason for undergoing vitrectomy surgery, particularly if the vitreous is affected. A vitrectomy might be necessary to remove damaged tissue and restore vision.
### 6. Endophthalmitis
Endophthalmitis is an eye condition that leads to bacterial or fungal infection, namely of the aqueous humour and the vitreous humour, according to the Cleveland Clinic. Endophthalmitis may be treated by vitrectomy surgery in order to remove the infectious material from the eye.
### How does Vitreous Hemorrhage Impact Vitrectomy Recovery?
Vitreous hemorrhage does not impact vitrectomy recovery, however it can be a reason a patient may undergo the procedure in the first place. A vitrectomy may be needed due to a cloudy vitreous, according to the Cleveland Clinic.
Need a New Pair of Glasses?
Visit an Oscar Wylee store near you to browse and try on our latest styles.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
## What Factors Affect Vitrectomy Recovery Time?
The factors that can affect vitrectomy recovery time include age, diabetes control, smoking, medications that reduce immunity, such as steroids and previous eye surgery or trauma, according to Bright Sight Eye Specialists.
### How Do Underlying Eye Conditions Affect Vitrectomy Recovery?
An underlying eye condition may not affect the vitrectomy recovery process; however, it is likely a reason as to why an individual would undergo the procedure in the first place. Conditions such as retinal detachment, macular holes and endophthalmitis are reasons someone may need a vitrectomy.
### How do Gas Bubbles or Silicone Oil Affect Recovery Duration?
Gas bubbles or silicone oil affect recovery duration as both are elements of the substance left inside the eye after surgery, known formerly as the tamponade, which aids recovery. Gas bubbles provide eye support but blur vision until dissolution, while silicone oil stays for months and needs a removal procedure, according to Bright Sight Eye Specialists.
#### Does the Type of Tamponade Agent Affect Vitrectomy Recovery Time?
Yes, the type of tamponade agent can affect vitrectomy recovery and rest time. Gas tamponade has a wide range of recovery time of around 1 to 14 days, silicone oil tamponade takes 1 to 2 weeks, and saline tamponade takes 1 to 3 days, according to the Retina Specialty Hospital.
## What Happens During the First Week of Vitrectomy Recovery?
What happens during the first week of vitrectomy surgery will generally vary from person to person. Generally, patients will experience eye redness, have a wobbly black line in their vision, be required to be positioned face down and only do light movements, according to Bright Sight.
* Eye redness: Eye redness will emerge as a result of recovery, alongside other symptoms such as tearing and eyelid puffiness.
* Wobbly black line: A wobbly black line will appear in the vision where gas meets the fluid, which is normal and shouldn't be a cause of concern.
* Required to be positioned face down: You will be required to be positioned face down or to the side, as instructed by the doctor. This is important to follow as it allows for the macular repair to go smoothly.
* Light movements: Light movements will be recommended, such as light meals, gentle walking as exercise and short sessions using screens such as phones or laptops. You should also avoid lifting over 5kg during this time.
### How Should Patients Care for Their Eyes after Vitrectomy Surgery?
How patients care for their eyes after vitrectomy surgery will ultimately depend on their healthcare provider's advice. Common advice includes wearing proper eye protection, exercising caution when around water, undertaking measures that prevent infection and exercising caution when eating and drinking, according to Terrace Eye Centre. Read more about this advice below.
* Wearing proper eye protection: Wearing proper eye protection is important in recovery. You should not remove the eye shield or pad until you see your doctor the day after the surgery. During the day, you should either wear a pair of glasses (sunglasses, reading glasses, distance glasses) or wear the hard plastic shield you have been provided. The hard shield should be worn at night time while sleeping for the first week after the surgery.
* Exercising caution around water: Exercise caution around water, namely while having a bath or showering. You should not get the eyes wet 24 hours after surgery. After this, you can have a shower as normal, but you should keep your face down if that has been suggested by your doctor. Do not immerse your eyes in a spa or swimming pool for at least one week.
* Undertaking measures that prevent infection: Undertaking measures that prevent infection is important, although it is rarer in modern times. Wash your hands frequently with antiseptic soap or gel, particularly if you are making contact with the eye.
* Exercising caution when eating and drinking: Exercise caution when eating and drinking. For the first 24 hours, you should eat light meals and avoid alcohol. You should look down whilst you are eating, and use a straw as this allows you to place your head down more easily.
### What Symptoms are Normal During Vitrectomy Recovery?
The symptoms that are normal during vitrectomy recovery include temporary blurred vision, swelling and increased eye pressure, according to Eagle Eye Surgeons. Read more about these symptoms that can be present during vitrectomy recovery.
* Temporary blurred vision: Temporary blurred vision is common in the early recovery as the eye adjusts and heals as a result of the surgery. Vision should gradually improve over the weeks.
* Swelling: Swelling inside the eye is a symptom in recovery and can blur vision. Anti-inflammatory medication may help reduce this swelling. It is important to consult your doctor about which medication you should take to reduce swelling.
* Increased eye pressure: Increased eye pressure can occur temporarily after surgery and may require short-term treatment to protect the optic nerve. This is directed by the surgeon.
### Why Should Patients Avoid Heavy Lifting after Vitrectomy Surgery?
Patients should avoid heavy lifting after vitrectomy surgery, as it can lead to intense strain and pressure on the eyes as well as the rest of the eye muscles.
### Why Should Patients Avoid Flying with a Gas Bubble in the Eye?
Patients should avoid flying with a gas bubble in the eye as the pressure in the eye will increase due to the high altitude, according to the City Eye Centre.
#### Can Screen Time Slow Vitrectomy Recovery?
Yes, screen time can slow or be detrimental to vitrectomy recovery. It is often recommended that screen time be minimised during the early recovery stages.
## What Risks Can Happen After Vitrectomy Surgery?
The complications and risks of vitrectomy surgery can depend on a person's existing health conditions, age and what eye problem they have. The complications of a vitrectomy are rare but, according to the Cleveland Clinic, include infection, bleeding, retinal tear and low or high eye pressure. The possible complications and risks of vitrectomy surgery are listed below.
* Infection: A complication of vitrectomy surgery is the development of an infection. The symptoms of an eye infection include discharge or pus coming from the eye, fever and swelling or redness around the eye.
* Bleeding: Excess bleeding inside the eye can be a complication of a vitrectomy. This is known as an intraocular hemorrhage. Most instances can be controlled and generally do not interfere with the surgery, according to an article published in ScienceDirect.
* Retinal tear: A retinal tear may occur due to vitrectomy surgery; however, it is rare. A retinal tear happens when the vitreous pulls on the retina, causing a split.
* Low or high eye pressure: Low or high intraocular pressure can be a risk of vitrectomy surgery. High eye pressure can lead to glaucoma, specifically primary open-angle glaucoma.
### How Successful is Vitrectomy Surgery for Restoring Vision?
Vitrectomy surgery can be considered very successful, with a success rate of over 90%, according to Sight Specialists Australia. Its success will vary from person to person.
#### Can Vitrectomy Surgery Fail to Improve Vision?
Yes, vitrectomy surgery can fail to improve vision. Temporarily, many will have poor vision while the eye is filled with gas from the procedure, but if the surgery is successful, vision will improve, according to the Better Health Channel.
## How Long Does it Take for Vision to Improve after Vitrectomy Surgery?
It will usually take around six to eight weeks for vision to stabilise and improve after vitrectomy surgery, according to Bright Sight Eye Specialists.
### How does Vision Change during the Healing Process after Vitrectomy Surgery?
Vision changes during the healing process after vitrectomy are gradual, as some patients may experience reduced vision for a few days, while others may take weeks to months for significant improvement, according to Sight Specialists.
### What can Patients do to Support Faster Vitrectomy Recovery?
Patients will be asked to do a number of things to support faster vitrectomy recovery. Some of these include facing downwards frequently, as suggested by the doctor, sleeping on the side and neck exercises. The requirements to be done after vitrectomy recovery will be specifically requested by the health professional you see.
#### Do Sunglasses Help after Vitrectomy Surgery?
Yes, [sunglasses](https://www.oscarwylee.com.au/glasses/eye/sunglasses) help after vitrectomy surgery and, in fact, are recommended outdoors post-surgery to protect the eyes from harsh UV rays, according to Melbourne Retinal Surgeon.
Read Vitrectomy Surgery: Risks and Recovery Time in other Oscar Wylee regions and their languages.
Australia   
[Australia](https://www.oscarwylee.com.au/glasses/eye/surgery/vitrectomy)
New Zealand

[Canada](https://oscarwylee.ca/glasses/eye/surgery/vitrectomy)
[Canadian French](https://oscarwylee.ca/fr/lunettes/oeil/chirurgie/vitrectomie)
Ready to Book an Eye Test?
We recommend everyone has a complete eye examination at least once every two years.
[Book an eye test](https://www.oscarwylee.com.au/booking)
Major Health Funds Accepted In-store
For the purchase of frames and lenses, use your private health fund insurance to limit how much you pay from your own pocket.
[Explore health funds](https://www.oscarwylee.com.au/health-funds.html)