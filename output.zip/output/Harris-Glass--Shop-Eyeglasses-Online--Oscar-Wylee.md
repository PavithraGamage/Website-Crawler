# Source: https://www.oscarwylee.com.au/harris-optical.html

# Harris
1
## Frame Design of Harris Glasses
The frame design of Oscar Wylee’s Harris glasses is characterised by its oval and round shape, high nose bridge fit and an acetate frame. Harris glasses are a unisex, stylish frame that will work for any occasion, whether the wearer wants to liven up their everyday style or complement a fun outfit for a day out.
$169    
In stock
Only %1 left
2 pairs from $199
Discount auto-applied at checkout
3 pairs from $249
Discount auto-applied at checkout
Qty
Add to cart
Book an eye test
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
excluding prescription lenses
## About Harris Frames
A unisex design, boasting a keyhole nose bridge, and rounded lenses, this frame will truly up your eyewear game.
| Frame fit | Measurements |
| --- | --- |
| NARROW | 47 - 23 - 150 |
These measurements mean lens width, bridge, and temple length in millimetres (mm). They can be found on the inside of the temple arm. If you already have a pair that you like, you can compare it to these measurements.
### Made from Acetate
Oscar Wylee’s Harris frame is a unisex oval and round glasses frame that is perfect for narrow faces and those with square, oval, heart or pear face shapes. The Harris frame is a stylish, widely wearable frame that blends well with your outfits or makes the perfect statement. The main specs of Oscar Wylee’s Harris glasses frame, including dimensions, shape, materials, lenses, nose fit and hinges are listed below.
| Harris Frame Features | Harris Frame Description | Dimensions | Shape | Materials | Lenses | Nose Fit | Hinges |
| --- | --- | --- | --- | --- | --- | --- | --- |
| The dimensions of the Harris frame are measured in millimetres (mm) and are 47 - 23 - 150, meaning the lens width is 47 mm, the bridge is 23 mm, and the temple length is 150 mm. |
| The Harris frame is an oval and round shape, well-suited to narrow faces. |
| Harris glasses are made from acetate. |
| The lenses that can be used in the Harris frame are optical lenses, which include single vision and multifocal lenses and non-prescription lenses, which are plain and can have a filter, such as a blue light filter, applied. |
| The nose fit for Harris is a high nose bridge fit. |
| The hinges in Harris are normal hinges, also known as standard or barrel hinges. |
Show All
### What Inspired the Frame Design of Oscar Wylee’s Harris Glasses?
The Oscar Wylee Harris frame design was inspired by current fashion trends, as oval and round shapes are often in fashion.
## What to Know About Oscar Wylee’s Harris Glasses?
There are many aspects of the Oscar Wylee Harris frames that customers should know about, so they can decide whether this is the right frame for them. The Harris frame is unisex, oval and round. Oscar Wylee’s Harris frame is suitable for many face shapes, but particularly compatible with square, oval, heart and pear face shapes. The Harris frame’s statement and trendy but essential design mean that they are fashionable all year round. The Harris glasses feature the standard [parts of glasses](https://www.oscarwylee.com.au/glasses/eye/part-of-glasses), such as a rim, temples, lenses, normal hinges and a high nose bridge.
### What are the Types of Temple Tips or Earpieces Included with Oscar Wylee’s Harris Glasses?
The type of temple tips or earpieces included in Oscar Wylee’s Harris Glasses are made from acetate.
### What Type of Nose Bridge do Oscar Wylee’s Harris Glasses Have?
The type of nose bridge included in Oscar Wylee’s Harris frame is a high nose bridge fit.
### What Type of Nose Pads are Included with Oscar Wylee’s Harris Glasses?
Oscar Wylee’s Harris do not have adjustable nose pads.
### What Type of Lenses do Oscar Wylee’s Harris Glasses Have?
The type of lenses that typically come with the Oscar Wylee Harris [glasses frame](https://www.oscarwylee.com.au/glasses.html) are optical lenses. Optical lenses are glasses lenses that have a prescription within the lens to help correct vision issues such as myopia, hyperopia and astigmatism. Harris glasses can also come with non-prescription lenses, with add-ons such as a blue light filter. Harris frames are also available as sunglasses with polarised lenses.
### What Material is Used for the Rim of Oscar Wylee’s Harris Glasses?
The material used for the rim of Oscar Wylee’s Harris glasses frames is acetate. The rim refers to the part of a glasses frame that holds the lenses.
### What Type of Hinges are Included with Oscar Wylee’s Harris Glasses?
The type of hinges included with Oscar Wylee’s Harris frames are normal hinges, also known as standard or barrel hinges. These hinges may have interlocking loops that are stabilised with a small screw.
## What Face Types are Most Suitable for Oscar Wylee’s Harris Glasses?
The face types that are most suitable for Oscar Wylee’s Harris frame are square, oval, heart and pear face shapes. The Harris frame is an oval and round shape, meaning that it complements the structure of square, oval, heart and pear faces particularly well. The Harris frames help to balance the features of a [square face shape](https://www.oscarwylee.com.au/glasses/face-shapes/square), [oval face shapes](https://www.oscarwylee.com.au/glasses/face-shapes/oval), [heart face shape](https://www.oscarwylee.com.au/glasses/face-shapes/heart) or [pear face shape](https://www.oscarwylee.com.au/glasses/face-shapes/pear) bringing the eyes and brows forward in a flattering way. Although there are many [glasses for face shapes](https://www.oscarwylee.com.au/glasses/face-shapes) that may be considered more aesthetically suitable, it is important that people also choose the frames that make them feel most comfortable and represent their personal style.
## What Size Options are Available for Oscar Wylee’s Harris Glasses?
The size options available for Oscar Wylee’s Harris frame are a narrow-frame fit across all colours.
## What Materials are Used to Create Oscar Wylee’s Harris Glasses?
The materials used to create the Oscar Wylee Harris frame are acetate. Acetate, also known as cellulose acetate, is a bioplastic made from cotton fibres or wood pulp. At Oscar Wylee, acetate glasses are made by adding a dye to cellulose acetate, which is rolled into a sheet. The shape of the glasses is then cut from this sheet.
## What’s Included
## What's Included
Each pair of glasses comes with a stylish frame case and lens cloth. We offer free shipping across Australia and 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects.
* Free Shipping for Australian Orders
* 1 Year Warranty on frames and lenses
* Scratch resistance lens coating on all prescriptions
* UV-proof coating on all prescriptions
* Stylish case and cloth
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
## Make and Materials
The frames then go through cleaning and strict quality control, and many pairs of crafting hands to be hand-assembled and polished. After your frames have gone through the production process, they are individually examined and packed before making their way to you!Also known as cellulose acetate, these frames are traditionally hand-crafted by skilled craftsmen, with each frame passing through numerous stages of production and are hand-polished to ensure a glorious lustre.
## Warranty Information
### Warranty Information
### Warranty Information
Oscar Wylee provides a 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects. 
We will repair or replace faulty or defective frames or lenses free of charge for warranty claims made within 1 year of the delivery.
We also offer repairs or replacement for problems experienced with vision during everyday use for claims made within 30 days of delivery. If the same product has been discontinued or is no longer available, then we may offer an exchange for a similar product or a refund.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Find a Store Location](https://www.oscarwylee.com.au/locations/full-store-list.html)
Recommended
1. [](https://www.oscarwylee.com.au/leo-optical.html)
[Leo](https://www.oscarwylee.com.au/leo-optical.html)
Charcoal Dusk