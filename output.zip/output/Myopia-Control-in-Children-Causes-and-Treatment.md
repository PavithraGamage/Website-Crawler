# Source: https://www.oscarwylee.com.au/glasses/eye/myopia-control-in-children

# Myopia Control in Children: Causes and Treatment
Published on February 25th, 2026
Updated on July 20th, 2026
Australia   
[Australia](https://www.oscarwylee.com.au/glasses/eye/myopia-control-in-children)
[New Zealand](https://www.oscarwylee.co.nz/glasses/eye/myopia-control-in-children)
Canada

Myopia, also known as short-sightedness, is a condition where near objects are clear, but distant objects appear blurry, according to Healthdirect. Myopia typically starts before you are ten, making myopia control and treatment imperative for children, according to My Kids Vision Organisation. At Oscar Wylee, we offer Essilor® Stellest® myopia control lenses, which are designed to both correct myopia and slow its progression in children and teenagers. Read on to learn more about myopia in children, including the causes and available management options.
Ask your Oscar Wylee optometrist if Essilor® Stellest® lenses are right for your child. An eye test is required.
Schedule your next eye test with us!
We have dedicated and knowledgeable teams at every store location
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Definition](#definition) [Causes](#causes) [Importance](#importance) [Myopia Correction](#correction)
## What Is Myopia in Children?
Myopia in children is the same as myopia in adults, referring to a condition wherein near objects are clear but distant objects are blurry. Myopia-affected eyes are longer and larger than the typical eye size. Child myopia would specifically occur for those under the age of 18, as they are considered children.
### How is Childhood Myopia Different From Adult Myopia?
Child myopia is different from adult myopia as it progresses more rapidly. The younger a child is, the faster myopia can get worse, while this progression is slower as you age. The eye tends to grow quicker during the preschool and early elementary school years, which makes [myopia](https://www.oscarwylee.com.au/eye-care/eye-conditions/myopia) onset associated with rapid progression, according to Bullimore et al., 2023.
#### Is Myopia a Common Eye Condition in Children?
Yes, myopia can be considered a common eye condition in children. Currently, 26% of parents have a child diagnosed with myopia, according to the Optometry Organisation Australia.
## What Causes Myopia in Children?
The causes of myopia in children include factors such as inadequate time spent outdoors, lack of exposure to natural sunlight and prolonged periods focusing on near-vision tasks, such as reading or using electronic devices, according to the Vision Eye Institute. Children who have short-sighted parents also have a higher risk of being affected themselves.
### What are the Main Risk Factors for Childhood Myopia?
The main risk factors of childhood myopia encompass lifestyle habits and family history. Lifestyle habits such as spending lots of time indoors, excess use of digital devices and lack of light exposure are lifestyle factors that can lead to childhood myopia, according to Recko and Stahl (2015). Family history, such as one or both parents having myopia, can increase the risk of a child inheriting it.
#### Can Screen Time Cause Myopia in Kids?
Yes, excess screen time has been associated with an increased risk of myopia in kids. Researchers from four countries, one being Australia, studied the link between smart devices and myopia development by compiling more than 3,000 separate research articles on the correlation. They found that more than three hours a day on a smart device had a 30% higher likelihood of developing myopia, according to Optometrists Organisation Australia.
## How Does Myopia Affect a Child's Vision?
Myopia can affect a child’s vision by causing blurry vision when looking at objects in the distance. Due to the irregular shape of the eyeball, the eye cannot focus light rays onto the retina and instead focuses the light in front of the retina, according to the Vision Eye Institute. Individuals with myopia may find that objects close up remain clear.
### What Happens Inside a Myopic Eye?
Inside a myopic eye, the main issue is its structure being too long, causing the eye to focus light in front of the retina, instead of onto the retina. Myopia is a common eye condition and a type of refractive error where distant objects appear blurry and objects up close are clear.
#### Does Myopia Cause Blurred Distance Vision?
Yes, myopia does cause blurred distance vision due to a misshapen eye, which disrupts the eye’s ability to receive and bend light. The abnormal shape of the eye causes light that enters the eye to focus in front of the retina rather than on the retina.
## Why Is Myopia Control Important for Children?
Myopia control is important for children as it can help slow down eye growth, as myopia progresses faster in younger children, according to Furqan et al., 2025. Controlling myopia in children mainly focuses on implementing treatment to slow excessive eye growth and is typically recommended to start for young children under 12 years old.
### What Happens if Childhood Myopia is Left Unmanaged?
If childhood myopia is left unmanaged, it may result in higher prescriptions and potentially a higher risk of severe eye conditions in the long term. The more serious eye conditions that could occur later include retinal detachment, macular detachment, cataracts and glaucoma.
#### Can Untreated Myopia Worsen Over Time?
Yes, untreated myopia can worsen over time. Myopia in children can especially worsen over time as the eye can continue to elongate. It is important to ensure early treatment for young children to slow down eye growth, prevent symptoms and the increased risk of other eye conditions.
## What Is Myopia Management in Children?
Myopia management in children, or myopia control, is a term that’s been used more frequently and refers to the use of treatments focused on slowing the progression in children. Some treatments include specialised glasses, soft contact lenses and certain eye drops. At Oscar Wylee, parents can purchase Essilor® Stellest® [myopia control lenses](https://www.oscarwylee.com.au/myopia-control-lenses) in-store for their child, following an eye test. These are specialised lenses designed to not only correct myopia, but also slow its progression in children. According to Optometry Australia, the younger you are when myopia occurs, the faster it can worsen. If the onset of myopia is before 10 years old, roughly 70% may be -3.00D to -6.00D by the age of 15, and 28% may be more than -6.00D.
### What Treatments are Included in Myopia Management?
The treatments included in myopia management can include specialised spectacle lenses, Atropine eye drops, orthokeratology lenses and outdoor time. Atropine eye drops can look just like regular eye drops. However, a much smaller dose is needed to relieve the eye’s exertion when focusing and lessen the signals that push the eye to continue growing, according to Optometry Australia.
#### Is Myopia Management Recommended for Kids?
Yes, myopia management is strongly recommended for kids, especially for children under the age of 12. &nbsp;It is widely agreed by eyecare experts that myopia management should start early in young children and continue through to their late teens. Developing myopia at a young age can often lead to higher levels of myopia faster, and the continued stretching of the eye can potentially lead to more severe eye conditions. Oscar Wylee offers Essilor® Stellest® myopia control lenses in-store as an add-on to your kid's glasses. Simply ask one of our friendly staff members for assistance.
## What Are the Signs of Myopia in Kids?
The signs of myopia in kids include blurry distance vision, squinting and frequent headaches. One of the key signs your child may be developing myopia is when they experience difficulty seeing distant objects or if they need to sit closer to the television to see properly, according to My Kids Vision. Squinting in kids may also be a common sign, in an effort to reduce how much light is going to their eyes. Experiencing headaches can often stem from kids’ eyes exerting more effort to focus on images that may appear blurry.
#### When Should Parents Suspect Myopia?
Parents should potentially suspect myopia if they notice their children struggling to see in the distance or have blurry distance vision, get frequent headaches, squinting or moving closer to improve vision. According to the Vision Eye Institute, myopia typically occurs before the age of 10 and can very likely progress faster. It is important for parents to take their kids to an optometrist as soon as there are changes to their vision to ensure early detection.
#### Does Squinting Indicate Myopia in Children?
Yes, squinting can indicate myopia in children. If you notice your child is frequently squinting, this could suggest they may be compensating for blurry distance vision. It is important to note that squinting can be a common symptom of many other eye conditions, which is why it is important to get your child’s eyes tested to get a professional diagnosis and start any necessary treatment plan as prescribed by the optometrist.
## What Age Can Myopia Start in Children?
The age at which myopia can start in children may be between the ages of 6 and 12, according to My Kids Vision. Therefore, it is important for kids to start getting regular eye tests before they start preschool and continue with regular eye tests every 1-2 years, unless advised otherwise by an optometrist. According to Optometry Australia, the rate of myopia affecting 12-year-olds in Australia has doubled in just 6 years.
### How Early Can Childhood Myopia Develop?
Childhood myopia can develop very early, with the earliest age being around six years old, according to HCF Australia. Genetics can play a big role in this early development, as a child with one short-sighted parent is three times more likely to develop myopia, according to the Vision Eye Institute.
#### Can Toddlers Develop Myopia?
Yes, toddlers can develop myopia; however, this is a notably rare occurrence. There have been cases of young children developing myopia at age four, according to My Kids Vision. These cases of myopia in young children can be a concerning issue as it progresses faster at a young age, which can make their myopia more severe when they reach adulthood. It is important to consult an optometrist if your toddler is experiencing signs of myopic vision.
## How Is Myopia Diagnosed in Children?
Myopia is diagnosed in children through an ordinary eye test. An optometrist will be able to assess how your child can identify letters from a distance and take a closer look inside your eye to detect any refractive errors. They can then use an instrument known as a phoropter to measure the required prescription for correction.
### What Tests are Used to Detect Myopia?
The tests that are used to detect myopia are a visual acuity test and retinoscopy, which are both part of a typical eye test, according to the Optometrists Organisation. A visual acuity test is when you are asked to identify letters on a chart that vary in size from large to small, such as a Snellen Chart, to determine the smallest object you can see clearly. A retinoscopy is a test done to get an accurate refractive error measurement. The optometrist will use a retinoscope to shine light into your eye and observe the reflection or reflex off your retina.
#### Is an Eye Exam Required to Diagnose Myopia?
Yes, an eye exam is required to diagnose myopia. An optometrist can see inside your eye to examine all the structures and detect shortsightedness and any other abnormalities. While there are clear symptoms that can indicate myopia, only an optometrist can measure the extent of a patient’s shortsightedness and assess overall eye health through an [eye exam](https://www.oscarwylee.com.au/glasses/eye/test-glossary).
Visit us in-store!
See our team and optometrist in-store for any of your eyecare needs.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
## What Are Myopia Treatments for Children?
The myopia treatments for children include specialised glasses, such as [myopia control lenses](https://www.oscarwylee.com.au/myopia-control-lenses), using atropine eye drops, and being surrounded by natural light, according to Myopia Australia. Glasses fitted with myopia control lenses correct vision while also slowing down the progression of myopia, according to the My Kids Vision Organisation. Using atropine eye drops can be an effective treatment, as there are clinical trials using low-dose atropine that are shown to reduce myopia progression in children, according to Myopia Australia. Ensure your child has regular outdoor time, as natural light exposure is important for enriching eye health. Children should spend at least two hours outside in natural light.
### Which Myopia Treatment Options are Most Effective?
The myopia treatment options that are most effective may include Atropine eye drops and specialised glasses designed for myopia control. Atropine eye drops can help relax the eye muscles and reduce the elongation of the eye, according to Sydney Ophthalmic Specialists. Specialised glasses specifically for myopia control in children feature lenses that not only help with correcting vision but also help slow down the progression. However, it should be noted that these treatments may not necessarily cure myopia.
#### Are there Proven Treatments for Childhood Myopia?
Yes, there are proven treatments for childhood myopia, which include Atropine eye drops and specialised glasses. Atropine eye drops can be an effective treatment for childhood myopia, as they have consistently exhibited efficiency in reducing myopia progression (Kaiti et al., 2022).
## What Lenses Are Used for Myopia Control?
The lenses that are used for myopia control are specialised lenses and/or contact lenses. Specialised lenses for glasses are intended to help clear blurry vision and slow down eye growth. Certain soft disposable contacts and overnight rigid contacts are often used for myopia control, according to Sydney Ophthalmic Specialists. It is important to note that Oscar Wylee offers specialised myopia control lenses, but does not provide any types of contact lenses.
### How do Myopia Control Lenses Work?
Myopia control lenses work by adjusting the focus in specific areas of the lens, which is thought to modify factors that cause the eye to elongate and progress myopia. These lenses, therefore, aid in reducing eye growth.
#### Do Special Lenses Slow Myopia Progression?
Yes. Special lenses can slow myopia progression, depending on the type of lenses. Lenses that are specifically designed for myopia control can aid in reducing eye growth. It is typically recommended to start management as early as possible for children to receive the best results.
## What is Myopia Correction?
Myopia correction refers to some methods used to improve vision in people with myopia (nearsightedness). Myopia correction primarily focuses on clearing blurry vision with standard prescription glasses. However, myopia control implements specialised treatments that are evidence-based, such as atropine drops and/or specialised lenses for glasses. The methods of myopia correction include prescription eyeglasses, contact lenses, orthokeratology and laser eye surgery. The different methods for myopia correction are listed below.
* Prescription Eyeglasses: Prescription eyeglasses are prescribed when a patient shows signs of refractive errors in their eye test.
* Contact Lenses: Contact lenses, such as standard soft lenses and rigid gas-permeable lenses, can be an alternative to glasses, used to treat shortsightedness.
* Orthokeratology: Orthokeratology are specially designed contact lens that patients can use overnight to help them see in the daytime without wearing contacts or glasses.
* Laser Eye Surgery: Laser eye surgery is a common laser eye surgery carried out to permanently reshape the cornea.
### 1. Prescription Eyeglasses
Prescription eyeglasses are a form of myopia correction as they help with correcting vision. You would typically need to see an optometrist so they can examine all the necessary parts of the eye for shortsightedness and assess your vision requirements. Standard prescription eyeglasses use concave lenses to aid blurry distance vision by bending light rays correctly onto the retina.
### 2. Contact Lenses
Contact lenses are thin, curved lenses that you place directly on the surface of the eye to help correct myopia, the same way eyeglasses do. Contact lenses help by bending light that enters the eye directly onto the retina. Contact lenses offer patients diagnosed with myopia an alternative correction method to eyeglasses, especially if they have active lifestyles or routines.
### 3. Orthokeratology
Orthokeratology lenses are another form of myopia correction that involves rigid contact lenses worn for sleeping to help alter the shape of the cornea. Orthokeratology lenses, also referred to as ortho-k lenses, reshape the cornea to allow patients to have clear vision during the day without the need to wear glasses or contacts. Patients who are suitable for this method are children and teenagers, and adults who don’t want to wear glasses in the daytime.
### 4. Laser Eye Surgery
Laser eye surgery, such as LASIK, may be recommended for myopia correction by altering the thickness of the cornea. The cornea is the outermost layer of the eye, protecting the structures in the eye. Individuals with myopia may require laser [eye surgery](https://www.oscarwylee.com.au/glasses/eye/surgery) depending on the severity of their condition.
### How Myopia Correction Works?
Myopia correction works through the prescribing of glasses that are concave. Concave lenses are used to correct short-sightedness and appear thinner in the centre than at the edge.
#### Can Myopia Correction Improve a Child's Vision Permanently?
No, myopia corrective methods cannot improve a child’s vision permanently. Myopia cannot be cured; however, there are treatment measures that aim to slow down progression, such as wearing specialised glasses, soft contact lenses, or using atropine eye drops according to My Kids Vision Organisation.
Try our frames on in-store or talk to an optometrist
Our teams are passionate about eyecare and providing quality services!
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
## How Fast Does Myopia Progress in Children?
Myopia progresses in children the fastest between the ages of 7 and 10 years old and then usually slows down a little each year after, according to My Kids Vision.
### What Factors Influence Myopia Progression?
The factors that influence myopia progression include genetics and time spent outdoors. A study called ‘Risk Factors for Incident Myopia in Australian Schoolchildren’ found that, in a group of 2103 children, time spent outdoors was negatively associated with incident myopia in both younger-aged teenagers and older-aged teenagers. However, near work and parental myopia were additional significant risk factors for myopia only in the younger cohort.
#### Does Myopia Worsen Every Year?
Yes, myopia does worsen every year. In the past, myopia was thought to stabilise around the time the eye reaches its adult size (around 20 years old); however, recent research has shown that myopia can progress well into adulthood, according to the Optometrists Organisation.
## How Can Parents Help Prevent Myopia Worsening?
Parents can help prevent myopia worsening by closely monitoring their children’s external environment and activities. They should ensure their children have at least two hours outdoors every day, and minimise the amount of recreational close-up activities they do, such as playing video games, according to The Royal Australian and New Zealand College of Ophthalmologists. It is important to get your child’s eyes tested to maintain [eye health](https://www.oscarwylee.com.au/glasses/eye/health-tips-keeping-eyesight-healthy) and allow for early detection of any potential problems with their vision.
### What Lifestyle Changes Help Control Myopia?
The lifestyle changes that help control myopia include more time spent outdoors and utilising the 20-20-20 rule. Children should spend at least 90 minutes outside and regularly do the 20-20-20 rule, which means that after 20 minutes of doing near-work, they should look at something 20 feet away for 20 seconds, according to the Centre for Eye Research Australia.
#### Does Outdoor Time Help Prevent Myopia?
Outdoor time can help prevent myopia. Several studies have shown the benefits of outdoor time and how it can prevent or lower the chances of myopia development in children. There are no concrete reasons as to why outdoor time can assist in prevention, but according to research in Progress in Retinal and Eye Research (2017), the sun’s rays cause a release of dopamine, which impacts the retina and may slow the elongation of the eye, as referenced in the Optometrists Organisation.
## How Is Myopia Corrected with Glasses?
Myopia is corrected with glasses that have concave or minus lenses that focus light directly onto the retina. The myopic eye focuses short of the retina at the back of the eye, leading to blurry distance vision.
### What Prescription Lenses are Used for Myopia?
The prescription lenses that are used for myopia are concave lenses. Myopic vision occurs because the eye is more elongated than the typical eye, making the light focus in front of and not on the retina. Myopia is corrected with a concave lens, as this allows light entering the lens to diverge so that it will focus on the retina instead.
#### Is a Concave Lens Used to Correct Myopia?
Yes, concave lenses are often used to correct myopia. Myopic vision occurs because the eye is more elongated, making the light focus in front of and not on the retina. Myopia is corrected with a concave lens, as this allows light entering the lens to diverge so that it will focus on the retina instead.
## How Often Should Children with Myopia Get Eye Tests?
Children with myopia should get an eye test every six months, or as otherwise instructed by their optometrist, until their vision becomes stabilised according to My Kids Vision. After their vision levels are stabilised and they do not experience any major vision differences, they can get yearly eye tests.
### Why is Regular Monitoring Important?
Regular monitoring is important for myopia as it allows for optometrists to be aware of any changes to your vision. It is important to consult an optometrist if your myopia worsens, so you can get professional, tailored advice for your eyesight.
#### Should Myopic Children Have Yearly Eye Tests?
Yes, myopic children should have yearly eye tests. This is to ensure optometrists can assess the progression of myopia and whether it has improved or worsened. You should see an optometrist more than once a year if your child is seeing a decline in their vision.
## What Types of Glasses Are Best for Children with Myopia?
The types of glasses that are best for children with myopia are those that are comfortable and compatible with the prescribed lenses. It is important to try on frames made in a variety of materials to see which one is most comfortable for the child. Metal glasses, which come with adjustable nose pads, can be beneficial for children with low nose bridges, which refer to those with nose midlines that sit at the same level of or below the eyeline, as these prevent slippage. Additionally, children with strong prescriptions for myopia correction, who tend to be thicker set and heavier, might benefit from selecting a high-index lens material to reduce the thickness and overall weight of the lens on the face, according to My Kids Vision Organisation. There are many [different types of glasses](https://www.oscarwylee.com.au/glasses/types%20); however, the most suitable type will depend on the condition of your child and what is advised by your optometrist.
### What Should Parents Look for When Choosing Glasses for a Myopic Child?
Parents should look for comfort when choosing glasses for a myopic child. It is important to try on frames made in a variety of materials to see which one is most comfortable for the child. Metal glasses, which come with adjustable nose pads, can be beneficial for children with [low nose bridges](https://www.oscarwylee.com.au/glasses/low-bridge-fit-glasses.html), which refer to those with nose midlines that sit at the same level of or below the eyeline. Children with strong prescriptions for myopia correction, which tend to be thicker on the edges and heavier, might benefit from selecting a high-index lens material to reduce the thickness and overall weight of the lens on the face, according to My Kids Vision Organisation.
#### Are Prescription Glasses Enough to Control Childhood Myopia?
Yes and no, while regular [prescription glasses](https://www.oscarwylee.com.au/glasses.html) are important for constant clear vision in myopia, they do not control childhood myopia. Other strategies such as specialised myopia control lenses, contact lenses and eye drops may be a better solution to control myopia. Speak to your optometrist to find a solution tailored to your clinical needs
Read Myopia Control in Children: Causes and Treatment in other languages and regions where Oscar Wylee is active.
Australia   
[Australia](https://www.oscarwylee.com.au/glasses/eye/myopia-control-in-children)
[New Zealand](https://www.oscarwylee.co.nz/glasses/eye/myopia-control-in-children)
Canada

Oscar Wylee Accepts Major Health Funds In-store
Visit Oscar Wylee in-store for eye care and eye wear services, and your health fund may help cover some of the cost.
[Explore health funds](https://www.oscarwylee.com.au/health-funds.html)
Experience Quality Eye Care!
We have knowledgeable optometrists at Oscar Wylee, who are available in-store to perform high-quality eye tests
[Book an eye test](https://www.oscarwylee.com.au/booking)