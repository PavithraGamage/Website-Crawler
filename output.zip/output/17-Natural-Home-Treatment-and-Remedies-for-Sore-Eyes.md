# Source: https://www.oscarwylee.com.au/glasses/eye/sore/remedies

# 17 Natural Home Treatments and Remedies for Sore Eyes
Updated on June 4th, 2026
Published on March 20th, 2023
Australia
[Australia](https://www.oscarwylee.com.au/glasses/eye/sore/remedies)
[New Zealand](https://www.oscarwylee.co.nz/glasses/eye/sore/remedies)
[Canada](https://oscarwylee.ca/glasses/eye/sore/remedies)
[Canadian French](https://oscarwylee.ca/glasses/eye/sore/remedies)
The 17 natural home treatments and remedies for sore eyes include Epsom
salts, warm compresses and essential oils. Sore eye remedies can be defined
as homemade medicationsand treatments
prepared easily and naturally, to treat and relieve the symptoms of sore
eyes. Home remedies should not be an exclusive treatment for eye conditions
but they may help relieve discomfort or irritation when at home. The
symptoms of sore eyes include pain, discomfort and swollen eyes. Sore eyes
may be caused by allergies, conjunctivitis, dry eyes and chalazia.
The information in this article is general in nature. It is important
to consult with a healthcare professional before using any home
treatments or remedies for sore eyes.
Due for an eye test?
With an optometrist in every store, you can receive a bulk billed eye test
to assess your vision and the health of your eyes.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Home remedies](#remedies) [Treatments](#treatments)
[Definition](#definition) [Causes](#causes)
[Prevention](#prevention)
The natural remedies for sore eyes include
milk and honey, potato, Epsom salt, castor oil, essential oils,
coriander, cucumber, warm compress, rose water, cold compress, salt water,
turmeric, guava leaves, aloe vera, green tea bags, chamomile tea compress
and honey eye compress.
The natural remedies mentioned for sore eyes are for informational
purposes only and are not guaranteed to cure or relieve symptoms.
Individual results may vary. Because eye conditions can escalate
quickly, please consult an optometrist or healthcare professional if you
experience persistent pain, vision changes, or severe discomfort.&nbsp;The home remedies for an eye infection that may cause sore eyes,
among other eye conditions that cause sore eyes, are listed below.
* Milk and honey: The soothing properties of
milk and the antibacterial qualities of honey work together to help sore
eyes.
* Potato: Potatoes possess properties that
can be beneficial to the skin and body and may treat sore eyes.
* Epsom salt: Epsom salt is a common
component of integrated medicine and can be used as a home remedy for sore
eyes.
* Castor oil: Castor oil is used in eye
drops to provide relief from eye irritation and can treat sore eyes.
* Essential oils: Essential oils may be used
as a natural remedy for eye infections that cause sore eyes, such as
conjunctivitis.
* Coriander: Coriander is an annual herb
that may relieve itchy and sore eyes and is often used in traditional
medicine.
* Cucumber: Cucumber is a popular ingredient
used in natural home remedies and not only helps sore eyes but also
irritated skin and puffy eyes.
* Warm compress: A warm compress is a simple
and commonly used home remedy for many eye issues such as sore eyes.
* Rose water: Rose water is commonly used in
home remedies to relieve sore or irritated eyes.
* Cold compress: A cold compress is an
effective home remedy for treating sore eyes as the cold temperature can
help reduce swelling and inflammation.
* Salt water: Salt water is a popular
natural home remedy used to treat certain eye issues such as eye
infections.
* Turmeric eyewash: Turmeric is a
multifaceted herb that contains curcumin, which may have medicinal
properties such as antioxidant, anti-bacterial and anti-inflammatory.
* Guava leaves: Guava leaves have
anti-inflammatory and antimicrobial properties that help to treat
swelling, irritation and pain in the eyes.
* Aloe Vera: Aloe vera has anti-inflammatory
and moisturising properties that can aid in soothing inflamed skin around
the eyes.
* Green tea bags: Green tea is a caffeinated
drink made from camellia sinensis leaves, and its tea bags may be used to
soothe sore eyes.
* Chamomile Tea Compress: A chamomile tea
compress may be used to bring down inflammation and soothe sore eyes.
* Honey Eye Compress: A honey eye compress
may help with relieving sore eyes due to their antibacterial properties.
Home remedies should not be used in place of proper medical treatment.
Consult a healthcare professional if you are experiencing eye problems.
## 1. Milk and Honey
Milk and honey may be used as a home remedy for sore eyes as
the soothing properties of milk and the antibacterial qualities of
honey work together to help treat the eyes.
Itching, redness, and swelling are a few symptoms of sore eyes that milk
and honey can help with because they are calming and anti-inflammatory.
It is not advised to put this home remedy directly in the eye.
## 2. Potato
Potatoes surprisingly
possess properties that can be beneficial to the skin and body.
Potatoes are rich in vitamins such as B6 and C
meaning they may help to reduce inflammation to treat sore eyes and
puffiness. It may also reduce dark circles under the eyes due to its
calming effect.
It is not advised to put this home remedy directly in the eye.
## 3. Epsom Salt
Epsom salt is a
common component of integrated medicine which is a type of medicine
that works to treat the mind and the body at the same time.
According to the Cleveland Clinic, Epsom salt is a naturally occurring
mineral salt of magnesium sulphate.
To use Epsom salt as a home remedy for sore eyes, mix Epsom salt in hot
water until it dissolves. Soak up the solution with a cotton pad and
place it over the closed eyes for 5-10 minutes. After the treatment,
rinse the eye out with water.
## 4. Castor Oil
Castor oil is
often used in eye drops to provide relief from eye irritation.
Castor oil is derived from castor beans and is used in pharmaceuticals
and medicine. It is a naturopathic method used to treat many different
conditions including sore eyes.
It is not advised to put this home remedy directly in the eye.
## 5. Essential Oils
Essential oils should not be used or applied anywhere near the
eyes.
To use essential oils as a sore eyes remedy, you will need to use them
in a diffuser which will be distributed via water vapour. Essential oils
are commonly used in natural remedies due to their medicinal properties
and are made by extracting the natural chemicals that come from certain
plants such as lavender, rose and tea trees.
## 6. Coriander
Coriander is an annual herb that
may relieve itchy and sore eyes and it is often used in traditional
medicine.
Coriander contains anti-inflammatory and anti-bacterial properties used
to help soothe sore eyes.
It is not advised to put this home remedy directly in the eye.
Visit a store near you
Come in and see our friendly staff where you can browse through our
wide range of stylish and on-trend glasses.
[Find a store](https://www.oscarwylee.com.au/locations)
## 7. Cucumber
Cucumber is a popular ingredient used in natural home remedies and skin
care products to not only help sore eyes but also irritated skin and
puffy eyes. Cucumber is
used for its cooling effects, hydration and anti-inflammatory
properties due to the vitamin C.
Use slices of cucumber soaked in cold water for the ultimate cooling
effect and place over closed eyes for 5-10 minutes. The juice of a
cucumber can also be used to treat sore eyes and may soothe puffy eyes
and lighten dark circles. Repeat this cucumber home remedy when the eyes
feel in need of cooling relief.
## 8. Warm Compress
A warm compress is a simple and commonly used home remedy for many eye
issues. It can be
effective for treating sore eyes as the heat from the compress helps
to increase blood flow to the area, reducing inflammation and
relieving discomfort.
A warm compress is made up of warm water and a
washcloth. Simply take a clean
cloth and soak it in warm, not hot, water, wring out any excess water
then gently place it over closed eyes and leave it for 2-5 minutes. This
can be repeated several times throughout the day to soothe the eyes.
## 9. Rose Water
Rose water is commonly used in home remedies to relieve sore or
irritated eyes. Rose water is
made with rose petals steeped in distilled water and may have
benefits such as soothing irritated skin, reducing inflammation and
calming redness.
It is not advised to put this home remedy directly in the eye.
## 10. Cold Compress
A cold compress is an effective home remedy for treating sore eyes as
the cold temperature of the compress can
help reduce swelling and inflammation, numb the area, and relieve
discomfort.
A cold compress is comprised of cold water and a washer or cloth. Simply
take a clean cloth and soak it in cold water, wring out excess water
then gently place it over the closed eyes and leave for 2-5 minutes.
This can be repeated several times throughout the day to soothe the
eyes.
## 11. Salt Water
Salt water is
a popular home and natural remedy used to treat certain eye issues
such as eye infections.
It works by clearing away eye irritants such as dirt or pus, functioning
like tears in the eyes. Salt water is full of minerals such as iron and
zinc which are beneficial for the skin as it helps with inflammation and
has healing properties.
Salt water can be made at home using cooled boiled water and salt. Mixed
together, this natural remedy can be wiped across the eyelids using a
cotton pad. Repeat this process a few times a day to soothe eye
irritation.
## 12. Turmeric
Turmeric is
a multifaceted herb that contains curcumin that may have medicinal
properties
such as antioxidant, anti-bacterial and anti-inflammatory. Turmeric is
known to have many health benefits and turmeric may help treat sore and
irritated eyes.
It is not advised to put this home remedy directly in the eye.
## 13. Guava Leaves
Guava leaves have
anti-inflammatory and antimicrobial properties that help to treat
swelling, irritation and pain in the eyes.
Guava leaves are members of the Myrtle family and are available all year
round. They have been used in natural medicine for relief from
menstruation symptoms and may help boost immunity.
It is not advised to put this home remedy directly in the eye.
## 14. Aloe Vera
Aloe vera is
a succulent plant that has been utilised as a natural remedy for
sunburns and other minor burns for hundreds of years.
Its clear gel inside its long and thick leaves possesses a substance
that is reminiscent of jelly, rich in amino acids, enzymes, minerals and
vitamins. According to Healthline, it can help with managing inflamed
skin.
## 15. Green Tea Bags
Green tea is
a caffeinated drink made from camellia sinensis leaves, and its tea
bags may be used to soothe sore eyes.
The caffeine in green tea is believed to help to treat minor swollen and
puffy eyes as it restricts the blood vessels.
## 16. Chamomile Tea Compress
A chamomile tea compress
may be used as a natural home remedy for sore eyes, as the caffeine
content is believed to aid in reducing inflammation,
according to Healthline.
## 17. Honey Eye Compress
A honey eye compress
may be used to help relieve sore eyes, potentially caused by dry
eyes, due to its antibacterial properties and aid in reducing
inflammation, according to the Vision Eye Institute (2020).
It is not advised to put this home remedy directly in the
eye.
## What are Sore Eyes?
Sore eyes is a term used to describe
a condition or symptom where the eyes are irritated or mildly painful
and can occur due to many different factors.
Sore eyes is also known as
[eye pain](https://www.oscarwylee.com.au/glasses/eye/pain-definition)
and may be due to inflammation or infection. The conditions that may
cause sore eyes include conjunctivitis and blepharitis. Symptoms of sore
eyes include blurred vision, dry eyes, eye pain, and watery or tearing
eyes. Other than home remedies, sore eyes are treated by a health care
professional depending on the cause.
It is important to consult with a healthcare professional if you have
sore eyes and before using any home treatments for this condition.
### How do Sore Eyes Start?
Sore eyes can start from a range of causes, such as
using smartphones, computers or gaming for a long time, driving or
reading for a long time, focusing your eyes to see clearly in poor
lighting, being tired or stressed, bright lights, not wearing your
glasses or wearing unsuitable glasses and medical issues. Long periods
of concentration while looking at a digital screen or printed page may
cause you to blink less, leading to dry eyes and soreness. Exerting
effort to see clearly can tire out your eye muscles and also
contribute to sore eyes developing, according to Health Direct.
#### Can Allergies Trigger Sore Eyes?
Yes, allergies may trigger sore eyes. Individuals with allergies may experience sore eyes in response
to present allergens in their environments, and present with sore eyes, itchiness, redness, swelling, watery
eyes and light sensitivity as a result of the histamine that is
produced by the body as a defence mechanism.
## What are the Common Signs of Sore Eyes?
The common signs of sore eyes may include a
sharp sensation, aching or throbbing. The common signs
of sore eyes are listed below.
* Sharp Sensation: A
common sign of sore eyes may include a sharp sensation in the eyes,
which can often come about when debris or an eyelash gets into the
eye.
* Aching: Aching can be
a common sign of sore eyes and may be described as a dull or
pressure-like sensation, which may stem from conditions such as eye
strain or sinus problems.
* Throbbing: A
throbbing type of eye pain may be described as a pulsating or beating
sensation and can be caused by common conditions such as eye strain
from too much screen time or concentration over a long period of time.
### Why do Eyes Become Red and Painful?
Eyes can become red and painful
during certain eye conditions due to the consequential
inflammation, irritation and/or infection. Pain and redness can arise as a result of many conditions, such as
corneal abrasions, infections, allergies, blepharitis or inflammatory
conditions. The intensity of pain and/or redness will likely depend on
the severity of one's condition. The small blood vessels in the eye
swell up, causing the red appearance of the eye.
### What is the Fastest Way to Soothe Sore Eyes?
There is
no one way that will soothe sore eyes fast, as the painful
experience of sore eyes likely differs between individuals. However, a cold compress can be applied depending on the nature of
the pain and the initial cause. It is generally advised to see an
optometrist so you can get a professional diagnosis, and treatment can
be determined if needed.
#### How Can You Reduce Sore Eyes With Eye Drops?
You may be able to
reduce sore eyes with eye drops depending on the cause of the
sore eyes.
Lubricating
[eye drops](https://www.oscarwylee.com.au/glasses/eye/types-of-eye-drops)
may provide relief for people with sore eyes, especially if the
discomfort is caused by allergies, inflammation or crying. According
to Healthline, lubricating eye drops are also known as artificial
tears and moisturise the eyes by adding elements to the eyes that
exist in tears.
#### Can Cold Compresses Calm Eye Irritation?
Yes, cold compresses may be able to calm eye irritation, depending
on the cause.
A cold compress may provide some temporary relief by helping the
blood vessels shrink, reducing
[irritation](https://www.oscarwylee.com.au/glasses/eye/irritation-causes), inflammation, swelling and/or redness. While a cold compress may aid with
alleviating symptoms, this may only be a temporary fix, and as
generally advised, you should see an optometrist or medical
professional for a proper examination.
#### What Should You Avoid When You Have Sore Eyes?
You should avoid
rubbing or touching your eyes, wearing contact lenses and wearing
eye makeup when you have sore eyes to reduce the risk of causing
more pain or further irritation.
If you usually wear contact lenses or eye make-up, it may be best to
avoid wearing them until you can get your eyes checked and/or
symptoms alleviate.
#### How Does Screen Time Affect Eye Recovery?
Screen time may affect eye recovery negatively,
as it can cause you to blink less, causing dry eyes and increased
irritation or soreness.
Long hours of screen time may also require more concentration and/or
the muscles may need to work more, which can cause eye strain. It
may be advisable to lessen screen time while your eyes are still
recovering to give them optimal rest.
#### Can Rubbing Your Eyes Make Symptoms Worse?
Yes, rubbing your eyes can make symptoms worse.
Rubbing your eyes can worsen symptoms as it can further spread
any debris or irritants that are in your eye and transfer any
germs from your hands to your eye.
It may also disrupt the epithelium layer of the cornea and
eventually harm the cornea if you rub your eyes frequently.
#### How Can You Prevent Sore Eyes Naturally?
You may prevent sore eyes naturally, depending on the cause of this
eye condition. Sore eyes caused by eye strain and fatigue may be
prevented by
taking regular breaks to let the eyes rest. If it
is caused by a stye,
practising good facial hygiene may prevent the
infection from forming.
#### How do Prescription Glasses Protect Your Eyes From Strain?
Prescription glasses can protect your eyes from strain
as it helps correct vision, which prevents your eyes from having
to exert excessive effort to see objects clearly.
[Prescription glasses](https://www.oscarwylee.com.au/)
support your eyes by bending light that passes through your eye
correctly onto the retina, allowing the retina to convert this light
into signals from the optic nerve to the brain.
### What do Sore Eyes Feel Like?
Sore eyes
can feel different for different people, depending on the
cause. Some people might find sore eyes to feel like a stinging sensation.
Others may feel itchy or pain, or feel like there is a foreign body in
the eye.
#### Are There Over-the-Counter Medicines for Sore Eyes?
Yes,
there are over-the-counter medicines available for sore eyes,
including eye drops or antihistamines. It is always best to consult with a doctor or pharmacist before
taking any over-the-counter medication, as it may not be suitable
for everyone. If sore eyes have been caused by allergic reactions,
eye drops, or antihistamines may be used to help manage this
reaction and soothe sore eyes. Other eye drops, such as antibiotics
for sore eyes caused by infections, will be prescription only.
## When Should You Seek Professional Help for Sore Eyes?
It is important to seek professional help for sore eyes as soon as symptoms
arise. Whilst some cases of sore eyes may be able to be treated with more
conservative methods such as home remedies, it’s important to
understand why the eyes are sore before moving onto treatment. If sore
eyes are being caused by an infection, for example, it is important to
see your health care provider, as conservative, home remedies will not
get rid of this issue and antibiotics may be needed as
treatment.
### What are the Causes of Sore Eyes?
There is a
wide range of causes of sore eyes ranging from relatively harmless
to more serious.
Some of the common eye conditions that may cause sore eyes include
conjunctivitis, a stye, dry eyes, keratitis and blepharitis. Other
causes include excessive eye rubbing, wearing glasses with an
incorrect prescription and being hit in the eye.
### How Do Sore Eyes Spread?
Sore eyes may or may not spread, depending on what is causing the
sore eyes.
Sore eyes caused by viral or bacterial conjunctivitis for example is
highly contagious and can be spread through direct contact with an
infected person such as touching or through airborne droplets in the
respiratory tract. A person can prevent conjunctivitis from spreading
by practising good hygiene, washing their hands often, not touching
their inflamed eyes and avoiding sharing personal items such as
towels, cups, makeup, or contact lenses. Sore eyes from wearing
glasses with an incorrect prescription however, will not spread.
### What are the Tips to Prevent Sore Eyes?
Tips for preventing sore eyes change depending on the cause of this
eye condition. Sore eyes caused by eye strain and fatigue may be
prevented by taking regular breaks to let the eyes rest. If it
is caused by a stye, practising good facial hygiene may prevent
the infection from forming.
How to get rid of an eye infection?
Eye infections such as conjunctivitis, corneal ulcers and blepharitis
may be treated with antibiotics and eye drops.
#### Can Wearing Eyeglasses Prevent Sore Eyes?
Yes.
If sore eyes are caused by eye strain, eyeglasses can help to
prevent discomfort by correcting a person’s vision.
Blue light glasses may also prevent sore eyes as they help block
rays that could potentially cause discomfort and strain to your
eyes. Oscar Wylee offer’s blue light filter for an additional $80 on
a standard pair of prescription glasses.
#### Are Home Remedies Effective Treatment for Sore Eyes?
Yes and no. In some cases,
home remedies can be effective at treating sore eyes but in more
serious and persistent cases, you should seek diagnosis and
treatment for an eye care professional.
Home remedies can be a way to deal with discomfort from sore eyes by
using natural treatments but should not be the only treatment.
#### Does Having Sore Eyes Mean You Need Glasses?
Not necessarily,
sore eyes may be caused by eye strain due to an uncorrected
refractive error such as myopia or hyperopia. Prescription glasses can be used to treat this specific
condition. Common symptoms that indicate you may need glasses
include blurry vision and trouble with near tasks such as reading or
writing.
#### Can Eye Drops Reduce Sore Eyes?
Yes,
certain types of eye drops can reduce sore eyes depending on the
cause of the sore eyes.
Lubricating eye drops may provide relief for people with sore eyes
especially if the discomfort is caused by allergies, inflammation or
crying. According to the American Academy of Ophthalmology,
lubricating eye drops are also known as artificial tears moisturise
the eyes by adding elements to the eyes that exist in tears.
#### Can You Cure a Sore Eye with Ice or Heat?
You will not be able to treat or cure a sore eye with ice or heat, in
the same way you may use these things to help treat an injury to
other parts of the body. A person may use warm or cold compresses, however, to help
soothe sore eyes.
### What are the Types of Sore Eyes?
There are no particular types of sore eyes, but different types of conditions
may cause sore eyes. The types of conditions that may cause sore eyes include allergies,
conjunctivitis, blepharitis, stye and sinusitis. The types of conditions that may cause sore eyes are listed
below.
* Allergies: Allergies occur when a
person’s immune system responds to substances that are not generally
harmful to other people. Allergies can cause the eyes to become
inflamed, itchy or sore in response to this immune system response.
* Conjunctivitis: Conjunctivitis is an inflammation of the conjunctiva, or the
white part of your eye. Conjunctivitis can cause swelling,
itchiness and pain in the eye, which may lead to soreness.
* Blepharitis:
Blepharitis refers to inflammation of the eyelid. This
inflammation may cause the eyes to feel sore.
* Stye:
A stye refers to a lump on the eyelid, often caused by an inflamed
or infected oil gland. Styes are red and swollen and can lead to
sore eyes.
* Sinusitis:
Sinusitis refers to the inflammation of the tissues in the
sinuses. Sinusitis can cause sore eyes as the sinuses are around
the eye area, and inflammation may cause pressure or pain.
#### Should You Wear Sunglasses for Sore Eyes?
If sore eyes are accompanied by light sensitivity, then wearing
sunglasses may be helpful. Light sensitivity refers to the eyes becoming overly sensitive
to light, like the sun. Conditions such as conjunctivitis or
blepharitis may cause increased light sensitivity. If the eyes are
feeling sensitive to light, then sunglasses when outside may help. It is important to seek medical attention for light sensitivity,
as this can be a symptom of a more serious issue.
Read Corneal Disease: Types, Symptoms, Causes, and Treatment in other
Oscar Wylee regions and their languages.
Australia
[Australia](https://www.oscarwylee.com.au/glasses/eye/sore/remedies)
[New Zealand](https://www.oscarwylee.co.nz/glasses/eye/sore/remedies)
[Canada](https://oscarwylee.ca/glasses/eye/sore/remedies)
[Canadian French](https://oscarwylee.ca/glasses/eye/sore/remedies)
Major health funds accepted in-store
Your health fund may help cover some of the cost of your Oscar Wylee
eye test or new frames.
[Discover Health Funds](https://www.oscarwylee.com.au/health-funds.html)
Need to have your eyes tested?
We recommend that everyone should have an eye test with an optometrist
at least once every 2 years.
[Book an eye test](https://www.oscarwylee.com.au/booking)