# Source: https://www.oscarwylee.com.au/glasses/eye/low-vision

# Low Vision: What Causes Bad Eyesight?
Updated on March 12th, 2025
Published on May 31st, 2024
Australia
[Australia](https://www.oscarwylee.com.au/glasses/eye/low-vision)
[Canada](https://oscarwylee.ca/glasses/eye/low-vision)
[Canadian French](https://oscarwylee.ca/fr/glasses/eye/low-vision)
Low vision is a type of vision problem that makes it difficult to perform everyday
activities such as reading, driving and telling colours apart. Low vision can be caused by many different eye conditions such as
cataracts, age-related macular degeneration, diabetic retinopathy and
glaucoma which can lead to vision loss if left untreated. The four common
types of low vision are central vision loss, peripheral vision loss, night
blindness and blurry vision. Treatments for low vision include low vision
aids, practical training and emotional support. Keep reading to learn what
causes poor eyesight and how low vision is diagnosed.
How’s Your Vision?
If you experience any changes in your vision, book an eye test with an
Oscar Wylee optometrist.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Definition](#definition) [Causes](#causes)
[Diagnosis](#diagnosis) [Treatments](#treatments)
## What Does Low Vision Mean?
Low vision is a term used to describe people who cannot or find it hard to do
everyday activities due to impaired vision caused by certain [eye problems](https://www.oscarwylee.com.au/glasses/eye/common-problems)
and diseases. Low vision refers to vision loss that cannot be fixed
through corrective devices such as glasses or contact lenses. Low
vision can affect a person’s daily life, making driving or recognising
faces difficult. According to Vision Australia, a person with low
vision will still have a degree of useful sight but glasses are no
longer enough to make everyday tasks possible, they will need to use
other devices or technology.
## What Causes Low Vision?
Low vision is most commonly caused by certain eye diseases or
conditions that affect a person's vision. The causes of low vision
include cataracts, age-related macular degeneration, diabetic retinopathy and
glaucoma. These eye and vision problems and their definitions are listed
below.
* Cataracts:
Cataracts is an eye condition that most commonly affects older
people due to natural changes in the eye that occur due to ageing. A
cataract is a clouding of the lens that interferes with light
entering the eye and focusing on the retina, which can lead to low
vision. Cataracts is often treated with surgery to remove and
replace the affected lens.
* Age-related macular degeneration:
Age-related macular degeneration is an eye disease that causes a
loss of central vision caused by damage to the cells in the macular.
Age-related macular degeneration can also cause vision issues such
as blurriness and a dark patch in vision and can make straight lines
appear wavy.
* Diabetic retinopathy:
Diabetic retinopathy is a complication of diabetes where the small
blood vessels in the retina located at the back of the eye are
damaged, leading to low vision. Diabetic retinopathy can lead to
blindness if left untreated or poorly managed.
* Glaucoma:
Glaucoma is defined as a group of eye conditions that cause vision
loss due to optic nerve damage. Low vision caused by glaucoma can
lead to issues with glare, colour contrast and visual acuity, making
it hard to see and possibly impacting daily life.
### Can Low Vision Lead to Vision Loss?
Low vision does not specifically lead to vision loss, however, many eye conditions that cause low vision can also lead to vision
loss if left untreated.
The eye conditions that can lead to vision loss include cataracts,
diabetic retinopathy, glaucoma and macular degeneration. In many
cases, vision loss can be prevented with early diagnosis and proper
treatment which is why eye tests are extremely important.
### Is Blurry Vision Caused by Refractive Errors?
Yes, one of the main causes of blurry vision is refractive errors.
While refractive errors are not a common cause of low vision, they
can be severe enough to cause visual impairment. Refractive errors
are a type of vision issue that occurs when the shape of the eye
stops light from focusing correctly on the retina. This could mean
that light entering the eye hits before or behind the retina. Types
of refractive errors include hyperopia (farsightedness), myopia
(nearsightedness), astigmatism and presbyopia. [Blurred vision](https://www.oscarwylee.com.au/glasses/eye/blurred-vision)
can also be caused by cataracts, glaucoma, eye injuries and dry
eyes.
Find Your Nearest Store
Visit an Oscar Wylee store near you to experience excellent eye care
and eyewear services.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
## How is Low Vision Diagnosed?
Low vision is diagnosed in an eye test performed by an optometrist.
According to the National Eye Institute, an optometrist will examine a patient’s vision which will involve asking them to read
letters far away and up close and will also check a patient’s central
and peripheral vision. The optometrist may also dilate the patient's pupils to perform a
dilated [eye test](https://www.oscarwylee.com.au/glasses/eye/test-glossary)
to check for certain eye problems that may cause low vision such as
glaucoma and cataracts. If you notice any changes in your vision, it
is important to book an eye test with an optometrist so they can
assess the health of your eyes.
### What Does 20/70 Vision Mean?
A person with 20/70 vision means that what they can read clearly at
20 feet, or 6 metres away, can be read by a person with average
vision (20/20 vision) at 70 feet (21 metres) away. 20/70 vision
is
a measurement of visual acuity which is the sharpness and clarity of
a person’s eyesight, identified in an eye test. According to the American Foundation
for the Blind, a person with a visual acuity of 20/70 or poorer is
considered to have low vision if vision cannot be improved with
regular corrective devices such as glasses or contact lenses.
#### Can 20/70 Vision Be Corrected?
20/70 vision can be corrected, however it depends on the cause of
why the person is unable to read 20/70. For example, if a person
is nearsighted, then their vision can be corrected simply with
glasses. If the vision is reduced to 20/70 due to macular
degeneration, then it cannot be corrected as glasses cannot repair
the degeneration and damage to the macula.
## What are Treatments for Low Vision?
Treatments for low vision will often be prescribed by eye care
professionals who specialise in low vision to provide a personal
treatment plan based on the patient’s condition and lifestyle needs.
The treatments for low vision involve vision rehabilitation in the form of low vision aids and practical
training.
The effects of low vision can also take a mental toll which is why emotional support
is also suggested as a form of treatment. The treatments for low
vision and their definitions are listed below.
* Low vision aids:
Low vision aids are used to help a person live independently and
maximise their vision. According to the Cleveland Clinic, low vision
aids may include optical magnifiers or telescopes, large print
products, screen readers, electronic magnifiers and audio reading
technology.
* Practical training: Practical training can be beneficial for people with low vision and
may involve occupational therapy, a mobility specialist to teach the
person how to get around and special vocation or education
services.
* Emotional support:
Emotional support can be very important for people with low vision.
According to Vision Australia, emotional support for low vision
involves learning how to cope with their vision, regaining
independence and teaching the person how to be their own
advocate.
### What Does Low Vision Look Like?
There are different types of low vision which can depend on the eye condition or disease causing the vision
impairment and can look different for each person. The four common types of low vision, according to the National Eye
Institute, are central vision loss, peripheral vision loss, night
blindness and blurry or [distorted vision.](https://www.oscarwylee.com.au/glasses/eye/distorted-vision)
#### Can Glasses Help Impaired Vision?
Yes, in some cases glasses can help impaired vision although they may
not be able to provide full correction and restore clear
vision.
According to All About Vision, impaired vision is commonly used to
describe vision that is reduced to the extent that it is unable to
be corrected to a normal level. The definition of impaired vision
and low vision can vary depending on the eye care professional as
some use them interchangeably while others consider them as
different vision problems. While regular glasses are often
ineffective at helping with low vision, optical magnifiers can be
useful.
#### Is 20/50 Vision Bad?
Vision is not described as bad or good, it is simply measured to
determine whether the person requires corrective devices or not.
In the case of 20/50 vision, it is not considered bad but rather below average,
the average being 20/20 vision.
A person with 20/50 vision can read clearly at 20 feet (6 metres)
away what a person with average vision can read clearly at 50 feet
(15 metres) away.
Read Low Vision: What Causes Bad Eyesight? in other Oscar Wylee
regions and their languages.
Australia
[Australia](https://www.oscarwylee.com.au/glasses/eye/low-vision)
[Canada](https://oscarwylee.ca/glasses/eye/low-vision)
[Canadian French](https://oscarwylee.ca/fr/glasses/eye/low-vision)
Do You Need Your Eyes Tested?
Book an appointment with an Oscar Wylee optometrist to have your eye
health and vision assessed.
[Book an eye test](https://www.oscarwylee.com.au/booking)
All Major Health Funds Accepted
Visit our team in-store for a full quote and advice on how you can use
your health fund for some of Oscar Wylee’s eye care services.
[Discover Health Funds](https://www.oscarwylee.com.au/health-funds.html)