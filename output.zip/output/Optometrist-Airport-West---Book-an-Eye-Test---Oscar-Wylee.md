# Source: https://www.oscarwylee.com.au/locations/optometrist-airport-west.html

# Optometrist Airport West
Westfield Ground Level, Shop 5729-35 Louis StreetAirport West VIC 3042
* Opposite Kmart
Opening hours
Monday9:00am - 5:30pm
Tuesday9:00am - 5:30pm
Wednesday9:00am - 5:30pm
Thursday9:00am - 9:00pm
Friday9:00am - 9:00pm
Saturday9:00am - 5:00pm
Sunday10:00am - 5:00pm
*Store hours reflect local standard trading hours and exclude public holidays
[Visit our Airport West Google Business page for directions, reviews, and updates.](https://g.page/r/CSQh9i7gwKA7EBM)
Book Appointment
[Call us: (03) 8597 2303](tel:(03) 8597 2303)
[Leave a Review!](https://g.page/r/CSQh9i7gwKA7EBM/review)
Our Reviews
dimi papantoniou
2 days ago
Thomas Nehrmann
2 days ago
A big thank you to the guys at Oscar Wylee in Airport West. I had managed to break the hinge of my g...lasses. They managed to replace my glasses. Professional, supportive and friendly! 10/10 points!
See more
Vince Mammone
2 weeks ago
Super helpful
Sajeer Aslam
3 weeks ago
Mary Lawton
3 weeks ago
I was impressed with the thorough examination with all information about my eye test results explain...ed thoroughly and professionally.  From customer service to testing I recommend your service as outstanding
See more
Tanya Guccione
3 weeks ago
Always very helpful and friendly the team fit me in right away which I really appreciated
Alaa Salim
1 month ago
Rukshana Rifai
1 month ago
Great to know about your eye. The Optomeris  was excellent who took her time and examined very caref...ully. Oscar Eylee has elegant glass and lots of choices. I will get one in the future.
See more
Ray
1 month ago
Staff were helpful and friendly,
Mengxin Wei who was the Optometrist and she was caring and knowledg...eable.
I was fit in at short notice  and my issues diagnosed quickly
thanks
See more
Robyn
1 month ago
I found the staff good at their roles,  very knowledgeable and helpful.
Scarlett Annie
1 month ago
Providing professional advice - with all relevant details.
In a caring and patience manner.
Loleta Leha
1 month ago
Pun
2 months ago
Came in to pick up my new glasses and had a great experience. Vick provided amazing customer service... and even took the time to tighten my old Oscar Wylee glasses as well. He stayed back to help us. Really appreciate the excellent service.Thank you, Vick!
See more
Barry Digby
2 months ago
georgina whitaker
2 months ago
Time taken by optometrist, Jen who was friendly, professional and thorough
Shane Collings
2 months ago
Really great staff very helpful and friendly
gabz027
2 months ago
Very good experience with the staff here doing eye tests. I learnt some good things and they were gr...eat with getting my script
See more
Suchinthara S.
3 months ago
The staff is very lovely. Great service.
Edward Goodwin
3 months ago
Excellent service from Jemma, including immediate attention in arranging a referral to a specialist ...for further treatment. I highly recommend Jemma's service.
See more
Rosie Maddicks
3 months ago
fantastic  service by the manager and optomitrist
Elizabeth White
3 months ago
My experience brought back my faith In this company.
They explained things to me better, they took t...he time to make sure understood the result.
I got in very quickly and felt respected.  Thank you.
See more
Henry Fus
3 months ago
Very good service and prodacts
Fiona Minnala
3 months ago
Great customer service by the Oscar Wylie team at airport west. The professionalism, friendliest and... ease of appointment were exceptional
See more
Belinda Small
3 months ago
Although I’m disappointed that my 10-year-old son has astigmatism, I honestly wish I had taken him f...or an eye check earlier. Eye health and regular check-ups are so important.
In saying that, the care we received from this optometrist was truly exceptional. The optometrist spoke to my son with so much kindness, sensitivity and reassurance during a really emotional appointment for him. The staff helping him choose glasses were also incredibly patient, encouraging and caring, which made such a difference to his confidence.
And it wasn’t just with children — they were equally wonderful with me too. Professional, warm and genuinely compassionate from start to finish. Very grateful for the experience and highly recommend.
See more
Sama
3 months ago
Matthew Keane
3 months ago
service was great , very nice staff and helpful.
Charlotte Maxwell
3 months ago
"I had a great experience at Oscar Wylee for my eye appointment. The staff were friendly and profess...ional, the optometrist explained everything clearly, and the process was smooth from start to finish. I felt well looked after and would happily recommend their service."
See more
Tony Parevski
4 months ago
Anth Nekich
4 months ago
Leanne phung
4 months ago
The reception staff were friendly and provided excellent service.  The optometrist was very professi...onal and explained things very clearly
See more
Paula Morgado
4 months ago
had a great experience super helpful staff :)
sandra reis
4 months ago
Great staff, very helpful, explained everything, very polite
Jess C
4 months ago
The staff there were great. Easy to talk to and gave clear instructions. Being hesitant in getting g...lasses for the first time they made it really easy with no pressure.
See more
Mick Taylor
4 months ago
Staff were great, easy to talk to and very helpful.
Highly recommend
Connie Mifsud
5 months ago
Very friendly staff, also very helpful and efficient.
Helen Ciampa
5 months ago
My experience was very positive, professional and efficient. The optician fully explained the proces...s and I left with two stylish glasses that are not only functional but very affordable given I wear multifocal glasses.
See more
carmel bianco
5 months ago
Fantastic service  great experience
Michelle Cummings
5 months ago
Lovely experience from front desk to the optometrist Tim. Great advice, clear explanations and excep...tional customer service.
See more
Tony Freeman
5 months ago
Staff are friendly and helpful
A great experience and knowledgeable staff
Elissa Stephens
6 months ago
Staff professional and super friendly! Great experience!
Shamsherali Datoo (Joe)
6 months ago
The optometrist was quite thorough and took a detailed exam of my eyes, post cataract. She even took... me through my concerns and gave me sound advice, something not expected. Keep it up!
See more
Sarah Sumner
7 months ago
Terrific overall first-time experience at Oscar Wylee. I booked in for an eye test after viewing the...ir range of beautiful glasses, and am not just extremely happy with my new glasses but the overall service received is incomparable.
I have worn glasses since early childhood and am now 40, and can confirm that the eye examination was one of the most thorough, professional and informative examinations I have had. I felt comfortable to ask questions, the optometrist was very friendly, professional, patient and really took the time to thoroughly understand my history and explain the findings of each test.
The store is organised well and found all of the staff to be helpful, friendly and professional.
Highly recommend.
See more
Laura Di Maggio
7 months ago
I had a wonderful experience, customer service was amazing so thanks Dutch and Jenna was also lovely... to deal with.
I can't wait to pick up my new glasses.
See more
George Loulakis
8 months ago
very friendly and courteous staff
Yaneth Torres
8 months ago
Was amazing the service and I really loved my glasses
Paul Pascuzzi
8 months ago
I had a wonderful experience at Oscar Wylee in Airport West. The service was outstanding, and I espe...cially want to thank Dutch for being so friendly, professional, and genuinely helpful. He took the time to explain everything clearly and made the whole process easy and enjoyable. It’s refreshing to receive such warm and attentive customer service. I highly recommend this store and will definitely be returning
See more
Diane Mottershead
8 months ago
Anjula Samaratunga
8 months ago
Ayra Ignacio
9 months ago
Went out to their Airport West branch and all the staff were very friendly and helpful. Had a nice a...nd pleasant experience overall. Would recommend :)
See more
Juan Paolo Ignacio
9 months ago
Not just because it’s Black Friday — I was genuinely happy with the service. Everyone was incredibly... friendly and approachable. They explained all the options clearly and helped us choose what was best for us. Plus, they have so many beautiful frames to choose from! Overall, it was a smooth, pleasant experience and I highly recommend them.
See more
## Find an Optometrist in Airport West With Oscar Wylee
Discover our Oscar Wylee store in Airport West Westfield, located just off the Western Freeway and roughly 10 minutes from Melbourne Airport. The team at Airport West Oscar Wylee are used to styling both locals and travellers. Come in to get your bulk billed eye test today, available for valid Medicare cardholders and shop for affordable, fashion-forward frames for your prescription glasses or prescription sunglasses! Westfield Airport West offers 8 separate car parks - no time limit and free parking and is near bus stops and the Airport West Tram line. 
Due to its prime location, Airport West has the best to offer for both suburban and city life. It boasts many coffee shops and shopping essentials, such as Target and Kmart, all near Melbourne Airport. There is a Village Cinema as well. Why not treat yourself once you’re done getting your prescriptions renewed with our Airport West optometrist? For those who live in the area, Oscar Wylee optometrists nearest to you include Oscar Wylee Broadmeadows and Oscar Wylee Keilor Central. Come in and see the team to experience some of the best eye care processes in Australia.        
Meet Our Team
* Optometrist
Bachelor of Vision Science
Masters of Optometry
* Store Manager
Our Services
* Bulk Billed Eye Examinations
* Professional Frame Styling
* Frame Adjustments and Repairs
* Visual Fields Testing
* Digital Retinal Scanning
Show All
## Find an Optometrist in Airport West, Melbourne for an Eye Health Test
Find an optometrist in Airport West in Victoria’s capital city, Melbourne, if you need an eye health test. At Oscar Wylee Airport West, we have a dedicated team of retail staff, an optometrist and an optical dispenser. While we do not have an eye doctor in-store, a patient can be referred to one if needed. While at Oscar Wylee Airport West, you can browse our wide range of fashion-forward frames that have both vintage and contemporary inspiration.
An eye health test in Airport West, Melbourne, will involve assessing a patient’s vision and also checking eye health for any signs of eye diseases. Oscar Wylee Airport West offers bulk billed eye tests for eligible Medicare cardholders. The average price range for an optometrist in Rundle Mall can vary depending on factors such as the patient’s overall health. Visit Oscar Wylee Airport West for excellent optometry services and if you need a new pair of optical glasses, prescription sunglasses or non-prescription glasses.
## How to Find an Optometrist in Airport West, Melbourne?
To find an optometrist in Airport West, Melbourne, you can take certain steps that can help make it easier for you such as searching online, assessing the store’s opening hours and finding the directions to your chosen location. The steps on how to find an optometrist in Airport West are listed below.
1. Search online using the phrase, Airport West optometrist near me. This can also be done here on the website via our locations page.
2. Click on the Oscar Wylee link, which will take you directly to our Airport West optometrist store page.
3. See the store’s opening hours and where the store is located specifically.
4. Use the Airport West Google Business page link located under store hours to see the directions on how to get to the store.
You can also find an optometrist in Airport West, Melbourne by searching the keywords optometrist near me. If you have locations enabled on your smartphone and you’re in the Airport West area, our Oscar Wylee Airport West store page should appear easily for you to click on.
### Is it Hard to Get an Eye Appointment in Airport West, Melbourne?
No, it is not hard to get an eye appointment in Airport West. You can easily book an appointment to see an Oscar Wylee optometrist in Airport West right here on this page. At Oscar Wylee we have highly qualified optometrists available for bulk billed eye appointments, which can be booked onli, over the phone, or in-store.
#### How to Compare Optometrists in Airport West to Each Other?
To compare optometrists in Airport West, you can use factors such as eye tests offered, health fund coverage, lens types and add-ons and eyewear offered. To take care of your vision and eye health, it is important to receive an eye test at least once every two years. There are different types of tests that can be performed in an eye test and not all optometrists may offer the same tests. Health funds can be used to help cover some of the cost of your frames and lenses. To find out if your health fund is accepted at an Airport West optometrist in Melbourne, visit their website. In the case of Oscar Wylee, we accept all major health funds and provide on-the-spot claims in-store. There are many different lens options available for prescription glasses such as single vision, multifocal and high index lenses. Most optometrists in Airport West will offer these lenses although it is good to make sure. There are also lens add-ons available to enhance your glasses such as anti-reflective and blue light filters. Finally, if you are looking to purchase a pair of glasses after your eye test, you can compare the different styles and colours you are interested in from the optometrists in Airport West, Melbourne. Oscar Wylee offers a wide range of frames with vintage and modern inspirations in bold colours and subtle designs.
#### How to Find an Eyeglasses Shop in Airport West, Melbourne?
To find a glasses store in Airport West, you can try to follow these simple steps including searching online, selecting a convenient location and looking at their health insurance policies.  The steps on how to find a glasses store in Airport West, Melbourne are listed below.
1. Search online using the phrase, glasses store in Airport West. This will provide you with various options for glasses stores in the whole Airport West, Melbourne area.
2. Select a glasses store that is most convenient for you to travel to.
3. Click the link to find out more information such as opening hours, exact location and directions to the glasses store in Airport West.
4. Read their health insurance policies to ensure you know what health benefits you have access to.
Our Oscar Wylee glasses store in Airport West, Melbourne offers primary eye care services such as comprehensive eye tests as well as other services performed by an optometrist and offers prescription and non-prescription eyewear.
##### Is it Possible to Purchase Prescribed Sunglasses in Airport West, Melbourne, Without Seeing an Optometrist?
Yes and no, it is possible to [purchase prescribed sunglasses](https://www.oscarwylee.com.au/sunglasses.html) in Airport West, Melbourne without seeing an optometrist if you already have a prescription that has not expired. If your prescription is expired, you can book an eye test to receive an updated or new prescription which will require you to see an optometrist. This will ensure your prescription sunglasses are appropriate for your visual needs.
## Where is the Oscar Wylee Airport West Optometrist Located in Melbourne?
The Oscar Wylee Airport West optometrist is located in Westfield Airport West, approximately 10 minutes from the Melbourne Airport. This expansive shopping centre is found just off the Western Freeway on Louis St.
### What is the Phone Number of Oscar Wylee Airport West Optometrist Store?
The Oscar Wylee Airport West optometrist store phone number is (03) 8597 2303. You can contact the Oscar Wylee Airport West store between the hours of 9 am and 5:30 pm from Monday to Wednesday, 9 am and 9 pm on Thursdays and Fridays, 9 am and 5 pm on Saturdays and 10 am and 5 pm on Sundays.
### What are the Reviews for Oscar Wylee Airport West Optometrist in Melbourne?
The many reviews for Oscar Wylee Airport West optometrist in Melbourne, left by our various customers can be found here on the website and online when you search for Oscar Wylee Airport West optometrist. The reviews for Oscar Wylee Airport West optometrist are listed below.
* Katie Miers:  Jenna the optometrist was fantastic - so thorough and professional. I felt like I was in very good hands. She asked a number of times if I had any questions. Highly recommend.
* Denise Sutton:  My experience was 100% exceptional. I have usually gone to OPSM but I have now decided after such efficient competent and friendly service, Oscar Wylee is my place for specs.
* Tammy Oren:  Incredible service, great selection of eyewear and the best price. Will definitely recommend to anyone.
* Brax Jack:  First time being at the Airport West OW. The girls are absolutely amazing!! Ty.
#### What Treatments or Eye Care Processes are Done in the Oscar Wylee Airport West Optometrist Location?
The treatments or eye care processes done in the Oscar Wylee Airport West optometrist Melbourne location include a tonometry test, a digital photograph, a slit lamp exam and a refraction test. Additional tests that may also be performed can include a visual field test and a dilated fundus exam. The treatments or eye-care processes that are done in the Oscar Wylee Airport West optometrist Melbourne location are listed below.
* A Tonometry Test: An optometrist or optical dispenser will conduct a tonometry test which involves the use of a machine that will release small puffs of air into your eyes. This will assist with measuring pressure in the eye.
* A Digital Photograph: An optometrist or optical dispenser may take a digital photograph of your eye which can be kept on record to use in future appointments to evaluate any changes to your eye.
* Slit Lamp Test: A slit lamp test can be used to evaluate your eye health, by examining your cornea and iris which are the anterior and posterior of the eye.
* Refraction Test: During a refraction test, an optometrist will have you view an image through different lenses and ask you to confirm which helps you see the image clearer.
* Visual Field Test: A visual field test can assist with assessing your peripheral vision, which may be beneficial for identifying any signs of glaucoma.
* Dilated Fundus Exam: A dilated fundus exam can help an optometrist assess your health in more detail by getting a clear view of the retina. This test is typically carried out for patients with diabetes and those who may be at risk of developing retinal damage.
## How Many Optometrists Exist in Airport West, Melbourne?
There are many optometrists that exist in Airport West, Melbourne to provide eye tests and glasses, including Oscar Wylee. The number of optometrists available in an area will typically depend on the population. At Oscar Wylee Airport West, we offer excellent optometry services including eye tests performed by skilled optometrists using high-quality equipment. We also have a wide range of fashion-forward frames that customers can browse in a large selection of sizes and colours. If you’re looking for an optometrist in Airport West, choose Oscar Wylee and we will take care of your optometry and eyewear needs.
### What are the Other Closest Optometrist Locations to Airport West, Melbourne in Australia?
The other closest Oscar Wylee optometrist locations to Airport West in Australia are Broadmeadows, Keilor Downs, Moonee Ponds and Highpoint. The locations and their distance from Airport West are listed below.
* Broadmeadows:  Broadmeadows is close to Airport West, around 7 km. The [Oscar Wylee Broadmeadows](https://www.oscarwylee.com.au/locations/optometrist-broadmeadows.html) store is located in Broadmeadows Central, next to My Chemist. An Oscar Wylee optometrist in Broadmeadows can provide bulk billed eye tests and prescription updates.
* Keilor Downs:  Keilor Downs is close to Airport West, around 10-11 km. The [Oscar Wylee Keilor Downs](https://www.oscarwylee.com.au/locations/optometrist-keilor-downs.html) store is located in the Keilor Central Shopping Centre, near Coles. If you need fundamental eye care services such as vision and eye health checks, you can visit our Keilor Downs store.
* Moonee Ponds:  Moonee Ponds is close to Airport West, around 9 km. The [Oscar Wylee Moonee Ponds](https://www.oscarwylee.com.au/locations/optometrist-moonee-ponds.html) store is located in the Moonee Ponds Central Shopping Centre, opposite Witchery. The team at Moonee Ponds Oscar Wylee offer bulk billed eye tests and professional frame styling.
* Highpoint:  Highpoint is close to Airport West, around 12 km. The [Oscar Wylee Highpoint](https://www.oscarwylee.com.au/locations/optometrist-moonee-ponds.html) store is located in Maribyrnong’s Highpoint Shopping Centre, near OPSM. Oscar Wylee Highpoint offers excellent optometry services including visual field testing and prescriptions.
### Eye Tests in Oscar Wylee Optometrist Airport West
You don’t have to go to an optometrist’s office in order to have your annual eye test done. Just stop by our Oscar Wylee Airport West eyeglasses shop, where we have trained optometrists performing bulk billed eye tests for eligible Medicare cardholders. Those without one have to pay a fee. Have your prescription updated, eye health checked for certain eye diseases, and order a new pair of glasses, all on the same day.
### Oscar Wylee Accepts Major Health Funds
Here at Oscar Wylee Airport West, we can process your health fund claim in-store with a valid health fund card. We also provide on-the-spot quotes for our frames and lenses which is why it is important that you bring your health fund card to your next appointment. Visit Oscar Wylee Airport West, to get your eyewear at an affordable, competitive price.
### Fashion-Forward Styles at Affordable Prices
Oscar Wylee Airport West is committed to providing you with stylish frames at affordable prices. We’re offering fashion-forward frames with both local and international inspirations, designed to appeal to all personal styles. Oscar Wylee’s prescription lenses can be customised to fit your needs including multifocal lenses or a blue light filter. Our experts at Oscar Wylee Airport West are ready and able to help you with any of your eyesight requirements.
Book Appointment
[Call us: (03) 8597 2303](tel:(03) 8597 2303)
[Leave a Review!](https://g.page/r/CSQh9i7gwKA7EBM/review)