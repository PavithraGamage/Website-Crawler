# Source: https://www.oscarwylee.com.au/serge-sunglasses.html

# Serge
1
## Frame Design of Serge Sunglasses
The frame design of Oscar Wylee’s Serge sunglasses is characterised by a classic square shape, a low nose bridge fit and an acetate frame. Serge glasses are a women's statement frame that will work for any occasion, whether the wearer wants to liven up their work style or complement an outfit for a night out.
$169    
In stock
Only %1 left
2 pairs from $199
Discount auto-applied at checkout
3 pairs from $249
Discount auto-applied at checkout
* 2 &amp; 3 Pair pricing applies to non-prescription sunglasses only. Prescription sunglasses incur additional charges.    
[Non-Prescription](https://www.oscarwylee.com.au/serge-sunglasses.html#)
Qty
Prescription
Book an eye test
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
excluding prescription lenses
## About Serge Frames
Named after the French musician, Serge Gainsbourg - this rectangular
frame channels modern of the moment shapes rather than drawing upon
vintage references. With unisex bold profile, we’re not surprised why
Serge is adored by many.
| Frame fit | Measurements |
| --- | --- |
| Wide | 53 - 20 - 145 |
These measurements mean lens width, bridge, and temple length in
millimetres (mm). They can be found on the inside of the temple arm.
If you already have a pair that you like, you can compare it to these
measurements.
### Made from Acetate
Oscar Wylee’s Serge frame is a women’s square sunglasses frame that is
perfect for those with round or oval face shapes. The Serge frame is a
sleek, widely wearable frame that can be worn every day. The main
specs of Oscar Wylee’s Serge glasses frame including
dimensions, shape, materials, lenses, nose fit and hinges
are listed below.
Filter category 2 (Dusk only) - General purpose sunglasses. Good
protection against sunglare. Good UV Protection.Not suitable for driving
in twilight, at night or under dull conditions
This frame (Dusk) comes with polarised lenses. An additional $100
will be added to your order total for prescription orders.
Filter category 3 (Chocolate Chip &amp; Denim Fade only) - General purpose
sunglasses. High protection against sunglare. Good UV Protection. Not
suitable for driving in twilight, at night or under dull conditions
This frame (Chocolate Chip &amp; Denim Fade) comes with polarised
lenses. An additional $100 will be added to your order total for
prescription orders.
Filter category 3 (Smokey Amber &amp; Brown Dapple only) - General purpose
sunglasses. High protection against sunglare. Good UV Protection. Not
suitable for driving in twilight, at night or under dull conditions
This frame (Smokey Amber &amp; Brown Dapple only) comes with tinted
lenses. An additional $30 will be added to your order total for
prescription orders.
| Serge Frame Features | Serge Frame Description | Dimensions | Shape | Materials | Lenses | Nose Fit | Hinges |
| --- | --- | --- | --- | --- | --- | --- | --- |
| The dimensions of the Serge frame are measured in millimetres (mm)
and are 53 - 20 - 145, meaning the lens width is 53 mm, the bridge
is 20 mm and the temple length is 145 mm. |
| The Serge frame is a square shape, well suited to wide faces. |
| Serge glasses are made from a material called acetate. |
| The lenses that can be used in the Serge frame are sunglass
lenses, which provide UV protection. Optical lenses are also
available for the Serge sunglass frame, however this is only
available for in-store purchases. |
| The nose fit of Serge frames is a low nose bridge fit. |
| The hinges in Serge glasses are spring hinges, which are more
flexible than other types of hinges and can extend past 90
degrees. |
Show All
### What Inspired the Frame Design of Oscar Wylee’s Serge
Glasses?
The Oscar Wylee Serge frame design was inspired by current fashion
trends as square shapes are often in fashion. A square glasses
shape is timeless meaning it remains popular throughout the
decades while other trends pass.
## What to Know About Oscar Wylee’s Serge Glasses?
There are many aspects of the Oscar Wylee Serge frames that
customers should know about, so they can decide whether this is
the right frame for them. The Serge frame is a women's
square-shaped frame. Oscar Wylee’s Serge frame is suitable for
many face shapes but particularly compatible with round and oval
face shapes. The Serge frame’s simple design means that they are
fashionable all year round. Serge glasses feature the standard
[parts of glasses](https://www.oscarwylee.com.au/glasses/eye/part-of-glasses)
such as a rim, temples, lenses, spring hinges and a low nose
bridge fit.
### What are the
Types of Temple Tips or Earpieces Included with Oscar
Wylee’s Serge Glasses?
The type of temple tips or earpieces included in Oscar Wylee’s
Serge Glasses are made from acetate, the same as the rest of the
temple and rim.
### What Type of Nose Bridge do Oscar Wylee’s Serge Glasses
Have?
The type of nose bridge included in Oscar Wylee’s Serge frame is a
low nose bridge fit.
### What Type of Nose Pads are Included with Oscar Wylee’s
Serge Glasses?
Oscar Wylee’s Serge frame does not include adjustable silicone
nose pads.
### What Type of Lenses do Oscar Wylee’s Serge Glasses
Have?
The lenses that can be used in the Serge frame are polarised
sunglass lenses, which provide UV protection. UV protection lenses
block harmful ultraviolet rays, safeguarding eyes from damage. It
comes in two filters: Filter Category 2 and Filter Category 3.
Filter Category 2 is available for Dusk. These are general purpose
sunglasses and provide good protection against sunglare. Filter
Category 3 is available for Chocolate Chip, Denim Fade, Smokey
Amber and Brown Dapple. This filter provides higher protection
against sunglare. They are not suitable for use while driving at
night. Prescription lenses are also available for the Serge
sunglass frame, in-store only.
### What Material is Used for the Rim of Oscar Wylee’s
Serge Glasses?
The material used for the rim of Oscar Wylee’s Serge glasses
frames is acetate. The rim refers to the part of a glasses frame
that holds the lenses.
### What Type of Hinges are Included with Oscar Wylee’s
Serge Glasses?
The type of hinges included with Oscar Wylee’s Serge frames are
spring hinges. These are more flexible than other types of hinges
and can extend past 90 degrees.
## What Face Types are Most Suitable for Oscar Wylee’s
Serge Glasses?
The face types that are most suitable for Oscar Wylee’s Serge
frame are round and oval face types. The Serge frame is a square
shape, meaning that it complements the structure of round and oval
faces particularly well. The Serge frames help to balance the
features of an
[oval face shape](https://www.oscarwylee.com.au/glasses/face-shapes/oval)
or a
[round face shape](https://www.oscarwylee.com.au/glasses/face-shapes/round), bringing the eyes and brows forward in a flattering way.
Although there are many
[glasses for face shapes](https://www.oscarwylee.com.au/glasses/face-shapes)
that may be considered more aesthetically suitable, it is
important that people also choose the frames that make them feel
most comfortable, and represent their personal style.
## What Size Options are Available for Oscar Wylee’s Serge
Glasses?
The size options available for Oscar Wylee’s Serge frame are a
wide frame fit across all colours.
## What Materials are Used to Create Oscar Wylee’s Serge
Glasses?
The primary material used to create the Oscar Wylee Serge frame is
acetate. Acetate, also known as cellulose acetate, is a
bioplastic, made from cotton fibres or wood pulp. At Oscar Wylee,
acetate glasses are made by adding a dye to cellulose acetate,
which is rolled into a sheet. The shape of the glasses is then cut
from this sheet.
## What’s Included
## What's Included
Each pair of glasses comes with a stylish frame case and lens cloth. We offer free shipping across Australia and 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects.
* Free Shipping for Australian Orders
* 1 Year Warranty on frames and lenses
* Scratch resistance lens coating on all prescriptions
* UV-proof coating on all prescriptions
* Stylish case and cloth
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
## Make and Materials
The frames then go through cleaning and strict quality control, and many pairs of crafting hands to be hand-assembled and polished. After your frames have gone through the production process, they are individually examined and packed before making their way to you!Also known as cellulose acetate, these frames are traditionally hand-crafted by skilled craftsmen, with each frame passing through numerous stages of production and are hand-polished to ensure a glorious lustre.
## Warranty Information
### Warranty Information
### Warranty Information
Oscar Wylee provides a 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects. We will repair or replace faulty or defective frames or lenses free of charge for warranty claims made within 1 year of the delivery. We also offer repairs or replacement for problems experienced with vision during everyday use for claims made within 30 days of delivery. If the same product has been discontinued or is no longer available, then we may offer an exchange for a similar product or a refund.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Find a Store Location](https://www.oscarwylee.com.au/locations/full-store-list.html)