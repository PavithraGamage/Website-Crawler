# Source: https://www.oscarwylee.com.au/locations/optometrist-castle-towers.html

# Optometrist Castle Hill
Castle TowersLevel 2, Shop 3256-14 Castle StreetCastle Hill NSW 2154
* Next to LEGO
Opening hours
Monday9:00am - 5:30pm
Tuesday9:00am - 5:30pm
Wednesday9:00am - 5:30pm
Thursday9:00am - 9:00pm
Friday9:00am - 5:30pm
Saturday9:00am - 5:00pm
Sunday10:00am - 5:00pm
*Store hours reflect local standard trading hours and exclude public holidays
[Visit our Castle Towers Google Business page for directions, reviews, and updates.](https://www.google.com/maps/place/Oscar+Wylee+Optometrist/@-33.730413,151.0039491,16z/data=!3m2!4b1!5s0x6b12a10b92e1afc1:0x1e54ca82bf8f59b4!4m6!3m5!1s0x6b12a10bee1f0eb9:0x7730f41b58e02672!8m2!3d-33.730413!4d151.0065294!16s%2Fg%2F11f4r1l3db)
Book Appointment
[Call us: (02) 8810 6981](tel:(02) 8810 6981)
[Leave a Review!](https://g.page/r/CXIm4Fgb9DB3EBM/review)
Our Reviews
Darren Godwin
2 weeks ago
Very nice and helpful staff at Castle Towers store
meetchii
2 weeks ago
The staff at the castle towers store were amazing gave me so much info as to how my eyes were changi...ng and how the right prescription would take the strain off my eyes  and as soon as I was sat down and had my eyes checked and and hit the right measurement on the lenses I instantly felt the strain and the pain from my eyes constantly trying to readjust disappear
Looking forward to my new glasses and frames
See more
kethmini h
3 weeks ago
Helpful receptionists, really lovely optom too
spencer bartlet
4 weeks ago
The optometrist at Oscar Wylee (Natasha) was amazing. Very thorough. I learnt more about my eyes tha...n i ever had. She took the time to explain lots about eye health.
See more
Goutham Bharadwaj
4 weeks ago
Susan Sicuro
4 weeks ago
We were at castle hill. Both of the girls that took care of us were amazing. The optometrist was so ...knowledgeable and so friendly.
See more
Valerina Pillay
1 month ago
The staff was so friendly and helpful the optometrist was really nice and patient as well
Jeanette Wade
1 month ago
Thank you Nikki I am so pleased with my replacement frames. I appreciate your excellent service. I w...ill SEE you clearly, and again! 5 stars
See more
Leanne Tassone
1 month ago
I had a fantastic experience with Oscar Wylee from start to finish. The optometrist was professional..., knowledgeable, and took the time to explain everything clearly during my eye examination. I felt genuinely cared for, and the whole process was thorough and unhurried.
The staff were friendly, welcoming, and made the experience easy and enjoyable. They also helped me choose the right frames without any pressure, and their advice was greatly appreciated.
I highly recommend Oscar Wylee to anyone looking for excellent eye care and outstanding customer service. I’ll definitely be returning for my future eye care needs. Thank you to the whole team for such a positive experience.
See more
James Lee
1 month ago
Shannon Miller
1 month ago
From the moment I walked in the Castle Towers store I was warmly greeted by staff. They clearly expl...ained what the process would be, from the initial tests to how long it would take my new glasses to arrive.
See more
Jien Tan
1 month ago
10/10 the optometrist Vivien and receptionist were really nice and made me feel welcomed and comfort...able. They were such girls girls ???? Would visit again!
See more
Buddy Lives
1 month ago
I came to Oscar Wylee for an eye test because I was recommended there, and I also checked there revi...ews online alot of happy customers.
It’s a great place to get your eyes checked honest, professional, and friendly staff. The whole experience was smooth and trustworthy. I highly recommend them for anyone looking for reliable eye care.
See more
Parisa Mesrinejad
1 month ago
Nice store with a great range of glasses. Friendly atmosphere and a professional-looking team. Highl...y recommended!
See more
Castle Towers OW
1 month ago
Omid Karami
1 month ago
From the moment I walked in, the reception team was warm, welcoming, and highly professional. The en...tire appointment was well organised, and everything ran smoothly.
The optometrist was outstanding thorough, knowledgeable, patient, and attentive throughout the entire eye examination. Every test was carried out with great care, and everything was explained clearly, which made me feel comfortable and confident throughout the process. I never felt rushed, and all of my questions were answered with patience and professionalism.
See more
Helen Giam
1 month ago
Really good experience!Lovely people and very helpful. Love their glasses
Isa L
2 months ago
After weeks of struggling with a persistent eye problem and receiving inconsistent advice from multi...ple GPs, I finally found the answer with Vivien (optometrist). Her thorough and careful examination pinpointed the issue straightaway, and the eye drops she prescribed worked exactly as needed. My eye has since healed completely.
The care here extended beyond the consultation, that the receptionist went out of her way to secure the earliest available appointment and thoughtfully rescheduled my other booking around it. That kind of attentiveness made a real difference when I was already dealing with some discomfort.
Vivien's expertise and the Castle Towers team's genuine care make this practice easy to recommend to anyone dealing with an eye concern that hasn't been resolved elsewhere.
See more
Sylvester &amp; Sylvia Siu
2 months ago
Great service and helpful with checking my eyes with PVD
Michael Teo
2 months ago
Tony Cinque
2 months ago
Excellent friendly and efficient service. Clear and precise information. Vivien was also extremely t...horough and considerate during the eye test.
See more
Jenn Dale Young
2 months ago
Tamma Tammo
2 months ago
Shah Karimian
3 months ago
Thilinee Crossman
3 months ago
Excellent service for eye test with great knowledgeable advice and information. Equally excellent se...rvice for choosing glasses. No pressure to buy, transparent and very competitive pricing. Highly recommend.
See more
Helen Russell
3 months ago
Greg Worner
3 months ago
Service was very fast,attentive and thorough. Particularly in respect of the eye tests.
There was a ...wide range of glasses to choose from, and assistance from the staff with this as well. ( Glasses not yet available for a photo).
See more
Ramski
3 months ago
Wifie Ninja
3 months ago
Sam was brilliant! Was very thorough, patient, and informative throughout the appointment. I really ...appreciated the care and attention to detail. So was the staff and the manager, Nikki. They were very helpful and polite. Thank you!
See more
Devi Moopnar
4 months ago
I went in for an eye test and the whole process was smooth and hassle-free from start to finish.. Dr... Natasha, a professional through and through  made everything easy to understand. The service by the team, 2 lovely young ladies at the counter,  were efficient, and the attention to detail ensured I got exactly what I needed. Overall, a seamless and positive experience—highly recommended Oscar Wylee Castle Towers .
See more
anna may
4 months ago
Informative and attentive optometrist and staff. They were very busy and were still helpful to every... one in store.
See more
Junan Ma
5 months ago
very good service
jp8684
7 months ago
Yoong yum
7 months ago
The service and eye tests went great. I book appointments for my son and I, the optometrist Vivien w...as patient and explained thoroughly, was friendly and professional.
See more
Christina Yu
8 months ago
Vivian &amp; Nikki are great customer service. I will highly recommend them to my friends .
Priya
8 months ago
Friendly staff, on time and quick.
Sharon Parnell
8 months ago
Grace at Oscar Wylee was amazing! Super friendly, helpful, and made the whole experience so easy. De...finitely went above and beyond, highly recommend!
See more
William Will
8 months ago
Paridhi Nama
8 months ago
Harsha
8 months ago
Vivian is very professional and detailed Optometrist. Great customer service at the front desk as we...ll, assisted me with the glasses.
See more
BamraFamily
8 months ago
The entire experience was smooth &amp; very professional. The staff were very friendly and helpful.
Joseph Hallal
8 months ago
Vivan is wonderful Optometrist, she goes the extra mile in checking and making sure and genuinely ca...res about her patients
See more
Michael Burnyeat
8 months ago
John Bailey
8 months ago
Wonderful and considerate service eager to answer every question. My eyesight had not determined rep...lacement glasses.
See more
Peter Shirley
8 months ago
A good experience. I was greeted and didn't have to wait for my appointment. The optometrist was cou...rteous, professional, and easy to talk to. She explained the whole process clearly and was thorough with the exam. She went over my results so I could understand my options. Overall, I left feeling really happy.
See more
Chantal Kalunga
9 months ago
Great customer service
Malcolm Souter
9 months ago
I was very happy with the lady who did my eye test. She was happy to answer any question I asked her... and was very open about each test and my results.
See more
Arun Ravi
9 months ago
Scheduling appointments through online is very convenient and works like a treat. optometrist at Cas...tle hill store was very knowledgeable and friendly. The prescription is emailed to u promptly. The whole eye test and pricing of frames &amp; lens are affordable. Overall a great experience!
See more
Clare Salt
9 months ago
Brilliant staff, gave me great information about the glasses! Nice, quick and easy eye test and grea...t selection of frames. Would definitely recommend.
See more
Anna Clark
9 months ago
Lovely staff, professional, helpful, quick service. Highly recommended.
## Find an Optometrist in Castle Hill with Oscar Wylee
Located in the bustling Castle Hill district, Oscar Wylee Castle Towers can be found at the Castle Towers Shopping Centre. Located next to the Lego store on Level 2, Oscar Wylee Castle Towers’ optometrists are available to provide Medicare bulk billed eye and vision tests, where staff can help you shop for affordable and stylish frames including prescription sunglasses! To make it to your appointment with Oscar Wylee Castle Towers, why not take the metro to Castle Hill station, just across from the centre, or drive into the centre with up to 3 hours of free parking available. 
Make the most of your trip by exploring the famed Castle Towers Shopping Centre. With over 300 retail stores with all the latest fashion trends to check out and also a range of delicious restaurants and cafes. If you live in the Baulkham Hills, Cherrybrook or Norwest areas, Oscar Wylee Castle Towers is the go-to for some of the best optometrist services in North-West Sydney.         
Meet Our Team
* Optometrist
* Store Manager
Our Services
* Bulk Billed Eye Examinations
* Professional Frame Styling
* Frame Adjustments and Repairs
* Visual Fields Testing
* Digital Retinal Scanning
* $25 consultation fee for RMS forms
* Diabetic screenings
* Children's testing is available depending on age - Please contact us before booking
Show All
## Find an Optometrist in Castle Towers, Greater Western Sydney for an Eye Health Test
An optometrist in Castle Towers Shopping Centre located in Castle Hill, Greater Western Sydney can provide eye care services for prescription sunglasses and non-prescription sunglasses. Our optometrists care about eye health so you can count on our team for high-quality eye health tests in Castle Towers in Castle Hill, Greater Western Sydney. Eye tests are important for maintaining vision health and looking out for eye diseases. So we recommend choosing Oscar Wylee to help you keep up to date with regular eye tests, which you can get at a bulk billed price thanks to the Australian Medicare System. When you visit an Oscar Wylee glasses store, you can expect great care and assistance from our optical dispenser. If the optometrist detects any signs of a more complex issue, you may likely be referred to an eye doctor.
The procedure of an eye test likely includes a few different tests in order to evaluate the health of different parts of the eye. The average price for an optometrist in Castle Hill may vary due to the health of your vision, the facility they operate in and the wider location.
## How to Find an Optometrist in Castle Towers in Castle Hill, Greater Western Sydney?
To find an optometrist in Castle Towers Shopping Centre in Castle Hill, Greater Western Sydney, you can take certain steps that can help make it easier for you such as searching online, assessing the store’s opening hours and finding the directions to your chosen location. The steps on how to find an optometrist in Castle Towers located in Castle Hill are listed below.
1. Search online using the phrase, Castle Towers optometrist near me. This can also be done here on the website via our locations page.
2. Click on the Oscar Wylee link, which will take you directly to our Castle Towers optometrist in Castle Hill store page.
3. See the store’s opening hours and where the store is located specifically.
4. Use the Castle Towers Google Business page link located under store hours to see the directions on how to get to the store.
You can also find an optometrist in Castle Towers by searching the keywords optometrist near me. If you have locations enabled on your smartphone and you’re in the Castle Hill area, our Castle Towers store page should appear easily for you to click on.
### Is it Hard to Get an Eye Appointment in Castle Towers in Castle Hill, Greater Western Sydney?
No, it is not hard to get an eye appointment in the Castle Towers Shopping Centre in Castle Hill. You can easily book an appointment to see an Oscar Wylee optometrist in Castle Towers right here on this page. At Oscar Wylee we have highly qualified optometrists available for bulk billed eye appointments, which can be booked online or in-store.
#### How to Compare Optometrists in Castle Towers to Each Other?
To compare optometrists in the Castle Towers Shopping Centre located in Castle Hill, you can use factors such as eye tests offered, health fund coverage, lens types and add-ons and eyewear offered. To take care of your vision and eye health, it is important to receive an eye test at least once every two years. There are different types of tests that can be performed in an eye test and not all optometrists may offer the same tests. Health funds can be used to help cover some of the cost of your frames and lenses. To find out if your health fund is accepted at Castle Towers optometrist in Castle Hill, Greater Western Sydney, visit their website. In the case of Oscar Wylee, we accept all major health funds and provide on-the-spot claims in-store. There are many different lens options available for prescription glasses such as single vision, multifocal and high index lenses. Most optometrists in Castle Towers will offer these lenses although it is good to make sure. There are also lens add-ons available to enhance your glasses such as anti-reflective and blue light filters. Finally, if you are looking to purchase a pair of glasses after your eye test, you can compare the different styles and colours you are interested in from Castle Towers optometrists in Castle Hill, Greater Western Sydney. Oscar Wylee offers a wide range of frames with vintage and modern inspirations in bold colours and subtle designs.
#### How to Find an Eyeglasses Shop in Castle Hill, Greater Western Sydney?
To find a glasses store in Castle Hill, you can try to follow these simple steps including searching online, selecting a convenient location and looking at their health insurance policies. The steps on how to find a glasses store in Castle Hill are listed below.
1. Search online using the phrase, glasses store in Castle Hill. This will provide you with various options for eyeglasses shops in the whole Castle Hill, Greater Western Sydney area.
2. Select a glasses store that is most convenient for you to travel to.
3. Click the link to find out more information such as opening hours, exact location and directions to the glasses store in Castle Hill.
4. Read their health insurance policies to ensure you know what health benefits you have access to.
Our Oscar Wylee glasses store in Castle Hill offers primary eye care services such as comprehensive eye tests as well as other services performed by an optometrist and offers prescription and non-prescription eyewear.
##### Is it Possible to Purchase Prescribed Sunglasses in Castle Towers in Castle Hill, Greater Western Sydney Without Seeing an Optometrist?
Yes and no, it is possible to [purchase prescribed sunglasses](https://www.oscarwylee.com.au/sunglasses.html) in Castle Towers shopping centre in Castle Hill without seeing an optometrist if you already have a prescription that has not expired. If your prescription is expired, you can book an eye test to receive an updated or new prescription which will require you to see an optometrist. This will ensure your prescription sunglasses are appropriate for your visual needs.
## Where is the Oscar Wylee Castle Towers optometrist in Greater Western Sydney Located?
The Oscar Wylee Castle Towers optometrist is located in Castle Hill next to the Lego Store on Level 2 of the Castle Towers shopping centre, near David Jones. The Castle Towers shopping centre can be found on Castle St and provides a diverse retail experience for Castle Hill residents and visitors.
### What is the Phone Number of Oscar Wylee Castle Towers Optometrist Store?
The Oscar Wylee Castle Towers optometrist store phone number is (02) 8810 6981. You can contact the Oscar Wylee Castle Towers store on Monday, Tuesday, Wednesday and Friday between 9 am and 5:30 pm, on Thursday between 9 am and 9 pm, on Saturday between 9 am and 5 pm and on Sunday between 10 am and 5 pm.
### What are the Reviews for Oscar Wylee Castle Towers in Castle Hill, Greater Western Sydney?
The many reviews for Oscar Wylee Castle Towers optometrist in Castle Hill, left by our many customers can be found here on the website and online when you search for Oscar Wylee Castle Towers optometrist. The reviews for Oscar Wylee Castle Towers optometrist in Castle Hill are listed below.
* Woon Khiong Liau -  Good service.
* Hemda Lama -  Good people &amp; good service.
* Julian Gonzalez -  So helpful. Sharon and Gary took their time to help find the best solution for some broken prescription glasses. Even though they were very busy I didn’t feel rushed. Thanks so much guys.
* Matty B -  Very friendly, and all my inquiries and questions were answered with a smile. The lady who examined me for my eye test was very pleasant.
#### What Treatments or Eye Care Processes are Done in the Oscar Wylee Castle Towers in Castle Hill Optometrist Location?
The treatments or eye care processes done in the Oscar Wylee Castle Towers optometrist in Castle Hill, Greater Western Sydney location include a tonometry test, a digital photograph, a slit lamp exam and a refraction test. Additional tests that may also be performed can include a visual field test and a dilated fundus exam. The treatments or eye-care processes that are done in the Oscar Wylee Castle Tower optometrist Castle Hill, Greater Western Sydney location are listed below.
* A Tonometry Test: An optometrist or optical dispenser will conduct a tonometry test which involves the use of a machine that will release small puffs of air into your eyes. This will assist with measuring pressure in the eye.
* A Digital Photograph: An optometrist or optical dispenser may take a digital photograph of your eye which can be kept on record to use in future appointments to evaluate any changes to your eye.
* Slit Lamp Test: A slit lamp test can be used to evaluate your eye health, by examining your cornea and iris which are the anterior and posterior of the eye.
* Refraction Test: During a refraction test, an optometrist will have you view an image through different lenses and ask you to confirm which helps you see the image clearer.
* Visual Field Test: A visual field test can assist with assessing your peripheral vision, which may be beneficial for identifying any signs of glaucoma.
* Dilated Fundus Exam: A dilated fundus exam can help an optometrist assess your health in more detail by getting a clear view of the retina. This test is typically carried out for patients with diabetes and those who may be at risk of developing retinal damage.
## How Many Optometrists Exist in Castle Hill, Greater Western Sydney in Australia?
You can find many optometrists that exist in Castle Hill to provide eye tests and glasses, including Oscar Wylee. There is no confirmed number of optometrists in Castle Hill, Greater Western Sydney, which may be due to certain reasons such as the number of residents in each location and the potential demand for optometry services. At Oscar Wylee Castle Towers in Castle Hill, Greater Western Sydney, you can count on high-standard services that are catered to ensuring your optimal eye and vision health.
### What are the Other Closest Optometrist Locations to Castle Towers in Castle Hill, Greater Western Sydney in Australia?
The other closest Oscar Wylee optometrist location to Castle Towers in Castle Hill, Greater Western Sydney in Australia is Winston Hills which is just around 7-9 km between stores. The [Oscar Wylee Winston Hills](https://www.oscarwylee.com.au/locations/optometrist-winston-hills.html) store is located in the Winston Hills shopping centre on Caroline Chisholm Dr next to Terry White Pharmacy.
### Oscar Wylee Castle Towers optometrists perform bulk billed eye tests
At Oscar Wylee’s eyeglasses shop in Castle Towers Shopping Centre, you can prioritise your eye health and take care of your vision with many eye care processes available. We offer prescription updates, eye health tests to assess vision and detect certain eye diseases and you can shop through the wide selection of affordable and stylish frames. At Oscar Wylee Castle Towers, eye tests are bulk billed for eligible Medicare card holders and performed by our dedicated and experienced Oscar Wylee optometrists.
### Oscar Wylee Castle Towers accepts major health funds
At Oscar Wylee Castle Towers, our staff can process your health fund claim in-store with a valid health fund card and help answer any questions about what you’re eligible for with your private health fund. You don’t have to navigate the most challenging parts of health insurance alone – the staff at Oscar Wylee Castle Towers is dedicated to making sure you get what you need at an affordable, competitive price.
### Fashion-forward styles at affordable prices
Oscar Wylee Castle Towers is committed to helping you find the perfect pair of frames, offering modern and vintage-style glasses at an affordable cost. Our Oscar Wylee Castle Towers optometrists help to provide prescription lenses that fit any customer needs - whether it’s a blue light filter, multifocal lens, or a polarised lens for your prescription sunglasses, our experts in-store are ready to help you with any of your eyesight requirements.
Book Appointment
[Call us: (02) 8810 6981](tel:(02) 8810 6981)
[Leave a Review!](https://g.page/r/CXIm4Fgb9DB3EBM/review)