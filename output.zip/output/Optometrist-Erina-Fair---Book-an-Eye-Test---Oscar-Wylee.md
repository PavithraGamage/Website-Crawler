# Source: https://www.oscarwylee.com.au/locations/optometrist-erina-fair.html

# Optometrist Erina Fair
Erina FairLevel 1, Shop T314620-658 Terrigal DriveErina NSW 2250
* Next to Hero Sushi
Opening hours
Monday9:00am - 5:30pm
Tuesday9:00am - 5:30pm
Wednesday9:00am - 5:30pm
Thursday9:00am - 9:00pm
Friday9:00am - 5:30pm
Saturday9:00am - 5:00pm
Sunday10:00am - 5:00pm
*Store hours reflect local standard trading hours and exclude public holidays
[Visit our Erina Fair Google Business page for directions, reviews, and updates.](https://g.page/r/CRU-NWtDUo7dEAE)
Book Appointment
[Call us: (02) 4300 8428](tel:(02) 4300 8428)
[Leave a Review!](https://g.page/r/CRU-NWtDUo7dEAg/review)
Our Reviews
karen Clement
3 days ago
Jo Jo
3 days ago
Ella Mannix
6 days ago
Lovely staff, Vince the optometrist is personable, he'll listen to your worries and suggestions arou...nd your eye care.
See more
Gail Duffy
1 week ago
JMF EDUCATION
1 week ago
The staff and service from the Oscar Wylee Erina team Was impeccable . Welcoming, warm and efficient... and professional. Highly recommend
See more
Robyn Sawtell
1 week ago
I have been coming to Erina Oscar Wylee for 10 years and always have a great experience
This time fo...r a different type of glasses than before ????????????
See more
Bronwyn Lewis
2 weeks ago
From the minute I walked into your shop at Erina I was greeted very professional and friendly.
From ...start to finished your staff are caring and are well knowledgeable in the eye care business
Nothing was too much trouble
See more
Jan Harivel
2 weeks ago
Ariane Amantiad
2 weeks ago
Xia You
3 weeks ago
I took my mum in this morning for her eye test, and we had such a wonderful experience. Vincent and ...Emma were absolutely fantastic — they were friendly, professional, patient, and extremely knowledgeable. They took the time to explain everything clearly and made my mum feel very comfortable throughout the appointment.
We purchased two pairs of glasses straight away! We really appreciate all their help and excellent customer service. The store is very lucky to have Vincent and Emma on board. Highly recommended!
See more
Nicholas Kilp
3 weeks ago
One delightful staff member was an absolute legend and helped me with my broken glasses. Absolutely ...above and beyond really appreciated.
See more
Steve Wood
3 weeks ago
Overall, the experience was okay, but I left feeling a little underwhelmed. At the retail desk, my n...ame was pronounced incorrectly twice, which wasn’t the best first impression.
The experience was very much what I’ve come to expect: I was left to choose my own glasses, with the same staff member simply advising the additional cost for each option. There was very little effort to understand what I was looking for, offer recommendations, or explain the differences between frames or lenses. The interaction felt quite disinterested throughout.
Unfortunately, this level of service seems to be fairly typical of the Erina store. I left feeling like I’d completed a transaction rather than received genuine customer service. There is definitely room for a more engaging and personalised experience.
See more
craig r
3 weeks ago
Fast efficient and friendly ????
found answers I could not get elsewhere. now I know why
I see doubl...ing at traffic lights.
I also clearly understand
what to expect and why
in the near future.
thankyou Vincent and Katy ????
See more
Luca Roncari
3 weeks ago
I always find a friendly team of professionals and specialists at Erina Fair Oscar Wylee Optometrist.... Everyone is very caring and accommodating, and they have a genuine attitude to assist, offering a solution to my changing circumstances. April and May have been very challenging for me due to a retinal detachment in my RE. A great sense of integrity. Thank you!
See more
Avalon Oates
4 weeks ago
Vincent is a very attentive and knowledgeable optometrist who makes a whole experience really pleasa...nt. I will continue to go here for my eye tests purely because of incident is so lovely to deal with.
See more
Susan Griffin
4 weeks ago
Always a pleasure .Lovely staff .Thank you .
A M
4 weeks ago
My optometrist was very thorough, explaining what each test was measuring, and discussing my family ...history with me. He was obviously very knowledgeable and totally committed to his profession. I felt confident that I was in experienced hands.
See more
Sue McR
1 month ago
Great service and great selection of frames.
Lorraine Bransby
1 month ago
Great experience! Vincent and the team at Erina Fair were such a great help ????
Adrian Howe
1 month ago
The staff at Oscar Wiley, Erina Fair, were super friendly, helpful and professional. From the eye te...st to choosing new glasses, I wasn’t completely satisfied with the help I received from the wonderful staff. Highly recommended.
See more
Sally Conn
1 month ago
Sally Hanzikourti
1 month ago
My partner and l recently visited the Oscar Wylee store in Erina Fair. We didn't have appointments b...ut the staff were most helpful and accommodating. Vincent, our optometrist, was professional and thorough. This was our first visit to this brand and we won't hesitate to visit again. Thank you for your kindness, it is so appreciated.
See more
Archie Tauasi
1 month ago
The staff were amazing and very friendly and helpful. The optometrist is a pro. Explained things cle...arly.
See more
Stephanie Brandley
1 month ago
Great service by optometrist and the staff are amazing in assisting with the selection
LYNETTE ELTHERINGTON
1 month ago
The team are wonderful and very helpful. I had ordered some readers, then realised that would not be... suitable for my need. I ordered the correct glasses and was able to still have the readers. Great customer service and support. Erina NSW
See more
Cath Connor
1 month ago
Excellent service at Oscar Wylie, Erina.  Thankyou.
Emily Cresswell
1 month ago
Beautiful service, highly recommend
L M
1 month ago
Vincent Tran at Erina branch is extremely professional and thorough. Thank you Vincent.
Dhinakar Kannan
1 month ago
Visited after making an online appointment to get an optometrist consultation. Appointment happened ...at the scheduled time, no delays. Professionally attended by front desk staff.
Vincent the optometrist was very thorough, courteous and professional in assessing my vision and recommending the change of my current prescription.
Great and cost effective collection of spectacles and frames to choose for your need.
See more
Lana Smith
1 month ago
As always my experience at Oscar Wylee Erina Fair was great. This was an emergency optometrist visit... as I had a contact lense tear and split while in my eye the night before and was concerned there was some debris left.
I was able to make an appointment for Sunday morning and get it checked out. The staff are always great and the optometrist on duty was very helpful and put me at ease. Thank you Team!
See more
Kelly Ferguson-Sprod
1 month ago
Always very happy with the service at Oscar Wylee, from the eye test through to selecting frames &amp; l...ense options. Staffa te knowledgeable &amp; very helpful &amp; patient .
See more
Julian Hofer
1 month ago
Excellent young team  of professionals. Have been coming for years. Excellent service
Belinda Youlten
1 month ago
So knowledgeable and helpful!!!!
Greg Finlay
2 months ago
Very communicative.
John Maloney
2 months ago
Joel Morgan
2 months ago
OC &amp; LG
2 months ago
Sheila Weir
2 months ago
I would like to sincerely thank you all for kindness care and professionalism you showed me during m...y very first visit for an eye test. I was feeling a little nervous not knowing what to expect but your manner and patience immediately put me at ease.
You took the time to explain everything clearly and made the experience comfortable. I was not sure what to expect as I had left this for a long time. I am truly grateful for the care I received from the young boy and Vince the optometrist for a very positive experience.Thank you again for your excellent care and for treating me with respect.
Sincere appreciation
Sheila
See more
Frank Collins
2 months ago
Have found all staff at Erina branch helping and caring and without over selling.
Tracy Biddle
2 months ago
I was very happy with the way I was treated and everyone was very helpful and caring
Barbara Aubrey
2 months ago
The optometrist fine and salesgirls very helpful. The space itself felt stifling and noisy.
Michael O'Brien
2 months ago
Excellent service
jennifer bowden
2 months ago
Amanda Jane Heaven
2 months ago
Extremely helpful and friendly.
Linda Wareham
2 months ago
Keri Anders
2 months ago
Great and efficient service.
Jane Russon
2 months ago
I just love this business. The optometrist is the best I've ever been too, and I've seen heaps over ...the years. The staff are helpful and respectful.  I actually cant fault this place. Just go there and find out for yourself!
See more
Janet Davies
3 months ago
Vincent was very good. Professional yet friendly and easy to discuss my eyesight with. Great experie...nce Thanks
See more
PC Marando
3 months ago
GREAT SERVICE FROM VINCENT AND TEAM
Kerrie Hadley
3 months ago
I was impressed by the quick and prompt service. I'm happy to recommend your business to anyone.
## Find an Optometrist in Erina With Oscar Wylee
Situated on the picturesque Central Coast of NSW, our Oscar Wylee Erina store can be found in the Erina Fair Shopping Centre, next to Hero Sushi Train. Here, our dedicated optometrists can conduct eye tests available for bulk billing as part of Australia’s Medicare system. To reach Oscar Wylee Erina, catch one of the many buses that service the centre or you can drive. Erina Fair Shopping Centre provides free parking for all customers. We recommend using the red car park. Once here, our Oscar Wylee Erina staff can help you shop our range of stylish and affordable frames which are available for prescription sunglasses as well. 
Erina Fair is just a 15-minute drive from Terrigal Beach. If you have time after your appointment, why not head over and explore the coastal sights, bustling shop fronts and a variety of beachside cafes. If you live in or around the Gosford or Terrigal area, Oscar Wylee at Erina Fair is your one-stop shop for your optometry needs, which includes necessary eye health tests for vision and eye diseases.        
Meet Our Team
* Optometrist Partner
B.VisSc
M.ClinOptom
* Retail Partner
Certificate IV in Optical Dispensing
Our Services
* Bulk Billed Eye Examinations
* Professional Frame Styling
* Frame Adjustments and Repairs
* Visual Fields Testing
* Digital Retinal Scanning
Show All
## Find an Optometrist in Erina Fair, Central Coast for an Eye Health Test
An optometrist at Erina Fair in Erina, Central Coast can provide customers with comprehensive eye testing, prescription sunglasses and many other services. When you visit the Oscar Wylee store at Erina Fair, you will find our skilled optometrist and optical dispenser who can readily help with any questions you may have. Whether it is for an eye health test in Erina Fair for regular eye checkups or for monitoring signs of eye diseases, we’ve got you covered. We offer eye tests at a bulk billed price thanks to the Australian Medicare System for eligible cardholders. For more complicated eye problems, we can refer patients to an ophthalmologist, also known as an eye doctor.
When carrying out an eye examination for your vision, our optometrists will be sure to examine multiple parts of your eye using different tools and machines. This will help ensure that the structures in and around the eye are all in optimal condition. The average price for an optometrist in Erina can differ between different optometrists, therefore, it may be difficult to provide correct information on the average price range for an optometrist in the area of Erina.
## How to Find an Optometrist in Erina, Central Coast?
To find an optometrist in Erina, Central Coast, you can take certain steps that can help make it easier for you such as searching online, assessing the store’s opening hours and finding the directions to your chosen location. The steps on how to find an optometrist in Erina are listed below.
1. Search online using the phrase, Erina optometrist near me. This can also be done here on the website via our locations page.
2. Click on the Oscar Wylee link, which will take you directly to our Erina optometrist store page.
3. See the store’s opening hours and where the store is located specifically.
4. Use the Erina Google Business page link located under store hours to see the directions on how to get to the store.
You can also find an optometrist in Erina by searching the keywords optometrist near me. If you have locations enabled on your smartphone and you’re in the Erina area, our Erina Fair store page should appear easily for you to click on.
### Is it Hard to Get an Eye Appointment in Erina Fair, Central Coast?
No, it is not hard to get an eye appointment in Erina. You can easily book an appointment to see an Oscar Wylee optometrist in Erina right here on this page. At Oscar Wylee we have highly qualified optometrists available for bulk billed eye appointments, which can be booked online or in-store.
#### How to Compare Optometrists in Erina to Each Other?
To compare optometrists in Erina, you can use factors such as eye tests offered, health fund coverage, lens types and add-ons and eyewear offered. To take care of your vision and eye health, it is important to receive an eye test at least once every two years. There are different types of tests that can be performed in an eye test and not all optometrists may offer the same tests. Health funds can be used to help cover some of the cost of your frames and lenses. To find out if your health fund is accepted at Erina optometrist in Central Coast, visit their website. In the case of Oscar Wylee, we accept all major health funds and provide on-the-spot claims in-store. There are many different lens options available for prescription glasses such as single vision, multifocal and high index lenses. Most optometrists in Erina will offer these lenses although it is good to make sure. There are also lens add-ons available to enhance your glasses such as anti-reflective and blue light filters. Finally, if you are looking to purchase a pair of glasses after your eye test, you can compare the different styles and colours you are interested in from Erina optometrists in Central Coast. Oscar Wylee offers a wide range of frames with vintage and modern inspirations in bold colours and subtle designs.
#### How to Find an Eyeglasses Shop in Erina, Central Coast?
To find a glasses store in Erina, you can try to follow these simple steps including searching online, selecting a convenient location and looking at their health insurance policies. The steps on how to find a glasses store in Erina, Central Coast are listed below.
1. Search online using the phrase, glasses store in Erina. This will provide you with various options for glasses stores in the whole Erina, Central Coast area.
2. Select a glasses store that is most convenient for you to travel to.
3. Click the link to find out more information such as opening hours, exact location and directions to the glasses store in Erina.
4. Read their health insurance policies to ensure you know what health benefits you have access to.
Our Oscar Wylee glasses store in Erina, Central Coast offers primary eye care services such as comprehensive eye tests as well as other services performed by an optometrist and offers prescription and non-prescription eyewear.
##### Is it Possible to Purchase Prescribed Sunglasses in Erina, Central Coast Without Seeing an Optometrist?
Yes and no, it is possible to [purchase prescribed sunglasses](https://www.oscarwylee.com.au/sunglasses.html) in Erina, Central Coast without seeing an optometrist if you already have a prescription that has not expired. If your prescription is expired, you can book an eye test to receive an updated or new prescription which will require you to see an optometrist. This will ensure your prescription sunglasses are appropriate for your visual needs.
## Where is the Oscar Wylee Erina Fair Optometrist in Central Coast Located?
The Oscar Wylee Erina, Central Coast optometrist is located in the Erina Fair Shopping Centre on level 1 next to Hero Sushi. The Erina Fair Shopping Centre is situated at 620-658 Terrigal Drive.
### What is the Phone Number of Oscar Wylee Erina Fair Optometrist Store?
The phone number of Oscar Wylee Erina Fair optometrist store is [(02) 4300 8428](tel:(02) 4300 8428). You can contact the Erina Fair optometrist store between 9 am and 5:30 pm on Monday, Tuesday, Wednesday and Friday, on Thursday between 9 am and 9 pm, on Saturday between 9 am and 5 pm and on Sunday between 10 am and 5 pm.
### What are the Reviews for Oscar Wylee Erina Fair Optometrist in Central Coast?
The many reviews for Oscar Wylee Erina Fair optometrist in Central Coast, left by our various customers can be found here on the website and online when you search for Oscar Wylee Erina Fair optometrist. The reviews for Oscar Wylee Erina Fair optometrist are listed below.
* Carolyn Peers:  Emily was a wonderful support in choosing glasses, pricing, and getting the best deal. Great experience.
* Louanne Shaw:  My experience at Oscar Wylee Erina is always great. Vincent is an excellent optometrist and the girls are always very attentive and helpful.
* Helen Eves:  Friendly staff, prompt service.
* Suzanne Jesson:  Excellent service. Everything explained really well.
* Myrene Hooper:  Vincent is an excellent, professional optometrist. Having been to him a number of times now, I have every confidence in him. He is pleasant, efficient and very competent.
#### What Treatments or Eye Care Processes are Done in the Oscar Wylee Erina Fair Optometrist Location?
The treatments or eye care processes done in the Oscar Wylee Erina Fair optometrist Central Coast location include a tonometry test, a digital photograph, a slit lamp exam and a refraction test. Additional tests that may also be performed can include a visual field test and a dilated fundus exam. The treatments or eye-care processes that are done in the Oscar Wylee Erina Fair optometrist Central Coast location are listed below.
* A Tonometry Test: An optometrist or optical dispenser will conduct a tonometry test which involves the use of a machine that will release small puffs of air into your eyes. This will assist with measuring pressure in the eye.
* A Digital Photograph: An optometrist or optical dispenser may take a digital photograph of your eye which can be kept on record to use in future appointments to evaluate any changes to your eye.
* Slit Lamp Test: A slit lamp test can be used to evaluate your eye health, by examining your cornea and iris which are the anterior and posterior of the eye.
* Refraction Test: During a refraction test, an optometrist will have you view an image through different lenses and ask you to confirm which helps you see the image clearer.
* Visual Field Test: A visual field test can assist with assessing your peripheral vision, which may be beneficial for identifying any signs of glaucoma.
* Dilated Fundus Exam: A dilated fundus exam can help an optometrist assess your health in more detail by getting a clear view of the retina. This test is typically carried out for patients with diabetes and those who may be at risk of developing retinal damage.
## How Many Optometrists Exist in Erina Fair, Central Coast?
There are many optometrists that exist in Erina Fair, Central Coast to provide eye tests and glasses, including Oscar Wylee. At Oscar Wylee Erina Fair located in Erina, we offer excellent optometry services including eye tests performed by highly-qualified optometrists using high-quality equipment. There may be certain factors for the current number of optometrists in Erina such as the geographical size of the suburb, residential population and possible demand for eyecare services. Come make the Oscar Wylee Erina Fair optometrist your go-to for excellent services.
### What are the Other Closest Optometrist Locations to Erina Fair, Central Coast in Australia?
The other closest Oscar Wylee optometrist locations to Erina Fair in Australia is Tuggerah with around 22 km in between stores and can be found at the Westfield shopping centre at 50 Wyong Rd, Tuggerah NSW 2259. The [Oscar Wylee Tuggerah](https://www.oscarwylee.com.au/locations/optometrist-tuggerah.html) store is a reliable destination for high-quality optometry services performed by a team that is passionate about eye care.
### Eye Tests Conducted by Oscar Wylee Erina Optometrists
We provide bulk billed eye tests if you are an eligible Medicare cardholder. Make sure you book your eye health tests regularly and have a look through our eyeglasses shop for new frames. Our optometrists at Oscar Wylee Erina can take care of your vision, and treat and examine eye problems, both with regular eye tests and with affordable frames.
### Leading Health Funds Accepted at Oscar Wylee
Visit our team in-store for help on all matters relating to your health fund. You will be able to have your health fund claim processed at Oscar Wylee Erina. Our team will be able to answer your health fund questions and evaluate what you’ll be able to receive. Like at every store, Oscar Wylee Erina is dedicated to your eye health as much as your customer experience so we will work to ensure you get prescription sunglasses and glasses at the right price.
### Fashionable Frames at Oscar Wylee Erina
Our prescription sunglasses and prescription glasses are fashion focused and affordable. Stop by Oscar Wylee Erina to speak to our team who are capable of guiding you when finding frames that are best for your face shape. We currently offer 2 pairs of prescription glasses from $199. You can walk out of Oscar Wylee Erina with glasses that look tailor-made for you.
Book Appointment
[Call us: (02) 4300 8428](tel:(02) 4300 8428)
[Leave a Review!](https://g.page/r/CRU-NWtDUo7dEAg/review)