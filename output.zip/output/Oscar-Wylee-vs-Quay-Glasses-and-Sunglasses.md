# Source: https://www.oscarwylee.com.au/vs-quay

# Oscar Wylee vs Quay Glasses and Sunglasses
Published on June 19th, 2025
Updated on March 21st, 2025   
Australia
Australia
New Zealand
Canada
Canadian French
 
Oscar Wylee and Quay are both beloved eyewear brands founded in Australia. Oscar Wylee began in 2012 as an online business selling glasses and sunglasses, with a physical store opening in Sydney in 2015. It has since expanded to New Zealand and Canada. Contrastingly, Quay Australia solely sells sunglasses. While they do not have their own physical stores, Quay glasses are sold internationally by over 2000 retailers around the world. Read on for the distinctions, similarities and differences between [Oscar Wylee](https://www.oscarwylee.com.au/) and Quay.
Book an Eye Test With Oscar&nbsp;Wylee
We have knowledgeable optometrists at our stores ready to provide eye care services.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Distinctions](#distinctions) [Specialised Lenses](#specialised-lenses) [Product Range Differences](#product-range) [Fashionability](#fashionability)
## What are the Distinctions between Oscar Wylee and Quay?
Some of the distinctive characteristics of Oscar Wylee compared to Quay are that they sell prescription optical glasses and sunglasses, have their own physical stores, and offer optometry services. Oscar Wylee offers prescription optical glasses and sunglasses alongside non-prescription eyewear. This is beneficial to those in need of prescriptive eyewear for vision correction. Oscar Wylee has their own physical stores across Australia, New Zealand and Canada that sell exclusively Oscar Wylee frames. This is unlike Quay where they are predominately online, but they do also sell in store through various different eyewear retailers. Oscar Wylee offers optometry services at all their stores. The optometrists are trained to provide eye tests, diagnose eye problems, and write prescriptions.
Some of the distinctive characteristics of Quay compared to Oscar Wylee is that they solely sell sunglasses in Australia and offer virtual try-ons. Quay sunglasses are offered both online and in store. While optical frames are available in person in America, they have yet to be released in Australia. This is in contrast to Oscar Wylee which offers prescription glasses and sunglasses in person and online. Quay also offers customers the opportunity to virtually try on frames. For a select number of frames, customers can virtually try them on to see if the sunglasses complement them well from their own devices before purchasing.
### What Stylistic Eyewear Options Does Oscar Wylee Offer Compared to Quay?
Some stylish eyewear options from Oscar Wylee include Arlia, Duckworth, Amber and Easten. Read more about some of the stylish sunglass options at Oscar Wylee compared to Quay listed below.
* Arlia: The Oscar Wylee Arlia glasses frame is a unique rectangular frame with a slight cat-eye shape, for a stylish and feminine sunglass.
* Duckworth: The Oscar Wylee Duckworth sunglasses, with their slightly oversized aviator shape is an effortlessly cool frame perfect for a beach day.
* Amber: The Oscar Wylee Amber glasses have a thin mental frame and unique geometric frame for a striking statement piece.
* Easten: The Oscar Wylee Easten glasses have a thick acetate frame and classic square shape for an a bold look for any wearer.
### Why Choose Oscar Wylee or Quay for Specialised Lenses?
Oscar Wylee and Quay both have specialised lenses to customise their glasses so customers can own eyewear that truly suit their everyday needs.
#### Oscar Wylee Specialised Lenses
Oscar Wylee offers prescription lenses for optical and sunglasses. These lenses can be extra thin, super thin and ultimate thin lens options alongside their standard lens to accommodate stronger prescriptions. These Oscar Wylee thin lenses come with a complimentary Basic Anti-Reflective coating. Oscar Wylee has a Premium Anti-Reflective Lens Coating add-on that is also anti-static, scratch, and smudge resistant, while the Blue Light Filter reduces potentially harmful blue light from digital screens. Oscar Wylee also has Transition Lenses available in store, smart lenses that automatically darken in the sun and quickly return to clear indoors, so the wearer doesn't have to switch between glasses and sunglasses.
Specific to sunglasses, Oscar Wylee offers Filter Category 2 and Filter Category 3 lenses which are general purpose sunglasses and provide high protection against glare. Oscar Wylee also has polarised sunglasses which have a coating applied to the lens to darken it and add colour. Polarised lenses also offer UV protection, while also cutting out glare on the horizontal wavelength.
#### Quay Specialised Lenses
Quay Australia has many specialised lenses for sunglasses. These include solid coloured, gradient, polarized, mirrored and fade lenses. Quay also has a select range of blue light frames.
### Why Choose Oscar Wylee or Quay for Blue Light Blocking Lenses?
Yes, Oscar Wylee offers [glasses that block blue light](https://www.oscarwylee.com.au/glasses/blue-light/review) emitted from digital devices. Blue light lenses aim to reduce the amount of blue light that hits the eye. Blue light glasses are perfect for office workers or students who spend time on devices frequently. Oscar Wylee allows glasses wearers to add a blue light filter to prescription or non-prescription glasses.
#### Do Oscar Wylee or Quay Offer Repairs for Eyeglasses?
Yes, Oscar Wylee and Quay offer repairs for eyeglasses. Oscar Wylee customers can head into the store and be assisted by a retail member to repair their glasses. However, charges may apply for items not covered under the 12-month warranty. At Quay, they have a repair kit available for purchase so customers can do easy frame repairs. Quay has a 3-month warranty policy in case of any manufacturing defects and offers exchanges or full refunds.
### How Long have Oscar Wylee and Quay been in Business?
Oscar Wylee has been in business since 2012 first as an E-Commerce business, then as physical stores. Oscar Wylee opened its first store in 2015 in Sydney, Australia. Quay has been in business since 2004 with its origins in Melbourne, Australia.
### What Products and Services does Oscar Wylee Offer?
Oscar Wylee provides prescription glasses, non-prescription glasses, and sunglasses for customers. The services at Oscar Wylee encompass bulk billed eye tests in Australia and a lifetime guarantee of adjustments or professional cleaning for Oscar Wylee glasses.
#### Does Oscar Wylee have In-House Eye Specialists?
No, Oscar Wylee does not have in-house eye specialists at their stores such as ophthalmologists. However, Oscar Wylee does have optometrists, [eye care professionals](https://www.oscarwylee.com.au/eye-health/optometrist-vs-ophthalmologist.html) who conduct extensive eye tests, diagnose eye problems and write prescriptions. These Oscar Wylee optometrists can refer you to an ophthalmologist for more serious eye issues.
#### Can you Order Prescription Glasses Online from Oscar Wylee?
Yes, you can order prescription glasses online from Oscar Wylee. This can be done directly on the Oscar Wylee website during checkout. You can provide them with your optometrist's contact information and Oscar Wylee will get in touch with them, upload a prescription copy, or click "send later" and send Oscar Wylee an email copy. The glasses can be delivered to your doorstep or collected in-store.
#### How to Find an Oscar Wylee Optometrist in Australia?
To find an Oscar Wylee Optometrist in Australia is simple. All there is to do is go to the locations page, enter your postcode, select the most convenient location and check the opening hours. Read more on these steps on how to [find an Oscar Wylee Optometrist](https://www.oscarwylee.com.au/find-optometrist) in Australia below.
* Go to the locations page: Go to the locations page on the Oscar Wylee website. This can be found at the very top of the website or at the footer under the heading 'Company.'
* Enter your postcode: Enter your postcode in the search bar to find the nearest Oscar Wylee optometrist to your home or desired location.
* Select the most convenient location: Select the most convenient Oscar Wylee location once you have typed in your postcode.
* Check the Opening Hours: Check the opening hours and address to find the perfect time to visit, and directions on how to get there.
### What Products and Services does Quay Offer?
Quay offers women's and men's sunglasses and accessories such as sunglass cases and repair kits. Quay offers prescription glasses, however this is only an American offering not yet available in Australia.
### What Brands does Quay Carry?
Quay does not carry other brands besides their own. They sell a wide catalogue of their own branded sunglasses.
#### Does Quay have In-House Eye Specialists?
Quay exclusively sells eyewear through third party retailers who may or may not have in-house eye specialists located on-site. The presence of in-house eye specialists will depend on the store location.
Update Your Prescription Today
See our team in-store for help with updating your prescription. We offer bulk billed eye tests and quality eye care assistance.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
## How do the Product Ranges of Oscar Wylee and Quay Differ?
The product ranges of Oscar Wylee and Quay may differ when it comes to their eyewear offered, availability of prescription eyewear and availability of kids' glasses. The categories in which Oscar Wylee and Warby Parker may differ are listed below.
|
|
| Category | Oscar Wylee | Quay |
| Eyewear Offered | Oscar Wylee offers both optical glasses and sunglasses. | Quay Australia solely offers sunglasses, though in America there are optical glasses sold. |
| Prescription Eyewear Available | Oscar Wylee has prescription eyewear available for both optical glasses and sunglasses for those needing vision correction. | Quay Australia only offers non prescription sunglasses. |
| Availability of kids' glasses | Oscar Wylee has a glasses range for kids specifically with bright coloured frames made from materials that are durable to children's active and playful lifestyles such as TR90. | Quay does not have glasses dedicated specifically to children's wear. |
### Where are Oscar Wylee Stores Located?
Oscar Wylee stores are located in Australia, Canada and New Zealand. There are more than 100 stores operating in Australia alone. The Oscar Wylee head office is located in Sydney, Australia, with many stores [located near](https://www.oscarwylee.com.au/locations/full-store-list.html) convenient locations.
#### Can Oscar Wylee Ship their Products Globally?
Oscar Wylee does not ship its products globally. However, Oscar Wylee customers are eligible for domestic shipping if they live in Australia, New Zealand or Canada. In Australia, all Oscar Wylee domestic [shipping](https://www.oscarwylee.com.au/shipping.html) orders are free.
### Where are the Quay Locations?
Quay does not have its own stores, instead they are sold at other retailers' physical stores, such as optometrists. There are more than 10 locations across Australia where Quay sunglasses are sold physically.
#### Can Quay Ship their Products Globally?
Yes, Quay customers can ship their products globally from Australia.
### Which Brand Offers a Wider Selection of Glasses, Oscar Wylee or Quay?
Both Oscar Wylee and Quay have a variety of glasses offered to consumers, though Oscar Wylee has a wider selection of glasses. Quay Australia offers sunglasses while Oscar Wylee offers both optical and sunglass options. Aesthetically, Quay offers more bold, festival-inspired frames while Oscar Wylee offers both vintage and modern frames.
#### Do Oscar Wylee or Quay Offer Warranties or Guarantees on Eyewear?
Yes, both Oscar Wylee and Quay offer warranties on eyewear. Oscar Wylee has a warranty period of 12 months. If there are production faults, such as material issues, defective frames or damage from the products manufacturing, Oscar Wylee offers replacement or repair of your purchase, completely free of charge. Quay has a 3-month warranty policy in case of any manufacturing defects and offers exchanges or full refunds on eyewear.
#### Are Oscar Wylee or Quay Glasses Suitable for Prescription Sunglasses?
Oscar Wylee is suitable for [prescription sunglasses](https://www.oscarwylee.com.au/glasses/eye/sunglasses/prescription). Quay Australia has a variety of sunglasses however prescription sunglasses are not an offering.
### Which Brand is More Suitable for Fashion-Conscious Consumers?
The brand that is more suitable for fashion-conscious consumers will depend on the individual's own stylistic preferences. Quay offers trendy sunglasses inspired by the "vibrant festival scene" as the brand aims to "merge(s) music and fashion to create trend-forward designer eyewear" making them particularly ideal for festivals and concerts and trendy amongst celebrities. Oscar Wylee has a variety of fashionable frames ranging from vintage to modern, as well as bold frames similar to the festival inspired shapes of Quay. Ultimately, it will depend on the wearer's personal style preference and lifestyle. For regular festival and live entertainment goers, you may prefer the striking, fashion-forward eyewear Quay provides. For those who prefer an everyday chic look, from subtle to bold frames, you may prefer Oscar Wylee frames.
#### Do Oscar Wylee or Quay Offer Virtual try-on Tools?
Yes, Quay offers a virtual try-on tool for customers. It is available on the top right corner of the website. The virtual try-on tool allows customers to sample a select number of glasses by using their webcam to see how glasses look on their faces. Oscar Wylee does not offer this tool.
## What are the Main Alternatives to Quay?
The main alternatives to Quay are Sunglass Hut, EyeBuyDirect, Specsavers, Oscar Wylee, Bailey Nelson, 1001 Optometry, OPSM and Warby Parker. Read more about these main alternatives below.
* Sunglass Hut: Sunglass Hut sells a range of reputable sunglass brands, originating in Miami, Florida and expanding to Australia in the mid-1990's.
* EyeBuyDirect: [EyeBuyDirect](https://www.oscarwylee.com.au/vs-eyebuydirect) is an online eyewear retailer with a focus on affordability. Like Quay, they also have a virtual try on feature for customers to trial glasses before buying.
* Specsavers: [Specsavers](https://www.oscarwylee.com.au/vs-specsavers) is an English eyewear retailer selling notable designer brands, with popular glasses collaborations alongside optometry and audiology services.
* Oscar Wylee: [Oscar Wylee](https://www.oscarwylee.com.au/) is an Australian brand that creates solely in-house glasses for distinguished eyewear suited to every demographic.
* Bailey Nelson: [Bailey Nelson](https://www.oscarwylee.com.au/vs-bailey-nelson)'s glasses range are designed in Australia. They have a variety of their own branded glasses, sunglasses and contact lenses on offer.
* 1001 Optometry: [1001 Optometry](https://www.oscarwylee.com.au/vs-1001-optometry) offers many brands of glasses, sunglasses and contact lenses. Some of their notable branded glasses include Ray-ban and Tom Ford.
* OPSM: [OPSM](https://www.oscarwylee.com.au/vs-opsm) is an Australian eyewear brand providing a variety of reputable branded glasses, sunglasses and contact lenses.
* Warby Parker: [Warby Parker](https://www.oscarwylee.com.au/vs-warby-parker) is an American eyewear brand featuring glasses collections and collaborations alongside features such as virtual try on's.
Read Oscar Wylee vs Quay Glasses and Sunglasses
in other Oscar Wylee regions and their
languages.
Australia
Australia
New Zealand
Canada
Canadian French
 
Major Health Funds Accepted at Oscar Wylee
For the purchase of frames and lenses at Oscar Wylee, use your private health fund insurance to minimize how much you pay from your own pocket.
[Explore health funds](https://www.oscarwylee.com.au/health-funds.html)
Book an Eye Test Today
At Oscar Wylee bulk billed eye tests are offered for eligible medicare card holders.
[Book an eye test](https://www.oscarwylee.com.au/booking)