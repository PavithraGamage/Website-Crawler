# Source: https://www.oscarwylee.com.au/glasses/eye/vitreous-hemorrhage

# Vitreous Hemorrhage: Causes, Symptoms and Treatment
Published on March 16th, 2026
Updated on March 21st, 2025 
A vitreous haemorrhage occurs when vessels bleed into the vitreous, which
is the gel in the eye centre, according to The Retina and Macula Centre. The causes are often the
presence of abnormal blood vessels or normal blood vessels that can rupture
under stress or trauma. The symptoms of vitreous hemorrhages include the
emergence of floaters and, in severe cases, vision loss. Read more about
Vitreous Hemorrhages, such as underlying eye diseases, treatments and
diagnosis.
It should be noted that the medical advice in this article is general in
nature and should not be a substitute for professional medical advice and
consultation.
Schedule your next appointment with our team for great eye care!
Our optometrists and teams are dedicated to your healthy vision.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Definition](#definition) [Causes](#causes)
[Symptoms](#symptoms) [Tests](#tests)
## What is Vitreous Hemorrhage?
A vitreous haemorrhage is a condition where blood leaks into the
vitreous humour,
which is the clear gel that is between the lens and retina, according to
Armadale Eye Clinic. This can cause vision issues, depending on the
amount of blood leakage and its location in the affected eye.
### How does Vitreous Hemorrhage Occur Inside the Vitreous Humour of the
Eye?
A vitreous hemorrhage occurs inside the vitreous humour of the eye,
due to a blood vessel within the retina breaking and
bleeding into the vitreous cavity, according to the Terrance Eye
Centre.
#### Does Bleeding in the Vitreous Gel Interfere With Light Reaching the
Retina?
Yes, bleeding in the vitreous gel interferes with light reaching
the retina.
This phenomenon is referred to as a vitreous haemorrhage, which is
where there is bleeding into the vitreous cavity of the eye. This is
the space at the back of the eye where there is vitreous gel.
Bleeding in the vitreous gel can impede the full amount of light
from reaching the retina.
## What Causes Vitreous Hemorrhage in the Eye?
The cause of a vitreous hemorrhage is usually due to
a blood vessel within the retina breaking and bleeding into the
vitreous cavity. Posterior Vitreous Detachment due to retinal tears is also a common
cause. Another cause of vitreous hemorrhages is the rupture of
neovascular blood vessels, such as from conditions such as diabetes.
### What Underlying Eye Diseases Lead to Vitreous Hemorrhage?
The underlying eye diseases that can lead to vitreous hemorrhages are
diabetic retinopathy, retinal tears and trauma. Read
more about these underlying eye diseases, which lead to vitreous
hemorrhage, below.
* Diabetic Retinopathy: Diabetic
retinopathy occurs when blood vessels in the retina become broken or
damaged. This irregular blood vessel growth and damaged vessels can
lead to vitreous hemorrhages.
* Retinal Tears: Retinal tears can
lead to blood coming from the retinal veins to enter the vitreous
humour, which is where vitreous hemorrhages take place.
* Trauma: Trauma that is blunt or
perforating can damage blood vessels and cause them to bleed into
the vitreous. This trauma includes instances such as getting hit
with a sports ball in the eye or making contact with a sharp stick.
* Posterior Vitreous Detachment: Posterior Vitreous Detachment is when vitreous traction on the
retina causes the retinal vessel to bleed. This is a common
condition that leads to vitreous hemorrhage.
#### Can Abnormal Blood Vessel Growth Increase the Risk of Eye Bleeding?
Yes, abnormal blood vessel growth increase is a
risk of eye bleeding. Abnormal blood vessel growth is referred to as
neovascularisation, which is caused by diseases such as diabetes and
retinal vein occlusion, according to Northside Eye Specialists.
## How does Posterior Vitreous Detachment Lead to Vitreous Hemorrhage?
Posterior Vitreous Detachment
can lead to vitreous hemorrhages. Posterior Vision
Detachment refers to the phenomenon where the vitreous humour separates
from the retina. During this process, tractive forces may either cause
small retinal blood vessels to rupture, or may create a retinal tear,
either of which can lead to bleeding into the vitreous cavity, and as a
result causing a vitreous hemorrhage.
### What Structural Changes Occur During Posterior Vitreous Detachment?
The structural changes that occur during posterior vitreous detachment
are that the vitreous, which is the transparent
substance that fills the middle of the eye,
detaches from the retina.
#### Can Separation of the Vitreous From the Retina Damage Blood Vessels?
Yes, the separation of the vitreous from the retina
can damage blood vessels. While the separation of the vitreous from
the retina is a regular process as a person ages, it can have
potential consequences, such as retinal tear or detachment,
according to the Retina Doctor.
Experience passionate eyecare and a memorable in-store experience!
Visit your local OW store for any of your concerns or browse our wide
selection of stylish frames!
[Find a store](https://www.oscarwylee.com.au/locations)
## How Can Eye Injuries Cause Vitreous Hemorrhage?
Eye injuries can cause vitreous hemorrhages as the blunt or penetrating trauma can directly rupture
vessels
or dislocate the retina from its base, according to Bright Sight
Specialists. These
[eye injuries](https://www.oscarwylee.com.au/glasses/eye/injuries)
can include being hit in the eye with a sports ball or a falling tree
branch.
### What Types of Eye Trauma Can Lead to Bleeding in the Vitreous?
The types of eye trauma that can lead to bleeding in the vitreous
include
blunt eye trauma, penetrating eye trauma, and perforating eye
trauma. Read more about the types of eye trauma that can lead to bleeding
in the vitreous.
* Blunt Eye Trauma: Blunt eye trauma
encompasses sports injuries and even physical fights.
* Penetrating Eye Trauma: Penetrating
eye trauma is when the eye makes contact with sharp objects, such as
sticks.
* Perforating Eye Trauma: A
perforating eye trauma is defined as one where the trauma has
separate entrance and exit wounds.
#### Can Sudden Impact to the Eye Trigger Internal Eye Bleeding?
Yes, a sudden impact to the eye can trigger
internal eye bleeding. A punch, a tree branch falling, or a kick to
the eye can result in internal eye bleeding.
## What are the Symptoms of Vitreous Hemorrhage?
The symptoms of vitreous hemorrhage include
floaters, blurry vision, dark patches in vision, light flashes and
cobwebs in vision. The symptoms of vitreous hemorrhages below.
* Floaters: Floaters are small spots or
threads that appear in your line of vision. They can be harmless, but
in vitreous hemorrhages, they may appear more frequently.
* Blurry Vision: Blurry vision is common
in vitreous hemorrhages. You may not be able to see as sharply as
before having a vitreous hemorrhage.
* Dark Patches in Vision: Dark patches
in your vision may emerge, blocking out parts of your line of sight.
* Light Flashes: Light flashes may
appear in your vision, and you may experience more sensitivity to
light.
* Cobwebs in Vision: Cobwebs in your
vision refer to floating, thread-like strands resembling cobwebs, like
its name suggests. It is a symptom of vitreous hemorrhages similar to
floaters.
### What Vision Changes Occur When Blood Enters the Vitreous Humour?
The vision changes that can occur when blood enters the vitreous
include
blurry vision and a reddish tint over your line of sight, according to Vision Eye Institute.
### Can Dark Spots or Shadows Suddenly Appear in the Field of Vision?
Yes, dark spots or shadows can suddenly appear in the
field of your vision if you suffer from a vitreous hemorrhage. It is a
common symptom of the condition.
## How are Eye Floaters Related to Vitreous Hemorrhage?
Eye floaters are related to vitreous hemorrhages as
they are a common symptom. They are caused by vitreous
debris that emerges as a result of vitreous hemorrhages, according to
The Royal Australian College of General Practitioners.
#### Can Small Particles of Blood Create Moving Spots in Vision?
Yes, small particles of blood can create moving spots
in vision as a result of vitreous hemorrhages. A vitreous haemorrhage
is when blood leaks into the vitreous humour, which can lead to fresh
blood cells floating to appear as dark, cloud-like floaters in your
vision, according to Bright Sight Eye Specialists.
## How is Vitreous Hemorrhage Diagnosed During an Eye Test?
Vitreous hemorrhage is diagnosed during an eye test through processes
such as an optical coherence tomography
(OCT) or a dilated fundus examination.
### What Clinical Tests Help Eye Doctors Detect Vitreous Hemorrhage?
The clinical tests eye doctors may use to detect vitreous hemorrhages
include a
slit-lamp exam, Optical Coherence Tomography (OCT) scan and
Fluorescein angiography Test. Read more about these clinical tests to detect vitreous hemorrhages
below.
* Slit-lamp exam: A slit-lamp exam is
used to observe and assess the vitreous haemorrhage.
* Optical coherence tomography (OCT) scan: The Optical Coherence Tomography creates high-resolution scans of
the macula and retina.
* Fluorescein Angiography Test: The
Fluorescein angiography test may be used in certain cases to assess
the source of the hemorrhage such as vascular leakage.
#### Can Doctors Detect Internal Eye Bleeding during a Dilated Eye Exam?
Yes, a doctor, namely an Optometrist, can spot
minute internal eye bleeding during a dilated eye test.
## What Treatments are Available for Vitreous Hemorrhage?
The treatments available for vitreous hemorrhages are
anti-VEGF injections, laser therapy and steroid injections. These treatment options do not treat the hemorrhage itself, rather
the underlying causes of it. It is important to note that you should
consult a medical professional to assess which treatment is best for you
and any potential risks that can come with it. Read more about these
treatments available for vitreous hemorrhages below.
* Anti-VEGF Injections: Anti-VEGF
injections work by shrinking abnormal vessels, reducing leakage and
reducing the risk of repeat bleeding, according to Bright Sight Eye
Specialists.
* Laser Therapy: Laser therapy comes in
many different forms and intends to seal leaky vessels or reseal
retinal breaks.
* Steroid Injections: Steroid injections
can help reduce swelling and inflammation in the eye and can be useful
if macular oedema is also present, according to BrightSight.
#### Can Mild Cases of Vitreous Bleeding Improve with Monitoring Alone?
Yes, mild cases of vitreous bleeding can improve with
monitoring alone. If a vitreous haemorrhage is mild and does not have
any effects on your vision, no treatment may be required, according to
Terrace Eye Centre. However, it is always important to consult an
Optometrist when you experience symptoms of vitreous bleeding.
## What Other Eye Conditions are Associated With Vitreous Hemorrhage?
The other eye conditions that are associated with vitreous hemorrhages
include
retinal tears and detachment, Posterior Vitreous Detachment, trauma,
diabetic retinopathy and age-related macular degeneration
(AMD). Read more about these eye conditions associated with vitreous
hemorrhage below.
* Retinal Tears and Detachment: Retinal
tears and detachment can lead to a vitreous haemorrhage due to blood
vessels within the retina being torn.
* Posterior Vitreous Detachment: Posterior Vitreous Detachment is when the vitreous, the jelly-like
substance in the middle of the eye becomes watery and less jelly-like.
It begins to detach and move away from the retina at the back of the
eye, and can lead to vitreous hemorrhages.
* Trauma: Trauma to the eye such as
blunt or penetrative contact can lead to vitreous hemorrhages. This
includes contact with fast moving sports balls, sharp sticks or other
harsh objects.
* Diabetic Retinopathy: Diabetic
retinopathy is a condition where blood vessels in the retina become
damaged and irregular blood vessels grow. These weak blood vessels can
leak into the vitreous and lead to vitreous hemorrhages.
* Age-related Macular Degeneration (AMD): A type of age-related macular degeneration called Wet Macular
Degeneration is where blood vessels leak fluid or blood into the
macula. Abnormal blood vessels in wet age-related macular degeneration
may extend into the vitreous cavity and lead to vitreous hemorrhage.
### How are Retinal Tears and Retinal Detachment Linked to Vitreous
Bleeding?
Retinal tears and retinal detachment are linked to vitreous bleeding
as they are common causes. A retinal tear and
detachment can lead to the eye's interior bleeding, which is called a
vitreous haemorrhage, according to Sydney Retina.
#### Can Damage to the Retina Increase the Likelihood of Vitreous
Bleeding?
Yes, damage to the retina can increase the
likelihood of vitreous bleeding. It is often a common cause of
vitreous bleeding.
#### Can Corrective Lenses Improve Daily Visual Clarity for Patients
Recovering from Vitreous Hemorrhage?
Corrective lenses may improve visual clarity for
patients recovering from vitreous hemorrhage in everyday life, such
as
[prescription glasses](https://www.oscarwylee.com.au/glasses.html). However, they are not a remedy or treatment for
vitreous hemorrhages.
## How can Sunglasses Protect Eyes After Vitreous Hemorrhage?
Sunglasses can protect eyes after a vitreous hemorrhage
from harsh Ultraviolet (UV) rays, a type of light emitted from the sun.
However,
[sunglasses](https://www.oscarwylee.com.au/glasses/eye/sunglasses)
are not a necessary part of recovery, and do not eliminate or reduce
symptoms.
#### Can Blue Light Glasses Improve Vision After Vitreous Hemorrhage?
There is no scientific evidence to suggest blue light
glasses improve vision after a vitreous hemorrhage.
[Blue light glasses](https://www.oscarwylee.com.au/glasses/eye/blue-light)
aim to block or reduce the blue light emitted from digital screens,
according to the Cleveland Clinic. While they may be useful for
digital eye strain and fatigue, they will not improve vision quality
after vitreous hemorrhages.
## When to See an Eye Doctor for Sudden Vitreous Hemorrhage Symptoms?
You should see an eye doctor for sudden vitreous hemorrhage
symptoms
if you experience severe symptoms that impede clear vision. If you
experience blurry vision, or black dots or figures that resemble clouds
or cobwebs in your vision, then you should seek urgent help, according
to Retina Doctor Melbourne.
### What Warning Signs Indicate the Need for Immediate Eye Examination For
Vitreous Hemorrhage?
These warning signs that indicate the need for immediate eye
examination for vitreous hemorrhage are the
sudden appearance of floaters, blurred vision, and red tinted
vision,
according to Armadale Eye Clinic. Read more about these warning signs
for vitreous hemorrhage below.
* Sudden Appearance of Floaters: The
sudden appearance of floaters may occur more frequently. These
small, moving spots and thread-like bodies may drift across the
field of vision in the affected eye. They can be harmless; however,
if they are frequent in your line of vision, it is important to get
them checked.
* Blurred Vision: Blurred vision can
make finer details harder to distinguish. Tasks like reading and
computer work may be affected.
* Red Tinted Vision: You may
experience red-tinted vision due to the presence of red blood cells
in the vitreous humour. These can create a reddish or darker hue
across part of your visual field.
#### Can Sudden Vision Loss or Floaters Signal a Vitreous Hemorrhage?
Yes, sudden vision loss or floaters can be a signal
of a vitreous hemorrhage. However, it should be noted that these can
also be signs of other eye conditions and that you should consult an
optometrist if you experience these dramatic vision changes.
Experience Quality Eye Care!
We have knowledgeable optometrists at Oscar Wylee, who are available
in-store to perform high-quality eye tests.
[Book an eye test](https://www.oscarwylee.com.au/booking)
Oscar Wylee Accepts Major Health Funds In-store
Visit Oscar Wylee in-store for eye care and eye wear services, and
your health fund may help cover some of the cost.
[Explore health funds](https://www.oscarwylee.com.au/health-funds.html)