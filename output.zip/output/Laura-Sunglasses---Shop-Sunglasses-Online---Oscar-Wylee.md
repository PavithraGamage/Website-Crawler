# Source: https://www.oscarwylee.com.au/laura-sunglasses.html

# Laura
1
## Frame Design of Laura Sunglasses
The frame design of Oscar Wylee’s Laura sunglasses is characterised by their oval and round shape, low nose bridge, and bio acetate frame. Laura is a wearable women's glasses frame that will complement any outfit or event, day to night.
$169    
In stock
Only %1 left
2 pairs from $199
Discount auto-applied at checkout
3 pairs from $249
Discount auto-applied at checkout
* 2 &amp; 3 Pair pricing applies to non-prescription sunglasses only. Prescription sunglasses incur additional charges.    
[Non-Prescription](https://www.oscarwylee.com.au/laura-sunglasses.html#)
Qty
Prescription
Book an eye test
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
excluding prescription lenses
## About Laura Sunglasses
Laura is a classic oversized beauty with metal embellishments on the temples alongside a luxe logo for a chic flair. Laura protects from the sun and is poised for the camera
| Frame fit | Measurements |
| --- | --- |
| MEDIUM | 54 - 18 - 145 |
These measurements mean lens width, bridge, and temple length in millimetres (mm). They can be found on the inside of the temple arm. If you already have a pair that you like, you can compare it to these measurements.
### Frame Design of Laura Sunglasses
The frame design of Oscar Wylee’s Laura sunglasses is characterised by their oval and round shape, low nose bridge, and bio acetate frame. Laura is a wearable women's glasses frame that will complement any outfit or event, day to night. The main specs of Oscar Wylee’s Laura glasses frame, including dimensions, shape, materials, lenses, nose fit, and hinges are listed below.
Filter category 2 (Auburn Tortoise and Mustard Tortoise only) - General purpose sunglasses. Good protection against sunglare. Good UV Protection. Not suitable for driving in twilight, at night or under dull conditionsFilter category 3 (Cacao Tortoise only) - General purpose sunglasses. High protection against sunglare. Good UV Protection. Not suitable for driving in twilight, at night or under dull conditionsThese frames come with polarised lenses. An additional $100 will be added to your order total for prescription orders.
| Laura Frame Features | Laura Frame Description | Dimensions | Shape | Materials | Lenses | Nose Fit | Hinges |
| --- | --- | --- | --- | --- | --- | --- | --- |
| The dimensions of the Laura frame are measured in millimetres (mm) and are 54 - 18 - 145, meaning the lens width is 54 mm, the bridge is 18 mm, and the temple length is 145 mm. |
| Laura is an oval and round shape, well-suited to medium faces. |
| Laura is made from bio acetate. |
| The lenses that can be used in the Laura frame are sunglass lenses, which provide UV protection. Prescription lenses are also available to purchase for the Laura sunglass frame, both online and in-store. |
| The nose fit for Laura is a low nose bridge fit. |
| The hinges in Laura are normal hinges, also known as standard or barrel hinges. |
Show All
### What Inspired the Frame Design of Oscar Wylee's Laura Glasses?
The Oscar Wylee Laura frame design was inspired by current fashion trends, as oval and round shapes are often in fashion. An oval and round glasses shape is timeless; it remains popular throughout the decades while other trends come and go.
## What to Know About Oscar Wylee's Laura Sunglasses?
There are many aspects of the Oscar Wylee Laura frames that customers should know to decide whether this is the right frame for them. The Laura frame is a women's, oval and round sunglasses frame. Oscar Wylee’s Laura frame is suitable for many face shapes, but particularly compatible with square, oval, heart, pear and diamond face shapes. The Laura frame’s simple design makes them fashionable all year round. Laura features the standard [parts of glasses](https://www.oscarwylee.com.au/glasses/eye/part-of-glasses), such as a rim, temples, lenses, low nose bridge, and normal hinges.
### What are the Types of Temple Tips or Earpieces Included with Oscar Wylee's Laura Glasses?
The type of temple tips or earpieces included in Oscar Wylee’s Laura Glasses are made from bio acetate.
### What Type of Nose Bridge do Oscar Wylee's Laura Glasses Have?
The type of nose bridge included in Oscar Wylee’s Laura frame is a low nose bridge.
### What Type of Nose Pads are Included with Oscar Wylee's Laura Glasses?
Oscar Wylee’s Laura frame does not include adjustable silicone nose pads.
### What Type of Lenses do Oscar Wylee's Laura Sunglasses Have?
The lenses that can be used in the Laura frame are sunglass lenses, which provide UV protection. UV protection lenses block harmful ultraviolet rays, safeguarding eyes from damage. Filter category 2 is available for Auburn Tortoise and Mustard Tortoise only which are general purpose sunglasses offering good protection against sun glare. Good UV Protection. Not suitable for driving in twilight, at night or under dull conditions. Filter category 3 (Cacao Tortoise only) are general purpose sunglasses. High protection against sunglare. Good UV Protection. Not suitable for driving in twilight, at night or under dull conditions.
### What Material is Used for the Rim of Oscar Wylee's Laura Glasses?
The material used for the rim of Oscar Wylee’s Laura glasses frames is bio acetate. The rim refers to the part of a glasses frame that holds the lenses.
### What Type of Hinges are Included with Oscar Wylee's Laura Glasses?
The type of hinges included with Oscar Wylee’s Laura frames are normal hinges, also known as standard or barrel hinges. These provide strength and smooth movement, connecting the frame's arms and lenses.
## What Face Types are Most Suitable for Oscar Wylee's Laura Glasses?
The face types most suitable for Oscar Wylee’s Laura frame are square, oval, heart, pear and diamond face types. The Laura frame is an oval and round shape, meaning it complements the structure of square, oval, heart, pear and diamond faces particularly well. The oval and round Laura frames help balance the features of a [square face shape](https://www.oscarwylee.com.au/glasses/face-shapes/square), [oval face shape](https://www.oscarwylee.com.au/glasses/face-shapes/oval), [heart face shape](https://www.oscarwylee.com.au/glasses/face-shapes/heart), [pear face shape](https://www.oscarwylee.com.au/glasses/face-shapes/pear) and [diamond face shape](https://www.oscarwylee.com.au/glasses/face-shapes/diamond), bringing the eyes and brows forward in a flattering way. Although there are many different [glasses for face shapes](https://www.oscarwylee.com.au/glasses/face-shapes) that may be considered more aesthetically suitable, it is important that people also choose frames that make them feel most comfortable and represent their personal style.
## What Size Options are Available for Oscar Wylee's Laura Glasses?
The size options available for Oscar Wylee’s Laura frame are a medium-frame fit across all colours.
## What Materials are Used to Create Oscar Wylee's Laura Glasses?
The material used to create the Oscar Wylee Laura frame is bio-acetate. Bio acetate is predominantly made from renewable plant matter such as wood pulp, for a more eco-conscious foundation.
## What’s Included
## OW Case &amp; Cloth
Protective Case and Lens Cloth
Our high-quality glasses case and lens cloth are included with every purchase of an Oscar Wylee frame. The stylish, magnetic case is made from a hard shell. This sturdy and durable material keeps your glasses protected and safe, wherever you go. Ensure your lenses are clean and scratch-free with our OW microfibre cloth, specifically designed to ensure you have comfortable vision through your lenses.
Oscar Wylee offers:
* Free Shipping for Australian Orders
* 1 Year Warranty on frames and lenses
* Scratch resistance lens coating on all prescriptions
* UV-proof coating on all prescriptions
Health fund rebate: Once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. Learn more about [health funds](https://www.oscarwylee.com.au/health-funds.html).
## Make and Materials
Eco-consciousness meets durability with bio-acetate. Replacing unbiodegradable plasticisers with plant based alternatives, bio-acetate allows a biodegradable lens frame, leaving a reduced carbon footprint on the environment.The frames then go through cleaning and strict quality control, and many pairs of crafting hands to be hand-assembled and polished. After your frames have gone through the production process, they are individually examined and&nbsp;packed before making their way to you!
## Warranty Information
### Warranty Information
### Warranty Information
Oscar Wylee provides a 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects. We will repair or replace faulty or defective frames or lenses free of charge for warranty claims made within 1 year of the delivery. We also offer repairs or replacement for problems experienced with vision during everyday use for claims made within 30 days of delivery. If the same product has been discontinued or is no longer available, then we may offer an exchange for a similar product or a refund.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Find a Store Location](https://www.oscarwylee.com.au/locations/full-store-list.html)