# Source: https://www.oscarwylee.com.au/glasses/collection/mens-glasses.html

102 Products        
Showing 15 of 102
1. [](https://www.oscarwylee.com.au/parker-l-optical.html)
[Parker Large](https://www.oscarwylee.com.au/parker-l-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/parker-l-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/parker-l-optical.html)
2. [](https://www.oscarwylee.com.au/parker-optical.html)
[Parker](https://www.oscarwylee.com.au/parker-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/parker-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/parker-optical.html)
3. [](https://www.oscarwylee.com.au/andrew-optical.html)
[Andrew](https://www.oscarwylee.com.au/andrew-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/andrew-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/andrew-optical.html)
4. [](https://www.oscarwylee.com.au/lori-optical.html)
[Lori](https://www.oscarwylee.com.au/lori-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/lori-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/lori-optical.html)
5. [](https://www.oscarwylee.com.au/vista-optical.html)
[Vista](https://www.oscarwylee.com.au/vista-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/vista-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/vista-optical.html)
6. [](https://www.oscarwylee.com.au/humphrey-optical.html)
[Humphrey](https://www.oscarwylee.com.au/humphrey-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/humphrey-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/humphrey-optical.html)
7. [](https://www.oscarwylee.com.au/zelda-optical.html)
[Zelda](https://www.oscarwylee.com.au/zelda-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/zelda-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/zelda-optical.html)
8. [](https://www.oscarwylee.com.au/zuri-optical.html)
[Zuri](https://www.oscarwylee.com.au/zuri-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/zuri-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/zuri-optical.html)
9. [](https://www.oscarwylee.com.au/murphy-optical.html)
[Murphy](https://www.oscarwylee.com.au/murphy-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/murphy-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/murphy-optical.html)
10. [](https://www.oscarwylee.com.au/emet-optical.html)
[Emet](https://www.oscarwylee.com.au/emet-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/emet-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/emet-optical.html)
11. [](https://www.oscarwylee.com.au/avery-optical.html)
[Avery](https://www.oscarwylee.com.au/avery-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/avery-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/avery-optical.html)
12. [](https://www.oscarwylee.com.au/mesa-optical.html)
[Mesa](https://www.oscarwylee.com.au/mesa-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/mesa-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/mesa-optical.html)
13. [](https://www.oscarwylee.com.au/leigh-l-optical.html)
[Leigh Large](https://www.oscarwylee.com.au/leigh-l-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/leigh-l-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/leigh-l-optical.html)
14. [](https://www.oscarwylee.com.au/kevin-optical.html)
[Kevin](https://www.oscarwylee.com.au/kevin-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/kevin-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/kevin-optical.html)
15. [](https://www.oscarwylee.com.au/francis-optical.html)
[Francis](https://www.oscarwylee.com.au/francis-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/francis-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/francis-optical.html)
102 Products        
Showing 15 of 102
Choosing The Best Glasses Best Material &amp; Lenses Width &amp; Colour Men’s Glasses FAQ
## How to Choose the Best Glasses Frame for Men?
To choose the [best glasses frames for men](https://www.oscarwylee.com.au/glasses/best-men-eyeglasses-for-every-face-shape) you should consider face shape, frame size, colour of the frames, matching the glasses to your hairstyle and accentuating your personality. Read on for how to choose the best glasses frame for men below.
* Consider face shape: Consider face shape for choosing the best glasses for men. Certain frames pair well with certain face shapes as they balance out your features.
* Frame size: Consider frame size by trying them on yourself as this allows you to truly assess how they fit on your face. A good rule of thumb to remember is that the frame should align with your temples and not extend past the eyebrows.
* The colour of your frames: Consider the colour of your frames based on your everyday attire and the occasions you most frequently wear your frames. Classic colours such as black and dark grey are perfect for corporate settings, while clear or shades of blue might be a more fun approach to parties and dinners.
* Match to your Hairstyle: Match your frames to your hairstyle. Shorter textured hair will make your eyewear a focal point on the face, so you may prefer a thinner frame which will not overpower. Medium length hair is versatile when it comes to compatible frames, so you might want to consider thickness and style when it comes to glasses frames. Men with longer hairstyles can opt for thicker frames as these won't be overshadowed by the length.
* Accentuating your Personality: Accentuate your personality with your glasses! If you love colour go for a two-toned look, or a frame with subtle embellishments if you like the luxe aesthetic.
### How to Choose the Best Men Glasses According to Skin Tone?
To choose the best men's glasses according to skin tone you should identify the undertone of your skin and pick a complementary colour. For cooler skin undertones such as blue or purple, cooler frame colours such as blue, silver, grey and green will complement your skin well. For warmer skin undertones such as yellow or peachy hues, select frames in similarly warmer colours like tortoiseshell, brown, gold, or other earthy tones. Neutral skin tones have both cool and warm undertones, making them relatively versatile in complementing many colours. Regardless of skin undertone, you can never go wrong with a classic black frame.
### How to Choose the Best Men Glasses According to Face Shape?
To choose the best men's glasses according to [face shape](https://www.oscarwylee.com.au/glasses/face-shapes) you should determine your face shape, and choose a glasses shape that fits it well. The most common face shapes are oval, round, square, pear and heart shapes. Read on for how to choose the best men's glasses according to face shape below.
* Oval Faces: Oval faces are versatile and can complement many glasses frames, however they work best with angular or [square glasses](https://www.oscarwylee.com.au/glasses/silhouette/square.html).
* Round Faces: Round faces will benefit from [rectangle glasses](https://www.oscarwylee.com.au/glasses/silhouette/rectangle.html) or [rectangle sunglasses at Oscar Wylee](https://www.oscarwylee.com.au/sunglasses/silhouette/rectangle.html) from Oscar Wylee such as [Brody glasses to shop online](https://www.oscarwylee.com.au/catalog/product/view/id/17533/s/brody-optical/category/2/). Square frames can also provide angular contrast to the soft curve of round faces.
* Square Faces: Square faces are angular and generally look as wide as they are long. The best [glasses for square face shapes](https://www.oscarwylee.com.au/glasses/face-shapes/square) are round or oval glasses. [Shopping round glasses online](https://www.oscarwylee.com.au/glasses/silhouette/round-glasses.html) or in store will soften the face shapes' naturally sharp angles.
* Pear Shaped Faces: Pear shaped faces benefit from frames that complement their narrow forehead and soften a fuller jawline. These include oval and round glasses to uplift the pear shaped face, such as the [Micah optical glasses](https://www.oscarwylee.com.au/micah-optical.html). Read more about the intellectual charm of round frames in [Round Glasses: Timeless, Best Frames, Benefits and Comparison](https://www.oscarwylee.com.au/glasses/round-frame).
* Heart Shaped Faces: Heart shaped faces are characterised by a wide forehead and a narrow chin. However, the proportions of a heart face for men are different to women, as men usually have a squarer and more angular chin. The best glasses for heart faces for men compared to [women’s glasses from Oscar Wylee](https://www.oscarwylee.com.au/glasses/collection/womens-glasses.html) for heart faces are square and oval glasses as they bring intrigue and balance to the face.
### How to Choose the Best Men's Glasses According to Eye Colour?
Ultimately, eye colour should not be a major influence in choosing the best men's glasses frame or colour. Other physical features such as skin, hair colour, face and nose shape will be larger factors in determining the best men's glasses for you. However, if you have brown or hazel eyes you may prefer a similar tone for your glasses such as tortoiseshell, gold or other dark browns while blue or grey eyes will pop in silver, grey, or navy frames.
[](https://www.oscarwylee.com.au/marco-optical.html) [](https://www.oscarwylee.com.au/parker-l-optical.html) [](https://www.oscarwylee.com.au/duckworth-optical.html) [](https://www.oscarwylee.com.au/catalog/product/view/id/17533/s/brody-optical)
[](https://www.oscarwylee.com.au/marco-optical.html) [](https://www.oscarwylee.com.au/parker-l-optical.html) [](https://www.oscarwylee.com.au/duckworth-optical.html) [](https://www.oscarwylee.com.au/catalog/product/view/id/17533/s/brody-optical)
## Which Material is Best for Men's Glasses?
The best material for men's glasses is dependent on personal style preferences and lifestyle habits. There is no singular best material for men's glasses, it will be different for each wearer. The common materials that are best for men's glasses are titanium, acetate, TR90, ultem and stainless steel. These materials best for men's glasses are listed below.
* Titanium: A type of metal known for its lightweightedness.
* Acetate: Acetate is a flexible plastic with plenty of variety in colour.
* Acetate &amp; Metal: Acetate and metal glasses provide strength and striking aesthetics.
* TR90: TR90 is a great option for active glasses wearers due to its impact resistance.
* Ultem: Ultem is a type of plastic known for its lightweight and durability.
* Stainless Steel: Stainless steel provides a sleek, effortlessly cool look.
* Bio-acetate: Bio-acetate women's is made mostly from renewable plant matter ideal for the eco-conscious.
### 1. Titanium Men's Glasses
[Titanium](https://www.oscarwylee.com.au/glasses/titanium) men's glasses are notable for their strength and lightweight frame. The metal's durability and sleek profile make them an effortlessly cool eyewear choice.
### 2. Acetate Men's Glasses
Acetate is a type of plastic that is used in the creation of men's glasses. [Acetate](https://www.oscarwylee.com.au/glasses/acetate-frame) is a flexible, often hypoallergenic material that can come in a variety of colours, for men who want more vibrant eyewear.
### 3. Acetate &amp; Metal
Acetate and metal men's glasses provide a striking aesthetic with the two materials. Acetate is typically used for the lens frame, providing interesting colourways, while metal temples provide strength and a minimalist profile.
### 4. TR90 Men's Glasses
TR90 men's glasses are known for their flexibility and impact resistance. [TR90](https://www.oscarwylee.com.au/glasses/tr90) is a thermoplastic material, with its durable properties making it the perfect choice for men who have a more active lifestyle.
### 5. Ultem Men's Glasses
Ultem is a high-quality plastic used in men's eyewear, offering flexibility, durability and comfort.
### 6. Stainless Steel Men's Glasses
[Stainless steel](https://www.oscarwylee.com.au/glasses/materials/stainless-steel.html) is a corrosion-resistant metal that can be used in the creation of men's eyewear, allowing for a sleek, minimalist profile fit for any occasion.
### 7. Bio-Acetate Men's Glasses
Bio-acetate men's glasses are made from bioacetate, a material mainly made from plant-based matter such as wood pulp and cotton fibres. Compared to acetate, it uses fewer oil based plasticisers in its creation, making it a more eco-conscious choice.
### Why Should Men Consider Blue Light Filter for their Prescription Glasses?
Men should consider a blue light filter for their prescription glasses if they regularly use digital devices such as computers and phones. Blue light filters are made to help block or reduce the blue light that digital screens emit. Blue light filters may help limit eye strain, improve comfort while using devices and improve sleep quality, making them invaluable particularly for those who work regularly with computers.
### Why Should Men Consider Anti Reflection for their Prescription Glasses?
Men should consider anti reflection for their prescription glasses as it will reduce the glare received from light and other reflective surfaces. This can increase vision quality as obtrusive reflections and glare will be reduced.
### How Can Men Turn Glasses into Sunglasses with Tints and Polarisation?
Men can turn optical or non-prescription glasses into sunglasses, by adding a tint or a polarisation to their lenses. At Oscar Wylee, a customer will have the option to add these options to their lenses, for an additional price on top of the cost of the frames.
### Why Should Transition or Adaptive Lenses be Considered?
Transition or adaptive lenses should be considered for men’s glasses who want compact sun protection. Transition lenses can be added to [prescription glasses and frames](https://www.oscarwylee.com.au/glasses.html), which allow your lenses to&nbsp; change from a clear to dark tint when exposed to sunlight. Transition lenses provide both vision correction and UV protection, so you can have the benefits of optical glasses and sunglasses in one pair.
## How to Buy Men's Glasses According to Width?
Oscar Wylee has a variety of men's glasses in varying widths to accommodate a range of face sizes. These width sizes include Narrow, Medium or Wide. Read on for the different men's glasses widths to consider before purchasing.
* Narrow: Narrow men’s glasses are suited for men with more thinner faces for a seamless fit such as the [Haskell Optical Glasses to shop online](https://www.oscarwylee.com.au/haskell-optical.html) or in-store.
* Medium: Medium men’s glasses encompass a range of frame shapes such as rectangular, square-round and geometric for many medium sized face widths and shapes such as the [Bowery optical glasses for shopping online](https://www.oscarwylee.com.au/bowery-optical.html) or in store.
* Wide: Wide men's glasses can come in many shapes and accommodate broader faces.
### Which Colour Pattern is Best for Men's Glasses Frames?
There is no best colour pattern for men's glasses frames. Some glasses colour patterns include matte, solid, tortoise, transparent and two-toned. Read on for the various colour patterns that could be the best for men's glasses frames.
* Matte: Matte glasses refer to a low-gloss, flat-looking finish for a smooth, minimal style
* Solid: Solid colour frames are classic and versatile, able to provide a subtly stylish accessory to any outfit.
* Tortoise: Tortoise shell patterns offer a blend of often warm tones and are an effortlessly stylish accessory, perfect for any occasion.
* Transparent: Transparent, clear frames are popular due to their minimalist, modern look, offering subtle style and practicality.
* Two-toned: Two-toned glasses create a striking contrast and visual interest, for those who want unique colour in their eyewear.
[](https://www.oscarwylee.com.au/cliff-optical.html) [](https://www.oscarwylee.com.au/parker-l-optical.html) [](https://www.oscarwylee.com.au/francis-optical.html) [](https://www.oscarwylee.com.au/connor-optical.html)
[](https://www.oscarwylee.com.au/cliff-optical.html) [](https://www.oscarwylee.com.au/parker-l-optical.html) [](https://www.oscarwylee.com.au/francis-optical.html) [](https://www.oscarwylee.com.au/connor-optical.html)
### Which Colour is Best for Men's Glasses?
Ultimately, the best colour for men's glasses is entirely up to your sense of style. At Oscar Wylee we have a variety of colours such as black, blue, brown, gold, clear, green, grey, red, silver, purple, pink, yellow and white. Read on for the various colours that can be best for men's glasses frames.
* Black: Black frames are classic and versatile for many occasions, particularly formal or business settings.
* Blue: Blue frames add stylish colour, whether a baby blue or rich navy, for versatility and a slight departure from more traditional frame colours.
* Brown: Brown frames provide a warmth and natural tone, making warmer skin tones in particular, pop.
* Gold: Gold frames bring an elegant and luxe flair to any outfit, notably in professional or formal settings. For more on the decadent aesthetic of gold frames, read [Gold Frame Glasses: Are They Still in Style?](https://www.oscarwylee.com.au/glasses/gold-frame)
* Clear: Clear frames are an ultra modern yet minimalist accessory, blending in seamlessly to any look.
* Green: Green glasses add a striking feature to any outfit, a vibrant alternative to more conventional colour schemes.
* Grey: Grey frames exude a neutral yet sleek look. In varying shades, they are perfect for professional settings.
* Red: Red glasses are a bold statement, creating an arresting look best suited for men who want to stand out.
* Purple: Purple frames exude a creative, unique look, perfect for a more eccentric aesthetic.
* Pink: Pink frames, while a more unconventional colour for men, can be a fun option.
* Yellow: Yellow frames exude a brightness, ready to uplift any outfit. Many will often look similar to gold or are part of a blended colour pattern.
[](https://www.oscarwylee.com.au/jinky-optical.html) [](https://www.oscarwylee.com.au/mumford-optical.html) [](https://www.oscarwylee.com.au/duckworth-optical.html) [](https://www.oscarwylee.com.au/farrell-optical.html)
[](https://www.oscarwylee.com.au/jinky-optical.html) [](https://www.oscarwylee.com.au/mumford-optical.html) [](https://www.oscarwylee.com.au/duckworth-optical.html) [](https://www.oscarwylee.com.au/farrell-optical.html)
### Which Colour Glasses are Best for Senior Men?
There is ultimately no best colour option for [senior men's glasses](https://www.oscarwylee.com.au/glasses-for-seniors.html). It will depend on the man's colour preferences and the colour scheme of their wardrobe. However, you cannot go wrong with classic colours such as black, brown and grey for a timeless look. Subtle metallic frames, such as silver or gold, are a striking addition for seniors, particularly alongside formal attire.
## What are the Price Factors for Men Glasses?
The price factors for men's glasses at Oscar Wylee will vary depending on elements such as glasses material, add-ons and lens types. One pair of men's glasses from our core range starts from $169, 2 pairs from $199 and 3 pairs from $249. It should be noted that lens thickness and other add-ons will affect overall pricing. See our [price guide](https://www.oscarwylee.com.au/price-guide/) page for more information.
### What is the Duration of Shipment for Men Glasses?
Oscar Wylee offers domestic shipping for men's glasses ordered on the website. Typically deliveries will usually be dispatched within 7-10 business days. If you are having them delivered to your home, this can take up to 2 weeks. An email will be sent to you confirming the order alongside an order tracking link.
### What is the Most Popular Add-On for Men's Glasses?
The most popular add-ons for men's glasses can include anti-reflective and blue light lenses, as well as optical add-ons such as multifocals and high index lenses. Add-ons such as anti-reflective and blue light filters are popular choices as they reduce glare and filter out blue light rays from digital devices, respectively. Other popular add-ons for men's glasses include multifocal options and lens thinning options, to accommodate those with differing and high prescriptions.
### What are the Standard Lenses that Come with Men's Glasses?
The standard lenses that come with men's glasses at Oscar Wylee are 1.5 standard single vision lenses. If men need lenses of a different index such as high index lens options, or wish to have multiple prescriptions in a lens, such as multifocal lenses, these will incur an additional cost.
[Prescription Glasses](https://www.oscarwylee.com.au/glasses.html)
[Women’s Glasses](https://www.oscarwylee.com.au/glasses/collection/womens-glasses.html)
[Men’s Glasses](https://www.oscarwylee.com.au/glasses/collection/mens-glasses.html)
[Senior Glasses](https://www.oscarwylee.com.au/glasses/collection/seniors.html)
[Glasses for Kids](https://www.oscarwylee.com.au/glasses/collection/kids-collection.html)