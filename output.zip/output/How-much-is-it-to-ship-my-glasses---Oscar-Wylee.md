# Source: https://www.oscarwylee.com.au/faq-shipping.html

* [POPULAR FAQS](https://www.oscarwylee.com.au/faq-popular.html)
* [ORDERING](https://www.oscarwylee.com.au/faq-ordering.html)
* [PRESCRIPTIONS](https://www.oscarwylee.com.au/faq-prescriptions.html)
* [SUNGLASSES](https://www.oscarwylee.com.au/faq-sunglasses.html)
* [RETURNS &amp; WARRANTIES](https://www.oscarwylee.com.au/faq-returns.html)
* [PAYMENT](https://www.oscarwylee.com.au/faq-payment.html)
* [HEALTH FUNDS](https://www.oscarwylee.com.au/faq-healthfund.html)
* [LENSES](https://www.oscarwylee.com.au/glasses/eye/types-of-lenses)
* [FRAMES](https://www.oscarwylee.com.au/faq-frames.html)
* [SHIPPING](https://www.oscarwylee.com.au/faq-shipping.html)
* [EYEWEAR STYLING TIPS](https://www.oscarwylee.com.au/faq-eyewear-styling-tips.html)
POPULAR
ORDERING
PRESCRIPTIONS
SUNGLASSES
RETURNS &amp; WARRANTIES
PAYMENT
HEALTH FUNDS
LENSES
FRAMES
SHIPPING
EYEWEAR STYLING TIPS
### SHIPPING
How much do you charge for shipping?
Oscar Wylee offers free domestic shipping on all orders placed on our website or in-store.
Once our laboratory has cut the lenses to fit your specifications, we'll try as hard as we can to get your glasses to you as fast as possible.
How long will it take before I receive my glasses?
Delivery on Australian orders is FREE, and your order will be sent out via standard parcel delivery. We are unable to send any orders out via Express Post. The estimated delivery time for in-store collection and home delivery are listed below:
1. In-Store Collection: Orders are typically ready for collection in-store within 7-10 business days from the date of purchase. A team member will contact you once your glasses have passed quality control checks and are ready for collection.
2. Home Delivery: If your order is being shipped to your home, it may take up to 2 weeks to arrive. This includes the production time of 7-10 business days and additional time for shipping
If you are not available to take delivery, a calling card will be left with instructions on how to pick up your package. Unfortunately, there are no deliveries on public holidays. In this instance, please expect your delivery to be delayed by one business day.
Please allow more time for store pick-up or delivery during peak times of the year, like public holidays or the Christmas period.