# Source: https://www.oscarwylee.com.au/health-funds/st-lukes-health.html

# St Luke's Health at Oscar Wylee

As a member of St Luke’s Health, you can claim on optical extras using
your health fund’s coverage for optical services, such as prescription
frames, lenses or glasses. St Luke’s Health Benefits reset every
calendar year,
claim your glasses before time runs out! Any extras you don’t use
will be lost.
With Oscar Wylee, you can have up to 100% coverage on select
optical purchases when you shop with us. Look at the table below to see
your St Luke’s Health policy’s name and the amount of coverage that
policy gives when you shop at Oscar Wylee.Your coverage
might change or not apply to extras such as add-ons, coatings or
tinting.
## Need an eye test?
Come to Oscar Wylee stores to get a bulk billed eye test, available
to all eligible medicare cardholders.
[Book an eye test](https://www.oscarwylee.com.au/booking)
#### Waiting Period
6 months
#### Benefit Limits Reset
1st of January
#### Claimable Benefits %
100%
To learn whether your plan includes single vision lenses, bifocal lenses
and/or multifocal lenses, talk to your health insurance provider.
| Your Extras Package Annual Limit:* | Starter Extras (Tasmania) | Wellbeing Extras (Tasmania) | Super Extras (Tasmania) | Budget Extras (Mainland) | Super Extras (Mainland) | Packaged Ultimate Gold | SINGLES COVER | 1 Standard OW Pair
from $169^ | 2 Standard OW Pairs
from $199^ | 3 Standard OW Pairs
from $249^ |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| $150 | $200 | $300 | $200 | $300 | $350 |
| Partial Cover | Covered | Covered | Covered | Covered | Covered |
| Partial Cover | Covered | Covered | Partial Cover1 | Covered | Covered |
| Partial Cover | Partial Cover | Covered | Partial Cover1 | Covered | Covered |
^Excludes add-ons. Standard frames and lenses only. Oscar Wylee’s
standard product inclusions are calculated based on the optical
allowances under each health fund package and may vary. If unsure,
please confirm with your provider. Our two pair and three pair deals are
only available per person and cannot be split between two people. Only
one prescription can be used per offer. If you have a distance and a
reading prescription, this is included in the offer as this is
considered to be one prescription. Any prescriptions must have the full
name of the person claiming and a valid expiry date to be able to order.
If you have two different prescribed prescriptions, you will need to
visit a store to be eligible for our two pair and three pair deals.
| FAMILY COVER | 1 Standard OW Pair
from $169^ | 2 Standard OW Pairs
from $199^ | 3 Standard OW Pairs
from $249^ |
| --- | --- | --- | --- |
| $150 per person | $200 per person | $300 per person | $200 per person | $300 per person | $350 per person |
| Partial Cover | Covered | Covered | Covered | Covered | Covered |
| Partial Cover | Covered | Covered | Partial Cover | Covered | Covered |
| Partial Cover | Partial Cover | Covered | Partial Cover | Covered | Covered |
^Excludes add-ons. Standard frames and lenses only. Oscar Wylee’s
standard product inclusions are calculated based on the optical
allowances under each health fund package and may vary. If unsure,
please confirm with your provider. Our two pair and three pair deals are
only available per person and cannot be split between two people. Only
one prescription can be used per offer. If you have a distance and a
reading prescription, this is included in the offer as this is
considered to be one prescription. Any prescriptions must have the full
name of the person claiming and a valid expiry date to be able to order.
If you have two different prescribed prescriptions, you will need to
visit a store to be eligible for our two pair and three pair deals.
## Take care of your eyes today
Oscar Wylee offers bulk billed eye exams. Book yours today!
[Book an eye test](https://www.oscarwylee.com.au/booking)
*Based on St Luke’s Health
[Cover Guide](https://stlukes.com.au/extras)
and product factsheet as presented to the commonwealth Ombudsman.
[St Lukes Brochure - Tasmania](https://cdnw.stlukes.com.au/assets/9edd9df1-e811-474a-9592-173d3caecbd7)
[St Lukes Brochure - Mainland](https://cdnw.stlukes.com.au/assets/d39baf91-c26f-4134-9772-58e1fc42127b).1 Partial cover for this deal is based on the
maximum benefit amount per frames and per lenses under this extras
plan.
Information correct as of November 2024.
## Your eye test explained
Routine eye test appointments are quick and painless. Find out
what to expect during an eye exam and how to understand your eye
test results.
[Find out more](https://www.oscarwylee.com.au/eye-health/your-eye-test-explained.html)
## Bulk Billing
Find out what bulk billing is and whether you're eligible to
receive an eye test free of charge.
[Find out more](https://www.oscarwylee.com.au/eye-health/eye-test-info/bulk-billing.html)
## What is Pupillary Distance? (PD)
Do you know your PD? It's something you'll need to know when
ordering glasses online. Find out what Pupillary Distance is and
how you can measure your own.
[Read more](https://www.oscarwylee.com.au/eye-care/eye-test/what-is-pupillary-distance.html)
## Book an eye test
Oscar Wylee eye tests are bulk billed through Medicare. This
means there will be no out-of-pocket expense for eligible
Medicare cardholders.
[Book online](https://www.oscarwylee.com.au/booking/)
## Find a store near you
Contact or visit your nearest store for a full quote.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)