# Source: https://www.oscarwylee.com.au/kitty-optical.html

# Kitty
1
## Frame Design of Kitty Glasses
The frame design of Oscar Wylee’s Kitty glasses is characterised by a geometric shape, adjustable nose pads and a TR90 and metal frame. Kitty glasses are a women’s, essential frame that will work for any occasion, whether the wearer wants to liven up their work style or complement a fun outfit for a night out.
$169    
In stock
Only %1 left
2 pairs from $199
Discount auto-applied at checkout
3 pairs from $249
Discount auto-applied at checkout
Qty
Add to cart
Book an eye test
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
excluding prescription lenses
## About Kitty Frames
Hello, Kitty! This geometric frame is the modern cat-eye lovers dream.
| Frame fit | Measurements |
| --- | --- |
| Medium | 52 - 17 - 140 |
These measurements mean lens width, bridge, and temple length in millimetres (mm). They can be found on the inside of the temple arm. If you already have a pair that you like, you can compare it to these measurements.
### Made from TR/Ultem Material
Oscar Wylee’s Kitty frame is a women’s, geometric glasses frame that is perfect for medium faces and those with round and oval face shapes. The Kitty frame is a stylish, widely wearable frame that can be worn every day. The main specs of Oscar Wylee’s Kitty glasses frame including dimensions, shape, materials, lenses, nose fit and hinges are listed below.
| Kitty Frame Features | Kitty Frame Description | Dimensions | Shape | Materials | Lenses | Nose Fit | Hinges |
| --- | --- | --- | --- | --- | --- | --- | --- |
| The dimensions of the Kitty frame are measured in millimetres (mm) and are 52 - 17 - 140, meaning the lens width is 52 mm, the bridge is 17 mm and the temple length is 140 mm. |
| The Kitty frame is a geometric frame shape, well suited to round and oval faces. |
| Kitty glasses are made from a material called TR90 and metal. |
| The lenses that can be used in the Kitty frame are optical lenses, which include single vision and multifocal lenses and non-prescription lenses, which are plain and can have a filter like a blue light filter applied. |
| The Kitty frame is fitted with adjustable nose pads |
| The hinges in Kitty glasses are normal hinges, also known as standard or barrel hinges. |
Show All
### What Inspired the Frame Design of Oscar Wylee’s Kitty Glasses?
The Oscar Wylee Kitty frame design was inspired by current fashion trends as geometric shapes are a must-have for those who like to go bold with their accessories by taking a step up from classic and essential shapes.
## What to Know About Oscar Wylee’s Kitty Glasses?
There are many aspects of the Oscar Wylee Kitty frames that customers should know about, so they can decide whether this is the right frame for them. The Kitty frame is a women’s geometric-shaped frame. Oscar Wylee’s Kitty frame is suitable for many face shapes but particularly compatible with round and oval face shapes. The Kitty frame’s unique design means that they are fashionable all year round. Kitty glasses feature the standard [parts of glasses](https://www.oscarwylee.com.au/glasses/eye/part-of-glasses) such as a rim, temples, lenses, normal hinge and nose pads.
### What are the Types of Temple Tips or Earpieces Included with Oscar Wylee’s Kitty Glasses?
The type of temple tips or earpieces included in Oscar Wylee’s Kitty Glasses are made from cupronickel.
### What Type of Nose Bridge do Oscar Wylee’s Kitty Glasses Have?
The type of nose bridge included in Oscar Wylee’s Kitty frame is nose pads.
### What Type of Nose Pads are Included with Oscar Wylee’s Kitty Glasses?
Oscar Wylee’s Kitty frame includes standard nose pads. Nose pads are great for comfort and can also be adjusted for the perfect fit.
### What Type of Lenses do Oscar Wylee’s Kitty Glasses Have?
The type of lenses that typically come with the Oscar Wylee Kitty [glasses frame](https://www.oscarwylee.com.au/glasses.html) are optical lenses. Optical lenses are glasses lenses that have a prescription within the lens to help correct vision issues such as myopia, hyperopia and astigmatism. Kitty glasses can also come with non-prescription lenses, with add-ons such as a blue light filter. Kitty frames are currently unavailable as sunglasses online, however, customers can customise in-store and add on tint or polarisation.
### What Material is Used for the Rim of Oscar Wylee’s Kitty Glasses?
The material used for the rim of Oscar Wylee’s Kitty glasses frames is TR90 and stainless. The rim refers to the part of a glasses frame that holds the lenses.
### What Type of Hinges are Included with Oscar Wylee’s Kitty Glasses?
The type of hinges included with Oscar Wylee’s Kitty frames are normal hinges, also known as standard or barrel hinges. These hinges have many interlocking loops that are stabilised with a small screw.
## What Face Types are Most Suitable for Oscar Wylee’s Kitty Glasses?
The face types most suitable for Oscar Wylee’s Kitty frame are round and oval face shapes. The Kitty frame is a geometric shape, meaning that it complements the structure of round and oval shapes particularly well. The Kitty frames help to balance the features of a [round face shape](https://www.oscarwylee.com.au/glasses/face-shapes/round) and an [oval face](https://www.oscarwylee.com.au/glasses/face-shapes/oval) shape, bringing the eyes and brows forward in a flattering way. Geometric frames help to flatter round and oval face types creating a pleasing visual contrast between sharp angles and rounded features highlighting without overemphasising them. Although there are many glasses for face shapes that may be considered more aesthetically suitable, it is important that people also choose the frames that make them feel most comfortable, and represent their personal style.
## What Size Options are Available for Oscar Wylee’s Kitty Glasses?
The size options available for Oscar Wylee’s Kitty frame are a medium-frame fit across all colours.
## What Materials are Used to Create Oscar Wylee’s Kitty Glasses?
The primary materials used to create the Oscar Wylee Kitty frame are TR90 and metal. The materials used for the nose bridge, temples and temple tips are made from cupronickel. TR90 is a thermoplastic material that is lightweight, durable and flexible.
## What’s Included
## OW Case &amp;a Cloth
Protective Case and Lens Cloth
Our high-quality glasses case and lens cloth are included with every purchase of an Oscar Wylee frame. The stylish, magnetic case is made from a hard shell. This sturdy and durable material keeps your glasses protected and safe, wherever you go. Ensure your lenses are clean and scratch-free with our OW microfibre cloth, specifically designed to ensure you have comfortable vision through your lenses.
Oscar Wylee offers:
* Free Shipping for Australian Orders
* 1 Year Warranty on frames and lenses
* Scratch resistance lens coating on all prescriptions
* UV-proof coating on all prescriptions
Health fund rebate: Once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. Learn more about [health funds](https://www.oscarwylee.com.au/health-funds.html).
## Make and Materials
The frames then go through cleaning and strict quality control, and many pairs of crafting hands to be hand-assembled and polished. After your frames have gone through the production process, they are individually examined and packed before making their way to you!We love our Ultem frames! They are super comfortable and very durable. Our Ultem frames are heat resistant, with high dielectric strength and flexible. The material is widely used in medical and chemical instruments. It is currently available in a range of colours for both matte and gloss finish.
## Warranty Information
### Warranty Information
### Warranty Information
Oscar Wylee provides a 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects. 
We will repair or replace faulty or defective frames or lenses free of charge for warranty claims made within 1 year of the delivery.
We also offer repairs or replacement for problems experienced with vision during everyday use for claims made within 30 days of delivery. If the same product has been discontinued or is no longer available, then we may offer an exchange for a similar product or a refund.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Find a Store Location](https://www.oscarwylee.com.au/locations/full-store-list.html)
Recommended
1. [](https://www.oscarwylee.com.au/aries-optical.html)
[Aries](https://www.oscarwylee.com.au/aries-optical.html)
Champagne
2. [](https://www.oscarwylee.com.au/peggy-optical.html)
[Peggy](https://www.oscarwylee.com.au/peggy-optical.html)
Blush Pink
3. [](https://www.oscarwylee.com.au/netta-optical.html)
[Netta](https://www.oscarwylee.com.au/netta-optical.html)
Gold Wisteria