# Source: https://www.oscarwylee.com.au/locations/optometrist-glen-waverley.html

# Optometrist Glen Waverley
The GlenG-030, 235 Springvale RdGlen Waverley, VIC 3150
* Near H&amp;M &amp; Target
Opening hours
Monday9:00am - 5:30pm
Tuesday9:00am - 5:30pm
Wednesday9:00am - 5:30pm
Thursday9:00am - 9:00pm
Friday9:00am - 9:00pm
Saturday9:00am - 5:00pm
Sunday10:00am - 5:00pm
*Store hours reflect local standard trading hours and exclude public holidays
[Visit our Glen Waverley Google Business page for directions, reviews, and updates.](https://g.page/r/CajpZ_j_SNuHEBM)
Book Appointment
[Call us: (03) 7035 3821](tel:(03) 7035 3821)
[Leave a Review!](https://g.page/r/CajpZ_j_SNuHEBM/review)
Our Reviews
Bryan
1 week ago
Very satisfied with my eye test and the thorough and helpful approach taken by the optometrist. She ...answered all my questions patiently and clearly. Staff at The Glen shop were also accommodating in handling my unusual request.
See more
Hong
1 week ago
Consumate professionals
Helpful, informative, attentive and I just walked in without a booking too!
rizafel bartolome
1 week ago
Shams Hard Work
1 week ago
Great selection of fashion glasses plus great customer service from a young lady ????????
Lixia zhou
2 weeks ago
(Translated by Google) I was so lucky to meet a lovely lady who speaks Chinese. She fixed my glasses... quickly and professionally, and she didn't even charge me! It was amazing! ????
(Original)
很幸运遇到了一位会讲中文的小姐姐，很快很专业的就帮我把眼镜修好了，还没收取我费用，真的太棒了????
See more
Dinh Tran
3 weeks ago
I stopped by for a walk-in appointment to get my eyes checked and find some reading glasses. Luckily..., Ms. Chen, the optometrist, was incredibly helpful! She made the whole process enjoyable and really guided me in choosing the perfect pair of glasses.
See more
Ricardo L
3 weeks ago
Excellent!!!
celia wang
3 weeks ago
Surkey in Glen Waverley store is amazing. She is professional, patient and friendly to my little one.... She assisted him to select his first pair of glasses.
See more
Anuj Beniwal
4 weeks ago
Hashim
1 month ago
Alice Chen
1 month ago
Excellent customer service ! ????????
Lam Lauding
1 month ago
Jennifer Chen
1 month ago
Very friendly and helpful staff.
Good experience.
Eric Choong
1 month ago
The staffs are very professional and friendly. Reasonable waiting time.
Binu Joseph
1 month ago
Edward
2 months ago
Good Service
Wen Long Yue
2 months ago
It was a very good experience…
Grace Lee
2 months ago
I've been using Oscar Wylee for years and had a positive experience with The Glen recently. The opto...metric assistant and the optometrist were both friendly and helpful throughout the appointment. I was able to select the best value-for-money frames and lenses.
See more
Eagle Group HY
2 months ago
Best Oscar Wylee ever????????
Fua Evile
2 months ago
Very friendly atmosphere and very good service.
yvettecox007
2 months ago
Optometrist and staff were excellent
B L
2 months ago
Been going there every 6 months to get new glasses due to aging of my eyes. The ladies here are phen...omenal at their job. They really do multifocals well
See more
Phoenix Ngan
2 months ago
Dimmy Christopoulos
3 months ago
Staff are loving,caring,kind and help us .thanks to wonderful women help us .They give u great price... .we love u guys .lm proud of Oscar Wylee optometrist  giving us help,love,kindess,undrrstanding ,great price.
See more
Vu Le
3 months ago
very nice friendly staff.
walk in eye test is welcomed
Nava Teja
3 months ago
Theory Nightshade
3 months ago
Been going to Oscar Wylee since I was 18 (almost a decade), and this specific location since it open...ed. The optometrists and the optical assistants are all lovely and they have the best range of glasses.
Went in today after the arm of the frame of my glasses snapped, and brought my prior prescription pair with me (same frame, different colour). They were able to put my current prescription into my old frame so I wouldn't be without glasses while waiting for the new frame to come in, and even changed the screws and nose pads in my old pair for me so I they'd be wearable!
Massive thanks to the team, I really appreciate their help and hospitality, it's always a quick and painless process when I have to come in ????
See more
Michelle Jago
3 months ago
Very professional, patient and accommodating from the moment I walked in the door. Highly recommende...d!!
See more
pk tester
3 months ago
Caila
3 months ago
I had a really lovely experience at Oscar Wylee for my most recent eye test.
I hadn’t gotten my eye...s tested in a couple years as I had been going to Spec Savers and the experience was just a bit cumbersome and they didn’t have many styles of frames that I liked.
Both the ladies in store were super friendly, offering assistance, completing the eye test in a timely manner and giving me all my options for the lenses without making me feel pressured to do any add ons.
The frames available are also really nice and light, as well as having a lot of neutral tone and really nicely shaped frames that I feel would be suitable for every day use and still look good in a professional setting.
I definitely recommend coming in for an eye test here if you’ve been feeling a bit put off getting the tests done. I was also super pleased to see a 2 for $199 deal and they accepted my health insurance as well which covered it!
I’ve included a picture of the frames I ended up choosing as well, super excited for them to arrive!
See more
Les Field
4 months ago
Always professional job. Plus very helpful with arranging appointments.
Pure Air
4 months ago
Great service, friendly staff and great glasses, thanks ????
Paul Chow
4 months ago
Val Traficante
5 months ago
Great service. My second time going. They were quick and professional.
Sam Hawke
5 months ago
My optomertrist is very good!
Joy CHEN
5 months ago
The clerk is warm, thoughtful, patient and professional.
Erica Lim
5 months ago
I have had the best customer service by Karen. A couple of months ago, I visited  Oscar Wylee in hop...es of finding a comfortable everyday frame. I was served by Karen who helped me walk through the style, explained the measurements and really helped me pick a frame. I wanted to have a think prior to purchasing my frames.
Fast forward to today, I felt inclined to come back to the store because of the care and expertise Karen had shown me at our last interaction! So I came back and placed my order with Karen who not only helped me with my order, but also was very patient, accomodating. She went above and beyond to assist me this afternoon. She truly was so helpful and made me feel valued as a customer! Thank you again Karen! ????
See more
rebecca gee
5 months ago
Much better than dealing with OPSM.
Elin
5 months ago
Gianni Frigo
5 months ago
Great experience. Very helpful and patient staff. Huge selection of frames too.
Bo Yang
5 months ago
Sanzi’s service is amazing. I really like her — she’s such a sweet girl.
Christine Prandi
6 months ago
Very friendly  ,helpful and explained everything ,liked the experience alot.
Piumantha Sanjaya
6 months ago
Desiree Perera
6 months ago
I had  a great experience at my recent eye test appointment. Henry was very professional and took th...e tine for a thorough examination.
See more
Steven Javorniczky
6 months ago
Very friendly team, makes you feel at ease, very nice optometrist, took her time, prices are good, w...ill review when I have the glasses.
See more
Keerthana Kamath
6 months ago
Excellent service
Marianna Wong
6 months ago
Good
L W
6 months ago
everything excellent
Grace Ren
6 months ago
I would like to sincerely thank the team, especially Surkey, for her dedication and exceptional care.... From the moment I walked in, the staff were welcoming, friendly, and kind. Surkey was extremely professional, helpful, and truly went above and beyond during my eye test. I highly recommend her to anyone.
See more
cherry liang
6 months ago
Staffs are really helpful . Nice and kind
## Find an Optometrist in Glen Waverley
Close to areas including Vermont South, Mount Waverley and Notting Hill, our Oscar Wylee Glen Waverley store is located in The Glen Shopping Centre. Oscar Wylee Glen Waverley offers bulk billed eye tests for eligible Medicare cardholders to check vision and eye health as well as prescription updates. Once your eye test is completed, our dedicated retail staff can help you find a stylish pair of prescription or non-prescription glasses from our wide selection of vintage and modern-inspired frames. The Glen is a shopping centre in Victoria that can be reached by public transport or car with over 3,500 parking spaces that can be easily accessed. There are many shops to explore in The Glen including David Jones, Aldi and UNIQLO. Visit Oscar Wylee Glen Waverley today to experience some of the best optometry services in Glen Waverley, Australia.
Meet Our Team
* Optometrist Partner
O.D. BBiomed Therapeutically Endorsed
* Store Manager
Our Services
* Bulk Billed Eye Examinations
* Professional Frame Styling
* Frame Adjustments and Repairs
Show All
## Find an Optometrist in Glen Waverley, Melbourne for an Eye Health Test
An optometrist in Glen Waverley, Melbourne is a go-to destination for great eye health services such as an eye health test in Glen Waverley, prescription glasses, prescription sunglasses and more. Our optometrists are trained to diagnose a range of eye diseases and problems, so make sure to see us for professional optometry services. As part of Australia’s Medicare system, we provide our eye health and vision services at a bulk billed price and if your vision condition requires further assessment, we can refer you to an eye doctor. When you visit us in-store, you can receive help with all eye health-related concerns and even eyewear concerns thanks to our optical dispenser. The average price for an optometrist in Glen Waverley may depend on the number of other optometrists in the area, the facility they operate in and your vision requirements.
## How to Find an Optometrist in Glen Waverley, Melbourne?
To find an optometrist in Glen Waverley, Melbourne you can take certain steps that can help make it easier for you such as searching online, assessing the store’s opening hours and finding the directions to your chosen location. The steps on how to find an optometrist in Glen Waverley are listed below.
1. Search online using the phrase, Glen Waverley optometrist near me. This can also be done here on the website via our locations page.
2. Click on the Oscar Wylee link, which will take you directly to our Glen Waverley optometrist store page.
3. See the store’s opening hours and where the store is located specifically.
4. Use the Glen Waverley Google Business page link located under store hours to see the directions on how to get to the store.
You can also find an optometrist in Glen Waverley by searching the keywords optometrist near me. If you have locations enabled on your smartphone and you’re in the Glen Waverley area, our Glen Waverley store page should appear easily for you to click on.
### Is it Hard to Get an Eye Appointment in Glen Waverley, Melbourne?
No, it is not hard to get an eye appointment in Glen Waverley. You can easily book an appointment to see an Oscar Wylee optometrist in Glen Waverley right here on this page. At Oscar Wylee we have highly qualified optometrists available for bulk billed eye appointments, which can be booked online or in-store.
#### How to Compare Optometrists in Glen Waverley to Each Other?
To compare optometrists in Glen Waverley, you can use factors such as eye tests offered, health fund coverage, lens types and add-ons and eyewear offered. To take care of your vision and eye health, it is important to receive an eye test at least once every two years. There are different types of tests that can be performed in an eye test and not all optometrists may offer the same tests. Health funds can be used to help cover some of the cost of your frames and lenses. To find out if your health fund is accepted at Glen Waverley optometrist in Melbourne, visit their website. In the case of Oscar Wylee, we accept all major health funds and provide on-the-spot claims in-store. There are many different lens options available for prescription glasses such as single vision, multifocal and high index lenses. Most optometrists in Glen Waverley will offer these lenses although it is good to make sure. There are also lens add-ons available to enhance your glasses such as anti-reflective and blue light filters. Finally, if you are looking to purchase a pair of glasses after your eye test, you can compare the different styles and colours you are interested in from Glen Waverley optometrists in Melbourne. Oscar Wylee offers a wide range of frames with vintage and modern inspirations in bold colours and subtle designs.
#### How to Find an Eyeglasses Shop in Glen Waverley, Melbourne?
To find a glasses store in Glen Waverley, you can try to follow these simple steps including searching online, selecting a convenient location and looking at their health insurance policies. The steps on how to find a glasses store in Glen Waverley, Melbourne are listed below.
1. Search online using the phrase, glasses store in Glen Waverley. This will provide you with various options for glasses stores in the whole area of Glen Waverley.
2. Select a glasses store that is most convenient for you to travel to.
3. Click the link to find out more information such as opening hours, exact location and directions to the glasses store in Glen Waverley.
4. Read their health insurance policies to ensure you know what health benefits you have access to.
Our Oscar Wylee glasses store in Glen Waverley, Melbourne offers primary eye care services such as comprehensive eye tests as well as other services performed by an optometrist and offers prescription and non-prescription eyewear.
##### Is it Possible to Purchase Prescribed Sunglasses in Glen Waverley, Melbourne Without Seeing an Optometrist?
Yes and no, it is possible to [purchase prescribed sunglasses](https://www.oscarwylee.com.au/sunglasses.html) in Glen Waverley, Melbourne without seeing an optometrist if you already have a prescription that has not expired. If your prescription is expired, you can book an eye test to receive an updated or new prescription which will require you to see an optometrist. This will ensure your prescription sunglasses are appropriate for your visual needs.
## Where is the Oscar Wylee Glen Waverley Optometrist in Melbourne Located?
The Oscar Wylee Glen Waverley optometrist is located at The Glen Shopping Centre which is located at Springvale Road. You can find the Oscar Wylee Glen Waverley store near H&amp;M &amp; Target.
### What is the Phone Number of Oscar Wylee Glen Waverley Optometrist Store?
The Oscar Wylee Glen Waverley optometrist store phone number is (03) 7035 3821. You can contact the Oscar Wylee Glen Waverley store between the hours of 9 am and 5:30 pm on Monday, Tuesday, and Wednesday, on Thursdays and Fridays between 9 am and 9 pm, on Saturdays between 9 am and 5 pm and on Sundays between 10 am and 5 pm.
### What are the Reviews for Oscar Wylee Glen Waverley Optometrist in Melbourne?
There are currently no reviews for the Oscar Wylee Glen Waverley optometrist store. However, you can learn more about our Glen Waverley store here on our website or by visiting our team in-store.
#### What Treatments or Eye Care Processes are Done in the Oscar Wylee Glen Waverley Optometrist Location?
The treatments or eye care processes done in the Oscar Wylee Glen Waverley optometrist Melbourne location include a tonometry test, a slit lamp exam and a refraction test. Additional tests that may also be performed can include a dilated fundus exam. The treatments or eye-care processes that are done in the Oscar Wylee Glen Waverley optometrist Melbourne location are listed below.
* A Tonometry Test: An optometrist or optical dispenser will conduct a tonometry test which involves the use of a machine that will release small puffs of air into your eyes. This will assist with measuring pressure in the eye.
A Digital Photograph: An optometrist or optical dispenser
may take a digital photograph of your eye which can be kept on
record to use in future appointments to evaluate any changes to
your eye.

* Slit Lamp Test: A slit lamp test can be used to evaluate your eye health, by examining your cornea and iris which are the anterior and posterior of the eye.
* Refraction Test: During a refraction test, an optometrist will have you view an image through different lenses and ask you to confirm which helps you see the image clearer.
Visual Field Test: A visual field test can assist with
assessing your peripheral vision, which may be beneficial for
identifying any signs of glaucoma.

* Dilated Fundus Exam: A dilated fundus exam can help an optometrist assess your health in more detail by getting a clear view of the retina. This test is typically carried out for patients with diabetes and those who may be at risk of developing retinal damage.
## How Many Optometrists Exist in Glen Waverley, Melbourne?
Many optometrists exist in Glen Waverley, Melbourne to provide eye tests and glasses, including Oscar Wylee. The number of optometrists in Glen Waverley may be due to the number of residents in the area and the geographical size of the suburb. If you need essential eye services such as a comprehensive eye test, a wide selection of prescription eyewear and more, then choose Oscar Wylee as your first choice for optometry services.
### What are the Other Closest Optometrist Locations to Glen Waverley, Melbourne in Australia?
The other closest Oscar Wylee optometrist locations to Glen Waverley, Melbourne in Australia are  Forest Hill, Knox, Chadstone and Eastland. The other closest optometrist locations to Glen Waverley are listed below.
* Forest Hill:  Forest Hill is close to Glen Waverley with 5-6 km in between stores and is located at the Chase Shopping Centre. You can find the [Oscar Wylee Forest Hill](https://www.oscarwylee.com.au/locations/optometrist-forest-hill.html) store near Woolworths which is the perfect place to have your eyes tested regularly and receive professional eyecare advice and assistance.
* Knox:  Knox is close to Glen Waverley with 8 km in between stores and is located at the Westfield shopping centre at 425 Burwood Hwy. You can find the [Oscar Wylee Knox](https://www.oscarwylee.com.au/locations/optometrist-knox.html) store on level 1, opposite Specsavers. Here is where you can receive great eye health services to care for your vision and look and feel your best with fashionable frames.
* Chadstone:  Chadstone is close to Glen Waverley with 10 km in between stores and is located at the Chadstone Shopping Centre at 1341 Dandenong Road. The [Oscar Wylee Chadstone](https://www.oscarwylee.com.au/locations/optometrist-chadstone.html) store can be found near Culture Kings and offers essential optometry services to ensure your ocular health is in optimal condition. These include eye tests and prescription eyewear.
* Eastland:  Eastland is close to Glen Waverley with 14 km in between stores and is located at 175 Maroondah Highway. You can find the [Oscar Wylee Eastland](https://www.oscarwylee.com.au/locations/optometrist-eastland.html) store on level 1, near Medibank. Here, our optometrists can help you care for your vision with a comprehensive eye test or assistance with your prescription eyewear.
### Oscar Wylee Eye Tests in Glen Waverley
At Oscar Wylee Glen Waverley, eye tests are bulk billed for eligible Medicare cardholders and performed by our skilled and dedicated Oscar Wylee optometrists. Our trusted optometrists offer eye care processes such as checking your eye health for certain eye diseases, assessing your vision and providing an updated prescription if needed. With a new prescription, you can browse for a new pair of glasses and order them on the same day.
### Leading Health Funds Accepted at Oscar Wylee
Oscar Wylee Glen Waverley in The Glen accepts major health funds for those with a valid card, so remember to bring yours to your next eye health test. Our experts can help you navigate the ins and outs of your insurance as well as process your claim in-store or provide an on-the-spot quote for Oscar Wylee lenses and frames.
### Stylish Frames at Glen Waverley
Our expert staff at Oscar Wylee Glen Waverley are onsite to help customers find the perfect pair of glasses or sunglasses. No matter if you’re buying a pair of prescription glasses or prescription sunglasses, we’ve got you covered with modern and vintage-style frames at affordable prices. Come in-store to get professionally fitted and styled for frames where you can choose from our different lens options including blue light filters, multifocals and polarised sunglasses.
Book Appointment
[Call us: (03) 7035 3821](tel:(03) 7035 3821)
[Leave a Review!](https://g.page/r/CajpZ_j_SNuHEBM/review)