# Source: https://www.oscarwylee.com.au/eye-test-offer-for-international-students

# Eye Test Offer for International Students at Oscar Wylee
At Oscar Wylee, we make it easy for international students to prioritise
their eye health. You can visit a store near you for a free eye test
when you purchase any pair of glasses on the same day.*
When was your last eye test?
[Eye test near me](https://www.oscarwylee.com.au/booking)
To receive this offer, you will need to show a valid international ID
and student ID which will be checked by our friendly in-store staff.
They will be happy to answer any questions you may have about this
offer.
Once finished with your eye test, the fun begins! Browse and try on a
wide range of frames that have both vintage and modern inspirations. We
have frames of all sizes, colours and shapes, and expert stylists
in-store to help you find your perfect pair.
## Shop Glasses
Our frames are affordable and stylish, with a large selection of shapes
and sizes to fit any personality. They are custom-made for each person,
hand-assembled and hand checked in our labs. We ensure our glasses are
of the highest quality before they are presented to our customers.
[Women's Glasses](https://www.oscarwylee.com.au/glasses/collection/womens-glasses.html)
[Men's Glasses](https://www.oscarwylee.com.au/glasses/collection/mens-glasses.html)
[Women's Sunglasses](https://www.oscarwylee.com.au/sunglasses/collection/womens-sunglasses.html)
[Men's Sunglasses](https://www.oscarwylee.com.au/sunglasses/collection/mens-sunglasses.html)
.cta-1 {
margin-top: 40px;
padding-bottom: 40px;
border-bottom: 1px solid silver;
}
.cta-1 .cta-box-wrapper {
display: grid;
grid-template-columns: 1fr 1fr;
align-items: center;
}
.cta-1 .cta-img-box {
display: flex;
flex-direction: column;
align-items: flex-end;
}
.cta-1 .cta-box-wrapper .cta-img-box img {
width: 90%;
border-radius: 10px;
height: 310px;
object-fit: cover;
}
.cta-1 .cta-box-wrapper .cta-box .heading {
font-size: 22px;
font-weight: 700;
margin-bottom: 30px;
}
.cta-1 .cta-box-wrapper .cta-box .content {
font-size: 16px;
max-width: 550px;
}
.cta-1 .cta-box-wrapper .cta-box .btnOw {
max-width: 340px;
margin-top: 40px;
}
@media (max-width: 900px) {
.cta-1 .cta-box-wrapper .cta-img-box img {
width: 100%;
height: auto;
}
.cta-1 .cta-box-wrapper .cta-box {
margin-right: 10%;
}
}
@media (max-width: 480px) {
.cta-1 .cta-box-wrapper {
grid-template-columns: 1fr;
gap: 47px;
}
.cta-1 .cta-box-wrapper .cta-box .heading {
text-align: center;
}
.cta-1 .cta-box-wrapper .cta-box .content {
text-align: center;
}
.cta-1 .cta-box-wrapper .cta-box .btnOw {
max-width: 100%;
}
.cta-1 .cta-box-wrapper .cta-box {
margin-right: 0%;
}
}

Your Eyes Need Care Too!
Make your eye health a priority and book an eye test in-store or online.
[Book an eye test](https://www.oscarwylee.com.au/booking)
Visit the Team In-Store
Find an Oscar Wylee store near you and claim your free eye test with any
glasses purchased!
[Optometrist near me](https://www.oscarwylee.com.au/locations/full-store-list.html)
*Receive a free eye test at Oscar Wylee with any glasses purchased on the
same day. Offer per person. Can be withdrawn at any time. To qualify for
this offer you will need to show a valid international ID and student ID.