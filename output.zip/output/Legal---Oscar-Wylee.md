# Source: https://www.oscarwylee.com.au/legal.html

* [Terms and Conditions](https://www.oscarwylee.com.au/legal/terms-and-conditions.html)
* [Privacy Policy](https://www.oscarwylee.com.au/legal/privacy-policy.html)
* [Competition and Consumer Law Compliance Policy](https://www.oscarwylee.com.au/legal/compliance-policy.html)
* [Oscar Wylee Warranty](https://www.oscarwylee.com.au/legal/oscar-wylee-warranty.html)
* [Complaints Handling Policy](https://www.oscarwylee.com.au/legal/complaints-handling-policy.html)