# Source: https://www.oscarwylee.com.au/locations/optometrist-carindale.html

# Optometrist Carindale
Westfield Ground Level, Shop 12231151 Creek RoadCarindale QLD 4152
* Near Coles
Opening hours
Monday9:00am - 5:30pm
Tuesday9:00am - 5:30pm
Wednesday9:00am - 5:30pm
Thursday9:00am - 9:00pm
Friday9:00am - 5:30pm
Saturday9:00am - 5:00pm
Sunday10:00am - 4:00pm
*Store hours reflect local standard trading hours and exclude public holidays
[Visit our Carindale Google Business page for directions, reviews, and updates.](https://g.page/r/Ccf72IU9STXbEAE)
Book Appointment
[Call us: (07) 3194 7686](tel:(07) 3194 7686)
[Leave a Review!](https://g.page/r/Ccf72IU9STXbEAE/review)
Our Reviews
Karen Chan
22 hours ago
Professional optometrist given a thorough check and advice.  Staff are very helpful and patiently ad...vised different packages.  Will not hesitate to recommend to anyone
See more
Allie Hunt
2 days ago
The optometrist and staff who helped me were truly incredible. Can’t fault my experience!
Pa Tor
1 week ago
These guys were incredible. Thorough, kind and efficient. I was pretty amazed by how great the staff... were here at Carindale, after dealing with the staff at Capalaba. It seems as if Oscar Wylee only has the best.
See more
mary-anne ackland
2 weeks ago
Shona Wilson
3 weeks ago
Noelene Ryden
3 weeks ago
Margaret O'Malley
3 weeks ago
I really appreciate the staff and their expertise at Oscar Wylee Carindale. Friendly and professiona...l and I always leave feeling great. There is a reason I keep going back every 12 months ????
See more
Holly Gibson
4 weeks ago
I had a great experience with Daniel at the Carindale branch. I would highly recommend him and the r...est of the team.
See more
Gary G
4 weeks ago
The guys at Oscar Wylee are superb. Our optometrist Daniel was brilliant, professional and great at ...his job. Great range of frames at great pricing. Recommend them highly
See more
Kane Luhrmann
4 weeks ago
Daniel was awesome!
Made the whole experience so much better
Michael Whiley
1 month ago
Daniel was brilliant !
All staff on the day were fantastic and good at there job.
Kim Holley
1 month ago
Excellent facilities and staff. Even wonderful with children
michael paten
1 month ago
Daniel was my optometrist and he was fabulous. So enthusiastic, you can really tell he likes his job... and is passionate and thoughtful
See more
Robin Hibberd
1 month ago
Excellent customer service and very thorough eye exam. Thank you.
iris
1 month ago
Super friendly staff and a wide range of glasses for my distinctive eye shape!
Alice Gore
1 month ago
Peppa Piacun
1 month ago
Lovely staff and service. Great range of frames
Gabe Itch
1 month ago
Very refined styles. Good service. I like this place very much.
Fatima Arshie
1 month ago
I absolutely adore this place so much, truly such a kind and considerate environment everyone needs ...to experience!
See more
linh ngo
1 month ago
Oscar Wylee is hands down the best thing that happened to Carindale shopping center. All the glasses... made me feel so fierce and runway ready????. My vision obviously needed fixing and the staffs were so helpful with everything i felt bedazzled. They looked so professional using the high tech machineries on my eyes i was blessed. 100% would make going to Oscar Wylee a family tradition to promote eye health????
See more
Isabella Wright
1 month ago
The other day I walked in with my youngest daughter and she was very insecure about getting glasses ...but the staff were welcoming and made her feel confident trying on different styles of glasses!
See more
Vivienne Radcliffe
1 month ago
I’ve been recommended to go here for ages and I am so glad that I did because the Daniel and the tea...m are just so friendly. I wanted to take a minute to write this because a team member Ivy made the experience so nice and eased my anxiety about coming in for glasses. Thank you guys so much!
See more
Isla Craven
1 month ago
I have two pairs of prescription glasses from this establishment and I am amazed at the kindness and... care employees showed throughout the process. They made me feel at home and looked after and I would 100% recommend it to friends and family anytime.
See more
Amin Nassar
1 month ago
Daniel and the team are always amazing and friendly. Wouldn’t go anywhere else.
Joan Fowke
1 month ago
Martin Heymer
2 months ago
Always a great experience at the Carindale shop, staff are always friendly and helpful.
cayla wait
2 months ago
Dr An Nguyen is fantastic! He is thorough, very well-educated, friendly and has exceptional communic...ation skills. I feel very heard and comfortable managing my symptoms related to complex medical conditions with this provider.
See more
rubi zymon
2 months ago
Huge shoutout to the optometrist! He was incredibly kind, respectful, and genuinely welcoming from t...he moment I walked in. He took the time to explain everything clearly, made me feel comfortable throughout the appointment, and carried himself with a high level of professionalism. You can tell he really cares about his patients. Highly recommend!
See more
Sarah Stockton
2 months ago
I’ve been using Oscar Wylee for years. The Carindale store is fabulous. They are very attentive and ...my script is always perfect and helpful when choosing frames that suit me.
See more
Chrissie Swain
2 months ago
I walked in without an appointment and was given a time 40 mins ahead in which time I was able to ha...ve a thorough look at all the frame options that were offered. By the time I had my eye check, I had chosen the two I wanted. Your receptionist was very friendly and helpful and Christine the optometrist was very thorough and gave me great advice for my dry and tired eyes.
Thank you
See more
Jeremy Tan
2 months ago
The staff are extremely friendly and helpful. Our optometrist, Daniel was extremely professional and... thorough!
See more
Tricia Fraser
2 months ago
Not sure what I expected but the whole examination &amp; talking me thru it took only about 20mins. All ...the staff &amp; Daniel the Optometrist were so friendly &amp; professional. &amp; I got help not only from staff but fellow customers in store with choosing the glasses frames !! Would certainly recommend friends to visit this store.
See more
Renata Nantes
2 months ago
Really friendly and helpful staff
Taylah Scougall
3 months ago
Daniel was fantastic and I’d highly suggest if you need help getting glasses going to see him. He’s ...very friendly and makes you feel extremely comfortable. He’s very accommodating and lovely to speak to.
See more
Changa
3 months ago
Daniel and the staff we’re fantastic, very thorough and professional, highly recommend a visit
Rebecca McLean
3 months ago
Really great experience!! Explained everything really well, and I was in and out within 20
minutes
Carenne May
3 months ago
Very professional &amp; caring.
Thank you.
kiya nobbs
4 months ago
Excellent experience and service. 10/10 would recommend. Been having my eyes tested and getting my g...lasses from the Carindale store for years and will continue to go back.
See more
Debbie Griffith
4 months ago
Fab experience!!   20.4.26
We are actually over from England on holiday when we visited the store
So... impressed with the quality of the test, staff friendliness, professionalism and helpfulness.
Finally the choice of frames was excellent and we purchased five pairs between us talking advantage of the competitive prices and getting sunglasses as well.
Thanks to Alana and Daniel ????????
See more
brendan flack
4 months ago
Everyone. And I mean EVERYONE at this store is just SO GOD DAMN lovely. Andrea who did my eye test w...as so insanely sweet and softly spoken whilst still being professional. The rest of the team are so helpful and sweet to interact with. I have probably only been to the store about 5-10 times over the past 4 years, but they remember me by name. Basically be careful because you’ll fall in love with all the staff and then basically make up excuses to go see them. 10/10 service
See more
Lynette Matheson
4 months ago
Daniel is amazing. He is so kind, informative and helpful.
KARLA FURSMAN
4 months ago
Fantastic service from Daniel and Charlotte. Such an asset to your business.
Giannitta Kent
4 months ago
I live in a regional area and didn't have an appointment, but I was having trouble with a red and we...eping eye for a few weeks and when I asked for some advice the optometrist promptly checked my eye thoroughly and gave me a script for some eye drops.  I was really impressed with the quick attention I received.  My husband was also very impressed with his visit to get checked for new glasses.  I would thoroughly recommend this optometrist shop.
See more
michelle Corletto
5 months ago
Daniel, Maisie and the whole team are so informative, genuine, and caring. They cannot do enough for... you, always so helpful. Best service ever. I give them 5/5! Thank you team.
See more
Ree P
5 months ago
Tabea Werner
5 months ago
Great team at carindale, the optometrist was super helpful and listened to my concerns without being... dismissive which was extremely refreshing. He was very knowledgeable and explained things in easy to understand terms. I can't wait for my prism glasses, they will help me tremendously.
See more
Joel H
5 months ago
Very thorough and professional service
Kevin Young
5 months ago
Went to Oscar Wylee in Westfield Carindale for a an eye test recently and I have to say they were fa...ntastic. Very thorough test with a lot of details. Professional staff and I also copped a couple of amazing new lenses too! So many option! Highly recommended
See more
Emmy Albany
5 months ago
Kevin Davis
5 months ago
## Find an Optometrist in Carindale With Oscar Wylee
Located in the thick of Brisbane’s South Eastern suburbs, you can find our Oscar Wylee Carindale store at Westfield Carindale, near Coles. Take one of the many buses that service the centre, or utilise Westfield’s free 3-hour parking to make your appointment with us. Once here, our optometrists at Oscar Wylee Carindale carry out Medicare bulk billed eye tests for eye health and vision, and our store team members can help you find stylish and affordable glasses for prescription glasses or prescription sunglasses- all in the same day! 
If you have time after your appointment, why not explore the area. Carindale is surrounded by parks and reserves, with plenty of outdoor adventures to be had. There are dog parks and picnic grounds, or you could even have a go at disc golf, also known as frisbee golf, at Cadogan Street Park. If you live in the Belmont, Carina or Camp Hill areas, Oscar Wylee Carindale is your go-to for optometry needs as we have outstanding eye care processes and some of the best optometrists in Carindale.         
Meet Our Team
* Optometrist Partner
* Retail Partner
Our Services
* Bulk Billed Eye Examinations
* Professional Frame Styling
* Frame Adjustments and Repairs
* Visual Fields Testing
* Digital Retinal Scanning
Show All
## Find an Optometrist in Carindale, Brisbane for an Eye Health Test
Find an optometrist in Carindale, Brisbane for a regular eye health test and make eye care a priority. Choose Oscar Wylee Carindale for Medicare eye tests at a bulk billed price meaning there are no out-of-pocket costs for eligible cardholders. Oscar Wylee Carindale in Brisbane has skilled optometrists providing high-quality optometry services as well as a wide range of stylish frames available as optical glasses and prescription sunglasses. At our glasses store in Carindale, we have an optical dispenser that can provide professional frame styling and fitting
There’s no need to have an eye test with an eye doctor as our Oscar Wylee optometrists are qualified and trained to perform comprehensive eye tests. The procedure of an eye health test in Carindale typically involves checking eye movement and assessing a patient's vision and the health of the eyes which involves checking for any signs of eye diseases. The average price range for an optometrist in Carindale can vary depending on factors such as the patient’s overall health, age and visual needs.
## How to Find an Optometrist in Carindale, Brisbane?
To find an optometrist in Carindale, Brisbane, you can take certain steps that can help make it easier for you such as searching online, assessing the store’s opening hours and finding the directions to your chosen location. The steps on how to find an optometrist in Carindale are listed below.
1. Search online using the phrase, optometrist near me in Carindale. This can also be done here on the website via our locations page.
2. Click on the Oscar Wylee link, which will take you directly to our Carindale optometrist store page.
3. See the store’s opening hours and where the store is located specifically.
4. Use the Carindale Google Business page link located under store hours to see the directions on how to get to the store.
You can also find an optometrist in Carindale by searching the keywords optometrist near me. If you have locations enabled on your smartphone and you’re in the Carindale area, our Oscar Wylee Carindale store page should appear easily for you to click on.
### Is it Hard to Get an Eye Appointment in Carindale, Brisbane?
No, it is not hard to get an eye appointment in Carindale. You can easily book an appointment to see an Oscar Wylee optometrist in Carindale right here on this page. At Oscar Wylee we have highly qualified optometrists available for bulk billed eye appointments, which can be booked online or in-store.
#### How to Compare Optometrists in Carindale to Each Other?
To compare optometrists in Carindale, you can use factors such as eye tests offered, health fund coverage, lens types and add-ons and eyewear offered. To take care of your vision and eye health, it is important to receive an eye test at least once every two years. There are different types of tests that can be performed in an eye test and not all optometrists may offer the same tests. Health funds can be used to help cover some of the cost of your frames and lenses. To find out if your health fund is accepted at an optometrist in Carindale, visit their website. In the case of Oscar Wylee, we accept all major health funds and provide on-the-spot claims in-store. There are many different lens options available for prescription glasses such as single vision, multifocal and high index lenses. Most optometrists in Carindale will offer these lenses although it is good to make sure. There are also lens add-ons available to enhance your glasses such as anti-reflective and blue light filters. Finally, if you are looking to purchase a pair of glasses after your eye test, you can compare the different styles and colours you are interested in from the optometrists in Carindale, Brisbane. Oscar Wylee offers a wide range of frames with vintage and modern inspirations in bold colours and subtle designs.
#### How to Find an Eyeglasses Shop in Carindale, Brisbane?
To find a glasses store in Carindale, you can try to follow these simple steps including searching online, selecting a convenient location and looking at their health insurance policies. The steps on how to find a glasses store in Carindale, Brisbane are listed below.
1. Search online using the phrase, glasses store in Carindale. This will provide you with various options for glasses stores in the whole Carindale, Brisbane area.
2. Select a glasses store that is most convenient for you to travel to.
3. Click the link to find out more information such as opening hours, exact location and directions to the glasses store in Carindale.
4. Read their health insurance policies to ensure you know what health benefits you can access.
Our Oscar Wylee glasses store in Carindale, Brisbane offers primary eye care services such as comprehensive eye tests as well as other services performed by an optometrist and offers prescription and non-prescription eyewear.
##### Is it Possible to Purchase Prescribed Sunglasses in Carindale, Brisbane Without Seeing an Optometrist?
Yes and no, it is possible to [purchase prescribed sunglasses](https://www.oscarwylee.com.au/sunglasses.html) in Carindale, Brisbane without seeing an optometrist if you already have a prescription that has not expired. If your prescription is expired, you can book an eye test to receive an updated or new prescription which will require you to see an optometrist. This will ensure your prescription sunglasses are appropriate for your visual needs.
## Where is the Oscar Wylee Carindale Optometrist in Brisbane Located?
The Oscar Wylee Carindale optometrist is located in Carindale Westfield near Coles. The Carindale Westfield Shopping Centre is located in Brisbane’s South Eastern suburbs and is one of the largest shopping centres in Australia.
### What is the Phone Number of Oscar Wylee Carindale Optometrist Store?
The Oscar Wylee Carindale optometrist store phone number is [(07) 3194 7686](tel:(07) 3194 7686). You can contact the Oscar Wylee Carindale store between the hours of 9 am and 5:30 pm from Monday to Wednesday, 9 am and 9 pm on Thursdays, 9 am and 5:30 pm on Fridays, 9 am to 5 pm on Saturdays and 10 am and 4 pm on Sundays.
### What are the Reviews for Oscar Wylee Carindale Optometrist in Brisbane?
The many reviews for Oscar Wylee Carindale optometrist in Brisbane, left by our various customers can be found here on the website and online when you search for Oscar Wylee Carindale optometrist. The reviews for Oscar Wylee Carindale optometrist are listed below.
* Claire Spencer:  Dan, Maisie and the team are very professional, knowledgeable and helpful. The process was seamless, quick and very enjoyable. I will definitely be returning and highly recommend.
* Sarah Morgan-Shelley:  I had a really lovely experience at the Oscar Wylee store in Carindale recently. The optometrist was super informative and knowledgeable, and I found him to be very personable. The staff were really kind and helpful. Thanks team!
* Joe Riverstone:  Very professional and friendly service. We were a walk-in and got service straight away. Eye testing and new glasses. Very happy.
* Ashleigh Reardon:  Always a great experience. Super helpful and kind.
#### What Treatments or Eye Care Processes are Done in the Oscar Wylee Carindale Optometrist Location?
The treatments or eye care processes done in the Oscar Wylee Carindale optometrist Brisbane location include a tonometry test, a digital photograph, a slit lamp exam and a refraction test. Additional tests that may also be performed can include a visual field test and a dilated fundus exam. The treatments or eye-care processes that are done in the Oscar Wylee Carindale optometrist Brisbane location are listed below
* A Tonometry Test: An optometrist or optical dispenser will conduct a tonometry test which involves the use of a machine that will release small puffs of air into your eyes. This will assist with measuring pressure in the eye.
* A Digital Photograph: An optometrist or optical dispenser may take a digital photograph of your eye which can be kept on record to use in future appointments to evaluate any changes to your eye.
* Slit Lamp Test: A slit lamp test can be used to evaluate your eye health, by examining your cornea and iris which are the anterior and posterior of the eye.
* Refraction Test: During a refraction test, an optometrist will have you view an image through different lenses and ask you to confirm which helps you see the image clearer.
* Visual Field Test: A visual field test can assist with assessing your peripheral vision, which may be beneficial for identifying any signs of glaucoma.
* Dilated Fundus Exam: A dilated fundus exam can help an optometrist assess your health in more detail by getting a clear view of the retina. This test is typically carried out for patients with diabetes and those who may be at risk of developing retinal damage.
## How Many Optometrists Exist in Carindale, Brisbane?
There are many optometrists that exist in Carindale to provide eye tests and glasses, including Oscar Wylee. The amount of optometrists available in an area will typically depend on the population. At Oscar Wylee Carindale in Carindale Westfield, we offer excellent optometry services including eye tests performed by skilled optometrists using high-quality equipment. We also have a wide range of fashion-forward frames that customers can browse in a large selection of sizes and colours. If you’re looking for an optometrist in Carindale, choose Oscar Wylee and we will take care of your optometry and eyewear needs.
### What are the Other Closest Optometrist Locations to Carindale, Brisbane in Australia?
The other closest Oscar Wylee optometrist locations to Carindale in Australia are Mt Gravatt, Capalaba Park and Brisbane - Albert St. The locations and their distance from Carindale are listed below.
* Mt Gravatt:  Mt Gravatt is close to Carindale, around 7-8 km. The [Oscar Wylee Mt Gravatt](https://www.oscarwylee.com.au/locations/optometrist-mt-gravatt.html) store is located in Westfield Mt Gravatt shopping centre next to Specsavers. Oscar Wylee Mt Gravatt provides primary eye care processes including digital retinal scanning and visual field testing.
* Capalaba Park:  Capalaba Park is close to Carindale, around 10-11 km. The [Oscar Wylee Capalaba Park](https://www.oscarwylee.com.au/locations/optometrist-capalaba.html) store is located in the Capalaba Park Shopping Centre near Kmart. For bulk billed eye tests and on-trend frames, visit Oscar Wylee Capalaba Park.
* Brisbane - Albert St:  Albert St is close to Carindale, around 11-13 km. The [Oscar Wylee Brisbane - Albert St](https://www.oscarwylee.com.au/locations/optometrist-albert-st.html) store is located in the Brisbane CBD near Vans. Visit Oscar Wylee Brisbane - Albert St for your annual eye test and you can also browse our wide of fashion-forward frames.
### Have Your Eyesight Checked in Carindale
Our optometrists conduct comprehensive eye tests at our Oscar Wylee Carindale store. Just stop by Oscar Wylee Carindale, where we have trained optometrists doing eye health tests available for bulk billing for valid Medicare cardholders. You can get your prescription updated, eye health checked, and shop for a new pair of glasses all on the same day. Let our team at Oscar Wylee Carindale take care of your vision requirements through our quality eye care processes.
### Oscar Wylee Carindale Accepts Major Health Funds
Here at Oscar Wylee Carindale, we can process your health fund claim at our eyeglasses shop with a valid health fund card. Our Oscar Wylee Carindale team will endeavour to answer any questions about what you’re eligible for with your health fund. You don’t have to stress about the hardest parts of health insurance alone - here at Oscar Wylee Carindale, we’re here to ensure you get what you need at an affordable, competitive price.
### Fashion-Forward Styles at Affordable Prices
Oscar Wylee Carindale is committed to bringing out your best style. We’re offering modern and vintage-style frames for prescription glasses as well as prescription sunglasses. We provide outstanding eyecare processes and pride ourselves in caring for not only your in-store experience but also your vision health and style preferences. So come visit our Oscar Wylee store today to have a chat with the team in Carindale.
Book Appointment
[Call us: (07) 3194 7686](tel:(07) 3194 7686)
[Leave a Review!](https://g.page/r/Ccf72IU9STXbEAE/review)