# Source: https://www.oscarwylee.com.au/locations/optometrist-midland-gate.html

# Optometrist Midland Gate
Shop T086B, 274 Great Eastern Hwy
Midland, WA 6056

We’re moving to a new location in the centre near Kmart, and next to
Shaver Shop.If you’d like to visit us sooner, our closest locations
are:[Galleria Shopping Centre](https://www.oscarwylee.com.au/locations/optometrist-morley-galleria.html)
(21 minutes away)[Ellenbrook Central](https://www.oscarwylee.com.au/locations/optometrist-ellenbrook.html)
(24 minutes away)
Near Target

Opening hours
Monday9:00am - 5:30pm
Tuesday9:00am - 5:30pm
Wednesday9:00am - 5:30pm
Thursday9:00am - 7:00pm
Friday9:00am - 5:30pm
Saturday9:00am - 5:00pm
Sunday11:00am - 4:00pm
*Store hours reflect local standard trading hours and exclude public
holidays
Visit our Midland Gate Google Business page for directions,
reviews, and updates.

[Leave a Review!](https://g.page/r/Cd2QygutrSIzEBM/review)
Our Reviews
Jeramie Dadis
2 weeks ago
I love the lady who assist me, I forgot her name but she is so lovely and helpful.
J
3 weeks ago
Great service, great frames…
Marsha Murphy
1 month ago
tracey fitzgerald
1 month ago
The optometrist was very thorough and explained what happening with my eyes. Really happy with his m...anner. The lady that helped me choose my glasses was also very pleasant and I was happy with service that was given.
See more
Samantha Hart
1 month ago
Very informative with me as the parent, very patient and calm with my 9 year old child getting the t...est done. All staff very helpful and patient.
See more
Annemaree Long
1 month ago
Midland Oscar Wylee staff were so helpful and friendly. I was able to get an appointment from walkin...g in. Jason the optometrist was so professional. I recommend going there - excellent service !
See more
Kathy Anthony
2 months ago
Great experience friendly experienced assistant
Mk
2 months ago
I had a great experience with my eye test. The staff were friendly, professional, and very helpful t...hroughout the process. They made me feel comfortable and explained everything clearly. Highly recommend their service
See more
Bibiana Frost
2 months ago
A very good team. Miriam in particular is an asset to the company, extremely patient and kind with m...y mum when getting her glasses fitted. Thank you very much!
See more
Sarah de Groot
2 months ago
Easy to book, friendly staff, quality service.
Chris Heiss
2 months ago
Except service.  I walked in, appointment available, saw optometrist, sorted out my issues gave me h...ints &amp; tips &amp; checked my eyes.  Thankyou, can't recommend highly enough.
See more
Philip Bromberg
2 months ago
Very professional service
Aimee Kyle
3 months ago
Susan Ransome
3 months ago
A very positive experience.  My husband and I attended routine eye tests at Oscar Wylee in Midland G...ate.  We were very impressed with the service we received - both from the customer service sales representative and the optician.  A huge range of frames available for prescription glasses and excellent value for money.
See more
Samantha Whittle
4 months ago
My eye test at Oscar Wylee was a seamless experience.  The optometrist was very good at explaining e...verything. My only disappointment was the Oscar Wylee don't prescribe contact lenses and that was my main reason for the appointment. I now have to go elsewhere.
See more
Irene Darwood
4 months ago
Myrean Traupmann
4 months ago
Richi banipal
4 months ago
Mathew Capar
5 months ago
Chris Cuerden
5 months ago
Very happy with everything and thanks to Jason.
Boon Yao Hong
6 months ago
I just want to say the optometrist was very professional and showed his competence in carefully expl...aining the test results.
See more
Tijo k jose
6 months ago
david mcleod
6 months ago
i had a very good experience at the Midland Oscar Wylee shop.Lots of good assistance from the staff....
David.
See more
Peter Best
6 months ago
I had such a great experience at Oscar Wylee. From the moment I walked in, I was given a warm welcom...e and made to feel comfortable straight away. The team were professional yet very personal at the same time, which made the whole experience relaxed and enjoyable.
They really listened to my needs and concerns and were incredibly accommodating and understanding throughout the process. What stood out most was the time and effort they put into helping me choose my frames — it never felt like a quick sale. It was genuinely about finding what suited me best and what worked within my budget. I wouldn’t hesitate to recommend them to anyone. In my opinion, the surrounding competitors don’t even come close. Outstanding service all round
See more
Miller Sampson
6 months ago
The optometrist Aamir was absolutely fantastic. The most amazing assessment I've ever had and he was... extremely knowledgeable. He was friendly and professional. Very happy to recommend to friends and family, and I will definitely be coming back. Thank you Aamir. The ladies who served me and completed my order were amazing.
See more
Nicky Bushell
6 months ago
Great service, quick and professional. Grace helped me find the right glasses. The optometrist ident...ified some issues with my eyes I didn't know about, so now that's getting sorted ????
See more
Marianna Harris
6 months ago
Caroline Parnham
6 months ago
Very patient staff who explain everything as you go through the process.  Thank you
Rosemarie Alford
6 months ago
Staff at Midland WA were amazing I couldn’t have wished for better service, customer service was out...standing
See more
Greg Hubbard
6 months ago
Jeannette Van Zwam
7 months ago
Roy Muller
7 months ago
Prompt, professional and (fortunately) no Specsaver/OPSM jargon for add on sales and costs. One thin...g, advertising is a bit false, you can not put frame prices and pass them off as full spectacles prices when the lenses included almost doubles the bill.
See more
Kirsten Barrack
7 months ago
I went to Oscar Wylee for the first time yesterday and had the pleasure of being served by Grace.  I... have had problems finding frames I like in the past at other places, but Grace made the process super easy and fun.  Grace explained the differences between different frames and what would work best, was friendly, patient and professional.  I am actually looking forward to picking up my glasses in a few weeks.  Grace is a real asset to Oscar Wylee Midland Gate, and I would certainly recommend her to others.
The service provided by the optometrist was also top-notch.
See more
Carol Whiting
7 months ago
From the receptionist on to the initial testing personnel through to the optometrist giving the full... eye test I experienced warmth and caring.  A really good experience  .
See more
Mandy Crawford
8 months ago
Service was great, super friendly, very helpful. Totally efficient. My only complaint would be that ...there is no testing for contact lenses had I realise I would had to go somewhere else.
So can’t get a bulk billed test for that now
See more
Stephen Warren
8 months ago
Very thorough test was so.proffessional and the Girl at the counter who helped me with chosing glass...es was also very kind and conciderate ,highly recommended
See more
Tam Jetta
8 months ago
Very lovely staff, very helpful &amp; all round an easy process. Took advantage of the 3 for $249 range ...of beautiful frames ☺️
See more
Sue Challen
9 months ago
Excellent service from initial contact by phone, after I walked in, during the eye exam and at the f...inal step choosing frames. Highly recommend this service.
See more
Chloe ee
9 months ago
Wonderful experience. Every one was so kind.
Lucine Franklin
9 months ago
Dudley &amp; Colleen “D&amp;C” Blevins
9 months ago
Quinn was very helpful, patient and polite and resolved my issues with new prescription professional...ly
See more
William Gill
10 months ago
I had a great experience at Oscar Wylee! The service provided by the optometrist was excellent, and ...the staff were incredibly friendly and helpful. I definitely recommend a visit.
See more
Emma Hart
10 months ago
Had a great experience here in Midland Gate store. Quinn is an amazing employee who really took the ...time to ensure I was happy with the frames I purchased. The store has so many cool frames it was hard to choose - I’ve lost count of how many I tried on????
The eye test was done in a timely fashion with no waiting around.
I recommend this place as a newer player in the eyewear market.
See more
SETH BOTCHWAY
10 months ago
The optometrist is very understanding and experienced. Polite and customer experience was fantastic
Luznelly7
10 months ago
The team at Oscar Wylee Midland Gate were absolutely amazing!
They were so friendly right from the s...tart.
Making the booking was also very easy. My eye test was done efficiently and then I was given plenty of time to choose my frames.
The two front customer service ladies were great and took the time to explain everything to me. They made me feel very comfortable.
The store looks absolutely amazing and has such a great range of glasses to choose from.
I would highly recommend Oscar Wylee Midland Gate to everyone.
See more
Amanda cronje
10 months ago
Was very impressed  they were professional and friendly  price wise is really good
Ebony Matson
11 months ago
The sweetest, the new worker was lovely and helpful, every single worker there was amazing!!
Nikki Manlapaz
11 months ago
Sarah Wells
11 months ago
The male optometrist who I had was very thorough and knowledgeable and reassured me my eye health wa...s great and I didnt need to get stronger glasses. The lady helping me choose glasses was also amazing and patient helping me pick 3 glasses to suit my face shape. Will always come back to Midland Oscar Wylee and refer others
See more
patricia gray
11 months ago
Helpful people at Oscar Wylie. Thankyou. ????
## Find an Optometrist in Midland Gate With Oscar Wylee
Located in the Midland Gate Shopping Centre, our Oscar Wylee team
is ready to help with all your optometry needs. Next to Betts, our dedicated
optometrists are available to provide Medicare bulk billed eye tests. Our
friendly retail staff can also help you shop for a pair of our stylish and
affordable glasses. To make your appointment with us, you can take one of the
many buses that service the centre, or take the train to Midland Train Station
nearby. The centre also has free parking for up to 4
hours.
Why not make the most of your trip here and explore
the local area. Midland boasts an array of wineries, microbreweries and
award-winning restaurants to try out. You could also take a walk around the
stunning Coal Dam Park. If you live close to the Hazelmere or Woodbridge
areas, come in and see the team at Oscar Wylee Midland Gate!        
Meet Our Team
* Optometrist
B.Optom (Hons)
TPA Endorsed
* Retail Partner
Our Services
* Bulk
Billed Eye Examinations
* Professional Frame Styling
* Frame Adjustments and
Repairs
* Visual Fields Testing
* Digital Retinal Scanning
Show All
## Find an Optometrist in Midland Gate, Perth for an Eye Health Test
An optometrist in Midland Gate, Perth is where you can
experience high-quality in-store shopping for modern and vintage
frames for prescription glasses as well as prescription
sunglasses. We can help you care for your eye health with an eye
health test in Midland Gate, which helps us look for any signs
of eye diseases so we can put the best treatment plan together
for you. If you require assistance with any adjustments or any
general questions, our optical dispenser in-store is available
to assist you.
Courtesy of Australia’s Medicare system, we can provide our eye
health and vision services at a bulk billed price and if your
condition requires further assessment, we can even refer you to
an eye doctor in Midland. The average price for an optometrist
in Midland Gate may depend on the number of other optometrists
in the area, the building they operate in and your vision
requirements.
## How to Find an Optometrist in Midland Gate, Perth?
To find an optometrist in Midland Gate, Perth, you can take
certain steps that can help make it easier for you such as
searching online, assessing the store’s opening hours and
finding the directions to your chosen location.
The steps on how to find an optometrist in Midland Gate are
listed below.
1. Search online using the phrase, Midland Gate optometrist near
me. This can also be done here on the website via our
locations page.
2. Click on the Oscar Wylee link, which will take you directly to
our Midland Gate optometrist store page.
3. See the store’s opening hours and where the store is located
specifically.
4. Use the Midland Gate Google Business page link located under
store hours to see the directions on how to get to the store.
You can also find an optometrist in Midland Gate by searching
the keywords optometrist near me. If you have locations enabled
on your smartphone and you’re in the Midland Gate area, our
Midland Gate store page should appear easily for you to click
on.
### Is it Hard to Get an Eye Appointment in Midland Gate, Perth?
No, it is not hard to get an eye appointment in Midland Gate.
You can easily book an appointment to see an Oscar Wylee
optometrist in Midland Gate right here on this page. At Oscar
Wylee we have highly qualified optometrists available for bulk
billed eye appointments, which can be booked online or in-store.
#### How to Compare Optometrists in Midland Gate to Each Other?
To compare optometrists in Midland Gate, you can use factors
such as eye
tests offered, health fund coverage, lens types and add-ons
and eyewear offered.
To take care of your vision and eye health, it is important to
receive an eye test at least once every two years. There are
different types of tests that can be performed in an eye test
and not all optometrists may offer the same tests. Health funds
can be used to help cover some of the cost of your frames and
lenses. To find out if your health fund is accepted at Midland
Gate optometrist in Perth, visit their website. In the case of
Oscar Wylee, we accept all major health funds and provide
on-the-spot claims in-store. There are many different lens
options available for prescription glasses such as single
vision, multifocal and high index lenses. Most optometrists in
Midland Gate will offer these lenses although it is good to make
sure. There are also lens add-ons available to enhance your
glasses such as anti-reflective and blue light filters. Finally,
if you are looking to purchase a pair of glasses after your eye
test, you can compare the different styles and colours you are
interested in from Midland Gate optometrists in Perth. Oscar
Wylee offers a wide range of frames with vintage and modern
inspirations in bold colours and subtle designs.
#### How to Find an Eyeglasses Shop in Midland Gate, Perth?
To find a glasses store in Midland Gate, you can try to follow
these simple steps including
searching online, selecting a convenient location and looking
at their health insurance policies.
The steps on how to find a glasses store in Midland Gate, Perth
are listed below.
1. Search online using the phrase, glasses store in Midland Gate.
This will provide you with various options for glasses stores
in the whole area of Midland Gate.
2. Select a glasses store that is most convenient for you to
travel to.
3. Click the link to find out more information such as opening
hours, exact location and directions to the glasses store in
Midland Gate.
4. Read their health insurance policies to ensure you know what
health benefits you have access to.
Our Oscar Wylee glasses store in Midland Gate, Perth offers
primary eye care services such as comprehensive eye tests as
well as other services performed by an optometrist and offers
prescription and non-prescription eyewear.
##### Is it Possible to Purchase Prescribed Sunglasses in Midland Gate,
Perth Without Seeing an Optometrist?
Yes and no, it is possible to
[purchase prescribed sunglasses](https://www.oscarwylee.com.au/sunglasses.html)
in Midland Gate, Perth without seeing an optometrist if you
already have a prescription that has not expired. If your
prescription is expired, you can book an eye test to receive an
updated or new prescription which will require you to see an
optometrist. This will ensure your prescription sunglasses are
appropriate for your visual needs.
## Where is the Oscar Wylee Midland Gate Optometrist in Perth
Located?
The Oscar Wylee Midland Gate optometrist is located at the
Midland Gate Shopping Centre which is located at 274 Great
Eastern Highway. The Oscar Wylee Midland Gate store can be found
near Target.
What is the Phone Number of Oscar Wylee Midland Gate Optometrist
Store?
The Oscar Wylee Midland Gate optometrist store phone number is
(08) 6113 5316. You can contact the Oscar Wylee Midland Gate
store between the hours of 9 am and 5:30 pm on Monday, Tuesday,
Wednesday and Friday, on Thursdays between 9 am and 8 pm, on
Saturdays between 9 am and 5 pm and on Sundays between 11 am and
4 pm.

### What are the Reviews for Oscar Wylee Midland Gate Optometrist in
Perth?
The many reviews for Oscar Wylee Midland Gate optometrist in
Perth, left by our various customers can be found here on the
website and online when you search for Oscar Wylee Midland Gate
optometrist. The reviews for Oscar Wylee Midland Gate
optometrist are listed below.
* Nancy Sharp:  Thank you. Very helpful and informative.
* Karanpreet Virk:  Staff is amazing and helpful.
* Lorena Rose:  Great selection of frames and good
pricing. Very happy with the service received. All staff are
very welcoming and professional.
* Ranee Footer:  Wonderful experience at the Midland
store. Very helpful indeed! A special shout out to the
optometrist who is a true professional! Thank you. Looking
forward to receiving my glasses!
#### What Treatments or Eye Care Processes are Done in the Oscar Wylee
Midland Gate Optometrist Location?
The treatments or eye care processes done in the Oscar Wylee
Midland Gate optometrist Perth location include
a tonometry test, a digital photograph, a slit lamp exam and
a refraction test.
Additional tests that may also be performed can include
a visual field test and a dilated fundus exam. The
treatments or eye-care processes that are done in the Oscar
Wylee Midland Gate optometrist Perth location are listed below.
* A Tonometry Test: An optometrist or optical dispenser
will conduct a tonometry test which involves the use of a
machine that will release small puffs of air into your eyes.
This will assist with measuring pressure in the eye.
* A Digital Photograph:  An optometrist or optical
dispenser may take a digital photograph of your eye which can
be kept on record to use in future appointments to evaluate
any changes to your eye.
* Slit Lamp Test: A slit lamp test can be used to
evaluate your eye health, by examining your cornea and iris
which are the anterior and posterior of the eye.
* Refraction Test: During a refraction test, an
optometrist will have you view an image through different
lenses and ask you to confirm which helps you see the image
clearer.
* Visual Field Test: A visual field test can assist with
assessing your peripheral vision, which may be beneficial for
identifying any signs of glaucoma.
* Dilated Fundus Exam: A dilated fundus exam can help an
optometrist assess your health in more detail by getting a
clear view of the retina. This test is typically carried out
for patients with diabetes and those who may be at risk of
developing retinal damage.
## How Many Optometrists Exist in Midland Gate, Perth?
Many optometrists exist in Midland Gate, Perth, to provide eye
tests and glasses, including Oscar Wylee. The number of
optometrists in Midland Gate may be due to the number of
residents in the area and the geographical size of the suburb.
If you need essential eye services such as a comprehensive eye
test, a wide selection of prescription eyewear and more, then
choose Oscar Wylee as your first choice for optometry services.
### What are the Other Closest Optometrist Locations to Midland Gate,
Perth in Australia?
The other closest Oscar Wylee optometrist locations to Midland
Gate, Perth Australia are
Morley Galleria and Carousel. Morley Galleria is close to
Midland Gate with 12-18 km in between stores. You can find the
[Oscar Wylee Morley Galleria](https://www.oscarwylee.com.au/locations/optometrist-morley-galleria.html)
store on the ground floor opposite OPSM and can receive Oscar
Wylee’s signature high-quality service and care. Carousel is
close to Midland Gate with 21-23 km in between stores and is
located at 1382 Albany Highway. You can find the
[Oscar Wylee Carousel](https://www.oscarwylee.com.au/locations/optometrist-carousel.html)
store on the ground level of the Westfield shopping centre,
which can be found near Dusk. Here, you can get your eyes tested
at a bulk billed price and have access to an abundant selection
of fashionable frames.
### Check Your Eyesight with our Oscar Wylee Optometrists
Stop by Oscar Wylee in Midland Gate Shopping Centre for high-quality
eye care processes, carried out by our dedicated and passionate
optometrists. Equipped with the latest optometry equipment, our
optometrists can provide eye health tests where they will check for
possible eye diseases or conditions and assess vision. For some of the
best optometrists in Midland, Australia, visit Oscar Wylee!
### Oscar Wylee Accepts Major Health Funds
Here at our Oscar Wylee eyeglasses shop in Midland Gate, our team can
process your health fund claim in-store with a valid health fund card.
We'll help answer any questions about what you’re eligible for with
your health fund at Oscar Wylee. You don’t have to navigate the
hardest parts of health insurance alone - here at Oscar Wylee Midland
Gate, our team is dedicated to ensuring all our customers get the most
out of their experience with us.
### Fashionable Frames at Affordable Prices with Oscar Wylee
Oscar Wylee is committed to ensuring our customers get the eyewear
they need. Oscar Wylee Midland Gate offers a range of frames in
various styles, sizes and colours. Oscar Wylee carries prescription
glasses, prescription sunglasses, and non-prescription glasses.
Whatever eyewear you need, our Oscar Wylee experts in-store are ready
and able to help you find the perfect pair!
[Leave a Review!](https://g.page/r/Cd2QygutrSIzEBM/review)