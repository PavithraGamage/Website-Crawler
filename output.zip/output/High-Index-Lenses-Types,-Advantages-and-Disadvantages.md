# Source: https://www.oscarwylee.com.au/glasses/eye/high-index-lenses

# High Index Lenses: Types, Advantages and Disadvantages
Published on November 6th, 2023
Updated on May 15th, 2026
Australia
[Australia](https://www.oscarwylee.com.au/glasses/eye/high-index-lenses)


New Zealand

[Canada](https://oscarwylee.ca/glasses/eye/high-index-lenses)


Canadian French

High index lenses are light and thin glasses lenses designed for people with strong or high prescriptions. High index lenses are made with a special plastic material that makes them more expensive than normal lenses. The advantages of high index lenses include they are lighter and thinner than standard lenses, are versatile and are aesthetically pleasing. The disadvantages include they are scratch-prone, are more expensive and high index lenses may reflect more light. High index lenses come in different lens indexes which include 1.60 lens index, 1.67 lens index and 1.74 lens index. High index lenses are available for most types of lenses including single vision lenses, bifocal lenses and multifocal lenses. Keep reading to learn more about high index glasses, what they are and how they work.
Need Your Eyes Checked?
At Oscar Wylee we offer bulk billed eye tests for all eligible Medicare cardholders.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Definition](#Definition) [Types](#Types) [Advantages](#Advantages) [Disadvantages](#Disadvantages)
## What are High Index Lenses?
A high index lens is a glasses lens designed for people with strong or high prescriptions and is thin and light, providing clear and comfortable vision. The higher the index, the lighter and thinner the lens will be. At Oscar Wylee, we offer high index lenses in a 1.6 index, 1.67 index and 1.74 index. 1.6 index lenses are recommended for prescriptions up to +/- 3 diopters, 1.67 index lenses are recommended for prescriptions up to +/- 4 diopters and 1.74 index lenses are recommended for those with +/-4 diopters and above. In summary, the answer to what are high index lenses, is they are thin and light lenses made for people who have high prescriptions.
### Do I Need High Index Lenses?
An optometrist will let you know if you need high index lenses. Typically, a person with a moderate to high eye prescription may need high index lenses. Prescription lenses are typically worn by those who have refractive errors that need correcting such as [myopia](https://www.oscarwylee.com.au/glasses/eye/nearsightedness), hyperopia and astigmatism. At Oscar Wylee, we offer three types of high index lenses,&nbsp; 1.6 index lens which is recommended for prescriptions up to +/- 3 diopters, 1.67 index lens which is recommended for prescriptions up to +/- 4 diopters and 1.74 index which is ideal for all prescriptions but is recommended for those with +/-4 diopters and above. If you are unsure what lenses are right for you and your eyesight needs, talk to an optometrist or optical dispenser.
### How Does the Refractive Index Relate to High Index Lenses?
The refractive index is a measure of the bending of light when it passes through one medium to another, according to Britannica. In terms of high index lenses, the refractive index refers to how efficiently the lens bends light and the time light takes to travel through the lens material. The standard refractive index of lenses is 1.50. The higher the lens index number, the thinner the lens will be, according to Optometrists.org.
### What are the Different Types of High Index Lenses?
There are three main types of high index lenses designed to provide clear and comfortable vision for people with high prescriptions. The different types of high index lenses are 1.60 high index lenses, 1.67 high index lenses and 1.74 high index lenses. These three high index lenses and their definitions are listed below.
* 1.60 high index lens: 1.60 high index lenses are thin and light lenses that are available for glasses. 1.60 index lenses are designed for people with moderate to high prescriptions.
* 1.67 high index lens: A 1.67 high index lens is a very thin and light lens that is available for glasses. 1.67 index lenses are designed for those with high prescriptions.
* 1.74 high index lens: 1.74 high index lenses are generally the thinnest and lightest lens options available for glasses. 1.74 index lenses are designed for people with very high prescriptions.
#### 1. 1.60 High Index Lens
1.60 high index lenses are thin and light lenses that are available for glasses. 1.60 index lenses are designed for people with moderate to high prescriptions to correct certain refractive errors including myopia, hyperopia and astigmatism. For those with high prescriptions, it is recommended to use 1.67 high index lenses and for those with very high prescriptions, 1.74 is the thinnest high index lenses on offer. At Oscar Wylee, we offer 1.60 high index lenses which are our thin lenses. The 1.60 index lens is recommended for prescriptions up to +/- 3 diopters.
#### 2. 1.67 High Index Lens
A 1.67 high index lens is a very thin and light lens that is available for glasses. 1.67 index lenses are designed for those with high prescriptions to correct refractive errors such as astigmatism, hyperopia and myopia. For those with very high prescriptions, it is recommended to use 1.74 high index lenses, which are generally the thinnest available for optical glasses. At Oscar Wylee, we offer 1.67 high index lenses which are our middle, thinner lenses. The 1.67 index lens is recommended for prescriptions up to +/- 4 diopters.
#### 3. 1.74 High Index Lens
1.74 high index lenses are generally the thinnest and lightest lens options available for glasses. 1.74 index lenses are designed for people with very high or severe prescriptions which may mean they have a high-level refractive error including myopia, hyperopia and astigmatism. These lenses work by bending light very efficiently so that the material the lens is made out of can be very thin and therefore, very light. At Oscar Wylee, we offer 1.74 high index lenses which are our thinnest lenses. The 1.74 index lens is ideal for all prescriptions but is recommended for those with +/-4 diopters and above.
### How Much Do High Index Lenses Cost?
How much high Index lens glasses cost can vary depending on the company, however, they are typically more expensive than standard lenses. At Oscar Wylee, we offer three types of high index lenses, 1.61 index, 1.67 index and 1.74 index. Our thin lens, 1.61 index is an additional $110 on top of the price of our standard frames. Our thinner lens, 1.67 index is an additional $160 and our thinnest lens, 1.74 index is an additional $260. These high index lenses include free Basic Anti-Reflective coating.
### What are High Index Lenses Made Of?
High index lenses are made of a special type of plastic which is lighter and thinner than standard lenses. High index lenses typically undergo a specific manufacturing process that ensures there is a high refractive index. Some high index lenses may be made from glass, although glass is not a popular choice for lens material.
Visit a Store Near You
We have highly qualified teams in every store dedicated to helping with your eye care and eyewear needs.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
## What are the Advantages of High Index Lenses?
There are many advantages of high index lenses that make them a great option for people with strong or high prescriptions. The advantages of high index lenses include they are lighter and thinner than standard lenses, are versatile and are more aesthetically pleasing. The advantages of these lenses and their definitions are listed below.
* Lighter and thinner: The main advantage of high index lenses is that they are lighter and thinner than normal optical glasses, making them more comfortable to wear. High index lenses are able to be light and thin as they are made out of a special, more dense plastic.
* Versatile: High index lenses are versatile as they can be used in a number of lens types such as single vision lenses, multifocal lenses and bifocal lenses. This means no matter your prescription needs, you can get the lenses that are best for you and your lifestyle.
* Aesthetically pleasing: High index lenses are aesthetically pleasing as they reduce the magnification and minification of the eyes, meaning they won’t give the wearer a bug-eyed look that some thicker lenses can produce.
### When Should You Consider High Index Lenses?
You should consider high index lenses if you have or will be moving to a higher prescription for your glasses. According to Optometry, higher prescriptions tend to mean thicker and heavier to lenses, to help direct light and correct a higher refractive error. High index lenses are ideal for people with strong prescriptions as the lenses will be lighter and thinner for comfortable wear. An optometrist or optical dispenser will suggest the best lenses for your prescription needs, whether that is normal lenses or high index lenses.
## What are the Disadvantages of High Index Lenses?
High index lenses have many advantages, such as being light, thin and versatile, but they also have disadvantages. The disadvantages of high index lenses are that they may be more scratch-prone, are typically more expensive than standard lenses, and they can reflect more light. At Oscar Wylee, our high-index lenses include a complimentary anti-reflective coating to help reduce reflections. The disadvantages of these lenses and their definitions are listed below.
* Scratch-prone: High index lenses are more scratch-prone than normal lenses; however, this can be helped by adding a scratch-resistant coating to the lenses.
* More expensive: Typically, high index lenses are more expensive than standard lenses as they are made with a special material.
* Reflect more light: High index lenses can be more reflective of light, which may make them harder to use during brightly lit work.
### Can you Get Photochromic Lenses with High Index Lenses?
Yes, high index lenses will generally be able to also carry a photochromic tint or coating. Photochromic lenses are a type of prescription glasses lens that change from clear to a dark tint when exposed to UV rays from the sun. [Photochromic lenses](https://www.oscarwylee.com.au/glasses/eye/photochromic-lenses) usually work by having a chemical embedded or coated onto the lens.
### When Did High Index Lenses Come Out?
High index lenses became a popular lens choice in the 1980s, according to the American Academy of Ophthalmology, but had been an idea in progress years prior. According to Pillay, Hansraj and Rampersad in the National Library of Medicine, thinner lenses of high refractive index had started to be created with materials such as alkaline metal oxides, however, these materials led to chromatic aberrations and made glasses heavier.
#### Is 1.74 the Thinnest Lens?
Yes, 1.74 is generally the thinnest lens available for prescription glasses. 1.74 index lenses are designed for very high prescriptions, and will help make lenses lighter and more comfortable to wear.
#### Is 1.50 Astigmatism High?
1.50 astigmatism is a high level of astigmatism and will usually require some form of correction, such as [prescription glasses](https://www.oscarwylee.com.au/glasses/eyewear-for-astigmatism) or contact lenses for clear vision, according to the American Academy of Ophthalmology.
#### Can you Have High-Index Lenses in Sunglasses?
Yes, you can generally have a high index lenses in [prescription sunglasses](https://www.oscarwylee.com.au/glasses/eye/sunglasses). Sunglasses can come in a variety of forms including with a tint, with polarised lenses or photochromic lenses. Most will be placed over the lens as a coating, or made within the lens.
Read High Index Lenses: Types, Advantages and Disadvantages in other Oscar Wylee regions and their languages.
Australia
[Australia](https://www.oscarwylee.com.au/glasses/eye/high-index-lenses)


New Zealand

[Canada](https://oscarwylee.ca/glasses/eye/high-index-lenses)


Canadian French

Ready to Book an Eye Test?
We recommend everyone has a complete eye test at least once every two years. Book yours today with Oscar Wylee.
[Book an eye test](https://www.oscarwylee.com.au/booking)
Major Health Funds Accepted
For the purchase of frames and lenses, use your private health fund insurance to limit how much you pay from your own pocket.
[Discover Health funds](https://www.oscarwylee.com.au/health-funds.html)