# Source: https://www.oscarwylee.com.au/glasses/eye/single-vision-lenses

# Single Vision Lenses: Definition, How it Works, Purpose, and Benefits
Published on September 14th, 2023
Updated on July 21st, 2025
Australia   
[Australia](https://www.oscarwylee.com.au/glasses/eye/single-vision-lenses)
New Zealand

[Canada](https://oscarwylee.ca/glasses/eye/single-vision-lenses)
Canadian French

Single vision lenses are a type of prescription lens that are worn to correct vision issues such as nearsightedness (myopia) or farsightedness (hyperopia). There are two main types of single vision lenses, concave and convex lenses, which are used to correct nearsightedness and farsightedness respectively. Glasses with a single vision lens can be worn to correct refractive errors which include astigmatism, presbyopia, hyperopia and myopia. Single vision lenses for near vision are also known as readers and are commonly prescribed to people over the age of 40. Single vision means the glasses only correct one vision issue, unlike bifocals or multifocals, which can correct multiple vision issues in one lens. Keep reading to learn more about how single vision lenses work, their purpose and the many benefits they provide.
Book an Eye Test at Oscar Wylee
Have your regular eye check-up with our skilled and friendly optometrists and receive bulk billing if you have an eligible Medicare card.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Definition](#definition) [Types of Single-Vision Lenses](#types) [Related Vision Conditions](#conditions) [When to Replace Your Glasses](#repair)
## What Are Single Vision Lenses?
A single vision lens is a type of prescription glasses lens containing one power, or prescription, over the whole surface of the lens. They are prescribed by an optometrist to correct refractive errors such as hyperopia, myopia, astigmatism and presbyopia. Another term for single vision lenses is reading glasses which correct near vision, making tasks such as reading and knitting clearer. Single vision lenses can contain convex or concave lenses, depending on the refractive error that is being corrected. In summary the answer to what are single vision lenses is; they are a kind of optical glasses that contain a single prescription over the whole lens.
## How do Single Vision Lenses Work?
Single vision lenses work by refracting light onto the retina using either a concave or convex lens, depending on the vision issue that is being corrected. A concave lens is used for a person who has myopia (nearsightedness) and a convex lens is used for hyperopia (farsightedness). A person with a degree of astigmatism will have a cylindrical correction added to the lens which is equal but opposite to the amount of astigmatism present. A single vision lens only contains one prescription throughout the entire lens, meaning if you have issues with both near and far vision, you will need two pairs of single vision glasses or a pair of bifocals or multifocals.
## What is the Primary Purpose of a Single Vision Lens?
The primary purpose of single vision lenses is to correct a person's vision, almost always to correct a refractive error. A refractive error is a type of vision issue that causes blurred vision due to an abnormally shaped eyeball that causes light to bend improperly, according to HealthDirect. Refractive errors include astigmatism, presbyopia, hyperopia and myopia. Single vision lenses for near vision are also known as readers which, as the name suggests, can make close tasks such as reading or writing easier. In summary, the primary purpose of single vision lenses is to give the wearer clear and comfortable vision.
### Can Single-Vision Glasses be Worn for Driving?
Yes, single vision glasses can be worn for driving as they can help people with blurry vision see things in the distance such as road signs, obstacles and other cars. A person who is nearsighted will have difficulty seeing things far away, which is known as myopia and will need glasses with a concave lens to make sure light is directed onto the retina, providing clear vision. Another type of lens that can be used when driving is an anti-reflective lens or coating. This coating can reduce glare from streetlights and headlights, making driving easier.
## What are the Different Types of Single Vision Lenses?
There are two main types of single vision lenses that are chosen based on the patient's prescription needs. The different types of single vision lenses are concave lenses and convex lenses. These types and their definitions are listed below.
* Concave lens: Concave lenses are a type of lens used in glasses to correct nearsightedness (myopia). These lenses are shaped inwards at the centre and bulge outwards towards the edges.
* Convex lens: Convex lenses are a type of lens used in glasses to correct farsightedness (hyperopia). These lenses are thinner at the edges and thicker in the middle.
### 1. Concave Lens
Concave lenses are a type of lens used in glasses to correct nearsightedness (myopia). These lenses are shaped inwards at the centre and bulge outwards towards the edges. If a person has nearsightedness, light that enters the eye refracts before the retina, not on the retina as normal, leading to blurred vision when looking at objects in the distance. According to Canon Global, concave lenses correct nearsightedness by reducing the refraction of light which then lengthens the focal length, creating clear vision.
### 2. Convex Lens
Convex lenses are a type of lens used in glasses to correct farsightedness (hyperopia). These lenses are thinner at the edges and thicker in the middle. If a person has farsightedness, light that enters the eye refracts behind the retina, not on the retina as normal. According to Canon Global, convex lenses correct farsightedness by increasing refraction which subsequently reduces focal length and restores clear vision.
### What is 1.50 Single Vision Index Lenses?
At Oscar Wylee, 1.50 single vision index lenses are our standard, entry-level lens for those with a mild to moderate prescription. These lenses are recommended for prescriptions up to +/- 2 diopters.
### What is 1.60 Single Vision Index Lenses?
At Oscar Wylee, 1.60 single vision index lenses are ideal for people who have a moderate prescription. 1.60 index lenses are recommended for prescriptions up to +/- 3 diopters.
### What is 1.67 Single Vision Index Lenses?
At Oscar Wylee, 1.67 single vision index lenses are ideal for people who have a strong prescription. 1.67 index lenses are recommended for prescriptions up to +/- 4 diopters.
1.74 Single Vision Index Lenses are high index and generally the thinnest and lightest lens options available for glasses. 1.74 single vision index lenses are designed for people with very high prescriptions.
Need a Pair of Single Vision Glasses?
Visit us in-store for an eye test and afterwards you can browse our wide selection of frames for your new glasses.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
## How to Know if You Need Single Vision Lenses?
To definitively know if you need single vision lenses, you will need to visit an optometrist for an eye test. They will assess your vision using a visual acuity test and also check your eye health using various tests. If you need vision correction, the optometrist will provide you with a prescription with all the necessary information for you to buy a pair of prescription glasses. Single vision lenses are typically prescribed to patients with a refractive error such as hyperopia, myopia, presbyopia and astigmatism. If a person has issues with both near and far vision, they are more likely to be prescribed bifocals or multifocals as they can correct these problems in one pair of glasses.
### What Vision Conditions do Single Vision Lenses Correct?
Single vision lenses help correct vision conditions such as myopia (nearsightedness), hyperopia (farsightedness) and astigmatism. The vision conditions that single vision lenses can help correct are listed below.
* Myopia: Myopia, also known as nearsightedness, is a refractive error that causes a person's distance vision to be blurry. Myopia commonly stems from a misshapen cornea or lens.
* Hyperopia: Hyperopia, also known as farsightedness, is a refractive error where light enters the eye incorrectly, focusing behind the retina instead of directly on it, which leads to blurry near vision.
* Astigmatism: Astigmatism is a refractive error caused by a misshapen or deformed eyeball, which disrupts the eye's ability to focus light onto the retina, resulting in blurry vision.
#### Myopia
Myopia, also known as nearsightedness, is a refractive error that causes a person's distance vision to be blurry. [Myopia](https://www.oscarwylee.com.au/glasses/eye/nearsightedness) is commonly caused by a misshapen eye, which can be an overly curved cornea or an elongated eyeball. The symptoms of myopia include frequent squinting to see clearly, eye strain, objects in the distance appearing fuzzy or blurry, eye fatigue and headaches. The kind of single vision lenses used to correct nearsightedness are concave lenses, which correct the focal issues, giving the wearer clear and comfortable vision. People may be more at risk of nearsightedness due to genetics or family history, age, extended close-up activities, diabetes, environmental factors, recurring visual stress, long-term use of devices and spending less time outside, according to Mivision (2023).
#### Hyperopia
Hyperopia, also known as farsightedness, is a refractive error where light enters the eye incorrectly to focus behind the retina instead of on the retina, which leads to blurry near vision. [Hyperopia](https://www.oscarwylee.com.au/glasses/eye/hyperopia) symptoms include trouble with close-up vision, eye strain, squinting and headaches, and it can be treated with corrective devices such as contact lenses or prescription glasses. Farsightedness can be diagnosed through an eye test with an optometrist who will assess your vision with many tests, such as a visual acuity test and a refraction test. The kind of single vision lenses that correct farsightedness are called convex lenses, also known as plus lenses. Convex lenses are characterised by their thick centre that helps light focus back onto the retina.
#### Astigmatism
Astigmatism is a refractive error that is caused by a misshapen or deformed eyeball, which disrupts the eye's ability to focus light onto the retina, leading to blurry vision. This refractive error is characterised by symptoms including headaches, blurred vision and poor night vision. A person can experience [astigmatism](https://www.oscarwylee.com.au/glasses/eye/astigmatism) in addition to other refraction errors, such as myopia or hyperopia. Single vision lenses correct astigmatism by correcting the focal disruption in the eye through glasses containing cylindrical (CYL) prescription lenses. A CYL lens is equal to but opposite to the amount of astigmatism that is represented on the patient's prescription. The causes of astigmatism include keratoconus, eye injury, age, eye surgery, genetics or family history and eye disease.
## What are the Benefits of Single Vision Lenses?
There are many benefits to single vision lenses that make them a good choice for people who have vision problems. The benefits of single vision lenses include vision correction, the whole lens is dedicated to one prescription and they are generally less expensive than other types of lenses. These benefits and their definitions are listed below.
* Vision correction: Single vision lenses offer vision correction for a number of vision issues including hyperopia, myopia, astigmatism and presbyopia. For people with blurry vision, single vision lenses can give you clear and comfortable vision.
* The whole lens is one prescription: Unlike bifocals or multifocals, the lenses in single vision glasses are dedicated to one prescription, meaning there is no distortion at the edges of the lens and no distinct lines separating different prescriptions.
* Less expensive: Generally, single vision lenses are a more affordable option than bifocal or multifocal lenses. This is due to single vision lenses only containing one lens whereas bifocals and multifocals have two and three respectively.
### Are There Any Limitations in Single Vision Lenses?
Yes, there are limitations in single vision lenses, the main being they only contain one prescription in the lens. Single vision lenses can correct a single distance such as near or far, therefore, if you have myopia and presbyopia, you will have to switch between reading glasses and distance glasses. This is opposite to multifocals, where the lenses contain near, intermediate and distance vision correction, so the wearer can experience clear vision all in one pair of glasses.
## How Much Do Single Vision Lenses Cost?
The single vision lenses cost can vary depending on where you purchase them as different brands have a range of prices. At Oscar Wylee, our standard single vision glasses start from $169 and can be customised with lens add-ons such as a blue light filter or anti-reflective coating for an additional cost. Once you have decided on your lenses, you can browse our wide range of frames, online or in-store. We have bold styles as well as subtle, everyday staples.
### Where to Buy Single Vision Lenses?
A person can buy single vision lenses or glasses from an online or in-store eyewear company. Some companies, like Oscar Wylee, have an optometrist onsite so you can get your eyes tested and choose your new glasses in one place. Oscar Wylee has a range of stylish frames for all personalities in a selection of sizes, shapes and colours. Some single vision lenses that correct near vision, known as readers, can be purchased without a prescription in news agencies and other general stores. However, we recommend you get your eyes tested and have a prescription to purchase single vision lenses, so the optometrist and optical dispenser can ensure you are getting what you need for optimal vision correction.
#### Are Single Vision Lenses Worth it?
Yes, single vision lenses are worth it as vision correction can significantly improve a person's quality of life and can prevent inconvenient or dangerous situations that blurry vision may cause. Single vision lenses can correct refractive errors such as astigmatism, presbyopia, hyperopia and myopia. If you are unsure if you need glasses or are unsure about purchasing a pair, speak to an optometrist about the benefits.
#### Can you Switch Between Single Vision and Progressive Lenses?
Yes, you can switch between single vision and progressive lenses although it is not necessary as progressive lenses, also known as multifocals, will include all the vision correction needed that is in single vision lenses as the lenses contain three different prescriptions; near, intermediate and distance.
#### Can Single Vision Glasses be Worn all the Time?
Yes, single vision glasses can be worn all the time if the wearer requires vision correction. Single vision lenses can correct vision issues such as nearsightedness, farsightedness, presbyopia and astigmatism, making a person's vision clear so they can complete everyday tasks without blurry vision.
##### What is the Difference Between Single Vision and Progressive Lenses?
The difference between single vision lenses and progressive lenses is single vision lenses only contain one prescription for vision correction while progressive lenses, also known as multifocal lenses, can correct three. Multifocals contain three different prescriptions, near, intermediate and distance which seamlessly transition from one to the other. Multifocals, or [progressive lenses](https://www.oscarwylee.com.au/glasses/eye/progressive-lenses), are a great option for people who don't want to switch between distance and near single vision glasses. With multifocals, you can get multiple vision correction options in one lens. When discussing the argument for progressive vs. single vision lenses, it is up to personal preference and you should also consider the advice of your optometrist.
##### What is the Difference Between Single Vision and Bifocal Lenses?
The difference between single vision lenses and bifocal lenses is single vision lenses only contain one prescription for vision correction while bifocal lenses contain two. [Bifocal glasses](https://www.oscarwylee.com.au/guides/lenses/bifocal.html) contain lenses that correct a person's near and distance vision and the two prescriptions are separated by a clear, horizontal line. The larger top area of the lens contains the distance prescription which helps the wearer see far-away objects such as street signs. The smaller area at the bottom of the lens holds the near prescription which helps for up-close activities such as reading. When discussing the argument for bifocals vs. single vision lenses, it is up to personal preference and you should also consider the advice of your optometrist.
### How to Choose the Right Lens Index For Your Prescription?
It is typically the optometrist who will recommend the most appropriate lens index based on what your prescription requires. You can inform the optometrist of your personal preferences and lifestyle, which they can take into account. When you get your eyes tested, the optometrist will be able to examine how well your eyes bend light and, therefore, will know what you need for optimal vision.
## Do I Need Single Vision Lenses?
If you think you may need prescription lenses, whether it be single vision lenses or any other type, it is always recommended that you come in and see the team at Oscar Wylee for an eye test. Use our [online booking page](https://www.oscarwylee.com.au/booking) to make an appointment, and our optometrists will be able to determine if you need prescription lenses.
### What are the Best Frames for Single Vision Lenses?
The best frames for single vision lenses can include most styles of frames, depending on your personal preferences. The best frames for single vision lenses include Oscar Wylee options such as Mumford, Cara, Parker and Humphrey. The best frames for single vision lenses are listed below.
* Mumford: Mumford can be an ideal frame for single vision lenses with its classic frame shape that can blend well with a range of different outfit styles. Its essential shape and minimal design make it easy to wear and style every day.
* Cara: Cara is characterised by a rounded shape and a low nose bridge fit. It can be suitable for single vision lenses due to its simple design and stylish appearance.
* Parker: Parker is a square-round frame that can complement a range of different face shapes, making it ideal for single vision lenses. Parker is available in a wide range of colourways and patterns.
* Humphrey: Humphrey can make an optimal frame for single vision lenses due to their classic style and versatility. The frame design of Oscar Wylee's Humphrey glasses is characterised by a square-round shape, a high-bridge nose fit, an acetate and metal frame and a lightweight feel.
[](https://www.oscarwylee.com.au/mumford-optical.html)
[Mumford](https://www.oscarwylee.com.au/mumford-optical.html)
$169    
Add to Cart
[Shop Mumford](https://www.oscarwylee.com.au/mumford-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/mumford-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/mumford-optical.html)
[](https://www.oscarwylee.com.au/cara-optical.html)
[Cara](https://www.oscarwylee.com.au/cara-optical.html)
$169    
Add to Cart
[Shop Cara](https://www.oscarwylee.com.au/cara-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/cara-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/cara-optical.html)
[](https://www.oscarwylee.com.au/parker-optical.html)
[Parker](https://www.oscarwylee.com.au/parker-optical.html)
$169    
Add to Cart
[Shop Parker](https://www.oscarwylee.com.au/parker-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/parker-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/parker-optical.html)
#### Is Blue Light Filter Available for Single Vision Lenses?
Yes, blue light filter is available for single vision lenses. At Oscar Wylee, you can get [blue light filter](https://www.oscarwylee.com.au/glasses/eye/blue-light) added on to your single vision lenses for an additional $85 on top of the price of your prescription frames. We also offer a Premium Blue Light Filter option for $95.
##### Can Single Vision Lenses Help with Digital Eye Strain?
Yes, single vision lenses can help with digital eye strain. Digital eye strain can often stem from your eyes having to exert effort for certain tasks, especially if you have a refractive error. Single vision lenses can aid with digital eye strain by providing clear vision and therefore, prevent your eyes from needing to focus in order to see more clearly.
##### How Often Should You Replace Your Single Vision Glasses?
You should replace your single vision glasses every 2 years unless your optometrist advises otherwise. It is often recommended to get an eye test at least once every 2 years unless you are 65 years or older as your vision or eye health can change as you age. Regular eye tests help you stay on top of any of those changes for monitoring and/or early detection of any potential eye problems.
Read Single Vision Lenses: Definition, How it Works, Purpose, and Benefits in other Oscar Wylee regions and their languages.
Australia   
[Australia](https://www.oscarwylee.com.au/glasses/eye/single-vision-lenses)
New Zealand

[Canada](https://oscarwylee.ca/glasses/eye/single-vision-lenses)
Canadian French

All Major Health Funds are Accepted In-Store
Come and see your local Oscar Wylee team and your health fund may help cover some of the cost of your purchases.
[Discover Health Funds](https://www.oscarwylee.com.au/health-funds.html)
Make Your Eye Health a Priority
It is recommended that you have an eye test at least once every two years. Visit Oscar Wylee today for yours.
[Book an eye test](https://www.oscarwylee.com.au/booking)