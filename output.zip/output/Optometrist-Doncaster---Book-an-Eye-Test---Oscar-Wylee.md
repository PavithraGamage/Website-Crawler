# Source: https://www.oscarwylee.com.au/locations/optometrist-doncaster.html

# Optometrist Doncaster
Westfield Level 2, Shop 114619 Doncaster Rd &amp; Williamsons RoadDoncaster VIC 3108
* Near Apple
Opening hours
Monday9:00am - 5:30pm
Tuesday9:00am - 5:30pm
Wednesday9:00am - 5:30pm
Thursday9:00am - 9:00pm
Friday9:00am - 9:00pm
Saturday9:00am - 6:00pm
Sunday10:00am - 5:00pm
*Store hours reflect local standard trading hours and exclude public holidays
[Visit our Doncaster Google Business page for directions, reviews, and updates.](https://g.page/r/CTitJmK4d-RfEBA)
Book Appointment
[Call us: (03) 9973 4267](tel:(03) 9973 4267)
[Leave a Review!](https://g.page/r/CTitJmK4d-RfEBM/review)
Our Reviews
Gargee Chakravarty
3 days ago
Very competent optometrists. Sincere and helpful too. Unlike some much-advertised optometrists, they... did not push frames and lenses like crazed marketeers. They also emailed my test results immediately. I was at their Westfield, Doncaster, store and will recommend them to everyone. Ten out of ten.
See more
julie mitsou
4 days ago
Very thorough and clear, very helpful
Ngoc Thi Minh Vu
1 week ago
Had a great experience with Abby and Selwyn. They were able to address my concerns and explain what ...I needed to monitor for my next test. The sales experience was very friendly without being overbearing unlike other optical providers. Had to dash as I didn't have much time before work but I'll be getting my pair via their website ????
See more
Ruth Foxwell
1 week ago
Excellent service by efficient professionals in Selwyn and Kash. Thank you for seeing  me even thoug...h I turned up a day too early for my appointment.  Ha ha.
See more
R D
1 week ago
Absolutely fantastic experience - wish I’d come here years ago! My optometrist was incredibly thorou...gh &amp; gave me guidance on what to do for my extremely dry eyes. I’d mentioned this at numerous appointments previously at SpecSavers but hadn’t received any useful information.
The range of glasses is amazing. The frames are much more fashion forward than other places. They also had many more options for frames that were wider &amp; suit my face.
I literally got a compliment on my glasses from a stranger within the first half hour of wearing them.
If you’ve been thinking about trying Oscar Wylee, definitely book an appointment.
See more
Philip
3 weeks ago
Friendly and professional staff made the process of selecting a new pair of prescription glasses a b...reeze.
See more
B B
3 weeks ago
Amazing, every person I spoke to in my couple of appointments were excellent and knowledge. Loved my... experience and am a new and ongoing customer
See more
Rod Faulkner
4 weeks ago
Very happy with the experience
John Oriander
1 month ago
Fantastic work explained everything great work .
Jay Jayarajan
1 month ago
Services provided by office staff was excellent. I am extremely satisfied with the advice and the se...rvice provided by the Optometrist was very good. I highly recommend.
See more
Jasmine Chy-Long
1 month ago
Friendly staff with a great environment. Had my eye test with Dr Michael Lim. He was very profession...al and paid close attention to the details. Definitively recommend for anyone needing optometry related services.
See more
Bunleang Pa
1 month ago
I had a great experience at Oscar Wylee Doncaster. Michael Lim was professional, knowledgeable, and ...took the time to explain everything clearly during my eye test. The staff were friendly and welcoming. Highly recommend!
See more
Natalie Dellidis
2 months ago
Great customer service ! very professional and very prompt . Eye specialist was very helpful and inf...ormative. Have a great variety of glasses.
See more
Debbie Clark
2 months ago
Always professional and knowledgeable. Great service and expertise.
Flynn Sun
2 months ago
(Translated by Google) Eye prescription test is very professional
(Original)
眼睛度数测试很专业...
See more
Elly Dewberry
2 months ago
Lovely friendly service, professional and helpful! ☺️
Sharon Yong
2 months ago
Had a fantastic experience with Selwyn the optometrist and the entire team. Very friendly, professio...nal, and made me feel comfortable from the moment I walked in. The eye examination was thorough, and everything was explained clearly. Highly recommend this optometrist to anyone looking for excellent eye care!
See more
Azalea He
2 months ago
Professional optometrist, had a really good experience there.????
Baden Roberts
2 months ago
Great friendly service, wide range, and fair
prices. Selwyn identified an issue that other optometri...sts had missed. Thank you.
See more
Diego Sánchez
2 months ago
Great experience, they were so kind and helpful, particularly Mr Yan was so nice
Simon Wee
2 months ago
Professional and personable service. It’s been a few years since my last glasses change so I had to ...take some time in choosing my frame, Selwyn and his team were very patient and responsive in helping me make my selection. Thank you for the good experience and service.
See more
V M
2 months ago
I have been going to Oscar Wylie Doncaster for a few years now and have consistently been very happy... with the service and the glasses. The optometrist there is knowledgeable and personable and I have always had a positive experience. I have always found it easy to find suitable, stylish, affordable and sturdy frames which look good! The team in store is always pleasant and helpful too!
See more
Melissa Keogh
3 months ago
Fantastic range of stylish frames at great prices.  Staff are very helpful at helping chose a look t...hat suits you
See more
Nina Mann
3 months ago
Really helpful and friendly service. the eye examination and testing was very thorough and well done.... I was given an explanation on what was happening when relevant
See more
Charlotte Kerr
3 months ago
The process was high tech and easy, it felt so much less draining than the last time I had my eyes t...ested around 10 years ago! Thanks to the great team at Oscar Wylee, Doncaster.
See more
Sophia
3 months ago
The eye test was comprehensive, and the staff were very helpful when assisting me with frames. I nev...er felt rushed during the process, which I appreciated. I did feel a little unsure about how my test went afterwards and would have liked a bit more detail and explanation regarding the results.
There was a nice range of glasses available, although many of the frames were quite large, and some of the colour choices were a little questionable.
I particularly wish it had been made clearer that blue light filter lenses were almost an extra $100, and that even basic scratch-resistant and anti-reflective coatings cost an additional $50. I feel that scratch resistance and anti-reflective coating should be included in the base price rather than treated as add-ons.
See more
Jonathan Sibley
4 months ago
Excellent Optometrists. Highly professional and knowledgeable. Good range of frames.
Fabio Rai
4 months ago
I had an eye test at Oscar Wylee and had a great experience. The staff were professional and friendl...y, and they managed to see me straight away with minimal waiting time. The whole process was quick and efficient. Highly recommend!
See more
Shashank R
4 months ago
Dieter Carlos
4 months ago
Very thorough testing and great recommendations and care
Cheryl Tam W
5 months ago
Today my daughter and I had an eye check-up here, and the experience was fantastic! My daughter’s op...tometrist was very gentle and patient, explained everything in detail, and you could really feel her professionalism. Overall experience is very comfortable and the staff are friendly—highly recommend!
See more
Paula Coghlan
5 months ago
My experience was a very positive one. The optometrist was very helpful and knowledgeable.
Andy
5 months ago
Had a long flight just got back on sunday afternoon and went shopping with friends.
Staff was atten...tive but was annoyed when I was dazing off.
Please let him know apologies for making him uncomfortable.
Store has a wide selection and very soothing to see.
See more
Marie Hein
5 months ago
Appointment was great. Staff were amazing they were so helpful. Pricing was fantastic and frame opti...ons were plenty. Advice and help to choose was appreciated. Would definitely recommend
See more
sunitha venkata kesarapu
5 months ago
Hou Jiaran
5 months ago
Sylvia Marslen
6 months ago
Very thorough, great service!
Parisa Sedigh
6 months ago
Sarah Walker
6 months ago
Very nice staff, the optometrist was helpful in explaining things to me, and the team helped me choo...se out frames that suited me.
See more
Jessica Ho
6 months ago
On February 6th, I visited the shop for my regular eye test. Mr. Yan is a highly professional optome...trist who conducts thorough and detailed eye tests. I highly recommend. The staff were very helpful.
See more
Michele Lo
7 months ago
Optometrist was very careful and detailed during the eye test.
Graham Ferres
7 months ago
Very reassuring and informative test with Nancy
Thanks
Graham
Philip Thomas
7 months ago
Very gentle and attentive to my needs and provided options in addition to testing eyes for just read...ing glasses.
Listened to my requirements and sympathetic to all my concerns.
See more
Alexandra Carter
7 months ago
The optometrist was experienced and professional - a seamless process
Michelle Clark
7 months ago
I hsve been going to Doncaster fir a very long time and always find all the staff friendly and very ...helpful which is why I keep going back!
See more
Vivienne Kostoglou
7 months ago
Staff friendly on time overall an excellent experience thanks
Vivian Wo
8 months ago
Today I came in store around 2pm hoping to find a new pair of sunglasses and had the pleasure of hav...ing Kevin help me with the process. He gave the most helpful, attentive and friendly service I’ve ever had in this store or any optometry store in general. This store is lucky to have him! Thanks Kevin!
See more
Grant Nalder
8 months ago
Louisa Chiu
8 months ago
Friendly and helpful staff. Comfortable venue for eye test.
Renee Hann
8 months ago
Competent, understanding and helpful staff - thank you so much ☺️
## Find an Optometrist in Doncaster With Oscar Wylee
Located in Westfield Doncaster, our Oscar Wylee store is central to areas such as Kerrimuir and Templestowe. Oscar Wylee Doncaster offers modern and vintage-inspired eyewear, providing prescription glasses and prescription sunglasses, as well as in-store Medicare bulk billed eye tests and vision testing. 
Westfield Doncaster offers excellent dining and entertainment and is children and pet friendly. It is located just 20 minutes east of the CBD and is one of the biggest shopping centres in Victoria. If you have some time after your appointment in Oscar Wylee Doncaster, you can visit the Doncaster Village Cinemas in the Westfield where you can see the latest films in the luxury of Gold Class. For excellent optometrists, eye care processes and on-trend frames, book online or come visit us at our Doncaster Oscar Wylee store.        
Meet Our Team
* Optometrist Partner
B.Optom
TPA Endorsed
* Store Manager
Our Services
* Bulk Billed Eye Examinations
* Professional Frame Styling
* Frame Adjustments and Repairs
* Visual Fields Testing
* Digital Retinal Scanning
Show All
## Find an Optometrist in Doncaster, Victoria for an Eye Health Test
At our glasses store in Oscar Wylee Doncaster, Victoria, our team is available to provide high-quality eye care services. Our optometrist in Doncaster, Victoria, can provide an eye health test to assess a patient's vision and whether there are any signs of eye disease. Our optometrists can refer patients to an eye doctor, also known as an ophthalmologist in Australia, if advanced care is needed. An optical dispenser and our knowledgeable retail staff are also available in-store to help customers shop for a new pair of stylish frames, including prescription glasses, prescription sunglasses and non-prescription eyewear.
At Oscar Wylee our eye tests are available at a bulk billed price as part of Australia’s Medicare system. This means there are no out-of-pocket expenses for eligible cardholders. The average price range for an optometrist in Doncaster, Victoria can vary depending on factors such as the patient’s overall health, age and visual needs. If you are in need of an eye health test in Doncaster, Victoria come and visit Oscar Wylee.
## How to Find an Optometrist in Doncaster, Victoria?
To find an optometrist in Doncaster, Victoria you can take certain steps that can help make it easier for you such as searching online, assessing the store’s opening hours and finding the directions to your chosen location. The steps on how to find an optometrist in Doncaster, Victoria are listed below.
1. Search online using the phrase, optometrist near me in Doncaster. This can also be done here on the website via our locations page.
2. Click on the Oscar Wylee link, which will take you directly to our Doncaster optometrist store page.
3. See the store’s opening hours and where the store is located specifically.
4. Use the Doncaster Google Business page link located under store hours to see the directions on how to get to the store.
You can also find an optometrist in Doncaster, Victoria by searching the keywords optometrist near me. If you have locations enabled on your smartphone and you’re in the Doncaster, Victoria area, our Doncaster store page should appear easily for you to click on.
### Is it Hard to Get an Eye Appointment in Doncaster, Victoria?
No, it is not hard to get an eye appointment in Doncaster. You can easily book an appointment to see an Oscar Wylee optometrist in Doncaster, Victoria right here on this page. At Oscar Wylee we have highly qualified optometrists available for bulk billed eye appointments, which can be booked online or in-store.
#### How to Compare Optometrists in Doncaster, Victoria to Each Other?
To compare optometrists in Doncaster, Victoria, you can use factors such as eye tests offered, health fund coverage, lens types and add-ons and eyewear offered. To take care of your vision and eye health, it is important to receive an eye test at least once every two years. There are different types of tests that can be performed in an eye test and not all optometrists may offer the same tests. Health funds can be used to help cover some of the cost of your frames and lenses. To find out if your health fund is accepted at an optometrist in Doncaster, Victoria visit their website. In the case of Oscar Wylee, we accept all major health funds and provide on-the-spot claims in-store. There are many different lens options available for prescription glasses such as single vision, multifocal and high index lenses. Most optometrists in Doncaster, Victoria will offer these lenses although it is good to make sure. There are also lens add-ons available to enhance your glasses such as anti-reflective and blue light filters. Finally, if you are looking to purchase a pair of glasses after your eye test, you can compare the different styles and colours you are interested in from the optometrists in Doncaster, Victoria. Oscar Wylee offers a wide range of frames with vintage and modern inspirations in bold colours and subtle designs.
#### How to Find an Eyeglasses Shop in Doncaster, Victoria?
To find a glasses store in Doncaster, Victoria you can try to follow these simple steps including searching online, selecting a convenient location and looking at their health insurance policies. The steps on how to find a glasses store in Doncaster, Victoria are listed below.
1. Search online using the phrase, glasses store in Doncaster, Victoria. This will provide you with various options for glasses stores in the whole Doncaster, Victoria area.
2. Select a glasses store that is most convenient for you to travel to.
3. Click the link to find out more information such as opening hours, exact location and directions to the glasses store in Doncaster.
4. Read their health insurance policies to ensure you know what health benefits you have access to.
Our Oscar Wylee glasses store in Doncaster, Victoria offers primary eye care services such as comprehensive eye tests as well as other services performed by an optometrist and offers prescription and non-prescription eyewear.
##### Is it Possible to Purchase Prescribed Sunglasses in Doncaster, Victoria Without Seeing an Optometrist?
Yes and no, it is possible to [purchase prescribed sunglasses](https://www.oscarwylee.com.au/sunglasses.html) in Doncaster, Victoria without seeing an optometrist if you already have a prescription that has not expired. If your prescription is expired, you can book an eye test to receive an updated or new prescription which will require you to see an optometrist. This will ensure your prescription sunglasses are appropriate for your visual needs.
## Where is the Oscar Wylee Doncaster, Victoria Optometrist Located?
The Oscar Wylee Doncaster optometrist is located in Doncaster’s Westfield shopping centre near Big W and opposite the centre’s Playworld. Westfield Doncaster can be found in Doncaster, which is a suburb in Melbourne, Victoria.
### What is the Phone Number of Oscar Wylee Doncaster, Victoria Optometrist Store?
The phone number for our Oscar Wylee Doncaster, Victoria optometrist store is (03) 9973 4267. Our Oscar Wylee Doncaster, Victoria store is open, and our staff are available to be contacted, between the hours of 9 am and 5:30 pm from Monday to Wednesday, 9 am and 9 pm on Thursdays and Fridays, 9 am and 6 pm on Saturdays and 10 am and 5 pm on Sundays.
### What are the Reviews for Oscar Wylee Doncaster, Victoria Optometrist?
The reviews for our Oscar Wylee Doncaster, Victoria optometrist, left by our various customers, can be found here on the website as well online when you search for Oscar Wylee Doncaster optometrist. The reviews for Oscar Wylee Doncaster optometrist are listed below.
* Judy Roberts:  It was a good process. From when you entered the store you were attended to. The eye examination was thorough and the results were explained clearly. A good selection of frames and the assistance given to select them was really good.
* SL Mac:  Really easy, convenient and no-fuss assessment from booking to choosing frames. Lovely staff and relaxed experience despite the importance of testing my eyes including eye pressure. Looking forward to receiving my specs.
* Fiona An:  Extremely thorough review and wonderful selection of frames. Fantastic customer service. Exceeded expectations.
#### What Treatments or Eye Care Processes are Done in the Oscar Wylee Doncaster, Victoria Optometrist Location?
The treatments or eye care processes done in the Oscar Wylee Doncaster, Victoria optometrist location include a tonometry test, a digital photograph, a slit lamp exam and a refraction test. Additional tests that may also be performed can include a visual field test and a dilated fundus exam. The treatments or eye-care processes that are done in the Oscar Wylee Doncaster optometrist location are listed below.
* A Tonometry Test: An optometrist or optical dispenser will conduct a tonometry test which involves the use of a machine that will release small puffs of air into your eyes. This will assist with measuring pressure in the eye.
* A Digital Photograph: An optometrist or optical dispenser may take a digital photograph of your eye which can be kept on record to use in future appointments to evaluate any changes to your eye.
* Slit Lamp Test: A slit lamp test can be used to evaluate your eye health, by examining your cornea and iris which are the anterior and posterior of the eye.
* Refraction Test: During a refraction test, an optometrist will have you view an image through different lenses and ask you to confirm which helps you see the image clearer.
* Visual Field Test: A visual field test can assist with assessing your peripheral vision, which may be beneficial for identifying any signs of glaucoma.
* Dilated Fundus Exam: A dilated fundus exam can help an optometrist assess your health in more detail by getting a clear view of the retina. This test is typically carried out for patients with diabetes and those who may be at risk of developing retinal damage.
## How Many Optometrists Exist in Doncaster, Victoria?
There are a variety of optometrists and eye care providers that exist around the Doncaster, Victoria area, including Oscar Wylee. The amount of optometrists available in an area will typically depend on the population. At Oscar Wylee Doncaster, Victoria, our team is passionate about providing our customers with high-quality, dedicated eye care. Our experienced optometrists offer bulk billed eye tests for eligible Medicare cardholders to help maintain your eye health. Our knowledgeable retail staff are also in-store to help you shop our range of frames. If you are looking for an optometrist in Doncaster, Victoria, Oscar Wylee is available to provide all your eye care and eyewear needs.
### What are the Other Closest Optometrist Locations to Doncaster, Victoria in Australia?
The other closest Oscar Wylee optometrist locations to Doncaster, Victoria in Australia are Melbourne Central, Chapel Street and Moonee Ponds. The other closest optometrist locations to Doncaster, Victoria are listed below.
* Melbourne Central: Melbourne Central is located near Doncaster, around a 17-18 km drive away. [Oscar Wylee Melbourne Central](https://www.oscarwylee.com.au/locations/optometrist-melbourne-central.html) is located in the Melbourne Central shopping centre. Come and visit our optometrists at Oscar Wylee Melbourne Central who provide eye tests and prescription updates. You can also find our stylish selection of frames in-store.
* Chapel Street:  Chapel Street is a location near Doncaster in which a person can find several optometrists. [Oscar Wylee Chapel Street](https://www.oscarwylee.com.au/locations/optometrist-chapel-st.html) is around 20 km away from Doncaster.
* Moonee Ponds: Moonee Ponds is a location close to Doncaster, approximately 22 km away, where you can find several optometrists. [Oscar Wylee Moonee Ponds](https://www.oscarwylee.com.au/locations/optometrist-moonee-ponds.html) is located in the Moonee Ponds Central Shopping Centre. Our Moonee Ponds team are available to provide eye care services such as eye tests and new frames.
### Check Your Eyesight in Oscar Wylee Doncaster
There is no need to go to an optometrist’s office in order to have your routine eye health test. Just stop by our Oscar Wylee store in Doncaster, where we have trained eye care professionals performing bulk billed eye tests for Medicare cardholders. You can get your eyesight assessed, eye health checked for certain diseases and your prescription updated, all in approximately 30 minutes. Book online to have a quick and convenient eye test at Oscar Wylee Doncaster.
### We Accept Major Health Funds at Oscar Wylee
Here at Oscar Wylee Doncaster, we can process your health fund claim in-store with a valid health fund card. Our friendly staff can help answer any questions you have about what you’re eligible for with your health fund. You won’t have to navigate the hardest parts of health insurance alone - here at Oscar Wylee Doncaster, we’re here to ensure you get what you need at an affordable, competitive price.
### Fashion-Forward Glasses at Affordable Prices
Visit Oscar Wylee Doncaster for professional frame styling from our experts in-store. We’re offering vintage-style frames as well as contemporary designs and colours. We have customisable prescription lenses to fit your needs - whether that’s a blue light filter to help with your sleep or a multifocal lens, to see at three different distances, our experts in our eyeglasses shop are ready and able to help you.
Book Appointment
[Call us: (03) 9973 4267](tel:(03) 9973 4267)
[Leave a Review!](https://g.page/r/CTitJmK4d-RfEBM/review)