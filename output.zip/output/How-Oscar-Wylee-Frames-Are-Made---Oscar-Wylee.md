# Source: https://www.oscarwylee.com.au/how-ow-frames-are-made.html

# How Oscar Wylee Frames Are Made
## PROCESS
At Oscar Wylee, we’ve cut out the distributor middleman to bring you designer-style glasses, directly from the source, at affordable prices. Our glasses go through an intricate production process and are hand-crafted and hand-assembled to ensure they meet our high standards.
DESIGN
PRODUCTION
QUALITY CONTROL
## Design
The Oscar Wylee product and design team take inspiration from the world around us and our home environment like the Sydney beaches and Australian landscapes. Our frames are influenced by global fashion, art, and architecture - all that excites us! We then share our design vision with our trusted and dedicated production partners. Prototypes are created to ensure the design is as we envisioned, and to make sure that the correct shape, size, colour, and detailing goes into each of our frames. We trial the frames as a team to make sure our frames will fit all face shapes, sizes, and features they are designed for. Once they get the tick of approval, production begins.
## Production
### 01 Production Begins
Acetate frames
Our acetate frames are made using a bio-based material that derives from the fibres in cotton pulp or wood, to make a compound called cellulose acetate. Dyes are added to the acetate to create individual colours and then rolled out into a sheet.
To create the patterned and multi-coloured frames you see in our stores, small acetate pieces are cut from the individually coloured sheets. No patterned frame will look the same, that’s why if you decide on a tortoiseshell or patterned multi-coloured frame for your next pair of glasses, your pair will be unique!
For our acetate frames, a precise machine called a CNC milling machine, sculpts the frame from a single piece of acetate, cutting the lens holes, the grooves for the hinges, and the nose bridge to make the front of the frame. The frame then goes through a dozen manual steps including milling and heat moulding for the frame shape to take its final form and curvature so that it will fit comfortably.
Metal frames
The life of our metal frames starts with the raw material: a simple metal wire that takes shape inside the specific reeling machine. During different phases, the front rim is welded manually to other metal components like the nose bridge that hold the lenses, the temples and the nose pad wires. The frame of each pair of glasses is hand-assembled, piece by piece.
### 02 Polish/Tumbling Process
Once the frames have been cut, they are polished using two different felt buffing wheels. First, an aggressive buffing wheel is used to smooth out the connection that was filled and remove any filling marks or gouges. A gentler wheel is then used to smooth out the acetate. Next, the frames are polished from 48 to 76 hours in the tumbling barrels. These tumblers are filled with small chips of beech and birch wood, whose continuous movement generates a slight abrasion eliminating imperfections, thus making the surface of the frames perfectly smooth.
### 03 Constructing the Frames
Glasses frames are comprised of three main parts, containing multiple sub-parts within their construction. These main components come in many different forms and materials which have their own specific functions, styles and names. In this step of the production process, rivets and hinges are added, the arms of the frames, called temples, are individually hand screwed to the front of the frame, and core wires are inserted into each temple so they don’t lose their shape but can still be adjusted to fit your face comfortably
### 04 Lens Fitting
Once the frame is ready, the lenses are cut one by one to fit each frame perfectly and inserted by hand. Our lenses are made from premium engineered polymers and formed under strict quality-controlled conditions in our modernised lab.
### 05 Quality Control
Each frame is inspected by the hands of our expert craftsmen and every small imperfection is corrected. This strict quality control ensures there are no faults with our glasses so they are of the highest quality before they are shipped out to our customers.
[Shop Glasses](https://www.oscarwylee.com.au/glasses.html)
Due for an eye test? Book now:
[Book an eye test](https://www.oscarwylee.com.au/booking)
We recommend that everyone should have an eye test with an optometrist at least once every 2 years. Oscar Wylee offers bulk billed eye test, so there are no out-of-pocket expenses for eligible Medicare card holders.