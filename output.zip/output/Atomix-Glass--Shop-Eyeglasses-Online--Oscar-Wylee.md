# Source: https://www.oscarwylee.com.au/atomix-optical.html

# Atomix
1
## Frame Design of Atomix Glasses
The frame design of Oscar Wylee’s Atomix glasses is characterised by their aviator shape, nose pads, and metal frame. Atomix is a unisex, statement glasses frame that will complement any outfit, day to night.
$169    
In stock
Only %1 left
2 pairs from $199
Discount auto-applied at checkout
3 pairs from $249
Discount auto-applied at checkout
Qty
Add to cart
Book an eye test
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
excluding prescription lenses
## About Atomix Frames
Splay bridge for broader noses, double bar for stability and edge, paired back and funky fresh!
| Frame fit | Measurements |
| --- | --- |
| MEDIUM | 55 - 16 - 140 |
These measurements mean lens width, bridge, and temple length in millimetres (mm). They can be found on the inside of the temple arm. If you already have a pair that you like, you can compare it to these measurements.
### Made from Stainless Steel
Oscar Wylee's Atomix frame is a unisex aviator glasses frame that is perfect for those with heart, oval, and pear face shapes. The Atomix frame is a stylish, widely wearable frame that can be worn every day. The main specs of Oscar Wylee's Atomix glasses frame, including dimensions, shape, materials, lenses, nose fit and hinges are listed below.
| Atomix Frame Features | Atomix Frame Description | Dimensions | Shape | Materials | Lenses | Nose Fit | Hinges |
| --- | --- | --- | --- | --- | --- | --- | --- |
| The dimensions of the Atomix frame are measured in millimetres (mm) and are 55 - 16 - 140, meaning the lens width is 55 mm, the bridge is 16 mm, and the temple length is 140 mm. |
| Atomix is an aviator shape, well-suited to medium faces. |
| Atomix is made from metal, stainless steel, cupronickel, and nickel alloy, with acetate temple tips. |
| The lenses that can be used in the Atomix frame include optical lenses, such as single-vision and multifocal, and non-prescription lenses, which are plain and can have a filter, such as a blue-light filter applied. Atomix also comes as sunglasses. |
| The nose fit for Atomix is characterised by nose pads. |
| The hinges in Atomix are spring hinges, which are more flexible than other types of hinges and can extend past 90 degrees. |
Show All
### What Inspired the Frame Design of Oscar Wylee's Atomix Glasses?
The Oscar Wylee Atomix frame design was inspired by current fashion trends, as aviator glasses are a timeless style.
## What to Know About Oscar Wylee's Atomix Glasses?
There are many aspects of the Oscar Wylee Atomix frames that customers should know about to decide whether this is the right frame for them. The Atomix frame is a unisex aviator-shaped frame. Oscar Wylee's Atomix frame is suitable for many face shapes, but particularly compatible with heart, oval, and pear face shapes. The Atomix frame's simple design makes them fashionable all year round. Atomix features the standard [parts of glasses](https://www.oscarwylee.com.au/glasses/eye/part-of-glasses), such as a rim, temples, lenses, hinges, and nose pads.
### What are the Types of Temple Tips or Earpieces Included with Oscar Wylee's Atomix Glasses?
The type of temple tips or earpieces included in Oscar Wylee's Atomix Glasses are made from acetate.
### What Type of Nose Bridge do Oscar Wylee's Atomix Glasses Have?
The type of nose bridge included in Oscar Wylee's Atomix frame is characterised by nose pads.
### What Type of Nose Pads are Included with Oscar Wylee's Atomix Glasses?
Oscar Wylee's Atomix frame includes standard nose pads. Nose pads are adjustable for a perfect fit.
### What Type of Lenses do Oscar Wylee's Atomix Glasses Have?
The type of lenses that typically come with the Oscar Wylee Atomix [glasses frame](https://www.oscarwylee.com.au/glasses.html) are optical lenses. Optical lenses are glasses lenses that have a prescription within the lens to help correct vision issues such as myopia, hyperopia, and astigmatism. Atomix frames can also come as sunglasses and with non-prescription lenses and add-ons such as a blue-light filter.
### What Material is Used for the Rim of Oscar Wylee's Atomix Glasses?
The material used for the rim of Oscar Wylee's Atomix glasses frames is stainless steel. The rim refers to the part of a glasses frame that holds the lenses.
### What Type of Hinges are Included with Oscar Wylee's Atomix Glasses?
The type of hinges included with Oscar Wylee's Atomix frames are spring hinges. A spring hinge in a glasses frame refers to hinges that are more flexible than normal hinges and can go slightly beyond 90 degrees. Spring hinges can provide a closer fit to the face.
## What Face Types are Most Suitable for Oscar Wylee's Atomix Glasses?
The face types that are most suitable for Oscar Wylee's Atomix frame are heart, oval, and pear face types. The Atomix frame is an aviator shape, meaning that it complements the structure of heart, oval, and pear faces particularly well. The aviator Atomix frames help balance the features of a [heart face shape](https://www.oscarwylee.com.au/glasses/face-shapes/heart), an [oval face shape](https://www.oscarwylee.com.au/glasses/face-shapes/oval), and a [pear face shape](https://www.oscarwylee.com.au/glasses/face-shapes/pear), bringing the eyes and brows forward in a flattering way. Although there are many [glasses for face shapes](https://www.oscarwylee.com.au/glasses/face-shapes) that may be considered more aesthetically suitable, it is important that people also choose frames that make them feel most comfortable and represent their personal style.
## What Size Options are Available for Oscar Wylee's Atomix Glasses?
The size options available for Oscar Wylee's Atomix frame are a medium-fit frame across all colours.
## What Materials are Used to Create Oscar Wylee's Atomix Glasses?
The primary material used to create the Oscar Wylee Atomix frame is metal. It is made from a combination of metal, with a stainless steel rim, cupronickel nose bridge, and nickel alloy temples, with acetate temple tips. Stainless steel is a durable iron based alloy.
## What’s Included
## What's Included
Each pair of glasses comes with a stylish frame case and lens cloth. We offer free shipping across Australia and 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects.
* Free Shipping for Australian Orders
* 1 Year Warranty on frames and lenses
* Scratch resistance lens coating on all prescriptions
* UV-proof coating on all prescriptions
* Stylish case and cloth
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
## Make and Materials
The frames then go through cleaning and strict quality control, and many pairs of crafting hands to be hand-assembled and polished. After your frames have gone through the production process, they are individually examined and packed before making their way to you!As part of our durable frame family, some of our most popular styles, are now in stainless steel. These frames are hypoallergenic, corrosion resistant, light weight, and not sensitive to temperature changes.
## Warranty Information
### Warranty Information
### Warranty Information
Oscar Wylee provides a 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects. 
We will repair or replace faulty or defective frames or lenses free of charge for warranty claims made within 1 year of the delivery.
We also offer repairs or replacement for problems experienced with vision during everyday use for claims made within 30 days of delivery. If the same product has been discontinued or is no longer available, then we may offer an exchange for a similar product or a refund.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Find a Store Location](https://www.oscarwylee.com.au/locations/full-store-list.html)
Recommended
1. [](https://www.oscarwylee.com.au/deus-optical.html)
[Deus](https://www.oscarwylee.com.au/deus-optical.html)
Gold
2. [](https://www.oscarwylee.com.au/taku-optical.html)
[Taku](https://www.oscarwylee.com.au/taku-optical.html)
Gold