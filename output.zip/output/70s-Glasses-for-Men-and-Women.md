# Source: https://www.oscarwylee.com.au/glasses/collection/70s.html

12 Products        
Showing 12
1. [](https://www.oscarwylee.com.au/mackenzie-optical.html)
[Mackenzie](https://www.oscarwylee.com.au/mackenzie-optical.html)
$199    
[2 pairs from $249](https://www.oscarwylee.com.au/mackenzie-optical.html)
2. [](https://www.oscarwylee.com.au/deus-optical.html)
[Deus](https://www.oscarwylee.com.au/deus-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/deus-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/deus-optical.html)
3. [](https://www.oscarwylee.com.au/amber-optical.html)
[Amber](https://www.oscarwylee.com.au/amber-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/amber-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/amber-optical.html)
4. [](https://www.oscarwylee.com.au/lincoln-optical.html)
[Lincoln](https://www.oscarwylee.com.au/lincoln-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/lincoln-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/lincoln-optical.html)
5. [](https://www.oscarwylee.com.au/beren-optical.html)
[Beren](https://www.oscarwylee.com.au/beren-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/beren-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/beren-optical.html)
6. [](https://www.oscarwylee.com.au/axelle-optical.html)
[Axelle](https://www.oscarwylee.com.au/axelle-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/axelle-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/axelle-optical.html)
7. [](https://www.oscarwylee.com.au/taku-optical.html)
[Taku](https://www.oscarwylee.com.au/taku-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/taku-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/taku-optical.html)
8. [](https://www.oscarwylee.com.au/haskell-optical.html)
[Haskell](https://www.oscarwylee.com.au/haskell-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/haskell-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/haskell-optical.html)
9. [](https://www.oscarwylee.com.au/kato-optical.html)
[Kato](https://www.oscarwylee.com.au/kato-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/kato-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/kato-optical.html)
10. [](https://www.oscarwylee.com.au/atomix-optical.html)
[Atomix](https://www.oscarwylee.com.au/atomix-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/atomix-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/atomix-optical.html)
11. [](https://www.oscarwylee.com.au/ford-optical.html)
[Ford](https://www.oscarwylee.com.au/ford-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/ford-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/ford-optical.html)
12. [](https://www.oscarwylee.com.au/duckworth-optical.html)
[Duckworth](https://www.oscarwylee.com.au/duckworth-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/duckworth-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/duckworth-optical.html)
12 Products        
Showing 12
Choosing the Best 70s Glasses
Best Material
Suitability
Suitability and Style
FAQs
## How to Choose the Best 70s Glasses for Women?
If you want to choose the best 70s glasses for women,
select a suitable frame shape,
try on different styles, and
consider your lifestyle needs. The
[best glasses for women](https://www.oscarwylee.com.au/glasses/best-women)
will be glasses that enhance your natural features, fit well and
comfortably on your face and suit your day-to-day life. The
steps on how to choose the best 70s glasses for women are listed
below.
* Select a suitable frame shape: Select a
suitable frame shape when choosing the best 70s glasses to fit
your face shape. Frame shapes are important to consider, as
they can either complement your facial features or appear
disproportionate and unbalanced to your facial features. A
helpful note to remember is to focus on contrasting your face
shape. For example, round or oval frame shapes are
complementary to square face shapes, as the curved frame lines
contrast with the straighter and stronger angles of square
face shapes.
* Try on different styles: Try on different
styles when choosing the best 70s glasses for women to narrow
down which particular frame styles you feel suit you best.
Oscar Wylee offers a wide range of bold, colourful and minimal
styles and other trendy options to choose from.
* Consider your lifestyle needs: Consider your
lifestyle needs to ensure your chosen 70s glasses are fit for
your day-to-day life. If you regularly engage in physical
activities outdoors, for example, you might need to opt for
frames from our active collection instead of 70s style
glasses. If you wear a uniform during the week, for example,
you may want to choose a 70s style that is minimal in design
or opt for a more classic style.
[](https://www.oscarwylee.com.au/deus-optical.html)
[Deus](https://www.oscarwylee.com.au/deus-optical.html)
$169    
Add to Cart
[Shop Deus](https://www.oscarwylee.com.au/deus-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/deus-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/deus-optical.html)
[](https://www.oscarwylee.com.au/kato-optical.html)
[Kato](https://www.oscarwylee.com.au/kato-optical.html)
$169    
Add to Cart
[Shop Kato](https://www.oscarwylee.com.au/kato-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/kato-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/kato-optical.html)
[](https://www.oscarwylee.com.au/beren-optical.html)
[Beren](https://www.oscarwylee.com.au/beren-optical.html)
$169    
Add to Cart
[Shop Beren](https://www.oscarwylee.com.au/beren-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/beren-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/beren-optical.html)
[](https://www.oscarwylee.com.au/amber-optical.html)
[Amber](https://www.oscarwylee.com.au/amber-optical.html)
$169    
Add to Cart
[Shop Amber](https://www.oscarwylee.com.au/amber-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/amber-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/amber-optical.html)
## How to Choose the Best 70s Glasses for Men?
You can choose the best 70s glasses for men through a simple
process,
opt for styles that suit your face shape, try several frames
on
and prioritise comfort. While it can differ
between individuals, the
[best glasses for men](https://www.oscarwylee.com.au/glasses/best-men-eyeglasses-for-every-face-shape)
should fit well, suit your personal taste and look and help you
feel your best. The steps on how to choose the best 70s glasses
for men are listed below.
* Opt for styles that suit your face shape: Opt
for styles that suit your face shape by choosing frame shapes
that contrast with your face shape. If you have a round face
shape, try square or rectangle frame shapes to help add more
angles to your curved facial features to create balance
visually.
* Try several frames on: Try several frames on
to familiarise yourself with what styles and different frame
sizes look best on you. At Oscar Wylee, there are many options
that match the 70s aesthetic to choose from.
* Prioritise comfort: Prioritise comfort by
ensuring your glasses fit well. To know if your glasses fit
properly and optimally, they shouldn't slide down or off, or
feel too tight on the nose or temples.
### How to Choose the Best 70s Glasses According to Face Shape?
Choose the best 70s glasses according to face shape by following
these steps,
determine your face shape to help know what glasses will best
suit your face shape.
Face shapes include square face shapes, round face shapes, pear
face shapes, oval face shapes and heart face shapes. The
[best glasses for different face shapes](https://www.oscarwylee.com.au/glasses/face-shapes)
with a 70's aesthetic are listed below.
* Square face shape: Square faces are
characterised by an angular forehead and chin, and a face that
is mostly in proportion. Round or oval 70s glasses and
sunglasses are good for square faces, as they soften the
naturally sharp angles.
* Round face shape: Round face shapes are
characterised by a round, softer look. Round face shapes are
well-suited to rectangular or square-shaped frames, as they
help to bring structure to the face.
* Pear face shapes: Pear face shapes are
characterised by a narrow forehead and fuller jaw. Rectangular
and square glasses are well-suited to pear face shapes, as
they add width to the forehead and help balance the face.
* Oval face shape: Oval face shapes resemble an
oblong shape and have smooth curves. Frames that suit an oval
face shape include rectangular and square-shaped frames, as
they help to balance the roundness of the face and bring
balance to features.
## Which Material is Best for 70s Glasses?
The various materials that may be best for 70s glasses include
stainless steel and acetate. The
different material options for 70s glasses will depend on your
preferences and what is available for your preferred styles of
frames.
[Stainless steel glasses](https://www.oscarwylee.com.au/glasses/materials/stainless-steel.html)
refer to glasses that are made with corrosion-resistant and
durable stainless steel frames. Stainless steel for glasses make
for easily stylish and sleek frames, suitable to pair with
different outfit styles.
[Acetate glasses](https://www.oscarwylee.com.au/glasses/acetate-frame)
are made from a flexible cellulose material that frames can be
made from, coming in a variety of colours and designs.
### What are 70s Glasses?
70s glasses refer to a style of
glasses that may be reminiscent of frames popularly worn during
the 1970s
and typically feature oversized square frames, aviator styles,
round frames and square frames. Oscar Wylee offers options that
can make for that ideal 70s aesthetic.
## How to Buy 70s Glasses According to Bridge Width?
There are
glasses of a variety of widths available at Oscar Wylee to
accommodate all face sizes when buying 70s glasses, including
narrow, medium and wide.
The way to buy 70s glasses according to width is listed below.
* Narrow: Narrow width frames are available at
Oscar Wylee. Our narrow frames are good for petite and narrow
faces.
* Medium: Medium frames are available&nbsp; at
Oscar Wylee in a range of colours and shapes. Medium frames are
well suited to those with average, or medium sized faces.
* Wide: Wide frames are available at Oscar Wylee.
Wide frames are good for those with wider, larger faces.
### Which Colour Pattern is Best for 70s Glasses?
The colour pattern that may be best for 70s glasses
can include solid colours and striped styles. Oscar Wylee's
options for 70s glasses feature solid colours such as gold,
silver, rose gold, black, pink, purple and blue.
What is deemed the best colour pattern will ultimately come down
to personal preference.
## What Types of Nose Shapes Complement 70s Glasses Best?
There are no particular nose shapes that complement 70s glasses
best.
70s glasses are suitable for any
[type of nose shape](https://www.oscarwylee.com.au/glasses/nose-types)
and will depend on your personal taste and style.
### Are Round 70s Glasses Suitable for Prescription Lenses?
Yes, round 70s glasses are suitable for prescription lenses.
Round 70s glasses and other 70s styles can be fitted with
[prescription glasses](https://www.oscarwylee.com.au/glasses/silhouette/aviator-glasses.html)
to help correct vision. You can also check with your optometrist first before making
any purchase, on what frame styles will be suitable for your
vision needs and preferences.
### Are Aviator Glasses Considered Part of the 70s Style?
Yes, aviator glasses are considered part of the 70s style.
Aviators came about originally during the 1930s according to the
North Central Institute (2022) with the first pair of aviator
sunglasses commissioned by the US military in 1935.
[Aviator glasses](https://www.oscarwylee.com.au/glasses/silhouette/aviator-glasses.html)
rose in popularity during the 60s and 70s with major figures
seen sporting them creating a reputable association with the
frame.
#### Are 70s-Inspired Sunglasses Practical for Outdoor Sports?
Yes, 70s-inspired sunglasses
can be practical for outdoor sports, however, it will depend on
the type of the sport.
Some outdoor sports may require specific styles that are designed
for outdoor sports and active use as they protect more of the eye
and facial area from UV light. They feature impact-resistant
lenses while maintaining its lightweight nature, optimal for more
frequent or spontaneous movement. Oscar Wylee's
[active collection](https://www.oscarwylee.com.au/sunglasses/collection/active-collection.html)
offers optimal options that meet both functional and aesthetic
needs.
## What are the Price Factors for 70s Glasses?
The price factors for women's sunglasses at Oscar Wylee will vary
depending on whether there are prescription lenses in the
sunglasses.
One pair of women's sunglasses starts from $169, two pairs from
$199 and three pairs from $249.
These prices apply to non-prescription glasses.
Prescription sunglasses will incur additional fees on top of
these, through features such as lens thickness and add-ons.
### How to Adjust 70s Glasses for a Comfortable Fit?
You may not be able to adjust 70s glasses for a comfortable fit
yourself.
For a more comfortable fit, choose glasses that don't slide down
or feel tight on your nose or temples.
If you do experience some discomfort when wearing your glasses,
see our optometrist in-store and they may be able to adjust your
frames. It is important to consult with the optometrist first as
attempting to adjust your glasses yourself could result in damage.
### What Lens Types Work Best with 70s Glasses Frames?
The lens types that can work best with 70s glasses
can include multifocal lenses, photochromic lenses, tinted
lenses, high index lenses, single vision lenses, blue light
filter lenses, polarised lenses, photochromic lenses and prism
lenses. All of these
[lens types](https://www.oscarwylee.com.au/glasses/eye/types-of-lenses)
are available to add on top of the price of your standard frames.
#### How Durable are 70s Glasses Frames?
70s glasses frames
can offer optimal durability at different levels based on the
materials that are used. 70s glasses frames can prioritise design for visual style as
well for quality and functionality. Here at Oscar Wylee, our
frames provide distinct and intentional designs with high-quality
materials such as acetate and stainless steel.
### Do 70s Prescription Glasses Change How Your Face Looks?
No, 70s prescription glasses
won't necessarily change how your face looks.
However, 70s prescription glasses can either enhance your features
or may not complement your features. However, this will depend on
your personal preference and can differ between individuals.
### What is the Duration of Shipment for 70s Glasses?
Oscar Wylee offers domestic shipping for 70s glasses ordered on
the website. Typically,
deliveries will usually be dispatched within 7-10 business
days. An email will be sent to you confirming the order alongside an
order tracking link. Deliveries to the home may take up to 2
weeks.
[Prescription Glasses](https://www.oscarwylee.com.au/glasses.html)
[Women’s Glasses](https://www.oscarwylee.com.au/glasses/collection/womens-glasses.html)
[Men’s Glasses](https://www.oscarwylee.com.au/glasses/collection/mens-glasses.html)
[Glasses for Seniors](https://www.oscarwylee.com.au/glasses/collection/seniors.html)
[Glasses for Kids](https://www.oscarwylee.com.au/glasses/collection/kids-collection.html)