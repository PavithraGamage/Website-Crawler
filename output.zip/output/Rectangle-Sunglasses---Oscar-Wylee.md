# Source: https://www.oscarwylee.com.au/sunglasses/silhouette/rectangle.html

9 Products        
Showing 9
1. [](https://www.oscarwylee.com.au/jett-sunglasses.html)
[Jett](https://www.oscarwylee.com.au/jett-sunglasses.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/jett-sunglasses.html)
[3 pairs from $249](https://www.oscarwylee.com.au/jett-sunglasses.html)
2. [](https://www.oscarwylee.com.au/sunglasses/materials/shaz-sunglasses.html)
[Shaz](https://www.oscarwylee.com.au/sunglasses/materials/shaz-sunglasses.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/sunglasses/materials/shaz-sunglasses.html)
[3 pairs from $249](https://www.oscarwylee.com.au/sunglasses/materials/shaz-sunglasses.html)
3. [](https://www.oscarwylee.com.au/stevie-sunglasses.html)
[Stevie](https://www.oscarwylee.com.au/stevie-sunglasses.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/stevie-sunglasses.html)
[3 pairs from $249](https://www.oscarwylee.com.au/stevie-sunglasses.html)
4. [](https://www.oscarwylee.com.au/christina-sunglasses.html)
[Christina](https://www.oscarwylee.com.au/christina-sunglasses.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/christina-sunglasses.html)
[3 pairs from $249](https://www.oscarwylee.com.au/christina-sunglasses.html)
5. [](https://www.oscarwylee.com.au/jessie-sunglasses.html)
[Jessie](https://www.oscarwylee.com.au/jessie-sunglasses.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/jessie-sunglasses.html)
[3 pairs from $249](https://www.oscarwylee.com.au/jessie-sunglasses.html)
6. [](https://www.oscarwylee.com.au/paloma-sunglasses.html)
[Paloma](https://www.oscarwylee.com.au/paloma-sunglasses.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/paloma-sunglasses.html)
[3 pairs from $249](https://www.oscarwylee.com.au/paloma-sunglasses.html)
7. [](https://www.oscarwylee.com.au/oliver-sunglasses.html)
[Oliver](https://www.oscarwylee.com.au/oliver-sunglasses.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/oliver-sunglasses.html)
[3 pairs from $249](https://www.oscarwylee.com.au/oliver-sunglasses.html)
8. [](https://www.oscarwylee.com.au/mesa.html)
[Mesa](https://www.oscarwylee.com.au/mesa.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/mesa.html)
[3 pairs from $249](https://www.oscarwylee.com.au/mesa.html)
9. [](https://www.oscarwylee.com.au/loretta-sunglasses.html)
[Loretta](https://www.oscarwylee.com.au/loretta-sunglasses.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/loretta-sunglasses.html)
[3 pairs from $249](https://www.oscarwylee.com.au/loretta-sunglasses.html)
9 Products        
Showing 9
Choosing the Best Glasses
Width, Fit, Lenses &amp; Colour
FAQs, Price &amp; Shipping
## How to Choose the Best Rectangle Sunglasses for Women?
The way
to choose the best rectangle sunglasses for women involves
considering face shape, assessing frame size, and considering
personal style.
The best way to choose rectangle sunglasses for women is listed
below.
* Consider face shape: Considering face shape
is the first step in choosing the best rectangular sunglasses
for women. There are certain face shapes that will work best
with rectangle sunglasses. Faces that are more curved, such as
round, oval and pear, will work best for rectangle sunglasses,
as they help to bring angles and structure to the face.
* Assess frame size: Assessing frame size is an
important step in choosing the best rectangle sunglasses for
women. If a person chooses a frame that is too big or too
small for their face, it may end up looking disproportionate
on the face.
* Consider personal style: Consider personal
style when choosing the best rectangular sunglasses for women.
Colour, size and frame materials can all impact the styling of
a frame and should be considered.
## How to Choose the Best Rectangle Sunglasses for Men?
The way
to choose the best rectangle sunglasses for men involves the
same process as choosing for women, including assessing frame
size, considering face shape and considering personal
style.
Anyone, regardless of gender, can wear rectangle sunglasses, so
the process of choosing will generally be the same for everyone.
The best way to choose rectangle sunglasses for men is listed
below.
* Assess frame size: Assessing frame size is an
important step in choosing the best rectangle sunglasses for
men. There are a variety of rectangle sunglasses available in
different sizes and widths, including narrow, medium and wide.
If a man chooses a frame that is too big or too small for his
face, it may end up looking disproportionate.
* Consider face shape: Considering face shape
is another important step in picking the best rectangular
sunglasses for men. Round, oval and pear face shapes will
generally work best for rectangle sunglasses, as they bring
structure to the face.
* Consider personal style: Consider personal
style when choosing the best rectangular sunglasses for men.
Men who prefer a more subtle style may want rectangle
sunglasses that are a more neutral colour and size. Those who
like to stand out might want a frame material like acetate,
which can be thick and have bold colour.
### How to Choose the Best Rectangle Sunglasses According to Face
Shape?
The way to choose the best rectangle sunglasses according to
face shape
involves identifying face shape and choosing a complementary
frame. Generally,
round, oval and pear face shapes are the
[best face shapes](https://www.oscarwylee.com.au/glasses/face-shapes)
for rectangle sunglasses
as they are curved, and often need a more angular frame to help
bring balance and structure to the face. The way to choose the
best rectangle sunglasses according to face shape is listed
below.
* Round face shapes: Round face shapes are
characterised by their circular, curved shape. Rectangle
sunglasses are good for round face shapes as their angles help
to bring some structure to the face.
* Oval face shapes: Oval face shapes are
similar to round face shapes as they are also characterised by
roundness and curves, but are generally longer than they are
wide. Rectangle sunglasses are well-suited to oval face
shapes, and they can bring some angles to the face, which can
balance the features.
* Pear face shapes: Pear face shapes are
characterised by a narrow forehead area, with less prominent
cheekbones and a fuller jawline. Rectangle sunglasses are a
good choice for pear face shapes as they can help balance the
face by bringing some dimension to the browline.
### How to Choose the Best Rectangle Sunglasses According to Eye
Colour?
Eye colour
does not generally play a role in choosing the best
rectangular sunglasses. Face shape, frame size and eye care needs are the more
important considerations to be made when choosing the best
rectangular sunglasses, as these can directly affect practical
elements like fit, and how effective the frames are at providing
vision correction. If a person does want to consider eye colour
when choosing rectangular sunglasses, then they should pick
complementary colours. For example, a person with lighter eyes
may want to pick another light colour frame to match.
## Which Material is Best for Rectangle Sunglasses?
The material that will be best for rectangle sunglasses will
mostly be dependent on the wearer and their material
preferences. At Oscar Wylee, we have sunglasses made from
acetate and metal.
[Acetate sunglasses](https://www.oscarwylee.com.au/sunglasses/materials/acetate.html)
are strong, with hypoallergenic properties. Acetate sunglasses
can come in many designs and colourways.
[Metal sunglasses](https://www.oscarwylee.com.au/sunglasses/materials/metal.html)
are sleek and stylish. Metal frames have lightweight properties
for those who want a comfortable feel.
## How to Buy Rectangle Sunglasses According to Bridge Width?
The way to buy rectangle sunglasses according to bridge width is
to try on some frames and assess the [types of nose bridge](https://www.oscarwylee.com.au/glasses/nose-bridge-types) widths that will suit you. Exact width and
fit may differ between retailers, but generally, sunglasses
widths are narrow, medium and wide. The ways to
buy rectangular sunglasses according to bridge width are below.
* Narrow rectangle sunglasses: Narrow
rectangular sunglasses are well-suited to those with thinner
or more petite faces. Kids and teenagers may also be well
suited for more narrow rectangular sunglasses.
* Medium rectangle sunglasses: Medium rectangle
sunglasses are a good choice for those with more average-sized
faces.
* Wide rectangle sunglasses: Wide rectangle
sunglasses are made to suit those with larger or more wide
faces.
### Which Colour Pattern is Best for Rectangle Sunglasses?
No colour pattern is necessarily the best for rectangle
sunglasses, as this will be down to the wearer's personal style.
Matte, solid and transparent colour patterns are some popular
choices for rectangle sunglasses.
The colour patterns that are best for rectangle sunglasses are
listed below.
* Matte Rectangle Sunglasses: Matte rectangle
sunglasses will have a flat-looking finish and are good for
those who want a less shiny, more subtle colour.
* Solid Rectangle Sunglasses: Solid rectangle
sunglasses refer to sunglasses with one solid colour on the
frame, good for those who want a bold look.
* Transparent Rectangle Sunglasses: Transparent
rectangular sunglasses refer to sunglasses that are
see-through. Transparent glasses can be coloured, but are
translucent.
### Can You Adjust Rectangle Sunglasses' Nose Pads?
Yes, you will be able to adjust the nose pads of rectangular
sunglasses if they come with adjustable nose pads. Some nose pads on rectangular sunglasses will be fixed,
meaning they are built into the frame and can't be adjusted.
Silicone adjustable nose pads can be altered to better fit the
shape of the nose.
### Which Lens Options Work Best with Rectangle Sunglasses?
The lens options that work best with rectangle sunglasses
will be dependent on the wearer and their eye care
needs. Some people who have a prescription that helps them see
clearly may also need a prescription added to the lens in their
rectangular sunglasses. Other
[lens types](https://www.oscarwylee.com.au/glasses/eye/types-of-lenses)
or options for sunglasses include polarisation, to help cut
glare.
## How does Nose Shape Affect Wearing Rectangle Sunglasses?
Nose shape does not typically affect how a person wears
rectangle sunglasses. A person's nose bridge may be better suited to certain
glasses features, such as adjustable nose pads, better than
other nose bridges. However,
[nose shape](https://www.oscarwylee.com.au/glasses/nose-types)
does not play a major role.
### What are Rectangle Sunglasses?
Rectangle sunglasses
refer to sunglasses that have a rectangular frame around the
lens. Sunglasses refer to eyewear that is designed to protect a
person’s eyes from UV rays emitted from the sun.
Sunglasses can be prescription, meaning they have a
person’s vision correction in the lens, or
non-prescription. Rectangle sunglasses are a popular choice for
sunglasses in terms of shape, as they are versatile, suited to
several face shapes and come in many different colours and
patterns.
[](https://www.oscarwylee.com.au/jett-sunglasses.html)
[Jett](https://www.oscarwylee.com.au/jett-sunglasses.html)
$169    
Add to Cart
[Shop Jett](https://www.oscarwylee.com.au/jett-sunglasses.html)
[2 pairs from $199](https://www.oscarwylee.com.au/jett-sunglasses.html)
[3 pairs from $249](https://www.oscarwylee.com.au/jett-sunglasses.html)
[](https://www.oscarwylee.com.au/christina-sunglasses.html)
[Christina](https://www.oscarwylee.com.au/christina-sunglasses.html)
$169    
Add to Cart
[Shop Christina](https://www.oscarwylee.com.au/christina-sunglasses.html)
[2 pairs from $199](https://www.oscarwylee.com.au/christina-sunglasses.html)
[3 pairs from $249](https://www.oscarwylee.com.au/christina-sunglasses.html)
[](https://www.oscarwylee.com.au/paloma-sunglasses.html)
[Paloma](https://www.oscarwylee.com.au/paloma-sunglasses.html)
$169    
Add to Cart
[Shop Paloma](https://www.oscarwylee.com.au/paloma-sunglasses.html)
[2 pairs from $199](https://www.oscarwylee.com.au/paloma-sunglasses.html)
[3 pairs from $249](https://www.oscarwylee.com.au/paloma-sunglasses.html)
[](https://www.oscarwylee.com.au/loretta-sunglasses.html)
[Loretta](https://www.oscarwylee.com.au/loretta-sunglasses.html)
$169    
Add to Cart
[Shop Loretta](https://www.oscarwylee.com.au/loretta-sunglasses.html)
[2 pairs from $199](https://www.oscarwylee.com.au/loretta-sunglasses.html)
[3 pairs from $249](https://www.oscarwylee.com.au/loretta-sunglasses.html)
### Are Clear Frames Considered for Rectangle Sunglasses?
Yes,
clear frames can be considered for rectangle
sunglasses.
[Clear frames](https://www.oscarwylee.com.au/glasses/clear-glasses.html)
refer to translucent frames that are totally clear, like a
window, or coloured. Clear frames are a subtle yet stylish
design for rectangle sunglasses.
#### Can Rectangle Sunglasses be Used for Outdoor Sports?
Yes, rectangle sunglasses can be used for outdoor sports, if
they are made with the right materials. A person may want to choose
[active sunglasses](https://www.oscarwylee.com.au/sunglasses/collection/active-collection.html)
or sports sunglasses that are in a rectangular shape, as opposed
to normal sunglasses, as active sunglasses are designed to
withstand the rough and tumble of outdoor sports.
## What Factors Affect the Price of Rectangle Sunglasses?
The
price of rectangle sunglasses will differ depending on the
retailer and is generally affected by factors such as lens
type and whether or not the sunglasses have a
prescription. At Oscar Wylee, our non-prescription sunglasses from our core
range start from
1 pair from $169, 2 pairs from $199 and 3 pairs from
$249. To add prescription to sunglasses will cost extra on top of
the price of frames.
### How Durable are Rectangle Sunglasses Frames?
The
durability of rectangle sunglasses frames are usually
dependent on the material, and how well they are looked
after. Rectangle sunglasses made from durable and strong materials
like acetate or metal, are usually durable. The way a person
looks after their rectangle sunglasses also plays a part in how
long-lasting they can be. Sunglasses must be well looked after,
including being in their case when not being used or hanging off
clothes, to protect from breakage.
### What is the Duration of Shipment for Rectangle Sunglasses?
The duration of shipment for rectangular glasses is
approximately
7-10 business days, for an Oscar Wylee store
pick-up. If you are having your rectangle sunglasses delivered
to your house, this can take up to 2 weeks.
[Prescription Glasses](https://www.oscarwylee.com.au/glasses.html)
[Women’s Glasses](https://www.oscarwylee.com.au/glasses/collection/womens-glasses.html)
[Men’s Glasses](https://www.oscarwylee.com.au/glasses/collection/mens-glasses.html)
[Senior Glasses](https://www.oscarwylee.com.au/glasses/collection/seniors.html)
[Glasses for Kids](https://www.oscarwylee.com.au/glasses/collection/kids-collection.html)