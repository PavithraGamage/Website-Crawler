# Source: https://www.oscarwylee.com.au/locations/optometrist-joondalup.html

# Optometrist Perth
Lakeside Joondalup Shopping CityGround Level, Shop T007A420
Joondalup DriveJoondalup WA 6027
* Near Woolworths
Opening hours
Monday9:00am - 5:30pm
Tuesday9:00am - 5:30pm
Wednesday9:00am - 5:30pm
Thursday9:00am - 9:00pm
Friday9:00am - 5:30pm
Saturday9:00am - 5:00pm
Sunday11:00am - 5:00pm
*Store hours reflect local standard trading hours and exclude public
holidays
[Visit our Joondalup Google Business page for directions,
reviews, and updates.](https://g.page/r/CdyDbvjdFSfnEBA)
Book Appointment
[Call us: (08) 6209 7966](tel:(08) 6209 7966)
[Leave a Review!](https://g.page/r/CdyDbvjdFSfnEAg/review)
Our Reviews
Emma B
4 days ago
Had my second eye test here and the team are so friendly and helpful. Not at all pushy. The optometr...ist is excellent.
See more
Νίκος Κ.
1 week ago
It was a really great experience! Helpful staff, kind people and ready to answer queries! Thanks onc...e again!
See more
Augustine Ndilowe
1 week ago
Very welcoming and excellent service. Surely eager to recommend
Antigoni Leftherioti
1 week ago
Really good experience. Lovely staff! Experienced and really professional optometrist.
Carolyn Iloa
2 weeks ago
A prompt examination with a result im more than happy with. Thank you
Jack
2 weeks ago
Helpful, informative and friendly staff.
Vicky Santamaria
2 weeks ago
Muskan Mehmi
3 weeks ago
Oscar Gomez
3 weeks ago
Very professional service and great service
Keshia Dorrington
1 month ago
Very helpful staff and organised appointments
Jan McBain
1 month ago
First time I have gone to this optometrist and found they are very helpful and friendly staff. They ...did a very thorough job examining my eyes &amp; look forward to getting my new glasses.
See more
Jon
1 month ago
The team were very knowledgeable and helpful. Very satisfied with the service. Thanks.
neeyanta n
1 month ago
The best experience I’ve had at an optometrist yet! I’ve been wearing glasses for over 10 years, but... this is the first time I’ve had an optometrist really explain everything to me- honestly the best eye test I’ve ever had! The retail staff were also so lovely and helpful ???? I can’t wait to get my glasses!
See more
Karen Dredge
1 month ago
Friendly staff. Optometrist is great and knowledgeable. No hard sales push. Great choice of frames t...o suit all at great prices. Highly recommend.
See more
simranjeet kaur
1 month ago
Had a great experience at Oscar Wylee! Bikram, the optometrist, was very professional, thorough and ...friendly. He made my eye check-up comfortable and explained everything clearly. Highly recommend Bikram and the team!
See more
Sobia Khan
1 month ago
Greg Burke
1 month ago
Service was great now let's see how the glasses go when they come in
Suzanne Bolland
1 month ago
Very Happy with the service at Joondalup
Val Stoev
1 month ago
Great service hope my glasses are great too
Rikki Philpott
1 month ago
Great experience, I have been to specsavers in the past and this was by far a much better experience.... Really impressed and I’ve already told my family about my experience and to make the switch
See more
Sarah Hutchings
2 months ago
Amazing experience with my neurodiverse anxious 8yr old. Phillip and the lady we saw (Micheala I thi...nk) were sooo brilliant with her and were happy for me to be right with her to support her during her 1st test. It was such a positive experience!
See more
Jadonemash
2 months ago
Superb service! I urgently needed an eye appointment, they got me in immediately and did a through e...ye exam.  Highly recommended
See more
Tricia Gilbert
2 months ago
Very helpful throughout.
Kate Ferguson
2 months ago
Easy, quick and lovely staff.
Apollo Ao
2 months ago
I got my meta all the sudden not working after 3 months using back for warranty. Staff super friendl...y and helpful. With professional troubleshooting and test just replace me a new pair. Very happy. 100% sure will stay with OPSM
See more
Jennifer Bateman (NovelTea Vintage)
3 months ago
Excellent full service. Kind and knowledgeable staff. Like the more funky style of glasses they have... vs other optometrists. Fair prices.
See more
Goran Milosevski
3 months ago
Very proffeshional staff. I would highly recomend their service.
John Bones
3 months ago
Professional, friendly staff. Would not go anywhere else
Richard Chew
3 months ago
The optometrist very professional and friendly. I would recommend his optometrist, my friends and fa...mily. Thank you ????
See more
Kara Negus
3 months ago
My eye tests are always great here. I have PTSD and the air puffs in my eyes make me jump every time... and I hate them. Everyone is very kind, and understanding of my anxiety, they allow my partner to come in to be with me, and they explain everything that's going to happen as it's happening so that's all very reassuring. They also have more fun glasses than other places I've been to in the past, and since going there I've not gone back to another optometrist. Their patient care is outstanding, and the prices are also really good.
See more
becky [[email&nbsp;protected]](https://www.oscarwylee.com.au/cdn-cgi/l/email-protection)
3 months ago
Excellent service, friendly professional staff, would definitely recommend a visit and a beautiful r...ange of glasses.
See more
Jenny Curel
3 months ago
Excellent service  and friendly
JT Tutton
3 months ago
Fantastic service!
Kitt Grey
3 months ago
renecimin daling
4 months ago
Rod Dixon
4 months ago
Brilliant service by the ladies on the counter and the optician who was very professional and very h...elpful.
See more
Renae Luplau
4 months ago
Sirilux Srisen
4 months ago
Staff very nice and helpful, highly recommend.
Polita Rosman
4 months ago
I had the best experience i have had in Perth in a very long time! Highly recommend
Cheryl Moran
4 months ago
Excellent customer service.
Robert Goodings
4 months ago
Very friendly and professional
Marie Twomey
4 months ago
Very professional &amp; informative
Steevie-bo Johnson
5 months ago
Lovely staff, great glasses and prices too!
Patrick Douglas
5 months ago
Easy to make online appointment . All staff very professional,  eye test quick, good to get instant ...results with any recomendations. Get eyes tested early to prevent any issues
See more
Loren Aime
5 months ago
My whole overall experience here was amazing. Out of every optometrist I’ve been to these guys were ...super amazing. Friendly staff, accomodating and also really really helpful picking out glasses. And even got my a bag to put all of my stuff in. The eye test itself was amazing staff were super kind and friendly to adjustments. Will definitely be going back
See more
Chloe McDonnell
5 months ago
Really positive experience getting an eye test - all of the staff i interacted with were super frien...dly and made me feel comfortable.
See more
Roger Vaughan
5 months ago
I popped in at lakeside shop as my frames where starting to give way I asked if I could book an appo...intment and she said I could have one there and then witch was great the test went well and the staff were really helpful well done guys ????
See more
Jake Quidit
6 months ago
It was straight forward and no time wasted. I prefer this kind of service and the staff were friendl...y enough to listen to your concerns and escalated to appropriate personnel. I like the optometrist who did my eye test
See more
Jamezy
6 months ago
Real pleasure speaking with the Optometrist on the day, not only very knowledgeable but personable t...oo which made all the difference to my experience.
See more
Brian Vallentine
6 months ago
My recent eye test was well organised and on time the test procedure was very thorough and the follo...w up after test by optometrist Bikramjit
Singh is nothing short of excellent  thank you
See more
## Find an Optometrist in Joondalup With Oscar Wylee
Located next to Woolworths in Lakeside Joondalup Shopping City,
the third largest shopping centre in Western Australia, our trained eye care
professionals are able to carry out Medicare bulk billed eye tests. Situated
close to Currambine and Heathridge and right by Joondalup station, you’ll find
us in this northern Perth suburb that stretches from white sandy beaches in
the west to Lake Joondalup in the east.
Our Joondalup store
is just a 5-minute drive from the Neil Hawkins Park that borders Lake
Joondalup. Here you can find native Australian Ringneck parrots, long neck
turtles, black swans and at twilight, you might spot some Kangaroos who come
to feed on the grass. Come visit us in-store where we are committed to looking
after your eye health and bringing you fashion-forward glasses frames at
affordable prices.        
Meet Our Team
* Optometrist Partner
BSc (Hons)
MCOptom
* Retail Partner
Our Services
* Bulk
Billed Eye Examinations
* Professional Frame Styling
* Frame Adjustments and
Repairs
* Visual Fields Testing
* Digital Retinal Scanning
* Vocational &amp;
Employment Assessments
* Colour Vision Screening
* Paediatrics (from 5 years)
Show All
## Find an Optometrist in Joondalup, Perth for an Eye Health Test
Visit an Oscar Wylee optometrist for your regular eye health
test in Joondalup, Perth. Located in Lakeside Joondalup Shopping
Centre, our optometrists will conduct vision testing and
assessments such as a slit lamp test to help diagnose eye
diseases. Our Joondalup optometrists can also update
prescriptions, give eye care advice and refer patients with
complex eye conditions to an eye doctor if needed, known as an
ophthalmologist in Australia. The cost for eye care services
including optometrists and ophthalmologists in Joondalup, Perth
may be dependent upon a person’s individual eye care needs. At
Oscar Wylee, our eye tests are conducted at a bulk billed price
under Australia’s Medicare system.
Our Oscar Wylee retail team and optical dispensers are available
in our glasses shop in Lakeside Joondalup to fit glasses, make
frame adjustments and provide styling advice. Oscar Wylee is
passionate about our customers finding the eyewear that is
perfect for their vision and lifestyle needs. So whether it’s
our prescription glasses, prescription sunglasses or
non-prescription glasses that you need, our team will ensure you
leave with frames that are perfect for you!
## How to Find an Optometrist in Joondalup, Perth?
To find an optometrist in Joondalup, Perth you can take certain
steps that can help make it easier for you such as
searching online, assessing the store’s opening hours and
finding the directions to your chosen location.
The steps on how to find an optometrist in Joondalup, Perth are
listed below.
1. Search online using the phrase, optometrist near me in
Joondalup. This can also be done here on the website via our
locations page.
2. Click on the Oscar Wylee link, which will take you directly to
our Joondalup optometrist store page.
3. See the store’s opening hours and where the store is located
specifically.
4. Use the Joondalup Google Business page link located under
store hours to see the directions on how to get to the store.
You can also find an optometrist in Joondalup, Perth by
searching the keywords optometrist near me. If you have
locations enabled on your smartphone and you’re in the
Joondalup, Perth area, our Joondalup store page should appear
easily for you to click on.
### Is it Hard to Get an Eye Appointment in Joondalup, Perth?
No, it is not hard to get an eye appointment in Joondalup. You
can easily book an appointment to see an Oscar Wylee optometrist
in Joondalup, Perth right here on this page. At Oscar Wylee we
have highly qualified optometrists available for bulk billed eye
appointments, which can be booked online or in-store.
#### How to Compare Optometrists in Joondalup, Perth to Each Other?
To compare optometrists in Joondalup, Perth, you can use factors
such as eye
tests offered, health fund coverage, lens types and add-ons
and eyewear offered.
To take care of your vision and eye health, it is important to
receive an eye test at least once every two years. There are
different types of tests that can be performed in an eye test
and not all optometrists may offer the same tests. Health funds
can be used to help cover some of the cost of your frames and
lenses. To find out if your health fund is accepted at an
optometrist in Joondalup, Perth visit their website. In the case
of Oscar Wylee, we accept all major health funds and provide
on-the-spot claims in-store. There are many different lens
options available for prescription glasses such as
single-vision, multifocal and high-index lenses. Most
optometrists in Joondalup, Perth will offer these lenses
although it is good to make sure. There are also lens add-ons
available to enhance your glasses such as anti-reflective and
blue light filters. Finally, if you are looking to purchase a
pair of glasses after your eye test, you can compare the
different styles and colours you are interested in from the
optometrists in Joondalup, Perth. Oscar Wylee offers a wide
range of frames with vintage and modern inspirations in bold
colours and subtle designs.
#### How to Find an Eyeglasses Shop in Joondalup, Perth?
To find a glasses store in Joondalup, Perth you can try to
follow these simple steps including
searching online, selecting a convenient location and looking
at their health insurance policies.
The steps on how to find a glasses store in Joondalup, Perth are
listed below.
1. Search online using the phrase, glasses store in Joondalup,
Perth. This will provide you with various options for glasses
stores in the whole Joondalup, Perth area.
2. Select a glasses store that is most convenient for you to
travel to.
3. Click the link to find out more information such as opening
hours, exact location and directions to the glasses store in
Joondalup.
4. Read their health insurance policies to ensure you know what
health benefits you have access to.
Our Oscar Wylee glasses store in Joondalup, Perth offers primary
eye care services such as comprehensive eye tests as well as
other services performed by an optometrist and offers
prescription and non-prescription eyewear.
##### Is it Possible to Purchase Prescribed Sunglasses in Joondalup,
Perth Without Seeing an Optometrist?
Yes and no, it is possible to
[purchase prescribed sunglasses](https://www.oscarwylee.com.au/sunglasses.html)
in Joondalup, Perth without seeing an optometrist if you already
have a prescription that has not expired. If your prescription
is expired, you can book an eye test to receive an updated or
new prescription which will require you to see an optometrist.
This will ensure your prescription sunglasses are appropriate
for your visual needs.
## Where is the Oscar Wylee Joondalup, Perth Optometrist Located?
The Oscar Wylee Joondalup optometrist is located in Lakeside
Joondalup Shopping City, in the suburb of Joondalup. The
Lakeside Joondalup Shopping City is located at 420 Joondalup
Drive in Joondalup, Perth.
### What is the Phone Number of Oscar Wylee Joondalup, Perth
Optometrist Store?
The phone number for our Oscar Wylee Joondalup, Perth
optometrist store is (08) 6209 7966. Our Oscar Wylee Joondalup,
Perth store is open, and our staff are available to be contacted
between 9 am and 5.30 pm Monday to Wednesday, 9 am to 9 pm on
Thursday, 9 am to 5.30 pm on Fridays, 9 am to 5 pm on Saturdays
and 11 am to 5 pm on Sundays.
### What are the Reviews for Oscar Wylee Joondalup, Perth Optometrist?
The customer reviews for our Oscar Wylee Joondalup, Perth
optometrist, can be found here on the website and online when
you search for Oscar Wylee Joondalup optometrist. The reviews
for our Oscar Wylee Joondalup optometrist are listed below.
* Marlisa Grausser: 
I am very happy and impressed with the professional service I
received during my eye test and purchase of my new eyewear.
Thank you to all the staff of Oscar Wylee Joondalup.
* Sarah Silveria: 
The team here were really helpful from start to finish. I felt
like the eye exam was thorough and he was able to answer all
of my questions. Would recommend.
* Mustafa Maza: 
Had a very nice experience. My first time at Oscar Wylee; all
staff were friendly, helpful and professional. Looks like I
will be a regular customer now. Thanks!
#### What Treatments or Eye Care Processes Are Done in the Oscar Wylee
Joondalup, Perth Optometrist Location?
The treatments or eye care processes done in the Oscar Wylee
Joondalup, Perth optometrist location include
a tonometry test, a slit lamp exam, a digital photograph, and
a refraction test.
Additional tests that may also be performed can include
a visual field test and a dilated fundus exam. The
treatments or eye-care processes that are done in the Oscar
Wylee Joondalup optometrist location are listed below.
* A Tonometry Test: An optometrist or optical dispenser
will conduct a tonometry test which involves the use of a
machine that will release small puffs of air into your eyes.
This will assist with measuring pressure in the eye.
* A Digital Photograph: An optometrist or optical
dispenser may take a digital photograph of your eye which can
be kept on record to use in future appointments to evaluate
any changes to your eye.
* Slit Lamp Test: A slit lamp test can be used to
evaluate your eye health, by examining your cornea and iris
which are the anterior and posterior of the eye.
* Refraction Test: During a refraction test, an
optometrist will have you view an image through different
lenses and ask you to confirm which helps you see the image
clearer.
* Visual Field Test: A visual field test can assist with
assessing your peripheral vision, which may be beneficial for
identifying any signs of glaucoma.
* Dilated Fundus Exam: A dilated fundus exam can help an
optometrist assess your health in more detail by getting a
clear view of the retina. This test is typically carried out
for patients with diabetes and those who may be at risk of
developing retinal damage.
## How Many Optometrists Exist in Joondalup, Perth?
Many optometrists exist in Joondalup, Perth and in the Joondalup
Shopping Centre, including Oscar Wylee. The amount of
optometrists available in an area will typically depend on the
population and the eye care needs of those in the area. At Oscar
Wylee Joondalup, Perth, our team is passionate about providing
our customers with high-quality, dedicated eye care services.
Our optometrists are available to provide bulk billed eye tests
with our dedicated optometrists, prescription updates and new
frames. If you are looking for an optometrist in Joondalup,
Perth, Oscar Wylee is available to provide all your eye care and
eyewear needs.
### What are the Other Closest Optometrist Locations to Joondalup,
Perth in Australia?
The closest Oscar Wylee Optometrist locations to Joondalup,
Perth are Claremont, Morley Galleria and Karrinyup. The
closest Oscar Wylee optometrist locations to Joondalup, Perth
are listed below.
* Claremont: 
Claremont is a suburb approximately 35 km away from Joondalup,
Perth and the Lakeside Joondalup Shopping City, in which you
can find an Oscar Wylee optometrist. Our
[Oscar Wylee Claremont](https://www.oscarwylee.com.au/locations/optometrist-claremont.html)
store is located in the Claremont Quarter Shopping Centre
where our optometrists can provide Medicare bulk billed eye
tests.
* Morley Galleria: 
Morley Galleria is a shopping centre located approximately 27
km away from Lakeside Joondalup, Perth, where our Oscar Wylee
optometrists are available to provide eye tests. Customers can
find
[Oscar Wylee Morley Galleria](https://www.oscarwylee.com.au/locations/optometrist-morley-galleria.html)
on the ground floor of the Galleria Shopping Centre.
* Karrinyup: 
Karrinyup is a suburb approximately 19 km away from Joondalup,
Perth where you can find an Oscar Wylee optometrist. Our
[Oscar Wylee Karrinyup](https://www.oscarwylee.com.au/locations/optometrist-karrinyup.html)
store is located in the Karrinyup Shopping Centre. Here our
team can provide eye care services such as eye tests,
prescription updates and new frames.
### Optometrist Eye Testing in Joondalup
Oscar Wylee Joondalup offers bulk billed Medicare eye health tests.
Our optometrists are trained to carry out eye care processes such as
vision testing, examining the eyes for possible eye diseases, updating
prescriptions and much more. It is recommended that people have an eye
test once every two years, or as otherwise advised by an optometrist,
in order to keep prescriptions updated and stay on top of eye health.
For some of the best optometrists in Joondalup, Australia, who will
take good care of your eye health, visit Oscar Wylee in Lakeside
Joondalup Shopping City.
### Oscar Wylee Joondalup Accepts Leading Health Funds
Our Oscar Wylee eyeglasses shop in Joondalup accepts major health
funds, with our team available in-store to process your health fund
claim with a valid health fund card. Come in and see the team at Oscar
Wylee Joondalup who are committed to making sure you get the
prescription glasses you need at an affordable, competitive price.
### Fashion Forward Styles at Affordable Prices
Oscar Wylee in Joondalup, Perth, is committed to helping you put your
best face forward. With a range of styles, colours and sizes
available, there is a frame to suit everyone at Oscar Wylee. Our
Joondalup store offers prescription glasses, prescription sunglasses
and non-prescription eyewear at an affordable cost. Whether it’s a
blue light filter or a multifocal lens, our experts in-store are ready
and able to help you with any of your eyesight needs.
Book Appointment
[Call us: (08) 6209 7966](tel:(08) 6209 7966)
[Leave a Review!](https://g.page/r/CdyDbvjdFSfnEAg/review)