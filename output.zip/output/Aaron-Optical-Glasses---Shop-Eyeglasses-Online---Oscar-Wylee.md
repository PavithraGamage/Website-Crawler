# Source: https://www.oscarwylee.com.au/aaron-optical.html

# Aaron
1
## Frame Design of Aaron Glasses
The frame design of Oscar Wylee’s Aaron glasses is characterised by their rectangle shape, adjustable nose pads, and titanium and bio acetate frame. Aaron is a men's, intellectual glasses frame that will complement any outfit, day to night.
$199    
In stock
Only %1 left
2 pairs from $249
Discount auto-applied at checkout
Qty
Add to cart
Book an eye test
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
excluding prescription lenses
## About Aaron Frames
Get a new perspective with Aaron. Blending titanium and acetate, this frame is a refined and understated browline shape with comfortable nose pads.
| Frame fit | Measurements |
| --- | --- |
| MEDIUM | 53 - 17 - 147 |
These measurements mean lens width, bridge, and temple length in millimetres (mm). They can be found on the inside of the temple arm. If you already have a pair that you like, you can compare it to these measurements.
### Made from Titanium and Bio Acetate
Oscar Wylee’s Aaron frame is a men's rectangle glasses frame that is perfect for those with round and oval face shapes. The Aaron frame is a rectangle, stylish frame that can be worn every day. The main specs of Oscar Wylee’s Aaron glasses frame, including dimensions, shape, materials, lenses, nose fit, and hinges, are listed below.
| Aaron Frame Features | Aaron Frame Description | Dimensions | Shape | Materials | Lenses | Nose Fit | Hinges |
| --- | --- | --- | --- | --- | --- | --- | --- |
| The dimensions of the Aaron frame are measured in millimetres (mm) and are 53 - 17 - 147, meaning the lens width is 53 mm, the bridge is 17 mm, and the temple length is 147 mm. |
| Aaron is a rectangle shape, well-suited to medium faces. |
| Aaron is made from titanium and bio acetate. |
| The lenses that can be used in the Aaron frame include optical lenses, such as single-vision and multifocal, and non-prescription lenses, which are plain and can have a filter, such as a blue light filter applied. |
| The nose fit for Aaron is characterised by adjustable nose pads. |
| The hinges in Aaron are normal hinges, also known as standard or barrel hinges. |
Show All
### What Inspired the Frame Design of Oscar Wylee’s Aaron Glasses?
The Oscar Wylee Aaron frame design was inspired by current fashion trends, as rectangle glasses are a timeless style.
## What to Know About Oscar Wylee’s Aaron Glasses?
There are many aspects of the Oscar Wylee Aaron frames that customers should know about to decide whether this is the right frame for them. The Aaron frame is a men's rectangle shaped frame. Oscar Wylee’s Aaron frame is suitable for many face shapes, but particularly compatible with round and oval face shapes. The Aaron frame’s simple design makes them fashionable all year round. Aaron features the standard [parts of glasses](https://www.oscarwylee.com.au/glasses/eye/part-of-glasses), such as a rim, temples, lenses and hinges.
### What are the Types of Temple Tips or Earpieces Included with Oscar Wylee’s Aaron Glasses?
The type of temple tips or earpieces included in Oscar Wylee’s Aaron Glasses are made from bio acetate.
### What Type of Nose Bridge do Oscar Wylee’s Aaron Glasses Have?
The type of nose bridge included in Oscar Wylee’s Aaron frame is characterised by adjustable nose pads.
### What Type of Nose Pads are Included with Oscar Wylee’s Aaron Glasses?
Oscar Wylee’s Aaron frame includes adjustable nose pads for an optimal fit suited to many faces.
### What Type of Lenses do Oscar Wylee’s Aaron Glasses Have?
The type of lenses that typically come with the Oscar Wylee Aaron [glasses frame](https://www.oscarwylee.com.au/glasses.html) are optical lenses. Optical lenses are glasses lenses that have a prescription within the lens to help correct vision issues such as myopia, hyperopia, and astigmatism. Aaron frames can also come as sunglasses and with non-prescription lenses and add-ons such as a blue light filter. Aaron frames can be customised into sunglasses in-store or online with add-on tints or polarisation.
### What Material is Used for the Rim of Oscar Wylee’s Aaron Glasses?
The material used for the rim of Oscar Wylee’s Aaron glasses frames is titanium and bio acetate. The rim refers to the part of a glasses frame that holds the lenses.
### What Type of Hinges are Included with Oscar Wylee’s Aaron Glasses?
The type of hinges included with Oscar Wylee’s Aaron frames are normal hinges, also known as standard or barrel hinges. These provide strength and smooth movement connecting the frame's arms and lenses.
## What Face Types are Most Suitable for Oscar Wylee’s Aaron Glasses?
The face types that are most suitable for Oscar Wylee’s Aaron frame are round and oval face types. The Aaron frame is a rectangle shape, meaning that it complements the structure of round and oval faces particularly well. The rectangle Aaron frames help balance the features of [round faces](https://www.oscarwylee.com.au/glasses/face-shapes/round) and [oval faces](https://www.oscarwylee.com.au/glasses/face-shapes/oval), bringing the eyes and brows forward in a flattering way. Although there are many [glasses for face shapes](https://www.oscarwylee.com.au/glasses/face-shapes) that may be considered more aesthetically suitable, it is important that people also choose frames that make them feel most comfortable and represent their personal style.
## What Size Options are Available for Oscar Wylee’s Aaron Glasses?
The size options available for Oscar Wylee’s Aaron frame are a medium-frame fit across all colours.
## What Materials are Used to Create Oscar Wylee’s Aaron Glasses?
The primary materials used to create the Oscar Wylee Aaron frame are titanium and bio acetate. Titanium and bio acetate is used for the rim and titanium for the nose bridge and temples. The temple tips are made from bio acetate. Titanium is a lightweight, durable and corrosion-resistant material. Bio acetate is a material mainly made from plant-based matter such as wood pulp and cotton fibres.
## What’s Included
## OW Case &amp;a Cloth
Protective Case and Lens Cloth
Our high-quality glasses case and lens cloth are included with every purchase of an Oscar Wylee frame. The stylish, magnetic case is made from a hard shell. This sturdy and durable material keeps your glasses protected and safe, wherever you go. Ensure your lenses are clean and scratch-free with our OW microfibre cloth, specifically designed to ensure you have comfortable vision through your lenses.
Oscar Wylee offers:
* Free Shipping for Australian Orders
* 1 Year Warranty on frames and lenses
* Scratch resistance lens coating on all prescriptions
* UV-proof coating on all prescriptions
Health fund rebate: Once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. Learn more about [health funds](https://www.oscarwylee.com.au/health-funds.html).
## Make and Materials
The frames then go through cleaning and strict quality control, and many pairs of crafting hands to be hand-assembled and polished. After your frames have gone through the production process, they are individually examined and&nbsp;packed before making their way to you!Our titanium frames are durable, corrosion resistant, lightweight, hypo-allergenic, with fixed spring hinges. Much of our titanium is sourced from Japan.
## Warranty Information
### Warranty Information
### Warranty Information
Oscar Wylee provides a 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects. We will repair or replace faulty or defective frames or lenses free of charge for warranty claims made within 1 year of the delivery. We also offer repairs or replacement for problems experienced with vision during everyday use for claims made within 30 days of delivery. If the same product has been discontinued or is no longer available, then we may offer an exchange for a similar product or a refund.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Find a Store Location](https://www.oscarwylee.com.au/locations/full-store-list.html)