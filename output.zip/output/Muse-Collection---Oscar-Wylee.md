# Source: https://www.oscarwylee.com.au/glasses/collection/muse-collection.html

[](#layer-product-list) 
[SHOP NOW](#layer-product-list)
[](#layer-product-list)   
Our new collection introduces a full range of sizes from small, regular to large, celebrating
inclusivity in every pair.

The bolder, the better. The Mega Eyewear Collection takes influence from 80’s fashion that is sure
to make a statement.
We’ve taken the frames you know and love and given them an upgrade for comfortable and easy wearing.

7 Products        
Showing 7
1. [](https://www.oscarwylee.com.au/nina-optical.html)
[Nina](https://www.oscarwylee.com.au/nina-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/nina-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/nina-optical.html)
2. [](https://www.oscarwylee.com.au/amanda-optical.html)
[Amanda](https://www.oscarwylee.com.au/amanda-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/amanda-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/amanda-optical.html)
3. [](https://www.oscarwylee.com.au/celeste-optical.html)
[Celeste](https://www.oscarwylee.com.au/celeste-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/celeste-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/celeste-optical.html)
4. [](https://www.oscarwylee.com.au/francis-optical.html)
[Francis](https://www.oscarwylee.com.au/francis-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/francis-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/francis-optical.html)
5. [](https://www.oscarwylee.com.au/zhane-optical.html)
[Zhane](https://www.oscarwylee.com.au/zhane-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/zhane-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/zhane-optical.html)
6. [](https://www.oscarwylee.com.au/paloma-sunglasses.html)
[Paloma](https://www.oscarwylee.com.au/paloma-sunglasses.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/paloma-sunglasses.html)
[3 pairs from $249](https://www.oscarwylee.com.au/paloma-sunglasses.html)
7. [](https://www.oscarwylee.com.au/loretta-sunglasses.html)
[Loretta](https://www.oscarwylee.com.au/loretta-sunglasses.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/loretta-sunglasses.html)
[3 pairs from $249](https://www.oscarwylee.com.au/loretta-sunglasses.html)
7 Products        
Showing 7