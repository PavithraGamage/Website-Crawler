# Source: https://www.oscarwylee.com.au/glasses/eye/seeing-flashing-lights-in-corner-of-eye

# Seeing Flashing Lights in the Corner of the Eye
Updated on June 22nd, 2026
Published on October 4th, 2023
Australia
[Australia](https://www.oscarwylee.com.au/glasses/eye/seeing-flashing-lights-in-corner-of-eye)
New Zealand

[Canada](https://oscarwylee.ca/glasses/eye/seeing-flashing-lights-in-corner-of-eye)
Canadian French

Seeing flashing lights in the eye
refers to eye flashes that occur towards the periphery of someone's
vision.
Flashing lights in the eye are generally caused by posterior vitreous
detachment, in which the vitreous humour separates from the retina.
Posterior vitreous detachment is a common condition that occurs as people
age, and there is generally no prevention for it. Other causes of flashes of
light in peripheral vision can include eye trauma, retinal detachments,
migraine, and Stickler Syndrome. For flashing lights in the eye caused by
posterior vitreous detachment, there is usually no treatment required. For
flashing lights that occur as a result of retinal detachment, there is
surgery available, such as a vitrectomy and scleral buckling. If you are
worried about why you are seeing flashes in the corner of your eye, you
should see an optometrist as soon as possible. Eye flashes can be a symptom
of retinal detachment, which may cause vision loss if left untreated.
Are You Due for an Eye Test?
Book a bulk billed eye test with one of our Oscar Wylee optometrists who
can help you stay on top of your eye health.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Causes](#causes)
[Appearance](#appearance)
[Treatments](#treatments)
## What are the Causes of Seeing Flashing Lights in the Corner of the Eye?
The most common causes of flashing lights in the corner of the eye may
include posterior vitreous detachment (PVD),
retinal tear, retinal detachment, ocular migraine (retinal migraine),
migraine with aura, eye injury or eye trauma, vitreoretinal traction,
age-related changes in the vitreous gel, inflammation inside the eye
(uveitis), diabetic retinopathy, visual disturbances after surgery,
head injury or concussion
and certain medications. The possible causes of seeing
flashes of light in the corner of the eye are listed below.
* Posterior Vitreous Detachment (PVD): Posterior vitreous detachment is a condition in which the vitreous
detaches from the retina, which may cause flashing lights in the eye.
* Retinal Tear: A retinal tear occurs
when the vitreous gel pulls on your retina and leads to a small break
or tear in the retina.
* Retinal Detachment: Retinal detachment
is when the retina detaches from its normal position. It is important
to note that retinal detachment is considered a medical emergency and
requires immediate medical attention.
* Ocular Migraine (Retinal Migraine): An
ocular migraine (retinal migraine) is characterised by loss of vision
that is usually followed by a headache. Occurring visual disturbances
may last under 60 minutes.
* Migraine with Aura: Migraines with
aura refer to migraines that happen in tandem with sensory
disturbances.
* Eye Injury or Eye Trauma: Eye trauma
refers to damage to the eye as a result of injury that may impact the
retina and, in turn, cause eye flashes.
* Vitreoretinal Traction: Vitreoretinal
traction occurs when the vitreous gel in the eye may be shrinking due
to increased age or other causes, and doesn't completely detach from
the retina.
* Inflammation inside the eye (uveitis): Inflammation inside the eye, often caused by autoimmune conditions,
can lead to flashing lights.
* Diabetic retinopathy: Diabetic
retinopathy is a complication of diabetes that affects vision.
* Visual disturbances after surgery: Visual disturbances after surgery, namely cataract surgery, can
occur, such as blurry vision and flashing lights.
* Head injury or concussion: Head injury
or concussion can affect vision and lead to blurriness, dark spots and
flashes of light.
* Certain medications: Certain
medications can lead to side effects that affect vision and cause
flashing lights.
### 1. Posterior Vitreous Detachment (PVD)
Posterior vitreous detachment (PVD) is
one of the most common causes of eye flashes and occurs when the
vitreous pulls away or detaches from the retina. Posterior vitreous detachment often occurs due to changes in the
vitreous fluid as it changes with age. The vitreous or vitreous humour
is a gel-like substance located between the lens and the retina,
helping to keep the shape of the eye. The retina is the
light-sensitive layer at the back of the eye that sends light that
enters the eye to the optic nerve, then to the brain. As a person
ages, their vitreous may begin to separate from the eye, which can
lead to eye flashes.
### 2. Retinal Tear
Retinal tears
refer to a break in the retina, which is the light-sensitive tissue
situated in the back of the eye, according to the Vision Eye
Institute. Retinal tear symptoms may include seeing flashes of light in your
vision or in the corner of your eyes, according to Mornington
Peninsula Eye Clinic.
### 3. Retinal Detachment
Retinal detachment is
a serious eye condition that may cause a person to see flashing
lights. If a person is having eye flashes, accompanied by other
symptoms such as eye floaters, blurry vision, seeing an empty circle
or seeing shadows, it is important to seek immediate attention from
a healthcare professional, as untreated retinal detachment can lead
to vision loss.
Retinal detachment occurs when the retina separates from the tissue at
the back of the eye, according to the Better Health Channel. When the
retina is detached, it loses access to important nutrients from the
surrounding tissues and cannot function. If treatment is not sought
quickly for retinal detachment, it can lead to vision loss.
### 4. Ocular Migraine
An ocular migraine is defined as a rare type of migraine that causes
temporary visual problems in one eye, according to the Sydney Headache
and Migraine Clinic.
Ocular migraines may be a cause for seeing flashing lights in the
corner of your eye as a result of the temporary spasms of the blood
vessels in the retina, disrupting blood flow to the back of the eye. This can lead to the
nerve cells triggering light flashes and other visual disturbances.
### 5. Eye Injury or Trauma
Eye trauma, resulting from injuries to the eye, may cause eye flashes.
Eye trauma or an injury to the eye
may result in eye flashes due to physical force exerted on the
retina. Eye injuries may occur as a result of a hit to the eye. Additional
force to the eye may also cause eye flashes, such as forcefully
coughing or even rubbing the eyes too hard, according to the
Optometrist Network.
### 6. Vitreoretinal Traction
Vitreoretinal traction may cause patients to see flashing lights in
the corner of their eye
due to the physical effect on the retina.
Vitreoretinal traction occurs when the vitreous gel doesn't completely
separate from the retina, which can result in it pulling on the
macula, disrupting the macula's usual shape, according to the Macular
Disease Foundation Australia. Vitreoretinal traction may be a cause of
seeing flashing lights in the corner of one's eye, consequently from
the physical pull of the vitreous, leading to the mechanical
stimulation of the retina, according to Kahawita et al. in their
article titled Flashes and Floaters: A Practical Approach to
Assessment and Management published in 2014.
### 7. Inflammation Inside the Eye (Uveitis)
Inflammation inside the eye, formally known as uveitis, is
often caused by an autoimmune response or infection.
One of the symptoms of uveitis is flashes of light, and others include
eye redness, pain and light sensitivity, according to Health Direct.
### 8. Diabetic Retinopathy
Diabetic retinopathy is a
complication of diabetes that damages the blood
vessels in the retina, according to Vision Australia. Symptoms include
dark spots in your vision, blurred vision, floaters and flashes of
light, according to Macular Disease Foundation Australia.
### 9. Visual Disturbances After Eye Surgery
Flashing lights can occur as
part of the visual disturbances that often emerge after eye
surgery.
This is particularly true of cataract surgery. While floaters are
common after the procedure, if they are combined with flashes of
light, you should consult your eye specialist, as it may be a sign of
a retinal tear, according to Mornington Peninsula Eye Clinic.
### 10. Head Injury or Concussion
Head injuries or concussions
can be a cause of light flashes; however, these often come with
floaters, which are a more common result of concussions.
### 11. Certain Medications
Certain medications can cause flashing lights and floaters in your
vision.
These medications can include Avastin, Viagra, Lanoxin and Seroquel,
according to Healthline.
Need To Update Your Prescription?
Visit an Oscar Wylee store near you where our qualified optometrists
can help you with a new prescription, and our retail staff can help
you shop our frames.
[Find a Store](https://www.oscarwylee.com.au/locations)
## What do Flashes of Light in Peripheral Vision Look Like?
Flashes of light in peripheral vision will
look like small, bright lights that shine in the corner
of your eyesight.
### How does the Retina Create Light Flashes?
The retina may create light flashes in a few different ways.
If the cause of the flashes is related to physical traction, like a
PVD, the physical disruption sends signals through the
retina, which creates a flash of light in your vision.
If the flash is related to a retinal migraine, then the change in
blood flow to the retina is the cause of the flash
sensation.
#### Is Seeing Flashing Lights in the Corner of the Eye a Symptom of Eye
Disease?
Seeing flashing lights in the corner of the eye is
not usually a symptom of an eye disease. Eye
flashes are generally caused by the vitreous fluid in the eye
pulling away from the retina. Random flashes of light in the field
of vision are commonly caused by ageing, as the older a person gets,
the more liquid the vitreous gel becomes, leading to its separation
from the retina. Eye flashes may also occur as a result of an eye
injury or a migraine, but are not often associated with
[eye diseases](https://www.oscarwylee.com.au/glasses/eye/common-problems).
##### Can Flashing Lights in the Eye be Harmless?
Yes, flashing lights in the eye
can be harmless; however, it is important to see an optometrist
if you see flashes, as they can also be a symptom of serious eye
conditions such as retinal detachment. Occasional eye flashes are a common occurrence, especially in
older age. The older a person gets, the more liquid the vitreous
gel becomes, leading to its separation from the retina, which can
cause eye flashes. Eye flashes that happen more regularly and are
accompanied by other symptoms such as floaters and blurred vision
can indicate a serious eye condition such as retinal detachment.
If a person has these symptoms, they should seek medical attention
as soon as possible.
###### Are Flashing Lights in the Eye and Eye Floaters the Same?
No,
flashing lights in the eye and eye floaters are not the same
thing, although both involve issues with the vitreous. Flashing lights or eye flashes refer to streaks or spots of
light that a person sees in their field of vision, caused by the
vitreous humour separating from the retina and tugging, or
causing friction between the two.
[Eye floaters](https://www.oscarwylee.com.au/glasses/eye/floaters-definition)
are a collection of cells of protein that get stuck in the
vitreous humour, according to Harvard Health Publishing, and
look like circles, cobwebs or lines in the field of vision.
If you experience both flashes and floaters together, seek
medical attention, as this could be a symptom of a serious
issue.
## Why do Flashes of Light Appear in One Eye?
The reasons why flashes of light may appear in one eye
are the same as the reasons why they would appear in both.
These reasons include posterior vitreous detachment, singular eye
trauma, retinal detachment and migraines.
#### Is a Flash of Light in One Eye a Warning Sign?
Yes, a flash of light in one eye can be a warning sign, notably if they are sudden and happen frequently. It can be a
warning sign of an underlying eye condition and should be checked
immediately by a health professional.
## How are Flashes of Light Diagnosed and Treated?
Flashes of light will usually be diagnosed and
treated with dilation and retinal imaging, which will allow the
optometrist or ophthalmologist to assess the cause of the flashes and
floaters. Most causes will need no treatment, but retinal tears will likely
require laser treatment, according to Sydney Retina.
### How Long Does the Treatment for Flashing Lights in Peripheral Vision
Last?
How long the treatment for flashing lights in peripheral vision lasts
will
depend on the underlying reason why they are happening.
Retinal tears, for example, are treated by laser therapy, which can
take 1-4 weeks to recover from, according to Coastal Eye Surgeons.
#### Can Treatment Stop Flashes of Light in the Eye?
Yes, in some cases treatment will be able to stop flashes of
light in the eye.
An eye test with dilation and retinal imaging will be used to assess
the cause of flashes and floaters, which often accompany these,
according to Sydney Retina. If the cause is a retinal tear, laser
treatment will likely be undertaken.
## How Can You Protect Your Vision When Seeing Eye Flashes?
You can protect your vision when seeing eye flashes by
seeing a health professional. Eye flashes may be a sign
of an underlying problem, making professional help important. An
optometrist will be able to check all regions of your eye to uncover
potential issues and address them in a timely manner.
Read Seeing Flashing Lights in the Corner of the Eye in other Oscar
Wylee regions and their languages.
Australia
[Australia](https://www.oscarwylee.com.au/glasses/eye/seeing-flashing-lights-in-corner-of-eye)
New Zealand

[Canada](https://oscarwylee.ca/glasses/eye/seeing-flashing-lights-in-corner-of-eye)
Canadian French

Prioritise Your Eye Health at Oscar Wylee
Oscar Wylee optometrists are available to perform bulk billed eye
tests, with no out-of-pocket expenses for eligible Medicare
cardholders.
[Book an eye test](https://www.oscarwylee.com.au/booking)
Oscar Wylee Accepts Leading Health Funds
In-store
Visit Oscar Wylee in-store where our knowledgeable staff can provide
you with a full quote.
[Explore health funds](https://www.oscarwylee.com.au/health-funds.html)