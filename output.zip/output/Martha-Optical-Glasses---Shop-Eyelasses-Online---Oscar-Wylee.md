# Source: https://www.oscarwylee.com.au/martha-optical.html

# Martha
1
## Frame Design of Martha glasses
The frame design of Oscar Wylee’s Martha glasses was inspired by the contemporary trend of cat eye-shaped glasses for women. Cat eye-shaped glasses are characterised by their pointed upper corners and round square bodies. The design of cat eye-shaped glasses was originally born out of the need for more variety in women’s glasses during the 1930s, which is when American artist Altina Schinasi designed the Harlequin frame, now known as cat eye-shaped glasses. Oscar Wylee’s range of [women's cat eye glasses can be shopped online](https://www.oscarwylee.com.au/glasses/silhouette/cat-eye-glasses.html).
$169    
In stock
Only %1 left
2 pairs from $199
Discount auto-applied at checkout
3 pairs from $249
Discount auto-applied at checkout
Qty
Add to cart
Book an eye test
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
excluding prescription lenses
## About Martha Frames
Delicate and soft with added strength from metal accents. Martha is a feminine browline shape with a subtle cat-eye. Think geek chic with a twist.
| Frame fit | Measurements |
| --- | --- |
| MEDIUM | 54 - 16 - 145 |
These measurements mean lens width, bridge, and temple length in millimetres (mm). They can be found on the inside of the temple arm. If you already have a pair that you like, you can compare it to these measurements.
### Made from Stainless Steel and Bio Acetate
Oscar Wylee’s Martha frame is a women's cat eye glasses frame that is perfect for those with heart, square, pear, or diamond face shapes. The Martha frame is a sleek, widely wearable frame that can be worn every day. The main specs of Oscar Wylee’s Martha glasses frame, including dimensions, shape, materials, lenses, nose fit and hinges are listed below.
| Martha Frame Features | Martha Frame Description | Dimensions | Shape | Materials | Lenses | Nose Fit | Hinges |
| --- | --- | --- | --- | --- | --- | --- | --- |
| The dimensions of the Martha frame are measured in millimetres (mm) and are 54 - 16 - 145, meaning the lens width is 54 mm, the bridge is 16 mm, and the temple length is 145 mm. |
| The Martha frame is a cat eye shape, well-suited to medium faces. |
| The Martha glasses are made of stainless steel and bio acetate. |
| The lenses that can be used in the Martha frame are optical lenses, which include single vision and multifocal lenses and non-prescription lenses, which are plain and can have a filter, such as a blue light filter, applied. |
| The Martha frame is fitted with adjustable nose pads. |
| The hinges in the Martha glasses are normal hinges, also known as standard or barrel hinges. |
Show All
### What Inspired the Frame Design of Oscar Wylee’s Martha Glasses?
The Oscar Wylee Martha frame design was inspired by current fashion trends, as cat eye shapes are often in fashion. A cat eye glasses shape is timeless, meaning it remains popular throughout the decades while other trends pass.
## What to Know About Oscar Wylee’s Martha glasses?
There are many aspects of the Oscar Wylee Martha frames that customers should know about, so they can decide whether this is the right frame for them. The Martha frame is a women's cat eye frame. Oscar Wylee’s Martha frame is suitable for many face shapes, but particularly compatible with heart, square, pear and diamond face shapes. The Martha frame’s simple design means that it is fashionable all year round. The Martha glasses feature the standard [parts of glasses](https://www.oscarwylee.com.au/glasses/eye/part-of-glasses), such as a rim, temples, lenses, normal hinges and an adjustable nose pad fit.
### What are the Types of Temple Tips or Earpieces Included with Oscar Wylee’s Martha Glasses?
The type of temple tips or earpieces included in Oscar Wylee’s Martha Glasses are made from bio acetate.
### What Type of Nose Bridge do Oscar Wylee’s Martha Glasses Have?
The type of nose bridge included in Oscar Wylee’s Martha frame is an adjustable nose pad fit.
### What Type of Nose Pads are Included with Oscar Wylee’s Martha Glasses?
Oscar Wylee’s Martha frame includes adjustable silicone nose pads.
### What Type of Lenses do Oscar Wylee’s Martha glasses Have?
The type of lenses that typically come with the Oscar Wylee Martha [glasses frame](https://www.oscarwylee.com.au/glasses.html) are optical lenses. Optical lenses are glasses lenses that have a prescription within the lens to help correct vision issues such as myopia, hyperopia and astigmatism. The Martha glasses can also come with non-prescription lenses, with add-ons such as a blue light filter.
### What Material is Used for the Rim of Oscar Wylee’s Martha Glasses?
The materials used for the rim of Oscar Wylee’s Martha glasses frames are stainless steel and bio acetate. The rim refers to the part of a glasses frame that holds the lenses.
### What Type of Hinges are Included with Oscar Wylee’s Martha Glasses?
The type of hinges included with Oscar Wylee’s Martha frames are normal hinges, also known as standard or barrel hinges. These provide strength and smooth movement connecting the frame's arms and lenses.
## What Face Types are Most Suitable for Oscar Wylee’s Martha Glasses?
The face types that are most suitable for Oscar Wylee’s Martha frame are heart, square, pear and diamond face types. The Martha frame is a cat eye shape, meaning that it complements the structure of heart, square, pear, and diamond faces particularly well. The Martha frames help to balance the features of a [heart face shape](https://www.oscarwylee.com.au/glasses/face-shapes/heart), [square face shape](https://www.oscarwylee.com.au/glasses/face-shapes/square), [pear face shape](https://www.oscarwylee.com.au/glasses/face-shapes/pear), or a [diamond face shape](https://www.oscarwylee.com.au/glasses/face-shapes/diamond), bringing the eyes and brows forward in a flattering way. Although there are many [glasses for face shapes](https://www.oscarwylee.com.au/glasses/face-shapes) that may be considered more aesthetically suitable, it is important that people also choose the frames that make them feel most comfortable and represent their personal style.
## What Size Options are Available for Oscar Wylee’s Martha Glasses?
The size options available for Oscar Wylee’s Martha frame are a medium-frame fit across all colours.
## What Materials are Used to Create Oscar Wylee’s Martha Glasses?
The primary materials used to create the Oscar Wylee Martha frame are bio acetate and stainless steel. The rim is made from both stainless steel and bio acetate, the nose bridge is made from stainless steel and the temples and temple tips are made from stainless steel and bio acetate.
## What’s Included
## OW Case &amp; Cloth
Protective Case and Lens Cloth
Our high-quality glasses case and lens cloth are included with every purchase of an Oscar Wylee frame. The stylish, magnetic case is made from a hard shell. This sturdy and durable material keeps your glasses protected and safe, wherever you go. Ensure your lenses are clean and scratch-free with our OW microfibre cloth, specifically designed to ensure you have comfortable vision through your lenses.
Oscar Wylee offers:
* Free Shipping for Australian Orders
* 1 Year Warranty on frames and lenses
* Scratch resistance lens coating on all prescriptions
* UV-proof coating on all prescriptions
Health fund rebate: Once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. Learn more about [health funds](https://www.oscarwylee.com.au/health-funds.html).
## Make and Materials
The frames then go through cleaning and strict quality control, and many pairs of crafting hands to be hand-assembled and polished. After your frames have gone through the production process, they are individually examined and&nbsp;packed before making their way to you!Also known as cellulose acetate, these frames are traditionally hand-crafted by skilled craftsmen, with each frame passing through numerous stages of production and are hand-polished to ensure a glorious lustre.
## Warranty Information
### Warranty Information
### Warranty Information
Oscar Wylee provides a 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects. We will repair or replace faulty or defective frames or lenses free of charge for warranty claims made within 1 year of the delivery. We also offer repairs or replacement for problems experienced with vision during everyday use for claims made within 30 days of delivery. If the same product has been discontinued or is no longer available, then we may offer an exchange for a similar product or a refund.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Find a Store Location](https://www.oscarwylee.com.au/locations/full-store-list.html)