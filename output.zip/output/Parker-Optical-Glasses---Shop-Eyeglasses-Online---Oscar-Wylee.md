# Source: https://www.oscarwylee.com.au/parker-optical.html

# Parker
1
## Frame Design of Parker Glasses
The frame design of Oscar Wylee’s Parker glasses is characterised by a square-round shape, a low nose bridge fit and an acetate frame. The Parker frame is a unisex, sophisticated glasses frame that will have you looking sharp any day of the week.
$169    
In stock
Only %1 left
2 pairs from $199
Discount auto-applied at checkout
3 pairs from $249
Discount auto-applied at checkout
Qty
Add to cart
Book an eye test
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
excluding prescription lenses
## About Parker Frames
Square-round and sleek. For looking sharp any day of the week. Parker packs a sophisticated yet modern style.
| Frame fit | Measurements |
| --- | --- |
| MEDIUM | 52 - 17 - 140 |
These measurements mean lens width, bridge, and temple length in millimetres (mm). They can be found on the inside of the temple arm. If you already have a pair that you like, you can compare it to these measurements.
### Made from Acetate
Oscar Wylee’s Parker frame is a unisex, square-round glasses frame that is a medium frame fit and ideal for those with round, oval and heart face shapes. The Parker frame is a stylish, widely wearable frame that is perfect for any day of the week. The main specs of Oscar Wylee’s Parker glasses frame including dimensions, shape, materials, lenses, nose fit and hinges are listed below.
| Parker Frame Features | Parker Frame Description | Dimensions | Shape | Materials | Lenses | Nose Fit | Hinges |
| --- | --- | --- | --- | --- | --- | --- | --- |
| The dimensions of the Parker frame are measured in millimetres (mm) and are 52 - 17 - 140, meaning the lens width is 52 mm, the bridge is 17 mm and the temple length is 140 mm. |
| The Parker frame is a square-round shape, well suited to medium faces. |
| Parker frames are made from a material called acetate. |
| The lenses that can be used in the Parker frame are optical lenses, which include single vision and multifocal lenses and non-prescription lenses, which are plain and can have a filter like a blue light filter applied. |
| The nose fit of Parker glasses is a low nose bridge fit. |
| The hinges in Parker frames are spring hinges, which are more flexible than other types of hinges and can extend past 90 degrees. |
Show All
### What Inspired the Frame Design of Oscar Wylee’s Parker Glasses?
The Oscar Wylee Parker frame design was inspired by current fashion trends as square-round shapes are often in fashion.
## What to Know About Oscar Wylee’s Parker Glasses?
There are many aspects of the Oscar Wylee Parker frames that customers should know about, so they can decide whether this is the right frame for them. The Parker frame is a unisex square-round shaped frame. Oscar Wylee’s Parker frame is suitable for many face shapes but particularly compatible with oval and round face shapes. The Parker frame’s simple design means that they are fashionable all year round. Parker frames feature the standard [parts of glasses such as a rim, temples, lenses, spring hinge and a low nose bridge for those with lower nose bridges.](https://www.oscarwylee.com.au/glasses/eye/part-of-glasses)
### What are the Types of Temple Tips or Earpieces Included with Oscar Wylee’s Parker Glasses?
The type of temple tips or earpieces included in Oscar Wylee’s Parker Glasses are made from acetate, the same as the rest of the temple and rim.
### What Type of Nose Bridge do Oscar Wylee’s Parker Glasses Have?
The type of nose bridge included in Oscar Wylee’s Parker frame is a low nose bridge fit. A low nose bridge fit is suitable for those with lower-nose bridges, in which the nose starts in line with or below the pupil.
### What Type of Nose Pads are Included with Oscar Wylee’s Parker Glasses?
Oscar Wylee’s Parker frame does not include any type of nose pads.
### What Type of Lenses do Oscar Wylee’s Parker Glasses Have?
The type of lenses that typically come with the Oscar Wylee Parker [glasses frame are optical lenses. Optical lenses are glasses lenses that have a prescription within the lens to help correct vision issues such as myopia, hyperopia and astigmatism. Parker frames can also come with non-prescription lenses, with add-ons such as a blue light filter. Parker frames are currently unavailable as sunglasses online, however, customers can customise in-store and add on tint or polarisation.](https://www.oscarwylee.com.au/glasses.html)
### What Material is Used for the Rim of Oscar Wylee’s Parker Glasses?
The material used for the rim of Oscar Wylee’s Parker glasses frames is acetate. The rim refers to the part of a glasses frame that holds the lenses.
### What Type of Hinges are Included with Oscar Wylee’s Parker Glasses?
The type of hinges included with Oscar Wylee’s Parker frames are spring hinges. A spring hinge in a glasses frame refers to hinges that are more flexible than normal hinges and can go slightly beyond 90 degrees. Spring hinges can provide a closer fit to the face.
## What Face Types are Most Suitable for Oscar Wylee’s Parker Glasses?
The face types that are most suitable for Oscar Wylee’s Parker frame are round, oval and heart face types. The Parker frame is a square-round shape, meaning that it complements the structure of round, oval and heart faces particularly well. The square-round Parker frames help to balance the features of an [oval face shape or a](https://www.oscarwylee.com.au/glasses/face-shapes/oval)[round face shape, bringing the eyes and brows forward in a flattering way. Although there are many](https://www.oscarwylee.com.au/glasses/face-shapes/round)[glasses for face shapes that may be considered more aesthetically suitable, it is important that people also choose the frames that make them feel most comfortable, and represent their personal style.](https://www.oscarwylee.com.au/glasses/face-shapes)
## What Size Options are Available for Oscar Wylee’s Parker Glasses?
The size options available for Oscar Wylee’s Parker frame are a medium-frame fit across all colours. The Parker glasses in Clear Crystal and Latte also come in larger fit sizes, as part of The Mega Eyewear Collection.
## What Materials are Used to Create Oscar Wylee’s Parker Glasses?
The primary material used to create the Oscar Wylee Parker frame is acetate. Acetate, also known as cellulose acetate, is a bioplastic, made from cotton fibres or wood pulp. At Oscar Wylee, acetate glasses are made by adding a dye to cellulose acetate, which is rolled into a sheet. The shape of the glasses is then cut from this sheet.
## What’s Included
## OW Case &amp; Cloth
Protective Case and Lens Cloth
Our high-quality glasses case and lens cloth are included with every purchase of an Oscar Wylee frame. The stylish, magnetic case is made from a hard shell. This sturdy and durable material keeps your glasses protected and safe, wherever you go. Ensure your lenses are clean and scratch-free with our OW microfibre cloth, specifically designed to ensure you have comfortable vision through your lenses.
Oscar Wylee offers:
* Free Shipping for Australian Orders
* 1 Year Warranty on frames and lenses
* Scratch resistance lens coating on all prescriptions
* UV-proof coating on all prescriptions
Health fund rebate: Once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. Learn more about [health funds](https://www.oscarwylee.com.au/health-funds.html).
## Make and Materials
The frames then go through cleaning and strict quality control, and many pairs of crafting hands to be hand-assembled and polished. After your frames have gone through the production process, they are individually examined and packed before making their way to you!Also known as cellulose acetate, these frames are traditionally hand-crafted by skilled craftsmen, with each frame passing through numerous stages of production and are hand-polished to ensure a glorious lustre.
## Warranty Information
### Warranty Information
### Warranty Information
Oscar Wylee provides a 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects. 
We will repair or replace faulty or defective frames or lenses free of charge for warranty claims made within 1 year of the delivery.
We also offer repairs or replacement for problems experienced with vision during everyday use for claims made within 30 days of delivery. If the same product has been discontinued or is no longer available, then we may offer an exchange for a similar product or a refund.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Find a Store Location](https://www.oscarwylee.com.au/locations/full-store-list.html)
Recommended
1. [](https://www.oscarwylee.com.au/oliver-optical.html)
[Oliver](https://www.oscarwylee.com.au/oliver-optical.html)
Charcoal Dusk