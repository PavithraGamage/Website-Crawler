# Source: https://www.oscarwylee.com.au/glasses/silhouette/cat-eye-glasses.html

25 Products        
Showing 15 of 25
1. [](https://www.oscarwylee.com.au/mona-optical.html)
[Mona](https://www.oscarwylee.com.au/mona-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/mona-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/mona-optical.html)
2. [](https://www.oscarwylee.com.au/betty-optical.html)
[Betty](https://www.oscarwylee.com.au/betty-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/betty-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/betty-optical.html)
3. [](https://www.oscarwylee.com.au/maddison-optical.html)
[Maddison](https://www.oscarwylee.com.au/maddison-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/maddison-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/maddison-optical.html)
4. [](https://www.oscarwylee.com.au/juniper-optical.html)
[Juniper](https://www.oscarwylee.com.au/juniper-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/juniper-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/juniper-optical.html)
5. [](https://www.oscarwylee.com.au/martha-optical.html)
[Martha](https://www.oscarwylee.com.au/martha-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/martha-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/martha-optical.html)
6. [](https://www.oscarwylee.com.au/nina-optical.html)
[Nina](https://www.oscarwylee.com.au/nina-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/nina-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/nina-optical.html)
7. [](https://www.oscarwylee.com.au/netta-optical.html)
[Netta](https://www.oscarwylee.com.au/netta-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/netta-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/netta-optical.html)
8. [](https://www.oscarwylee.com.au/nami-optical.html)
[Nami](https://www.oscarwylee.com.au/nami-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/nami-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/nami-optical.html)
9. [](https://www.oscarwylee.com.au/shel-optical.html)
[Shel](https://www.oscarwylee.com.au/shel-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/shel-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/shel-optical.html)
10. [](https://www.oscarwylee.com.au/opal-optical.html)
[Opal](https://www.oscarwylee.com.au/opal-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/opal-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/opal-optical.html)
11. [](https://www.oscarwylee.com.au/kitty-optical.html)
[Kitty](https://www.oscarwylee.com.au/kitty-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/kitty-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/kitty-optical.html)
12. [](https://www.oscarwylee.com.au/peggy-s-optical.html)
[Peggy Small](https://www.oscarwylee.com.au/peggy-s-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/peggy-s-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/peggy-s-optical.html)
13. [](https://www.oscarwylee.com.au/aleks-optical.html)
[Aleks](https://www.oscarwylee.com.au/aleks-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/aleks-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/aleks-optical.html)
14. [](https://www.oscarwylee.com.au/ana-optical.html)
[Ana](https://www.oscarwylee.com.au/ana-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/ana-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/ana-optical.html)
15. [](https://www.oscarwylee.com.au/vivian-optical.html)
[Vivian](https://www.oscarwylee.com.au/vivian-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/vivian-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/vivian-optical.html)
25 Products        
Showing 15 of 25
Choosing Best Glasses Best Material Width &amp; Colour Styling Price &amp; Shipping
## How to Choose the Best Cat Eye Glasses for Women?
To choose the best cat eye glasses for women, you should consider face size, face shape, and what frames will accentuate your personality. The [best glasses for women](https://www.oscarwylee.com.au/glasses/best-women) that are cat eye shaped, will be those that suit personality, and suit face size and shape. Cat eye is a typically more feminine shape but can be worn by any gender. The [best men's glasses](https://www.oscarwylee.com.au/glasses/best-men-eyeglasses-for-every-face-shape) of cat eye shape, will take into consideration face size, shape and personal style. The ways to choose the best cat eye glasses for women are listed below.
* Consider face size: Consider face size when choosing the best cat eye glasses. Face size, when thinking about glasses fit, typically refers to the width of the face. If a person has a medium sized face, but chooses small frames, then they risk being too tight and pinching on the face. Similarly, if a person with a medium face chooses large or wide frames, these are likely to be ill-fitting and slide off the face.
* Face shape: Consider the shape when deciding[how to choose glasses for male and female face shapes](https://www.oscarwylee.com.au/glasses/face-shapes) in a cat-eye frame. Some frame shapes will suit certain face shapes better than others. For example, those with a round face would benefit from square or rectangular frames to break up the softness of the face.
* Accentuate your Personality: Accentuate your personality with your medium frames. Whilst size and face shape are important considerations, it's also important to pick a frame shape and colour that suits your personality.
[](https://www.oscarwylee.com.au/juniper-optical.html)
[Juniper](https://www.oscarwylee.com.au/juniper-optical.html)
$169    
Add to Cart
[Shop Juniper](https://www.oscarwylee.com.au/juniper-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/juniper-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/juniper-optical.html)
[](https://www.oscarwylee.com.au/faye-optical.html)
[Faye](https://www.oscarwylee.com.au/faye-optical.html)
$169    
Add to Cart
[Shop Faye](https://www.oscarwylee.com.au/faye-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/faye-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/faye-optical.html)
### How to Choose the Best Cat Eye Frame Glasses According to Face Shape?
The way to choose the best cat eye frame glasses according to [face shape](https://www.oscarwylee.com.au/glasses/face-shapes) includes determining your face shape and choosing a glasses shape that fits it well. In consiiderThe most common face shapes are square, oval, pear, round and oval face shapes. The types of face shapes and whether [cat eye frames as prescription eyewear for women](https://www.oscarwylee.com.au/glasses/cat-eye-frame) and men would suit them are listed below.
* Square Faces: Square faces are characterised by an angular forehead and chin, and facial features that are mostly in proportion. Cat eye glasses are good for square faces, as they give the face roundness beneath the browline and highlight the powerful brow and forehead of a square shape.
* Oval Faces: Oval faces are longer than they are wide and a rounded shape. Cat eye frames can complement the striking features of an oval face shape, bringing intrigue to the browline.
* Pear Faces: Pear faces are characterised by a wider jawline and narrow forehead. Cat eye frames can help to attract the eye upwards, drawing attention away from the wider jawline, and bring more structure to the face.
* Round Faces: Round faces are characterised by a circular appearance with little to no angles. Cat eye frames can help to provide some shape and intrigue to the soft curves of this face shape.
* Diamond Faces: Diamond faces are characterised by prominent cheekbones, a narrow forehead and a pointed chin. Cat eye frames are good for diamond faces and they can help soften the sharp features and contours of the face.
## Which Material is Best for Cat Eye Glasses?
The best material for cat eye glasses will be dependent on personal style preferences, as well as lifestyle factors. Materials that can be used for cat eye glasses include titanium, acetate, bio-acetate and stainless steel. The best materials for medium glasses are listed below.
* Titanium: Titanium is a type of metal known for its lightweight qualities, a good material choice for sleek, minimal cat eye glasses.
* Acetate: Acetate is a flexible cellulose material that can come in a variety of shapes, sizes and colours, perfect for fun and eye catching cat eye frames.
* Bio-acetate: Bio-acetate glasses are made mainly from a plant-based material such as wood pulp and cotton fibres. Bio-acetate can come in a variety of colours and designs and is an eco-friendly eyewear choice, another good material for fun cat eye frames.
* Stainless Steel: Stainless steel medium sized glasses can provide a chic look for cat eye frames.
[](https://www.oscarwylee.com.au/betty-optical.html)
[Betty](https://www.oscarwylee.com.au/betty-optical.html)
$169    
Add to Cart
[Shop Betty](https://www.oscarwylee.com.au/betty-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/betty-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/betty-optical.html)
[](https://www.oscarwylee.com.au/juniper-optical.html)
[Juniper](https://www.oscarwylee.com.au/juniper-optical.html)
$169    
Add to Cart
[Shop Juniper](https://www.oscarwylee.com.au/juniper-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/juniper-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/juniper-optical.html)
[](https://www.oscarwylee.com.au/kitty-optical.html)
[Kitty](https://www.oscarwylee.com.au/kitty-optical.html)
$169    
Add to Cart
[Shop Kitty](https://www.oscarwylee.com.au/kitty-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/kitty-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/kitty-optical.html)
[](https://www.oscarwylee.com.au/nami-optical.html)
[Nami](https://www.oscarwylee.com.au/nami-optical.html)
$169    
Add to Cart
[Shop Nami](https://www.oscarwylee.com.au/nami-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/nami-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/nami-optical.html)
### 1. Titanium Cat Eye Glasses
[Titanium](https://www.oscarwylee.com.au/glasses/titanium) cat eye glasses are made from a type of metal renowned for its strength and lightweight quality. Titanium can provide cat eye glasses with a sleek, chic look.
### 2. Acetate Cat Eye Glasses
Acetate cat eye glasses are made from a type of cellulose material that can come in a variety of shapes, colours and sizes. [Acetate](https://www.oscarwylee.com.au/glasses/acetate-frame) frames are often hypoallergenic, and are a good choice of material for cat eye glasses as they can create fun, bold cat eye browlines and colours.
[](https://www.oscarwylee.com.au/frieda-optical.html)
[Frieda](https://www.oscarwylee.com.au/frieda-optical.html)
$169    
Add to Cart
[Shop Frieda](https://www.oscarwylee.com.au/frieda-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/frieda-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/frieda-optical.html)
[](https://www.oscarwylee.com.au/maddison-optical.html)
[Maddison](https://www.oscarwylee.com.au/maddison-optical.html)
$169    
Add to Cart
[Shop Maddison](https://www.oscarwylee.com.au/maddison-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/maddison-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/maddison-optical.html)
[](https://www.oscarwylee.com.au/nina-optical.html)
[Nina](https://www.oscarwylee.com.au/nina-optical.html)
$169    
Add to Cart
[Shop Nina](https://www.oscarwylee.com.au/nina-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/nina-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/nina-optical.html)
### 3. Bio-acetate Cat Eye Glasses
Bio-acetate cat eye glasses are made mainly from a plant-based material such as wood pulp and cotton fibres. Bio-acetate is a great choice of material for cat eye frames, especially if the wearer is eco-conscious. [Bio-acetate](https://www.oscarwylee.com.au/glasses/bio-acetate) frames can come in a variety of colours, shapes and sizes.
[](https://www.oscarwylee.com.au/nina-optical.html)
[Nina](https://www.oscarwylee.com.au/nina-optical.html)
$169    
Add to Cart
[Shop Nina](https://www.oscarwylee.com.au/nina-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/nina-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/nina-optical.html)
[](https://www.oscarwylee.com.au/martha-optical.html)
[Martha](https://www.oscarwylee.com.au/martha-optical.html)
$169    
Add to Cart
[Shop Martha](https://www.oscarwylee.com.au/martha-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/martha-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/martha-optical.html)
### 4. Stainless Steel Cat Eye Glasses
[Stainless steel](https://www.oscarwylee.com.au/glasses/materials/stainless-steel.html) cat eye glasses are made from a metal material that is lightweight, comfortable and long lasting. Stainless steel is a good choice of frame for a sleek, stylish look.
[](https://www.oscarwylee.com.au/betty-optical.html)
[Betty](https://www.oscarwylee.com.au/betty-optical.html)
$169    
Add to Cart
[Shop Betty](https://www.oscarwylee.com.au/betty-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/betty-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/betty-optical.html)
[](https://www.oscarwylee.com.au/ava-optical.html)
[Ava](https://www.oscarwylee.com.au/ava-optical.html)
$169    
Add to Cart
[Shop Ava](https://www.oscarwylee.com.au/ava-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/ava-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/ava-optical.html)
### What are Cat Eye Glasses?
Cat eye glasses refer to [glasses](https://www.oscarwylee.com.au/glasses/prescription) that are upswept at the corners, giving a feline-like appearance. Cat eye glasses were first created around 1930, and started to become popular in the 1950s. Stars such as Marilyn Monroe and Audrey Hepburn were some of the first celebrities to help popularise this glasses design. It has now become a staple frame design, worn by women all over the world for a fun, sleek and feminine look. Oscar Wylee’s [Mona optical glasses, which can be purchased as eyeglasses online](https://www.oscarwylee.com.au/mona-optical.html), are a great choice for cat-eye frames.
### Which Colour Pattern is Best for Cat Eye Frame Glasses?
There is no best colour pattern for cat eye glasses frames, as it will depend on the preferences of the wearer. Some glasses colour patterns a person may want to consider for cat eye glasses include matte, solid, tortoise, and two-toned. Read on for the various colour patterns that could be the best for cat eye frame glasses.
* Matte: Matte cat eye frame glasses refer to a low-gloss, flat-looking finish for chic, subtle style.
* Solid: Solid colour medium frame glasses are classic and versatile, able to provide a subtly stylish accessory to any outfit.
* Tortoise: Tortoiseshell medium-sized glasses offer a blend of often warm tones and are an effortlessly stylish accessory, perfect for any occasion.
* Two-toned: Two-toned medium frame glasses offer a striking and unique blend of colour.
### Which Colour is Best for Cat Eye Glasses?
The best colour for cat eye glasses is up to the style and personal preference of the wearer. At Oscar Wylee we have a variety of frame colours for cat eye glasses including black, blue, brown, gold, clear, red, purple and pink. Read on for more on the variety of colours that cat eye frames come in.
* Black: Black cat eye glasses are a staple colour perfect for any outfit or occasion.
* Blue: Blue cat eyeglasses are a versatile eye wear choice. A navy blue can be a chic, professional look, and a bright blue can work for a fun day out with friends.
* Brown: Brown cat eyeglasses provide style, and an instant warmth to any outfit.
* Gold: Gold cat eyeglasses instantly add a luxe aesthetic to formal outfits.
* Clear: Clear cat eye glasses give minimalist look, whilst still maintaining their interesting shape.
* Red: Red cat eye glasses can provide a bold focal point on the face, perfect for those who want a statement.
* Purple: Purple cat eyeglasses provide a rich beauty for a unique and classy look.
* Pink: Pink cat eye glasses exude a chic, feminine charm for a fashion-forward accessory.
[](https://www.oscarwylee.com.au/frieda-optical.html)
[Frieda](https://www.oscarwylee.com.au/frieda-optical.html)
$169    
Add to Cart
[Shop Frieda](https://www.oscarwylee.com.au/frieda-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/frieda-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/frieda-optical.html)
[](https://www.oscarwylee.com.au/maddison-optical.html)
[Maddison](https://www.oscarwylee.com.au/maddison-optical.html)
$169    
Add to Cart
[Shop Maddison](https://www.oscarwylee.com.au/maddison-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/maddison-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/maddison-optical.html)
[](https://www.oscarwylee.com.au/ana-optical.html)
[Ana](https://www.oscarwylee.com.au/ana-optical.html)
$169    
Add to Cart
[Shop Ana](https://www.oscarwylee.com.au/ana-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/ana-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/ana-optical.html)
[](https://www.oscarwylee.com.au/evie-optical.html)
[Evie](https://www.oscarwylee.com.au/evie-optical.html)
$169    
Add to Cart
[Shop Evie](https://www.oscarwylee.com.au/evie-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/evie-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/evie-optical.html)
## What Types of Nose Shapes Work Best with Cat Eye Glasses?
There is no particular nose shape type that will work best with cat eye glasses. Any nose shape or [nose type](https://www.oscarwylee.com.au/glasses/nose-types) can be complemented by cat eye glasses.
### Are Cat Eye Glasses Good for People with Big Noses?
Cat eye glasses are a good choice for people with big noses, and noses of any size. Cat eye glasses are a versatile and complementary frame design, suitable for all sized noses.
### Are Cat Eye Glasses Suitable for Reading Glasses?
Yes, cat eye glasses are suitable for use as reading glasses. [Reading glasses](https://www.oscarwylee.com.au/reading_glasses.html) refers to a type of eyewear worn by people to see clearer for reading, and other close up tasks. Cat eye glasses can be a fun and interesting frame design for reading glasses.
### How to Adjust Cat Eye Glasses for a Comfortable Fit?
If you need to adjust your cat eye glasses for a comfortable fit, it is recommended that you bring your frame to an optical retailer, to have them adjusted professionally. It is always best to have any repairs or adjustments made at your optical retailer, as making alterations to the frames yourself, or at other establishments, may void warranty.
#### Are Cat Eye Frame Glasses Suitable for Sports and Active Use?
Cat eye glasses are not typically suitable for sports and active use, as they are more of a fashion frame, good for general every day use. Active eyewear are glasses that are made from materials and have features that can withstand the rough and tumble of physical activity, which will be better for sports use than cat eye sunglasses glasses. At Oscar Wylee our [active eyewear collection](https://www.oscarwylee.com.au/sunglasses/collection/active-collection.html) are sunglasses suitable for sports and active use.
### What Lens Types Work Best with Cat Eye Frames?
The lens types that work best with cat eye frames are the ones that best suit the wearer's eye care needs. This could mean a multifocal lens for a person who needs vision correction at multiple distances. This could also mean a lens with a blue light lens filter, for someone who spends a lot of time working on digital screens.
### What Hairstyles Look Best with Cat Eye Glasses?
Hairstyles that look best with cat eye glasses are generally ones that let the glasses shine. As cat eye glasses can be a statement frame design, hairstyles that aren't over the eyes or the frames may look best. However, it is ultimately up to the wearer to decide.
#### How to Pair Cat Eye Glasses with Outfits for Different Occasions?
Cat eye glasses are a fun, stylish and versatile eye wear piece that can work with many outfits for different occasions. A more subtle metal cat eye may work well for work, as it is both stylish, fun but subtle. A brightly coloured acetate cat eye frame may work well for going out or a fun day out with friends.
## What are the Price Factors for Cat Eye Frame Glasses?
The price factors for cat eye glasses at Oscar Wylee will vary depending on elements such as glasses material, add-ons and lens types. One pair of cat eye glasses in our core range starts from $169, 2 pairs from $199 and 3 pairs from $249. It should be noted that lens thickness and other add-ons will affect overall pricing. Read our full[price guide](https://www.oscarwylee.com.au/price-guide/) for more information.
### What is the Duration of Shipment for Cat Eye Glasses?
Oscar Wylee offers domestic shipping for cat eye glasses ordered on the website. Typically, deliveries will usually be dispatched within 7-10 business days. An email will be sent to you confirming the order alongside an order tracking link. If you are having them delivered to your home, this can take up to 2 weeks.
[Prescription Glasses](https://www.oscarwylee.com.au/glasses.html)
[Women’s Glasses](https://www.oscarwylee.com.au/glasses/collection/womens-glasses.html)
[Men’s Glasses](https://www.oscarwylee.com.au/glasses/collection/mens-glasses.html)
[Senior Glasses](https://www.oscarwylee.com.au/glasses/collection/seniors.html)
[Glasses for Kids](https://www.oscarwylee.com.au/glasses/collection/kids-collection.html)