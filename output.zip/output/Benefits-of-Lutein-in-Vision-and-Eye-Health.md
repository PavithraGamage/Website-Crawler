# Source: https://www.oscarwylee.com.au/glasses/eye/best-vitamin/benefits-of-lutein

# Lutein and Its Benefits For Vision and Eye Health
Published on July 16th, 2024
Lutein is a type of carotenoid, found in foods such as egg, corn, grapes, and green, leafy vegetables.
Lutein is
not made in the human body and must be consumed via these foods in a healthy and balanced diet. Lutein is hugely
beneficial for health, including eye health as it acts as an antioxidant in the body. The benefits of lutein for
eye health include reducing free radicals, protecting against oxidative stress, protecting the eye from UV and
helping to prevent age-related eye conditions such as cataracts and age-related macular degeneration.
Prioritise Your Eye Health at Oscar Wylee
Oscar Wylee optometrists are available to perform bulk billed eye tests, with no
out-of-pocket expenses for eligible Medicare cardholders.
[Book an eye
test](https://www.oscarwylee.com.au/booking)
[Definition](#definition)
[Benefits](#benefits)
[Food Source](#source)
[Other Beneficial Nutrients](#beneficial)
## What is Lutein?
Lutein is a type of fat-soluble carotenoid, naturally occurring in foods such as egg yolks, corn,
grapes, zucchini and green, leafy vegetables such as spinach and kale. Carotenoids are yellow, red and
orange pigments found in plants. Carotenoids such as lutein are not produced by the human body and must
be consumed as part of a balanced and healthy diet. Lutein acts as an antioxidant in the human body,
helping to boost general health, including eye health.
## What are the Benefits of Lutein for Vision and Eye Health?
There are many benefits of lutein for vision and eye health including helping to prevent
oxidative
stress, fighting free radicals, protecting the eye from UV rays, and serving as an
anti-inflammatory
agent. Lutein can also benefit vision and eye health by protecting the retina from the
effects of
ageing which in turn can help prevent age-related [eye conditions](https://www.oscarwylee.com.au/glasses/eye/health) such as [cataracts](https://www.oscarwylee.com.au/glasses/eye/cataracts) and macular
degeneration, according to the University of Rochester Medical Centre.
### How Does Lutein Help with Age-related Macular Degeneration (AMD)?
Lutein has been theorised to help with preventing age-related macular degeneration (AMD).
According
to a paper by Mrowicka, Mrowicki, Kucharska and Majsterek, one of the major benefits of lutein is it
helps protect the eye by reducing oxidative stress and fighting free radicals. These protective
measures can help to maintain macular structure and function. This in turn, helps to prevent
age-related eye diseases such as [age-related
macular degeneration (AMD)](https://www.oscarwylee.com.au/glasses/eye/age-related-macular-degeneration), according to Feng, Nie,
Jiang and Fan in the paper, Effects of lutein supplementation in age-related macular
degeneration.
Need New Glasses?
Visit an Oscar Wylee store near you where you can speak to our knowledgeable
staff and experience professional frame styling.
[Find a
store](https://www.oscarwylee.com.au/locations/full-store-list.html)
### Are Lutein and Zeaxanthin the Same?
Lutein and zeaxanthin are similar in that they are both two types of fat-soluble carotenoids.
According to the Bright Focus Organisation, lutein and zeaxanthin are both micronutrients
structurally related to Vitamin A. When consumed, Lutein and Zeaxanthin are transported to the
retina.
### What Foods are Good Sources of Lutein?
The foods that are a good source of lutein include eggs, capsicum, corn, grapes and leafy greens
such as kale, spinach and broccoli. Most people will be able to consume the amount of lutein
they
need through eating these foods as part of a balanced and healthy diet. According to the NHS, the
average Western diet is reported to contain an average of 3mg of lutein a day.
### How Much Lutein Does a Person Need?
Several studies have shown that 10mg of lutein a day is a good amount of lutein for the
average
person to consume, according to the NHS. Most people with a healthy and balanced diet
will be
able to get all the lutein the body needs from fruit and vegetables such as eggs, corn, grapes,
capsicum, spinach, kale and broccoli. A person can take lutein supplements, which range in
dosage from 5mg to 40mg. It is recommended that a person consults with a doctor before taking
any supplements.
## Are There Side Effects of Lutein?
There are very few side effects of taking lutein as a supplement. According to a study by
Buscemi,
Corleo, Di Pace, Petroni, Satriano and Marchesini called The Effect of Lutein on Eye and Extra-Eye
Health, one reported side effect of extended lutein intake, 15mg a day for 20 weeks, caused skin
yellowing in some patients.
### Is Lutein Safe for Pregnant or Breastfeeding People?
Lutein that occurs naturally in foods is generally safe for pregnant people or those that are
breastfeeding, as part of a balanced and healthy diet. Lutein in supplement form may not be
suitable
for pregnant people. It is recommended that those who are pregnant check with their doctor before
taking any supplements.
## What Other Nutrients Are Beneficial for Eye Health?
There are several other [nutrients that
can be beneficial for eye health](https://www.oscarwylee.com.au/glasses/eye/best-vitamin) including vitamin A, vitamin C,
vitamin E, vitamin B, zinc and omega-3 fatty acids. The other nutrients that can be beneficial
for eye
health are listed below.
* Vitamin A:
Vitamin A is beneficial for the eye as it helps protect the conjunctiva and cornea, according to
Health Direct. Vitamin A can be found in eggs, dairy, orange vegetables and fruits.
* Vitamin C:
Vitamin C can be beneficial to eye health as it may help to prevent or slow the progression of
age-related macular degeneration (AMD) and cataracts. Vitamin C is found in food such as oranges,
strawberries and broccoli.
* Vitamin E:
Vitamin E can be beneficial for eye health as it is an antioxidant that can help protect the eye
from free radicals. Free radicals may harm tissues and structures in the eye.
* Vitamin B:
Vitamin B can be beneficial to eye health as it may help in preventing or slowing age-related
macular degeneration (AMD). Vitamin B or B vitamins refer to a group of water-soluble vitamins and
include B6, B9, and B12.
* Zinc:
Zinc is a type of mineral that can be beneficial to eye health as it can help to maintain retina
function and possibly prevent the progression of age-related macular degeneration (AMD).
* Omega 3 Fatty Acids:
Omega-3 fatty acids are a type of healthy fat that can be beneficial to eye health as they may help
relieve symptoms of dry eye disease and lower the risk of developing glaucoma and age-related
macular degeneration (AMD).
In Need of an Eye Test?
At Oscar Wylee, we offer bulk billed eye tests for valid Medicare cardholders.
[Book an
Eye Test](https://www.oscarwylee.com.au/booking)
All Major Health Funds Accepted
At Oscar Wylee, we provide on-the-spot claims when you bring a valid health fund card in-store.
[Explore Health Funds](https://www.oscarwylee.com.au/health-funds.html)