# Source: https://www.oscarwylee.com.au/glasses/eye/surgery/cataract

# Cataract Surgery: How is Surgery Conducted, Complications and Recovery Time
Published on April 16th, 2024
Updated on September 06th, 2024
Cataract surgery
refers to a procedure to treat the eye condition cataracts, in which the
affected lens is removed and replaced with an artificial lens or an
intraocular lens (IOL). Cataracts is an eye condition in which proteins in the eye clump together
and cloud the lens. Cataract surgery will be conducted by an ophthalmologist
and generally takes around 45 minutes. An ophthalmologist is a medical
doctor who specialises in eye care and is qualified to perform eye surgery.
Cataract surgery recovery time may vary from person to person, but generally
takes up to 8 weeks for the eye to benefit from the surgery.
Are You Due for an Eye Test?
Book online and our dedicated Oscar Wylee optometrists will perform
Medicare, bulk billed eye tests to keep your eye health on track.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Definition](#definition) [Process](#process)
[Complications](#complications ) [Recovery](#recovery)
## What is Cataract Surgery?
Cataract surgery
is a procedure in which the lens of an eye that has been affected by
cataracts is replaced by a transparent artificial lens called an
intraocular lens (IOL).
Cataracts refers to an eye condition in which the lens of the eye
becomes cloudy, which can affect vision.
[Cataracts](https://www.oscarwylee.com.au/glasses/eye/cataracts)
are caused by damage to the proteins in the eye which then clump
together. A cloudy lens affects how much light enters the eye which can
impact vision, according to Health Direct. Cataract removal surgery aims
to resolve this condition by replacing the lens and restoring vision.
Cataract surgery will be conducted by an ophthalmologist, who in
Australia, is a medical doctor that specialises in eye care.
## How is Cataract Surgery Conducted?
Cataract surgery will be conducted by an ophthalmologist and is a simple
procedure that usually takes around 45 minutes to perform. Cataract
surgery is conducted by
first numbing the eye with eye drops or an injection. The
ophthalmologist will then make an incision in the eye, break down the
lens, and insert the new lens. The patient will then have to wait in
recovery
to ensure nothing has gone wrong before they are sent home. The way
cataract surgery is conducted is listed below.
1. Numbing the eye:  Numbing the eye is
the first step in cataract surgery, so a patient will not feel any
pain whilst the procedure is occurring. This can be done through
numbing eye drops or injections.
2. Ophthalmologist makes an incision in the eye:
The ophthalmologist will then make an incision in the eye to access
the lens.
3. Breaking down the lens:  Breaking down
the lens is the next step in cataract surgery and will be done using
small instruments, according to the American Academy of Ophthalmology.
4. New artificial lens is inserted:  The
new artificial lens will be inserted into the eye.
5. Patient will wait in recovery:  The
patient will have to wait in a recovery room for a period of time so
the ophthalmologist can check if everything is okay with the eye. The
patient will be sent home with a cover over the eye to protect the
area while it heals.
### How Long Does Cataract Surgery Typically Take?
Cataract surgery
generally takes around 45 minutes to complete. Cataract surgery
is a simple
[eye surgery](https://www.oscarwylee.com.au/glasses/eye/surgery)
that usually takes approximately 45 minutes, though this may differ
depending on the person and their eye care professional.
## What are the Cataract Surgery Complications?
Cataract surgery is generally a safe and straightforward procedure with
minimal complications, however some may occur. Possible complications
with cataract surgery include
eye infection, blurred vision and retinal detachment. A patient
needs to see a healthcare professional as soon as possible if they
believe they are having complications following cataract surgery. The
possible complications of cataract surgery are listed below.
* Eye infection:  As cataract surgery is
invasive, it comes with the risk of an eye infection. If a person
notices the eye becoming red, painful, or leaking fluid, it is
important to see a healthcare professional, according to Health
Direct.
* Blurred vision:  Blurred vision is a
potential complication of cataract surgery, however, this is generally
caused by swelling in the eye post operation, according to the
American Academy of Ophthalmology, and should subside.
* Retinal detachment:  Retinal
detachment is a rare but serious complication of cataract or lens
surgery, in which the retina detaches from the back of the eye.
Symptoms of retinal detachment include a sudden increase of eye
floaters, flashes and shadows over vision. If a person has symptoms of
retinal detachment they should seek medical attention from a
healthcare professional as soon as possible.
### What is the Cataract Surgery Recovery Time?
The recovery time for cataract surgery
will vary from person to person, but generally takes around 4 to 6
weeks, according to the NHS. After cataract surgery, the eye may feel uncomfortable and
irritated and may water more. Most patients usually see improvements
in vision 1-3 days post-surgery, according to My Health Alberta.
However, it can take several weeks for the eye to fully heal and
vision to benefit from the surgery.
Find an Oscar Wylee Store Near You
Come and visit your local Oscar Wylee store where our friendly team
will help you shop our range of stylish and affordable frames, and
assist with your eye care needs.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
#### Can Cataract Surgery Correct Vision Problems?
Yes, cataract surgery can correct vision problems that are related
to the cataract itself. In some cases a surgeon may implant a lens
that helps to reduce the need for glasses. You can get toric
implants (to correct for astigmatism) or even multifocal implants.
### How Do You Know When You Need Cataract Surgery?
An
optometrist or ophthalmologist will discuss with a patient when
cataract surgery is needed.
If cataracts are in the early stages, surgery may not be necessary.
However, if cataracts are affecting vision and making everyday
activities hard, then cataract surgery may be recommended to replace
the lens. You may have cataracts diagnosed by an optometrist, who is a
primary eye care professional and the first point of contact in your
eye health journey. An optometrist will diagnose cataracts through an
[eye test](https://www.oscarwylee.com.au/eye-care/eye-test), and monitor the progression of the condition. If your optometrist
believes a cataract needs treatment, they will refer you to an
ophthalmologist who will conduct the surgery. At Oscar Wylee, eye
tests are bulk billed for eligible
[Medicare](https://www.oscarwylee.com.au/eye-test/medicare)
card holders. If your optometrist believes a cataract needs treatment,
they will refer you to an ophthalmologist who will conduct the
surgery.
### What Can You Expect During the Recovery Period After Cataract Surgery?
The recovery period after cataract surgery
will take several weeks and is generally an easy recovery
process. According to the NHS, a person will generally be able to go home on
the same day of the surgery, with vision returning in a few hours.
After cataract surgery has been completed, the patient will have an
eye patch or a pad put over the eye to help protect it. During the
first few days of recovery, the eye may feel irritated or
uncomfortable and may water more than usual. Vision should return to
normal in a few days. During the recovery process, it is important to
look after the eye, use eye drops if they have been provided and avoid
strenuous activity. Full healing may take several weeks.
If there is pain, redness or discharge from the eye, it is
important to seek medical attention.
### What Preparations Are Necessary Before Undergoing Cataract Surgery?
The
preparations a person should take before undergoing cataract
surgery will be at the discretion of the ophthalmologist performing
the eye surgery. According to Health Direct, the preparation before surgery may
include eye drops or an injection around the eye to numb the area.
It's also important to prepare transportation to and from the
appointment as you will be unable to drive yourself after surgery.
#### Is Cataract Surgery a Permanent Solution for Cataracts?
Yes, cataract surgery is
conducted to be a permanent solution for cataracts. Cataract
surgery involves removing the affected lens and replacing it with an
intraocular lens (IOL). According to Better Health Victoria, a
cataract cannot redevelop after it has been removed.
### How is the Eye Affected After Cataract Surgery?
After cataract surgery, the
eye may be affected by postoperative symptoms such as blurry eyes,
a feeling of irritation, gritty eyes or the feeling that something
is in the eye.
These post-operative symptoms should clear up within 1-3 days. As the
eye heals, vision should improve. When the eye is fully healed, the
symptoms of cataracts such as cloudy and blurred vision, should be
gone.
Look After Your Eyes!
It won’t take a moment to see our qualified optometrists for an eye
test, bulk billed for all eligible Medicare cardholders.
[Book an Eye Test](https://www.oscarwylee.com.au/booking)
Major Health Funds Accepted In-store
For the purchase of frames and lenses, use your private health fund
insurance to limit how much you pay from your own pocket.
[Explore Health Funds](https://www.oscarwylee.com.au/health-funds.html)