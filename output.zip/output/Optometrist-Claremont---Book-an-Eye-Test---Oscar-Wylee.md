# Source: https://www.oscarwylee.com.au/locations/optometrist-claremont.html

# Optometrist Claremont
Claremont Quarter133B, 9 Bay View TerraceClaremont WA 6010
* Near Coles
Opening hours
Monday9:00am - 5:30pm
Tuesday9:00am - 5:30pm
Wednesday9:00am - 5:30pm
Thursday9:00am - 7:00pm
Friday9:00am - 5:30pm
Saturday9:00am - 5:00pm
Sunday11:00am - 4:00pm
*Store hours reflect local standard trading hours and exclude public
holidays
[Visit our Claremont Google Business page for directions,
reviews, and updates.](https://g.page/r/CQUedgcf31-qEBA)
Book Appointment
[Call us: (08) 6237 1814](tel:(08) 6237 1814)
[Leave a Review!](https://g.page/r/CQUedgcf31-qEBA/review)
Our Reviews
Barry Bignell
23 hours ago
Great service. Friendly and professional
Chris Wood
2 weeks ago
The service was exceptional and they took the time to provide me the best advice for my needs.  High...ly recommended.
See more
Lara Clarke
3 weeks ago
Staff were amazing! They were so flexible when I needed to change my appointment time. They were als...o very helpful and brutally honest when it came to choosing glasses which I absolutely love and respected.
See more
David Feldman
3 weeks ago
Robert Bennett
4 weeks ago
Very thorough, comprehensive and informative eye test.
Judith
1 month ago
Staff were very helpful and professional.
Thanks
C D
1 month ago
Excellent, friendly service
Loc Ngo
2 months ago
Samantha and Janet are the real ones! I had such a pleasant shopping experience.
Gustavo Lopes
2 months ago
I visited the Oscar Wylee Claremont store and received wonderful service from the team, especially S...amantha, the store manager. Everyone was friendly, helpful, and professional. I would definitely recommend them to anyone, and I’ll be coming back for sure!
See more
Georgia Phelps
2 months ago
I love the team at OW. I am a return customer, they look after my whole family with great optometry,... service and selection of glasses.
See more
Isabella Marchetti
2 months ago
I believe her name was Samantha at the Claremont shop, she was so amazing and so helpful!
Fairlie Johnstone
3 months ago
Allan Pedersen
3 months ago
Niti the optician was amazing - an absolute gem. Seth at the front desk was arrogant and you had the... feeling of being either judged or ignored. He remained on his phone with his friend when customers came in the store. Several purchases from this store have been amazing experiences except for this arrogance
See more
Christine Jayne
3 months ago
I’ve been going to OW for 4+ years for my eye care. They’re always welcoming, bright and friendly. A...dditionally they actually have glasses frames that are flattering so definitely a bonus. I recommend them to everyone who mentions they need to get their eyes tested or need new frames.
See more
Helen Emmerich
3 months ago
Very good as l needed to see a specialist! Niti was prompt and extremely efficient at setting up ref...erral. Thank you so much
See more
Caroline
3 months ago
I had my eye test done at a different store and was a bit concerned about the accuracy of the result...s. Samantha was extremely helpful and took extra care to ensure everything was checked thoroughly and sorted out for me. I really appreciate her dedication and excellent service. Thank you :)
See more
Junyan Tan
4 months ago
Professional eye exam, professional staff, small store so can have some wait time if busy period
G
4 months ago
Have been here a few years now. Samantha is such a joy to deal with. No pressure and more than happy... to pull all the specs out. Very efficient crew.
See more
Marin Mihovilovic
4 months ago
I recently had an eye examination and purchased two pairs of prescription glasses, and I couldn’t be... happier with the whole experience.
The staff were incredibly friendly, welcoming, and at the same time very professional. The eye exam was thorough and well explained, with no rush at all – I felt like they genuinely cared about getting everything right. Samntha was really helpful.
They also helped me choose the frames, giving honest advice without any pressure, which I really appreciated.
Overall, a great experience with excellent service and a relaxed atmosphere. I would definitely recommend this place to anyone looking for a quality eye exam and glasses.
See more
Rebecca Wood
4 months ago
Prompt, friendly service. The team there seem to know all their clients by first name whenever I hav...e visited. There was an issue with my reading glasses which the manager Samantha sorted out quickly and easily. Very happy with the service and the products. Recommending to all my friends. Love the variety of colours and shapes of the frames.
See more
Julie Rose
4 months ago
Excellent . Everyone at the Claremont store was super friendly , helpful and professional. Highly re...commended.
See more
Anja Mersmann
5 months ago
Finally Samantha is back. I missed her so much. Samantha is also incredibly helpful, friendly, and a...ttentive, making the whole experience smooth and enjoyable. Fixing always all my problems I couldn’t believe one of the other employee fixed my sunnies a while an ago and put on one side a normal glass inside. Instead to tell she just gave to me like that and I was wondering the all time why I am Suddenly seeing do bad with them.
Till I want back in the store and Samantha finally was back. Fixed and Told me only of one side are description Glasses.
Love Samantha can’t imagine the shop will be running without her.
Janet provided outstanding service from start to finish. Janet conducted my eye test and was extremely professional, thorough, and made me feel completely at ease throughout the process. She explained everything clearly, which I really appreciated.
Highly recommend this store but only with Samantha and Janet for excellent customer service and professional eye care!
Other ones of far was all hopeless
See more
Elle Statham
5 months ago
Very thorough test by a very experienced staff.
Warren Bellouard
6 months ago
I had a great experience at Oscar Wylee Claremont. The team were super friendly and easy to deal wit...h, guiding me through everything from the eye test to choosing my new glasses. They made the whole process simple and stress-free. Would definitely recommend!
See more
Charli Pearson
6 months ago
Very professional, quick, explained what was going on well, would go back and recommend.
Charlotte Baxter
6 months ago
Michelle Multari
7 months ago
Great service !
Highly recommended
Tracy Pfaff
7 months ago
Janet Viner is always super gentle, kind, professional and efficient.
Tracy
7 months ago
Janet Viner is always super gentle, kind, professional and efficient.
Kay McNeil
7 months ago
Craig Roger
7 months ago
The eye test was very comprehensive. I learned exactly what I needed to be able to see and the staff... were very helpful in helping me choose my glasses (sorry for being so indecisive!). I’m excited to receive them.
See more
Amy Louise
7 months ago
Ross Tinney
8 months ago
Excellent, professional attention from the optometrist.
Ross Tinney
8 months ago
Excellent, professional attention from the optometrist.
Samantha Boys
8 months ago
Robert Thomas
8 months ago
A good experience. Staff were very helpful and Janet the Optometrist was very thorough and made me f...eel very welcome.
See more
Pamela Reilly
9 months ago
Helen Mahoney
9 months ago
A great experience getting my eye test at Oscar Wylee.  Not rushed and answered all my
queries.  Tha...nk you.
See more
Glenise Key
9 months ago
Such a pleasant experience great selection of frames but most of all I was so impressed with the sta...ff.
Aleigha and Janet were so  professional friendly and helpful which made choosing my frames so  easy and that is usually the part that I find so difficult and I am looking forward to the finished product.
With thanks
Glenise Key.
See more
Deanne Ellen Lumsdon
9 months ago
Very thorough, efficient, friendly staff. A great variety of frames. Staff really helpful about what... frames suits you. Everything was explained really well about the changes in sight, +  health of the eye in general Highly recommend!
See more
Fred
9 months ago
Great service all round.
Armin Postmaster
9 months ago
great service
Kelela  and Janet were very helpful
Kim Marland
10 months ago
Janet was on time, very thorough and informative. Spent time to understand my specific issues and co...vered everything. Would definitely recommend and return.
See more
John Anderson
10 months ago
Joaquin Hinostroza
11 months ago
Janet Barron
11 months ago
Very comprehensive, relaxed, professional and informative. Highly re ommmend Janet,  the optician's ...services!
See more
L B
11 months ago
Special mention for Janet, who did my eye test for me. She was very thorough and engaging.  Excellen...t service.
See more
Sarah Simpson
11 months ago
I had an appointment yesterday. Right from the start the front desk was amazing and then to meet Dan...iel was a delight. They were both so professional.. A really good experience all round. Sarah
See more
Si Si P
11 months ago
What a wonderful experience I had. I was lucky enough to be looked after by Aleigha. I visited the s...tore three times and every visit was great and productive. Nothing was too much trouble and both pairs of my glasses turned out brilliant! I could not be happier. Very easy and seamless process, you have a regular customer in me ????
See more
George Brown
11 months ago
Very pleasant staff, efficient service and reasonable prices.
## Find an Optometrist in Claremont With Oscar Wylee
You can find our Oscar Wylee store on the ground floor of the
Claremont Quarter Shopping Precinct, just past Coles. Here, our dedicated
optometrists can provide Medicare bulk billed eye tests and our friendly staff
can help you shop our range of modern and vintage-inspired frames. To get to
us, you can take the train to Claremont Station, a short walk from the store,
or catch one of the many buses that service the surrounding areas. You could
also drive in, with parking at Claremont Quarter free for up to 3
hours.
There is plenty to explore in the area when you have
finished your appointment with us. There are several beaches nearby such as
Cottesloe Beach and the Foreshore Reserve, perfect for a walk in the sun or a
nice picnic. If you live close to the Cottesloe or Swanbourne areas, Oscar
Wylee Claremont is your go-to for optometry services!        
Meet Our Team
* Optometrist
BSc(Hons)Dip.Opt.GradCertOcTher
* Store Manager
Our Services
* Bulk
Billed Eye Examinations
* Professional Frame Styling
* Frame Adjustments and
Repairs
Show All
## Find an Optometrist in Claremont, Perth for an Eye Health Test
Visit our Oscar Wylee store in Claremont, Perth for high-quality
eye care services including eye health tests, prescription
updates and new frames. Our Oscar Wylee optometrists are
available in-store at the Claremont Quarter to perform eye tests
for a bulk billed price under Australia’s Medicare system. Our
eye testing services at Oscar Wylee aim to test vision and help
with the detection and management of eye diseases. Our Oscar
Wylee optometrists can also provide eye care advice, and
prescription updates, and refer patients to an eye doctor, known
in Australia as an ophthalmologist, for specialised care if
needed. In Claremont, Perth, the average cost for an optometrist
often depends on factors such as a person's age, health and eye
care needs.
At our Oscar Wylee glasses shop in Claremont, Perth, our
dedicated retail team, including our optical dispensers, are
available in-store to help customers shop our range of frames.
Oscar Wylee is passionate about our customers finding the right
eyewear for their vision needs, so whether it's prescription
glasses, prescription sunglasses or non-prescription eyewear,
our team will make sure customers leave with the frames that are
perfect for them. If you require high-quality eye care services
such as new frames or eye health tests in Claremont, Perth, come
and visit our Oscar Wylee team.
## How to Find an Optometrist in Claremont, Perth?
To find an optometrist in Claremont, Perth you can take certain
steps that can help make it easier for you such as
searching online, assessing the store’s opening hours and
finding the directions to your chosen location.
The steps on how to find an optometrist in Claremont, Perth are
listed below.
1. Search online using the phrase, optometrist near me in
Claremont. This can also be done here on the website via our
locations page.
2. Click on the Oscar Wylee link, which will take you directly to
our Claremont optometrist store page.
3. See the store’s opening hours and where the store is located
specifically.
4. Use the Claremont Google Business page link located under
store hours to see the directions on how to get to the store.
You can also find an optometrist in Claremont, Perth by
searching the keywords optometrist near me. If you have
locations enabled on your smartphone and you’re in the
Claremont, Perth area, our Claremont store page should appear
easily for you to click on.
### Is it Hard to Get an Eye Appointment in Claremont, Perth?
No, it is not hard to get an eye appointment in Claremont. You
can easily book an appointment to see an Oscar Wylee optometrist
in Claremont, Perth right here on this page. At Oscar Wylee we
have highly qualified optometrists available for bulk billed eye
appointments, which can be booked online or in-store.
#### How to Compare Optometrists in Claremont, Perth to Each Other?
To compare optometrists in Claremont, Perth, you can use factors
such as eye
tests offered, health fund coverage, lens types and add-ons
and eyewear offered.
To take care of your vision and eye health, it is important to
receive an eye test at least once every two years. There are
different types of tests that can be performed in an eye test
and not all optometrists may offer the same tests. Health funds
can be used to help cover some of the cost of your frames and
lenses. To find out if your health fund is accepted at an
optometrist in Claremont, Perth visit their website. In the case
of Oscar Wylee, we accept all major health funds and provide
on-the-spot claims in-store. There are many different lens
options available for prescription glasses such as
single-vision, multifocal and high-index lenses. Most
optometrists in Claremont, Perth will offer these lenses
although it is good to make sure. There are also lens add-ons
available to enhance your glasses such as anti-reflective and
blue light filters. Finally, if you are looking to purchase a
pair of glasses after your eye test, you can compare the
different styles and colours you are interested in from the
optometrists in Claremont, Perth. Oscar Wylee offers a wide
range of frames with vintage and modern inspirations in bold
colours and subtle designs.
#### How to Find an Eyeglasses Shop in Claremont, Perth?
To find a glasses store in Claremont, Perth you can try to
follow these simple steps including
searching online, selecting a convenient location and looking
at their health insurance policies.
The steps on how to find a glasses store in Claremont, Perth are
listed below.
1. Search online using the phrase, glasses store in Claremont,
Perth. This will provide you with various options for glasses
stores in the whole Claremont, Perth area.
2. Select a glasses store that is most convenient for you to
travel to.
3. Click the link to find out more information such as opening
hours, exact location and directions to the glasses store in
Claremont.
4. Read their health insurance policies to ensure you know what
health benefits you have access to.
Our Oscar Wylee glasses store in Claremont, Perth offers primary
eye care services such as comprehensive eye tests as well as
other services performed by an optometrist and offers
prescription and non-prescription eyewear.
##### Is it Possible to Purchase Prescribed Sunglasses in Claremont,
Perth Without Seeing an Optometrist?
Yes and no, it is possible to
[purchase prescribed sunglasses](https://www.oscarwylee.com.au/sunglasses.html)
in Claremont, Perth without seeing an optometrist if you already
have a prescription that has not expired. If your prescription
is expired, you can book an eye test to receive an updated or
new prescription which will require you to see an optometrist.
This will ensure your prescription sunglasses are appropriate
for your visual needs.
## Where is the Oscar Wylee Claremont, Perth Optometrist Located?
The Oscar Wylee Claremont optometrist is located in the
Claremont Quarter Shopping Centre, in the suburb of Claremont.
The Claremont Quarter Shopping Centre is located at 9 Bay View
Terrace, Claremont, Perth.
### What is the Phone Number of Oscar Wylee Claremont, Perth
Optometrist Store?
The phone number for our Oscar Wylee Claremont, Perth
optometrist store is (08) 6237 1814. Our Oscar Wylee Claremont,
Perth store is open, and our staff are available to be contacted
between 9 am and 5.30 pm from Monday to Wednesday, 9 am to 8 pm
on Thursdays, 9 am to 5.30 pm on Fridays, 9 am to 5 pm on
Saturdays and 11 am to 4 pm on Sundays.
### What are the Reviews for Oscar Wylee Claremont, Perth Optometrist?
The customer reviews for our Oscar Wylee Claremont, Perth
optometrist, can be found here on the website and online when
you search for Oscar Wylee Claremont optometrist. The reviews
for our Oscar Wylee Claremont optometrist are listed below.
* Denise Boreham:  Thank you to the wonderful staff at
Claremont OW who helped me on my eyewear journey. Samantha and
Lee were very helpful and went beyond expectations.
* Elaine Lopes:  Friendly, incredibly helpful staff who
made the whole eye test and selection of new frames so
enjoyable and straightforward.
* Annelise Mauritz:  Absolutely brilliant! From the
confirmation of the booking, the eye test and choosing
glasses, honestly the best experience I’ve had. Thank you!
#### What Treatments or Eye Care Processes Are Done in the Oscar Wylee
Claremont, Perth Optometrist Location?
The treatments or eye care processes done in the Oscar Wylee
Claremont, Perth optometrist location include
a tonometry test, a slit lamp exam and a refraction test.
Additional tests that may also be performed can include
a dilated fundus exam. The treatments or eye-care
processes that are done in the Oscar Wylee Claremont optometrist
location are listed below.
* A Tonometry Test: An optometrist or optical dispenser
will conduct a tonometry test which involves the use of a
machine that will release small puffs of air into your eyes.
This will assist with measuring pressure in the eye.
A Digital Photograph: An optometrist or optical dispenser
may take a digital photograph of your eye which can be kept on
record to use in future appointments to evaluate any changes to
your eye.

* Slit Lamp Test: A slit lamp test can be used to
evaluate your eye health, by examining your cornea and iris
which are the anterior and posterior of the eye.
* Refraction Test: During a refraction test, an
optometrist will have you view an image through different
lenses and ask you to confirm which helps you see the image
clearer.
Visual Field Test: A visual field test can assist with
assessing your peripheral vision, which may be beneficial for
identifying any signs of glaucoma.

* Dilated Fundus Exam: A dilated fundus exam can help an
optometrist assess your health in more detail by getting a
clear view of the retina. This test is typically carried out
for patients with diabetes and those who may be at risk of
developing retinal damage.
## How Many Optometrists Exist in Claremont, Perth?
Many optometrists exist in Claremont, Perth and in the Claremont
Quarter Shopping Centre, including Oscar Wylee. The amount of
optometrists available in an area will typically depend on the
population and the eye care needs of those in the area. At Oscar
Wylee Claremont, Perth, our team is passionate about providing
our customers with high-quality, dedicated eye care services.
Our optometrists are available to provide bulk billed eye tests
with our dedicated optometrists, prescription updates and new
frames. If you are looking for an optometrist in Claremont,
Perth, Oscar Wylee is available to provide all your eye care and
eyewear needs.
### What are the Other Closest Optometrist Locations to Claremont,
Perth in Australia?
The closest Oscar Wylee Optometrist locations to Claremont,
Perth are Morley Galleria, Fremantle and Booragoon. The
closest Oscar Wylee optometrist locations to Claremont, Perth
are listed below.
* Morley Galleria:  Morley Galleria is a shopping centre
located approximately 19 km away from Claremont, where our
Oscar Wylee optometrists are available to provide eye care
services. Come and visit
[Oscar Wylee Morley](https://www.oscarwylee.com.au/locations/optometrist-morley-galleria.html)
for eye tests, prescription updates and eye care advice.
* Fremantle:  Fremantle is a suburb approximately 10 km
from Claremont, Victoria.
[Oscar Wylee Fremantle](https://www.oscarwylee.com.au/locations/optometrist-fremantle.html)
is located in the Manning Buildings where you can find an
Oscar Wylee optometrist for a Medicare bulk billed eye test,
prescription updates and eye care advice.
* Booragoon:  Booragoon is a suburb located approximately
16 km away from Claremont Quarter, Victoria, where you can
find an Oscar Wylee optometrist. Visit
[Oscar Wylee Booragoon](https://www.oscarwylee.com.au/locations/optometrist-booragoon.html)
in Booragoon Westfield and our team can help you with your eye
care needs from eye tests to new frames.
### Medicare Bulk Billed Eye Tests at Oscar Wylee
For some of the best optometrists in Claremont, Australia, come in and
see the team at Oscar Wylee Claremont Quarter. Our experienced Oscar
Wylee optometrists are equipped with some of the latest optometry
equipment to ensure our customers are well taken care of and receive
high-quality eye care processes including Medicare bulk billed eye
health tests. Our optometrists will assess vision, examine the eyes
for possible eye diseases, and update any prescriptions if needed. Our
retail team can then help you shop for your new pair of frames, all on
the same day!
### Oscar Wylee Accepts Major Health Funds In-store
At our Oscar Wylee eyeglasses shop in Claremont Quarter, we accept
major health funds. Bring your valid health fund card to your
appointment with us and our team will help process your claim, as well
as answer any questions about health funds at Oscar Wylee.
### Fashion-Forward Glasses Frames at Oscar Wylee
Here at our Oscar Wylee store in Claremont Quarter, there is a range
of fashionable frames on offer, from prescription glasses and
prescription sunglasses to non-prescription glasses. Choose from Oscar
Wylee’s modern-inspired styles with bold shapes and bright colours, or
pick a more subtle and classy frame with vintage inspirations. No
matter the eyewear you need, Oscar Wylee has your covered!
Book Appointment
[Call us: (08) 6237 1814](tel:(08) 6237 1814)
[Leave a Review!](https://g.page/r/CQUedgcf31-qEBA/review)