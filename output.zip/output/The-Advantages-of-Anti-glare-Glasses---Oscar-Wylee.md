# Source: https://www.oscarwylee.com.au/guides/lenses/anti-glare

# The Advantages Of Anti-glare (Anti-reflective) Glasses
Published on October 26th, 2022
Updated on July 2nd, 2025
Australia    
[Australia](https://www.oscarwylee.com.au/guides/lenses/anti-glare)
[New Zealand](https://www.oscarwylee.co.nz/guides/lenses/anti-glare)
[Canada](https://oscarwylee.ca/guides/lenses/anti-glare)
One of the drawbacks of any corrective prescription or even a normal pair of sunglasses is reflection from the lens surface. With anti-glare (anti-reflective) glasses, you can see and be seen clearly than ever before.
Prioritise Your Eye Health
Our team can help you stay up to date with regular eye tests to keep your eyes healthy!
[Book your eye test](https://www.oscarwylee.com.au/booking)
[Function](#Function) [Advantages](#Advantages) [Preventing Glare When Driving](#Preventing) [Disadvantages](#Disadvantages)
## How do anti-glare (anti-reflective) glasses work?
Anti-glare, also known as anti-reflective glasses, are glasses that have had a coating applied to the lens. This coating is composed of many thin layers of materials with an alternating refractive index. These materials even out the refraction of light, reducing reflection and allowing over 99% of light to pass through the lens.
Oscar Wylee applies anti-reflective coating via vacuum. This means that there will be no spray marks or uneven surfaces along your glasses. We can add this coating to many different types of lenses, such as [bifocal](https://oscarwylee.ca/guides/lenses/bifocal.html) or [progressive lenses](https://oscarwylee.ca/glasses/eye/progressive-lenses).
The lens coating also has a ‘bloom’ colour. This is a faint, lingering colour from the coating itself. The colour itself is most commonly green, but blue or purple coatings can be found as well.
### Why is reflection a problem?
When any source of light reaches your spectacles, it strikes the back of your lenses and reflects. The reflection from the front of the lens will prevent others from seeing your eyes, and the reflection from the back of the lens will be seen by you. This is the reason you may sometimes see your own eyes reflected in a pair of uncoated glasses, and it’s one of the best reasons to use an anti-reflective coating on your glasses.
## At Oscar Wylee:
For further advice about our anti-reflective coatings and other lens enhancement options, simply walk into an Oscar Wylee store, and one of our friendly staff will be ready to assist you.
## What are the advantages of anti-glare (anti-reflective) glasses?
Having an anti-reflective coating on your glasses will reduce the glare you receive from light and reflective surfaces. This will reduce eye strain, improve vision, and prevent disruptive reflections.
Because of the hardening material used in the coating, anti-reflective frames also have scratch- resistant features. The coating can also make you appear better. With the glare reduction, your facial features will be clearer for all to see.
The glare blocking will also enhance your frames' appearance as it will reduce distracting reflections and make you and your glasses look better in photographs due to reducing the effects of flash.
### How do I stop glare when I’m driving?
Anti-glare (anti-reflective) glasses do not reduce the amount of light that reaches your eyes. In fact, an anti-reflective coating can improve visual clarity when driving at night by reducing halos and glare from oncoming headlights and street lamps.
This makes them a recommended choice for a night drive, for leisure or professional work.
Find Your Nearest OW Store!
We’ve got knowledgeable teams who are passionate about delivering high-quality care.
[Find a store](https://www.oscarwylee.com.au/locations/)
## Anti-glare (anti-reflective) glasses for computers:
By preventing the bright reflections and glares of both natural and artificial light, anti-glare (anti-reflective) glasses can provide a greater degree of comfort when you are working with computers.
One of the greatest benefits of anti-reflection is during video conferencing. The person viewing your camera image will be able to see through to your eyes without the harsh reflection of your computer screen obstructing their view.
### Are anti-glare (anti-reflective) and blue light glasses the same?
Blue light is believed to be a sleep-disrupting light that emits from many everyday sources of artificial light, such as computer screens or cell phones.
[Blue light](https://oscarwylee.ca/blue-light-glasses/) lenses and anti-reflective lenses both reduce the amount of glare that reaches your eyes from all sources of light. However, blue light glasses may be able to block high-energy lights from artificial sources that may cause discomfort.
Anti-glare (anti-reflective) glasses are more general in their purpose and are made to reduce disruptive reflections and allow more forms of light through your lenses. This includes the high-energy rays emitted by digital screens.
An anti-reflective coating on its own does not filter blue light from digital screens in the way that dedicated blue light filter lenses do.
At Oscar Wylee, our blue light filter options also include anti-reflective technology.
## Disadvantages of anti-glare (anti-reflective) glasses:
As anti-reflective coatings reduce glare and provide enhanced clarity, any fingerprints or dust on the lens surface will appear to be more visible. It is common for people to mention that it is harder to keep their anti-reflective lenses clean.
Because of the enhanced clarity the frames provide, the lenses will always be clearer to see. As a result, they will stain with fingerprints and oil smudges more often and more visibly, as well as scratches and damage being clearer in the lenses. At Oscar Wylee, we offer a premium anti-reflective coating that has anti-smudge technology, which will combat this disadvantage. Our premium anti-reflective coating also includes scratch and static resistance, a great addition to any pair of optical glasses.
The coating is also applied to the outside of the lens. This means extreme temperatures may damage the surface of glasses with an anti-reflective coating faster than an uncoated pair.
### Cleaning and keeping anti-glare (anti-reflective) glasses
As the coating applied to your lenses makes smudges more visible, caution is advised when cleaning your new glasses. Using a microfiber cloth is highly recommended, as any other fabric may damage or remove the coating. It’s also recommended to use a spray lens cleaner, which will help to lift dust and dirt without scratching the lens.
Your glasses should be stored in their protective casing when not in use, to minimise accidental damage to the frame, lenses or coating.
Read The Advantages Of Anti-glare (Anti-reflective) Glasses in other Oscar Wylee regions and their languages.
Australia    
[Australia](https://www.oscarwylee.com.au/guides/lenses/anti-glare)
[New Zealand](https://www.oscarwylee.co.nz/guides/lenses/anti-glare)
[Canada](https://oscarwylee.ca/guides/lenses/anti-glare)
Need to have your eyes tested?
Book an appointment with our Oscar Wylee optometrists.
[Book your eye test](https://www.oscarwylee.com.au/booking)
Find a store near you
Contact or visit your nearest store for a full quote.
[Find a store](https://www.oscarwylee.com.au/locations/)