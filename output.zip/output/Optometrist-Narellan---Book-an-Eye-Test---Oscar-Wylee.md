# Source: https://www.oscarwylee.com.au/locations/optometrist-narellan.html

# Optometrist Narellan
Narellan Town CentreShop 67, 326 Camden Valley WayNarellan NSW 2567
* Next to Queens Jeweller
Opening hours
Monday9:00am - 5:30pm
Tuesday9:00am - 5:30pm
Wednesday9:00am - 5:30pm
Thursday9:00am - 9:00pm
Friday9:00am - 5:30pm
Saturday9:00am - 5:00pm
Sunday10:00am - 4:00pm
*Store hours reflect local standard trading hours and exclude public holidays
[Visit our Narellan Google Business page for directions, reviews, and updates.](https://g.page/r/CUOH1HJONYqXEAE)
Book Appointment
[Call us: (02) 4610 1367](tel:(02) 4610 1367)
[Leave a Review!](https://g.page/r/CUOH1HJONYqXEBM/review)
Our Reviews
Loretta Garnsey
1 day ago
Very efficient appointment. Jason the optometric is very good at his profession and offered thorough... explanations.  Thanks OW.
See more
Tracey Shaw
1 week ago
Very helpful and efficient.
Maureen Gale
1 week ago
I'm very happy with the service and attention I get at Oscar Wylee.
Very friendly and attentive staf...f
See more
A. V.S.A
2 weeks ago
All the staff are so lovely! :)
Michele Twiddy
2 weeks ago
Great friendly professional service
Robert Seeto
2 weeks ago
First time experience with getting eye test and having to get glasses. Was a good experience and ser...vice with a smile as well. Thank you Oscar Wylee Narellan Robert S
See more
Liz Seeto
3 weeks ago
Mariana Perdomo
3 weeks ago
Great experience. On time and super helpful!
Katie Rogers
3 weeks ago
They couldn’t have been more helping polite and professional. The compassion the staff showed me was... beautiful.  I totally recommend Oscar Wylee narellan
See more
Christian Aliste
3 weeks ago
Very nice and helpful staff, and professional.
Liz Seeto
4 weeks ago
Staff fantastic, would highly recommend.
Lisa Prindesis
1 month ago
Great customer service, very friendly and very helpful. The optometrist was very professional and ta...lked through everything with me. Will definitely be going back
See more
Bronwen Moir
1 month ago
The staff were kind and helpful. The eye test itself was and unusually pleasant experience. My thank...s to all.
See more
Sharon Ussia
1 month ago
Excellent service and a great price
Hamza Ahmed Siddiqui
1 month ago
Even though we came in 20 minutes or more late, upon arrival the staff was friendly and considerate ...to grant us the opportunity to still have an eye test for my family. We went to Narellan town centre and It went quite quick and was highly bulk billed as advertised. The process was quite smooth, though the space was kind of limited, therefore in busy hours it can easily get cramped
See more
Denise
1 month ago
It was great and friendly
Kerrylee Hempenstall
1 month ago
From the time I arrived until I left I felt welcomed and cared for. The optometrist was calm, listen...ed, helpful and thorough. The assistants were helpful and friendly. I would highly recommend.
See more
Valerie Todd
1 month ago
had my eyes checked and was happy and the optometrist Jason was professional and explained all my qu...eries.
See more
Linda Rickards
1 month ago
Vince Whitehouse - whitehouse
1 month ago
Always Good ????
C m V D
1 month ago
Staff on the weekend were super lovely, went back in on Monday with my daughter and the service staf...f and optometrist were not friendly, in fact a little angry
See more
Jackie Kroeger
2 months ago
Jason the optometrist is so friendly &amp; professional. Answered all my questions &amp; concerns happily. T...he girls who assisted me with my frame selection were also excellent. Kate made sure I didn't select the wrong type of frame for my type of lenses. Highly recommend ????
See more
Daniel Overett
2 months ago
I found them very helpful and pleasant to deal with
Asma Alam
2 months ago
I like the way they're taking care of me, and my eye check-up was really very good. Joshua is really... a great optometrist. Asma Alam
See more
Kerryn Tutt
2 months ago
Lucy Surtandi
2 months ago
Professional, good choices and good value for money, eyes check was excellent
tiana roberts
2 months ago
Kate and Jason were so accommodating during my experience at Oscar Wylee in Narellan. Jason’s test w...as clear and concise and Kate helped me pick the best specs for me! I will definitely be returning here each year. ????
See more
Caroline Argyle
2 months ago
Professional and helpful optometrist and staff
Teresa Webster
3 months ago
Very efficient team
Donna Hayes
3 months ago
The sales lady was lovely, very helpful. Jay Jay the optometrist was absolutely brilliant. Very thor...ough and efficient. Will be returning
See more
Elisa James M.Mus.Th.M
3 months ago
The staff at Oscar Wylee Narellan are fantastic. After I had a very upsetting experience at another ...brand , they kindly took my glasses and prescription and fixed everything up for me in record time. They were so sweet and kind and handled everything with grace and ease. They will be my go to choice for glasses from now on. Highly recommended.
See more
Shane Murray
3 months ago
YAHYA S TOURE
3 months ago
The customer service is top notch!!!
Angela Kane
4 months ago
Great service and excellent Optometrist.
Claudia Robino
4 months ago
I could not be happier, I was just walking by and they managed to fit me in. The optometrist was tho...rough and explained everything clearly. Once outside, the sales girl was very patient and helpful when I was choosing my frames. Could not be happy.
See more
Caitlin Short
4 months ago
Rickey Pedder
4 months ago
Emma Watkins
4 months ago
Easy experience, very informative. Happy with the appointment I had
Elizabeth Hall
4 months ago
Very happy with the kind, calm and patient service provided.
David Dorman
5 months ago
Katie Hooker
5 months ago
Great friendly, customised service.
Mey Ak
5 months ago
My young daughters were so nervous... but jason the optometrist was very patient, explained what was... going to happen and made them feel comfortable.
Both my girls loved the glasses range.
See more
James Tyler
6 months ago
I came in last week for an eye test, found some new glasses which I really liked, the service was gr...eat, professional, and Jason was good to talk to, very caring, very helpful too
See more
Tania Robinson
6 months ago
The optomestrist was lovely the dark haired middle aged lady was great but the young girl working wi...th her was Extremely annoying.  She spoke in riddles the whole time. She  needs some customer service training.  My husband and I almost walked out because of her. We will be back to pick up our glasses but we won't be returning if she is still there..
See more
Donna McDougall
6 months ago
Optometrist was amazing, explaining everything in detail, and the girls that help with frame selecti...on were wonderful too.
See more
Ivan
6 months ago
Natalie Cuerden
6 months ago
Attentive and friendly great experience from the optometrist to the front of house staff.
PAULINE DOWNING
6 months ago
We attended Oscar Wylee-Optometrist at Narellan Town Centre in early February whose optometrist is J...ason Ford. We were exceedingly impressed with Jason's skill and attitude and excellent advice. We will certainly be pleased to attend again when our next appointment is due.
See more
David Logan
7 months ago
The store is equipped with all the latest test equipment and the staff are gret to deal with.
Carolyn Stokes
7 months ago
testing of eyes was excellent. The girl out the front could have offered her assistance in choosing ...the glasses sooner
See more
## Find an Optometrist in Narellan With Oscar Wylee
If you live in the Harrington Park, Smeaton Grange or Kirkham areas, our Oscar Wylee Narellan store at the Narellan Town Centre is your go-to for optometry services. Our dedicated optometrists can provide you with comprehensive eye tests, for checking vision health and assessing for eye diseases. Our eye health tests can be bulk billed if you are an eligible Medicare cardholder. To make your appointment with Oscar Wylee Narellan, catch one of the many buses that service the Narellan area, or utilise the centre’s free parking. Once here, our friendly staff can help as you shop our range of affordable frames, inspired by modern and vintage styles. 
If you have time to spare after your appointment, the Narellan Town Centre has over 200 stores for you to explore. From Casey’s Toys to City Beach and plenty of cafes, there is something for everyone to enjoy. Come on down and see the Oscar Wylee Narellan team at the Town Centre.        
Meet Our Team
* Optometrist Partner
B. Optom (Hons)
Therapeutically Endorsed
* Store Manager
Certification IV in Optical Dispensing
5+ years experience in the Optical Industry
Our Services
* Bulk Billed Eye Examinations
* Professional Frame Styling
* Frame Adjustments and Repairs
* Visual Fields Testing
* Digital Retinal Scanning
Show All
## Find an Optometrist in Narellan, Sydney for an Eye Health Test
An optometrist in Narellan, Sydney is where you can find a dedicated team that is passionate about your vision health and making sure you feel and look your best. At Oscar Wylee, we offer an eye health test in Narellan as well as general assistance with anything optometry-related. Our optometrists are qualified to diagnose and help manage a range of eye diseases as well as to refer you to an eye doctor if they deem it necessary. When you visit our store in Narellan, you can browse our wide range of prescription sunglasses so you can protect your eyes in style.
At Oscar Wylee Narellan, Sydney, you can also seek help with what frames are best for you thanks to our skilled optical dispenser. You won’t have to worry about any out-of-pocket expenses as you have access to our services at a bulk billed price if you are registered on Australia’s Medicare system and are an eligible cardholder. The average price for an optometrist in Narellan may be based on different factors such as the number of available optometrists in the area, the equipment used and your vision requirements.
## How to Find an Optometrist in Narellan, Sydney?
To find an optometrist in Narellan, Sydney you can take certain steps that can help make it easier for you such as searching online, assessing the store’s opening hours and finding the directions to your chosen location. The steps on how to find an optometrist in Narellan are listed below.
1. Search online using the phrase, Narellan optometrist near me. This can also be done here on the website via our locations page.
2. Click on the Oscar Wylee link, which will take you directly to our Narellan optometrist store page.
3. See the store’s opening hours and where the store is located specifically.
4. Use the Narellan Google Business page link located under store hours to see the directions on how to get to the store.
You can also find an optometrist in Narellan by searching the keywords optometrist near me. If you have locations enabled on your smartphone and you’re in the Narellan area, our Narellan store page should appear easily for you to click on.
### Is it Hard to Get an Eye Appointment in Narellan, Sydney?
No, it is not hard to get an eye appointment in Narellan. You can easily book an appointment to see an Oscar Wylee optometrist in Narellan right here on this page. At Oscar Wylee we have highly qualified optometrists available for bulk billed eye appointments, which can be booked online or in-store.
#### How to Compare Optometrists in Narellan to Each Other?
To compare optometrists in Narellan, you can use factors such as eye tests offered, health fund coverage, lens types and add-ons and eyewear offered. To take care of your vision and eye health, it is important to receive an eye test at least once every two years. There are different types of tests that can be performed in an eye test and not all optometrists may offer the same tests. Health funds can be used to help cover some of the cost of your frames and lenses. To find out if your health fund is accepted at Narellan optometrist in Sydney, visit their website. In the case of Oscar Wylee, we accept all major health funds and provide on-the-spot claims in-store. There are many different lens options available for prescription glasses such as single vision, multifocal and high index lenses. Most optometrists in Narellan will offer these lenses although it is good to make sure. There are also lens add-ons available to enhance your glasses such as anti-reflective and blue light filters. Finally, if you are looking to purchase a pair of glasses after your eye test, you can compare the different styles and colours you are interested in from Narellan optometrists in Sydney. Oscar Wylee offers a wide range of frames with vintage and modern inspirations in bold colours and subtle designs.
#### How to Find an Eyeglasses Shop in Narellan, Sydney?
To find a glasses store in Narellan, you can try to follow these simple steps including searching online, selecting a convenient location and looking at their health insurance policies. The steps on how to find a glasses store in Narellan, Sydney are listed below.
1. Search online using the phrase, glasses store in Narellan. This will provide you with various options for glasses stores in the whole area of Narellan.
2. Select a glasses store that is most convenient for you to travel to.
3. Click the link to find out more information such as opening hours, exact location and directions to the glasses store in Narellan.
4. Read their health insurance policies to ensure you know what health benefits you have access to.
Our Oscar Wylee glasses store in Narellan, Sydney offers primary eye care services such as comprehensive eye tests and other services performed by an optometrist and offers prescription and non-prescription eyewear.
##### Is it Possible to Purchase Prescribed Sunglasses in Narellan, Sydney Without Seeing an Optometrist?
Yes and no, it is possible to [purchase prescribed sunglasses](https://www.oscarwylee.com.au/sunglasses.html) in Narellan, Sydney without seeing an optometrist if you already have a prescription that has not expired. If your prescription is expired, you can book an eye test to receive an updated or new prescription which will require you to see an optometrist. This will ensure your prescription sunglasses are appropriate for your visual needs.
## Where is the Oscar Wylee Narellan Optometrist in Sydney Located?
The Oscar Wylee Narellan optometrist is located at the Narellan Town Centre which is located at Camden Valley Way. The Oscar Wylee Narellan store can be found next to Queens Jeweller.
### What is the Phone Number of Oscar Wylee Narellan Optometrist Store?
The Oscar Wylee Narellan optometrist store phone number is [(02) 4610 1367](tel:(02) 4610 1367). You can contact the Oscar Wylee Narellan store between the hours of 9:30 am and 5:30 pm on Monday, Tuesday, Wednesday and Friday, on Thursday between 9 am and 9 pm, on Saturday between 9 am and 5 pm and on Sunday between 10 am and 4 pm.
### What are the Reviews for Oscar Wylee Narellan Optometrist in Sydney?
The many reviews for Oscar Wylee Narellan optometrist in Sydney, left by our various customers can be found here on the website and online when you search for Oscar Wylee Narellan optometrist. The reviews for Oscar Wylee Narellan optometrist are listed below.
* Kathy Larsson:  Geoffrey was very pleased with the staff and the efficiency of his experience.
* Julie O'Neill:  All staff were extremely helpful and lovely. Thank you.
* Jonathon House:  Great Team! Professional friendly staff that know their range of eyewear. The optometrist Jason is honest and efficient. This is the 2nd time I've bought glasses from the team and will come back again when I need an update.
* Karlee Mallia:  The optometrist was great! And the staff was really helpful to pick out glasses.
#### What Treatments or Eye Care Processes are Done in the Oscar Wylee Narellan Optometrist Location?
The treatments or eye care processes done in the Oscar Wylee Narellan optometrist Sydney location include a tonometry test, a digital photograph, a slit lamp exam and a refraction test. Additional tests that may also be performed can include a visual field test and a dilated fundus exam. The treatments or eye-care processes done in the Oscar Wylee Narellan optometrist Sydney location are listed below.
* A Tonometry Test: An optometrist or optical dispenser will conduct a tonometry test which involves the use of a machine that will release small puffs of air into your eyes. This will assist with measuring pressure in the eye.
* A Digital Photograph: An optometrist or optical dispenser may take a digital photograph of your eye which can be kept on record to use in future appointments to evaluate any changes to your eye.
* Slit Lamp Test: A slit lamp test can be used to evaluate your eye health, by examining your cornea and iris which are the anterior and posterior of the eye.
* Refraction Test: During a refraction test, an optometrist will have you view an image through different lenses and ask you to confirm which helps you see the image clearer.
* Visual Field Test: A visual field test can assist with assessing your peripheral vision, which may be beneficial for identifying any signs of glaucoma.
* Dilated Fundus Exam: A dilated fundus exam can help an optometrist assess your health in more detail by getting a clear view of the retina. This test is typically carried out for patients with diabetes and those who may be at risk of developing retinal damage.
## How Many Optometrists Exist in Narellan, Sydney?
Many optometrists exist in Narellan, Sydney to provide eye tests and glasses, including Oscar Wylee. If you’re in search of essential eye services such as a comprehensive eye test, a wide selection of prescription eyewear and more, then choose Oscar Wylee as your first choice for optometry services. The number of optometrists in Narellan may be due to the number of residents in the area and the geographical size of the suburb.
### What are the Other Closest Optometrist Locations to Narellan, Sydney in Australia?
The other closest Oscar Wylee optometrist locations to Narellan, Sydney Australia are Macarthur Square and Liverpool. Macarthur Square is close to Narellan with just 8 km in between stores and can be found at the Macarthur Square Shopping Centre on level 2, near Sephora, along Gilchrist Drive in Campbelltown. The [Oscar Wylee Macarthur](https://www.oscarwylee.com.au/locations/optometrist-macarthur-square.html) Square store can offer bulk billed comprehensive eye tests as well as a wide selection of fashionable frames. Liverpool is close to Narellan with 25-28 km in between stores and can be found on level 2 of the Westfield Shopping Centre. At [Oscar Wylee Liverpool](https://www.oscarwylee.com.au/locations/optometrist-liverpool.html) , you have access to eye tests to ensure optimal eye health or if you require updates to your prescription.
### Oscar Wylee Narellan Optometrists
We offer eye tests to ensure good eye and vision health and are available for bulk billing for those with valid Medicare cards so you can be sure there are no out-of-pocket expenses. Have your annual eye health checkup and browse for your new prescription glasses or prescription sunglasses on the same day. At Oscar Wylee Narellan, you can prioritise your eyesight, examine and take care of eye problems, both with regular eye tests and affordable frames.
### Health Fund Claims at Oscar Wylee Narellan
Oscar Wylee Narellan staff are experts at what they do, including helping you through the ins and outs of your health fund. You can easily have your health fund claim processed with your valid health fund card. Our Oscar Wylee Narellan optometrists are also available to assist you in finding out what you have access to with your health fund. We want nothing more than for you to get prescription sunglasses or glasses at an affordable and competitive price.
### Stylish Frames at Oscar Wylee Narellan
At Oscar Wylee Narellan, you can expect to find affordable prescription sunglasses and prescription glasses without sacrificing style. Come visit our Oscar Wylee Narellan store today and speak with any one of our experts and find the perfect frames for your face shape. Currently, you can receive three pairs of prescription glasses from $249.
Book Appointment
[Call us: (02) 4610 1367](tel:(02) 4610 1367)
[Leave a Review!](https://g.page/r/CUOH1HJONYqXEBM/review)