# Source: https://www.oscarwylee.com.au/locations/optometrist-ellenbrook.html

# Optometrist Ellenbrook
Ellenbrook CentralShop G-043, 11 Main Street Ellenbrook WA 6069
* Near Coles
Opening hours
Monday9:00am - 5:30pm
Tuesday9:00am - 5:30pm
Wednesday9:00am - 5:30pm
Thursday9:00am - 7:00pm
Friday9:00am - 5:30pm
Saturday9:00am - 5:00pm
Sunday11:00am - 5:00pm
*Store hours reflect local standard trading hours and exclude public
holidays
[Visit our Ellenbrook
Google
Business page for directions,
reviews, and updates.](https://maps.app.goo.gl/ijCAMkGk3weJSA6f8)
Book Appointment
[Call us: (08) 6186 2335](tel:(08) 6186 2335)
[Leave a Review!](https://g.page/r/CQAfaTnod5pNEBM/review)
&nbsp;
Our Reviews
Martin Orrock
3 days ago
Good service
Emma Whiteman
1 week ago
I was very happy with my experience at Oscar Wylee. The optometrist was very informative. The choice... of frames are great. Really great styles and colours. I'm looking forward to getting my new pairs.
See more
Tanya Andion
2 weeks ago
Dean Cleary
2 weeks ago
Great service, experience and care.
Anne Samuelson
3 weeks ago
The front house staff and optometrist were both excellent in their service and explained everything ...as required
See more
Heath Knott
4 weeks ago
Really helpful and staff explained process really well
Thuy Nguyen
1 month ago
It was great service with Nam and Oscar team at Newtown
Very helpful
Thanks
John Alsop
1 month ago
My eye exam and the proposed eyewear solutions were very thorough, practical and affordable. All sta...ff were welcoming and professional in their approach.
See more
Ryan Caldwell
1 month ago
Christian Birch
1 month ago
The eye test was a pleasant experience. The lady whom conducted the test was really nice and gave we...ll informed, detailed answers to my questions.
See more
Liam Kavanagh
1 month ago
Wonderful customer service, very humanistic, polite and informative. Great service ????.  Great peop...le
See more
Filipa Baptista
1 month ago
Very professional, I'll definitely go back.
Luis Loyola
1 month ago
Ruth singh
1 month ago
Excellent very helpful and efficient, the young man at the front desk was very cheerful and went out... of his way to help me,the optometrist was also very nice
and did a great job
See more
Alice Grohmann
2 months ago
Found a really cute frame here for a small price. Even with my bad eyesight (-7) the glass is super ...thin. Shoutout to Fiona for the great service.
See more
Shae Judd
2 months ago
Jesse Aish
2 months ago
I booked on really late notice and team was great. No wait, and very friendly. The process was reall...y easy also. Highly recommend
See more
Kimberlee Currell
2 months ago
Always super wonderful and helpful, very happy with my purchase today
Alejandra Manosalva.
2 months ago
Hannah
2 months ago
Luciana Callaghan
2 months ago
My optometrist was on time for my appointment and kind
. No tiny seats to squish into with 4 others ...whilst waiting! Lovely banquette.
Personalised. Lovely optometrist and front of house.
I wasn't asked to "look at the frames" like I had been asked when at another optomatrist instead of checking me in.
I wasn't sold glasses for no reason (like the "savers" brand). My eyes are fine for driving and no signs of glaucoma .
A walk up the road so support even more local.
Thank you I'll be back next year!
See more
Jason Berney
2 months ago
From the moment I stepped in the store the service was amazing. Looking forward to receiving my new ...glasses!
See more
Mackenzie
2 months ago
Amit Karmakar
2 months ago
Absolutely beautiful experience. Welcoming, friendly and genuinely helpful. Can't recommend enough.
Danny Booth
3 months ago
Fast and easy, always good to come by and get my eyes checked after 2 years and have the correct len...ses on great pair of glasses
See more
Grace Cauchi
3 months ago
Great experience at this store, the sales assistant was extremely patient with us and knowledgeable!
Lachlan Smith
3 months ago
Rillark Bolton
3 months ago
Very friendly, great service and they don’t oversell you ????
Louella Archbold
3 months ago
Christina was friendly and professional and I appreciated her in depth explanation of the process an...d its outcomes. She was efficient yet thorough. Fiona was wonderful, helping me make decisions to find the right glasses. An excellent experience so I am now switching from my previous provider to Oscar Wyler.
See more
Kristine Ballard
3 months ago
Great fuss free service. Smart and helpful staff make it easy. Great choice of specs too. Repeat pur...chaser over many years. Always a pleasure to visit. (Newtown NSW store).
See more
Susannah Perkins
3 months ago
Amazing fast friendly service.
Megan Donald
3 months ago
Great service, the team always make you feel comfortable during your eye test. The turn around for n...ew glasses is always quick.
See more
Ali Zalums
3 months ago
Very helpful thank you!
Lizzy Burley
3 months ago
Engaging and polite staff that made picking the next pair of glasses so easy! They were also able to... repair a pair of old frames for a very affordable price!
See more
MI ibrahim
4 months ago
Great experience, great team
Isabelle Robinson
4 months ago
Both the sales team and Optometrist were very nice and helpful! Made the experience easy for me, sto...re was also really clean and welcoming!
See more
Melanie Smith
4 months ago
The weekend optometrist was exceptional in his duty of care and assisting with additional questions ...I had.  Excellent service.
See more
Martin Temple-Brown
4 months ago
Excellent experience going for first eye test. Staff are incredibly helpful and friendly. I highly r...ecommend this place. They also have a good range of frames. They were able to see me quickly on the same day.
See more
Kate Maconachie
4 months ago
I've been going to Oscar Wylee for several years now. The optometrist is friendly, professional, and... explains everything clearly. All of my eye tests have felt thorough but relaxed, and the staff are always welcoming and helpful. They also have a great range of frames for any budget.
See more
Karen Strates
4 months ago
Oscar Wylee Newtown has the best customer service! I made an online booking but on arriving early I ...asked if I could have an earlier appointment. I received a phone call about half an hour later moving it forward by one hour! which was great as I could only get 2hr street parking. The optometrist was superb and so helpful. This is my favourite OW in Sydney!
See more
Jane Scott
4 months ago
Sam made the experience of having my eyes tested very easy. He listened to any questions I had and p...rovided helpful responses.
See more
James Lees
4 months ago
I've gone here for multiple eye tests now, and it has been a great experience each time. Staff are v...ery helpful and kind, and have answered any question I've had about my eyes or the testing procedure. Also has a really good selection of glass frames.
Would easily recommend this optometrist
See more
Mathew Johnston
4 months ago
friendly, attentive staff. the optometrist was thorough & professional
Liz Nguyen
4 months ago
All staff members were really welcoming and helpful. I've been a couple of times and it's the same d...elightful experience each time. Highly recommend. Will be a return customer
See more
Harriet
4 months ago
Amazing customer service, super friendly and helpful. Everyone was very knowledgeable!
Joseph Dang
4 months ago
Staff was really friendly and knows their stuff.
Excellent customer service and follow up if I neede...d any assistance.
Suggested what style you needed and value for your money.
I will definitely return with my family and refer friends.
See more
Astrid
4 months ago
Eva Huezo
4 months ago
Great service!! Fiona is wonderful and so helpful
Mia K
5 months ago
I appreciate Fiona’s help!
Sam George
5 months ago
Zac was great, very helpful and friendly!
require(['jquery', 'js/slick.min'], function ($) {
$('#review-list-right').slick({
dots: false,
arrows: true,
infinite: false,
slidesToShow: 1,
slidesToScroll: 1,
autoplay: false,
mobileFirst: true,
responsive: [
{
breakpoint: 800,
settings: {
slidesToShow: 3,
slidesToScroll: 1,
dots: false
}
}
]
});
$(".myBtn").click(function() {
var dots = $(this).parent().find(".dots");
var moreText = $(this).parent().find(".more");
var btnText = $(this).parent().find(".myBtn")
if(dots.css('display') == 'none'){
dots.css("display", "inline");
btnText.html("See more");
moreText.css("display", "none");
} else {
dots.css("display", "none");
btnText.html("Hide");
moreText.css("display", "inline");
}
})
});

## Find
an Optometrist in Ellenbrook With Oscar Wylee
If you live in the Henley Brook, Aveley or The Vines areas,
our Oscar Wylee store at Ellenbrook Central is your go-to for high-quality optometry and eye care services. Take the
bus or drive in, using one of the centre’s 2500 car parking spaces, and our Oscar Wylee optometrists will provide
Medicare bulk billed eye tests. Once you are done with your test, our friendly retail team will help you shop our
range of affordable and stylish frames.
When you finish your appointment, why not make the most of the many retail stores, cafes and beauty salons Ellenbrook
Central has to offer? Whether you need to do groceries at Woolworths, fancy a haircut from DJ Salon or need a caffeine
hit from Jamaica Blue, you’ll find everything you need at Ellenbrook Central.
For those who live in the Ellenbrook area, other Oscar Wylee optometrists nearest to you include Oscar Wylee Westfield
Carousel and Oscar Wylee Morley Galleria. Come in and see us at our Oscar Wylee eyeglasses shop today, and experience
some of the best optometry services in Ellenbrook, Australia!
Meet Our Team
* Store Manager
Our Services
* Bulk Billed Eye Examinations
* Professional Frame Styling
* Frame Adjustments and Repairs
Show All
## Find an Optometrist in Ellenbrook, Perth for an Eye Health Test
You can find an Oscar Wylee optometrist in Ellenbrook, Perth for an eye health test and other eye care
services such as prescription updates and new frames. Located in Ellenbrook Central, Oscar Wylee
optometrists are available to perform eye tests that will include vision testing and the detection of
eye diseases and eye conditions. Other eye care services available at Oscar Wylee Ellenbrook include
prescription updates, eye care advice and referrals to an ophthalmologist, also known as an eye doctor,
for specialised care if needed. In Ellenbrook, Perth, the average cost for an optometrist often depends
on factors such as a person's age, health and eye care needs. At Oscar Wylee, our eye tests are
conducted at a bulk billed price under Australia’s Medicare system.
At Oscar Wylee’s glasses shop in Ellenbrook, Perth, we have a wide range of frames available for
purchase including prescription glasses, prescription sunglasses and non-prescription glasses. Our
retail team, including our optical dispensers, are located in-store to help customers shop our frames.
If you need adjustments or lens add-ons such as a blue light filter, our team will be able to assist
with this, ensuring all of our customers leave with eyewear that is right for their vision and lifestyle
needs. For high-quality eye care services such as new frames or eye health tests in Ellenbrook, Perth,
come and visit our Oscar Wylee team!
## How to Find an Optometrist in Ellenbrook, Perth?
To find an optometrist in Ellenbrook, Perth you can take certain steps that can help make it easier for
you such as searching online, assessing the store’s opening hours and finding the directions to your
chosen location. The steps on how to find an optometrist in Ellenbrook, Perth are listed below.
1. Search online using the phrase, optometrist near me in Ellenbrook. This can also be done here on the
website via our locations page.
2. Click on the Oscar Wylee link, which will take you directly to our Ellenbrook optometrist store
page.
3. See the store’s opening hours and where the store is located specifically.
4. Use the Ellenbrook Google Business page link located under store hours to see the directions on how
to get to the store.
You can also find an optometrist in Ellenbrook, Perth by searching the keywords optometrist near me. If
you have locations enabled on your smartphone and you’re in the Ellenbrook, Perth area, our Ellenbrook
store page should appear easily for you to click on.
### Is it Hard to Get an Eye Appointment in Ellenbrook, Perth?
No, it is not hard to get an eye appointment in Ellenbrook. You can easily book an appointment to see
an Oscar Wylee optometrist in Ellenbrook, Perth right here on this page. At Oscar Wylee we have highly
qualified optometrists available for bulk billed eye appointments, which can be booked online or
in-store.
#### How to Compare Optometrists in Ellenbrook, Perth to Each Other?
To compare optometrists in Ellenbrook, Perth, you can use factors such as eye tests offered, health
fund
coverage, lens types and add-ons and eyewear offered. To take care of your vision and eye health,
it is
important to receive an eye test at least once every two years. There are different types of tests that
can be performed in an eye test and not all optometrists may offer the same tests. Health funds can be
used to help cover some of the cost of your frames and lenses. To find out if your health fund is
accepted at an optometrist in Ellenbrook, Perth visit their website. In the case of Oscar Wylee, we
accept all major health funds and provide on-the-spot claims in-store. There are many different lens
options available for prescription glasses such as single-vision, multifocal and high-index lenses. Most
optometrists in Ellenbrook, Perth will offer these lenses although it is good to make sure. There are
also lens add-ons available to enhance your glasses such as anti-reflective and blue light filters.
Finally, if you are looking to purchase a pair of glasses after your eye test, you can compare the
different styles and colours you are interested in from the optometrists in Ellenbrook, Perth. Oscar
Wylee offers a wide range of frames with vintage and modern inspirations in bold colours and subtle
designs.
#### How to Find an Eyeglasses Shop in Ellenbrook, Perth?
To find a glasses store in Ellenbrook, Perth you can try to follow these simple steps including
searching online, selecting a convenient location and looking at their health insurance policies.
The
steps on how to find a glasses store in Ellenbrook, Perth are listed below.
1. Search online using the phrase, glasses store in Ellenbrook, Perth. This will provide you with
various options for glasses stores in the whole Ellenbrook, Perth area.
2. Select a glasses store that is most convenient for you to travel to.
3. Click the link to find out more information such as opening hours, exact location and directions to
the glasses store in Ellenbrook.
4. Read their health insurance policies to ensure you know what health benefits you have access to.
Our Oscar Wylee glasses store in Ellenbrook, Perth offers primary eye care services such as
comprehensive eye tests as well as other services performed by an optometrist and offers prescription
and non-prescription eyewear.
##### Is it Possible to Purchase Prescribed Sunglasses in Ellenbrook, Perth Without Seeing an Optometrist?
Yes and no, it is possible to [purchase
prescribed sunglasses](https://www.oscarwylee.com.au/sunglasses.html) in Ellenbrook, Perth without seeing an
optometrist if you already have a prescription that has not expired. If your prescription is expired,
you can book an eye test to receive an updated or new prescription which will require you to see an
optometrist. This will ensure your prescription sunglasses are appropriate for your visual needs.
## Where is the Oscar Wylee Ellenbrook, Perth Optometrist Located?
The Oscar Wylee Ellenbrook optometrist is located in Ellenbrook Central shopping centre, in the suburb
of Ellenbrook.
### What is the Phone Number of Oscar Wylee Ellenbrook, Perth Optometrist Store?
The phone number for our Oscar Wylee Ellenbrook, Perth optometrist store is [(08) 6186 2335](tel:(08) 6186 2335). Our Oscar
Wylee Ellenbrook, Perth store is open, and our staff are available to be contacted Monday to Wednesday
from 9 am to 5.30 pm, Thursday 9 am to 7 pm, Friday 9 am to 5.30 pm, Saturday 9 am to 5 pm and Sunday 11
am to 5 pm.
What are the Reviews for Oscar Wylee West Edmonton Mall in Alberta?
The many reviews for Oscar Wylee West Edmonton Mall in Alberta, left by our various
customers can be found here on the website and online when you search for Oscar Wylee
West Edmonton Mall. The reviews for Oscar Wylee West Edmonton Mall are listed below.
Jazmyn Hogg: Really helpful and nice!
Mehdi Ben: The staff are amazing and helpful and professional. The doctor is
a nice lady, she explained everything to me concerning my eye condition and she gave
me advice to protect and take care of my eyes.
Daniela Baldauf: Staff were great, friendly and helpful. Dr Tu was quick but
thorough. Appointment was on time and checkout process was speedy.
Bibi Valieva: Amazing staff and the glasses selection is diverse. I have a
very round wide face and so it’s hard finding glasses that fit and look nice but had
no problem here. Also the price can’t be beat.

#### What Treatments or Eye Care Processes Are Done in the Oscar Wylee Ellenbrook, Perth Optometrist
Location?
The treatments or eye care processes done in the Oscar Wylee Ellenbrook, Perth optometrist location
include a tonometry test, a slit lamp exam, a digital photograph, and a refraction test.
Additional
tests that may also be performed can include a visual field test and a dilated fundus
exam. The
treatments or eye-care processes that are done in the Oscar Wylee Ellenbrook optometrist location are
listed below.
* A Tonometry Test: An optometrist or optical dispenser will conduct a tonometry test which
involves the use of a machine that will release small puffs of air into your eyes. This will assist
with measuring pressure in the eye.
* A Digital Photograph: An optometrist or optical dispenser may take a digital photograph of
your eye which can be kept on record to use in future appointments to evaluate any changes to your
eye.
* Slit Lamp Test: A slit lamp test can be used to evaluate your eye health, by examining your
cornea and iris which are the anterior and posterior of the eye.
* Refraction Test:  During a refraction test, an optometrist will have you view an image
through different lenses and ask you to confirm which helps you see the image clearer.
* Visual Field Test: 
A visual field test can assist with assessing your peripheral vision, which may be beneficial for
identifying any signs of glaucoma.
* Dilated Fundus Exam:  A dilated fundus exam can help an optometrist assess your health in
more detail by getting a clear view of the retina. This test is typically carried out for patients
with diabetes and those at risk of developing retinal damage.
## How Many Optometrists Exist in Ellenbrook, Perth?
Many optometrists exist in Ellenbrook, Perth and in the Ellenbrook Central shopping centre, including
Oscar Wylee. The amount of optometrists available in an area will typically depend on the population and
the eye care needs of those in the area. At Oscar Wylee Ellenbrook, Perth, our team is passionate about
providing our customers with high-quality, dedicated eye care services. Our optometrists are available
to provide bulk billed eye tests with our dedicated optometrists, prescription updates and new frames.
If you are looking for an optometrist in Ellenbrook, Perth, Oscar Wylee is available to provide all your
eye care and eyewear needs.
### What are the Other Closest Optometrist Locations to Ellenbrook, Perth in Australia?
The closest Oscar Wylee optometrist locations to Ellenbrook, Perth are Karringyup, Morley Galleria
and
Westfield Carousel. The closest Oscar Wylee optometrist locations to Ellenbrook, Perth are listed
below.
* Karrinyup Karrinyup is a suburb located approximately 30 km from Ellenbrook where you can
find an Oscar Wylee optometrist. Find our [Oscar Wylee Karrinyup](https://www.oscarwylee.com.au/locations/optometrist-karrinyup.html)
team in Karrinyup Shopping Centre for
eye care services including eye tests and new frames.
* Morley Galleria Morley Galleria is a shopping centre located approximately 20 km away from
Ellenbrook, in which you can find an Oscar Wylee optometrist for eye care services. [Oscar Wylee Morley
Galleria](https://www.oscarwylee.com.au/locations/optometrist-morley-galleria.html) is located in the suburb of Morley, where our optometrist can provide Medicare bulk
billed
eye tests and prescription updates.
* Westfield Carousel: Westfield Carousel is a shopping centre located approximately 34 km away
from Ellenbrook in which you can find an Oscar Wylee optometrist. [Oscar Wylee Carousel
Westfield](https://www.oscarwylee.com.au/locations/optometrist-carousel.html) is
located in the suburb of Cannington, where our optometrists can provide Medicare bulk billed eye tests
and our retail staff can help customers shop for new frames from our stylish collection.
### Ellenbrook Bulk Billed Eye Examinations
Come in and have your prescription updated at Oscar Wylee Ellenbrook, so you can shop for a new pair of
fashion-forward eyeglasses on the same day. Our trained Oscar Wylee Ellenbrook optometrists are onsite to
update your prescription or provide a new one if necessary, usually in under 30 minutes. Oscar Wylee
optometrists will assess your vision, check your eye health and diagnose possible eye diseases and conditions.
With the recommended frequency of an eye check-up and vision testing being at least once every two years,
Oscar Wylee’s optometrist-led eye tests in-store at Oscar Wylee Ellenbrook, Australia, can keep you up-to-date
on your eyesight and eye health needs.
### Health Funds Accepted at Oscar Wylee
Oscar Wylee in Ellenbrook, Australia accepts all major health funds including Bupa, Medibank and HCF. Our
friendly staff are trained to process your claim in-store with a valid health fund card, as well as answer any
questions you have about your claim. Remember to bring your health fund card to your next appointment with
Oscar Wylee Ellenbrook for your eyewear and optometry needs.
### Stylish Glasses in Ellenbrook
Oscar Wylee Ellenbrook Central offers a range of prescription eyeglasses and prescription sunglasses in a
variety of modern and vintage-inspired styles. With add-ons such as anti-reflective coating, a blue light
filter, or polarised lenses, you’ll be sure to find a pair of frames to meet your eye care needs. Oscar
Wylee’s experts in-store can assist in ensuring you receive the frames that are best suited to your lifestyle
and prescription needs.
Book Appointment
[Call us: (08) 6186 2335](tel:(08) 6186 2335)
[Leave a Review!](https://g.page/r/CQAfaTnod5pNEBM/review)