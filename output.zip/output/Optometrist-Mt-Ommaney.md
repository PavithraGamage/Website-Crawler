# Source: https://www.oscarwylee.com.au/locations/optometrist-mt-ommaney.html

# Optometrist Mt Ommaney
Mt Ommaney Centre SP103, Lot 3 Mount Ommaney,171 Dandenong Rd. Mount Ommaney, QLD 4074
* Near Woolworths
Opening hours
Monday9:00am - 5:30pm
Tuesday9:00am - 5:30pm
Wednesday9:00am - 5:30pm
Thursday9:00am - 8:00pm
Friday9:00am - 5:30pm
Saturday9:00am - 5:00pm
Sunday10:00am - 4:00pm
*Store hours reflect local standard trading hours and exclude public holidays
[Visit our title Google Business page for directions, reviews, and updates.](https://maps.app.goo.gl/XYtkwLozFy4RFXHd9)
Book Appointment
[Call us: (07) 2111 2605](tel:(07) 2111 2605)
[Leave a Review!](https://g.page/r/CQRYjmSiuUC5EBM/review)
Our Reviews
Mayowa Showunmi
3 months ago
Had a great experience at Oscar Wylee last week. The optometrist, Aaron was so lovely, professional,... and made me feel really comfortable throughout the appointment. Highly recommend!
See more
It's Me!
3 months ago
I just love it here!! The staff here are genuinely so kind and patient, I took ages to select my gla...sses but I didnt feel rushed at all, the frames are really good quality and affordable too!! Definitely recommend!! ????????
See more
## Find an Optometrist in Mount Ommaney With Oscar Wylee
If you live in areas such as Jindalee, Jamboree Heights, or Sinnamon Park, our Oscar Wylee store at the Mount Ommaney Centre in Mount Ommaney is your go-to for high-quality optometry and eye care services.
The Mount Ommaney Centre bus interchange is situated directly outside the shopping centre, allowing easy public transport access, alongside the centre’s free parking if you choose to drive. Our dedicated team of Oscar Wylee optometrists here provide Medicare bulk billed eye tests, and our friendly retail team can help you choose a pair of frames from our affordable and stylish range of glasses.
Mount Ommaney Centre offers a range of fresh food, fashion, and cafes at your disposal after your appointment with us. Why not stock up on groceries at Mt Ommaney Fresh, window shop at Pandora, or grab a coffee at Espresso Lane?
For those who live in the Mount Ommaney area, other Oscar Wylee optometrists nearest to you include Oscar Wylee Indooroopilly, Oscar Wylee Albert St, and Oscar Wylee Mt Gravatt. Come and visit us at your preferred Oscar Wylee store today, and experience some of the best optometry services in Queensland!
Meet Our Team
* Optometrist
MOptom, BVisSc
Therapeutically Endorsed Optometrist
iRO Colour Vision Certified
* Store Manager
Our Services
* Bulk Billed Eye Examinations
* Professional Frame Styling
* Frame Adjustments and Repairs
* Visual Fields Testing
* Digital Retinal Scanning
Show All
## Find an Optometrist in Mount Ommaney, Queensland for an Eye Health Test
Our Oscar Wylee optometrists provide professional eye tests as well as other services such as prescription updates, eye care advice, and referrals to an ophthalmologist if necessary. These comprehensive eye tests include vision testing and the detection of eye diseases and other conditions. In Mount Ommaney, Queensland, the average cost for an eye test by a professional optometrist will be determined by factors such as age, health, and eye care needs. At Oscar Wylee, our eye tests are administered at a bulk billed price under Australia's Medicare system.
Oscar Wylee Mount Ommaney offers a wide range of different frames, including prescription glasses, prescription sunglasses, and non-prescription glasses. Our welcoming retail team, including our optical dispensers, are always available in store to assist you with choosing your frames. Any add-ons you wish to purchase, such as a blue light filter, can be accommodated by our team. If you're looking for exceptional eye care and a seamless shopping experience, visit our store at Mount Ommaney Centre!
## How to Find an Optometrist in Mount Ommaney, Queensland?
Finding an optometrist in Mount Ommaney, Queensland, is easy by taking steps such as searching online, assessing the store's opening hours, and finding directions to your preferred Oscar Wylee location. Below, you will find steps to help you find an optometrist in Mount Ommaney, Queensland.
1. Search the web using the phrase, 'optometrist near me in Mount Ommaney'. This can also be done here on the Oscar Wylee website via our locations page.
2. Click on the Oscar Wylee link, which will take you directly to our Mount Ommaney Centre optometrist store page.
3. Check the store's opening hours and where the store is located.
4. Use the Mount Ommaney Centre Google Business page link located under store hours to see the directions on how to get to the store.
You can also find an optometrist in Mount Ommaney, Queensland by searching the keywords 'optometrist near me'. If you have locations enabled on your smartphone and you're in the Mount Ommaney, Queensland area, our Mount Ommaney Centre store page should appear easily for you to click on.
### Is it Hard to Get an Eye Appointment in Mount Ommaney?
No, it is not hard to get an eye appointment in Mount Ommaney. You can easily book an appointment to see an Oscar Wylee optometrist in the Mount Ommaney Centre, right here on this page. At Oscar Wylee, we have highly qualified optometrists available for bulk billed eye appointments, which can be booked online or in-store.
#### How to Compare Optometrists in Mount Ommaney, Queensland to Each Other?
To compare optometrists in Mount Ommaney, Queensland, you can use factors such as eye tests offered, health fund coverage, lens types, add-ons, and eyewear offered. To take care of your vision and eye health, it is important to receive an eye test at least once every two years. Different types of tests can be performed in an eye test, and not all optometrists may offer the same tests. Health funds can be used to help cover some of the cost of your frames and lenses. To find out if your health fund is accepted at an optometrist in Mount Ommaney, Queensland, visit their website. In the case of Oscar Wylee, we accept all major health funds and provide on-the-spot claims in-store. There are many different lens options available for prescription glasses, such as single-vision, multifocal, and high-index lenses. Most optometrists in Mount Ommaney, Queensland, will offer these lenses, although it is a good idea to make sure. There are also lens add-ons available to enhance your glasses, such as anti-reflective and blue light filters. Finally, if you are looking to purchase a pair of glasses after your eye test, you can compare the different styles and colours you are interested in from the optometrists in Mount Ommaney Centre. Oscar Wylee offers a wide range of frames with vintage and modern inspirations in bold colours and subtle designs.
#### How to Find an Eyeglasses Shop in Mount Ommaney, Queensland?
To find a glasses store in Mount Ommaney, Queensland, you can try following these simple steps, including searching online, selecting a convenient location, and looking at their health insurance policies. The steps on how to find a glasses store in Mount Ommaney, Queensland, are listed below.
1. Search online using the phrase, 'glasses store in Mount Ommaney, Queensland.' This will provide you with various options for glasses stores in the Mount Ommaney, Queensland area.
2. Select a glasses store that is most convenient for you to travel to.
3. Click the link to find out more information, such as opening hours, exact location, and directions to the glasses store in Mount Ommaney.
4. Read their health insurance policies to ensure you know what health benefits you have access to.
Our Oscar Wylee glasses store in Mount Ommaney Centre offers primary eye care services such as comprehensive eye tests, as well as other services performed by an optometrist, and offers prescription and non-prescription eyewear.
##### Is it Possible to Purchase Prescribed Sunglasses in Mount Ommaney Centre Without Seeing an Optometrist?
Yes and no. It is possible to [purchase prescribed sunglasses](https://www.oscarwylee.com.au/sunglasses.html) in Mount Ommaney Centre without seeing an optometrist if you already have a prescription that has not expired. If your prescription has expired, you can book an eye test to receive an updated or new prescription, which will require you to see an optometrist. This will ensure your prescription sunglasses are appropriate for your visual needs.
## Where is the Oscar Wylee Mount Ommaney, Queensland Optometrist Located?
The Oscar Wylee Mount Ommaney Queensland optometrist is located in Mount Ommaney Centre, in the suburb of Mount Ommaney in Queensland.
What is the Phone Number of Oscar Wylee Mount Ommaney Centre Optometrist Store?
The phone number for our Oscar Wylee Mount Ommaney Centre optometrist store is (##) #### ####. Our Oscar Wylee Mount Ommaney Centre store is open, and our staff are available to be contacted.
 
### What are the Reviews for Oscar Wylee Mount Ommaney Optometrist?
The customer reviews for our Oscar Wylee Mount Ommaney optometrist can be found here on our website and online when you search for 'Oscar Wylee Mount Ommaney optometrist.'
#### What Treatments or Eye Care Processes Are Done in the Oscar Wylee Mount Ommaney Centre, Australia Optometrist Location?
The treatments or eye care processes done in the Oscar Wylee Mount Ommaney Centre optometrist location include a tonometry test, a slit lamp exam, a digital photograph, and a refraction test. Additional tests that may also be performed can include a visual field test and a dilated fundus exam. The treatments or eye-care processes that are done in the Oscar Wylee Mount Ommaney optometrist location are listed below.
* A Tonometry Test: An optometrist or optical dispenser will conduct a tonometry test, which involves the use of a machine that will release small puffs of air into your eyes. This will assist with measuring pressure in the eye.
* A Digital Photograph: An optometrist or optical dispenser may take a digital photograph of your eye, which can be kept on record to use in future appointments to evaluate any changes to your eye.
* Slit Lamp Test: A slit lamp test can be used to evaluate your eye health by examining your cornea and iris, which are the anterior and posterior parts of the eye.
* Refraction Test: During a refraction test, an optometrist will have you view an image through different lenses and ask you to confirm which one helps you see the image clearly.
* Visual Field Test: A visual field test can assist with assessing your peripheral vision, which may be beneficial for identifying any signs of glaucoma.
* Dilated Fundus Exam: A dilated fundus exam can help an optometrist assess your health in more detail by getting a clear view of the retina. This test is typically carried out for patients with diabetes and those at risk of developing retinal damage.
## How Many Optometrists Exist in Mount Ommaney, Queensland?
Many optometrists exist in Mount Ommaney, Queensland, and in the Mount Ommaney shopping centre, including Oscar Wylee. The number of optometrists available in an area will typically depend on the population and the eye care needs of those in the area. At Oscar Wylee Mount Ommaney, Queensland, our team is passionate about providing our customers with high-quality, dedicated eye care services. Our optometrists are available to provide bulk billed eye tests, prescription updates, and new frames. If you are looking for an optometrist in Mount Ommaney, Queensland, Oscar Wylee is available to provide all your eye care and eyewear needs.
### What are the Other Closest Optometrist Locations to Mount Ommaney, Queensland, in Australia?
The closest Oscar Wylee optometrist locations to Mount Ommaney Centre are in Indooroopilly, Brisbane - Albert St, and Mt Gravatt. The closest Oscar Wylee optometrist locations to Mount Ommaney, Queensland, are listed below.
* Indooroopilly: Our Oscar Wylee Indooroopilly store is located in the Indooroopilly Shopping Centre. [Oscar Wylee Indooroopilly](https://www.oscarwylee.com.au/locations/optometrist-indooroopilly.html) is located in the suburb of Indooroopilly, where our optometrist can provide Medicare bulk billed eye tests and prescription updates.
* Brisbane - Albert St: Oscar Wylee Brisbane - Albert St is located in the heart of Brisbane City CBD, approximately 16km from Mount Ommaney Centre. Here, you can find an optometrist in our [Oscar Wylee Brisbane - Albert St](https://www.oscarwylee.com.au/locations/optometrist-albert-st.html) team, for eye care services including eye tests and new frames.
* Mt Gravatt: Our Oscar Wylee Mt Gravatt store, located in the Westfield Mt Gravatt Shopping Centre in Upper Mount Gravatt, is approximately 19km away from Mount Ommaney Centre. At [Oscar Wylee Mt Gravatt](https://www.oscarwylee.com.au/locations/optometrist-mt-gravatt.html), you can find an Oscar Wylee optometrist who can provide Medicare bulk billed eye tests, and our retail staff can help you shop for new frames from our stylish collection.
### Stylish Glasses in Mount Ommaney
At Oscar Wylee Mount Ommaney, you are able to choose from a wide range of both prescription eyeglasses and sunglasses in an assortment of different styles, from modern to more vintage-inspired eyewear. Extra offerings are available, such as anti-reflective coating, blue light filters, and polarised lens add-ons to honour your unique eye care needs. Our helpful team, including both optometrists and optical assistants, will take care of you to ensure you leave with the perfect pair of frames for you!
### Mount Ommaney Queensland Bulk Billed Eye Examinations
Our professionally trained optometrists are able to provide new prescriptions or update your existing script, so you can leave with a fresh pair of stylish glasses made just for you. Our Oscar Wylee optometrists work in-house and will usually be able to assist you within 30 minutes. During your eye test, they will assess your vision, check your eye health, and assess for signs of eye conditions and refer you where appropriate. It is recommended to receive an eye test at least once every two years, and Oscar Wylee Mount Ommaney is your one-stop shop to keep your eye health in check.
### Health Funds Accepted at Oscar Wylee
Oscar Wylee Mount Ommaney accepts all major health funds, including Bupa, Medibank, and HCF. Our friendly team is trained to process your claim in-store with your valid health fund card and answer any questions you have about your claim. Remember to bring your health fund card to your next appointment at Oscar Wylee Mount Ommaney to claim on your eyewear and optometry needs.
Book Appointment
[Call us: (07) 2111 2605](tel:(07) 2111 2605)
[Leave a Review!](https://g.page/r/CQRYjmSiuUC5EBM/review)