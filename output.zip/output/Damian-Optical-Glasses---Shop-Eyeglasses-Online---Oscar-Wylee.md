# Source: https://www.oscarwylee.com.au/damian-optical.html

# Damian
1
## Frame Design of Damian Glasses
The frame design of Oscar Wylee’s Damian glasses is characterised by their rectangle shape, high nose bridge, TR90 frame, and lightweight feel. Damian is a wearable men’s glasses frame that you can rely on, day to night.
$169    
In stock
Only %1 left
2 pairs from $199
Discount auto-applied at checkout
3 pairs from $249
Discount auto-applied at checkout
Qty
Add to cart
Book an eye test
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
excluding prescription lenses
## About Damian Frames
The two toned charm of Damian is perfect for those on the go. The small vents above each rim means Damian is less prone to fogging for optimal convenience. Made from TR90, its lightweight frame is the ideal companion for an active day.
| Frame fit | Measurements |
| --- | --- |
| WIDE | 54 - 18 - 140 |
These measurements mean lens width, bridge, and temple length in millimetres (mm). They can be found on the inside of the temple arm. If you already have a pair that you like, you can compare it to these measurements.
### Made from TR90
Oscar Wylee's Damian frame is a men's rectangle glasses frame that is perfect for those with round and oval face shapes. The Damian frame is a sleek, versatile frame that can be worn every day. The main specs of Oscar Wylee's Damian glasses frame, including dimensions, shape, materials, lenses, nose fit and hinges are listed below.
| Damian Frame Features | Damian Frame Description | Dimensions | Shape | Materials | Lenses | Nose Fit | Hinges |
| --- | --- | --- | --- | --- | --- | --- | --- |
| The dimensions of the Damian frame are measured in millimetres (mm) and are 54 - 18 - 140, meaning the lens width is 54 mm, the bridge is 18 mm, and the temple length is 140 mm. |
| Damian is a rectangle shape, well-suited to wide faces. |
| Damian is made from TR90 with rubber temple tips. |
| The lenses that can be used in the Damian frame include optical lenses, such as single-vision and multifocal, and non-prescription lenses, which are plain and can have a filter, such as a blue-light filter applied. |
| The nose fit for Damian is a high nose bridge fit. |
| The hinges in Damian are normal hinges, also known as standard or barrel hinges. |
Show All
### What Inspired the Frame Design of Oscar Wylee's Damian Glasses?
The Oscar Wylee Damian frame design was inspired by current fashion trends, as rectangle shapes are often in fashion. A rectangle glasses shape is timeless; it remains popular throughout the decades while other trends come and go.
## What to Know About Oscar Wylee's Damian Glasses?
There are many aspects of the Oscar Wylee Damian frames that customers should know about to decide whether this is the right frame for them. The Damian frame is a men's rectangle-shaped frame. Oscar Wylee's Damian frame is suitable for many face shapes, but particularly compatible with round and oval face shapes. The Damian frame's simple design makes them fashionable all year round. Damian features the standard [parts of glasses](https://www.oscarwylee.com.au/glasses/eye/part-of-glasses), such as a rim, temples, lenses, hinges, and a high nose bridge fit.
### What are the Types of Temple Tips or Earpieces Included with Oscar Wylee's Damian Glasses?
The type of temple tips or earpieces included in Oscar Wylee's Damian Glasses are made from rubber.
### What Type of Nose Bridge do Oscar Wylee's Damian Glasses Have?
The type of nose bridge included in Oscar Wylee's Damian frame is a high nose bridge fit.
### What Type of Nose Pads are Included with Oscar Wylee's Damian Glasses?
Oscar Wylee's Damian frame does not include adjustable silicone nose pads.
### What Type of Lenses do Oscar Wylee's Damian Glasses Have?
The type of lenses that typically come with the Oscar Wylee Damian [glasses frame](https://www.oscarwylee.com.au/glasses.html) are optical lenses. Optical lenses are glasses lenses that have a prescription within the lens to help correct vision issues such as myopia, hyperopia, and astigmatism. Damian can also come with non-prescription lenses, with add-ons such as a blue light filter. Damian frames can be customised into sunglasses in-store or online with add-on tints or polarisation.
### What Material is Used for the Rim of Oscar Wylee's Damian Glasses?
The material used for the rim of Oscar Wylee's Damian glasses frames is TR90. The rim refers to the part of a glasses frame that holds the lenses.
### What Type of Hinges are Included with Oscar Wylee's Damian Glasses?
The type of hinges included with Oscar Wylee's Damian frames are normal hinges. These provide strength and smooth movement connecting the frame's arms and lenses.
## What Face Types are Most Suitable for Oscar Wylee's Damian Glasses?
The face types that are most suitable for Oscar Wylee's Damian frame are round and oval face types. The Damian frame is a rectangle shape, meaning that it complements the structure of round and oval faces particularly well. The rectangle Damian frames help balance the features of a [round face shape](https://www.oscarwylee.com.au/glasses/face-shapes/round) and an [oval face shape](https://www.oscarwylee.com.au/glasses/face-shapes/oval), bringing the eyes and brows forward in a flattering way. Although there are many [glasses for face shapes](https://www.oscarwylee.com.au/glasses/face-shapes) that may be considered more aesthetically suitable, it is important that people also choose frames that make them feel most comfortable and represent their personal style.
## What Size Options are Available for Oscar Wylee's Damian Glasses?
The size options available for Oscar Wylee's Damian frame are a wide-fit frame across all colours.
## What Materials are Used to Create Oscar Wylee's Damian Glasses?
The primary material used to create the Oscar Wylee Damian frame is TR90. TR90 is a form of thermoplastic material, perfect for making flexible, durable, and lightweight glasses.
## What’s Included
## OW Case &amp; Cloth
Protective Case and Lens Cloth
Our high-quality glasses case and lens cloth are included with every purchase of an Oscar Wylee frame. The stylish, magnetic case is made from a hard shell. This sturdy and durable material keeps your glasses protected and safe, wherever you go. Ensure your lenses are clean and scratch-free with our OW microfibre cloth, specifically designed to ensure you have comfortable vision through your lenses.
Oscar Wylee offers:
* Free Shipping for Australian Orders
* 1 Year Warranty on frames and lenses
* Scratch resistance lens coating on all prescriptions
* UV-proof coating on all prescriptions
Health fund rebate: Once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. Learn more about [health funds](https://www.oscarwylee.com.au/health-funds.html).
## Make and Materials
Our TR90 glasses are for the adventurers! TR90 is a thermoplastic material renowned for its lightweight nature, durability and comfort. TR90 is produced through Swiss technology that allows it to be incredibly strong and tough to impact, perfect for the active wearer.The frames go through cleaning and strict quality control.After your frames have gone through the production process, they are individually examined and packed before making their way to you!
## Warranty Information
### Warranty Information
### Warranty Information
Oscar Wylee provides a 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects. We will repair or replace faulty or defective frames or lenses free of charge for warranty claims made within 1 year of the delivery. We also offer repairs or replacement for problems experienced with vision during everyday use for claims made within 30 days of delivery. If the same product has been discontinued or is no longer available, then we may offer an exchange for a similar product or a refund.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Find a Store Location](https://www.oscarwylee.com.au/locations/full-store-list.html)