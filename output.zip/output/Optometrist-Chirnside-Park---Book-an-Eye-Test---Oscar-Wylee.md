# Source: https://www.oscarwylee.com.au/locations/optometrist-chirnside-park.html

# Optometrist Chirnside Park
Chirnside Park Shopping CentreGround Level, Shop 626A239-241 Maroondah HwyChirnside Park VIC 3116
* Near Specsavers
Opening hours
Monday9:00am - 5:30pm
Tuesday9:00am - 5:30pm
Wednesday9:00am - 5:30pm
Thursday9:00am - 7:00pm
Friday9:00am - 7:00pm
Saturday9:00am - 5:00pm
Sunday10:00am - 5:00pm
*Store hours reflect local standard trading hours and exclude public holidays
[Visit our Chirnside Park Google Business page for directions, reviews, and updates.](https://g.page/r/CYo84HRjWF0wEBM)
Book Appointment
[Call us: (03) 9727 5344](tel:(03) 9727 5344)
[Leave a Review!](https://g.page/r/CYo84HRjWF0wEBM/review)
Our Reviews
Jess K
4 days ago
Staff are really kind and caring, always try to do their best for you, and are really welcoming
Dawn Ashdown
6 days ago
The service was excellent and good value for what I got. Very happy
Leanne Cheetham
1 week ago
Very professional and great service
David Baldwin
2 weeks ago
First time using Oscar Wylee i was impressed as the eye test was very thorough compared to what I ha...d done in a previous test with with another optometrist , the staff were friendly and helpful with the decision on what products I ended up ordering ????.
See more
Joanne
2 weeks ago
The optometrist was amazing.  He was thorough, explained everything and took his time.  Customer ser...vice was great. They were friendly and helpful
See more
June Spence
2 weeks ago
Friendly and knowledgeable
Elaine Norton
2 weeks ago
Friendly, Welcoming , Professional
Louise
3 weeks ago
Test was old school, a bit ‘this is the space we have, sorry’. Optometrist was professional and pers...onable. I left a message on the listed phone number asking for a call back regarding contact lenses note: they didn’t call me back and I used my annual Medicare eye check and they DONT DO CONTACT LENSES ????
See more
maddi (Mads)
3 weeks ago
I came in recently after being referred to an optometrist for frequent headaches and my mum recommen...ding Oscar Wylee based on past experience- but I can truely say the “great service” she described was an understatement, the team at Chirnside park were just AMAZING. They took the time to listen to me and better understand my history &amp; what I was going through before starting, explained everything to me as we went and made the eye testing process quick + simple. The optometrist was not only knowledgeable &amp; efficient but she was also actually kind &amp; empathetic, upon confirming minor vision focus &amp; light sensitivity issues to correct with glasses she was still concerned about the now ‘unrelated’ headaches I was referred for and advocated for me to see a neurologist in response to my gp! Additionally the reception staff were also amazing at answering any questions I had &amp; explained everything about the ordering process for my new glasses- even helping me decide which frames suited me best while I tried on half the store! I highly recommend the Chirnside store to anyone needing an optometrist, and I highly recommend management to acknowledge the incredible team they have here &amp; give these guys the praise they truely do deserve!! ❤️
See more
Tennille Goulding
4 weeks ago
Staff were lovely, maybe not enough staff at times gor the amount of customers but its a small store... and they are trying g their best. Optomitrist was lovely, knowledgeable and informative. Definitely recommend.
See more
Gundula Jurgen
4 weeks ago
Fantastic service. Great sales staff and optometrist.
Andrew McBain
1 month ago
My experience was fantastic yesterday. I would certainly recommend Oscar Wylee to anyone wanting the...ir eyes tested or wanting to purchase your next pair of glasses.
See more
De Blanche
1 month ago
I always have a great experience with this company. Polite, friendly and professional.
If your think...ing about glasses or any eye needs consider Oscar Wylee.
See more
Debbi Weaver
1 month ago
The young man on reception was incredibly helpful and friendly
Warren Millar
1 month ago
Was nervous until sat and spoke to the Optomertrist. Was at ease the test was thorough and each step... was explained. A great experience and would recommend Oscar Wylee to anyone
See more
Melinda McVay
1 month ago
Friendly and attentive staff who were very pleasant and customer focused making the experience easy.
Claudia Carlyon
2 months ago
Thank you so much to the lovely staff member who helped me with organising a new frame to replace th...e one that I had broken - really saved a dilema. It was fixed in no time at all. Really appreciated the quick and friendly turn around.
See more
María Elena Ruíz Díaz Alegre
2 months ago
Russell Coffey
2 months ago
Ian Francis
2 months ago
Assessment was really good and the referral to for my cataract assessment was arranged quickly. High...ly recommend them for anyone looking for a better quality service
See more
Tien Nguyen
2 months ago
The optometrists here are very knowledgeable and experienced. They help me to heal my eye problems a...nd find the best prescription glasses for distance and reading. Moreover, the receptionists are very friendly and helpful.
See more
tayla hinton
2 months ago
Amazing staff always make u feel comfortable and relaxed when getting ur test done and picking out n...ew glasses
See more
rorie russell
2 months ago
My husband Frederick  and I had our eyes  examined few days ago. Ourv eye examinations were thorough...ly  done.  Optometrist was very helpful and explained the conditions and current stage of my eye condition as well as my husband's.  The Optometrist helped us also in the choice of public/private care . I was impressed by his professionalism and concerns.
Staff assisted in my choice of eye glass frames were  friendly and helpful. I'm satisfied.
Highly recommended  ????
See more
Amy Kumar
2 months ago
The optometrist was very thorough and informative.
I have always had a positive experience at the ch...irnside store with friendly and helpful staff
See more
Adam Neeves
2 months ago
Came in for a set of gogs because I'm blind as a welder's dog. Rikarla helped me and was just outsta...nding, providing clear and helpful advice and absolutely stellar follow ups. Whatever they're paying her isn't enough.
See more
Smita Sebastian
2 months ago
Eye test - Very good experience. No push selling.
Irene Patricia Borg
3 months ago
OPTOMOTRIST AND STAFF WER VERY CLEAR WITH EXPLAINING DETAILS
Heather Hyland
3 months ago
Brenda Rinnovasi
3 months ago
The guy was very helpful to me with helping me pick glasses. The eyes test the man he expanded every... step along the way . In all I had great experience there
See more
Melissa Town
3 months ago
I was so impressed with my experience at Oscar Wylee Chirnside Park yesterday.  The staff there were... thoroughly professional and friendly. I had  was reassured about the health of my eyes and made to feel valued.
See more
Gary Taylor
3 months ago
Hannah Weymes
3 months ago
Kathy Degroot
3 months ago
I was super impressed with the service I received. Staff were awesome, helpful and very informative .... Optometrist was fantastic, explaining everything. I didn't have to wait around like a lot of other places. Would highly recommend the team at Chirnside Park.
See more
Erwin Sperl
3 months ago
Amazing staff and service can’t wait to get my new frames
Philip Gardner
4 months ago
Oscar wylee were fantastic.  The optician discovered a problem within my eye and immediately referre...d me to the eye hospital in Melbourne. Four hour and some laser surgery later I’m all sorted.
See more
Kerryn Haeusler
4 months ago
A very thorough and detailed eye examination with lots of feedback and easy instructions was provide...d and the frame selection was super easy. Pricing was transparent and the guys were very patient with me when a banking glitch delayed payment. Very happy with the service and the product.
See more
Racheal Adrianna GS
5 months ago
Friendly helpful happy staff on arrival.
After 6 years at Specsavers and 4yrs at OPSM, I have to say... this is one of the best optometrist I’ve ever been to.
Highly recommended as the service is great also affordable and everything explained well about my vision and most of all the time that was spent helping me.
A beautiful range of glasses.
Thanks Again to the lovely girls at service desk and the great Optometrist. ????
See more
Jeff Hazzledine
5 months ago
Always very helpful and friendly
Joan Anderson
5 months ago
Very pleased with my eye test. Staff were very pleasant &amp; informative.
Agata Iannarella
5 months ago
Very professional. Eye professional was friendly, thorough and knowledgeable, explaining all the ste...ps and results during the examination.
The front staff were so friendly and helpful with choosing the eye wear.  Highly recommend
See more
Sarah Hamilton
6 months ago
Brilliant experience. The Optometrist I saw was the best I’ve ever seen. Explained everything so wel...l, including pros and cons of different lens styles in reference to my every day use of the glasses. The lady who helped me choose the actual frame was amazing. She was so helpful and honest about what suited my face and what didn’t. I really appreciated that.
See more
Brydie Manifold
6 months ago
took both my daughters to get a check up at oscar's wylee, our optometrist was very good, he made su...re to do
all the appropriate tests on the girls eyes and wasn't pushy at all with if they needed glasses or not as one of my daughters site was just not good enough and he didn't push us to get glasses left it up to my daughters decision. highly recommend oscar wylee chirnside park.
See more
Gurnoor Sethi
6 months ago
Friendly staff and doctor inside reallly helpfull.
Jarray Moo
6 months ago
Mairin Mains
7 months ago
Quick, efficient and organised.
gerry mc swiggan
7 months ago
Very professional and friendly staff. Would highly recommend them to anyone. Great service and the o...ptometrist was very thorough.
See more
Peter Brad
7 months ago
I have to say I loved the service at this store. Apologies to the optometrist who's name I've forgot...ten however he was excellent in providing the correct eye glass prescription for me and advising on my eye health. I was also surprised by the prices and expected to pay far more for the three pair purchase I made. The young lady who provided assistance with the frames etc was so professional and lovely in her service. I've  been to a few different optometrists over the years and found this store and staff to be the best experience so far. Many thanks to them.
See more
jmcnamara14
7 months ago
Alan and Beth were very good with their help and testing on my visit .
JabFlyer
7 months ago
Excellent yecare and customer service! Thank you Beth and Alicia
Jaimie Winand
7 months ago
Such an easy and friendly experience with the Chirnside team, optometrist is lovely and explains thi...ngs well, very comfortable experience and the ladies in the front are supper friendly and helpful , making picking frames incredibly easy! Thanks Chirnside team! ☺️☺️
See more
## Find an Optometrist in Chirnside Park With Oscar Wylee
Discover our Oscar Wylee store located opposite Michael Hill Jewelers and next to Platypus at Chirnside Park Shopping Centre. Our Oscar Wylee Chirnside Park optometrist can be found in-store, ready to offer you a Medicare bulk billed eye test. Our friendly optical dispensing staff are there to help you select your new pair of glasses and assist with any inquiries. Chirnside Park Shopping Centre offers over 2000 parking spaces and there is a bus stop located right outside the centre. 
Chirnside Park Shopping Centre has been servicing locals since 1979 and has recently undergone various upgrades including repaints and new food court options. The centre offers late-night shopping on Thursday and Friday nights so you can take care of your optical needs, weekly groceries and much more. The centre also offers a range of activities to young children to keep them entertained whilst parents do their shopping. Come in and see us at our Oscar Wylee store today, and experience some of the best optometry services in Chirnside Park, Australia!        
Meet Our Team
* Optometrist
B.Biomed (Hons)
Doctor of Optometry
* Store Manager
Our Services
* Bulk Billed Eye Examinations
* Professional Frame Styling
* Frame Adjustments and Repairs
Show All
## Find an Optometrist in Chirnside Park, Melbourne for an Eye Health Test
Visit an optometrist in Chirnside Park, Melbourne, if you need eye care services including an eye health test or a prescription for glasses. The Oscar Wylee Chirnside Park store offers eye care and eyewear services for a bulk billed price, thanks to Australia’s Medicare system. If you need a new pair of glasses or prescription sunglasses, you can choose from our wide range of on-trend and vintage-inspired frames.
The average price range for an optometrist in Chirnside Park can vary depending on factors such as the patient’s overall health and visual needs. Eye tests in Oscar Wylee Chirnside Park, Melbourne, will assess a patient’s vision as well as check for signs of eye disease. If a patient requires more advanced treatment, they will be referred to an eye doctor, known as an ophthalmologist in Australia. For an eye health test, choose Oscar Wylee Chirnside Park in Melbourne as we have dedicated optometrists and optical dispensers in-store to help with all your eye care needs.
## How to Find an Optometrist in Chirnside Park, Melbourne?
To find an optometrist in Chirnside Park, Melbourne, you can take certain steps that can help make it easier for you such as searching online, assessing the store’s opening hours and finding the directions to your chosen location. The steps on how to find an optometrist in Chirnside Park are listed below.
1. Search online using the phrase, Chirnside Park optometrist near me. This can also be done here on the website via our locations page.
2. Click on the Oscar Wylee link, which will take you directly to our Chirnside Park optometrist store page.
3. See the store’s opening hours and where the store is located specifically.
4. Use the Chirnside Park Google Business page link located under store hours to see the directions on how to get to the store.
You can also find an optometrist in Chirnside Park, Melbourne by searching the keywords optometrist near me. If you have locations enabled on your smartphone and you’re in the Chirnside Park area, our Oscar Wylee Chirnside Park store page should appear easily for you to click on.
### Is it Hard to Get an Eye Appointment in Chirnside Park, Melbourne?
No, it is not hard to get an eye appointment in Chirnside Park. You can easily book an appointment to see an Oscar Wylee optometrist in Chirnside Park right here on this page. At Oscar Wylee we have highly qualified optometrists available for bulk billed eye appointments, which can be booked online, over the phone, or in-store.
#### How to Compare Optometrists in Chirnside Park to Each Other?
To compare optometrists in Chirnside Park, you can use factors such as eye tests offered, health fund coverage, lens types and add-ons and eyewear offered. To take care of your vision and eye health, it is important to receive an eye test at least once every two years. There are different types of tests that can be performed in an eye test and not all optometrists may offer the same tests. Health funds can be used to help cover some of the cost of your frames and lenses. To find out if your health fund is accepted at a Chirnside Park optometrist in Melbourne, visit their website. In the case of Oscar Wylee, we accept all major health funds and provide on-the-spot claims in-store. There are many different lens options available for prescription glasses such as single vision, multifocal and high index lenses. Most optometrists in Chirnside Park will offer these lenses although it is good to make sure. There are also lens add-ons available to enhance your glasses such as anti-reflective and blue light filters. Finally, if you are looking to purchase a pair of glasses after your eye test, you can compare the different styles and colours you are interested in from the optometrists in Chirnside Park, Melbourne. Oscar Wylee offers a wide range of frames with vintage and modern inspirations in bold colours and subtle designs.
#### How to Find an Eyeglasses Shop in Chirnside Park, Melbourne?
To find a glasses store in Chirnside Park, you can try to follow these simple steps including searching online, selecting a convenient location and looking at their health insurance policies. The steps on how to find a glasses store in Chirnside Park, Melbourne are listed below.
1. Search online using the phrase, glasses store in Chirnside Park. This will provide you with various options for glasses stores in the whole Chirnside Park, Melbourne area.
2. Select a glasses store that is most convenient for you to travel to.
3. Click the link to find out more information such as opening hours, exact location and directions to the glasses store in Chirnside Park.
4. Read their health insurance policies to ensure you know what health benefits you can access.
Our Oscar Wylee glasses store in Chirnside Park, Melbourne offers primary eye care services such as comprehensive eye tests as well as other services performed by an optometrist and offers prescription and non-prescription eyewear.
##### Is it Possible to Purchase Prescribed Sunglasses in Chirnside Park, Melbourne, Without Seeing an Optometrist?
Yes and no, it is possible to [purchase prescribed sunglasses](https://www.oscarwylee.com.au/sunglasses.html) in Chirnside Park, Melbourne without seeing an optometrist if you already have a prescription that has not expired. If your prescription is expired, you can book an eye test to receive an updated or new prescription which will require you to see an optometrist. This will ensure your prescription sunglasses are appropriate for your visual needs.
## Where is the Oscar Wylee Chirnside Park Optometrist Located in Melbourne?
The Oscar Wylee Chirnside Park optometrist is located in the Chirnside Park Shopping Centre, near Specsavers. Chirnside Park is a suburb located in Victoria’s capital, Melbourne and is within the Shire of Yarra Ranges local government.
### What is the Phone Number of Oscar Wylee Chirnside Park Optometrist Store?
The Oscar Wylee Chirnside Park optometrist store phone number is (03) 9727 5344. You can contact the Oscar Wylee Chirnside Park store between the hours of 9 am and 5:30 pm from Monday to Wednesday, 9 am and 9 pm on Thursdays and Fridays, 9 am and 5 pm on Saturdays and 10 am and 5 pm on Sundays.
### What are the Reviews for Oscar Wylee Chirnside Park Optometrist in Melbourne?
The many reviews for Oscar Wylee Chirnside Park optometrist in Melbourne, left by our various customers can be found here on the website and online when you search for Oscar Wylee Chirnside Park optometrist. The reviews for Oscar Wylee Chirnside Park optometrist are listed below.
* Maggie Purlpe:  Very helpful and professional. Thank you.
* Sharon Bryant:  Nicole and Alan were amazing and very helpful and friendly. We chose our glasses and are very happy with our purchase. Would definitely recommend giving Nicole and Alan a visit.
* Shole 0o0o:  Nice place to get your eyes checked. All the staff were professional and responsive.
* Wendy Pienaar: I was given excellent and timely service, treated with respect and I will definitely be a returning customer. Highly recommend them for their professionalism.
#### What Treatments or Eye Care Processes are Done in the Oscar Wylee Chirnside Park Optometrist Location?
The treatments or eye care processes done in the Oscar Wylee Chirnside Park optometrist Melbourne location include a tonometry test, a slit lamp exam and a refraction test. Additional tests that may also be performed can include a dilated fundus exam. The treatments or eye-care processes that are done in the Oscar Wylee Chirnside Park optometrist Melbourne location are listed below.
* A Tonometry Test: An optometrist or optical dispenser will conduct a tonometry test which involves the use of a machine that will release small puffs of air into your eyes. This will assist with measuring pressure in the eye.
A Digital Photograph: An optometrist or optical dispenser
may take a digital photograph of your eye which can be kept on
record to use in future appointments to evaluate any changes to
your eye.

* Slit Lamp Test: A slit lamp test can be used to evaluate your eye health, by examining your cornea and iris which are the anterior and posterior of the eye.
* Refraction Test: During a refraction test, an optometrist will have you view an image through different lenses and ask you to confirm which helps you see the image clearer.
Visual Field Test: A visual field test can assist with
assessing your peripheral vision, which may be beneficial for
identifying any signs of glaucoma.

* Dilated Fundus Exam: A dilated fundus exam can help an optometrist assess your health in more detail by getting a clear view of the retina. This test is typically carried out for patients with diabetes and those who may be at risk of developing retinal damage.
## How Many Optometrists Exist in Chirnside Park, Melbourne?
There are many optometrists that exist in Chirnside Park, Melbourne to provide eye tests and glasses, including Oscar Wylee. The number of optometrists available in an area will typically depend on the population. At Oscar Wylee Chirnside Park, we offer excellent optometry services including eye tests performed by skilled optometrists using high-quality equipment. We also have a wide range of fashion-forward frames that customers can browse in a large selection of sizes and colours. If you’re looking for an optometrist in Chirnside Park, choose Oscar Wylee and we will take care of your optometry and eyewear needs.
### What are the Other Closest Optometrist Locations to Chirnside Park, Melbourne in Australia?
The other closest Oscar Wylee optometrist locations to Chirnside Park in Australia are Knox, Forest Hill and Doncaster. The locations and their distance from Chirnside Park are listed below.
* Knox:  Knox is close to Chirnside Park, around 16 km. The [Oscar Wylee Knox](https://www.oscarwylee.com.au/locations/optometrist-knox.html) store is located in Westfield Knox Shopping Centre, opposite Specsavers. At Oscar Wylee Knox, you can experience excellent eye care and eyewear services.
* Forest Hill:  Forest Hill is close to Chirnside Park, around 18-19 km. The [Oscar Wylee Forest Hill](https://www.oscarwylee.com.au/locations/optometrist-forest-hill.html) store is located in the Forest Hill Chase Shopping Centre, near Woolworths. You can visit Oscar Wylee Forest Hill for professional optometry services.
* Doncaster:  Doncaster is close to Chirnside Park, around 20 km. The [Oscar Wylee Doncaster](https://www.oscarwylee.com.au/locations/optometrist-doncaster.html) store is located in Westfield Doncaster, near Apple. Our optometrist in Oscar Wylee Doncaster offers bulk billed eye tests for eligible Medicare cardholders which may include visual field testing.
### Oscar Wylee Eye Tests, Bulk Billed
Oscar Wylee Chirnside Park offers eye tests and vision assessment from a trained eye care professional at our eyeglasses shop. We bulk bill our eye health tests, so there are no out-of-pocket costs if you have a valid Medicare card. Non-medicare cardholders have to pay a small fee. Get your eyesight tested, your eye health checked for certain eye diseases, and find your new glasses, all on the same day.
### Health Funds Accepted at Chirnside Park
Oscar Wylee Chirnside Park staff are available in-store to process your claim for new prescription eyeglasses and prescription sunglasses. Our experts can also provide on-the-spot quotes for frames and lenses. Visit Oscar Wylee Chirnside Park today where our friendly staff can help you with your health fund and eligibility so you can get the best price for your eyewear.
### Expert Advice in Oscar Wylee Chirnside Park
Our friendly staff at Oscar Wylee Chirnside Park will help you find the perfect pair of eyeglasses or sunglasses to suit your prescription and style needs. Visit the team in-store to get fitted for frames, choose from our different lens options, and even select from our different lens coatings to customise and optimise your new pair of glasses. This means you can add a blue light filter or choose multifocal lenses to help you see comfortably at three different distances.
Book Appointment
[Call us: (03) 9727 5344](tel:(03) 9727 5344)
[Leave a Review!](https://g.page/r/CYo84HRjWF0wEBM/review)