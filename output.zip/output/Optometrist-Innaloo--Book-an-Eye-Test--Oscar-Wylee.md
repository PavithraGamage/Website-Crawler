# Source: https://www.oscarwylee.com.au/locations/optometrist-innaloo.html

# Optometrist Innaloo
Westfield InnalooShop 1-1067/8Ellen Stirling BlvdInnaloo WA 6018
* Opposite Woolworths
Opening hours
Monday9:00am - 5:30pm
Tuesday9:00am - 5:30pm
Wednesday9:00am - 5:30pm
Thursday9:00am - 8:00pm
Friday9:00am - 5:30pm
Saturday9:00am - 5:00pm
Sunday11:00am - 5:00pm
*Store hours reflect local standard trading hours and exclude public holidays
Monday9:00am - 5:30pm
Tuesday8:00am - 5:30pm
Wednesday9:00am - 5:30pm
Thursday9:00am - 7:00pm
Friday8:00am - 5:30pm
Saturday8:00am - 5:00pm
Sunday10:00am - 4:00pm
*Store hours reflect local standard trading hours and exclude public
holidays

[Visit our Innaloo Google Business page for directions, reviews, and updates.](https://g.page/r/CWRC6Q2MU3WkEBM)
Book Appointment
[Call us: 08 6186 2337](tel:08 6186 2337)
[Leave a Review!](https://g.page/r/CWRC6Q2MU3WkEBM/review)
Our Reviews
Lauren Connolly
2 weeks ago
Great experience, thanks Renae for making my visit really wonderful.
Kristy Webb
2 weeks ago
Very good service, nice people who know what they are doing. Thankyou
Tash Goodyer
3 weeks ago
Optometrist was lovely, and very professional. Would recommend to anyone considering going here.
Phub Zam
4 weeks ago
The lady at the reception was so calm welcoming and overall very helpful. She happily and calmly ans...wered to all my questions with full enthusiasm. And same with the girl who did my eye test. Thank u both ❤️ sorry I forgot both ur name????
See more
Beverly Pritchard
1 month ago
Excellent customer service from the team and optometrist. Their friendly advice and professionalism ...made my eye test and selection of new glass frames a pleasure. They provide high quality products and cost affordable in comparison to the competition. Thoroughly recommend their services. Bev Pritchard Stirling WA
See more
Ian Pickens
1 month ago
Accepted multiple appointment changes
Good range of frames to choose from
Anna Herd
1 month ago
Good experience
Geoff
1 month ago
Renee was very  nice and the  optometric was young  but I felt  very knowledgeable
I was very well l...ooked after
I was very sorry though that I might have been miss understood when after 1hour I pointed that.i needed to be somewhere else ,.I was not grizzling  I just wanted to explain my wife's and myself urgency to leave. I am. Very sorry if I offended anyone. They are all lovely staff
Please forgive me if I  upset  anyone thanks Geoff Riseley
,I HAVE received an email today to say my glasses are ready to pic really impressed by the speedy service. I am used to waiting  a long time for my glasses
.altogether a great result for me l am really  impressed. And can't wait to collect tomorrow, Geoffrey RISELEY AND ANNA HERD.
See more
Christine
1 month ago
Friendly, patient and helpful.  Couldn’t be more happier with my experience from beginning to end. G...reat quality glasses and design.
See more
jane porter
1 month ago
Very helpful staff
Efrona Ketema
1 month ago
Star Laska
1 month ago
Very thorough and patient optician who helped find glasses to fit comfortably and suit my face.
Evyonne Hale
2 months ago
L K
2 months ago
Fantastic service from Renae. Super friendly and helpful, would definitely recommend this store, and... will definitely be back again. Thanks Renae! :)
See more
Belinda Werder
2 months ago
Plenty of available appointments and friendly staff. Frames had a good range, and I feel well looked... after. I ordered 2 new pairs and can't wait for them to arrive!
See more
Julie Farrell
3 months ago
Friendly and professional
Jade Holt
3 months ago
Renee was amazing at helping me choose my frames - what a legend
Beverly Swan
3 months ago
Teeqz
4 months ago
Excellent service
Jigme Thinley
4 months ago
Grace Scott
4 months ago
helen mclean
5 months ago
Very helpful. Great experience. thank you.
Jonathan David Corner
6 months ago
1st time customers of O/W; what a pleasant experience; entering the store we approached Laura (the S...tore Manager) for help and advice.
Laura took the time to explain what we were entitled to on our Health Insurance, costed everything up, showed us where we could look for new frames, discussed lens requirements,  measured us up and clinched the deal.
What was commendable was how approachable and knowledgeable Laura was. Nothing was too much trouble for her. She went out of her way to make sure we were comfortable.
On leaving the store, I personally thanked Laura, commending her for her professionalism, knowledge and friendliness.
We can highly recommend Laura and the Innaloo O/W store.
See more
Marlene Bürkle
6 months ago
My husband and I were looking for sunglasses yesterday. Hazel was super friendly and helped find the... right pair for him.
See more
Ken Wan
6 months ago
I recently visited the Oscar Wylee store in Innaloo for an eye test and had an excellent experience.... My optometrist, Selina, was both highly professional and very friendly. She took the time to listen carefully to my eye health history, including past issues with retinal detachment and cataracts, and provided thorough, attentive care.
The store staff were also very helpful and friendly in assisting me with selecting glasses, making the entire process smooth and enjoyable.
See more
Itsaso Andrade
7 months ago
Really nice and professional!
Thuktan Lhamo
7 months ago
Costumer service was excellent, friendly
marc de padova
7 months ago
A very easy informative and pleasant experience.
Staff were marvelous, friendly, professional and kn...owledgeable..
Oscar Wylee innaloo .... works like clockwork
WILL BE BACK!
See more
Mahnaz Bahrami
7 months ago
Optometrist was very knowledgeable and helpful. highly recommend.
Anne Patterson
7 months ago
I cannot fault any of the staff here. From the eye test, to choosing the frames, then picking up the... glasses and getting the frames adjusted, and later getting the frames adjusted again, everyone I have dealt with has been patient and helpful. Even when it was almost closing time the staff member took the time to adjust the frames so that they sat properly.
See more
Vesna Golik
7 months ago
John Robbins
8 months ago
Great service friendly and professional
Jeffrey Dcruz
8 months ago
Great the optometrist who saw me was very helpful. She explained everything  in detail.
Colin Jones
8 months ago
Jill Lonsdale
8 months ago
I found the service and care were excellent and I felt listen to with my watery eyes. Thankyou so mu...ch
See more
Ben Fletcher
8 months ago
Very thorough and excellent service. Best I have had. Will be a repeat customer.
Tracey Nelli
9 months ago
Toni Van Rullen
9 months ago
Laura was extremely helpful and efficient,  helping me to choose frames.
Patty Hall
9 months ago
Great optometrist I have ocular toxoplasmosis did eye pressure check and eye test. Lovely to deal wi...th will be a repeat customer.
See more
Zoe Coates
9 months ago
The Innaloo Oscar Wylee store was such a refreshing experience. I was helped by 4 different staff me...mbers across my visits and each person made me feel welcomed, and genuinely cared for. I highly recommend visiting the Innaloo team to help you with your next eyewear purchase. Big shout out to Laura also, you were so helpful and warm!
See more
James Kwik
9 months ago
Very welcoming staff. Everything was explained in detail by the Optometrist that attended to me.
Lilach Melville
9 months ago
A surprisingly pleasant optometrist experience, and I have already recommended it to my friends: The... shop assistants were lovely and very professional, even though I am not the easiest person to eye-test as I blink during the intraocular pressure (IOP) test. The lady was patient and supportive throughout and it was the first time ever the did not to give up on this test and to actually obtain a result.
The optometrist was excellent and had a sense of humour that made the experience much more pleasant. I selected two beautiful frames and am now waiting to receive them.
See more
Sal Casa
9 months ago
My 16 year old daughter had a good experience. She found the staff very friendly and helpful. I had ...a very pleasant experience guiding my daughter through the experience. Plus I like to support home grown companies.
See more
Luke Winfield
9 months ago
angie Lionetto-Civa
9 months ago
Lovely staff who attended and listened to my needs.
Thank you
Tomás Mendioroz
10 months ago
Very professional and friendly service.
marcia karvat
10 months ago
Very nice girls, patients and very professional...we like it.
Camille tune_by_tune
10 months ago
Great, easy, efficient and friendly. I love my glasses!
Hannah Mehta
10 months ago
Hannah Viray
10 months ago
## Find an Optometrist in Westfield Innaloo With Oscar Wylee
If you live in areas such as Innaloo, Karrinyup or Stirling, our Oscar Wylee store at Westfield Innaloo is your go-to for high-quality optometry and eye care services. Take the bus or drive in, using one of the centre’s 2300 car parking spaces, and our Oscar Wylee optometrists will provide Medicare bulk billed eye tests. Once you are done with your test, our friendly retail team will help you shop our range of affordable and stylish frames. When you finish your appointment, why not make the most of the many retail stores, cafes and grocery stores Westfield Innaloo has to offer? Whether you need to restock your pantry at Woolworths, want to browse at Target, or need a caffeine hit from Coffee Club, you’ll find everything you need at Westfield Innaloo.For those who live in the Innaloo area, other Oscar Wylee optometrists nearest to you include Oscar Wylee Claremont Quarter, Oscar Wylee Karrinyup and Galleria Shopping Centre. Come in and see us at our Oscar Wylee eyeglasses shop today, and experience some of the best optometry services in Western Australia!
Meet Our Team
* Store Manager
Show All
## Find an Optometrist in Innaloo, Western Australia for an Eye Health Test
You can find an Oscar Wylee optometrist in Innaloo, Western Australia for an eye health test and other eye care services such as prescription updates and new frames. Located in Westfield Innaloo, Oscar Wylee optometrists are available to perform eye tests that will include vision testing and the detection of eye diseases and eye conditions. Other eye care services available at Oscar Wylee Westfield Innaloo include prescription updates, eye care advice and referrals to an ophthalmologist, also known as an eye doctor, for specialised care if needed. In Inaloo, Western Australia, the average cost for an optometrist often depends on factors such as a person's age, health and eye care needs. At Oscar Wylee, our eye tests are conducted at a bulk billed price under Australia’s Medicare system.
At Oscar Wylee’s glasses shop in Westfield Innaloo we have a wide range of frames available for purchase including prescription glasses, prescription sunglasses and non-prescription glasses. Our retail team, including our optical dispensers, are located in-store to help customers shop our frames. If you need adjustments or lens add-ons such as a blue light filter, our team will be able to assist with this, ensuring all of our customers leave with eyewear that is right for their vision and lifestyle needs. For high-quality eye care services such as new frames or eye health tests in Innaloo, Western Australia, come and visit our Oscar Wylee team!
## How to Find an Optometrist in Innaloo, Western Australia?
To find an optometrist in Innaloo, Western Australia you can take certain steps that can help make it easier for you such as searching online, assessing the store’s opening hours and finding the directions to your chosen location. The steps on how to find an optometrist in Innaloo, Western Australia are listed below.
1. Search online using the phrase, ‘optometrist near me in Innaloo’. This can also be done here on the website via our locations page.
2. Click on the Oscar Wylee link, which will take you directly to our Westfield Innaloo optometrist store page.
3. See the store’s opening hours and where the store is located specifically.
4. Use the Westfield Innaloo Google Business page link located under store hours to see the directions on how to get to the store.
You can also find an optometrist in Innaloo, Western Australia by searching the keywords ‘optometrist near me’. If you have locations enabled on your smartphone and you’re in the Innaloo, Western Australia area, our Innaloo Westfield store page should appear easily for you to click on.
### Is it Hard to Get an Eye Appointment in Innaloo, Western Australia?
No, it is not hard to get an eye appointment in Innaloo. You can easily book an appointment to see an Oscar Wylee optometrist in Innaloo, Western Australia right here on this page. At Oscar Wylee we have highly qualified optometrists available for bulk billed eye appointments, which can be booked online or in-store.
#### How to Compare Optometrists in Innaloo, Western Australia to Each Other?
To compare optometrists in Innaloo, Western Australia, you can use factors such as eye tests offered, health fund coverage, lens types and add-ons and eyewear offered. To take care of your vision and eye health, it is important to receive an eye test at least once every two years. There are different types of tests that can be performed in an eye test and not all optometrists may offer the same tests. Health funds can be used to help cover some of the cost of your frames and lenses. To find out if your health fund is accepted at an optometrist in Innaloo, Western Australia visit their website. In the case of Oscar Wylee, we accept all major health funds and provide on-the-spot claims in-store. There are many different lens options available for prescription glasses such as single-vision, multifocal and high-index lenses. Most optometrists in Innaloo, Western Australia will offer these lenses although it is good to make sure. There are also lens add-ons available to enhance your glasses such as anti-reflective and blue light filters. Finally, if you are looking to purchase a pair of glasses after your eye test, you can compare the different styles and colours you are interested in from the optometrists in Innaloo, Western Australia. Oscar Wylee offers a wide range of frames with vintage and modern inspirations in bold colours and subtle designs.
#### How to Find an Eyeglasses Shop in Innaloo, Western Australia?
To find a glasses store in Innaloo, Western Australia you can try to follow these simple steps including searching online, selecting a convenient location and looking at their health insurance policies. The steps on how to find a glasses store in Innaloo, Western Australia are listed below.
1. Search online using the phrase, glasses store in Innaloo, Western Australia. This will provide you with various options for glasses stores in the whole Innaloo, Western Australia area.
2. Select a glasses store that is most convenient for you to travel to.
3. Click the link to find out more information such as opening hours, exact location and directions to the glasses store in Innaloo.
4. Read their health insurance policies to ensure you know what health benefits you have access to.
Our Oscar Wylee glasses store in Innaloo, Western Australia offers primary eye care services such as comprehensive eye tests as well as other services performed by an optometrist and offers prescription and non-prescription eyewear.
##### Is it Possible to Purchase Prescribed Sunglasses in Innaloo, Western Australia Without Seeing an Optometrist?
Yes and no, it is possible to [purchase prescribed sunglasses](https://www.oscarwylee.com.au/sunglasses.html) in Innaloo, Western Australia without seeing an optometrist if you already have a prescription that has not expired. If your prescription is expired, you can book an eye test to receive an updated or new prescription which will require you to see an optometrist. This will ensure your prescription sunglasses are appropriate for your visual needs.
## Where is the Oscar Wylee Innaloo, Western Australia Optometrist Located?
The Oscar Wylee Westfield Innaloo optometrist is located in the Westfield Innaloo shopping centre, in the suburb of Innaloo in Western Australia.
### What is the Phone Number of Oscar Wylee Innaloo, Western Australia Optometrist Store?
The phone number for our Oscar Wylee Innaloo, Western Australia optometrist store is [08 6186 2337](tel:08 6186 2337). Our Oscar Wylee Innaloo, Western Australia store is open, and our staff are available to be contacted Monday to Wednesday from 9 am to 5.30 pm, Thursday 9 am to 8 pm, Friday 9 am to 5.30 pm, Saturday 9 am to 5 pm and Sunday 11 am to 5 pm.
### What are the Reviews for Oscar Wylee Innaloo, Western Australia Optometrist?
The customer reviews for our Oscar Wylee Innaloo, Western Australia optometrist, can be found here on our website and online when you search for ‘Oscar Wylee Innaloo optometrist.’
Marie A:  Friendliest customer service staff and
optometrist, they were running a little late but up front with
the delay. The customer service was AMAZING, she went above
and beyond to try to fix my very crooked glasses. Thank you
Strathpine OW team!
Dave Murchie:  Friendly service, with a very
experienced in-house optometrist.
Mr Lucifer:  The optometrist was really helpful and let
me know what’s the problem clearly and helped me to find a
solution for it. Sales person was so helpful in the selection.
Thank you Oscar Wylee.
Gail Adams:  Experience excellent, lovely friendly
staff.

#### What Treatments or Eye Care Processes Are Done in the Oscar Wylee Innaloo, Western Australia Optometrist Location?
The treatments or eye care processes done in the Oscar Wylee Innaloo, Western Australia optometrist location include a tonometry test, a slit lamp exam, a digital photograph, and a refraction test. Additional tests that may also be performed can include a visual field test and a dilated fundus exam. The treatments or eye-care processes that are done in the Oscar Wylee Westfield Inaloo optometrist location are listed below.
* A Tonometry Test: An optometrist or optical dispenser will conduct a tonometry test which involves the use of a machine that will release small puffs of air into your eyes. This will assist with measuring pressure in the eye.
* A Digital Photograph: An optometrist or optical dispenser may take a digital photograph of your eye which can be kept on record to use in future appointments to evaluate any changes to your eye.
* Slit Lamp Test: A slit lamp test can be used to evaluate your eye health, by examining your cornea and iris which are the anterior and posterior of the eye.
* Refraction Test: During a refraction test, an optometrist will have you view an image through different lenses and ask you to confirm which helps you see the image clearer.
* Visual Field Test: A visual field test can assist with assessing your peripheral vision, which may be beneficial for identifying any signs of glaucoma.
* Dilated Fundus Exam: A dilated fundus exam can help an optometrist assess your health in more detail by getting a clear view of the retina. This test is typically carried out for patients with diabetes and those at risk of developing retinal damage.
## How Many Optometrists Exist in Innaloo, Western Australia?
Many optometrists exist in Innaloo, Western Australia and in the Westfield Innaloo shopping centre, including Oscar Wylee. The number of optometrists available in an area will typically depend on the population and the eye care needs of those in the area. At Oscar Wylee Innaloo, Western Australia, our team is passionate about providing our customers with high-quality, dedicated eye care services. Our optometrists are available to provide bulk billed eye tests with our dedicated optometrists, prescription updates and new frames. If you are looking for an optometrist in Innaloo, Western Australia, Oscar Wylee is available to provide all your eye care and eyewear needs.
### What are the Other Closest Optometrist Locations to Innaloo, Western Australia in Australia?
The closest Oscar Wylee optometrist locations to Innaloo, Western Australia are in Claremont Quarter, Karrinyup and Galleria Shopping Centre. The closest Oscar Wylee optometrist locations to Innaloo, Western Australia are listed below.
* Claremont Quarter: Claremont Quarter is a shopping centre located approximately 11 km away from Innaloo, in which you can find an Oscar Wylee optometrist for eye care services. [Oscar Wylee Claremont Quarter](https://www.oscarwylee.com.au/locations/optometrist-claremont.html) is located in the suburb of Claremont, where our optometrist can provide Medicare bulk billed eye tests and prescription updates.
* Karrinyup: Karrinyup is a suburb located approximately 5 km from Innaloo where you can find an Oscar Wylee optometrist. Find our [Oscar Wylee Karrinyup](https://www.oscarwylee.com.au/locations/optometrist-karrinyup.html) team in Karrinyup Shopping Centre for eye care services including eye tests and new frames.
* Galleria Shopping Centre: Galleria Shopping Centre is a shopping centre located approximately 11 km away from Innaloo where you can find an Oscar Wylee optometrist. [Oscar Wylee Morley Galleria](https://www.oscarwylee.com.au/locations/optometrist-morley-galleria.html) is located in the suburb of Morley, where our optometrists can provide Medicare bulk billed eye tests and our retail staff can help customers shop for new frames from our stylish collection.
### Innaloo Bulk Billed Eye Examinations
Come in and have your prescription updated at Oscar Wylee Westfield Innaloo, so you can shop for a new pair of fashion-forward eyeglasses on the same day. Our trained Oscar Wylee Innaloo optometrists are onsite to update your prescription or provide a new one if necessary, usually in under 30 minutes. Oscar Wylee optometrists will assess your vision, check your eye health and diagnose possible eye diseases and conditions. With the recommended frequency of an eye check-up and vision testing being at least once every two years, Oscar Wylee’s optometrist-led eye tests in-store at Oscar Wylee Innaloo, Australia, can keep you up-to-date on your eyesight and eye health needs.
### Health Funds Accepted at Oscar Wylee
Oscar Wylee in Westfield Innaloo, Australia accepts all major health funds including Bupa, Medibank and HCF. Our friendly staff are trained to process your claim in-store with a valid health fund card, as well as answer any questions you have about your claim. Remember to bring your health fund card to your next appointment with Oscar Wylee Westfield Innaloo for your eyewear and optometry needs.
### Stylish Glasses in Innaloo
Oscar Wylee Westfield Innaloo offers a range of prescription eyeglasses and prescription sunglasses in a variety of modern and vintage-inspired styles. With add-ons such as anti-reflective coating, a blue light filter, or polarised lenses, you’ll be sure to find a pair of frames to meet your eye care needs. Oscar Wylee’s experts in-store can assist in ensuring you receive the frames that are best suited to your lifestyle and prescription needs.
Book Appointment
[Call us: 08 6186 2337](tel:08 6186 2337)
[Leave a Review!](https://g.page/r/CWRC6Q2MU3WkEBM/review)