# Source: https://www.oscarwylee.com.au/locations/optometrist-macarthur-square.html

# Optometrist Campbelltown
Macarthur SquareLevel 2, Shop L068200 Gilchrist DriveCampbelltown NSW 2560
* Near Sephora
Opening hours
Monday9:00am - 5:30pm
Tuesday9:00am - 5:30pm
Wednesday9:00am - 5:30pm
Thursday9:00am - 9:00pm
Friday9:00am - 5:30pm
Saturday9:00am - 5:30pm
Sunday10:00am - 5:00pm
*Store hours reflect local standard trading hours and exclude public holidays
[Visit our Macarthur Square Google Business page for directions, reviews, and updates.](https://g.page/r/CfpzvmdYkky3EAE)
Book Appointment
[Call us: (02) 4610 1887](tel:(02) 4610 1887)
[Leave a Review!](https://g.page/r/CfpzvmdYkky3EBM/review)
Our Reviews
David Luxford
1 week ago
Very helpful, very thorough. Highly recomended
angela zhang
2 weeks ago
Dr Hossein is very patient, through and helpful! Especially with teaching me how to use contacts for... the first time :)
See more
Helen Taylor
3 weeks ago
From the moment we stepped into the store, the friendly sales assistants were incredibly helpful and... happy to answer all our questions. They were patient while we tried on a variety of glasses and helped us until we were completely happy with our selections.
We had booked our eye test the day before and were taken in on time. The optometrist was efficient, provided clear information, answered all our questions and explained the different options available.
All in all, the whole experience was outstanding, especially the wonderful sales assistants. We would definitely recommend a visit and will certainly be back!This keeps the review personal and genuine, while making it flow a little more smoothly.
See more
Judith Peake
3 weeks ago
Friendly efficient and helpful staff and expert advice  made for a positive experience and why OW is... my go to for eye tests and glasses.
See more
Shane Bramman
1 month ago
The team at Macarthur Square were amazing. The front staff were very welcoming and happy to answer a...ll my questions. The optometrist was very knowledgeable and helpful with selecting the right script for my eyes
See more
Jane Noble
1 month ago
Excellent care by the Optometrist.
Highly recommend the eye care provided.
Vanessa T
1 month ago
I highly recommend coming here. Very lovely staff members were patient with me. They helped me choos...e what frames suited me and considered lens thickness. I usually would bring someone with me to see how the frames look as I cannot see far distance while trying on frames. The optometrist Dr Hussein (I am not sure if I spelt his name right) gave me eye contacts similiar to my lens to wear while trying out new frames. I never had an optometrist consider my farsightedness before. I feel seen and so much happier that I made the right choice with my frames thanks to the eye contacts he gave me :)
See more
Matt H
1 month ago
Rebecca Roberts
1 month ago
The overall experience was positive. They were organised, knew what they were talking about. All of ...my questions were answered straight away.
See more
Danni Galvin
1 month ago
The staff were amazing, they helped me picked glasses and explained all the options clearly. Totally... great experience
See more
Margaret Janssen
1 month ago
Extremely happy with my glasses and staff very professional.
Anshu Chand
1 month ago
Customer friendly and 5 star service .
Lilli-Mae Phommasaeng
1 month ago
Adham Mansour
1 month ago
It’s very good place very experienced doctor and have a great experience
Barry Swain
1 month ago
Kim Woollams
2 months ago
Great customer service at Oscar Wylee MacArthur Square.. very helpful with choosing glasses and very... experienced Optometrist with so much precision in his work.. thank you
See more
Derek Timbrell
2 months ago
Excellent!
As always friendly helpful staff. Not a production line , like the  “ should have gone to... that place….”
Prices were better than that place too.
Oscar Wiley, very happy ????
See more
DAVID STEVENS
3 months ago
Every experience ive had with the Macarthur team at Oscar and Wylee Macarthur square has always been... proffessional, friendly and very helpful. I have recommended them to all my friends and family and wouldn't use any other optometrist., especially when they put up with my husbands Dad jokes. Lol. Thankyou Oscar and Wylee for always making it a pleasurable experience every time.
Regards
Paula Stevens
See more
Ebenezer R Tobi
3 months ago
Very Good Doctor and staffs. Good service and great dealing. Affordable price.
Very happy.
Highly re...commended.
See more
Liliane UTAMURIZA
4 months ago
Amazing experience! The optometrist is very kind and takes the time to examine your eyes thoroughly.... He explains everything clearly, which I really appreciated. The other staff are also very friendly and help you choose the right frames for your glasses. They really know their stuff—very professional! I truly enjoyed my visit.
See more
Amanda Bortolazzo
4 months ago
Great , professional service. Very friendly staff. ????
Tammie Dengate
4 months ago
the staff are so kind and friendly and act good and thay are all ways happy
Johann Stewart
4 months ago
The girls at the front counter were lovely and friendly and greeted us on arrival for our appointmen...t.  Our OpTom was friendly and courteous.  It was a very pleasant experience and one we will be repeating in the furture.
See more
farah 14
4 months ago
Laura Sanchez Santos
4 months ago
Best experience with the ophthalmologist and the woman at the front desk. They took their time to ex...plain everything to me. I didn't feel like they were trying to sell me anything; they just gave me the information and let me decide.
​Highly recommended! And the prices are definitely very competitive.
See more
Ravindra Kumar
5 months ago
Luaipou Satuatasi
5 months ago
Marijana Donev
5 months ago
Fantastic experience ???? great staff and extremely helpful
rhea jean toling
5 months ago
Khaleb
5 months ago
Graeme Doherty
5 months ago
Second time I have gone to Oscar Wylee Mac Square for glasses. Both times the team there have been g...reat. Would recommend.
See more
Karren Driver
6 months ago
Extremely easy to make an appointment online. The eye test was relatively quick &amp; painless. Large se...lection of frames. Great prices. Staff very friendly and helpful.
See more
Carole Fletcher
6 months ago
Was very impressed with the level of service and friendliness of staff
Purple Flower
6 months ago
Went in late this arvo to order new prescription sunglasses, served by Meli. What a delightful exper...ience with this fabulous young lady! Friendly, helpful, courteous, a wonderful example of true customer service, thank you so much
See more
Amanda O'Connor
6 months ago
All the staff were professional. Made me feel at ease. Explained every step of the way and listened ...to my questions giving me options. Highly recommend.
See more
Denise Ashton
7 months ago
Very positive experience with the staff at Macarthur Square Campbelltown. The optometrist was very h...elpful and
answered any questions I had. Would definitely go back again.
See more
Kalisi Navara
7 months ago
Excellent work done yesterday! Hats off to the doctor and the assistant
Gwen Winnall
7 months ago
Very happy with the Macarthur Store staff.  Receptionist very friendly and efficient.  The optometri...st is very professional.  All necessary tests were done and also he completed the necessary form on line for me as I had to have my annual competence to drive  .
See more
Mark Schwenke
7 months ago
Excellent service, quick, friendly and professional. h
Tiana M
7 months ago
I was just served by Mellie at Oscar Wylee while picking up my order and she provided exceptional cu...stomer service. She was so personable, kind, and genuinely took the time to help me,  it was honestly so refreshing to experience such warm and thoughtful service.
She made the whole process easy and enjoyable, and you can tell she truly cares about her customers. Thank you Mellie for such a lovely experience, you really made my day!
See more
Md. Mahbubul Mohsin Khan
7 months ago
Very professional and explains clearly.
Nabeela Goosen
7 months ago
Always a pleasant experience, optometrist friendly, professional, personable and efficient, making t...he experience easy and seamless.
See more
Yuki Hirobe
7 months ago
The eye test it self was great - the optometrist-Dr Hosein was very thorough and explained things we...ll and patiently answered all our questions.
The shop staff were very helpful too-the only thing was that the price structure for the deal was a little obscure and as a result, we had to pay some extra… but again the senior staff was helpful in reaching out to the area manager for some additional assistance. Over all, I had a positive experience there.
See more
Renata Marsh
8 months ago
Katie McCready
8 months ago
Very friendly and explained the whole process thoroughly.
Isabella Compton
9 months ago
Love coming to Oscar Wylee at Macarthur Square. Always a smooth process with very supportive staff. ...Even more of a bonus now that they carry contact lens in their stores!
See more
Antonio Barón
9 months ago
Amazing customer service, one of the best!
Russ H
9 months ago
Great people make things easy and you made the whole process easy.
Thanks
RussH
Nazneen Kapadia
9 months ago
Sam Baz
9 months ago
## Find an Optometrist in Campbelltown Macarthur Square With Oscar Wylee
Situated in the heart of Campbelltown, our Oscar Wylee store can be found in the Macarthur Square Shopping Centre. Come and see our optometrists on level 2, who can provide you with bulk billed eye health tests. Take the train to Macarthur station just over the road or utilise the centre’s free 3-hour parking, and our staff can help you shop our range of affordable and stylish glasses. 
If you want to indulge in some retail therapy when you have finished your appointment with our optometrists in Oscar Wylee Campbelltown located in Macarthur Square, the shopping centre in Macarthur Square is the right place to do so. With over 200 stores, there is something for everyone to enjoy. If you’d prefer to get outdoors, the Australian Botanic Garden is just a 10-minute drive away. If you live in the Englorie Park, Mount Annan or Leumeah areas, our Oscar Wylee Campbelltown store at Macarthur Square is your go-to for optometry needs, our team are fully qualified in examining eye diseases as part of Oscar Wylee’s eye care processes. Our optometrists are dedicated to your vision health and customer experience, so make Oscar Wylee Campbelltown in Macarthur Square your next stop for eye health.        
Meet Our Team
* Optometrist
B.Sc.Optom (Hons)
Therapeutically Endorsed
* Store Manager
Our Services
* Bulk Billed Eye Examinations
* Professional Frame Styling
* Frame Adjustments and Repairs
* Staff with over 5 years of optical experience
Show All
## Find an Optometrist in Macarthur Square, Campbelltown for an Eye Health Test
An optometrist in Macarthur Square, Campbelltown is your destination for stylish frames, eye tests and other important eye health services. An eye health test in Macarthur Square is essential for the detection of certain eye diseases and to maintain vision health and is available for a bulk billed price as part of Australia’s Medicare System. If our team comes across any signs of concern, they will happily refer you to an eye doctor in the area for further assessment. When you visit our Oscar Wylee store in Macarthur Square, you can find our skilled optical dispenser for any assistance with your glasses. Protect your eyes in style with our selection of prescription sunglasses or non-prescription sunglasses.
A comprehensive eye test will typically involve examining the different regions of the eye to make sure everything is in good condition. The factors that may contribute to the average price for an optometrist in Macarthur Square may include the number of available optometrists in the area, equipment and the nature of your condition.
## How to Find an Optometrist in Macarthur Square, Campbelltown?
To find an optometrist in Macarthur Square, Campbelltown, you can take certain steps that can help make it easier for you such as searching online, assessing the store’s opening hours and finding the directions to your chosen location. The steps on how to find an optometrist in Macarthur Square are listed below.
1. Search online using the phrase, Macarthur Square optometrist near me. This can also be done here on the website via our locations page.
2. Click on the Oscar Wylee link, which will take you directly to our Macarthur Square optometrist store page.
3. See the store’s opening hours and where the store is located specifically.
4. Use the Macarthur Square Google Business page link located under store hours to see the directions on how to get to the store.
You can also find an optometrist in Macarthur Square by searching the keywords optometrist near me. If you have locations enabled on your smartphone and you’re in the Macarthur Square area, our Macarthur Square store page should appear easily for you to click on.
### Is it Hard to Get an Eye Appointment in Macarthur Square, Campbelltown?
No, it is not hard to get an eye appointment in Macarthur Square. You can easily book an appointment to see an Oscar Wylee optometrist in Macarthur Square right here on this page. At Oscar Wylee we have highly qualified optometrists available for bulk billed eye appointments, which can be booked online or in-store.
#### How to Compare Optometrists in Macarthur Square to Each Other?
To compare optometrists in Macarthur Square, you can use factors such as eye tests offered, health fund coverage, lens types and add-ons and eyewear offered. To take care of your vision and eye health, it is important to receive an eye test at least once every two years. There are different types of tests that can be performed in an eye test and not all optometrists may offer the same tests. Health funds can be used to help cover some of the cost of your frames and lenses. To find out if your health fund is accepted at Macarthur Square optometrist in Campbelltown, visit their website. In the case of Oscar Wylee, we accept all major health funds and provide on-the-spot claims in-store. There are many different lens options available for prescription glasses such as single vision, multifocal and high index lenses. Most optometrists in Macarthur Square will offer these lenses although it is good to make sure. There are also lens add-ons available to enhance your glasses such as anti-reflective and blue light filters. Finally, if you are looking to purchase a pair of glasses after your eye test, you can compare the different styles and colours you are interested in from Macarthur Square optometrists in Campbelltown. Oscar Wylee offers a wide range of frames with vintage and modern inspirations in bold colours and subtle designs.
#### How to Find an Eyeglasses Shop in Macarthur Square, Campbelltown?
To find a glasses store in Macarthur Square, you can try to follow these simple steps including searching online, selecting a convenient location and looking at their health insurance policies. The steps on how to find a glasses store in Macarthur Square, Campbelltown are listed below.
1. Search online using the phrase, glasses store in Macarthur Square. This will provide you with various options for glasses stores in the whole Macarthur Square, Campbelltown area.
2. Select a glasses store that is most convenient for you to travel to.
3. Click the link to find out more information such as opening hours, exact location and directions to the glasses store in Macarthur Square.
4. Read their health insurance policies to ensure you know what health benefits you have access to.
Our Oscar Wylee glasses store in Macarthur Square, Campbelltown offers primary eye care services such as comprehensive eye tests as well as other services performed by an optometrist and offers prescription and non-prescription eyewear.
##### Is it Possible to Purchase Prescribed Sunglasses in Macarthur Square, Campbelltown Without Seeing an Optometrist?
Yes and no, it is possible to [purchase prescribed sunglasses](https://www.oscarwylee.com.au/sunglasses.html) in Macarthur Square without seeing an optometrist if you already have a prescription that has not expired. If your prescription is expired, you can book an eye test to receive an updated or new prescription which will require you to see an optometrist. This will ensure your prescription sunglasses are appropriate for your visual needs.
## Where is the Oscar Wylee Macarthur Square Optometrist in Campbelltown Located?
The Oscar Wylee Campbelltown optometrist is located in Macarthur Square Shopping Centre on level 2, near Sephora. You can find the Macarthur Square Shopping Centre along Gilchrist Drive in Campbelltown.
### What is the Phone Number of Oscar Wylee Macarthur Square Optometrist Store?
The Oscar Wylee Macarthur Square optometrist store phone number is [(02) 4610 1887](tel:(02) 4610 1887). You can contact the Oscar Wylee Macarthur store between the hours of 9 am and 5:30 pm on Monday, Tuesday, Wednesday, Friday and Saturday, between 9 am and 9 pm on Thursday and between 10 am and 5 pm on Sunday.
### What are the Reviews for Oscar Wylee Macarthur Square Optometrist in Campbelltown?
The many reviews for Oscar Wylee Macarthur Square optometrist in Campbelltown, left by our various customers can be found here on the website and online when you search for Oscar Wylee Macarthur Square optometrist. The reviews for Oscar Wylee Macarthur Square optometrist are listed below.
* Ratna Hossain:  Professional, friendly and convenient.
* Marcus Rodriguez:  Had an amazing experience, both the staff and the optometrist were professional and polite. They helped us with choosing frames and provided some valuable fashion advice.
* Renata Marsh:  Optometrist very thorough and experienced. Beautiful selection of frames.
* Neeloy Alam:  Excellent. The optometrist provided information and explanation on every test they did. Very good understanding of my requirements.
* Richard Scurr:  Very professional, very good.
#### What Treatments or Eye Care Processes are Done in the Oscar Wylee Macarthur Square Optometrist Location?
The treatments or eye care processes done in the Oscar Wylee Macarthur Square optometrist Campbelltown location include a tonometry test, a slit lamp exam and a refraction test. Additional tests that may also be performed can include a dilated fundus exam. The treatments or eye-care processes that are done in the Oscar Wylee Macarthur Square optometrist Campbelltown location are listed below.
* A Tonometry Test: An optometrist or optical dispenser will conduct a tonometry test which involves the use of a machine that will release small puffs of air into your eyes. This will assist with measuring pressure in the eye.
* Slit Lamp Test: A slit lamp test can be used to evaluate your eye health, by examining your cornea and iris which are the anterior and posterior of the eye.
* Refraction Test: During a refraction test, an optometrist will have you view an image through different lenses and ask you to confirm which helps you see the image clearer.
* Dilated Fundus Exam: A dilated fundus exam can help an optometrist assess your health in more detail by getting a clear view of the retina. This test is typically carried out for patients with diabetes and those who may be at risk of developing retinal damage.
## How Many Optometrists Exist in Macarthur Square, Campbelltown?
There are many optometrists that exist in Macarthur Square Campbelltown, who have eye tests and a wide selection of glasses available, including Oscar Wylee. The number of Macarthur Square optometrists in Campbelltown may be due to the large number of residents in the area and possibly the geographical size of the area. Oscar Wylee offers great services to help you prioritise your eye health and look your best. So make Oscar Wylee Macarthur Square your first choice for optometry services.
### What are the Other Closest Optometrist Locations to Macarthur Square Campbelltown in Australia?
The other closest Oscar Wylee optometrist locations to Macarthur Square in Australia are Narellan, Liverpool and Bankstown. The other closest optometrist locations to Macarthur Square are listed below.
* Narellan:  Narellan is close to Macarthur Square with just 8 km in between stores and can be found at the Narellan Town Centre next to Queens Jeweller. The [Oscar Wylee Narellan](https://www.oscarwylee.com.au/locations/optometrist-narellan.html) store is where you can receive eye health services conducted by a passionate team.
* Liverpool:  Liverpool is close to Macarthur Square, around 27 km in distance and can be found at the Westfield shopping centre on level 2, near Hype DC. The [Oscar Wylee Liverpool](https://www.oscarwylee.com.au/locations/optometrist-liverpool.html) store can provide eye health tests for general check-ups and prescription eyewear.
* Bankstown:  Bankstown is close to Macarthur Square with 38 km in between stores and is located at the Bankstown Central Shopping Centre, which can be found at 188 North Terrace. The [Oscar Wylee Bankstown](https://www.oscarwylee.com.au/locations/optometrist-bankstown.html) store performs high-standard comprehensive eye tests available for bulk billing. Here you can browse our wide range of stylish frames and get help with general eyecare and selecting frames that fit you best.
### Eyes Tests with our Campbelltown Optometrists
You can get all essential eye tests completed by our qualified optometrists. You can visit our Oscar Wylee Macarthur Square store in Campbelltown, where we offer bulk billing for eligible Medicare card holders in approximately 20 minutes. Get your vision tested and update your prescription at our Oscar Wylee Macarthur store in Campbelltown.
### Leading Health Funds Accepted
You can visit our Oscar Wylee Campbelltown store located in Macarthur Square and our capable staff will take care of your health fund claims with a valid health fund card. If you’re unsure about what you’re eligible for with your health fund, our optometrists at Oscar Wylee Campbelltown in Macarthur Square will be sure to help you with any enquiries you may have. Here at Oscar Wylee, we will strive to ensure you get exactly what you need.
### Affordable and Fashionable Glasses at Oscar Wylee
Oscar Wylee has some of the best eyewear services in Campbelltown as we prioritise bringing out your best style. You can expect prescription glasses and prescription sunglasses at an affordable price. Feel free to ask our knowledgeable staff in Oscar Wylee Campbelltown in Macarthur Square about our different lens options that can accommodate your different visual needs. Oscar Wylee offers blue light filters and multifocal lenses among the many options available. Our team will endeavour to cover all your vision and eye health concerns.
Book Appointment
[Call us: (02) 4610 1887](tel:(02) 4610 1887)
[Leave a Review!](https://g.page/r/CfpzvmdYkky3EBM/review)