# Source: https://www.oscarwylee.com.au/glasses/eye/how-does-human-eye-see

# How Does the Human Eye See?
Published on August 21st, 2023
Updated on March 21st, 2025 
Australia
[Australia](https://www.oscarwylee.com.au/glasses/eye/how-does-human-eye-see)
New Zealand

[Canada](https://oscarwylee.ca/glasses/eye/how-does-human-eye-see)
Canadian French

The human eye is a complex organ that uses different parts of the eye to
transform light into images. The parts of the eye that are responsible for
vision are the cornea, the iris, the pupil, the lens, the retina and the
optic nerve. There are many aspects to how the eye works, with each part of
the anatomy crucial in receiving light from objects and transferring them to
the brain. How well the human eye can see is dependent on certain factors
such as the health of the eye, the visual acuity as well as how much light
is present and how obstructed their sight is.
In summary, the human eye works as light is received by the eye, passing
through the cornea which bends the light. The light then passes through the
lens to focus on the retina which turns the light into electrical signals
which travel from the retina, to the optic nerve and finally into the brain
which turns these signals into the images we see. Keep reading to learn more
about how vision works and what the human eye is capable of.
When Was Your Last Eye Test?
Visit us in-store for a Medicare bulk billed eye test for those with a
valid card.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Eye Parts for Vision](#Vision)
[Vision Process](#Process) [Vision Quality](#Quality)
[Blue Light](#Light)
## What Parts of the Eye are Responsible for Vision?
The
[parts of the eye](https://www.oscarwylee.com.au/glasses/eye/anatomy)
that are responsible for vision are
the cornea, the iris, the pupil, the lens, the retina and the optic
nerve.
These parts work together to help humans see images by sending visual
information obtained by the eye to the brain. The parts of the eye
responsible for vision are listed below.
* Cornea: The cornea is the part of the
eye that helps focus light. It is the clear outer layer found at the
front of the eye.
* Iris: The iris is the coloured part of
the eye which is located behind the cornea. The iris controls the
amount of light that enters the eye through the pupil.
* Pupil: The pupil is the black circle
in the centre of the eye and is responsible for the amount of light
that enters the eye and is located in the iris.
* Lens: The lens, also known as the
crystalline lens, is a transparent structure that helps the eye to
focus light onto the retina.
* Retina: The retina is a structure in
the eye found at the back of the eyeball. Its main function is to
convert light that enters the eye into images that are then sent to
the brain.
* Optic nerve: The optic nerve is part
of both the eye and the body’s central nervous system. It transmits
all visual information to the brain.
The below image is the anatomy of the eye and shows the different parts
that are responsible for vision.
### How Does the Eye Work with the Brain?
The eye and the brain work together to make vision possible. The brain
is an integral part of how vision works as, according to Discovery
Eye,
the brain translates what we see into something we can
understand.
According to the National Eye Institute, this process works as cells
in the eye called photoreceptors turn light that hits the retina into
electrical signals which travel through the optic nerve and into the
brain. Once the brain receives these signals, it turns them into
images that humans see.
The brain is also very important in what we see as it flips the images
the right way up. When light hits the retina, what we see is upside
down, so
the brain is responsible for turning the images right side up.
## What is the Step-by-Step Process by Which the Human Eyes See?
The step-by-step process for how the human eye sees is as follows;
the cornea allows light to enter the eye, the pupil adapts according
to the intensity of light, the lens directs and concentrates the light
onto the retina, the retina receives the light that is focused and the
optic nerve carries visual information to the brain.
The step-by-step process of seeing is listed below.
1. The cornea allows light to enter the eye:
The cornea is the part of the eye that helps light enter the eye. The
cornea controls the amount of light entering the eye, focusing the
light that is received.
2. The pupil adapts according to the intensity of light:
The pupil contracts and expands to let light in, adapting according to
the intensity of the light.
3. The lens directs and concentrates the light onto the retina:
The lens works by directing and concentrating light onto the retina.
The lens, also known as the crystalline lens, is the clear part of the
eye located behind the iris.
4. The retina receives the light that is focused:
The retina is a layer of tissue at the back of the eye which receives
light that is focused on the retina by the lens. The retina is the
part of the eye that converts light into electrical impulses.
5. The optic nerve carries visual information to the brain:
The optic nerve is located at the back of the eye and is the part of
the eye that carries visual information from the eye to the brain.
Light is crucial for the human eye to see as without light, we would not
be able to see anything. According to The Physics Classroom, the human
eye sees due to light from objects moving through space to reach our
eyes.
### 1. The Cornea Allows Light to Enter the Eye
The cornea is
located in the front of the eye, covering the iris, pupil and
anterior chamber and is the part of the eye that allows light to
enter the eye.
The cornea is a clear, outer layer and, according to the Cleveland
Clinic, it is made up of collagen and water. The cornea is the first
contact light has with a person’s eye. And its main function is to
control the amount of light entering the eye, focusing the light that
is received. When light enters the cornea, it bends and refracts the
light. Once light enters the eye through the cornea, it travels to the
lens.
### 2. The Pupil Adapts According to the Intensity of Light
When light enters the eye, the pupil adapts by getting bigger or
smaller according to the intensity of light. The pupil is a part of
the eye which is the black circle located directly in the eye’s centre
and is covered by the cornea and surrounded by the iris which is the
coloured part of the eye. The pupil
allows light to pass through so that it can be focused in the
retina by the eyes’ lens and transferred into images.
According to the National Eye Institute, the iris controls how much
light the pupil lets into the eye.
### 3. The Lens Directs and Concentrates the Light onto the Retina
The lens is the next part of the eye that is
responsible for vision and it works by directing and concentrating
the light onto the retina.
The lens, also known as the crystalline lens, is the clear part of the
eye located behind the iris. According to the National Eye Institute,
the lens works with the cornea to focus light so that it reaches the
retina correctly. The lens receives the light of images upside down
and as it is transferred to the brain, the optic nerve flips the image
so it is right side up. The lens changes its shape due to its natural
elasticity to shine received light directly to the retina, starting
the process of transforming outside light into a perceivable image.
### 4. The Retina Receives the Light that is Focused
The retina is a layer of tissue at the back of the eye which
receives light that is focused on the retina by the lens.
According to the National Eye Institute, the retina is the part of the
eye that converts light into electrical impulses. These impulses are
then sent to the brain via the optic nerve, creating the images humans
see. The retina is made up of two parts, the first is the macula which
is integral in vision as it perceives up close and small details. The
second is the peripheral retina which is responsible for peripheral
vision which is the vision outside a person’s central vision.
### 5. The Optic Nerve Carries Visual Information to the Brain
The optic nerve is an essential part of sight which is
made up of millions of nerve fibres and it carries visual
information from the eye to the brain.
The optic nerve is the largest sensory nerve in the eye and is part of
the central nervous system, as described by the National Eye
Institute. This long nerve extends from the back of the eye and
connects directly to the brain. Once the retina has turned light into
electrical signals, these are sent to the optic nerve which then
travels to the brain where finally, the brain will turn the signals
into images. The optic nerve is a critical part of what humans see as
without it, no visual information would be received by the brain.
Visit the Team In-store
Looking for a new pair of glasses? Browse our wide collection of
vintage and modern-inspired frames.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
## How Well Does the Human Eye See?
The human eyes
can see very well in many aspects such as detail, distance and colour
perception.
In terms of distance, according to the Guinness World Record, the human
eye can see at a distance of 275 miles which is approximately 443
kilometres. Most of the time,
the distance at which we can see is interrupted by the horizon,
meaning we could see further but due to the earth’s curvature, our
sight is cut short.
How well the human eyes see can be affected by the health of the eye and
a person’s visual acuity. Certain eye diseases can affect a person's
vision, potentially leading to partial or complete vision loss. Some of
these eye conditions include glaucoma, age-related macular degeneration,
cataracts and diabetic retinopathy. In terms of visual acuity, this is
the measurement of the sharpness and clarity of a person’s vision.
Visual acuity may be diminished due to refractive errors such as
nearsightedness, farsightedness or astigmatism.
### Is the Human Eye More Precise Than a Camera?
It is difficult to determine whether the human eye is more precise
than a camera as there are many aspects of vision and image capturing
that can be compared. According to Cambridge in Colour, a learning
community for photographers,
there are three main differences between the human eye and a
camera. The first is the angle of view, the second is detail and
resolution and finally sensitivity and dynamic range.
One difference of note is how the eyes perceive detail and how a
camera perceives detail. A camera detail is measured in megapixels
which essentially describes how clear the image captured is. The human
eye doesn't capture an image the same way a camera does as our mind
doesn't see an image in megapixels, but rather in what is most
memorable whether that is colours, textures or contrast. Cambridge in
Colour describes this as the eyes taking a mental image with the
detail being an indication of what was most interesting to the person.
### What is the Best Vision Possible?
There is
no definitive answer to what is the best vision possible although
20/20 vision is measured as normal vision
so it can be inferred that a person with better than 20/20 vision has
above-average vision. 20/20 is a measurement in feet of a person’s
visual acuity which is the sharpness and clarity of their vision. The
measurement is determined using a letter chart that is used in an eye
test with an optometrist. 20/20 is not the
[best vision](https://www.oscarwylee.com.au/glasses/eye/perfect-vision)
possible as people can have better than this measurement. For example,
a person can have 20/15 vision which means they can see an object
clearly at 20 feet what a person with 20/20 vision would need to be 15
feet away to see.
### How Does Blue Light Affect How the Human Eye Sees?
Blue light
does not directly affect how the human eye sees, rather there is
some evidence that it may cause damage to the eyes.
According to the University of California, extended exposure over time
to
[blue light](https://www.oscarwylee.com.au/glasses/blue-light)
may cause damage to the eye’s retina cells, which could lead to the
development of certain eye conditions such as age-related macular
degeneration and cataracts. There is also research conducted by the
National Eye Institute that suggests children's eyes absorb more blue
light from digital devices, making them more at risk than adults.
Blue light glasses can be worn to potentially mitigate the effect of
blue light as the lenses are designed to block a certain degree of
blue light emitted from digital screens such as a computer, laptop or
smartphone.
### Can the Human Eye See Everything Around Us?
No,
the human eye cannot see everything around us as there are certain
limitations the eyes have.
For example, we are unable to see bacteria without the help of a
microscope and we cannot see radio waves. However, the human eye can
see great distances depending on other factors such as light, the
earth’s curvature and the health and visual acuity of a person’s eye.
#### What can we not See with our Human Eyes?
There are many limitations the human eyes have meaning there are
certain things they cannot see. According to the University of
Rochester, some of the limitations of the human eye include its
light-gathering ability,
the eye being unable to store images like a camera. The eyes
are also limited in their frequency response meaning they can
only see electromagnetic radiation in the visible wavelengths.
##### Are There Colours the Human Eye Cannot See?
Yes,
there are colours that the human eye cannot see. According
to the European Space Agency,
there is a large amount of the spectrum of light that the human
eye cannot see
such as infrared and ultraviolet colours. The way the eyes
perceive colour, as described by Pantone, is that colours are
absorbed or reflected on the surface of objects, meaning objects
do not inherently have colour. According to Pantone, it is
estimated by researchers that the human eye can see approximately
one million different colours.
Read How Does the Human Eye See? in other Oscar Wylee regions and
their languages.
Australia
[Australia](https://www.oscarwylee.com.au/glasses/eye/how-does-human-eye-see)
New Zealand

[Canada](https://oscarwylee.ca/glasses/eye/how-does-human-eye-see)
Canadian French

Health Funds Accepted at Oscar Wylee
Bring your health fund to your next visit and our team can process
your claim in-store.
[Discover Health Funds](https://www.oscarwylee.com.au/health-funds.html)
Prioritise Your Eye Health
Book your regular eye checkup with one of our dedicated optometrists.
[Book an eye test](https://www.oscarwylee.com.au/booking)