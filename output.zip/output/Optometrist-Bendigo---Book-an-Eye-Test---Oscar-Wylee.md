# Source: https://www.oscarwylee.com.au/locations/optometrist-bendigo.html

# Optometrist Bendigo
Bendigo MarketplaceShop G008, 116-120 Mitchell StBendigo VIC 3550
* Near Woolworths
Opening hours
Monday9:00am - 5:30pm
Tuesday9:00am - 5:30pm
Wednesday9:00am - 5:30pm
Thursday9:00am - 6:00pm
Friday9:00am - 9:00pm
Saturday9:00am - 4:00pm
Sunday10:00 - 4:00pm
*Store hours reflect local standard trading hours and exclude public holidays
[Visit our Bendigo Google Business page for directions, reviews, and updates.](https://g.page/r/CetavCkVUhM4EBA)
Book Appointment
[Call us: (03) 5400 2170](tel:(03) 5400 2170)
[Leave a Review!](https://g.page/r/CetavCkVUhM4EAg/review)
Our Reviews
Sue Denison
2 days ago
Andrew is such a great optomatrist. Highly recommend Oscar Wylee. Great staff and lovely glasses
Clive Buckland
4 days ago
The overall experience was well above my expectations
I am greatly appreciative of the expertise the... staff displayed and the value for money I received.
See more
Kerry Bryce
1 week ago
Completely amazing!!! The whole team was so supportive to my son. They made sure he was comfortable,... felt at ease and could follow the instructions. They were thorough and wonderful in their recommendations for his future testing. We appreciate your kindness for a young boys first eye test.
See more
Janine Cullen
1 week ago
I found Andrew very professional and would recommend.
Cherie Heslington
2 weeks ago
Michelle Geronimo
2 weeks ago
Natalie Elliott
2 weeks ago
Drm s
3 weeks ago
Since moving to Australia in January 2025, this has honestly been the best team I’ve come across.
Kr...is, Josh, and Anthony the optometrist were absolutely brilliant—friendly, professional, knowledgeable, and genuinely helpful. Exceptional service from start to finish. Highly recommend! ⭐️⭐️⭐️⭐️⭐️
See more
Jean Paul Raynaud
3 weeks ago
Karen Jones
3 weeks ago
What a delightful team @ Oscar Wylee Optometrist Bendigo.  Service was flawless.  Thankyou all
Christine Sayer
1 month ago
I dread eye tests. I find them very uncomfortable.  But my first experience with the crew at Oscar W...ylee was amazing! The staff are lovely, very helpful, and the optometrist made the whole eye testing experience smooth and stress free. I am looking forward to getting my new glasses, (cool frames!), and lens that make seeing easy. I loved the way he explained my vision to me,  how it differs from my last eye test and what I can do to keep my eyes healthy.  Thank you!
See more
noelene walton
1 month ago
great experience, very friendly and professional.
Lynne Cannon
1 month ago
Very efficient - thankyou
Bev Green (Fozziemum)
1 month ago
Very happy with the staff from Optometrist through to sales, easy, great help and a fabulous range o...f glasses to choose from.
See more
Kylie S
1 month ago
Shout out to Zoe and Tessa at the Bendigo store.
Zoe was professional and friendly.
Knew her stock e...xtremely well and all within thirty minutes. I had 2 new pairs of glasses!
Tessa was honest with her opinion as was Zoe.
All in all, a fabulous experience and I'm glad I took the time to go in.
See more
Lynley McDonald
1 month ago
Andrew Optomerist was very thorough with my eye test and explained my eye test very well.I would rat...e this test as one of the best over many years.
See more
Sukhveer Kaur Brar
1 month ago
PATRICIA PARKER
1 month ago
Staff were very pleasant helpful and did everything they could to make my appointment run as smoothl...y as possible I will and have recommended them to lots of people already and will continue to do so cost was better than I have ever paid before
See more
Dara Spiric
1 month ago
I recently went into Oscar Wylee to see the optometrist and honestly I was sooooo impressed with how... knowledgeable, thorough and helpful the optometrist was. Usually I go to specsavers but after recently going there and being told there was nothing wrong I decided to get a second opinion from Oscar Wylee. Turns out I had 3 issues with my eyes that couldn't be ignored and required a prescription. Best decision I've made in a long time and I'll definitely be coming back in the future!
See more
Nghia Pham
1 month ago
Carol Mellington
1 month ago
Very happy with the whole procedure, optometrist very thorough, the girls behind the desk were very ...helpful, I am profoundly deaf and they handled it well, I thought the price was very good, so I can’t wait to get my glasses, thank you, Carol.
See more
tegan Bree
1 month ago
Peter Scilini
1 month ago
Absolutely fantastic. Big thanks to the Bendigo Marketplace team.
M angle
2 months ago
The eye test didn't take me long, and the doctor explained my case
really well
I highly recommend
Th...e ladies in the front desk were also really nice, helpful and patient.
See more
Sallyann Vincent
2 months ago
Jena White
2 months ago
Great experience, helpful &amp; friendly staff.
Tahlia Gunn
2 months ago
Aaron Dunkley
2 months ago
Rhonda Linnell
2 months ago
We were very impressed with the friendly service and advice we received.  We were even more impresse...d with the total cost - half that charged by Specsavers.
See more
Kelly Young
2 months ago
Bendigo Optometrist was very friendly and thorough, paid attention and listened carefully to what I ...needed. Highly recommend to everyone.
See more
Jo Griffiths
2 months ago
Recent eye test was conducted very professionally while still felt treated as a person, not just the... next client.
See more
Jacob Barnes
2 months ago
Easy to book. Clear and straightforward check up.
Matthew Diss
2 months ago
Very professional and I'm very with the service.
Ricky Whitfort
2 months ago
Great service .great staff really know there stuff .great optometrist as well
Brieanna Swift
3 months ago
Elizabeth Bruce
3 months ago
The staff here are very friendly &amp; helpful. Andrew is particularly easy to talk to &amp; explains everyt...hing really well.
See more
Kylie Cox
3 months ago
Fantastic service.
Friendly and patient assistance at front of shop with finding glasses to suit me....
Optometrist very professional and explained all aspects of tests clearly.
Very happy!
See more
Debra Mitchell
3 months ago
Tessa was Fantastic today!!
I highly recommend Oscar Wylee at Bendigo Market Place.  My first but de...finitely not my last purchase. Tessa was very patient &amp; helpful - thank you.
See more
Kathryn Stepien
3 months ago
Friendly, helpful staff upon arrival, to assisting me to choose new frames and leaving was a very ch...eerful and pleasing experience.
See more
Vicky Hudson
3 months ago
Has a lovely experience at Oscar Wylee Bendigo
Great staff very friendly
Thank you
Sally Mcloughlin
3 months ago
Great customer service. Incredibly clear vision!
Vivienne Norrie
4 months ago
The staff at Oscar Wylee, Bendigo were helpful, informative and friendly. There was no pressure to p...urchase my new glasses on the day. I recommend dropping in and seeing them.
See more
s d
4 months ago
Great service, nice and friendly staff
Tiare Downs
4 months ago
Lovely staff and very helpful . Our optometrist was fantastic and very thorough
Geoffrey Wheelehan
4 months ago
Highly recommend
Great service
Thorough examination
lucresia halili
4 months ago
Thank you for the wonderful experience. Andrew is amazing, very informative and accommodating. Highl...y recommended
See more
Jacinta Wagstaff
4 months ago
The staff were lovely and very helpful. Andrew was friendly, professional and thorough at my recent ...eye test . He answered all my questions and explained everything in detail and didn't rush me out the door during my appointment. Would highly recommend Oscar Wylee Bendigo and Andrew.
See more
jincy jose
4 months ago
Deb Henderson
4 months ago
Dean Beasley
4 months ago
my recent appointment at Oscar Wylee was friendly and professional, they walk you through all the st...eps and make you welcome, and treat you like a person, great team and I would highly recommend them to anyone thats looking to see an optometrist.
See more
## Find an Optometrist in Bendigo With Oscar Wylee
At Oscar Wylee Bendigo, we aim to provide excellent eye care processes and stylish eyewear, to the Bendigo community and surrounding areas. The Oscar Wylee Bendigo store is conveniently located close to the city centre and Bendigo train station, in the Bendigo Marketplace. 
We offer bulk billed eye tests to valid Medicare cardholders throughout the week. These eye health tests can be conveniently booked over the phone, online or in-store. As well as exceptional eye care, we also strive to provide frames and lens options that are affordable and made to fit you and your needs. The Bendigo Oscar Wylee team pride themselves on giving outstanding service to all our customers during every stage of their optical journey. We hope to see you in our eyeglasses shop soon to experience some of the best optometry services in Bendigo, Australia!         
Meet Our Team
* Store Manager
7 years experience in Optical Dispensing
Our Services
* Bulk Billed Eye Examinations
* Professional Frame Styling
* Frame Adjustments and Repairs
* Visual Fields Testing
* Digital Retinal Scanning
* Diabetic Screening
* Kids Eye Test
* Police Academy Vision Checks
* Vicroads Vision Assessments
Show All
## Find an Optometrist in Bendigo, Victoria for an Eye Health Test
An optometrist in Bendigo, Victoria can provide optometry services such as an eye health test and prescription updates. At Oscar Wylee Bendigo, you can experience bulk billed eye tests for eligible cardholders thanks to Australia’s Medicare System, however, the average price range for an optometrist in Bendigo can vary depending on factors such as the patient’s overall health.
An eye test at Oscar Wylee Bendigo will look at a patient’s vision and also assess for eye diseases. For patients with more complex eye issues, our optometrists can refer them to an eye doctor, known in Australia as an ophthalmologist. Visit Oscar Wylee Bendigo, Victoria where our great staff, including an optometrist and optical dispenser, can help with your eye care and eyewear needs including prescription sunglasses and glasses.
## How to Find an Optometrist in Bendigo, Victoria?
To find an optometrist in Bendigo, Victoria, you can take certain steps that can help make it easier for you such as searching online, assessing the store’s opening hours and finding the directions to your chosen location. The steps on how to find an optometrist in Bendigo are listed below.
1. Search online using the phrase, Bendigo optometrist near me. This can also be done here on the website via our locations page.
2. Click on the Oscar Wylee link, which will take you directly to our Bendigo optometrist store page.
3. See the store’s opening hours and where the store is located specifically.
4. Use the Bendigo Google Business page link located under store hours to see the directions on how to get to the store.
You can also find an optometrist in Bendigo, Victoria by searching the keywords optometrist near me. If you have locations enabled on your smartphone and you’re in the Bendigo area, our Oscar Wylee Bendigo store page should appear easily for you to click on.
### Is it Hard to Get an Eye Appointment in Bendigo, Victoria?
No, it is not hard to get an eye appointment in Bendigo. You can easily book an appointment to see an Oscar Wylee optometrist in Bendigo right here on this page. At Oscar Wylee we have highly qualified optometrists available for bulk billed eye appointments, which can be booked online, over the phone, or in-store.
#### How to Compare Optometrists in Bendigo to Each Other?
To compare optometrists in Bendigo, you can use factors such as eye tests offered, health fund coverage, lens types and add-ons and eyewear offered. To take care of your vision and eye health, it is important to receive an eye test at least once every two years. There are different types of tests that can be performed in an eye test and not all optometrists may offer the same tests. Health funds can be used to help cover some of the cost of your frames and lenses. To find out if your health fund is accepted at an Bendigo optometrist in Victoria, visit their website. In the case of Oscar Wylee, we accept all major health funds and provide on-the-spot claims in-store. There are many different lens options available for prescription glasses such as single vision, multifocal and high index lenses. Most optometrists in Bendigo will offer these lenses although it is good to make sure. There are also lens add-ons available to enhance your glasses such as anti-reflective and blue light filters. Finally, if you are looking to purchase a pair of glasses after your eye test, you can compare the different styles and colours you are interested in from the optometrists in Bendigo, Victoria. Oscar Wylee offers a wide range of frames with vintage and modern inspirations in bold colours and subtle designs.
#### How to Find an Eyeglasses Shop in Bendigo, Victoria?
To find a glasses store in Bendigo, you can try to follow these simple steps including searching online, selecting a convenient location and looking at their health insurance policies.  The steps on how to find a glasses store in Bendigo, Victoria are listed below.
1. Search online using the phrase, glasses store in Bendigo. This will provide you with various options for glasses stores in the whole Bendigo, Victoria area.
2. Select a glasses store that is most convenient for you to travel to.
3. Click the link to find out more information such as opening hours, exact location and directions to the glasses store in Bendigo.
4. Read their health insurance policies to ensure you know what health benefits you can access.
Our Oscar Wylee glasses store in Bendigo, Victoria offers primary eye care services such as comprehensive eye tests as well as other services performed by an optometrist and offers prescription and non-prescription eyewear.
##### Is it Possible to Purchase Prescribed Sunglasses in Bendigo, Victoria, Without Seeing an Optometrist?
Yes and no, it is possible to [purchase prescribed sunglasses](https://www.oscarwylee.com.au/sunglasses.html) in Bendigo, Victoria without seeing an optometrist if you already have a prescription that has not expired. If your prescription is expired, you can book an eye test to receive an updated or new prescription which will require you to see an optometrist. This will ensure your prescription sunglasses are appropriate for your visual needs.
## Where is the Oscar Wylee Bendigo Optometrist Located in Victoria?
The Oscar Wylee Bendigo optometrist is located in Bendigo Marketplace Shopping Centre, near Woolworths. The city of Bengido in Victoria is located in Bendigo Valley, north-west of Melbourne.
### What is the Phone Number of Oscar Wylee Bendigo Optometrist Store?
The Oscar Wylee Bendigo optometrist store phone number is (03) 5400 2170. You can contact the Oscar Wylee Bendigo store between the hours of 9 am and 5:30 pm from Monday to Wednesday, 9 am and 6 pm on Thursday, 9 am and 9 pm on Fridays, 9 am and 4 pm on Saturdays and 10 am and 4 pm on Sundays.
### What are the Reviews for Oscar Wylee Bendigo Optometrist in Victoria?
The many reviews for Oscar Wylee Bendigo optometrist in Victoria, left by our various customers can be found here on the website and online when you search for Oscar Wylee Bendigo optometrist. The reviews for Oscar Wylee Bendigo optometrist are listed below.
* Christopher Parker (Wild Ambulations):  Good selection of modern frames, staff very helpful in offering advice, eye test thorough with detailed explanation, all in all a good experience.
* Suzie St George:  Can’t recommend the staff who assisted me enough. Friendly and competent. Andrew was extremely thorough in testing and I had good fun with Thomas choosing frames.
* Stephen Flaherty:  Thanks to Thomas and Andrew, this was one of my best retail experiences. Professional, knowledgeable and patient.
* Debbie Riordan:  Loved how the staff were so friendly. Very professional and couldn't be more helpful. Wonderful experience.
#### What Treatments or Eye Care Processes are Done in the Oscar Wylee Bendigo Optometrist Location?
The treatments or eye care processes done in the Oscar Wylee Bendigo optometrist Victoria location include a tonometry test, a digital photograph, a slit lamp exam and a refraction test.  Additional tests that may also be performed can include a visual field test and a dilated fundus exam. The treatments or eye-care processes that are done in the Oscar Wylee Bendigo optometrist Victoria location are listed below.
* A Tonometry Test: An optometrist or optical dispenser will conduct a tonometry test which involves the use of a machine that will release small puffs of air into your eyes. This will assist with measuring pressure in the eye.
* A Digital Photograph: An optometrist or optical dispenser may take a digital photograph of your eye which can be kept on record to use in future appointments to evaluate any changes to your eye.
* Slit Lamp Test: A slit lamp test can be used to evaluate your eye health, by examining your cornea and iris which are the anterior and posterior of the eye.
* Refraction Test: During a refraction test, an optometrist will have you view an image through different lenses and ask you to confirm which helps you see the image clearer.
* Visual Field Test: A visual field test can assist with assessing your peripheral vision, which may be beneficial for identifying any signs of glaucoma.
* Dilated Fundus Exam: A dilated fundus exam can help an optometrist assess your health in more detail by getting a clear view of the retina. This test is typically carried out for patients with diabetes and those who may be at risk of developing retinal damage.
## How Many Optometrists Exist in Bendigo, Victoria?
There are many optometrists that exist in Bendigo, Victoria to provide eye tests and glasses, including Oscar Wylee. The number of optometrists available in an area will typically depend on the population. At Oscar Wylee Bendigo, we offer excellent optometry services including eye tests performed by skilled optometrists using high-quality equipment. We also have a wide range of fashion-forward frames that customers can browse in a large selection of sizes and colours. If you’re looking for an optometrist in Bendigo, choose Oscar Wylee and we will take care of your optometry and eyewear needs.
### What are the Other Closest Optometrist Locations to Bendigo, Victoria in Australia?
There are no other Oscar Wylee optometrist locations close to Bendigo in Australia, however, we have many stores in New South Wales, Queensland, Western Australia and Victoria. If you are looking for an optometrist near you, you can find the locations of our many stores on our [full store locations page](https://www.oscarwylee.com.au/locations.html).
### Bulk Billed Bendigo Eye Tests
Expect optometrist-led eye tests in-store at Oscar Wylee Bendigo Marketplace. Come in to have your prescription updated and shop for a new pair of eyeglasses on the same day. Our trained optometrists perform tests to assess your vision and detect certain eye diseases and conditions. Choose Oscar Wylee in Bendigo to keep you up-to-date on your eyesight and eye health needs.
### Health Funds Accepted In-Store
Oscar Wylee in Bendigo Marketplace accepts all major health funds including Teachers Health, NIB and Medibank. Our friendly staff can process your claim in-store with a valid health fund card, as well as help you navigate the ins and outs of your insurance to make sure you’re getting the best price every single time for all of your prescription glasses needs.
### Frames for the Fashion-Forward
Oscar Wylee store in Bendigo offers prescription eyeglasses and prescription sunglasses which you can browse and try on in-store. We’ve got everything you need, from classic shapes to bright, bold colours. Plus, you can customise your lenses to your prescription requirements as we offer multifocal lenses and other lens add-ons such as anti-reflective coatings.
Book Appointment
[Call us: (03) 5400 2170](tel:(03) 5400 2170)
[Leave a Review!](https://g.page/r/CetavCkVUhM4EAg/review)