# Source: https://www.oscarwylee.com.au/poppy-optical.html

# Poppy
1
## Frame Design of Poppy Glasses
The frame design of Oscar Wylee’s Poppy glasses is characterised by a square-round shape, a low nose bridge fit and an acetate frame. Poppy glasses are a simple, sophisticated and stylish frame that will pair well with any outfit or occasion.
$169    
In stock
Only %1 left
2 pairs from $199
Discount auto-applied at checkout
3 pairs from $249
Discount auto-applied at checkout
Qty
Add to cart
Book an eye test
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
excluding prescription lenses
## About Poppy Frames
Meet Poppy, isn't she dreamy? A perfectly oversized, square-round, ideal for those with square and oval face shapes.
| Frame fit | Measurements |
| --- | --- |
| MEDIUM | 52 - 18 - 148 |
These measurements mean lens width, bridge, and temple length in millimetres (mm). They can be found on the inside of the temple arm. If you already have a pair that you like, you can compare it to these measurements.
### Made from Acetate
Oscar Wylee’s Poppy frame is a women’s square-round glasses frame that is a medium fit, ideal for those with square or oval face shapes. The Poppy frame is a simple, stylish, widely wearable frame that is perfect for any day of the week. The main specs of Oscar Wylee’s Poppy glasses frame including dimensions, shape, materials, lenses, nose fit and hinges are listed below.
| Poppy Frame Features | Poppy Frame Description | Dimensions | Shape | Materials | Lenses | Nose Fit | Hinges |
| --- | --- | --- | --- | --- | --- | --- | --- |
| The dimensions of the Poppy frame are measured in millimetres (mm) and are 52 - 18 - 148, meaning the lens width is 52 mm, the bridge is 18 mm and the temple length is 148 mm. |
| The Poppy frame is a square-round shape, well suited to medium faces. |
| Poppy glasses are made from a material called acetate. |
| The lenses that can be used in the Poppy frame are optical lenses, which include single-vision lenses, multifocal lenses and non-prescription lenses, which are plain and can have a filter like a blue light filter applied. |
| The nose fit of the Poppy frame is a low nose bridge fit. |
| The hinges in Poppy glasses are spring hinges, which are more flexible than other types of hinges and can extend past 90 degrees. |
Show All
### What Inspired the Frame Design of Oscar Wylee’s Poppy Glasses?
The Oscar Wylee Poppy frame design was inspired by current fashion trends as square-round shaped glasses are often in fashion and widely wearable.
## What to Know About Oscar Wylee’s Poppy Glasses?
There are many aspects of the Oscar Wylee Poppy frames that customers should know about, so they can decide whether this is the right frame for them. The Poppy frame is a square-round shape, suitable for many face shapes but particularly compatible with square or oval shaped faces. The Poppy frame’s simple design means that they are fashionable all year round. Poppy glasses feature the standard [parts of glasses such as a rim, temples, lenses, spring hinges and a low nose bridge fit.](https://www.oscarwylee.com.au/glasses/eye/part-of-glasses)
### What are the Types of Temple Tips or Earpieces Included with Oscar Wylee’s Poppy Glasses?
The type of temple tips or earpieces included in Oscar Wylee’s Poppy Glasses are made from acetate, like the rest of the frame.
### What Type of Nose Bridge do Oscar Wylee’s Poppy Glasses Have?
The type of nose bridge included in Oscar Wylee’s Poppy frame is a low nose bridge fit. A low nose bridge refers to a nose that sits in line, or below the pupils.
### What Type of Nose Pads are Included with Oscar Wylee’s Poppy Glasses?
Oscar Wylee’s Poppy frame does not include adjustable silicone nose pads.
### What Type of Lenses do Oscar Wylee’s Poppy Glasses Have?
The type of lenses that typically come with the Oscar Wylee Poppy [glasses frame are optical lenses. Optical lenses are glasses lenses that have a prescription within the lens to help correct vision issues such as myopia, hyperopia and astigmatism. Poppy glasses can also come with non-prescription lenses, with add-ons such as a blue light filter. Poppy frames are currently unavailable as sunglasses online, however, customers can customise in-store and add on tint or polarisation.](https://www.oscarwylee.com.au/glasses.html)
### What Material is Used for the Rim of Oscar Wylee’s Poppy Glasses?
The material used for the rim of Oscar Wylee’s Poppy glasses frames is acetate. The rim refers to the part of a glasses frame that holds the lenses.
### What Type of Hinges are Included with Oscar Wylee’s Poppy Glasses?
The type of hinges included with Oscar Wylee’s Poppy frames are spring hinges. A spring hinge in a glasses frame refers to hinges that are more flexible than normal hinges and can go slightly beyond 90 degrees. Spring hinges can provide a closer fit to the face.
## What Face Types are Most Suitable for Oscar Wylee’s Poppy Glasses?
The face types that are most suitable for Oscar Wylee’s Poppy frame are square or oval face types. The Poppy frame is a square-round shape, meaning that it complements the structure of oval faces particularly well. The rounded Poppy frames help to balance the features of an [oval face shape and heart face shape, bringing the eyes and brows forward in a flattering way. The Poppy frame is also suitable for a](https://www.oscarwylee.com.au/glasses/face-shapes/oval)[square face shape. Round frames help to soften the sharp and striking features of a square face type, bringing balance to the face. Although there are many](https://www.oscarwylee.com.au/glasses/face-shapes/square)[glasses for face shapes that may be considered more aesthetically suitable, it is important that people also choose the frames that make them feel most comfortable, and represent their personal style.](https://www.oscarwylee.com.au/glasses/face-shapes)
## What Size Options are Available for Oscar Wylee’s Poppy Glasses?
The size options available for Oscar Wylee’s Poppy frame are a medium-frame fit across all colours.
## What Materials are Used to Create Oscar Wylee’s Poppy Glasses?
The primary material used to create the Oscar Wylee Poppy frame is acetate. Acetate, also known as cellulose acetate, is a bioplastic, made from cotton fibres or wood pulp. At Oscar Wylee, acetate glasses are made by adding a dye to cellulose acetate, which is rolled into a sheet. The shape of the glasses is then cut from this sheet.
## What’s Included
## OW Case &amp; Cloth
Protective Case and Lens Cloth
Our high-quality glasses case and lens cloth are included with every purchase of an Oscar Wylee frame. The stylish, magnetic case is made from a hard shell. This sturdy and durable material keeps your glasses protected and safe, wherever you go. Ensure your lenses are clean and scratch-free with our OW microfibre cloth, specifically designed to ensure you have comfortable vision through your lenses.
Oscar Wylee offers:
* Free Shipping for Australian Orders
* 1 Year Warranty on frames and lenses
* Scratch resistance lens coating on all prescriptions
* UV-proof coating on all prescriptions
Health fund rebate: Once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. Learn more about [health funds](https://www.oscarwylee.com.au/health-funds.html).
## Make and Materials
The frames then go through cleaning and strict quality control, and many pairs of crafting hands to be hand-assembled and polished. After your frames have gone through the production process, they are individually examined and&nbsp;packed before making their way to you!Also known as cellulose acetate, these frames are traditionally hand-crafted by skilled craftsmen, with each frame passing through numerous stages of production and are hand-polished to ensure a glorious lustre.
## Warranty Information
### Warranty Information
### Warranty Information
Oscar Wylee provides a 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects. We will repair or replace faulty or defective frames or lenses free of charge for warranty claims made within 1 year of the delivery. We also offer repairs or replacement for problems experienced with vision during everyday use for claims made within 30 days of delivery. If the same product has been discontinued or is no longer available, then we may offer an exchange for a similar product or a refund.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Find a Store Location](https://www.oscarwylee.com.au/locations/full-store-list.html)