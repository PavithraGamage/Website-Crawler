# Source: https://www.oscarwylee.com.au/glasses/collection/bold.html

16 Products        
Showing 15 of 16
1. [](https://www.oscarwylee.com.au/amber-optical.html)
[Amber](https://www.oscarwylee.com.au/amber-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/amber-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/amber-optical.html)
2. [](https://www.oscarwylee.com.au/lincoln-optical.html)
[Lincoln](https://www.oscarwylee.com.au/lincoln-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/lincoln-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/lincoln-optical.html)
3. [](https://www.oscarwylee.com.au/beren-optical.html)
[Beren](https://www.oscarwylee.com.au/beren-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/beren-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/beren-optical.html)
4. [](https://www.oscarwylee.com.au/kristof-optical.html)
[Kristof](https://www.oscarwylee.com.au/kristof-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/kristof-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/kristof-optical.html)
5. [](https://www.oscarwylee.com.au/ezra-optical.html)
[Ezra](https://www.oscarwylee.com.au/ezra-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/ezra-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/ezra-optical.html)
6. [](https://www.oscarwylee.com.au/cliff-optical.html)
[Cliff](https://www.oscarwylee.com.au/cliff-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/cliff-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/cliff-optical.html)
7. [](https://www.oscarwylee.com.au/zeke-optical.html)
[Zeke](https://www.oscarwylee.com.au/zeke-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/zeke-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/zeke-optical.html)
8. [](https://www.oscarwylee.com.au/ford-optical.html)
[Ford](https://www.oscarwylee.com.au/ford-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/ford-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/ford-optical.html)
9. [](https://www.oscarwylee.com.au/serge-l-optical.html)
[Serge Large](https://www.oscarwylee.com.au/serge-l-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/serge-l-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/serge-l-optical.html)
10. [](https://www.oscarwylee.com.au/molly-optical.html)
[Molly](https://www.oscarwylee.com.au/molly-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/molly-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/molly-optical.html)
11. [](https://www.oscarwylee.com.au/bowery-optical.html)
[Bowery](https://www.oscarwylee.com.au/bowery-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/bowery-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/bowery-optical.html)
12. [](https://www.oscarwylee.com.au/serge-optical.html)
[Serge](https://www.oscarwylee.com.au/serge-optical.html)
$169.00    
[2 pairs from $199](https://www.oscarwylee.com.au/serge-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/serge-optical.html)
13. [](https://www.oscarwylee.com.au/jinky-optical.html)
[Jinky](https://www.oscarwylee.com.au/jinky-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/jinky-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/jinky-optical.html)
14. [](https://www.oscarwylee.com.au/mesa-optical.html)
[Mesa](https://www.oscarwylee.com.au/mesa-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/mesa-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/mesa-optical.html)
15. [](https://www.oscarwylee.com.au/kyle-optical.html)
[Kyle](https://www.oscarwylee.com.au/kyle-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/kyle-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/kyle-optical.html)
16 Products        
Showing 15 of 16
Choosing the Best Bold Glasses  Material, Width and Colour Suitability Price &amp; Shipping
## How to Choose the Best Bold Glasses?
To choose the best bold glasses, you should consider face shape, frame size, colour of the frames, match the glasses to your hairstyle, accessorise accordingly and accentuate your personality.
* Consider face shape:Consider face shape for choosing the best bold glasses. Certain frames pair well with certain face shapes as they balance out your features.
* Frame size: Consider frame size by trying them on and assessing how they fit. Bold frames can be any size.
* The colour of your frames:Consider the colour of your frames based on your everyday attire and the occasions you most frequently wear your frames. Bold frames are typically brightly coloured or have a fun, interesting pattern.
* Match to your Hairstyle:Match your frames to your hairstyle. Shorter textured hair will make your eyewear a focal point on the face, so you may prefer a thinner frame which will not overpower. Medium length hair is versatile when it comes to compatible frames, so you might want to consider thickness and style when it comes to glasses frames. Men with longer hairstyles can opt for thicker frames as these won’t be overshadowed by the length.
* Accentuate your Personality: Accentuate your personality with your bold glasses! The point of bold glasses is to stand out from the crowd! Pick a bright colour or pattern, size or shape that you feel best represents you!
[](https://www.oscarwylee.com.au/kyle-optical.html)
[Kyle](https://www.oscarwylee.com.au/kyle-optical.html)
$169    
Add to Cart
[Shop Kyle](https://www.oscarwylee.com.au/kyle-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/kyle-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/kyle-optical.html)
[](https://www.oscarwylee.com.au/zeke-optical.html)
[Zeke](https://www.oscarwylee.com.au/zeke-optical.html)
$169    
Add to Cart
[Shop Zeke](https://www.oscarwylee.com.au/zeke-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/zeke-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/zeke-optical.html)
[](https://www.oscarwylee.com.au/serge-optical.html)
[Serge](https://www.oscarwylee.com.au/serge-optical.html)
$169    
Add to Cart
[Shop Serge](https://www.oscarwylee.com.au/serge-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/serge-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/serge-optical.html)
[](https://www.oscarwylee.com.au/jinky-optical.html)
[Jinky](https://www.oscarwylee.com.au/jinky-optical.html)
$169    
Add to Cart
[Shop Jinky](https://www.oscarwylee.com.au/jinky-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/jinky-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/jinky-optical.html)
### How to Choose the Best Bold Glasses According to Skin Tone?
To choose the best bold glasses according to skin tone you should identify the undertone of your skin and pick a complementary colour. To identify your skin undertone you can look at the veins in your wrist. Generally blue or purple veins indicate cool toned skin. For cooler skin undertones, such as blue or purple, cooler frame colours like blue, silver, and green will complement your skin well. Green veins can indicate warm toned skin. For warmer skin undertones, such as yellow or peachy hues, select frames in similarly warm colours, like tortoiseshell, brown, gold, or other earthy tones. Neutral skin tones have both cool and warm undertones, making them relatively versatile in complementing colours.
### How to Choose the Best Bold Glasses According to Face Shape?
To choose the best bold glasses according to [face shape](https://www.oscarwylee.com.au/glasses/face-shapes) you should determine your face shape, and choose a glasses shape that fits it well. The most common face shapes are square, oval, pear and round, shapes. The types of face shapes and what glasses would suit them, are listed below.
* Square Faces: Square faces are characterised by an angular forehead and chin, and a face that is mostly in proportion. Round or oval glasses are [best for square faces](https://www.oscarwylee.com.au/glasses/face-shapes/square), as they soften the naturally sharp angles.
* Oval Faces: Oval faces are rounded and longer than they are wide. Angular or square frames are [best for oval faces](https://www.oscarwylee.com.au/glasses/face-shapes/oval); however, this face shape is considered versatile and may work with other shapes too.
* Pear Faces: Pear faces are characterised by a narrow forehead and wider jawline. The [best glasses for pear faces](https://www.oscarwylee.com.au/glasses/face-shapes/pear) are round and oval shapes.
* Round Faces: Round faces are circular in appearance with little to no angles. The [best glasses for the round face shape](https://www.oscarwylee.com.au/glasses/face-shapes/round) are rectangular or [square frames](https://www.oscarwylee.com.au/glasses/silhouette/square.html) as they provide contrast and angles for the soft curves of this face shape.
### How to Choose the Bold Glasses According to Eye Colour?
Eye colour should not play a major factor in choosing the best bold glasses. If a person wants guidance on what frames may look the best on them, it is best to look towards other physical features such as skin, hair colour, face and nose shape. If a person does want to consider eye colour however, brown or hazel eyes may work with tortoiseshell, gold or dark brown glasses to match the eyes. Blue or grey eyes will be complemented by silver, grey, or navy bold frames.
## Which Material is Best for Bold Glasses?
The best material for bold glasses is mostly dependent on personal style preferences, as well as lifestyle factors. The common materials that are best for bold glasses are titanium, acetate, bio-acetate and stainless steel. The best materials for bold glasses are listed below.
* Titanium: Titanium is a type of metal known for its lightweight qualities.
* Acetate: Acetate is a flexible cellulose material that can come in a variety of shapes, sizes and colours, perfect for bold glasses.
* Bio-acetate: Bio-acetate glasses are made mainly from a plant-based material such as wood pulp and cotton fibres. Bio-acetate can come in a variety of colours and designs and is an eco-friendly eyewear choice.
* Stainless Steel: Stainless steel bold glasses can provide a standout, yet stylish look.
### 1. Titanium Bold Glasses
[Titanium](https://www.oscarwylee.com.au/glasses/titanium) bold glasses are characterised by a metal appearance, their strength and [lightweight](https://www.oscarwylee.com.au/glasses/materials/lightweight.html) quality. The metal’s durability and sleek profile make it an effortlessly cool eyewear choice.
[](https://www.oscarwylee.com.au/franklin-optical.html)
[Franklin](https://www.oscarwylee.com.au/franklin-optical.html)
$169    
Add to Cart
[Shop Franklin](https://www.oscarwylee.com.au/franklin-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/franklin-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/franklin-optical.html)
### 2. Acetate Bold Glasses
Acetate is a type of cellulose material, a popular choice for bold glasses, as it can come in a variety of shapes, colours and sizes. [Acetate](https://www.oscarwylee.com.au/glasses/acetate-frame) is a flexible, often hypoallergenic material.
[](https://www.oscarwylee.com.au/serge-optical.html)
[Serge](https://www.oscarwylee.com.au/serge-optical.html)
$169    
Add to Cart
[Shop Serge](https://www.oscarwylee.com.au/serge-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/serge-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/serge-optical.html)
[](https://www.oscarwylee.com.au/duckworth-optical.html)
[Duckworth](https://www.oscarwylee.com.au/duckworth-optical.html)
$169    
Add to Cart
[Shop Duckworth](https://www.oscarwylee.com.au/duckworth-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/duckworth-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/duckworth-optical.html)
[](https://www.oscarwylee.com.au/molly-optical.html)
[Molly](https://www.oscarwylee.com.au/molly-optical.html)
$169    
Add to Cart
[Shop Molly](https://www.oscarwylee.com.au/molly-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/molly-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/molly-optical.html)
### 3. Bio-acetate Bold Glasses
Bio-acetate is an eco-friendly, bold glasses material, made mainly from a plant-based material such as wood pulp and cotton fibres. [Bio-acetate](https://www.oscarwylee.com.au/glasses/bio-acetate) frames can come in a variety of colours, shapes and sizes, perfect for bold glasses.
[](https://www.oscarwylee.com.au/lincoln-optical.html)
[Lincoln](https://www.oscarwylee.com.au/lincoln-optical.html)
$169    
Add to Cart
[Shop Lincoln](https://www.oscarwylee.com.au/lincoln-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/lincoln-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/lincoln-optical.html)
### 4. Stainless Bold Glasses
[Stainless steel](https://www.oscarwylee.com.au/glasses/materials/stainless-steel.html) is a metal that is a great material for bold glasses. Bold glasses made from stainless steel can be shaped into large, geometric shapes, giving the wearer a standout look.
[](https://www.oscarwylee.com.au/ford-optical.html)
[Ford](https://www.oscarwylee.com.au/ford-optical.html)
$169    
Add to Cart
[Shop Ford](https://www.oscarwylee.com.au/ford-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/ford-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/ford-optical.html)
[](https://www.oscarwylee.com.au/betty-optical.html)
[Betty](https://www.oscarwylee.com.au/betty-optical.html)
$169    
Add to Cart
[Shop Betty](https://www.oscarwylee.com.au/betty-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/betty-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/betty-optical.html)
[](https://www.oscarwylee.com.au/amber-optical.html)
[Amber](https://www.oscarwylee.com.au/amber-optical.html)
$169    
Add to Cart
[Shop Amber](https://www.oscarwylee.com.au/amber-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/amber-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/amber-optical.html)
### What does "Bold" Glasses Mean?
Bold glasses is a broad term, but generally means glasses that stand out and are eye-catching. Bold glasses can be a standout in many ways, including their colour, with many bold frames featuring bright pinks, yellows, reds and greens. Bold glasses can also be stand out in their size, with large, [oversized glasses](https://www.oscarwylee.com.au/glasses/silhouette/oversized.html) eye-catching. Bold glasses can also be in fun shapes, such as cat-eye or geometric.
## How to Buy Bold Glasses According to Width?
Oscar Wylee has a variety of bold glasses in varying widths to accommodate a range of face sizes. These width sizes include X-Small, Narrow, Medium or Wide. Read on for the various bold glasses widths to consider before purchasing.
* X-Small: X-small is the smallest size we sell at Oscar Wylee. X-small is well suited to kids, or those with very small, narrow faces.
* Narrow: Narrow width frames are available at Oscar Wylee. Our narrow frames are good for petite and narrow faces.
* Medium: Medium frames are available at Oscar Wylee in a range of colours and shapes. Medium frames are well suited to those with average, or medium sized faces.
* Wide: Wide frames are available at Oscar Wylee. Wide frames are good for those with wider, larger faces.
[](https://www.oscarwylee.com.au/jorja-optical.html)
[Jorja](https://www.oscarwylee.com.au/jorja-optical.html)
$169    
Add to Cart
[Shop Jorja](https://www.oscarwylee.com.au/jorja-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/jorja-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/jorja-optical.html)
[](https://www.oscarwylee.com.au/jinky-optical.html)
[Jinky](https://www.oscarwylee.com.au/jinky-optical.html)
$169    
Add to Cart
[Shop Jinky](https://www.oscarwylee.com.au/jinky-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/jinky-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/jinky-optical.html)
### Which Colour Pattern is Best for Bold Glasses Frames?
There are various colour patterns that can be best for a bold glasses frame. Some bold glasses colour patterns include solid, tortoise transparent, and two-toned. Read on for the various colour patterns that could be best for an eye-catching bold glasses frame.
* Solid: Solid colour frames can be a bold eyewear choice, particularly in bright colours such as green, yellow, and red. These can add an eye-catching flair to your outfit.
* Tortoise: Tortoiseshell patterns offer a blend of often warm tones. For a more bold tortoiseshell look, you may want to choose a frame that has pops of colour in contrast to the typical warm tones, such as blues and purples.
* Transparent: Transparent, clear frames are popular due to their minimalist, modern look, offering subtle style and practicality.
* Two-toned: Two-toned glasses create an eye-catching contrast and visual interest for those who want a bold pop of colour to their outfits.
[](https://www.oscarwylee.com.au/cliff-optical.html) [](https://www.oscarwylee.com.au/parker-l-optical.html) [](https://www.oscarwylee.com.au/serge-optical.html)
[](https://www.oscarwylee.com.au/cliff-optical.html) [](https://www.oscarwylee.com.au/parker-l-optical.html) [](https://www.oscarwylee.com.au/serge-optical.html)
### Which Colour is Best for Bold Glasses?
Ultimately, the best colour for your bold glasses is entirely up to your sense of style. At Oscar Wylee we have a variety of bold colours such as blue, gold, green, red, purple, pink, yellow and white. Read on for the various colours that can be best for men’s glasses frames.
* Blue: Blue bold frames add stylish colour, whether a baby blue or rich navy, for a visually appealing aesthetic.
* Gold: Gold frames bring an elegant and luxe flair to any outfit, making it a more unconventional yet striking bold glasses colour.
* Green: Green bold glasses add a rich charm and a vibrant beauty to your accessories.
* Red: Red glasses are a truly bold statement, creating an arresting look for the wearer.
* Purple: Purple frames exude a regal, unique look, perfect for an elegant and truly eye-catching accessory.
* Pink: Pink frames can be a fun, feminine option for bold glasses, such as a hot pink frame for a Barbie inspired look.
* Yellow: Yellow bold frames exude a brightness, ready to uplift any outfit with its head-turning colour.
* White: White frames offer a clean, modish look. It can easily transform into a bold frame when paired with black or navy coloured clothing for a stunning contrast.
[](https://www.oscarwylee.com.au/mesa-optical.html) [](https://www.oscarwylee.com.au/parker-l-optical.html) [](https://www.oscarwylee.com.au/nina-optical.html) [](https://www.oscarwylee.com.au/zola-optical.html) [](https://www.oscarwylee.com.au/parker-optical.html) [](https://www.oscarwylee.com.au/jessie-sunglasses.html) [](https://www.oscarwylee.com.au/paloma-sunglasses.html)
[](https://www.oscarwylee.com.au/mesa-optical.html) [](https://www.oscarwylee.com.au/parker-l-optical.html) [](https://www.oscarwylee.com.au/nina-optical.html) [](https://www.oscarwylee.com.au/zola-optical.html) [](https://www.oscarwylee.com.au/parker-optical.html) [](https://www.oscarwylee.com.au/jessie-sunglasses.html) [](https://www.oscarwylee.com.au/paloma-sunglasses.html)
## What Types of Nose Shapes Work Best with Bold Glasses?
Any type of nose shape can generally work well with bold glasses and will just depend on the wearer’s personal preferences. Bold glasses can be suitable for any type of nose shape and may depend more on face shape and frame shape in terms of suitability. The different [types of nose shapes](https://www.oscarwylee.com.au/glasses/nose-types) can include a straight nose, an aquiline nose, a button nose, a wide nose, a celestial nose, a Nixon nose and a round nose.
### How do Bold Glasses Compare to Oversized Glasses?
Bold glasses and oversized glasses can sometimes mean the same thing, as oversized glasses can be considered bold. Bold glasses refer to glasses that stand out and are eye-catching, whether in size, shape, or colour. Oversized glasses refer to eyewear with big frames that take up a larger portion of the face compared to standard-sized glasses. Bold glasses are typically large in frame size however, they don’t always have to be as they can be small yet have bold, striking colour. Oversized glasses always have larger frames.
### Are Bold Glasses Suitable for Sports and Active Use?
Yes, there are bold glasses in our [active eyewear collection](https://www.oscarwylee.com.au/sunglasses/collection/active-collection.html). Active eyewear refers to glasses that are made from materials and have features that can withstand the rough and tumble of physical activity. The designs of these are often oversized with eye-catching colours, allowing for bold eyewear options.
## What are the Price Factors for Bold Glasses?
The price factors for bold glasses at Oscar Wylee will vary depending on elements such as glasses material, add-ons and lens types. One pair of bold glasses starts from $169, 2 pairs from $199 and 3 pairs from $249. It should be noted that lens thickness and other add-ons will affect overall pricing. For a full price guide, read [here](https://www.oscarwylee.com.au/price-guide/).
### What is the Duration of Shipment for Bold Glasses?
Oscar Wylee offers domestic shipping for bold glasses ordered on the website. Typically, deliveries will usually be dispatched within 7-10 business days. An email will be sent to you confirming the order alongside an order tracking link. If you are having them delivered to your home, this can take up to 2 weeks.
### What is the Refund Policy for Bold Glasses?
The return or refund policy for bold glasses will depend on whether they are prescription or non-prescription and/or the type of prescription. Since each pair of glasses is customised based on your prescription, Oscar Wylee does not offer any exchange or refund for change of mind on prescription items. For non-prescription over the counter items, we can offer exchanges within 14 days from receiving grants if they are still in satisfactory condition. Oscar Wylee offers a 1 year warranty from the date of delivery covering manufacturing faults or defects in frames and lenses, with free repair or replacement during this period. We also provide repair or replacement for vision-related issues experienced during everyday use within 30 days of delivery. If a product has been discontinued, an exchange for a similar item or a refund may be offered. This warranty operates in addition to your rights under Australian Consumer Law.
### How does Oscar Wylee Manufacture Bold Glasses?
Our high quality bold frames are manufactured through a careful blend of quality materials, precision engineering, and skilled assembly. Acetate frames start with bio-based cellulose acetate derived from natural fibres, cut to create both solid and uniquely patterned designs. The front of each acetate frame is then milled from a single block and shaped, polished, and refined through multiple hand-finished steps. Metal frames start as fine wire that’s formed, welded, and assembled piece by piece for strength and durability. After shaping, all frames undergo extensive polishing and tumbling for a smooth, comfortable finish. Hinges, rivets, and temples are fitted by hand, lenses are individually cut to match each frame, and every pair is thoroughly inspected to ensure it meets our quality standards before it reaches you. Here at [Oscar Wylee](https://www.oscarwylee.com.au/), we pride ourselves on the expert design and production of our frames and strive to showcase professionalism in every detail.
How does Oscar Wylee Manufacture Bold Glasses?
Oscar Wylee manufactures bold glasses by following a thorough production process.
First Oscar Wylee frames are cut. They are then polished and
put through a tumbling wheel. They are then constructed, a process whereby rivets and hinges are added, the core
wire is inserted into the temple, and the temples are
individually hand screwed to the front of the frame. Once this
is complete, the lenses are fitted and the Oscar Wylee
final product is thoroughly quality checked.

[Prescription Glasses](https://www.oscarwylee.com.au/glasses.html)
[Women’s Glasses](https://www.oscarwylee.com.au/glasses/collection/womens-glasses.html)
[Men’s Glasses](https://www.oscarwylee.com.au/glasses/collection/mens-glasses.html)
[Glasses for Seniors](https://www.oscarwylee.com.au/glasses-for-seniors.html)
[Glasses for Kids](https://www.oscarwylee.com.au/glasses/collection/kids-collection.html)