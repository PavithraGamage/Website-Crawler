# Source: https://www.oscarwylee.com.au/vs-specsavers

# Oscar Wylee vs Specsavers Glasses and Eyewear
Published on February 13th, 2025
Updated on June 17th, 2025
Oscar Wylee is an Australian founded and owned eyewear company that first
launched online in 2012, with its headquarters in Sydney, Australia. Oscar Wylee then branched into physical stores, with its first store
opening in Australia in 2015. Oscar Wylee went on to open their first two
stores in New Zealand in 2019 followed by their first store in Canada in
2021. Oscar Wylee now has over 130 stores across Australia, Canada and New
Zealand. Contrastingly,
Specsavers was founded by couple Doug and Mary Perkins in 1983,
officially launching in 1984 on Guernsey Island, located in the English
Channel. It expanded across Europe and the US and made its way to Australia in
2008. Specsavers has over 2600 stores worldwide as written in their 2022-23
Annual Review. Oscar Wylee and Specsavers are both widely known eyewear
companies that provide a variety of prescription and non-prescription
glasses.
Book an Eye Test With Oscar Wylee Today
We have knowledgeable optometrists at all our stores ready to help.
[Book an Oscar Wylee Eye Test](https://www.oscarwylee.com.au/booking)
[Distinctions between Oscar Wylee and Specsavers](#Advantages)
[Specialised Lenses in Oscar Wylee and Specsavers](#Specialised-Lenses)
[Product Range Differences](#Difference)
## What are Some of the Distinctions between Oscar Wylee and Specsavers?
Some distinctive characteristics of Oscar Wylee are their
in-house designed glasses and free eye test for international students
initiative. Oscar Wylee’s glasses are all in-house designed glasses.
Incorporating both global and local inspiration, and past and present
aesthetics, they are hand-assembled and hand-checked ensuring a high
standard of care. This makes Oscar Wylee’s glasses of a consistent
quality with a distinct individuality from more notable brands. Both
Specsavers and Oscar Wylee accept bulk billing from Medicare and private
health insurance. Oscar Wylee extends extra assistance to international
students in Australia and New Zealand. If students buy a pair of Oscar
Wylee glasses, then they can receive a free eye test on the same day.
Some of Specsavers’ distinctive characteristics compared to Oscar Wylee
include their
branded glasses, audiology services and a larger target market.
Specsavers offers branded eyewear, such as Ray-Ban, Mimco and Hugo Boss.
This can be favourable to customers who desire the reputability and
appeal of branded frames. Specsavers provide audiology services such as
hearing tests and hearing-related products such as hearing aids. This
can be convenient for customers who seek services for maintaining both
eye and hearing health. Specsavers have a larger market share and
customer base in Australia, Canada and New Zealand as well as the other
continents they operate in such as Europe and the US. With a significant
customer base, around 40 million plus worldwide, Specsavers can reach a
more expansive target market with their numerous stores.
### What Stylish Eyewear Options Does Oscar Wylee Offer?
Some stylish eyewear options from Oscar Wylee are
Serge, Drew, Parker and Alya. From vintage-inspired, modern,
practical and minimalist styles, there is a pair for every preference.
Read more about some of the stylish eyewear options at Oscar Wylee
listed below.
* Serge: Serge is a classic frame with
a timeless square shape and acetate make. Its unisex, modern appeal
makes it an option for anyone who wants a bold accessory.
* Drew: Drew is a trendy transparent
frame with a distinct square-round frame. The acetate and stainless
steel build makes for an eye-catching and durable pair.
* Parker: Parker is a versatile pair,
as its square-round, unisex frame will suit many faces and many
occasions.
* Alya: The unique Alya frame has a
striking round frame and TR90 build, for a lightweight, stylish
look.
[](https://www.oscarwylee.com.au/serge-optical.html)
[Serge](https://www.oscarwylee.com.au/serge-optical.html)
$169    
Add to Cart
[Shop Serge](https://www.oscarwylee.com.au/serge-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/serge-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/serge-optical.html)
[](https://www.oscarwylee.com.au/drew-optical.html)
[Drew](https://www.oscarwylee.com.au/drew-optical.html)
$169    
Add to Cart
[Shop Drew](https://www.oscarwylee.com.au/drew-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/drew-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/drew-optical.html)
[](https://www.oscarwylee.com.au/parker-optical.html)
[Parker](https://www.oscarwylee.com.au/parker-optical.html)
$169    
Add to Cart
[Shop Parker](https://www.oscarwylee.com.au/parker-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/parker-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/parker-optical.html)
[](https://www.oscarwylee.com.au/alya-optical.html)
[Alya](https://www.oscarwylee.com.au/alya-optical.html)
$169    
Add to Cart
[Shop Alya](https://www.oscarwylee.com.au/alya-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/alya-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/alya-optical.html)
*Serge, Drew, Parker and Alya are all Oscar Wylee frames that are
available online and in-store
### Why Choose Oscar Wylee or Specsavers for Specialised Lenses?
Oscar Wylee and Specsavers
both have specialised lenses for customers to add to their
eyewear.Oscar Wylee has extra thin, super thin and ultimate thin lens
options alongside their standard lens to accommodate stronger
prescriptions. Oscar Wylee have photochromic lenses, tinted lenses,
polarised lenses and prism lenses. Oscar Wylee also has lens add-ons.
Anti-reflective lenses are included with every lens type which is
scratch-resistant and reduces reflection. The premium anti-reflective
lens coating add-on does this and is also anti-static, scratch, and
smudge resistant, while the blue light filter reduces potentially
harmful blue light from digital screens. Specsavers has a
scratch-resistant coating that comes with every lens. The Ultraclear
Superclean lens option is also scratch resistant as well as being
anti-reflective, water-repellent, smudge resistant, antistatic and
providing a blue light filter to reduce blue light that emits from
digital screens. Specsavers has other lenses such as thin lenses, sun
tint and UV, Reaction photochromic lenses and polarizing lenses. They
have ones that Oscar Wylee does not carry such as specialist
multifocal lenses for lifestyle habits such as SuperDigital for those
who use devices frequently, SuperDrive designed for driving, and
SuperTask for up-close work.
### Do Oscar Wylee and Specsavers Offer Blue Light Blocking Lenses?
Both Oscar Wylee and Specsavers offer
[blue light blocking lenses](https://www.oscarwylee.com.au/glasses/blue-light/review). Oscar Wylee allows glasses wearers to add a blue light filter to
any optical prescription up to 1.67 index, or to non-prescription
glasses. The Oscar Wylee Blue Light Filter product includes a basic
anti reflective coating. Specsavers offer a blue light treatment to
reduce blue light with their Ultraclear Superclean lens option.
#### Do Oscar Wylee or Specsavers Offer Hearing Aids?
Specsavers offers hearing aids alongside hearing tests. Oscar Wylee
does not offer hearing aids or hearing tests.
#### Do Oscar Wylee or Specsavers offer Contact Lenses?
Specsavers offer a variety of contact lenses. Oscar Wylee does not
offer contact lenses.
### How Long have Oscar Wylee and Specsavers been in Business?
Oscar Wylee has been in business since 2012, initially starting
as an E-commerce store. Oscar Wylee’s first physical store opened in
Chatswood Interchange in 2015. Contrastingly,
Specsavers has been in business since 1984, starting with
physical stores in the UK and Guernsey, separate from the
headquarters. Specsavers has since expanded, now operating across
three continents in numerous countries.
Update Your Prescription Today
See our team in-store for help with updating your prescription. We
offer bulk billed eye tests and quality eye care assistance.
[Find an Oscar Wylee Store](https://www.oscarwylee.com.au/locations/full-store-list.html)
### What Products and Services does Oscar Wylee Offer?
Oscar Wylee provides
prescription glasses, non-prescription glasses, and
[sunglasses](https://www.oscarwylee.com.au/sunglasses.html). services at Oscar Wylee include bulk billed
eye tests and a lifetime guarantee of adjustments or professional
cleaning
for your Oscar Wylee glasses.
#### Does Oscar Wylee have In-House Eye Specialists?
Yes, Oscar Wylee
has in-house
[eye specialists](https://www.oscarwylee.com.au/eye-health/optometrist-vs-ophthalmologist.html). These are
[optometrists](https://www.oscarwylee.com.au/find-optometrist)
who conduct extensive eye tests, including kids' eye tests, diagnose
eye problems and write prescriptions. Oscar Wylee also has retail
staff that provide stylistic assistance so customers can pick out the
glasses that suit their face and style preferences.
#### Can you Order Prescription Glasses Online from Oscar Wylee?
Yes, you can order prescription glasses online from Oscar
Wylee. This can be done directly on the website during checkout. You
can provide them with your optician’s contact information and Oscar
Wylee will get in touch with them, upload a copy, or click "send
later" and send Oscar Wylee a copy via email. These can be delivered
to your doorstep or in-store.
## What Products and Services do Specsavers offer?
According to the Specsavers AU website, as of March 2025, their products
include
prescription glasses, designer glasses, sunglasses, non-prescription
glasses, contact lenses, hearing aids. Specsavers' services include eye tests and hearing tests.
### What Brands does Specsavers carry?
Specsavers carry some notable brands. These include their
in-house range, Ted Baker, Tommy Hilfiger, Vivienne Westwood,
Mimco, and Marc Jacobs
to name a few.
#### Do Specsavers Have In-House Eye Specialists?
Specsavers
employ in-house specialists, namely optometrists that conduct
eye tests including kids’ eye tests, write and dispense
prescriptions and offer advice on eye health. Specsavers also employ
retail staff in their stores that provide stylistic assistance for
customers to pick a suitable pair of glasses.
## How do the Product Ranges of Oscar Wylee and Specsavers Differ?
The product ranges of Oscar Wylee and Specsavers differ through their
collections, eyewear categories and glasses brands. The product
range differences of both companies are listed in more detail below.
* Collections: The eyewear collections
of Oscar Wylee and Specsavers differ from each other. Oscar Wylee’s
eyewear collections will often focus on a feature or aesthetic. For
example, the Memory Twist Collection features glasses made from Memory
Metal material, while the Muse Collection focuses on bold,
eye-catching designs. Specsavers features collaborative collections
such as the sportier Adidas range and the feminine Florence by Mills.
* Eyewear categories: The eyewear
categories for Oscar Wylee and Specsavers are organised differently on
the website. In Oscar Wylee, they are organised by glasses and
sunglasses, which are again organised by gender, material and frame
shape. Contrastingly, Specsavers organises their glasses by type,
collection if applicable, age group and gender as of March 2025.
* Glasses brands: The glasses brands
that Oscar Wylee and Specsavers have in their catalogue differ. Oscar
Wylee produces in-house designed eyewear. These pieces take
inspiration from current trends and vintage pieces, allowing for an
original, individual look for each wearer. Specsavers also offer their
own range of glasses alongside other branded glasses such as
Quiksilver and HUGO for those who prefer brand names.
### Where are Oscar Wylee Stores Located?
Oscar Wylee has stores located in
Australia, Canada and New Zealand. The head office is located at
320 Sussex St, Sydney, Australia. There are currently more than 130 stores across Australia, New
Zealand and Canada.
#### Can Oscar Wylee Ship Their Products Globally?
Oscar Wylee does not ship its products globally. However,
customers are eligible for domestic
[shipping](https://www.oscarwylee.com.au/shipping.html)
in Australian, New Zealand and Canada. In Australia, all domestic
shipping orders are free.
### Where are Specsavers Stores Located?
Specsavers stores are located across numerous countries such as the
UK, Ireland, Australia and New Zealand, Canada and other European
countries. The company’s headquarters is located in Guernsey, an island in the
English Channel.
#### Can Specsavers Ship Their Products Globally?
At the time of this article being written, Specsavers
do not ship their products globally to customers outside the
countries where they have physical stores. According to the Specsavers website, you will need to ship
domestically from a country where they operate such as the UK or
Australia.
### Which Brand offers a Better Selection of Glasses, Oscar Wylee or
Specsavers?
The brand that offers the better selection of glasses
will be subjective, depending on the individuals’ stylistic
preferences. Specsavers has a wider catalogue which includes branded glasses.
Oscar Wylee’s catalogue consists solely of a wide variety of Oscar
Wylee designed glasses that take inspiration from a variety of present
and emerging trends, suited to every face.
## What are the Main Alternatives to Specsavers?
The main alternatives to Specsavers include
Oscar Wylee, EyeBuyDirect, OPSM, 1001 Optometry and Bailey Nelson. These are the main alternatives to Specsavers, and their
distinguishing characteristics are listed below.
* Oscar Wylee: Oscar Wylee creates
solely in-house glasses for distinguished eyewear that are stylish,
affordable, and suited to every demographic.
[Oscar Wylee](https://www.oscarwylee.com.au/) also offers a
free eye test for international students when they purchase any pair
of glasses on the same day.
* EyeBuyDirect: [EyeBuyDirect](https://www.oscarwylee.com.au/vs-eyebuydirect)
is a budget-friendly eyewear brand that is solely based online, with
home try-ons options for many frame styles.
* OPSM: [OPSM](https://www.oscarwylee.com.au/vs-opsm) is an
Australian eyewear company with a range of glasses, lenses and optical
technology. OPSM also has a global eyecare charity, OneSight.
* 1001 Optometry: [1001 Optometry](https://www.oscarwylee.com.au/vs-1001-optometry)
offers many brands of glasses, sunglasses and contact lenses. Some of
their notable branded glasses include Prada and Gucci.
* Bailey Nelson: [Bailey Nelson](https://www.oscarwylee.com.au/vs-bailey-nelson)'s wide glasses range are designed in Australia. They also have
accessories such as clip-on's which are polarized lenses that can be
attached to the front of prescription glasses using a simple clip
mechanism.
* Warby Parker: [Warby Parker](https://www.oscarwylee.com.au/vs-warby-parker)
is an American eyewear brand with a variety of glasses collections and
helpful customer features such as virtual try on's.
Book an Oscar Wylee eye test today
At Oscar Wylee we offer bulk billed eye tests for all eligible
Medicare card holders.
[Book an Oscar Wylee eye test](https://www.oscarwylee.com.au/booking)
Major Health Funds Accepted In-store
For the purchase of frames and lenses, use your private health fund
insurance to minimize how much you pay from your own pocket.
[Explore Health funds](https://www.oscarwylee.com.au/health-funds.html)