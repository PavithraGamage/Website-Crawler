# Source: https://www.oscarwylee.com.au/ash-sunglasses.html

# Ash
1
## Frame Design of Ash Sunglasses
The frame design of Oscar Wylee’s Ash sunglasses is characterised by a chic oval and round shape, a low nose bridge, and bio acetate frame. Ash glasses are a woman's statement frame that will work with any outfit, day to night.
$169    
In stock
Only %1 left
2 pairs from $199
Discount auto-applied at checkout
3 pairs from $249
Discount auto-applied at checkout
* 2 &amp; 3 Pair pricing applies to non-prescription sunglasses only. Prescription sunglasses incur additional charges.    
[Non-Prescription](https://www.oscarwylee.com.au/ash-sunglasses.html#)
Qty
Prescription
Book an eye test
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
excluding prescription lenses
## About Ash Sunglasses
Ash knows how to keep her cool. These subtle geometric frames, coupled with metallic temple detailing, are effortlessly glam, perfect for braving the heat and the spotlight.
| Frame fit | Measurements |
| --- | --- |
| WIDE | 54 - 19 - 145 |
These measurements mean lens width, bridge, and temple length in millimetres (mm). They can be found on the inside of the temple arm. If you already have a pair that you like, you can compare it to these measurements.
### Made from Bio Acetate
Oscar Wylee’s Ash frame is a women's oval and round sunglasses frame that is perfect for those with square, oval, and heart face shapes. The Ash frame is a glamorous, yet wearable frame that can be worn every day. The main specs of Oscar Wylee’s Ash glasses frame, including dimensions, shape, materials, lenses, low nose fit, and hinges, are listed below.
Filter category 2 (Cioccolato and Cacao Tortoise only) - General purpose sunglasses. Good protection against sunglare. Good UV Protection. Not suitable for driving in twilight, at night or under dull conditions
These frames come with tinted lenses. An additional $30 will be added to your order total for prescription orders.
| Ash Frame Features | Ash Frame Description | Dimensions | Shape | Materials | Lenses | Nose Fit | Hinges |
| --- | --- | --- | --- | --- | --- | --- | --- |
| The dimensions of the Ash frame are measured in millimetres (mm) and are 54 - 19 - 145, meaning the lens width is 54 mm, the bridge is 19 mm, and the temple length is 145 mm. |
| The Ash frame is an oval and round shape, well suited to wide faces. |
| Ash glasses are made from bio acetate. |
| The lenses that can be used in the Ash frame are sunglass lenses, which provide UV protection. Prescription lenses are also available to purchase for the Ash sunglass frame, both online and in-store. |
| The nose fit of the Ash frame is a low nose bridge fit. |
| The hinges in Ash glasses are normal hinges, also known as standard or barrel hinges. |
Show All
### What Inspired the Frame Design of Oscar Wylee's Ash Glasses?
The Oscar Wylee Ash frame design was inspired by current fashion trends, as oval and round shapes are often in fashion.
## What to Know About Oscar Wylee's Ash Sunglasses?
There are many aspects of the Oscar Wylee Ash frames that customers should know about, so they can decide whether this is the right frame for them. The Ash frame is a women's oval and round shaped frame. Oscar Wylee's Ash frame is suitable for many face shapes, but particularly compatible with square, oval and heart face shapes. The Ash frame's eye-catching design means that they are fashionable all year round. Ash glasses feature the standard [parts of glasses](https://www.oscarwylee.com.au/glasses/eye/part-of-glasses), such as a rim, temples, lenses, hinges and a low nose bridge.
### What are the Types of Temple Tips or Earpieces Included with Oscar Wylee's Ash Glasses?
The type of temple tips or earpieces included in Oscar Wylee's Ash Glasses are made from bio acetate.
### What Type of Nose Bridge do Oscar Wylee's Ash Glasses Have?
The type of nose bridge included in Oscar Wylee's Ash frame is a low nose bridge fit.
### What Type of Nose Pads are Included with Oscar Wylee's Ash Glasses?
Oscar Wylee's Ash frame does not include adjustable silicone nose pads.
### What Type of Lenses do Oscar Wylee's Ash Sunglasses Have?
The lenses that can be used in the Ash frame are sunglass lenses, which provide UV protection. UV protection lenses block harmful ultraviolet rays, safeguarding eyes from damage. The Ash frame comes in Filter Category 2. These are general purpose sunglasses. Good protection against sunglare. Good UV Protection. Not suitable for driving in twilight, at night, or under dull conditions. Prescription lenses are also available for the Ash sunglasses frame, both online and in-store.
### What Material is Used for the Rim of Oscar Wylee's Ash Glasses?
The material used for the rim of Oscar Wylee's Ash glasses frames is bio acetate. The rim refers to the part of a glasses frame that holds the lenses.
### What Type of Hinges are Included with Oscar Wylee's Ash Glasses?
The type of hinges included with Oscar Wylee's Ash frames are normal hinges, also known as standard or barrel hinges.
## What Face Types are Most Suitable for Oscar Wylee's Ash Glasses?
The face types that are most suitable for Oscar Wylee's Ash frame are square, oval, and heart face shapes. The Ash frame is an oval and round shape, meaning that it complements the structure of square, oval, and heart faces particularly well. The oval and round Ash frames help to balance the features of a [square face shape](https://www.oscarwylee.com.au/glasses/face-shapes/square), an [oval face shape](https://www.oscarwylee.com.au/glasses/face-shapes/oval), or a [heart face shape](https://www.oscarwylee.com.au/glasses/face-shapes/heart), highlighting without overemphasising them. Although there are many [glasses for face shapes](https://www.oscarwylee.com.au/glasses/face-shapes) that may be considered more aesthetically suitable, it is important that people also choose the frames that make them feel most comfortable and represent their personal style.
## What Size Options are Available for Oscar Wylee's Ash Glasses?
The size option available for Oscar Wylee's Ash frame is a wide frame fit across all colours.
## What Materials are Used to Create Oscar Wylee's Ash Glasses?
The primary material used to create the Oscar Wylee Ash frame is bio acetate. Bio acetate is predominantly made from renewable plant matter such as wood pulp, for a more eco-conscious foundation.
## What’s Included
## OW Case &amp; Cloth
Protective Case and Lens Cloth
Our high-quality glasses case and lens cloth are included with every purchase of an Oscar Wylee frame. The stylish, magnetic case is made from a hard shell. This sturdy and durable material keeps your glasses protected and safe, wherever you go. Ensure your lenses are clean and scratch-free with our OW microfibre cloth, specifically designed to ensure you have comfortable vision through your lenses.
Oscar Wylee offers:
* Free Shipping for Australian Orders
* 1 Year Warranty on frames and lenses
* Scratch resistance lens coating on all prescriptions
* UV-proof coating on all prescriptions
Health fund rebate: Once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. Learn more about [health funds](https://www.oscarwylee.com.au/health-funds.html).
## Make and Materials
Eco-consciousness meets durability with bio-acetate. Replacing unbiodegradable plasticisers with plant based alternatives, bio-acetate allows a biodegradable lens frame, leaving a reduced carbon footprint on the environment.The frames then go through cleaning and strict quality control, and many pairs of crafting hands to be hand-assembled and polished. After your frames have gone through the production process, they are individually examined and&nbsp;packed before making their way to you!
## Warranty Information
### Warranty Information
### Warranty Information
Oscar Wylee provides a 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects. We will repair or replace faulty or defective frames or lenses free of charge for warranty claims made within 1 year of the delivery. We also offer repairs or replacement for problems experienced with vision during everyday use for claims made within 30 days of delivery. If the same product has been discontinued or is no longer available, then we may offer an exchange for a similar product or a refund.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Find a Store Location](https://www.oscarwylee.com.au/locations/full-store-list.html)