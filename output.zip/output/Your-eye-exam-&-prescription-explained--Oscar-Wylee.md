# Source: https://www.oscarwylee.com.au/eye-health/your-eye-test-explained.html

# Your eye test explained
An eye test is not just about prescriptions. Our optometrists are eye health professionals who can help identify changes or problems with your vision.
[Eye test near me](https://www.oscarwylee.com.au/booking)
## What to expect during an eye test
Wondering what happens during an eye exam? Your optometrist will tailor the test according to your visual needs and lifestyle, but these are the general process
1. ## Check-in
When you arrive for your eye test, we will confirm your booking details, including: Medicare card, health fund cards, visual history (includes reading your prescription from your current eyewear), any eye concerns or needs you might have.
2. ## Pre-testing
Screening tests are performed prior to seeing the optometrist, who will review the results. This includes an auto-refraction (where a machine estimates your glasses prescription), eye pressure measurement and photographs of the retina (back surface of the eye).
3. ## Eye testing &amp; optometrist consultation
After discussing any eye or vision concerns that you are experiencing, the optometrist performs a series of tests to assess your vision. They will check if your eyesight can be improved with prescription lenses, and evaluate the health of the front and back of the eyes.This enables the optometrist to make recommendations for glasses and flag eye health issues. In some cases, they may also suggest extra tests, or a referral to an ophthalmologist (eye specialist), for further investigation.
## How to understand your eye test results
If you need glasses, a prescription will specify the exact strength which is needed to correct your vision. Higher values indicate a stronger prescription. The glasses prescription usually consists of 3 main numbers:
* SPH (Sphere)Indicates the amount of long-sightedness (denoted with a “+” symbol), or short-sightedness (denoted with a “-” symbol).
* CYL (Cylinder)Represents the amount of astigmatism (denoted with a “-” symbol).
* AXISSpecifies the angle between 0-180 degrees which corrects the astigmatism.
There may be other numbers which form part of your prescription, including:
* ADDShows the amount of magnification required for close vision (denoted with a “+” symbol).
* Int ADD (Intermediate ADD)Representing the amount of magnification required for computer vision, which is typically about 70cm away.
* PrismSometimes needed to improve double vision or assist with focusing, and can be denoted with directions such as base up, down, in, and out.
* PD (Pupil Distance)Measurement in millimetres of the distance between the eyes and used to ensure that your lenses are positioned properly to give you clear vision. PD value is required when ordering a new pair of glasses.
Due for an eye test? Book now:
[Eye test near me](https://www.oscarwylee.com.au/booking)
We recommend that everyone should have an eye test with an optometrist at least once every 2 years.
Oscar Wylee offers bulk billed eye test, so there are no out-of-pocket expenses for eligible Medicare card holders.
[](https://www.oscarwylee.com.au/eye-health/eye-test-info.html)
###### Eye test information
Common questions about eye test answered by our optometrist. Find out more about eye exam cost, duration, and if you are eligible for a free eye test.
[Find out more](https://www.oscarwylee.com.au/eye-health/eye-test-info.html)
[](https://www.oscarwylee.com.au/eye-health/common-eye-conditions.html)
###### Common eye conditions
It's a good idea to know the symptoms of common eye conditions. Find out what to look out for and how we can help.
[Find out more](https://www.oscarwylee.com.au/eye-health/common-eye-conditions.html)
[](https://www.oscarwylee.com.au/eye-health.html)
###### Eye Health
Your eyes can tell a lot about your general health. It's important to keep your eye health in check with a regular eye examination.
[Find out more](https://www.oscarwylee.com.au/eye-health.html)
[](https://www.oscarwylee.com.au/booking/)
###### Book an eye test
Oscar Wylee eye tests are bulk billed through Medicare. This means eligible Medicare card holders get a free eye test.
[Book online](https://www.oscarwylee.com.au/booking/)