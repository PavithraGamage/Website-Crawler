# Source: https://www.oscarwylee.com.au/glasses/eye/nystagmus

# Nystagmus: Definition, Types, Causes, Symptoms, Diagnosis, and Treatment
Published on July 21st, 2023
Updated on March 21st, 2025  
Australia   
[Australia](https://www.oscarwylee.com.au/glasses/eye/nystagmus)
New Zealand

[Canada](https://oscarwylee.ca/glasses/eye/nystagmus)
[Canadian French](https://oscarwylee.ca/fr/lunettes/oeil/nystagmus)
The nystagmus definition is a condition that affects vision, causing the eyes to involuntarily and rapidly move in up and down (vertical nystagmus), circular, or side-to-side (horizontal nystagmus) motions. These motions can result in poor vision as both eyes are not able to hold a stable focus on objects. The different types of Nystagmus are congenital nystagmus and acquired nystagmus. Congenital nystagmus can occur in babies, presenting symptoms between the age of six weeks and three months. Congenital nystagmus is when you are born with this vision condition and may have inherited it from your parents. Acquired nystagmus may have many different causes, including underlying medical conditions or drug and alcohol consumption and can develop at a later stage in life. The causes of nystagmus may include albinism, high-grade refractive error, congenital cataracts, conditions in the inner ear, certain medications, multiple sclerosis and diseases related to the central nervous system. This condition can include symptoms of involuntary eye movement that may include eyes shaking side to side, blurry vision, dizziness and difficulty balancing, sensitivity to light, and vision problems during the night. According to the American Optometric Association, nystagmus may be diagnosed by an ophthalmologist through a comprehensive eye test and can also involve reviewing the patient’s medical history, visual acuity, eye-focusing ability and a refraction test. Treatment for nystagmus may involve prescription glasses or contact lenses, although they are not able to fix nystagmus, they may be able to aid your vision. Using other resources such as magnifying devices, more lighting and large font text may also provide some help.
Need your eyes tested?
Come and see our knowledgeable optometrists at Oscar Wylee today.
[Book an eye exam](https://www.oscarwylee.com.au/booking)
[Definition](#definition) [Causes](#causes) [Symptoms](#symptoms) [Treatment](#treatment)
## What is Nystagmus?
The answer to what is nystagmus is it is a condition that causes rapid and uncontrollable movement in the eyes. According to the American Academy of Ophthalmology, nystagmus can cause the eyes to move side to side, in a circular motion or up and down and can occur in a fast or slow nature. The nystagmus definition also includes the two main types of this condition which are congenital nystagmus and acquired nystagmus. Congenital nystagmus is when you are born with this condition. Babies with congenital nystagmus may start to present symptoms between the ages of six weeks and three months old. Acquired nystagmus is the opposite, wherein, it is when the condition occurs later in life, as an adult. According to John Hopkins Medicine, nystagmus can also be categorised as pendular nystagmus and jerk nystagmus. Pendular nystagmus is when the eyes swing in a back-and-forth motion and jerk nystagmus can be defined as the slow drift in one direction and then a quick jerk back the other way.The image below shows a person who is experiencing nystagmus as his eyes are pointed in different directions.
### What is Nystagmus Also Known as?
Nystagmus may also be known as dancing eyes as well as congenital nystagmus and acquired nystagmus. Other terms such as horizontal nystagmus, vertical nystagmus, pendular and jerk nystagmus can also be used referring to the different motions that nystagmus may move in.
### Is Nystagmus a Brain Issue?
Yes, nystagmus can be a brain issue. When nystagmus develops, it may be that certain areas of the brain that are responsible for eye movements are not functioning properly, according to the Cleveland Clinic. However, it can also be an issue relating to the inner ear’s balance. Brain diseases such as multiple sclerosis can result in pendular nystagmus. Jerk nystagmus may typically be a consequence of diseases affecting the vestibular organ, located in the inner ear according to John Hopkins Medicine.
## What are the Different Types of Nystagmus?
The different types of nystagmus are congenital nystagmus, acquired nystagmus, horizontal nystagmus, vertical nystagmus, pendular nystagmus, jerk nystagmus, manifest nystagmus, manifest-latent nystagmus, latent nystagmus and gaze-evoked nystagmus. The different types of nystagmus are listed below.
* Congenital Nystagmus: Congenital nystagmus is when you are born with this condition. Nystagmus at this age may also be categorized as another form of strabismus.
* Acquired Nystagmus: Acquired nystagmus can occur later in life and can be a result of a disease such as multiple sclerosis, a head injury, or a neurological problem.
* Horizontal Nystagmus: Horizontal nystagmus is when the eyes are moving in a side-to-side motion.
* Vertical Nystagmus: Vertical nystagmus is when the eyes are moving in an up-and-down motion.
* Pendular Nystagmus: Pendular nystagmus is when the eyes move in a back-and-forth motion similar to how a swinging pendulum moves.
* Jerk Nystagmus: Jerk nystagmus is when the eyes move slowly in one direction and then jerk back in the other direction.
* Manifest Nystagmus: Manifest nystagmus is a type of nystagmus that is always present.
* Manifest-latent Nystagmus: Manifest-latent nystagmus is when this condition is always present but is worse when one eye is covered.
* Latent Nystagmus: Latent nystagmus is when the condition occurs when you cover one eye.
* Gaze-evoked Nystagmus: Gaze-evoked nystagmus is a type of nystagmus that is triggered when the eyes are held in an eccentric position.
### What is the Prevalence of Nystagmus?
The prevalence of nystagmus in Australia is estimated to be 1 case per 1000 people. However, it is more common in the white European population but prevalence in the general worldwide population is not known according to All About Vision.
## What are the Causes of Nystagmus?
The causes of nystagmus include head injury, multiple sclerosis, stroke, Meniere’s illness and further ear issues, drug use or alcohol, crossed eyes in babies, certain medications, abnormalities of the retina or optic nerve, cataracts in babies and albinism. It is important to note these listed nystagmus causes are potential factors that may contribute to but not result in nystagmus even with these conditions present. The causes of nystagmus and their definitions are listed below.
* Head Injury: Head injuries to the back of the head may cause nystagmus as the occipital lobe is responsible for eyesight and movement.
* Multiple Sclerosis: Multiple sclerosis may cause nystagmus due to nerve damage to the cerebellum or brain stem.
* Stroke: A stroke may cause nystagmus as a result of brain damage caused by the lack of blood supply to the brain.
* Meniere's Illness and Further Inner Ear Issues: Meniere’s illness may lead to nystagmus due to problems in the inner ear.
* Drug Use or Alcohol: Drug and alcohol intoxication may lead to nystagmus due to their effect on the cerebellum function.
* Crossed Eyes in Babies: Crossed eyes or also known as strabismus in babies are commonly associated with nystagmus.
* Certain Medications: Certain medications may be associated with harmful ocular effects that can include nystagmus.
* Abnormalities of the Retina or Optic Nerve: Abnormalities of the retina or optic nerve may lead to nystagmus.
* Cataracts in Babies: Cataracts in babies may factor in developing nystagmus as a result of early loss of binocular vision development.
* Albinism: Albinism may cause nystagmus due to its impact on melanin production causing ophthalmic defects.
### 1. Head injury
A head injury may cause a number of problems including nystagmus depending on the region of the injury. Injuries to the back of the head may result in nystagmus as the occipital lobe which is responsible for eye movement and eyesight is located in that region. A head injury is a broad term to describe a variety of injuries to the brain, skull, scalp or blood vessels and tissue in the brain. A head injury can range from mild to severe and may call for urgent medical attention if other symptoms occur. Symptoms that may indicate a more severe head injury can include bleeding, unconsciousness, feeling dazed or confused and nausea or vomiting according to Health Direct.
### 2. Multiple Sclerosis
Multiple sclerosis (MS) is an ongoing autoimmune disease that affects the central nervous system. Multiple sclerosis may result in nystagmus as it can cause nerve damage to areas of the brain that correlate with vision, muscle movements and balance according to the Multiple Sclerosis Trust. These areas are known as the brainstem and cerebellum. Nystagmus may also be triggered by multiple sclerosis due to potential damage to the optic nerve. The optic nerve helps the brain to interpret images by transmitting messages from the eyes to the brain.
### 3. Stroke
A stroke may trigger nystagmus as strokes can occur when the brain's blood supply is impeded or when a blood vessel has ruptured in the brain. Nystagmus arising from a stroke can depend on which area of the brain it occurred in according to the American Stroke Association. Damage to the occipital lobe is harmful to the brain’s function of processing visual information as it is the primary vision centre in the brain. Damage to the brain stem risks the ability to control eye movements, see and comprehend objects as well as feelings related to stability and balance.
### 4. Meniere's Illness and Further Inner Ear Issues
Meniere’s illness is defined as a disorder in the inner ear that can cause hearing and balance problems. Nystagmus may be brought on by Meniere’s illness as it can affect the vestibular system in the inner ear. Problems that occur in the inner ear can cause issues such as dizziness or vertigo according to John Hopkins Medicine. Symptoms of Meniere’s illness can include vertigo, loss of hearing, ear ringing and ear pressure according to the Mayo Clinic.
### 5. Drug Use or Alcohol
The heavy consumption of alcohol as well as the use of drugs pose many health issues including nystagmus due to its potential impact on certain parts of the brain. Nystagmus along with other eye problems can be triggered by severe alcohol intoxication as it can cause harm to the cerebellum. The Cerebellum is an intricate structure in the brain that interrelates to the brain stem, cerebral cortex and basal ganglia. Hindering cerebellum function may result in gaze instability along with gaze-evoked nystagmus according to the National Institutes of Health. Gaze-evoked nystagmus is characterised as a type of nystagmus that is brought on when the eyes are kept in an eccentric position according to Arvo Journals. Nystagmus may also be a symptom of intoxication from a mix of drugs according to the American Addiction Centres.
### 6. Crossed Eyes in Babies
Crossed eyes or strabismus in babies may lead to nystagmus according to the American Academy of Ophthalmology. [Crossed eyes](https://www.oscarwylee.com.au/glasses/eye/crossed-definition) in babies can be defined as a condition when both eyes are not aligned and cannot look at an object at the same time according to the American Optometric Association. Strabismus may be managed through vision therapy, prisms, glasses and eye muscle surgery according to the American Optometric Association.
### 7. Certain Medications
Certain medications may be associated with nystagmus among other conditions such as diplopia and extraocular muscle palsies. Examples of certain medications that may lead to these harmful ocular effects are systemic medications that may include antihistamines, depressants for the central nervous system, barbiturates, and elevated blood ethanol concentrations. Systemic medications are substances that are able to flow through the bloodstream targeting and affecting cells throughout the whole body according to the National Cancer Institute.
### 8. Abnormalities of the Retina or Optic Nerve
Abnormalities of the retina or optic nerve may present as factors that contribute to nystagmus. Optic nerve hypoplasia is a disorder that can develop at birth and is defined as the underdevelopment of the optic nerves. It is noted that the majority of patients with optic nerve hypoplasia experience nystagmus according to the National Organisation of Rare Disorders. Damage to the optic nerve can hinder its function of sending messages from the retina to the brain, which may impede interpreting visual information. Retinal disorders that can lead to visual loss may commonly result in nystagmus due to the inability of maintaining gaze on an object or known as visual fixation.
### 9. Cataracts in Babies
Cataracts in babies or also referred to as congenital cataracts, may be accompanied by nystagmus due to two potential reasons. Manifest-latent nystagmus may occur as a result of cataracts in babies and children due to deterioration of early binocular vision development. Binocular vision is defined as using information from both eyes. The second possible reason is due to an ongoing state of poor vision in one eye. The cause of nystagmus in relation to [congenital cataracts](https://www.oscarwylee.com.au/glasses/eye/childhood-cataracts) may be a consequence of early loss of binocular vision according to Jay Self and Ian Christopher Lloyd in their book Congenital Cataract.
### 10. Albinism
Albinism may lead to nystagmus due to its impact of reduced melanin production which can significantly affect the development of the visual system and eye. Albinism can result in different visual problems such as nystagmus as well as reduced acuity, the translucency of the iris and foveal hypoplasia according to the National Library of Medicine. Albinism is defined as a genetic condition that causes abnormal production of pigmentation in the skin known as melanin. According to the National Organisation of Rare Disorders, the fovea’s lack of development (foveal hypoplasia) can lead to unusual connections in the nerves from the retina to the brain. This hinders the eyes from tracking and causes poor visual acuity and nystagmus.
Find a local Oscar Wylee store near you
Our team is highly qualified and can provide a range of eye care services.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
## What are the Symptoms of Nystagmus?
The symptoms of nystagmus are sensitivity to light, excessive eye movement, balance issues, issues with seeing at night, dizziness and unstable or hazy eyesight. The symptoms of nystagmus and their definitions are listed below.
* Sensitivity to Light: Sensitivity to light is a symptom that can occur when your eyes hurt or feel irritated when exposed to light.
* Excessive Eye Movement: Excessive eye movement may indicate nystagmus, especially if eye movements are uncontrollable and rapid.
* Balance Issues: Balance issues may occur as a symptom if the nystagmus is related to a vestibular system problem.
* Issues with Seeing at Night: Issues with seeing at night may be a symptom of nystagmus due to reduced vision.
* Dizziness: Dizziness may be a consequence of nystagmus if the condition is caused by vestibular system problems in the inner ear.
* Unstable or Hazy Eyesight: Unstable or hazy eyesight refers to vision that may appear shaky or blurry.
### 1. Sensitivity to Light
Sensitivity to light is defined as a common eye condition that is described as pain or discomfort occurring when looking at light. Light sensitivity may be a sign of nystagmus but is also a common symptom of different eye conditions, so it is important to have your eyes tested by an optometrist. In cases of albinism in relation to nystagmus, children can experience sensitivity to light according to Gene Vision. Using sunglasses when outdoors and avoiding overly bright settings may help alleviate sensitivity to light.
### 2. Excessive Eye Movement
Excessive eye movement that is rapid and uncontrollable may be an indication of nystagmus. Excessive eye movement in horizontal, vertical, circular or a combination of these motion types should be examined by an optometrist as clear vision may be affected. The use of glasses or contact lenses may help in slowing excessive eye movements according to the Cleveland Clinic.
### 3. Balance Issues
Balance issues are defined as difficulty while walking or feeling out of balance, which can occur from problems in the vestibular system in the inner ear. Nystagmus in the horizontal or circular form may trigger balance issues when caused by diseases in the vestibular organ located in the inner ear according to the National Library of Medicine.
### 4. Issues with Seeing at Night
Issues with seeing at night can be described as difficulty seeing clearly during nighttime. Nystagmus may cause issues with seeing at night as it can cause poor vision due to issues with transmitting messages from the eye to the brain. Nystagmus can also lead to hindrances in how regions of the brain that control eye movement process visual information according to the Royal National Institute of Blind People. Prescription of glasses may help improve vision. If you are experiencing trouble seeing at night, it is recommended that you see an optometrist.
### 5. Dizziness
Dizziness can be described as a feeling of spinning and as if you’re losing balance. Dizziness may be a symptom of nystagmus due to vestibular disorders. In the case of a vestibular problem causing nystagmus, dizziness and vertigo may commonly occur as a consequence due to the vestibular system’s role in maintaining balance in the body. The vestibular system produces a sense of balance and information on the position of our body in relation to gravity according to the National Institutes of Health.
### 6. Unstable or Hazy Eyesight
Unstable or hazy eyesight can be characterized as vision that may appear shaky and blurry. Nystagmus may cause this symptom due to oscillopsia, which is the sensation of unstable vision and is often the result of a nervous system disorder according to All About Vision. This disorder can harm areas of the brain that operate eye movements and sections of the inner ear that are responsible for balance.
### How do Glasses or Prescription Glasses Help with Nystagmus Symptoms?
Prescription glasses can help with nystagmus symptoms by improving vision. Patients with nystagmus may experience blurry, hazy or unstable vision therefore using [prescription](https://www.oscarwylee.com.au/glasses/eye/best-vitamin/benefits-of-lutein)[glasses](https://www.oscarwylee.com.au/glasses)may help to provide clearer vision according to the American Optometric Association. It is important to note that glasses cannot correct nystagmus but may provide some improvement and relief.
#### Are There Glasses for Nystagmus?
No, there are no glasses for nystagmus specifically. It is recommended to speak with an optometrist so they can determine the severity of your condition and symptoms. However, glasses with the right prescription to suit your visual requirements may still be helpful.
#### Do Children with Nystagmus Need Glasses?
Yes, children with nystagmus may need glasses as their vision may be affected. Prescription glasses may be able to sharpen vision that may be blurry or hazy as a result of nystagmus. Although glasses cannot cure nystagmus, they may help to clear vision and help ensure your child has as much optimal vision as possible according to the Royal National Institute of Blind People.
## How is Nystagmus Diagnosed?
Nystagmus is diagnosed through a comprehensive eye exam and a test for nystagmus may be conducted with a particular focus on eye movement. This may involve a visual acuity test, refraction test, and assessing how both eyes work together to focus and move according to the American Optometric Association. Visual acuity will evaluate how much your vision is affected and a refraction test can help decide what lens power may be suitable to aid any refractive errors as well as checking whether both eyes are able to focus and work together at the same time. Knowing the patient’s medical history may also help to identify causes for occurring symptoms and whether there may be underlying conditions.
### Do Optometrists or Ophthalmologists Diagnose Nystagmus?
Optometrists and ophthalmologists can both diagnose nystagmus through comprehensive eye testing. According to Vision Australia, you can see an optometrist, ophthalmologist or even your GP for vision problems including uncontrollable eye movements. It is important to note while optometrists can diagnose a range of eye conditions and diseases, they are not doctors, there is a [difference between optometrists and ophthalmologists](https://www.oscarwylee.com.au/glasses/eye/doctors).
## How is Nystagmus Treated?
Nystagmus is typically treated with prescription glasses, although they cannot completely correct nystagmus. Having your eyes tested by an optometrist can help determine what you may require in your glasses prescription. Other resources such as more lighting, magnifying devices and larger fonts may also be helpful to increase clear vision for patients with nystagmus. According to the Cleveland Clinic, other nystagmus treatments can include some medications such as antiseizure, and muscle relaxant medications which may be able to reduce symptoms.
### Can Nystagmus be Cured?
No, nystagmus cannot be cured, however, symptoms of nystagmus may be mitigated with glasses and vision aid resources such as increased lighting, larger font text and magnifying devices.
### Can Nystagmus be Prevented?
No, nystagmus cannot be prevented. According to the Cleveland Clinic, there is currently no prevention for nystagmus but it can be managed and reduced through treatment of the underlying cause.
Read Nystagmus: Definition, Types, Causes, Symptoms, Diagnosis, and Treatment in other Oscar Wylee regions and their languages.
Australia   
[Australia](https://www.oscarwylee.com.au/glasses/eye/nystagmus)
New Zealand

[Canada](https://oscarwylee.ca/glasses/eye/nystagmus)
[Canadian French](https://oscarwylee.ca/fr/lunettes/oeil/nystagmus)
Oscar Wylee Accepts Major Health Funds In-store
Come and visit our store for your eye care needs and your health fund may help cover some of the cost.
[Explore health funds](https://www.oscarwylee.com.au/health-funds.html)
Book an eye test online
Come into Oscar Wylee to see one of our skilled optometrists
[Book an eye test](https://www.oscarwylee.com.au/booking)