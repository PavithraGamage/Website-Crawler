# Source: https://www.oscarwylee.com.au/faq-prescriptions.html

* [POPULAR FAQS](https://www.oscarwylee.com.au/faq-popular.html)
* [ORDERING](https://www.oscarwylee.com.au/faq-ordering.html)
* [PRESCRIPTIONS](https://www.oscarwylee.com.au/faq-prescriptions.html)
* [SUNGLASSES](https://www.oscarwylee.com.au/faq-sunglasses.html)
* [RETURNS &amp; WARRANTIES](https://www.oscarwylee.com.au/faq-returns.html)
* [PAYMENT](https://www.oscarwylee.com.au/faq-payment.html)
* [HEALTH FUNDS](https://www.oscarwylee.com.au/faq-healthfund.html)
* [LENSES](https://www.oscarwylee.com.au/glasses/eye/types-of-lenses)
* [FRAMES](https://www.oscarwylee.com.au/faq-frames.html)
* [SHIPPING](https://www.oscarwylee.com.au/faq-shipping.html)
* [EYEWEAR STYLING TIPS](https://www.oscarwylee.com.au/faq-eyewear-styling-tips.html)
POPULAR
ORDERING
PRESCRIPTIONS
SUNGLASSES
RETURNS &amp; WARRANTIES
PAYMENT
HEALTH FUNDS
LENSES
FRAMES
SHIPPING
EYEWEAR STYLING TIPS
### PRESCRIPTIONS
Do you offer eye tests?
We offer bulk-billed eye tests in all our stores with a valid Medicare
card. If you are not covered under Medicare, our eye tests are available
for a small fee.
Click [here](https://www.oscarwylee.com.au/booking/) to book a test.
Do you offer eye tests for kids?
We offer eye tests from around ages 10 and upwards. This can vary
depending on the store and location.
Click [here](https://www.oscarwylee.com.au/booking/) to book a test or contact you local
[store](https://www.oscarwylee.com.au/locations.html).
Do you offer contact lenses?
Unfortunately, we do not offer or test for contact lenses at the moment,
but we may do in future.
How long is the eye test?
Our eye tests usually take between 20 and 30 minutes. If any additional
tests need to take place, the Optometrist will explain these for you. We
may need to re-book these for another day.
Do I need to prepare anything before my eye test?
We will call you on the day of your eye test to confirm your
appointment. If there are any special requirements, then we will let you
know.
Make sure that you arrive 5-10 minutes before your scheduled time so we
can complete all the necessary paperwork before your test.
Make sure to bring a valid Medicare card (if applicable), any private
health insurance cards and any current glasses.
Is there anything specific I need to tell the Optometrist?
During your eye test, the Optometrist may ask some lifestyle questions
to get the best idea of how you will use your prescription. This helps
them get the most accurate result for your day-to-day life. They may ask
when and where you last had an eye test.
The Optometrist may also ask about your health and any medications you
may be on. This will help with assessing the health of your eyes and any
potential visual issues. This information is stored on your file and is
confidential.
What can the Optometrist tell from looking at my eye?
By checking the blood vessels in the eye, the Optometrist can tell any
signs of circulation problems or high blood pressure. They can also see
the effects of Glaucoma or any reactions to certain medications.
Can you test my eyes if I have a pre-existing eye condition?
Certainly! We can check your prescription and your eye health. If
needed, we may refer you to a specialist or back to your regular
Ophthalmologist. If this is the case, we can fill in the needed
information and pass this onto them before an appointment.
What equipment do you have in your stores?
We have a lot of high-quality equipment in all of our stores such as:
Autorefractor - This helps give our Optometrist an idea
of your prescription by testing your eye's ability to focus. This also
checks the pressure of the eye to help check for any signed of Glaucoma.
The Optometrist will then use these results to fine-tune your
prescription.
Lens Meter - This machine can be used to measure the
prescription of your current glasses. As this is just to give an
estimate, we will not be able to produce glasses using the reading from
this machine.
Retinal Photography (Not available in all stores) -
This takes a picture of the back of the eye and helps the Optometrist
keep a virtual record of your eye health. A manual check is always
completed during every eye exam and the results are noted on your file.
Visual Fields Machine (Not available in all stores) -
This machine helps with checking for signs of Glaucoma, a possible
stroke or a brain tumour. It checks the central and peripheral vision to
find any abnormalities.
Snellen Chart - This consists of different sized
letters that you will be asked to read and this will help the
Optometrist determine your prescription.
Slit lamp - This can be used when checking the health
of the eye.
An Ishihara book - This is used when checking for signs
of colour blindness.
How do I read my prescription?
Prescriptions are made up of various different sections:
OD and OS - Derived from Latin, Oculus Dexter meaning
Right eye and Oculus Sinister meaning Left eye.
SPH (Sphere) - This is the amount of lens power,
measured in diopters, prescribed to correct nearsightedness or
farsightedness.
CYL (Cylinder) - This is the amount of lens power for
astigmatism. If nothing appears in this column, you have little or no
astigmatism that requires any correction.
AXIS - This is the degree that your SPH and CYL overlap
to give the clearest vision.
INT ADD (Intermediate Add) - This is the addition
needed to give clarity at around 1 meter away.
ADD (Near Add) - This is the addition needed to give
clarity at around 30 cms away.
PRISM - This is the amount of prismatic power
prescribed to compensate for eye alignment problems.
PD (Pupillary Distance) - This is the distance between
your eyes. This is measured from the centre of each pupil in mm’s. This
is not included in all prescriptions.
I have a strong prescription, are you able to provide suitable
lenses?
We can provide lenses for a wide range of prescriptions including high
scripts with astigmatism.
If you have a SPH (Sphere) value stronger than +/-3 and or a CYL
(Cylinder) value stronger than +/-3.00 on your prescription, a high
index lens will be recommended to you when ordering in-store. When you
order online, you will be prompted during the checkout process to add
high-index lenses to your order. This only applies if you manually
entered your prescription details and not uploaded a picture or entered
your optometrist details.
We will review your order before it is processed by our lab and may be
in touch if we think a better lens option is available based on your
prescription.
If you wish to only wish to purchase the frames alone and visit your
local optician to fill your lenses, order the frames as
non-prescription.
What if I have an astigmatism?
A lot of people have astigmatism correction in their lenses. The amount
can depend on if there will be any additional cost for your lenses. Head
into an Oscar Wylee [store](https://www.oscarwylee.com.au/locations.html) or send us an
[email](/cdn-cgi/l/email-protection#4e272028210e213d2d2f3c3937222b2b602d2123). Include a copy of your
prescription and we can give you an idea of the best lens for you.
If you want to go ahead and order online, make sure to fill in all your
prescription information including the CYL (Cylinder) and axis figures.
If you do not have a CYL (Cylinder) or AXIS on your prescription, this
means is that you don’t have astigmatism. If this is the case, simply
leave the "CYL" and "AXIS" fields empty during the checkout process when
ordering online.
Can I use my contact lens prescription to order glasses?
The prescriptions used for contact lenses and eyeglasses are different.
Glasses sit approximately 12 millimetres away from the eye, whilst
contact lenses sit directly on the eye. Because of this difference, the
lenses used can differ in strength and aren’t always interchangeable.
For legal and safety reasons, we cannot use your contact lenses
prescription for an order of glasses.
If you order using a contact lens prescription and the lenses are
incorrect, purchaser agrees that Oscar Wylee is not responsible for the
cost of a remake.
How do I get a copy of my prescription? 
To find your prescription, you can follow these steps:
Visit an Oscar Wylee Store: As of 28th July 2026,
due to the increasing risk of scams, identity fraud, and social
engineering attacks, prescriptions can no longer be released over the
phone. If you’ve had your eyes tested at an Oscar Wylee store, your
prescription will be on file. Customers can visit any Oscar Wylee
store to retrieve their existing prescription.
Book a New Eye Test: If your prescription has
expired or you haven’t had an eye test recently, you’ll need to book
an eye test to obtain an up-to-date prescription. Oscar Wylee offers
bulk-billed eye tests for eligible Medicare cardholders.
Book an eye test with an Oscar Wylee optometrist
[Book an eye test](https://www.oscarwylee.com.au/booking)
My prescription has expired. Can I still use it to order glasses?
Unfortunately, we are unable to use an expired prescription to produce
new glasses. The eyes can change and it's always good to keep up-to-date
with all eye health checks. If you order online, and your prescription
has expired, we will not be able to start production of your order until
a valid prescription has been received.
Click [here](https://www.oscarwylee.com.au/booking/) to book a test or contact you local
[store](https://www.oscarwylee.com.au/locations.html).