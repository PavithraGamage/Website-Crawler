# Source: https://www.oscarwylee.com.au/price-guide/

## Single Vision
Includes 1.50 index single vision lenses, hard coating, and UV
protection.Both options are perfect for near-sightedness or
distance correction.
1 pair of optical glassesIncludes standard single vision lenses
from
$169
1 pair of premium optical glassesIncludes standard single vision lensesFrames from OW Iconic Range
from
$199
2 pairs of optical glassesIncludes standard single vision lenses
from
$199
2 pairs of premium optical glassesIncludes standard single vision lensesFrames from OW Iconic Range
from
$249
3 pairs of optical glassesIncludes standard single vision lenses
from
$249
3 pairs of premium optical glassesIncludes standard single vision lensesFrames from OW Iconic Range
from
$448
Prices are for complete glasses. Second and third pairs must be the same
prescription.
Fashion-forward Glasses
With a large selection of shapes, sizes and colours, there’s a frame for
everyone at Oscar Wylee. Explore Oscar Wylee’s wide range of glasses
in-store today!
[Shop Glasses](https://www.oscarwylee.com.au/glasses.html)
## Lenses &amp; Coatings
Add-on prices are for 1 pair of glasses. Use your health fund benefits,
ask for a quote. Some options may not be available in online store.
Premium Anti-Reflective
+$50
* Reduce reflection for clearer vision
* Scratch and smudge resistant
* Anti-static
Blue Light Filter*
+$85
* Reduces blue light
* Includes complimentary Anti-Reflection
* Scratch resistant and anti-static
Blue Light Filter Premium*
+$95
* Reduces blue light
* Includes Premium Anti-Reflective coating
* Scratch and smudge resistant, anti-static
* ## What is Blue Light?
Blue light is emitted from digital screens such as your phone and
computer. Long hours of blue light exposure could be harmful to your
eyes as it may cause eye strain and disrupt your sleep quality.
* ## Who needs Blue Light Filter?
If your career or lifestyle relies heavily on using digital devices,
we recommend using our Blue Light Filter for your glasses.
* ## Find out more
Please visit our
[Blue Light Glasses page](https://www.oscarwylee.com.au/blue-light-glasses.html).
* Please note the Blue Light Filter is only available for clear lenses
and is unavailable for sunglasses due to the tint. Our BLF is only
available in standard 1.5, 1.61 and 1.67 index lenses.
## Multifocals
Choose your type of multifocal lenses from the options below - at an
additional cost on top of the Standard Optical Glasses prices, if
required.
## Multifocal Standard
* Some degree of soft focus at the edge of your vision
* Good for occasional glasses use
* Ideal for those on a budget
1 pair with Standard Multifocal
INCLUDED
2 pairs with Standard Multifocal
+ $80
3 pairs with Standard Multifocal
+ $130
## Multifocal Premium
* Wider field of clear vision
* Ideal for those who wear glasses in the office, especially for
computer work
* Easier adjustment than standard multifocal lenses
1 pair with Premium Multifocal
+ $130
2 pairs with Premium Multifocal
+ $180
3 pairs with Premium Multifocal
+ $230
## Multifocal Elite
* Very wide field of clear vision
* All-rounder lens for modern lifestyle demands, and a lot of
computer work
* Provides more natural and comfortable vision
1 pair with Elite Multifocal
+ $235
2 pairs with Elite Multifocal
+ $285
3 pairs with Elite Multifocal
+ $335
^Certain lens limitations apply. Bifocal premium optical lenses also
available, ask staff for more details.
## Tips for wearing multifocal glasses
Adjusting to a brand new pair of multifocals can be difficult. But there are
some useful tips that can ease the transition and help you settle into your
glasses quicker.
* Make sure to wear your new multifocals as much as possible to encourage
your eyes to adapt to your new lenses.
* Try not to go back to your previous glasses as it can affect the progress
you have made with your new multifocals.
* Move your head when looking around, not just your eyes. By pointing your
nose where you want to see you will be looking out the clearest part of
the lens.
* If you are struggling to wear them initially, try using the new glasses in
a comfortable and familiar environment to help build confidence.
* If after 1-2 weeks of using your multifocals, you are still struggling to
adjust, visit an Oscar Wylee store near you and our friendly team members
will assist you.
Find an Oscar Wylee Store Near You
Come and visit your nearest Oscar Wylee store for your eye care needs
including eye exams and affordable, stylish frames.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
## Add ons
Add-on prices are for 1 pair of glasses. Use your health fund benefits,
ask for a quote. Some options may not be available in online store.
## Thinner lenses
Extra Thin &amp; Light Lens*
+ $110
* 1.61 index
Super Thin &amp; Light Lens*
+ $160
* 1.67 index
Ultimate Thin &amp; Light Lens*
+ $260
* 1.74 index
*Aspheric lenses which include complimentary Basic Anti-Reflective coating
## Sun Protection
Tinted Lenses
+ $30
* Choose from 7 available colours.
* Includes complimentary basic Anti-Reflective coating.
Polarised
+ $100
* Good UV Protection.
* Includes complimentary basic Anti-Reflective coating.
Adaptive Lenses
+ $100
* Oscar Wylee’s brand of photochromic lenses.
* Changes from clear to darker opacity to adapt to light conditions.
* All Adaptive lenses are spheric lenses.
Transitions® GEN S™ Lenses
+ $160
* Responsive to light, enabling a change from clear to dark lenses
in 25 seconds1.
* Fast fade-back from dark to clear lenses in less than 2
minutes2.
* Available in 1.5, 1.61 and 1.67 lens indexes.
* Available in grey, brown, sapphire, graphite green, ruby,
emerald, amethyst and amber.
Transitions is a registered trademark and the
Transitions logo is a trademark of Transitions Optical, Inc., used
under license by Transitions Optical Ltd. GEN S is a trademark of
Transitions Optical Limited. ©2025 Transitions Optical Limited. Photochromic
performance may vary across colours and lens materials and is influenced by
temperature and UV exposure1For CR39 lenses across colours,
achieving 18% transmission at 23°C. 2For grey CR39 lenses
with a premium anti-reflective coating fading back to 70% transmission @
23°C.
## Sunglasses
Includes any in-store non-prescription sunglasses. 
## Non-prescription
Includes any in-store non-prescription sunglasses.

1 pair of non-prescription sunglasses
Includes any in-store non-prescription sunglasses.
from
$169
2 pairs of non-prescription sunglasses
Includes any in-store non-prescription sunglasses.
from
$199
3 pairs of non-prescription sunglasses
Includes any in-store non-prescription sunglasses.
from
$249
## Prescription
Includes tinted single vision lenses.Polarised lenses available at
additional cost.
1 pair of prescription sunglasses
Includes tinted single vision lenses.
Polarised lenses available at additional cost.
from
$199
2 pairs of prescription sunglasses
Includes tinted single vision lenses.
Polarised lenses available at additional cost.
from
$259
3 pairs of prescription sunglasses
Includes tinted single vision lenses.
Polarised lenses available at additional cost.
from
$339
## Available Filter categories
* Filter category 2:General purpose
sunglasses. Good protection against sun-glare. Good UV protection. Not
suitable for driving in twilight or at night or under dull conditions.
* Filter category 3:General purpose
sunglasses. High protection against sun-glare. Good UV protection. Not
suitable for driving in twilight or at night or under dull conditions.
Oscar Wylee Sunglasses
Protect your eyes in style with Oscar Wylee’s range of sunglasses.
Customise your sunglasses and choose from tinted, polarised or Adaptive
lenses.
[Shop sunglasses](https://www.oscarwylee.com.au/sunglasses.html)
## Frames
## Traditional Hand Assembly, Designed In-house
We believe that good design isn't just about looking good, it's about seeing
clearly too. That's why we use high-quality lenses for all our glasses,
complete with anti-scratch and UV proof coatings.
## Frame Styles
### Acetate
Also known as cellulose acetate, these frames are traditionally
hand-crafted by skilled craftsmen, with each frame passing through
numerous stages of production and are hand-polished to ensure a
glorious lustre. Our collections are a mix of Italian Mazzucchelli and
Chinese-crafted plant-based plastic, which is both durable and
light-weight.
### Bio Acetate
Bio-acetate is a material made mainly from plant-based sources, and
just like standard acetate, it’s ideal for creating high-quality
frames for your everyday. The key difference is that there are fewer
plasticisers in the material and more sources, such as wood pulp and
cotton fibres, used for an eco-friendly alternative.
### Stainless-Steel
As part of our durable frame family, some of our most popular styles
such as Kato, are now in stainless steel. These frames are
corrosion-resistant, lightweight, and not sensitive to temperature
changes.
### Titanium
Our titanium frames are durable, corrosion-resistant and lightweight,
with spring hinges.
### Ultem Material
We love our Ultem frames! They are super comfortable and very durable.
Our Ultem frames are heat resistant, with high dielectric strength and
are flexible. The material is widely used in medical and chemical
instruments. It is currently available in a range of colours for both
matte and gloss finish.
### TR90
TR90 was produced by Swiss technology as a thermoplastic material.
TR90 frames are durable, flexible and lightweight!
## Services
Oscar Wylee offers bulk billed eye tests for valid Medicare cardholders.
### Complete Eye Test
* A complete eye test can be bulk billed for eligible Medicare
cardholders. If a person is not covered under Medicare, a private
comprehensive eye test starts from $70.
### Frame Adjustments
* Lifetime service with us means you can have your OW glasses adjusted
or professionally cleaned, free of charge during the life of your
glasses.
### Style Advice
* Our in-store stylists are here to help you find the right pair of
glasses or sunglasses. Find us in any of our
[Australian locations](https://www.oscarwylee.com.au/locations/full-store-list.html).
## 1 YEAR Quality Guarantee
If within 1 year of purchase your glasses have any defects due to material
or production faults, we will repair or replace them for you. Learn more
about our
[Oscar Wylee Warranty](https://www.oscarwylee.com.au/legal/oscar-wylee-warranty.html).
Prices valid as of June 2025. Offer per person &amp; may be withdrawn at any
time.
Look After Your Eyes at Oscar Wylee
Book an eye test with an Oscar Wylee optometrist and prioritise your eye
health today.
[Book an eye test](https://www.oscarwylee.com.au/booking)