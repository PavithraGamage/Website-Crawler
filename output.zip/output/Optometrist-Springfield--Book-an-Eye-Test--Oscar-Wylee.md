# Source: https://www.oscarwylee.com.au/locations/optometrist-springfield.html

# Optometrist Springfield
Orion Springfield CentralGround Floor, Shop 66, 1 Main StSpringfield Central QLD 4300
* Near Big W
Opening hours
Monday9:00am - 5:30pm
Tuesday9:00am - 5:30pm
Wednesday9:00am - 5:30pm
Thursday9:00am - 9:00pm
Friday9:00am - 5:30pm
Saturday9:00am - 5:00pm
Sunday10:00am - 4:00pm
*Store hours reflect local standard trading hours and exclude public holidays
[Visit our Orion Springfield Google Business page for directions, reviews, and updates.](https://g.page/r/CfkjZXXfH9MnEAE)
Book Appointment
[Call us: 07 3418 3224](tel:07 3418 3224)
[Leave a Review!](https://g.page/r/CfkjZXXfH9MnEAg/review)
Our Reviews
renee williams
5 days ago
Absolutely great the optometrist was funny and thorough really helpful
Elham Memar
1 week ago
Jan Taylor
1 week ago
I was happy with the optometrist I saw at Oscar Wylee. He was patient, gentle and thorough.
Tuija Heikura
1 week ago
I walked into a couple of optical stores on this day without having someone even acknowledge me
I wa...s giving up hope whe I decided to have one last try at Oscar Wylee Springfield Orion
I was greeted instantly by the staff, placed my concerns about my current glasses. I was given an appointment within 30 minutes, the testing was exceptional and explanation of why I was having issues, I left very satisfied after realising their prices were really good with 2 pair of multi focals and one pair of sunglasses
Great service, pleasant staff, very happy
Highly recommend
See more
Lisa Gregory
2 weeks ago
Thanh is super thorough!
Jose Flores
2 weeks ago
Very professional
Bryan Hogan
2 weeks ago
Absolutely so good I recommend oscar wlee to any one I right hightly freindly staff allways good hel...p
See more
Sam Wingman
3 weeks ago
Penny Richardson
3 weeks ago
Amazing customer service and I had such a great experience with the team.
Aaron McCormack
3 weeks ago
Good, quick. Will update when prescriptions are received.
MIKE ML
4 weeks ago
Went to this store this afternoon 2nd August. My glasse's frames were loose.  Maria helped with fixi...ng my glasses.  She did a great job.  Fixed the hole frame and tightened all the screws that need tightening.  Maria had a great customer service and very professional. She's a great asset to the team of Oscar Wylee.
See more
Robin Spencer-Scarr
1 month ago
Very professional and informative. I felt like part of the family
Ngaari Taupiasi
1 month ago
Hii,, the service was awesome n fast ????????
The staff was very friendly n helpful
I will definitel...y be back for my glasses
See more
Saroj Kumar
1 month ago
I am a new client.very impressed by the service received. Smiling and friendly staff.
Highly recomme...nd this business.
See more
Porscha Turetahi
1 month ago
Highly recommend this clinic! Very friendly and supportive team at Springfield Orion. The doctor was... also very helpful with the whole process and made the experience very comfortable, smooth, and stress-free. Thank you for the excellent care!
See more
brooke Milford
1 month ago
Dusko Amidzic
1 month ago
Danica Knubel
1 month ago
Had a great experience the optometrist was wonderful and explained everything thoroughly.
PK ILLMER
1 month ago
I have seen 2 optometrists at OW Springfilend and both have been brilliant. Highly recommended.
Nona Ruse
1 month ago
My first time with O&amp;W and my eye exam was thorough and didn’t feel rushed. My concerns were listene...d to and all the staff were friendly, professional and knowledgeable.
See more
Anna Whitehead
1 month ago
Very friendly and professional. Great range of frames.
Kim Dunn
1 month ago
The optometrist was thorough and picked up changes to my eyesight.  I had previously gone to spec sa...vers and felt this experience way more personal than spec savers.  They even adjusted my current glasses to make them more comfortable whilst waiting for my new glasses.  Will be back for sure.
See more
Kodzo
1 month ago
I had an excellent experience at Oscar Wylee. The staff were friendly, welcoming, and professional f...rom the moment I arrived.
See more
Melissa Edwards
1 month ago
5 stars. The optometrist got me in early for my eye test and replacement glasses. The whole team at ...the springfield store were very welcoming and friendly.
See more
Anoop Kundu Valappil
1 month ago
Khamsene Savirak
1 month ago
Sasha Makoare-Adams
2 months ago
Great eye test service - would highly recommend Springfield all the staff were amazing &amp; very helpfu...l.
See more
Sarah Milford
2 months ago
Althea
2 months ago
Very lovely staff and beautiful frame designs! It was very quick and easy to book an appointment for... my eye test, of which was very quick and thorough. I had an amazing optometrist who was also very patient with me because I struggled between options, and he was super chill. I just collected my glasses today and I'm very happy :)
See more
Kelly M
2 months ago
Customer service at Orion Springfield was definitely 5 stars. From assistance with choosing frames t...o the very thorough eye test, I highly recommend Oscar Wylee.
See more
Patkun Kanhasinwattana
2 months ago
Barnabas Petelo
2 months ago
Pleasant experience, easy and no hassle.
Leighann's craft room
2 months ago
Being only new to the area I need to seek out an optometrist for myself. I had not heard of Oscar Wy...lee before, though a close family member did and recommended you to me. Suffering from anxiety I knew I would struggle with my first appointment so my daughter and granddaughter accompanied me, helping me choose frames ect
I was treated very well and kindly by the staff.  They helped me feel at ease.
I've been back a few times now and no more anxiety when it's appointment time.
See more
David Chamberlain
2 months ago
All of the staff were very helpful and friendly.
The lady who performed my eye test was fantastic, ...thoroughly explaining everything so it was easy to understand.
Very impressed all round.
See more
Adair Donaldson
2 months ago
Malaefilogia Laupua Ivapene
2 months ago
I have had my first appointment with Oscar Wylee, normally a Specsavers throughout the whole time.
T...his will be my definitely go to Eye professional in the future.
I was treated respectfully with an eye professional &amp; their amazing staff. I’d also love my purchase, really suits my face lol, money worth spending.
Highly recommended
Thank you so much.
See more
crazy Corn
3 months ago
Very lovely staff, very professional. Great with my asd daughter. Highly recommend
Grumpy Grimwood
3 months ago
I’ve been wearing my new Glasses for a few weeks now and they would be the best suited glasses I’ve ...ever had. Anna, (the Optometrist) really knows her work and is super friendly and professional. The Ladies out front of shop, (Deanna and Amanda) gave the best Customer Service, showing they know their product and really have their Customers best interests at heart.  Thank you very much and I highly recommend the Springfield Lakes Store for their service.
See more
Jan Brown
3 months ago
Wonderful service. Friendly, prompt and very thorough. Thank you team.
David Millar
3 months ago
As we are visitors to Qld, we chose Oscar wylee at Orion shopping centre Springfield after looking f...or opttometrist by researching reviews. We found the staff  and the optometrist very thorough, pleasent and professional.
Can highly recommend.
See more
Sidharth Mohandas
3 months ago
Great experience with the Optometrist Tek. The store people were also patient. Good price for value.... Overall will strongly recommend.
See more
Sarah Livingstone
3 months ago
Great team of people, kind and passionate about what they do. Great service.
Stuart Clarke
3 months ago
Anna Wall
4 months ago
Friendly and professional staff.
Cerina Parker
4 months ago
Welcoming as soon as I walked in.  Very accommodating and friendly.
Kaylene Green
4 months ago
Ihsan Malik
4 months ago
Its was quick, nice and easy. Got my prescription.
Mrs Fkynn
4 months ago
Decided to make a change when getting my glasses done this time and was surprised with the huge vari...ety and options for such a reasonable price, the staff were amazing from start to finish a special shout out to Ali the optometrist and Amanda who handled my sale will definitely be back
See more
Tee Ray (Teeray)
4 months ago
every time I come here I always have the smoothest experience. the staff are always so friendly and ...the optometrist was kind and caring during my eye exam. bonus that the glasses are trendy and actually look cute!
See more
Heather Robertson
4 months ago
The staff at Springfield are wonderful, accomodating and very professional
## Find an Optometrist in Orion Springfield With Oscar Wylee
If you live in the Springfield or Brookwater areas, our Oscar Wylee store at the Orion Springfield Central Shopping Centre is your go-to for high-quality eye-care processes as well as some of the best optometry services in Springfield, Australia. Take the short walk from Springfield train station or utilise one of the 3000 car park spaces at the centre, and our Oscar Wylee optometrists can conduct a Medicare, bulk billed eye test. Once you are here, our in-store Oscar Wylee Orion Springfield staff can also help you find a pair of modern or vintage-style frames that are the best fit for you. 
If you have time after your Oscar Wylee appointment, why not explore the retail, dining and entertainment options the Orion Springfield Centre has to offer. From Bookface to Baskin Robbins, there is plenty to do. If you have kids, the large Orion playground just behind the shopping centre is sure to keep them entertained. Come and visit us in-store, we hope to see you soon!        
Meet Our Team
* Optometrist Partner
B. VisSci M. Optom
* Store Manager
Certificate IV in Optical Dispensing
Our Services
* Bulk Billed Eye Examinations
* Professional Frame Styling
* Frame Adjustments and Repairs
* Visual Fields Testing
* Digital Retinal Scanning
* Paediatric Eye Examinations
Show All
## Find an Optometrist in Springfield, Queensland for an Eye Health Test
If you are in the Springfield area and need an eye health test, visit Oscar Wylee in Orion Springfield Central, Queensland. At Oscar Wylee Springfield, we offer excellent optometry services including bulk billed eye tests courtesy of the Australian Medicare system. You can also try on our selection of on-trend and vintage-inspired frames if you need a pair of optical glasses or prescription sunglasses.
While there is no eye doctor in Oscar Wylee Springfield, we do have a great team consisting of retail staff as well as an optometrist and optical dispenser who can provide high-quality eye care. The average price range for an optometrist in Springfield, Queensland can vary depending on factors such as the patient’s overall health, age and visual needs. The procedure of an eye health test in our Springfield glasses store typically involves checking eye movement and assessing a patient's vision and the health of the eyes which involves checking for any signs of eye diseases.
## How to Find an Optometrist in Springfield, Queensland?
To find an optometrist in Springfield, you can take certain steps that can help make it easier for you such as searching online, assessing the store’s opening hours and finding the directions to your chosen location. The steps on how to find an optometrist in Springfield are listed below.
1. Search online using the phrase, Springfield optometrist near me. This can also be done here on the website via our locations page.
2. Click on the Oscar Wylee link, which will take you directly to our Springfield optometrist store page.
3. See the store’s opening hours and where the store is located specifically.
4. Use the Springfield Google Business page link located under store hours to see the directions on how to get to the store.
You can also find an optometrist in Springfield, Queensland by searching the keywords optometrist near me. If you have locations enabled on your smartphone and you’re in the Springfield area, our Oscar Wylee Springfield store page should appear easily for you to click on.
### Is it Hard to Get an Eye Appointment in Springfield, Queensland?
No, it is not hard to get an eye appointment in Springfield. You can easily book an appointment to see an Oscar Wylee optometrist in Springfield right here on this page. At Oscar Wylee we have highly qualified optometrists available for bulk billed eye appointments, which can be booked online, over the phone, or in-store.
#### How to Compare Optometrists in Springfield to Each Other?
To compare optometrists in Springfield, you can use factors such as eye tests offered, health fund coverage, lens types and add-ons and eyewear offered. To take care of your vision and eye health, it is important to receive an eye test at least once every two years. There are different types of tests that can be performed in an eye test and not all optometrists may offer the same tests. Health funds can be used to help cover some of the cost of your frames and lenses. To find out if your health fund is accepted at an optometrist in Springfield, visit their website. In the case of Oscar Wylee, we accept all major health funds and provide on-the-spot claims in-store. There are many different lens options available for prescription glasses such as single vision, multifocal and high index lenses. Most optometrists in Springfield will offer these lenses although it is good to make sure. There are also lens add-ons available to enhance your glasses such as anti-reflective and blue light filters. Finally, if you are looking to purchase a pair of glasses after your eye test, you can compare the different styles and colours you are interested in from the optometrists in Springfield, Queensland. Oscar Wylee offers a wide range of frames with vintage and modern inspirations in bold colours and subtle designs.
#### How to Find an Eyeglasses Shop in Springfield, Queensland?
To find a glasses store in Springfield, you can try to follow these simple steps including searching online, selecting a convenient location and looking at their health insurance policies. The steps on how to find a glasses store in Springfield, Queensland are listed below.
1. Search online using the phrase, glasses store in Springfield. This will provide you with various options for glasses stores in the whole Springfield, Queensland area.
2. Select a glasses store that is most convenient for you to travel to.
3. Click the link to find out more information such as opening hours, exact location and directions to the glasses store in Springfield.
4. Read their health insurance policies to ensure you know what health benefits you can access.
Our Oscar Wylee glasses store in Springfield, Queensland offers primary eye care services such as comprehensive eye tests as well as other services performed by an optometrist and offers prescription and non-prescription eyewear.
##### Is it Possible to Purchase Prescribed Sunglasses in Springfield, Queensland Without Seeing an Optometrist?
Yes and no, it is possible to [purchase prescribed sunglasses](https://www.oscarwylee.com.au/sunglasses.html) in Springfield, Queensland without seeing an optometrist if you already have a prescription that has not expired. If your prescription is expired, you can book an eye test to receive an updated or new prescription which will require you to see an optometrist. This will ensure your prescription sunglasses are appropriate for your visual needs.
## Where is the Oscar Wylee Springfield Optometrist Located in Queensland?
The Oscar Wylee Springfield optometrist is located in the Orion Springfield Central Shopping Centre, near Big W. Orion Springfield Central is a modern and vibrant shopping centre located in the city of Ipswich, Queensland.
### What is the Phone Number of Oscar Wylee Springfield Optometrist Store?
The Oscar Wylee Springfield optometrist store phone number is [(07) 3418 3224](tel:(07) 3418 3224). You can contact the Oscar Wylee Springfield store between the hours of 9 am and 5:30 pm from Monday to Wednesday, 9 am and 9 pm on Thursdays, 9 am and 5:30 pm on Fridays, 9 am to 5 pm on Saturdays and 10 am and 4 pm on Sundays.
### What are the Reviews for Oscar Wylee Springfield Optometrist in Queensland?
The many reviews for Oscar Wylee Springfield optometrist in Queensland, left by our various customers can be found here on the website as well as online when you search for Oscar Wylee Springfield optometrist. The reviews for Oscar Wylee Springfield optometrist are listed below.
* Narella Drake:  Best optometrist I have dealt with. Excellent with my 95 year old mother - and first one ever to put drops in my eyes to test for diabetes disease. Will be going back there.
* Vanessa Jordanovich:  Lovely optometrist, she was very helpful and explained everything in detail. Will definitely be a return customer.
* Janelle Christou:  Amazing stuff. Professional &amp; very helpful! Will be back every year!
* Jessica Jure-Le Manac’H:  Friendly, accommodating &amp; helpful staff. Efficient service. Good selection of fashion forward frames. Highly recommend!
#### What Treatments or Eye Care Processes are Done in the Oscar Wylee Springfield Optometrist Location?
The treatments or eye care processes done in the Oscar Wylee Springfield optometrist Queensland location include a tonometry test, a digital photograph, a slit lamp exam and a refraction test. Additional tests that may also be performed can include a visual field test and a dilated fundus exam. The treatments or eye-care processes that are done in the Oscar Wylee Springfield optometrist Queensland location are listed below.
* A Tonometry Test: An optometrist or optical dispenser will conduct a tonometry test which involves the use of a machine that will release small puffs of air into your eyes. This will assist with measuring pressure in the eye.
* A Digital Photograph: An optometrist or optical dispenser may take a digital photograph of your eye which can be kept on record to use in future appointments to evaluate any changes to your eye.
* Slit Lamp Test: A slit lamp test can be used to evaluate your eye health, by examining your cornea and iris which are the anterior and posterior of the eye.
* Refraction Test: During a refraction test, an optometrist will have you view an image through different lenses and ask you to confirm which helps you see the image clearer.
* Visual Field Test: A visual field test can assist with assessing your peripheral vision, which may be beneficial for identifying any signs of glaucoma.
* Dilated Fundus Exam: A dilated fundus exam can help an optometrist assess your health in more detail by getting a clear view of the retina. This test is typically carried out for patients with diabetes and those who may be at risk of developing retinal damage.
## How Many Optometrists Exist in Springfield, Queensland?
There are many optometrists that exist in Springfield, Queensland to provide eye tests and glasses, including Oscar Wylee. The amount of optometrists available in an area will typically depend on the population. At Oscar Wylee Springfield, we offer excellent optometry services including eye tests performed by skilled optometrists using high-quality equipment. We also have a wide range of fashion-forward frames that customers can browse in a large selection of sizes and colours. If you’re looking for an optometrist in Springfield, choose Oscar Wylee and we will take care of your optometry and eyewear needs.
### What are the Other Closest Optometrist Locations to Springfield, Queensland in Australia?
The other closest Oscar Wylee optometrist locations to Springfield in Australia are  Indooroopilly, Mt Gravatt and Loganholme. The locations and their distance from Springfield are listed below.
* Indooroopilly:  Indooroopilly is close to Springfield, around 25 km. The [Oscar Wylee Indooroopilly](https://www.oscarwylee.com.au/locations/optometrist-indooroopilly.html) store is in the Indooroopilly Shopping Centre near Coles. Oscar Wylee Strathpine offers high-quality eye tests, professional frame styling and digital retinal scanning.
* Mt Gravatt:  Mt Gravatt is close to Springfield, around 29-30 km. The [Oscar Wylee Mt Gravatt](https://www.oscarwylee.com.au/locations/optometrist-mt-gravatt.html) store is located in Westfield Mt Gravatt shopping centre next to Specsavers. Oscar Wylee Mt Gravatt provides primary eye care processes including digital retinal scanning and visual field testing.
* Loganholme:  Loganholme is close to Springfield, around 38-39 km. The [Oscar Wylee Loganholme](https://www.oscarwylee.com.au/locations/optometrist-loganholme.html) store is located in the Hyperdome Shopping Centre just off the Pacific Highway. Oscar Wylee Loganholme offers excellent eyewear and optometry services including comprehensive eye tests and frame adjustments and repairs.
### Bulk Billed Eye Tests With Oscar Wylee
We offer optometrist-led eye health tests in-store at Oscar Wylee Orion Springfield Central. Come in and have your prescription updated, your vision checked for certain eye diseases and shop for a new pair of eyeglasses on the same day. Our trained optometrists can update your prescription or issue a new one, usually in under 30 minutes. Oscar Wylee Springfield can keep you up-to-date on your eyesight and eye health needs, so choose us for your regular eye check-up.
### Leading Health Funds Accepted
Oscar Wylee Springfield accepts all major health funds including Medibank, Bupa and HCF. The capable staff will process your claim in-store with a valid health fund card, so make sure to bring your card to your next appointment. Insurance can be tricky but with our staff on hand, you won’t have to navigate it alone. The team at Oscar Wylee Springfield will ensure you’re getting the best price every single time for all of your eyewear needs.
### Expert Styling Advice in Orion Springfield
Here at our Oscar Wylee store in Orion Springfield Central, we offer prescription eyeglasses and prescription sunglasses in a variety of modern and vintage-inspired styles. Choose to add on anti-reflective lenses, blue light filter lenses, and more. Our Oscar Wylee experts in our eyeglasses shop will help you choose the best frames and lenses for your prescription needs and personal style. Whether you’re looking for a bold statement frame or a subtle everyday accessory, Oscar Wylee Springfield has the one for you.
Book Appointment
[Call us: 07 3418 3224](tel:07 3418 3224)
[Leave a Review!](https://g.page/r/CfkjZXXfH9MnEAg/review)