# Source: https://www.oscarwylee.com.au/glasses/eye/colour-blindness-types

# A Comprehensive Guide to Different Types of Colour Blindness
Published on August 18th, 2023
Updated on November 14th, 2024
Australia
[Australia](https://www.oscarwylee.com.au/glasses/eye/colour-blindness-types)
[Canada](https://oscarwylee.ca/glasses/eye/color-blindness-types)
[Canadian French](https://oscarwylee.ca/fr/glasses/eye/color-blindness-types)
Colour blindness also referred to as colour deficiency, is defined as an eye
condition that makes it difficult for the eyes to see colour correctly.
Colour blindness may be caused by a function issue with the rods and cones
of your eyes and also by inheriting it from your parents. Other causes can
include the use of certain medications, medical conditions and head and eye
injuries. The three different cones operate as one of the main colour
receptors and include red-sensing cones, green-sensing cones and
blue-sensing cones. They are also referred to as long-wavelength (L),
medium-wavelength (M) and short-wavelength (S) cones. There are different
types of colour blindness such as complete colour blindness, blue-yellow
colour blindness and red-green colour blindness, which is the most common
type of colour deficiency. The four different types of red-green colour
blindness are deuteranomaly, protanomaly, protanopia and deuteranopia.
Blue-yellow colour deficiency is less common and has two types which include
tritanomaly and tritanopia.
The comprehensive guide to different types of colour blindness are monochromatism (complete colour blindness), blue-yellow colour blindness
and red-green colour blindness. The list of different types of colour blindness and their definitions
are listed below.
* Monochromatism (complete colour blindness):
Monochromatism also known as complete colour blindness occurs when you
cannot see any colour at all.
* Blue-Yellow Colour Blindness: Blue-yellow colour blindness can include tritanopia; one of the two
types that causes difficulty of the eyes to differentiate between blue,
green, red, pink, purple and yellow. Tritanomaly, the second type,
hinders the eyes from differentiating between blue and green and yellow
and red.
* Red-green colour blindness: Red-green colour blindness has four types which include protanomaly,
deuteranomaly, protanopia and deuteranopia.
Prioritise Your Eye Health
Let our team at Oscar Wylee help you take care of your eye health.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Definition](#definition) [Prevalence](#prevalence)
[Cause](#cause) [Treatment](#treatment)
## Monochromatism (Complete Colour Blindness)
Monochromatism is known as complete colour blindness and hinders the eyes from perceiving all
colours. Due to the lack of working cone photoreceptors, people with this type
of colour deficiency may only be capable of seeing grey colours according
to the National Library of Medicine. Individuals with monochromatism may
also be susceptible to other vision problems such as nystagmus and low
visual acuity according to the Nature Journal. Complete colour blindness
is considered the most rare and severe type of colour blindness and cannot
be treated. It is generally caused by genetic defects and can appear
during infancy.
## What is Colour Blindness?
Colour blindness is an eye condition that impedes the eyes from seeing colours properly. There are three different forms of colour blindness which include complete colour blindness (monochromatism), blue-yellow colour blindness
and red-green colour blindness. [Colour blindness](https://www.oscarwylee.com.au/glasses/eye/colour-vision-deficiency)
may develop as a result of genetics as it can typically occur at birth or
due to other causes such as the use of certain medications, medical
conditions and head and eye injuries. The two types of photoreceptors that
enable colour vision and night vision are known as rods and cones and
function by transforming light into signals that are sent to the brain.
The cones help with detecting red, green and blue colours and are also
known as L cones, M cones and S cones.
### How Does Colour Blindness Work?
Colour blindness works when the L cones, M cones and S cones are missing or are not
functioning correctly.
This can result in the retina’s inability to send visual signals
through the optic nerve to reach the brain to help interpret the colours
we see.
The L cones also known as red-sensing cones recognise long wavelengths,
and the M cones also known as green-sensing cones are responsible for
sensing medium wavelengths. The S cones also referred to as blue-sensing
cones detect short wavelengths.
## How Common is Colour Blindness?
Colour blindness can be common, according to Vision Eye Institute with 8% of males in Australia experiencing some form of colour blindness. For
females in Australia, it is 0.4%. Red-green colour blindness is the most common form, it mainly affects
males and is typically inherited according to Better Health. Colour
blindness can occur later in life from conditions such as eye diseases,
some medicines, injuries to the brain or eyes, and brain and nervous
system diseases according to the National Eye Institute. Colour blindness
is a [common eye condition](https://www.oscarwylee.com.au/glasses/eye/common-problems)
that affects 1 in 12 men and 1 in 200 women according to the National Eye
Institute.
### How Does Colour Blindness Affect a Person's Life?
Colour blindness may affect a person’s daily life as it can alter how
everyday tasks are done. Tasks that may be affected can include cooking, driving and clothing-related tasks. When cooking, you may not
be capable of knowing if produce has expired or if certain foods are
completely cooked. When driving, you may not see the correct colours of
road signs and markings or when following traffic lights, ensure you memorise the placement of each light. When shopping, you
may not be able to know what colour the items are and identify the
colours of your own clothes. People with colour blindness are likely to
overcome these small hindrances along with assistance from professionals
and family members.
#### Is Colour Blindness a Disability?
Yes, colour blindness is considered a disability, according to the
NCCD, the Nationally Consistent Collection of Data on School Students
with Disabilities. Their established definitions include colour-blind
individuals
or those who use corrective devices as this condition is considered an impairment to the function of the
eyes.
#### Can a Person Be Slightly Colour Blind?
Yes and no, a person is either colour blind or not, however,
this condition can vary from mild to moderate and severe between
individuals.
Therefore, someone with a mild case of red-green colour blindness may
still be able to see red colours, however, in a less vibrant and
darkened nature.
#### Can a Colour Blind Person Have Perfect Vision?
Yes, a colour-blind person can have [perfect vision](https://www.oscarwylee.com.au/glasses/eye/perfect-vision), which is a colloquial term for visual acuity, as colour blindness only affects the eyes from perceiving colour and
does not prompt impaired vision
according to the Vision Eye Institute. Colour blindness occurs as a
result of affected or missing cones in the eye and not other vital
structures that are responsible for sight.
## How to Know What Type of Colour Blindness You Have?
You may know what type of colour blindness you have if you are experiencing difficulty with discerning between reds and greens, seeing
green colours appear more red, certain shades of red look more green, are
incapable of distinguishing between blues and greens and yellows and reds
and have an affected perception of blue colours. This condition is typically present at birth, however, can also occur at
any age. The ways to know what type of colour blindness you have and their
definitions are listed below.
* Experiencing Difficulty Differentiating Between Reds and Greens:
If you’re experiencing trouble differentiating between red colours and
green colours completely, this may indicate you have protanopia and
deuteranopia (red-green colour blindness).
* Seeing Green Colours Appear More Red: If
you are seeing green colours appear more red, this may be a sign you have
deuteranomaly (red-green colour blindness).
* Certain Shades of Red Look More Green: If
you see green in red colours and in a less bright nature, you may be
experiencing protanomaly.
* Incapable of Distinguishing Between Blues and Greens and Yellows and
Reds:
If you are struggling to discern between blue colours and green colours
and between yellow colours and red colours, this could indicate
tritanomaly (blue-yellow colour blindness).
* Affected Perception of Blue Colours: If
you cannot differentiate between reds, pinks, purples and greens, you may
be experiencing tritanopia. This type of blue-yellow colour blindness
affects your perception of colours that contain attributes of either blue
or yellow.
* Unable to See All Colours: If you are
unable to see any colour, you most likely have monochromatism (complete
colour blindness).
### What Kind of Eye Doctor Diagnoses Colour Blindness?
An optometrist or your local doctor can diagnose colour blindness.
According to Health Direct, an optometrist is capable of checking for colour blindness through
different colour vision tests. An optometrist is not an [eye doctor](https://www.oscarwylee.com.au/glasses/eye/doctors), however, they hold all the necessary qualifications to diagnose a
wide range of eye conditions such as this one.
#### Can You Be Colour Blind Without Knowing?
Yes, you can be colour-blind without knowing as symptoms can often
range in severity depending on the individual. According to the
National Eye Institute, some people are unaware they have colour blindness as the condition’s
implications can be very mild.
#### Can You Self-Diagnose Colour Blindness?
Yes, you can self-diagnose colour blindness using some online tests
that may closely replicate the traditional tests used by optometrists. You may use an Ishihara test which consists of coloured plates with
coloured dots and a number usually in a different colour on top.
If you are not able to see the numbers, you may likely be
colour-blind, which you can consult further with an optometrist to
confirm. If you experience any sudden changes to colour vision, seek
immediate medical attention or see your optometrist.
### What Causes Colour Blindness?
The causes of colour blindness may include genetics as it can be passed down from your parents, the use of certain
medications and medical conditions. Other extreme causes may include eye injuries, certain types of brain
tumours, retinal detachment and radiation treatments, according to the
National Eye Institute.
#### Can Glaucoma Cause Colour Blindness?
Yes, glaucoma may cause colour blindness in the initial stages. Patients with [glaucoma](https://www.oscarwylee.com.au/glasses/eye/glaucoma)
were found to be susceptible to colour blindness due to factors such
as increased eye pressure and a damaged optic nerve head or changes to
the visual field,
according to the National Library of Medicine. However, it is
important to note that glaucoma does not inherently lead to colour
blindness. Due to the negative effect of the pressure on the optic
nerve, colour blindness may develop as the optic nerve carries the
visual signals that are sent from the eyes to the brain.
### How is Colour Blindness Treated?
Colour blindness cannot be completely treated, however, you can establish certain habits
when carrying out certain tasks to help. These can include labels to indicate colours, having a list of
important objects and personal items and their colours and using your
touch and smell.
#### Do Colour Blind Glasses Work?
Yes and no, colour-blind glasses may not work for every individual with colour blindness. The
effectiveness of colour-blind glasses depends on the severity of their
condition and whether it is caused by a defect in their photoreceptors
or absent photoreceptors. According to the American Academy of Ophthalmology, colour-blind
glasses are created with certain substances to either filter out or
take in certain wavelengths of light. For those with colour blindness
caused by photoreceptor issues, these glasses may be able to alter
what they see when they use them, however, it can be a different case
for each individual. Oscar Wylee does not offer colour-blind glasses
or any product for colour vision issues.
### What is the Difference Between Colour Blindness and Corneal Diseases?
The difference between colour blindness and corneal diseases is how
they affect the eye and how they develop. Colour blindness is an eye
condition that hinders your ability to see certain colours or
distinguish between certain colours and is typically inherited. Corneal
diseases refers to a group of eye diseases that affect the cornea and
can include eye infections, injuries, inflammation and dry eyes. [Corneal diseases](https://www.oscarwylee.com.au/glasses/eye/common-problems)
can develop as a result of several factors, however, the most common
causes may be from viral or bacterial infections.
Read A Comprehensive Guide to Different Types of Colour Blindness in other
Oscar Wylee regions and their languages.
Australia
[Australia](https://www.oscarwylee.com.au/glasses/eye/colour-blindness-types)
[Canada](https://oscarwylee.ca/glasses/eye/color-blindness-types)
[Canadian French](https://oscarwylee.ca/fr/glasses/eye/color-blindness-types)
Oscar Wylee Accepts Leading Health Funds
Be sure to bring your health fund card when you visit and we can help
you use your health fund to cover some of the cost.
[Health Funds](https://www.oscarwylee.com.au/health-funds.html)
We Offer Bulk Billed Eye Tests at All Our Stores
Book an appointment online or with us in-store today to see one of our
optometrists.
[Book an eye test](https://www.oscarwylee.com.au/booking)