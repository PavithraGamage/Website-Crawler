# Source: https://www.oscarwylee.com.au/soma-sunglasses.html

# Soma
1
## Frame Design of Soma Sunglasses
The frame design of Oscar Wylee’s Soma sunglasses is characterised by a classic oval &amp; round shape, adjustable nose pads and a stainless steel and acetate frame. Soma glasses are a women's statement frame that will work for any occasion, whether the wearer wants to liven up their work style or complement an outfit for a night out.
$169    
In stock
Only %1 left
2 pairs from $199
Discount auto-applied at checkout
3 pairs from $249
Discount auto-applied at checkout
* 2 &amp; 3 Pair pricing applies to non-prescription sunglasses only. Prescription sunglasses incur additional charges.    
[Non-Prescription](https://www.oscarwylee.com.au/soma-sunglasses.html#)
Qty
Prescription
Book an eye test
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
excluding prescription lenses
## About Soma Frames
Nothing screams cool more than this octagon-shaped glasses. Not to
mention, Soma comes with the most comfortable nose pads. So much
style, so much class. Both online and offline.
| Frame fit | Measurements |
| --- | --- |
| Medium | 50 - 20 - 145 |
These measurements mean lens width, bridge, and temple length in
millimetres (mm). They can be found on the inside of the temple arm.
If you already have a pair that you like, you can compare it to these
measurements.
### Made from Stainless Steel
Oscar Wylee’s Soma frame is a women’s oval &amp; round sunglasses frame
that is perfect for those with square, oval or heart face shapes. The
Soma frame is a sleek, widely wearable frame that can be worn every
day. The main specs of Oscar Wylee’s Soma glasses frame including
dimensions, shape, materials, lenses, nose fit and hinges
are listed below.
Filter category 3 - General purpose sunglasses. High protection against
sunglare. Good UV Protection.Not suitable for driving in twilight, at
night or under dull conditions
This frame comes with polarised lenses. An additional $100 will be
added to your order total for prescription orders.
| Soma Frame Features | Soma Frame Description | Dimensions | Shape | Materials | Lenses | Nose Fit | Hinges |
| --- | --- | --- | --- | --- | --- | --- | --- |
| The dimensions of the Soma frame are measured in millimetres (mm)
and are 50 - 20 - 145, meaning the lens width is 50 mm, the bridge
is 20 mm and the temple length is 145 mm. |
| The Soma frame is a round shape, well suited to medium faces. |
| Soma glasses are made from a material called stainless steel and
acetate. |
| The lenses that can be used in the Soma frame are sunglass lenses,
which provide UV protection. Optical lenses are also available for
the Soma sunglass frame, however, this is only available for
in-store purchases. |
| The nose fit of Soma frames is fitted with adjustable nose pads. |
| The hinges in Soma glasses are normal hinges, also known as
standard or barrel hinges. |
Show All
### What Inspired the Frame Design of Oscar Wylee’s Soma
Glasses?
The Oscar Wylee Soma frame design was inspired by current fashion
trends as oval &amp; round shapes are often in fashion. A square
glasses shape is timeless meaning it remains popular throughout
the decades while other trends pass.
## What to Know About Oscar Wylee’s Soma Glasses?
There are many aspects of the Oscar Wylee Soma frames that
customers should know about, so they can decide whether this is
the right frame for them. The Soma frame is a women's oval &amp; round
shaped frame. Oscar Wylee’s Soma frame is suitable for many face
shapes but particularly compatible with square, oval or heart
shapes. The Soma frame’s simple design means that they are
fashionable all year round. Soma glasses feature the standard
[parts of glasses](https://www.oscarwylee.com.au/glasses/eye/part-of-glasses)
such as a rim, temples, lenses, hinges and an adjustable nose pad
fit.
### What are the
Types of Temple Tips or Earpieces Included with Oscar
Wylee’s Soma Glasses?
The type of temple tips or earpieces included in Oscar Wylee’s
Soma Glasses are made from acetate.
### What Type of Nose Bridge do Oscar Wylee’s Soma Glasses
Have?
The type of nose bridge included in Oscar Wylee’s Soma frame is a
low nose bridge fit.
### What Type of Nose Pads are Included with Oscar Wylee’s
Soma Glasses?
Oscar Wylee’s Soma includes adjustable silicone nose pads.
### What Type of Lenses do Oscar Wylee’s Soma Glasses Have?
The lenses that can be used in the Soma frame are sunglass lenses,
which provide UV protection. UV protection lenses block harmful
ultraviolet rays, safeguarding eyes from damage. It comes in
Filter Category 3. Filter Category 3 is available for the Soma
sunglasses. This filter provides higher protection against
sunglare. They are not suitable for use while driving at night.
Prescription lenses are also available for the Soma sunglass
frame, in-store only.
### What Material is Used for the Rim of Oscar Wylee’s Soma
Glasses?
The material used for the rim of Oscar Wylee’s Soma glasses frames
is stainless steel. The rim refers to the part of a glasses frame
that holds the lenses.
### What Type of Hinges are Included with Oscar Wylee’s
Soma Glasses?
The type of hinges included with Oscar Wylee’s Soma frames are
normal hinges. These provide strength and smooth movement,
connecting the frame’s arms and lenses.
## What Face Types are Most Suitable for Oscar Wylee’s
Soma Glasses?
The face types that are most suitable for Oscar Wylee’s Soma frame
are square, oval or heart faces. The Soma frame is a round &amp; oval
shape, meaning that it complements the structure of round, oval,
and heart faces particularly well. The Soma frames help to balance
the features of an
[oval face shape](https://www.oscarwylee.com.au/glasses/face-shapes/oval),
[round face shape](https://www.oscarwylee.com.au/glasses/face-shapes/round), and
heart face shape, bringing the eyes and brows forward in a
flattering way. Although there are many
[glasses for face shapes](https://www.oscarwylee.com.au/glasses/face-shapes)
that may be considered more aesthetically suitable, it is
important that people also choose the frames that make them feel
most comfortable, and represent their personal style.
## What Size Options are Available for Oscar Wylee’s Soma
Glasses?
The size options available for Oscar Wylee’s Soma frame are a
medium frame fit across all colours.
## What Materials are Used to Create Oscar Wylee’s Soma
Glasses?
The primary material used to create the Oscar Wylee Soma frame is
stainless steel. Stainless steel is a highly durable and strong
material, ensuring a firm foundation for your sunglasses. Acetate
is used for the creation of the temple tips. Acetate, also known
as cellulose acetate, is a bioplastic, made from cotton fibres or
wood pulp.
## What’s Included
## What's Included
Each pair of glasses comes with a stylish frame case and lens cloth. We offer free shipping across Australia and 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects.
* Free Shipping for Australian Orders
* 1 Year Warranty on frames and lenses
* Scratch resistance lens coating on all prescriptions
* UV-proof coating on all prescriptions
* Stylish case and cloth
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
## Make and Materials
The frames then go through cleaning and strict quality control, and many pairs of crafting hands to be hand-assembled and polished. After your frames have gone through the production process, they are individually examined and packed before making their way to you!As part of our durable frame family, some of our most popular styles, are now in stainless steel. These frames are hypoallergenic, corrosion resistant, light weight, and not sensitive to temperature changes.
## Warranty Information
### Warranty Information
### Warranty Information
Oscar Wylee provides a 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects. 
We will repair or replace faulty or defective frames or lenses free of charge for warranty claims made within 1 year of the delivery.
We also offer repairs or replacement for problems experienced with vision during everyday use for claims made within 30 days of delivery. If the same product has been discontinued or is no longer available, then we may offer an exchange for a similar product or a refund.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Find a Store Location](https://www.oscarwylee.com.au/locations/full-store-list.html)
Recommended
1. [](https://www.oscarwylee.com.au/sunglasses/materials/bryce-sunglass.html)
[Bryce](https://www.oscarwylee.com.au/sunglasses/materials/bryce-sunglass.html)
Rose Gold
2. [](https://www.oscarwylee.com.au/haskell-sunglasses.html)
[Haskell](https://www.oscarwylee.com.au/haskell-sunglasses.html)
Rose Gold