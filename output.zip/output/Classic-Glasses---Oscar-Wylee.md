# Source: https://www.oscarwylee.com.au/glasses/silhouette/classic.html

44 Products        
Showing 15 of 44
1. [](https://www.oscarwylee.com.au/serge-optical.html)
[Serge](https://www.oscarwylee.com.au/serge-optical.html)
$169.00    
[2 pairs from $199](https://www.oscarwylee.com.au/serge-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/serge-optical.html)
2. [](https://www.oscarwylee.com.au/kato-optical.html)
[Kato](https://www.oscarwylee.com.au/kato-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/kato-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/kato-optical.html)
3. [](https://www.oscarwylee.com.au/duckworth-optical.html)
[Duckworth](https://www.oscarwylee.com.au/duckworth-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/duckworth-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/duckworth-optical.html)
4. [](https://www.oscarwylee.com.au/soma-optical.html)
[Soma](https://www.oscarwylee.com.au/soma-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/soma-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/soma-optical.html)
5. [](https://www.oscarwylee.com.au/chamberlain-optical.html)
[Chamberlain](https://www.oscarwylee.com.au/chamberlain-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/chamberlain-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/chamberlain-optical.html)
6. [](https://www.oscarwylee.com.au/charlie-optical.html)
[Charlie](https://www.oscarwylee.com.au/charlie-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/charlie-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/charlie-optical.html)
7. [](https://www.oscarwylee.com.au/kent-optical.html)
[Kent](https://www.oscarwylee.com.au/kent-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/kent-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/kent-optical.html)
8. [](https://www.oscarwylee.com.au/ava-optical.html)
[Ava](https://www.oscarwylee.com.au/ava-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/ava-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/ava-optical.html)
9. [](https://www.oscarwylee.com.au/betty-optical.html)
[Betty](https://www.oscarwylee.com.au/betty-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/betty-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/betty-optical.html)
10. [](https://www.oscarwylee.com.au/mischa-optical.html)
[Mischa](https://www.oscarwylee.com.au/mischa-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/mischa-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/mischa-optical.html)
11. [](https://www.oscarwylee.com.au/oliver-optical.html)
[Oliver](https://www.oscarwylee.com.au/oliver-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/oliver-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/oliver-optical.html)
12. [](https://www.oscarwylee.com.au/leo-optical.html)
[Leo](https://www.oscarwylee.com.au/leo-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/leo-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/leo-optical.html)
13. [](https://www.oscarwylee.com.au/sadie-optical.html)
[Sadie](https://www.oscarwylee.com.au/sadie-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/sadie-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/sadie-optical.html)
14. [](https://www.oscarwylee.com.au/marco-optical.html)
[Marco](https://www.oscarwylee.com.au/marco-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/marco-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/marco-optical.html)
15. [](https://www.oscarwylee.com.au/luca-optical.html)
[Luca](https://www.oscarwylee.com.au/luca-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/luca-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/luca-optical.html)
44 Products        
Showing 15 of 44
Choosing Classic Glasses Suitability Classic Glasses FAQs
## How to Choose the Best Classic Glasses for Women?
To choose the best classic [glasses frames for women](https://www.oscarwylee.com.au/glasses/sunglasses/best-for-men), you should consider face shape, frame size, colour of the frames and accentuating your personality. These are also factors to think about when selecting the [best women's glasses](https://www.oscarwylee.com.au/glasses/best-women) regardless of frame shape. The considerations for how to choose the best classic glasses for women are listed below.
* Consider face shape: Consider face shape when choosing the best classic glasses for women. Classic glasses are best suited to square, oval and pear faces, however other faces can benefit from their shape, which is neither too curved or angular. Try them on to assess how they complement your face shape.
* Frame size: Consider frame size by trying them on yourself, as this allows you to truly assess how they fit on your face. A good rule of thumb to remember is that the frame should align with your temples and not extend lengthwise past the eyebrows.
* The colour of your frames: Consider the colour of your classic glasses based on your appearance and sense of style. For example, if you enjoy warm colours such as tortoiseshell, you should opt for a classic frame in that colour, which is notable for complementing warm skin tones.
* Accentuate your personality: Accentuate your personality with your glasses! For example, a classic frame with metal embellishments is perfect for those who want a luxe accessory.
[](https://www.oscarwylee.com.au/julia-optical.html)
[Julia](https://www.oscarwylee.com.au/julia-optical.html)
$169    
Add to Cart
[Shop Julia](https://www.oscarwylee.com.au/julia-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/julia-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/julia-optical.html)
[](https://www.oscarwylee.com.au/evie-optical.html)
[Evie](https://www.oscarwylee.com.au/evie-optical.html)
$169    
Add to Cart
[Shop Evie](https://www.oscarwylee.com.au/evie-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/evie-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/evie-optical.html)
[](https://www.oscarwylee.com.au/poppy-optical.html)
[Poppy](https://www.oscarwylee.com.au/poppy-optical.html)
$169    
Add to Cart
[Shop Poppy](https://www.oscarwylee.com.au/poppy-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/poppy-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/poppy-optical.html)
## How to Choose the Best Classic Glasses for Men?
To choose the best classic glasses for men, you should browse men's classic glasses, consider face shape, frame size and the colour of the frames. These factors are similar to how you would choose the [best glasses for men](https://www.oscarwylee.com.au/glasses/best-men-eyeglasses-for-every-face-shape), regardless of frame shape. The considerations for how to choose the best classic glasses for men are listed below.
* Browse Men's Classic Glasses: Browse men's classic glasses to see shapes and sizes that are best compatible with men's faces. You can even try unisex glasses to get a broader selection of classic glasses options.
* Consider Face Shape: Consider face shape when choosing the best classic glasses for men. Classic glasses are best suited to square, oval and pear faces, however other faces can benefit from their shape which is neither too curved or angular. Try them on to assess how they complement your face shape.
* Frame Size: Consider frame size by trying them on yourself, as this allows you to truly assess how they fit on your face. A good rule of thumb to remember is that the classic frame should align with your temples and not extend past the eyebrows.
* The Colour of your Frames: Consider the colour of your frames based on your appearance and everyday attire. For example, cooler classic frames such as in silver and navy blue complement pale skin, which has cool tones.
[](https://www.oscarwylee.com.au/connor-optical.html)
[Connor](https://www.oscarwylee.com.au/connor-optical.html)
$169    
Add to Cart
[Shop Connor](https://www.oscarwylee.com.au/connor-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/connor-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/connor-optical.html)
[](https://www.oscarwylee.com.au/poppy-optical.html)
[Poppy](https://www.oscarwylee.com.au/poppy-optical.html)
$169    
Add to Cart
[Shop Poppy](https://www.oscarwylee.com.au/poppy-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/poppy-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/poppy-optical.html)
### How to Choose Classic Glasses According to Skin Tone?
To choose classic glasses according to skin tone, determine your skin undertone, and choose your frames to align with this. Determine your undertone by checking the colour of the veins on your inner wrist/forearm. If they look blue or purple, you may have cool undertones and fair skin; if they look green, you may have warm undertones and darker skin. However, if you have a mix of blue and green, you may be considered neutral-toned. Choose classic glasses that are complementary to your skin tone. For those with cool undertones, opt for blues, silver or green classic glasses which are also cool colours. For those with warm undertones, opt for similarly warm colours such as gold and bronze. Neutral-toned skin can opt for a variety of colours due to the balance of cool and warm skin tones.
### How to Choose Classic Glasses According to Face Shape?
To choose classic glasses according to [face shape](https://www.oscarwylee.com.au/glasses/face-shapes), you should determine your face shape and see if classic glasses suit it well. The best face shapes for classic glasses are square, oval and pear face shapes. While these are the recommended face shapes for classic glasses, it is also a good idea to try a pair on for yourself, regardless if you have these face shapes. Read on for how to choose the classic glasses according to face shape below.
* Oval Faces: Oval faces have an oblong shape with a wide forehead and a rounder jawline and chin. Classic glasses are one of the [best glasses for the oval shape](https://www.oscarwylee.com.au/glasses/face-shapes/oval) as they balance out this longer face shape.
* Square Faces: Square faces are equal in width and length. The [best glasses for square face](https://www.oscarwylee.com.au/glasses/face-shapes/square) are classic glasses as they soften the pronounced angles of the square face.
* Pear Shaped Faces: Pear shaped faces will have a narrow forehead and a fuller jaw. Classic glasses are one of the [best glasses for pear shaped face men and women](https://www.oscarwylee.com.au/glasses/face-shapes/pear) balance out the differing proportions of the forehead and jawline of this face.
### How to Choose Classic Glasses According to Eye Colour?
Eye colour will not likely play a big role in choosing classic glasses that best suit your appearance. Other factors such as overall style, face shape, skin colour and hair colour will have more influence in determining the best classic glasses for you.
#### Are Classic Glasses Good for Prescription Use?
Yes, classic glasses are good for prescription use. Classic [prescription glasses](https://www.oscarwylee.com.au/glasses/prescription) incorporate style and practicality as they allow for clear vision and timeless charm for the wearer.
#### Are Classic Glasses Suitable for Seniors?
Yes, classic glasses are definitely suitable for seniors. Classic [senior glasses](https://www.oscarwylee.com.au/glasses-for-seniors.html) come in an array of shapes from round to browline, and colours, able to complement any senior's face shape.
## How to Choose Classic Glasses According to Bridge Width?
Classic glasses can be chosen according to bridge width for a compatible fit, such as narrow, medium and wide. Bridge width is [type of nose bridge](https://www.oscarwylee.com.au/glasses/nose-bridge-types). Read about how to buy classic glasses according to bridge width below.
* Narrow: Narrow classic glasses are available for petite and thinner faces who need a more compatible fitting frame to sit on the face comfortably and not slide off.
* Medium: Medium classic glasses are accommodating for faces with medium widths, often worn amongst all genders.
* Wide: Wide classic glasses are intended to accommodate broader and wider faces for a non-constrictive fit. They also work well for those who want an oversized classic frame.
[](https://www.oscarwylee.com.au/bronwyn-optical.html)
[Bronwyn](https://www.oscarwylee.com.au/bronwyn-optical.html)
$169    
Add to Cart
[Shop Bronwyn](https://www.oscarwylee.com.au/bronwyn-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/bronwyn-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/bronwyn-optical.html)
[](https://www.oscarwylee.com.au/humphrey-optical.html)
[Humphrey](https://www.oscarwylee.com.au/humphrey-optical.html)
$169    
Add to Cart
[Shop Humphrey](https://www.oscarwylee.com.au/humphrey-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/humphrey-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/humphrey-optical.html)
[](https://www.oscarwylee.com.au/peggy-optical.html)
[Peggy](https://www.oscarwylee.com.au/peggy-optical.html)
$169    
Add to Cart
[Shop Peggy](https://www.oscarwylee.com.au/peggy-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/peggy-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/peggy-optical.html)
### Which Frame Colour Looks Best on Classic Glasses?
The frame colour patterns that may be best for classic glasses can include matte, solid, striped, tortoiseshell and transparent. The best colour patterns for classic glasses are listed below.
* Matte Classic Glasses: Matte classic glasses refers to a low-gloss, flat-looking finish for a sleek, good-looking frame.
* Solid Classic Glasses: Solid classic glasses provide wearers with a monochromatic look that's easy to incorporate with their personal style.
* Striped Classic Glasses: Striped classic glasses provide a timeless pattern for a modern, stylish frame.
* Tortoiseshell Classic Glasses: Tortoiseshell classic glasses offer a blend of often warm tones for an effortlessly stylish accessory, perfect for the classic frame.
* Transparent Classic Glasses: Transparent or clear glasses offer a modern twist on a classic frame due to their rise in popularity.

#### Are Oversized Classic Glasses Suitable for Everyday Wear?
Yes, oversized classic glasses are suitable for everyday wear. Like any other frame in our Classic Glasses collection, [oversized glasses](https://www.oscarwylee.com.au/glasses/silhouette/oversized.html) are practical and a stunning option for everyday wear that will never go out of style.
#### Are Classic Prescription Glasses a Good Option for Teenagers?
Yes, classic prescription glasses are a good option for teenagers. These frames, with their varied colours, patterns and sizes can appeal to every teenager's sense of style and provide visual sharpness and clarity.
### Why are Classic Glasses Popular for Everyday Wear?
Classic glasses are popular for everyday wear as they combine practicality and beauty. Classic glasses are a balanced shape, not too round or angular. This makes them a timeless frame with the ability to pair seamlessly with everyday outfits. Alongside this, classic glasses with prescription lenses allows for clearer and sharper vision for the wearer, making them a popular option for everyday wear.
### Why are Classic Glasses a Top Pick for Modern Professionals?
Classic glasses are a top pick for modern professionals due to their timeless shape and ability to fit in seamlessly in professional settings. Classic glasses refer to frame shapes that are a combination of a square and circle. This subtle shape, easily accommodating to many face shapes, makes them the perfect option for [professional glasses](https://www.oscarwylee.com.au/glasses/professional-eyewear). With a variety of shapes and colours found in classic glasses, it can be easy to find the perfect pair to fit into your professional life.
### What Factors Affect the Price of Classic Glasses?
The price factors for classic glasses at Oscar Wylee will vary depending on elements such as lens index and other add-ons. One pair of classic glasses in our core range starts from $169, 2 pairs from $199 and 3 pairs from $249, not inclusive of high index lenses or other add-ons. Read our full [price guide](https://www.oscarwylee.com.au/price-guide/) for more information.
### How to Adjust Classic Glasses for a Comfortable Fit?
To adjust your classic glasses for a comfortable fit, you should bring your frame to an optical retailer to have it done professionally. It is always best to have any repairs or adjustments done at your optical retailer, as making alterations yourself or at other establishments may not be covered by warranty. At Oscar Wylee, we offer lifetime adjustments for those who have purchased classic glasses or other types of eyewear from us.
#### Are Transition Lenses Available in the Classic Glasses Collection?
Yes, transition lenses are available for frames in the classic glasses collection. [Transition lenses](https://www.oscarwylee.com.au/glasses/eye/photochromic-lenses) are smart lenses that automatically darken when you're in the sun and quickly return to clear when you are indoors. These are a convenient option for those who do not want to carry sunglasses around alongside their optical frames. At Oscar Wylee, adding transition lenses to your frames can only be done in-store.
#### Are Classic Black Glasses Ideal for All Seasons?
Yes, classic black glasses are ideal for all seasons. Black is a versatile colour, easily paired with any attire regardless of the weather. Classic black glasses can be a striking and practical accessory.
## What Lens Types Work Best for Classic Glasses?
The lens types that can work best for classic glasses will come down to your prescription and personal lifestyle needs. For example, if you have a high prescription, you may need to opt for high index lenses. Additionally, if you use the computer frequently you may want to opt for a BluLite filter which blocks or reduces the blue light emitted from digital screens.
### What Outfits Work Best with Stylish Classic Glasses?
Any outfit can work best with stylish classic glasses. Outfit compatibility will ultimately be determined by the colour of your glasses and your clothing. Otherwise, any type of attire can work best with stylish classic glasses. Whether a jeans and t-shirt combination, maxi dresses, suits, or jumpsuits, stylish classic glasses can instantly enhance any look.
### How Long Does It Take to Get Prescription Classic Glasses?
It can take within 7-10 business days from the date of purchase when collecting in-store to get prescription rectangle glasses. A team member will contact you once your glasses have passed through all the quality control checks and are ready for collection. If your rectangle glasses are being shipped to your home, it may take up to 2 weeks to arrive. This includes the production time of 7-10 business days and additional time for shipping.
### What is the Return or Refund Policy for Classic Glasses?
The return or refund policy for classic glasses will depend on whether they are prescription or non-prescription and/or the type of prescription. Since each pair of glasses is customised based on your prescription, Oscar Wylee does not offer any exchange or refund for change of mind on prescription items. However, Oscar Wylee offers a 1 year warranty from the date of delivery covering manufacturing faults or defects in frames and lenses, with free repair or replacement during this period. We also provide repair or replacement for vision-related issues experienced during everyday use within 30 days of delivery. If a product has been discontinued, an exchange for a similar item or a refund may be offered. This warranty operates in addition to your rights under Australian Consumer Law.
### How Are High-Quality Classic Glasses Manufactured?
Our high quality classic glasses are manufactured through a careful blend of quality materials, precision engineering, and skilled assembly. Acetate classic frames start with bio-based cellulose acetate derived from natural fibres, cut to create both solid and uniquely patterned designs. The front of each acetate frame is then milled from a single block and shaped, polished, and refined through multiple hand-finished steps. Metal frames start as fine wire that's formed, welded, and assembled piece by piece for strength and durability. After shaping, all frames undergo extensive polishing and tumbling for a smooth, comfortable finish. Hinges, rivets, and temples are fitted by hand, lenses are individually cut to match each frame, and every pair is thoroughly inspected to ensure it meets our quality standards before it reaches you.
[Prescription Glasses](https://www.oscarwylee.com.au/glasses.html)
[Women’s Glasses](https://www.oscarwylee.com.au/glasses/collection/womens-glasses.html)
[Men’s Glasses](https://www.oscarwylee.com.au/glasses/collection/mens-glasses.html)
[Senior Glasses](https://www.oscarwylee.com.au/glasses/collection/seniors.html)
[Glasses for Kids](https://www.oscarwylee.com.au/glasses/collection/kids-collection.html)
const productContainers = document.querySelectorAll(".product-container");
const nxtBtn = document.querySelectorAll(".nxt-btn");
const preBtn = document.querySelectorAll(".pre-btn");
productContainers.forEach((item, i) => {
// Count the number of images in the current product container
const imageCount = item.querySelectorAll("img").length;
if (imageCount  {
item.scrollLeft += containerWidth + 3;
});
preBtn[i].addEventListener("click", () => {
item.scrollLeft -= containerWidth;
});
}
});
window.onload = function () {
document.body.className += " loaded";
};
