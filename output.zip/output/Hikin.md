# Source: https://www.oscarwylee.com.au/hikin-sunglasses.html

# Hikin
1
## Frame Design of Hikin Sunglasses
The frame design of Oscar Wylee’s Hikin sunglasses is characterised by a classic oval and round shape, low nose bridge, and an acetate frame. Hikin glasses are a women's statement frame that will work for any occasion, whether the wearer wants to liven up their work style or complement an outfit for a night out.
$169    
In stock
Only %1 left
2 pairs from $199
Discount auto-applied at checkout
3 pairs from $249
Discount auto-applied at checkout
* 2 &amp; 3 Pair pricing applies to non-prescription sunglasses only. Prescription sunglasses incur additional charges.    
[Non-Prescription](https://www.oscarwylee.com.au/hikin-sunglasses.html#)
Qty
Prescription
Book an eye test
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
excluding prescription lenses
## About Hikin Frames
Acetate never looked so good! Hikin is a wide fit frame with rounded
lenses and sharp temples. The perfect unisex frame.
| Frame fit | Measurements |
| --- | --- |
| Wide | 56 - 17 - 145 |
These measurements mean lens width, bridge, and temple length in
millimetres (mm). They can be found on the inside of the temple arm.
If you already have a pair that you like, you can compare it to these
measurements.
### Made from Acetate
Oscar Wylee’s Hikin frame is a women's oval and round sunglasses frame
that is perfect for those with square, oval and heart face shapes. The
Hikin frame is a sleek, widely wearable frame that can be worn every
day. The main specs of Oscar Wylee’s Hikin glasses frame
dimensions, shape, materials, lenses, nose fit and hinges
are listed below.
Filter category 2 (Midnight Blue only) - General purpose sunglasses.
Good protection against sunglare. Good UV Protection.Not suitable for
driving in twilight, at night or under dull conditions
This frame comes with gradient lenses. An additional $30 will be
added to your order total for prescription orders.
Filter category 3 (Candy Brown only) - General purpose
sunglasses. High protection against sunglare. Good UV Protection. Not
suitable for driving in twilight, at night or under dull conditions
This frame comes with tinted lenses. An additional $30 will be
added to your order total for prescription orders.
| Hikin Frame Features | Hikin Frame Description | Dimensions | Shape | Materials | Lenses | Nose Fit | Hinges |
| --- | --- | --- | --- | --- | --- | --- | --- |
| The dimensions of the Hikin frame are measured in millimetres (mm)
and are 56 - 17 - 145, meaning the lens width is 56 mm, the bridge
is 17 mm and the temple length is 145 mm. |
| The Hikin frame is an oval and round shape, well suited to wide
faces. |
| Hikin glasses are made from acetate. |
| The lenses that can be used in the Hikin frame are sunglass
lenses, which provide UV protection. Prescription lenses are also
available for the Hikin sunglass frame, however this is only
available for in-store purchases. |
| The nose fit of the Hikin frame is a low nose bridge fit. |
| The hinges in Hikin glasses are normal hinges, also known as
standard or barrel hinges. |
Show All
### What Inspired the Frame Design of Oscar Wylee’s Hikin
Glasses?
The Oscar Wylee Hikin frame design was inspired by current fashion
trends as oval shapes are often in fashion. An oval glass shape is
timeless meaning it remains popular throughout the decades while
other trends pass.
## What to Know About Oscar Wylee’s Hikin Glasses?
There are many aspects of the Oscar Wylee Hikin frames that
customers should know about, so they can decide whether this is
the right frame for them. The Hikin frame is a women's oval shaped
frame. Oscar Wylee’s Hikin frame is suitable for many face shapes
but particularly compatible with square, oval and heart face
shapes. The Hikin frame’s simple design means that they are
fashionable all year round. Hikin glasses feature the standard
[parts of glasses](https://www.oscarwylee.com.au/glasses/eye/part-of-glasses) such
as a rim, temples, lenses, hinges and a low nose bridge.
### What are the
Types of Temple Tips or Earpieces Included with Oscar
Wylee’s Hikin Glasses?
The type of temple tips or earpieces included in Oscar Wylee’s
Hikin Glasses are made from acetate.
### What Type of Nose Bridge do Oscar Wylee’s Hikin Glasses
Have?
The type of nose bridge included in Oscar Wylee’s Hikin is an
adjustable nose pad.
### What Type of Nose Pads are Included with Oscar Wylee’s
Hikin Glasses?
Oscar Wylee’s Hikin frame does not include adjustable silicone
nose pads.
### What Type of Lenses do Oscar Wylee’s Hikin Glasses
Have?
The lenses that can be used in the Hikin frame are sunglass
lenses, which provide UV protection. UV protection lenses block
harmful ultraviolet rays, safeguarding eyes from damage. The Hikin
Frame comes in Filter Category 2 for Midnight Blue and Filter
Category for Candy Brown. These are general purpose sunglasses.
High protection against sunglare. Good UV Protection. Not suitable
for driving in twilight, at night or under dull conditions.
Prescription lenses are also available for the Hikin sunglass
frame, in-store only.
### What Material is Used for the Rim of Oscar Wylee’s
Hikin Glasses?
The material used for the rim of Oscar Wylee’s Hikin glasses
frames is acetate. The rim refers to the part of a glasses frame
that holds the lenses.
### What Type of Hinges are Included with Oscar Wylee’s
Hikin Glasses?
The type of hinges included with Oscar Wylee’s Hikin frames are
normal hinges. These provide strength and smooth movement
connecting the frame’s arms and lenses.
## What Face Types are Most Suitable for Oscar Wylee’s
Hikin Glasses?
The face types that are most suitable for Oscar Wylee’s Hikin
frame are square, oval and heart faces. The Hikin frame is an oval
shape, meaning that it complements the structure of square, oval
and heart faces particularly well. The Hikin frames help to
balance the features of a
[square face shape](https://www.oscarwylee.com.au/glasses/face-shapes/square)
, heart face shape or
[oval face shape](https://www.oscarwylee.com.au/glasses/face-shapes/oval), bringing
the eyes and brows forward in a flattering way. Although there are
many
[glasses for face shapes](https://www.oscarwylee.com.au/glasses/face-shapes)
that may be considered more aesthetically suitable, it is
important that people also choose the frames that make them feel
most comfortable, and represent their personal style.
## What Size Options are Available for Oscar Wylee’s Hikin
Glasses?
The size options available for Oscar Wylee’s Hikin frame is a wide
frame fit across all colours.
## What Materials are Used to Create Oscar Wylee’s Hikin
Glasses?
The primary material used to create the Oscar Wylee Hikin frame is
acetate. The rim, nose bridge, temple and temple tips are made
from acetate.
## What’s Included
## What's Included
Each pair of glasses comes with a stylish frame case and lens cloth. We offer free shipping across Australia and 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects.
* Free Shipping for Australian Orders
* 1 Year Warranty on frames and lenses
* Scratch resistance lens coating on all prescriptions
* UV-proof coating on all prescriptions
* Stylish case and cloth
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
## Make and Materials
The frames then go through cleaning and strict quality control, and many pairs of crafting hands to be hand-assembled and polished. After your frames have gone through the production process, they are individually examined and&nbsp;packed before making their way to you!Also known as cellulose acetate, these frames are traditionally hand-crafted by skilled craftsmen, with each frame passing through numerous stages of production and are hand-polished to ensure a glorious lustre.
## Warranty Information
### Warranty Information
### Warranty Information
Oscar Wylee provides a 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects. We will repair or replace faulty or defective frames or lenses free of charge for warranty claims made within 1 year of the delivery. We also offer repairs or replacement for problems experienced with vision during everyday use for claims made within 30 days of delivery. If the same product has been discontinued or is no longer available, then we may offer an exchange for a similar product or a refund.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Find a Store Location](https://www.oscarwylee.com.au/locations/full-store-list.html)