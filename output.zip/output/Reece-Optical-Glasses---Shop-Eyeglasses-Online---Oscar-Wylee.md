# Source: https://www.oscarwylee.com.au/reece-optical.html

# Reece
1
## Frame Design of Reece Glasses
The frame design of Oscar Wylee’s Reece glasses is characterised by their geometric shape, nose pads, and titanium and acetate frame. Reece is a unisex, statement glasses frame that will complement any outfit, day to night.
$199    
In stock
Only %1 left
2 pairs from $249
Discount auto-applied at checkout
Qty
Add to cart
Book an eye test
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
excluding prescription lenses
## About Reece Frames
The Reece is the perfect companion to have as you bask in the ever-changing landscape. We love the metal detailing on the temples, further elevating the feminine frame.
| Frame fit | Measurements |
| --- | --- |
| MEDIUM | 53 - 19 - 145 |
These measurements mean lens width, bridge, and temple length in millimetres (mm). They can be found on the inside of the temple arm. If you already have a pair that you like, you can compare it to these measurements.
### Made from Titanium and Acetate
Oscar Wylee’s Reece frame is a unisex geometric glasses frame that is perfect for those with round and oval face shapes. The Reece frame is a stylish, striking frame that can be worn every day. The main specs of Oscar Wylee’s Reece glasses frame, including dimensions, shape, materials, lenses, nose fit, and hinges, are listed below.
| Reece Frame Features | Reece Frame Description | Dimensions | Shape | Materials | Lenses | Nose Fit | Hinges |
| --- | --- | --- | --- | --- | --- | --- | --- |
| The dimensions of the Reece frame are measured in millimetres (mm) and are 53 - 19 - 145, meaning the lens width is 53 mm, the bridge is 19 mm, and the temple length is 145 mm. |
| Reece is a geometric shape, well-suited to medium faces. |
| Reece is made from titanium and acetate. |
| The lenses that can be used in the Reece frame include optical lenses, such as single-vision and multifocal, and non-prescription lenses, which are plain and can have a filter, such as a blue light filter applied. |
| The nose fit for Reece is characterised by nose pads. |
| The hinges in Reece are normal hinges, also known as standard or barrel hinges. |
Show All
### What Inspired the Frame Design of Oscar Wylee’s Reece Glasses?
The Oscar Wylee Reece frame design was inspired by current fashion trends, as geometric glasses are a timeless style.
## What to Know About Oscar Wylee’s Reece Glasses?
There are many aspects of the Oscar Wylee Reece frames that customers should know about to decide whether this is the right frame for them. The Reece frame is a unisex geometric-shaped frame. Oscar Wylee’s Reece frame is suitable for many face shapes, but particularly compatible with round and oval face shapes. The Reece frame’s simple design makes them fashionable all year round. Reece features the standard [parts of glasses](https://www.oscarwylee.com.au/glasses/eye/part-of-glasses), such as a rim, temples, lenses and hinges.
### What are the Types of Temple Tips or Earpieces Included with Oscar Wylee’s Reece Glasses?
The type of temple tips or earpieces included in Oscar Wylee’s Reece Glasses are made from acetate.
### What Type of Nose Bridge do Oscar Wylee’s Reece Glasses Have?
The type of nose bridge included in Oscar Wylee’s Reece frame is characterised by adjustable nose pads.
### What Type of Nose Pads are Included with Oscar Wylee’s Reece Glasses?
Oscar Wylee’s Reece frame includes adjustable nose pads.
### What Type of Lenses do Oscar Wylee’s Reece Glasses Have?
The type of lenses that typically come with the Oscar Wylee Reece [glasses frame](https://www.oscarwylee.com.au/glasses.html) are optical lenses. Optical lenses are glasses lenses that have a prescription within the lens to help correct vision issues such as myopia, hyperopia, and astigmatism. Reece frames can also come as sunglasses and with non-prescription lenses and add-ons such as a blue light filter. Reece frames can be customised into sunglasses in-store or online with add-on tints or polarisation.
### What Material is Used for the Rim of Oscar Wylee’s Reece Glasses?
The material used for the rim of Oscar Wylee’s Reece glasses frames is titanium and acetate. The rim refers to the part of a glasses frame that holds the lenses.
### What Type of Hinges are Included with Oscar Wylee’s Reece Glasses?
The type of hinges included with Oscar Wylee’s Reece frames are normal hinges, also known as standard or barrel hinges. These provide strength and smooth movement connecting the frame's arms and lenses.
## What Face Types are Most Suitable for Oscar Wylee’s Reece Glasses?
The face types that are most suitable for Oscar Wylee’s Reece frame are round and oval face types. The Reece frame is a geometric shape, meaning that it complements the structure of oval and round faces particularly well. The geometric Reece frames help balance the features of [round faces](https://www.oscarwylee.com.au/glasses/face-shapes/round) and [oval faces](https://www.oscarwylee.com.au/glasses/face-shapes/oval) and bring the eyes and brows forward in a flattering way. Although there are many [glasses for face shapes](https://www.oscarwylee.com.au/glasses/face-shapes) that may be considered more aesthetically suitable, it is important that people also choose frames that make them feel most comfortable and represent their personal style.
## What Size Options are Available for Oscar Wylee’s Reece Glasses?
The size options available for Oscar Wylee’s Reece frame are a medium-frame fit across all colours.
## What Materials are Used to Create Oscar Wylee’s Reece Glasses?
The primary material used to create the Oscar Wylee Reece frame is titanium and acetate. Titanium and acetate are used for the rim. Titanium is used for the nose bridge and temple and the temple tips are made from acetate. Titanium is a lightweight, durable and corrosion-resistant material. Acetate, also known as cellulose acetate, is a bioplastic, made from cotton fibres or wood pulp.
## What’s Included
## OW Case &amp; Cloth
Protective Case and Lens Cloth
Our high-quality glasses case and lens cloth are included with every purchase of an Oscar Wylee frame. The stylish, magnetic case is made from a hard shell. This sturdy and durable material keeps your glasses protected and safe, wherever you go. Ensure your lenses are clean and scratch-free with our OW microfibre cloth, specifically designed to ensure you have comfortable vision through your lenses.
Oscar Wylee offers:
* Free Shipping for Australian Orders
* 1 Year Warranty on frames and lenses
* Scratch resistance lens coating on all prescriptions
* UV-proof coating on all prescriptions
Health fund rebate: Once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. Learn more about [health funds](https://www.oscarwylee.com.au/health-funds.html).
## Make and Materials
Our frames go through numerous stages of production and are hand-polished to ensure a glorious lustre. Featuring a mix of high-quality acetate and polished metal, these mixed materials frames are sure to enhance your eyewear collection.The frames then go through cleaning and strict quality control, and many pairs of crafting hands to be hand-assembled and polished. After your frames have gone through the production process, they are individually examined and packed before making their way to you!
## Warranty Information
### Warranty Information
### Warranty Information
Oscar Wylee provides a 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects. We will repair or replace faulty or defective frames or lenses free of charge for warranty claims made within 1 year of the delivery. We also offer repairs or replacement for problems experienced with vision during everyday use for claims made within 30 days of delivery. If the same product has been discontinued or is no longer available, then we may offer an exchange for a similar product or a refund.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Find a Store Location](https://www.oscarwylee.com.au/locations/full-store-list.html)