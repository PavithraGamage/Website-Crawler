# Source: https://www.oscarwylee.com.au/glasses/eye/pterygium-definition

# Pterygium (Surfer's Eye): Causes, Symptoms, and Treatments
Published on March 8th, 2023
Updated on February 10th, 2025
Australia
[Australia](https://www.oscarwylee.com.au/glasses/eye/pterygium-definition)
New Zealand

[Canada](https://oscarwylee.ca/glasses/eye/pterygium-definition)
Canadian French

The definition of pterygium is a fleshy, triangular growth in the corner of
the eye. This article will explore the pterygium causes, pterygium symptoms
and pterygium treatments. The main cause of pterygium in the eye is thought
to be UV radiation from the sun, as well as environmental factors such as
pollen, sand, smoke, wind and dust, found in hot, dry climates. Pterygium is
an eye condition that may begin as a pinguecula growth. The symptoms of
pterygium include dryness in the eyes, diminished or blurry vision, eye
redness and mild eye pain, a raised, wedge-shaped growth on the eye, the
feeling of having something in your eye and an itchy, burning sensation in
the eye. Pterygium treatment includes eye drops, surgery, topical medication
and protecting the eyes from UV light.
When was your last eye test?
Book an appointment with one of our trusted Oscar Wylee optometrists.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[How Pterygium Develops](#develops)
[Causes](#causes) [Symptoms](#symptoms)
[Treatments](#treatments)
## What is Pterygium?
Pterygium, or surfer's eye, is
a growth of fleshy tissue that covers the conjunctiva, the clear
membrane covering the white part of the eye and the inner
eyelids.
Pterygium usually grows from the inner corner of the eye, but can also
grow from the outer corner, according to Good Vision for Life. Pterygium
is a growth that is benign and non-cancerous, but may affect vision if
it grows big enough to cover the cornea, the transparent part of the eye
that lets in light. Pterygium can start as a pinguecula, a raised, white
or yellow growth on the conjunctiva.
We recommend that you see your optometrist to check any unusual
growths on your eye.
What is pterygium or surfer's eye?Pterygium or
surfer’s eye is a benign eye growth, white or pinkish looking, usually
with visible blood vessels and formed in a triangular shape. A pterygium
will extend from the cornea of the eye across the conjunctiva.
## What are the Other Terms for Pterygium?
The other terms for pterygium are
surfer's eye or farmer’s eye.
According to the American Academy of Ophthalmology, people who are
exposed to high levels of UV light from the sun, as well as wind and
dust in hot and dry climates, are most likely to get pterygium. As
surfers or farmers are known to be regularly exposed to UV radiation and
hot, dry climates, they are the type of people or professions most
likely to get pterygium, which is where the term surfer’s eye or
farmer’s eye originates from.
We recommend that you see your optometrist to check any unusual
growths on your eye.
## How does Pterygium Develop?
Pterygium or surfer’s eye is thought to develop
from prolonged exposure to UV radiation and environmental factors
such as wind, dust and sand from dry and hot climates. A pterygium will usually begin to develop as a raised growth on the
conjunctiva part of the eye.
### How Common is Pterygium?
Pterygium is a [common eye condition](https://www.oscarwylee.com.au/glasses/eye/common-problems), affecting around 1 in 100 Australians, according to the Victorian
Government’s Better Health Channel. Pterygium is more common in older people and in males. It is
estimated that 12% of Australian men over 60 have the condition,
according to the Better Health Channel. Pterygium is also more
common in those that spend extended periods of time exposed to the
sun, as well as wind, dust and hot, dry, environments.
#### Is Pterygium the Most Common Corneal Disease?
Pterygium may be one of the most common corneal diseases in countries where
there is a hot, windy and dry climate, such as Australia. Pterygium is one of the most common [corneal diseases](https://www.oscarwylee.com.au/glasses/eye/corneal-diseases)
in Australia. According to the Victorian Government’s Better
Health Channel, approximately every 1 in 100 Australians will
develop a pterygium.
### What are the Different Pterygium Stages?
There are no definitive stages of pterygium, however,
pterygium may look different and show different symptoms depending
on the progression of the condition.
According to Good Vision for Life, when pterygium first begins to grow
in the early stages, symptoms can be painless, but cause mild
discomfort such as red and inflamed conjunctiva or an itchy, burning
or gritty feeling in the eye. As the condition progresses and moves
into its later stages, where the growth has gotten large, pterygium
can cause dry eyes, and diminished vision if it covers the
conjunctiva.
## What are the Causes of Pterygium?
The exact cause of pterygium is not conclusively known, however, it is
thought the main cause of pterygium is
exposure to ultraviolet (UV) radiation from the sun.
According to Good Vision for Life, environmental factors that are common
in hot and dry climates such as
pollen, sand, smoke, wind and dust, may also contribute
to pterygium. The causes of pterygium are listed below.
* Pollen: Pollen and the eye irritation and
inflammation it can cause, have been theorised to be a contributing
factor in the development of pterygium.
* Sand: Sand, and the irritation it can cause the eye,
may be a contributing factor to the development of pterygium.
* Smoke: Smoke, and the irritation it may cause the eye
may contribute to pterygium development.
* Wind: Wind and the eye irritation it may cause, can
be a contributing cause of pterygium.
* Dust: Dust is an environmental factor in hot and dry
climates and long term exposure to it is thought to be a contributing
cause of pterygium.
* Ultraviolet Radiation: UV radiation from the sun is
thought to be the most common cause of pterygium.
### 1. Pollen
Pollen may be a contributing factor to pterygium or surfer’s eye.
Pollen is a powder-like substance released by plants. Pollen can be an
irritant to those who are prone to allergies and cause symptoms in the
eye such as itchiness, scratchy eyes and watery eyes. Pollen and the
irritation it causes the eye may be a contributing factor to the
development of pterygium.
### 2. Sand
Sand is thought to contribute to the development of pterygium or
surfer’s eye. Sand is the granular material found on beaches,
riverbeds and deserts, made of mineral particles. Sand is commonly
found in hot and dry outdoor climates, which is an environment that
people who develop pterygium tend to be frequently exposed to. Sand
and the irritation it can cause the eye is thought to be a possible
contributing factor to the development of pterygium.
### 3. Smoke
Smoke is thought to contribute to the development of pterygium or
surfer’s eye. Smoke refers to a gathering of airborne particles,
carbon monoxide, carbon dioxide, according to New York State’s
Department of Health. Smoke can be emitted from a range of fire
sources, from bush fires, waste fires or wood fires. The irritation
smoke causes the eye may contribute to pterygium development.
### 4. Wind
Wind may be a contributing cause of pterygium or surfer’s eye. Wind
refers to the movement of air. Wind is a key environmental factor in
hot and dry climates, an environment that people who develop pterygium
tend to be frequently exposed to. Wind, especially strong winds and
winds that pick up debris, can cause eye irritation and damage. Wind
and the irritation it causes the eye is thought to be a contributing
factor in the development of pterygium.
### 5. Dust
Dust is thought to be a contributing factor to the development of
pterygium or surfer’s eye. Dust is a gathering of particles made from
a variety of material such as bacteria, skin-cells, hair, sand, and
dust mites. Dust is an environmental factor common in hot and dry
outdoor climates that can cause eye irritation. Exposure to dust may
be a contributing cause of pterygium.
### 6. Ultraviolet Radiation
Ultraviolet (UV) radiation from the sun is thought to be the most
common cause of pterygium, or surfer’s eye. Ultraviolet radiation is a
type of energy produced by the sun. According to the American Academy
of Ophthalmology, long-term exposure to UV light can be damaging to
the eye, including the surface of the eye and the deeper structures
such as the cornea and the lens. The eye damage caused by UV radiation
can lead to eye cancers, cataracts, and eye growths, such as
pterygium.
#### What Medical Conditions Cause Pterygium?
There are
no medical conditions or pre existing eye conditions that cause
pterygium.
The main causes of pterygium are thought to be exposure to ultraviolet
radiation from the sun and environmental factors such as wind, dust
and sand, that are common in dry and hot climates.
## What are the Symptoms of Pterygium?
The symptoms of pterygium or surfer's eye, include a
dryness in the eyes, diminished or blurry vision, eye redness and
mild eye pain, raised, wedge-shaped growth on the eye, the feeling of
having something in your eye and an itchy, burning sensation in the
eye.
The symptoms a person will have with pterygium may depend on how far the
condition has progressed. The symptoms of pterygium are listed below.
* Dryness: Dry eyes may be a symptom of pterygium if
the growth is affecting the way tears cover or lubricate the eye.
* Diminished vision: Diminished vision may be a symptom
of pterygium that has grown to cover parts of the cornea, blocking the
amount of light allowed into the eye.
* Redness and mild eye pain: A red or inflamed
conjunctiva may be a symptom of pterygium. Mild eye pain may also be a
symptom of pterygium, especially if the conjunctiva is irritated or
inflamed due to the growth.
* A raised, wedge-shaped growth on the surface of the eye:
One of the first symptoms of pterygium is a raised growth on the
conjunctiva.
* The feeling of having something in your eye:  The
feeling of having something stuck in the eye, or a gritty feeling in
the eye, is a symptom of pterygium caused by irritation and
inflammation.
* Itching or burning sensation in the eye:  An itching
or burning sensation in the eye is a common symptom of pterygium
caused by irritation and inflammation.
### 1. Dryness
Eye dryness may be a symptom of pterygium or the surfer's eye. Eye
dryness or [dry eyes](https://www.oscarwylee.com.au/glasses/eye/dry-eyes), describes a condition in which the eyes do not produce enough
tears to provide adequate lubrication to the eye, leaving the eyes
feeling dry. If a person has pterygium, the growth can interfere
with the way tears are produced, or how the tears cover the eye,
causing dry eyes.
### 2. Diminished Vision
Diminished vision can be a symptom of pterygium, or surfer’s eye,
particularly in the later stages where the growth has become larger.
Diminished vision refers to the eye having reduced ability to see
clearly.
Diminished vision can be a symptom of other medical conditions and
should be assessed by a medical professional.
In the case of pterygium, diminished vision will be caused by the
growth pulling on the cornea or covering the cornea, in turn affecting
the line of vision, according to The Australian Pterygium Centre. The
cornea is the clear window at the front of the eye that allows light
in. If the cornea is obstructed it may lead to reduced or diminished
vision.
### 3. Redness and Mild Eye Pain
Redness and mild eye pain can be symptoms of pterygium, or surfer’s
eye. Redness refers to the eyes appearing red or pink in colour, and
displaying signs of inflammation such as swollen conjunctiva and
noticeable blood vessels. Pterygium may cause the eyes to appear red,
inflamed or swollen, due to the irritation the growth causes.
[Red or bloodshot eyes,](https://www.oscarwylee.com.au/glasses/eye/red-or-bloodshot)
and eye inflammation can be both an early and later symptom of
pterygium. Mild eye pain can also be a cause of pterygium or surfer's
eye, though it is not as common as other symptoms. Mild eye pain
refers to a pain that occurs in or around the eye that is not severe
in its intensity. Mild eye pain can occur due to the inflammation and
irritation of the pterygium growth. Eye pain from pterygium should not
be severe and will usually happen in conjunction with other pterygium
symptoms.
If you are experiencing eye pain, it is important to seek medical
attention.
### 4. A Raised, Wedge-Shaped Growth on the Surface of the Eye
A raised, wedge-shaped growth on the surface of the eye is one of the
most common symptoms of pterygium or surfer’s eye. A raised growth on
the eye describes a growth that is not flush to the surface of the
eye, instead standing out or raised above the surface. In the cast of
pterygium, the raised growth will look white or pinkish, triangular in
shape and will often contain blood vessels.
### 5. The Feeling of Having Something in your Eye
The feeling of having something in your eye, also referred to as a
gritty feeling in the eye, describes a rough, uncomfortable feeling in
the eye. The irritation that a pterygium growth causes across the
surface of the eye, or the conjunctiva, may lead to the feeling that
there is something in the eye and is a common symptom of early
pterygium.
### 6. Itching or Burning Sensation in the Eye
An itching or burning sensation in the eye is a common symptom of
pterygium or surfer’s eye. Itching in the eye refers to a sensation of
irritation, or the feeling that your eye needs to be scratched.
Burning in the eye refers to a hot or stinging feeling in the eye. The
irritation that a pterygium growth causes across the surface of the
eye, or the conjunctiva, may lead to itching, burning eyes and is a
common symptom of early pterygium.
### When Do Pterygium Symptoms Usually Occur?
Pterygium, or surfer’s eye symptoms, can
occur at any stage of the condition, but are more common as the
growth progresses.
Early symptoms may be painless and mild, like eye irritation and
redness. Later symptoms, when the growth has advanced, can involve
diminished sight.
### What are the Risk Factors of Pterygium?
The risk factors of pterygium or surfer’s eye include
prolonged exposure to UV light, living close to the equator, living
an outdoor lifestyle, living or working in dry climates and being
older in age.
The risk factors for pterygium are listed below.
* Prolonged exposure to UV light: People who are
frequently exposed to the sun and its UV rays are at higher risk of
pterygium, as UV radiation is thought to be the leading cause of the
pterygium growth.
* Living close to equator: Living in a country close
to the equator increases the risk of developing pterygium as this
location is where the sun and UV radiation is at its highest, with
this thought to be the major cause behind pterygium.
* Outdoor lifestyle: Spending a lot of time outdoors,
in the sun and dry or hot weather, is also a risk factor for
pterygium as it exposes a person to the elements that may cause the
condition.
* Dry Climates: People who work, live or spend
extended periods of time in dry climates may be at higher risk of
pterygium as elements found in this climate, such as wind, dust and
sand can contribute to the development of pterygium.
* Age: According to the Better Health Channel, being
of an older age increases the risk of developing pterygium, with 12%
of men over 60 in Australia estimated to be diagnosed with the
condition.
Looking for your next pair of glasses?
Find your nearest Oscar Wylee store and our friendly staff can
assist you with all your optical and eyewear needs.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
### What are the Pterygium Complications?
The complications of pterygium
mainly involve diminished sight. If pterygium grows
to cover part of the cornea, then it may begin to impact sight. The
cornea is the transparent part of the front of the eye that lets light
in. If the cornea is obstructed by pterygium, it may impact how well
you see. Pterygium that causes vision complications may be treated
with surgery, to remove the growth.
### How is Pterygium Diagnosed?
Pterygium is diagnosed by a
health care professional, likely an optometrist,
during an eye test. An optometrist will use a microscopic tool to
examine the growth and diagnose as appropriate. An optometrist may use
a slit lamp to diagnose pterygium, which is a microscope with a beam
of light that allows close examination of the structures of the eye.
#### Where can you Seek Pterygium Diagnosis?
If you believe you may have pterygium, you can seek a diagnosis from a
health care professional, either a doctor or an optometrist.
## What are the Treatments Available for Pterygium?
The treatments available for pterygium, or surfer’s eye, include
eye drops, surgery, topical medication and protecting the eyes from
UV light. The treatments for pterygium will depend upon how far along the
pterygium is, the symptoms it is causing, and whether or not it is
obstructing the cornea. The types of pterygium treatments available are
listed below.
* Eye drops: Eye drops may be used to treat the
symptoms associated with pterygium, such as dry and irritated eyes and
eye inflammation.
* Surgery: Eye surgery for pterygium aims to remove the
growth and stop it growing over the cornea.
* Topical medication: Topical ointments are a type of
cream like medication that can be applied to the eye and its
surrounding areas, to relieve symptoms of pterygium such as inflamed
eyes.
* UV Protection: If the pterygium growth is small and
painless, protecting the eyes from UV rays may help prevent further
growth.
It is important that you consult with a healthcare professional
before taking any medication. If you think you need pterygium
treatment, seek medical advice.
### 1. Eye Drops
Eye drops are a type of liquid that is applied to the surface of the
eye via an eye dropper.&nbsp;[Eye drops](https://www.oscarwylee.com.au/glasses/eye/types-of-eye-drops)
will not cure nor get rid of a pterygium, but may help to relieve
symptoms of this condition such as dry, irritated or inflamed
eyes.
Eye drops include artificial tears and anti-inflammatory eye drops.
Artificial tears are a type of eye drop that aim to bring lubrication
to the eye. Anti-inflammatory eye drops are a type of eye drops that
contain medication to reduce inflammation in the eye.
Anti-inflammatory eye drops include corticosteroids, which help to
bring down swelling and ease symptoms such as mild eye pain and eye
irritation.
### 2. Surgery
Eye surgery is a common way to treat pterygium and the only way to
remove the growth from the eye. Surgery to remove pterygium describes
a procedure in which an eye surgeon will remove the pterygium, as well
as any affected conjunctival tissue. Eye surgery for pterygium is
usually only used as a treatment when the growth has advanced close to
the cornea and puts sight at risk.
### 3. Topical Medication
Topical medication are medications such as ointments, cream-like,
semi-solid substances, that are applied to the eye and its surrounding
areas. Topical eye ointments will not cure nor get rid of a pterygium,
but it may be used as a treatment for the symptoms that are caused by
this eye condition such as eye irritation, dry eyes and inflammation.
### 4. UV Protection
Protecting the eyes from UV radiation can be used to treat
pterygium if the growth is small and not obstructing the cornea. UV
radiation describes a type of energy produced from the sun.
Prolonged exposure to UV radiation from the sun, has been proven to
have negative effects on the eyes and is thought to be a major cause
of pterygium. Protecting the eyes from UV radiation may help to slow
down the growth of pterygium. This treatment is often recommended in
the early stages, where pterygium is small, not growing over the
cornea and mostly painless, according to the Better Health Channel.
To protect the eyes, it is recommended to wear [UV protection glasses](https://www.oscarwylee.com.au/glasses/best-uv-sunglasses-for-eye-protection)
such as sunglasses, that have full coverage, as well as a hat when
outside in the sun.
#### Are there any Non-Surgical Treatments Available for Pterygium?
Yes, there are non-surgical treatments for pterygium including
eye drops, topical medications and protecting the eyes from UV
rays.
These treatments will not cure pterygium, but may help to treat the
symptoms associated with the conditions.
#### Can Pterygium be Cured Naturally?
Pterygium can not be cured naturally, however,
protecting the eyes from UV radiation is a non-invasive way to slow
the growth if the pterygium is small, painless and not covering the
cornea.
#### What are Some of the Potential Complications of Pterygium Surgery?
The potential complications of pterygium surgery include
scarring and the potential regrowth of the pterygium.
However, surgery to remove a pterygium is generally low-risk and
effective.
## How is Pterygium Prevented?
Pterygium, or surfer’s eye, may be prevented by
limiting exposure to the sun and UV radiation,
according to the The Australian Pterygium Centre. UV radiation is a type
of energy produced by the sun. Long term exposure to UV radiation has
been shown to damage the eyes and is thought to be a major cause for
pterygium. To prevent pterygium, it is recommended to limit eye exposure
to the sun and protect the eyes when outside. Wearing sunglasses can
help prevent pterygium by protecting the eye from UV radiation.
Sunglasses with wide eye cover such as wrap-around sunglasses are best
to protect the eyes. It is also recommended that a person use sunglasses
that meet Australian consumer standards. Wearing a hat is another
important way to prevent pterygium as hats further protect the eyes and
the face from the sun. Wide brim hats with full head and facial coverage
are recommended to protect the eyes. Avoiding the sun at its hotter
periods, or when the UV is at its highest is another way to help prevent
pterygium.
#### Are Pterygiums Curable?
Pterygiums are not necessarily curable. Whilst a
pterygium growth may be removed, it can grow back.
#### Does Wearing Sunglasses Help to Prevent Pterygium?
Yes, wearing sunglasses helps to prevent pterygium, or surfer’s
eye. [Wearing sunglasses](https://www.oscarwylee.com.au/glasses/eye/sunglasses)
can help to prevent pterygium by protecting the eyes from the sun
and its UV rays, which are a major cause of the eye condition. Sunglasses are defined as eyewear that has a tint, or polarization
over the lens, that helps to protect the eyes from the sun. The sun
produces a type of energy called UV radiation which can be damaging
to the eyes if they are exposed to it for a prolonged period. UV
radiation is thought to be the major cause behind the development of
pterygium.
### How Can Oscar Wylee Assist With Your Pterygium Eye Problems?
Visit an Oscar Wylee store near you, and our dedicated optometrists can assist with eye problems such as
pterygium by providing eye tests and treatment if needed. Our Oscar Wylee optometrists are equipped with the latest
optometry technology to conduct eye tests that can help with
diagnosing pterygium. An Oscar Wylee optometrist will also assist
with any pterygium eye problems by providing advice on how to manage
a pterygium and help with treatment.
### What is the Difference Between Pinguecula and Pterygium?
The main differences between pinguecula and pterygium are in their appearance and their composition. A [pinguecula](https://www.oscarwylee.com.au/glasses/eye/pinguecula)
is a yellow, raised growth on the conjunctiva that usually contains
calcium, fat or protein, according to the American Academy of
Ophthalmology. A pterygium is a triangular raised growth, usually
with blood vessels, white or fleshy in colour. A pinguecula is
usually contained to the conjunctiva, whereas a pterygium may grow
over the conjunctiva to obstruct the cornea. Both pterygium and
pinguecula are thought to be caused by exposure to UV rays and
environmental factors such as wind, sand and dust from hot and dry
climates. A pterygium can start as a pinguecula. In considering the
question, pinguecula vs pterygium, it is clear that whilst these
growths have similar causes, their appearance, composition and
progression are what separates the two.
Read Pterygium (Surfer's Eye): Causes, Symptoms, and Treatments in
other Oscar Wylee regions and their languages.
Australia
[Australia](https://www.oscarwylee.com.au/glasses/eye/pterygium-definition)
New Zealand

[Canada](https://oscarwylee.ca/glasses/eye/pterygium-definition)
Canadian French

All major health funds are accepted in-store at Oscar Wylee
Come in and see the team for an eye test or a new pair of frames,
and your health fund may help cover the cost.
[Health Funds](https://www.oscarwylee.com.au/health-funds.html)
Have your next eye test at Oscar Wylee
We offer bulk billed eye tests, so there are no out-of-pocket
expenses for eligible Medicare cardholders.
[Book an eye test](https://www.oscarwylee.com.au/booking)