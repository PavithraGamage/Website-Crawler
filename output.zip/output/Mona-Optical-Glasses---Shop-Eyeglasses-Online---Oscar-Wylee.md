# Source: https://www.oscarwylee.com.au/mona-optical.html

# Mona
1
## Frame Design of Mona Glasses
The frame design of Oscar Wylee’s Mona glasses is characterised by
its cat-eye shape, high nose bridge fit and an acetate and stainless steel
frame. Mona glasses are a women’s, stylish frame that will work for
any occasion, whether the wearer wants to liven up their everyday style or
complement a fun outfit for a day out.
$169    
In stock
Only %1 left
2 pairs from $199
Discount auto-applied at checkout
3 pairs from $249
Discount auto-applied at checkout
Qty
Add to cart
Book an eye test
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
excluding prescription lenses
## About Mona Frames
The ultimate cat eye frame. Instant boost to take your everyday look to the next level. Purr-fection!
| Frame fit | Measurements |
| --- | --- |
| MEDIUM | 50 - 19 - 145 |
These measurements mean lens width, bridge, and temple length in millimetres (mm). They can be found on the inside of the temple arm. If you already have a pair that you like, you can compare it to these measurements.
### Made from Metal and Acetate
Oscar Wylee’s Mona frame is a women’s cat-eye glasses frame that is perfect for medium faces and those with heart or square face shapes. The Mona frame is a stylish, widely wearable frame that blends well with your outfits or makes the perfect statement. The main specs of Oscar Wylee’s Mona glasses frame including dimensions, shape, materials, lenses, nose fit and hinges are listed below.
| Mona Frame Features | Mona Frame Description | Dimensions | Shape | Materials | Lenses | Nose Fit | Hinges |
| --- | --- | --- | --- | --- | --- | --- | --- |
| The dimensions of the Mona frame are measured in millimetres (mm) and are 50 - 19 - 145, meaning the lens width is 50 mm, the bridge is 19 mm and the temple length is 145 mm. |
| The Mona frame is a cat-eye shape, well suited to medium faces. |
| Mona glasses are made from a mixture of acetate and metal. |
| The lenses that can be used in the Mona frame are optical lenses, which include single vision and multifocal lenses and non-prescription lenses, which are plain and can have a filter like a blue light filter applied. |
| The Mona frame does not include nose adjustable silicone nose pads. |
| The hinges in Mona glasses are normal hinges, also known as standard or barrel hinges. |
Show All
### What Inspired the Frame Design of Oscar Wylee’s Mona Glasses?
The Oscar Wylee Mona frame design was inspired by the contemporary trend of cat-eye shaped glasses for women. Cat-eye shaped glasses are characterised by their pointed upper corners and round square bodies. The design of cat-eye shaped glasses was originally born out of the need for more variety in women’s glasses during the 1930s, which is when American artist, Altina Schinasi designed the Harlequin frame now known as cat-eye shaped glasses. Oscar Wylee’s range of [women's cat eye glasses](https://www.oscarwylee.com.au/glasses/silhouette/cat-eye-glasses.html)can be shopped online.
## What to Know About Oscar Wylee’s Mona Glasses?
There are many aspects of the Oscar Wylee Mona frames that customers should know about, so they can decide whether this is the right frame for them. The Mona frame is a woman's cat-eye frame. Oscar Wylee’s Mona frame is suitable for many face shapes but particularly compatible with square and heart face shapes. The Mona frame’s simple trendy but essential design means that they are fashionable all year round. Mona glasses feature the standard [parts of glasses](https://www.oscarwylee.com.au/glasses/eye/part-of-glasses)such as a rim, temples, lenses, normal hinge and a high nose bridge fit. [Cat eye frames](https://www.oscarwylee.com.au/glasses/cat-eye-frame)as prescription glasses for women are a great eyewear choice for a fun yet stylish look.
### What are the Types of Temple Tips or Earpieces Included with Oscar Wylee’s Mona Glasses?
The type of temple tips or earpieces included in Oscar Wylee’s Mona Glasses are made from acetate and the temples are made from stainless steel.
### What Type of Nose Bridge do Oscar Wylee’s Mona Glasses Have?
The type of nose bridge included in Oscar Wylee’s Mona frame are high nose bridge fit.
### What Type of Nose Pads are Included with Oscar Wylee’s Mona Glasses?
Oscar Wylee’s Mona glasses do not include adjustable silicone nose pads.
### What Type of Lenses do Oscar Wylee’s Mona Glasses Have?
The type of lenses that typically come with the Oscar Wylee Mona [glasses](https://www.oscarwylee.com.au/glasses.html) frame are optical lenses.Optical lenses are glasses lenses that have a prescription within the lens to help correct vision issues such as myopia, hyperopia and astigmatism. Mona glasses can also come with non-prescription lenses, with add-ons such as a blue light filter. Mona frames are also available as sunglasses with polarised lenses.
### What Material is Used for the Rim of Oscar Wylee’s Mona Glasses?
The material used for the rim of Oscar Wylee’s Mona glasses frames is acetate and stainless steel. The rim refers to the part of a glasses frame that holds the lenses.
### What Type of Hinges are Included with Oscar Wylee’s Mona Glasses?
The type of hinges included with Oscar Wylee’s Mona frames are normal hinges, also known as standard or barrel hinges. These hinges have many interlocking loops that are stabilised with a small screw.
## What Face Types are Most Suitable for Oscar Wylee’s Mona Glasses?
The face types that are most suitable for Oscar Wylee’s Mona frame are square and heart face shapes. When considering [glasses for mens and womens face shapes](https://www.oscarwylee.com.au/glasses/face-shapes), cat eye glasses are usually considered to be more rounder frames. The Mona frame is a cat-eye shape, meaning that it complements the structure of square and heart faces particularly well. The Mona frames help to balance the features of a [square face shape](https://www.oscarwylee.com.au/glasses/face-shapes/square) or a heart face shape, bringing the eyes and brows forward in a flattering way. Although there are many glasses for face shapes that may be considered more aesthetically suitable, it is important that people also choose the frames that make them feel most comfortable and represent their personal style.
## What Size Options are Available for Oscar Wylee’s Mona Glasses?
The size options available for Oscar Wylee’s Mona frame are a medium-frame fit across all colours.
## What Materials are Used to Create Oscar Wylee’s Mona Glasses?
The materials used to create the Oscar Wylee Mona frame are acetate and metal. The rim is made from both acetate and stainless steel, the nose bridge and temples are made from stainless steel and the temple tips are made from acetate. Acetate, also known as cellulose acetate, is a bioplastic, made from cotton fibres or wood pulp.
## What’s Included
## OW Case &amp; Cloth
Protective Case and Lens Cloth
Our high-quality glasses case and lens cloth are included with every purchase of an Oscar Wylee frame. The stylish, magnetic case is made from a hard shell. This sturdy and durable material keeps your glasses protected and safe, wherever you go. Ensure your lenses are clean and scratch-free with our OW microfibre cloth, specifically designed to ensure you have comfortable vision through your lenses.
Oscar Wylee offers:
* Free Shipping for Australian Orders
* 1 Year Warranty on frames and lenses
* Scratch resistance lens coating on all prescriptions
* UV-proof coating on all prescriptions
Health fund rebate: Once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. Learn more about [health funds](https://www.oscarwylee.com.au/health-funds.html).
## Make and Materials
The frames then go through cleaning and strict quality control, and many pairs of crafting hands to be hand-assembled and polished. After your frames have gone through the production process, they are individually examined and packed before making their way to you!Our frames go through numerous stages of production and are hand-polished to ensure a glorious lustre. Featuring a mix of high-quality acetate and polished metal, these mixed materials frames are sure to enhance your eyewear collection.
## Warranty Information
### Warranty Information
### Warranty Information
Oscar Wylee provides a 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects. 
We will repair or replace faulty or defective frames or lenses free of charge for warranty claims made within 1 year of the delivery.
We also offer repairs or replacement for problems experienced with vision during everyday use for claims made within 30 days of delivery. If the same product has been discontinued or is no longer available, then we may offer an exchange for a similar product or a refund.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Find a Store Location](https://www.oscarwylee.com.au/locations/full-store-list.html)