# Source: https://www.oscarwylee.com.au/glasses/eye/coloboma

# Coloboma: Definition, Causes and Treatment
Published on August 13th, 2026
Coloboma is a congenital eye condition where a piece of tissue is missing from inside or around the eye. Types of coloboma include iris coloboma, retinal coloboma, optic nerve coloboma, lens coloboma, and eyelid coloboma. Coloboma is caused when the embryonic fissure doesn't close properly during early prenatal development. There is no cure for coloboma, but the condition can be managed with prescription glasses, contact lenses, patching for children, and sometimes surgery.
It is important to note that Oscar Wylee offers optometry services only; this article is for educational purposes only and is not a substitute for professional medical advice, diagnosis, or treatment.
Prioritise Your Eye Health
Our team can help you stay up to date with regular eye tests to keep your eyes healthy!
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Definition](#definition) [Types](#types) [Causes](#causes) [Diagnosis](#diagnosis) [Treatment](#treatment)
## What is Coloboma?
Coloboma is a rare congenital eye condition where a part of the eye's tissue is missing, such as from the [iris](https://www.oscarwylee.com.au/glasses/eye/anatomy/iris), [retina](https://www.oscarwylee.com.au/glasses/eye/anatomy/retina), [choroid](https://www.oscarwylee.com.au/glasses/eye/choroid), or [optic nerve](https://www.oscarwylee.com.au/glasses/eye/anatomy/optic-nerve). Coloboma occurs during prenatal development, when the fetal fissure fails to close properly. The most common type of coloboma is iris coloboma, which creates a distinct keyhole-shaped pupil.
### How does Coloboma Affect the Structure of the Eye?
Coloboma usually affects the lower part of the eye and can alter structures like the iris, retina, choroid, or optic nerve, according to UNSW Embryology.
#### Is Coloboma Considered a Rare Eye Condition?
Yes, coloboma is considered a rare eye condition, according to Kiddies Eye Care, Victoria. Coloboma occurs in a small percentage of births and is classified as a congenital condition.
## What are the Different Types of Coloboma?
The main different types of coloboma are iris coloboma, chorioretinal coloboma, optic nerve coloboma, lens coloboma, eyelid coloboma, and macular coloboma, according to the School of Special Educational Needs: Sensory (Government of Western Australia). These types of coloboma are explained below.
* Iris Coloboma: Iris coloboma is a defect in the coloured part of the eye that creates a distinct keyhole-shaped pupil.
* Chorioretinal Coloboma: Chorioretinal coloboma is missing tissue in the retina or choroid layer at the back of the eye. This can affect peripheral and central vision.
* Optic Nerve Coloboma: Optic nerve coloboma is a defect in the optic nerve, which can reduce visual acuity.
* Lens Coloboma: Lens coloboma refers to a small part of the lens missing.
* Eyelid Coloboma: Eyelid coloboma refers to a missing part of the upper or lower eyelid.
* Macular Coloboma: Macular coloboma is a defect where the macula does not develop properly.
### How Do Iris Coloboma and Optic Nerve Coloboma Differ?
Iris coloboma and optic nerve coloboma differ mostly due to their location in the eye and how they affect sight. Iris coloboma affects the iris (coloured part of the eye) and changes pupil shape; however, vision is often retained. Optic nerve coloboma affects the nerve connection to the brain and can lead to severe [visual impairment or blindness](https://www.oscarwylee.com.au/glasses/eye/visual-impairment).
Find Your Nearest OW Store!
We've got knowledgeable teams who are passionate about delivering high-quality care.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
#### Can a Person Have More Than One Type of Coloboma?
Yes, a person can have more than one type of coloboma. A coloboma occurs when the embryonic fissure does not close properly during pregnancy. This 'gap' can lead to multiple defects in the eye, such as an iris coloboma combined with a chorioretinal or optic nerve coloboma. The medical term for multiple colobomas is 'colobomata.'
## What Causes Coloboma?
The cause of coloboma is incomplete development of the eye during pregnancy, according to Sydney Ophthalmic Specialists. Specifically, coloboma occurs when the fetal optic fissure fails to close properly, which causes a gap in the eye structures. Other factors such as genetic changes, chromosomal syndromes, and environmental factors like exposure to harmful elements during pregnancy are risk factors in a child developing coloboma.
### How Common Is Coloboma as a Congenital Eye Condition?
Coloboma is a rare congenital eye condition, affecting about 1 in 10,000 births. Although it is generally rare, coloboma is one of the primary congenital diseases that cause vision impairment and blindness in children, according to a 2016 study by Save Sight Institute and the University of Sydney.
#### Can Genetic Mutations Be Responsible for Coloboma?
Yes, genetic mutations can be responsible for coloboma, according to Sydney Ophthalmic Specialists. Changes in specific genes that control eye development during pregnancy can affect optic fissure closure and lead to a gap in the eye, according to Sydney Ophthalmic Specialists.
## How does Coloboma Affect Vision?
Coloboma affects vision broadly, from no change in vision to severe vision loss, according to the Prevent Blindness Organisation. Coloboma affects an individual's vision depending on where it is in the eye. Iris colobomas usually do not affect vision, but can cause light sensitivity (photophobia) due to the keyhole-shaped pupil. Retinal and choroidal colobomas can cause blind spots in the field of vision due to gaps at the back of the eye. Optic nerve colobomas cause optic nerve gaps that can cause blurry vision.
### What Types of Vision Problems Do People With Coloboma Experience?
The types of vision problems people with coloboma may experience include reduced vision, severe vision loss, light sensitivity, nystagmus, strabismus, amblyopia, and refractive errors. The extent of vision problems associated with coloboma depends on the location and size of the missing tissue gap. These vision problems that people with coloboma may experience are explained below.
* Reduced Vision: Reduced vision refers to decreased clarity, visual field loss, blind spots, and general visual impairment that can occur due to coloboma.
* Severe Vision Loss: Severe vision loss may occur in some individuals with coloboma, particularly when the tissue gap affects the retina, macula, or optic nerve.
* Light sensitivity: [Light sensitivity](https://www.oscarwylee.com.au/glasses/eye/light-sensitivity) is a vision problem that can occur in iris coloboma, due to the keyhole-shaped pupil affecting how the eye blocks and adjusts to bright light.
* Nystagmus: [Nystagmus](https://www.oscarwylee.com.au/glasses/eye/nystagmus) refers to involuntary eye movements, which can be caused by colobomas that affect the optic nerve and macula.
* Strabismus: [Strabismus](https://www.oscarwylee.com.au/glasses/eye/crossed-definition) refers to misalignment of the eyes, which can happen in patients with colobomas as the brain struggles with coordination.
* Amblyopia: [Amblyopia](https://www.oscarwylee.com.au/glasses/eye/lazy-definition), or a lazy eye, can be caused by coloboma, due to early visual development being affected, according to Inner South Eye Surgeons, Victoria.
* Refractive Errors: Refractive errors such as myopia, hyperopia, and astigmatism are associated with and more common in people with coloboma, according to Sydney Ophthalmic Specialists.
#### Can Coloboma of the Optic Nerve Lead to Severe Visual Impairment?
Yes, coloboma of the optic nerve can lead to severe visual impairment. Coloboma of the optic nerve can cause reduced visual acuity, blind spots, or complete blindness. The visual impact of an optic nerve coloboma is heavily dependent on its size and location in the eye.
## How is Coloboma Diagnosed?
Coloboma is diagnosed through a comprehensive physical examination and dilated eye examination by an [ophthalmologist](https://www.oscarwylee.com.au/eye-care/optometrist/ophthalmologist.html), according to Sydney Ophthalmic Specialists. When babies are born, visible forms of coloboma, such as iris coloboma, can be detected during routine checks. Deeper structural issues within the eye need special tools and imaging tests, according to Sydney Ophthalmic Specialists. Genetic testing in the form of blood tests can also be performed to test for gene changes related to coloboma.
### What Eye Tests Can Detect Coloboma Early?
The eye tests that can detect coloboma early are mainly a comprehensive dilated eye exam and an ophthalmoscopy, but ocular ultrasounds and visual field testing are also commonly performed. While an optometrist can detect signs or screen for coloboma during routine tests, formal diagnosis and complex ocular management are referred to an ophthalmologist. These [eye tests](https://www.oscarwylee.com.au/glasses/eye/test-glossary) that can detect coloboma early are explained below.
* Comprehensive Dilated Eye Exam: A comprehensive [dilated eye exam](https://www.oscarwylee.com.au/glasses/eye/dilated-pupil-exam) entails eye drops used to dilate the pupil so that an ophthalmoscope can be used to view the eye's inner structures.
* Ophthalmoscopy: An ophthalmoscopy or fundus exam is a quick, painless procedure during a routine eye test where an optometrist uses a magnifying lens to view the back of the eye, according to Glaucoma Australia.
* Ocular Ultrasound: An ocular ultrasound is a quick, painless test that uses high-frequency sound waves to map an image of the inside of the eye, according to Eastern Suburbs Eye Specialists, Sydney.
* Visual Field Testing: [Visual field testing](https://www.oscarwylee.com.au/visual_field.html) measures central and peripheral (side) vision, according to Glaucoma Australia.
#### Are Retinal Imaging and Ophthalmoscopy Recommended for a Coloboma?
Yes, [retinal imaging](https://www.oscarwylee.com.au/retinal-scan.html) and ophthalmoscopy are recommended in diagnosing and mapping colobomas. They are especially useful if a coloboma affects the back of the eye, such as the retina or optic nerve. Retinal imaging and ophthalmoscopy are usually part of a comprehensive eye test.
## What Treatments Are Available for Coloboma?
There is no cure for coloboma, and treatment focuses on managing the condition, according to Sydney Ophthalmic Specialists. Available management options include prescription glasses, contact lenses, patching for children, and sometimes surgery.
* Prescription Glasses: Prescription glasses correct nearsightedness, farsightedness, or astigmatism, which are often linked to coloboma.
* Contact Lenses: Contact lenses can correct refractive errors, and in some cases, tinted [contact lenses](https://www.oscarwylee.com.au/glasses/eye/contact-lenses) can help give the iris a normal, rounded shape. In some cases, specialised lenses can reduce light sensitivity.
* Patching For Children: Patching for children may be used on the stronger eye to prevent or treat amblyopia (lazy eye), according to the Prevent Blindness Organisation.
* Surgery: Surgery can repair eyelid coloboma or reconstruct the iris to improve appearance and reduce glare.
### Can Coloboma Be Treated with Glasses or Surgery?
Yes and no; coloboma cannot be cured or completely repaired, but it can be managed with glasses and surgery. [Glasses](https://www.oscarwylee.com.au/glasses.html) help by correcting refractive errors that are often associated with coloboma, such as myopia, hyperopia, and astigmatism. Tinted lenses and sunglasses can help ease light sensitivity, which is a common symptom caused by iris coloboma. Children can also benefit from wearing patches that can prevent amblyopia (lazy eye) development. Surgery can help reshape an iris and reconstruct structural gaps in the eye, as well as fix related issues such as cataracts, strabismus, or [retinal detachment](https://www.oscarwylee.com.au/glasses/retinal-detachment).
#### Is Surgical Repair Effective for Iris Coloboma?
Yes, surgical repair is generally effective for iris coloboma. Surgery for iris coloboma helps to reconstruct the shape of the pupil, which can ease light sensitivity symptoms and improve appearance.
## What Other Health Issues Can Coloboma Cause?
Coloboma is associated with health issues such as CHARGE syndrome, cat eye syndrome, Patau syndrome, and renal coloboma syndrome when it is part of a genetic syndrome rather than an isolated eye trait. These health issues related to coloboma are explained below.
* CHARGE Syndrome: CHARGE syndrome involves heart defects, nasal blockage, and delayed growth. CHARGE stands for coloboma, heart defects, atresia of the nasal choanae, retardation of growth, genital anomalies, and ear abnormalities.
* Cat Eye Syndrome: Cat eye syndrome can cause heart defects and kidney problems.
* Patau Syndrome: Patau syndrome causes severe intellectual disability and heart defects.
* Renal Coloboma Syndrome: Renal coloboma syndrome involves kidney problems and optic nerve gaps.
### How is Coloboma Linked to Syndromes or Systemic Conditions?
Coloboma is linked to syndromes and systemic conditions when a genetic mutation alters the embryonic fissure during pregnancy, which affects multiple organs, according to Macquarie University, Sydney. Key syndromes linked to coloboma include CHARGE syndrome, cat eye syndrome, and renal coloboma syndrome.
#### Is Coloboma Associated With Heart or Kidney Abnormalities in Rare Cases?
Yes, coloboma is associated with heart and kidney abnormalities as part of genetic syndromes such as CHARGE syndrome and renal coloboma syndrome.
Experience High Quality Eyecare Services From Our Team
Book an appointment online with an Oscar Wylee optometrist today.
[Book an eye test](https://www.oscarwylee.com.au/booking)
Major Health Funds Accepted In-store
For the purchase of frames and lenses, use your private health fund to limit how much you pay from your own pocket.
[Health Funds](https://www.oscarwylee.com.au/health-funds.html)