# Source: https://www.oscarwylee.com.au/bobby-sunglasses.html

# Bobby
1
## Frame Design of Bobby Sunglasses
The frame design of Oscar Wylee’s Bobby sunglasses is characterised by their classic shape, low nose bridge, and acetate frame. Bobby is a wearable unisex glasses frame that will complement any outfit or event, day to night.
$169    
In stock
Only %1 left
2 pairs from $199
Discount auto-applied at checkout
3 pairs from $249
Discount auto-applied at checkout
* 2 &amp; 3 Pair pricing applies to non-prescription sunglasses only. Prescription sunglasses incur additional charges.    
[Non-Prescription](https://www.oscarwylee.com.au/bobby-sunglasses.html#)
Qty
Prescription
Book an eye test
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
excluding prescription lenses
## About Bobby Sunglasses
Bobby presents a subtle luxe profile with its purposeful curves and junctions, alongside a sculpted hardware hinge imbuing mid century charm.
| Frame fit | Measurements |
| --- | --- |
| MEDIUM | 52 - 19 - 145 |
These measurements mean lens width, bridge, and temple length in millimetres (mm). They can be found on the inside of the temple arm. If you already have a pair that you like, you can compare it to these measurements.
### Made from Acetate
Oscar Wylee’s Bobby frame is a unisex classic sunglasses frame that is perfect for those with square, oval, and pear face shapes. The Bobby frame is a trendy and versatile frame that can be worn every day. The main specs of Oscar Wylee’s Bobby glasses frame, including dimensions, shape, materials, lenses, nose fit, and hinges are listed below.
Filter category 3 - General purpose sunglasses. High protection against sunglare. Good UV Protection. Not suitable for driving in twilight, at night or under dull conditions.This frame comes with tinted lenses. An additional $30 will be added to your order total for prescription orders.
| Bobby Frame Features | Bobby Frame Description | Dimensions | Shape | Materials | Lenses | Nose Fit | Hinges |
| --- | --- | --- | --- | --- | --- | --- | --- |
| The dimensions of the Bobby frame are measured in millimetres (mm) and are 52 - 19 - 145, meaning the lens width is 52 mm, the bridge is 19 mm, and the temple length is 145 mm. |
| Bobby is a classic shape, well-suited to medium faces. |
| Bobby is made from acetate. |
| The lenses that can be used in the Bobby frame are sunglass lenses, which provide UV protection. Prescription lenses are also available to purchase for the Bobby sunglass frame, both online and in-store. |
| The nose fit for Bobby is a low nose bridge fit. |
| The hinges in Bobby are normal hinges, also known as standard or barrel hinges. |
Show All
### What Inspired the Frame Design of Oscar Wylee's Bobby Glasses?
The Oscar Wylee Bobby frame design was inspired by current fashion trends, as classic shapes are often in fashion. A classic glasses shape is timeless; it remains popular throughout the decades while other trends come and go.
## What to Know About Oscar Wylee's Bobby Sunglasses?
There are many aspects of the Oscar Wylee Bobby frames that customers should know to decide whether this is the right frame for them. The Bobby frame is a unisex, classic sunglasses frame. Oscar Wylee’s Bobby frame is suitable for many face shapes, but particularly compatible with square, oval, and pear face shapes. The Bobby frame’s simple design makes them fashionable all year round. Bobby features the standard [parts of glasses](https://www.oscarwylee.com.au/glasses/eye/part-of-glasses), such as a rim, temples, lenses, hinges, and a low nose bridge.
### What are the Types of Temple Tips or Earpieces Included with Oscar Wylee's Bobby Glasses?
The type of temple tips or earpieces included in Oscar Wylee’s Bobby Glasses are made from acetate.
### What Type of Nose Bridge do Oscar Wylee's Bobby Glasses Have?
The type of nose bridge included in Oscar Wylee’s Bobby frame is a low nose bridge.
### What Type of Nose Pads are Included with Oscar Wylee's Bobby Glasses?
Oscar Wylee’s Bobby frame does not include adjustable silicone nose pads.
### What Type of Lenses do Oscar Wylee's Bobby Sunglasses Have?
The lenses that can be used in the Bobby frame are sunglass lenses, which provide UV protection. UV protection lenses block harmful ultraviolet rays, safeguarding eyes from damage. The Bobby frame comes in Filter Category 3. These are general purpose sunglasses. low protection against sunglare. Good UV protection. They are not suitable for driving in twilight, at night, or under dull conditions. Prescription lenses are also available for the Bobby frame, both online and in-store.
### What Material is Used for the Rim of Oscar Wylee's Bobby Glasses?
The material used for the rim of Oscar Wylee’s Bobby glasses frames is acetate. The rim refers to the part of a glasses frame that holds the lenses.
### What Type of Hinges are Included with Oscar Wylee's Bobby Glasses?
The type of hinges included with Oscar Wylee’s Bobby frames are normal hinges, also known as standard or barrel hinges. These provide strength and smooth movement connecting the frame's arms and lenses.
## What Face Types are Most Suitable for Oscar Wylee's Bobby Glasses?
The face types most suitable for Oscar Wylee’s Bobby frame are square, oval, and pear face types. The Bobby frame is a classic shape, meaning it complements the structure of square, oval, and pear faces particularly well. The classic Bobby frames help balance the features of a [square face shape](https://www.oscarwylee.com.au/glasses/face-shapes/square), an [oval face shape](https://www.oscarwylee.com.au/glasses/face-shapes/oval), and a [pear face shape](https://www.oscarwylee.com.au/glasses/face-shapes/pear), bringing the eyes and brows forward in a flattering way. Although there are many different [glasses for face shapes](https://www.oscarwylee.com.au/glasses/face-shapes) that may be considered more aesthetically suitable, it is important that people also choose frames that make them feel most comfortable and represent their personal style.
## What Size Options are Available for Oscar Wylee's Bobby Glasses?
The size options available for Oscar Wylee’s Bobby frame are a medium-frame fit across all colours.
## What Materials are Used to Create Oscar Wylee's Bobby Glasses?
The material used to create the Oscar Wylee Bobby frame is acetate. Acetate, also known as cellulose acetate, is a bioplastic made from cotton fibres or wood pulp. At Oscar Wylee, acetate glasses are made by adding a dye to cellulose acetate, which is rolled into a sheet. The shape of the glasses is then cut from this sheet.
## What’s Included
## OW Case &amp; Cloth
Protective Case and Lens Cloth
Our high-quality glasses case and lens cloth are included with every purchase of an Oscar Wylee frame. The stylish, magnetic case is made from a hard shell. This sturdy and durable material keeps your glasses protected and safe, wherever you go. Ensure your lenses are clean and scratch-free with our OW microfibre cloth, specifically designed to ensure you have comfortable vision through your lenses.
Oscar Wylee offers:
* Free Shipping on all orders
* 1 Year Warranty on frames and lenses
* Scratch resistance lens coating on all prescriptions
* UV-proof coating on all prescriptions
Health fund rebate: Once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. Learn more about [health funds](https://www.oscarwylee.com.au/health-funds.html).
## Make and Materials
Also known as cellulose acetate, these frames are traditionally hand-crafted by skilled craftsmen, with each frame passing through numerous stages of production and are hand-polished to ensure a glorious lustre. The frames then go through cleaning and strict quality control, and many pairs of crafting hands to be hand-assembled and polished. After your frames have gone through the production process, they are individually examined and&nbsp;packed before making their way to you!
## Warranty Information
### Warranty Information
### Warranty Information
Oscar Wylee provides a 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects. We will repair or replace faulty or defective frames or lenses free of charge for warranty claims made within 1 year of the delivery. We also offer repairs or replacement for problems experienced with vision during everyday use for claims made within 30 days of delivery. If the same product has been discontinued or is no longer available, then we may offer an exchange for a similar product or a refund.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Find a Store Location](https://www.oscarwylee.com.au/locations/full-store-list.html)