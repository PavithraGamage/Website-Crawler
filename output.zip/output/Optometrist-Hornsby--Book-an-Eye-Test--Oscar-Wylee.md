# Source: https://www.oscarwylee.com.au/locations/optometrist-hornsby.html

# Optometrist Hornsby
Level 1, Shop 1069236 Pacific HighwayHornsby NSW 2077
* Near Commonwealth Bank
Opening hours
Monday9:00am - 5:30pm
Tuesday9:00am - 5:30pm
Wednesday9:00am - 5:30pm
Thursday9:00am - 7:00pm
Friday9:00am - 5:30pm
Saturday9:00am - 5:00pm
Sunday10:00am - 5:00pm
*Store hours reflect local standard trading hours and exclude public holidays
[Visit our Hornsby Google Business page for directions, reviews, and updates.](https://g.page/r/CcZI-xZi1wO4EBM/)
Book Appointment
[Call us: (02) 8924 3944](tel:(02) 8924 3944)
[Leave a Review!](https://g.page/r/CcZI-xZi1wO4EBM/review)
Our Reviews
Sheryl Sorio
6 days ago
Qiyun Even Chen assisted me a couple of weeks ago. She was professional and friendly, and explained ...everything clearly. I really appreciate her help and kindness.
As well as Doctor Howie who checked my eyes. He was patient and professional. He took the time to explain everything clearly and me feel comfortable throughout the consultation.
Thanks 1001 Optometrist Hornsby.
See more
Lynette Kirsten
1 month ago
Good services by Tiff!
Barsha Poudel
1 month ago
Excellent service. Even though I didn’t buy my glasses from them, they still went above and beyond t...o help me without charging me anything The staff were very friendly and welcoming. Thank you so much for your outstanding service????
See more
barsha Poudel
1 month ago
renee hawke
1 month ago
Staff were really helpful and lovely
abhilasha ignatius
2 months ago
Gong Peiling
2 months ago
Excellent service! I came in to have my glasses repaired, and the lady who assisted me was incredibl...y kind and helpful. She fixed my glasses quickly and was very professionalq throughout. Her friendly attitude made the whole experience pleasant. Thank you so much for your help — highly recommended!
See more
Miriam Overdijk
3 months ago
Always a great experience! Tiffany is super helpful and friendly.
Jessie Slater
3 months ago
Fantastic and friendly service! Accidentally bent my glasses and Tiffany was able to fix them on the... spot perfectly - thank you!!
See more
Miok Chung
3 months ago
Eric Xu
3 months ago
Rose Burkill
4 months ago
Always such friendly service and I love my new frames. Would highly recommend. I was just looking to... get new lenses in my same frames but the lovely staff I dealt with did multiple calculations to ensure I got the best deal with 2 brand new frames for 25% of the cost!
See more
susan tremellen
4 months ago
Excellent thorough and informative. Optometrist explained every step of the process and waited for m...y input. Highly recommend them.
See more
Madie Garrett
4 months ago
Great experience, Tiffany was so helpful and made the whole process super smooth and seamless. Would... definitely recommend this location!
See more
Jo Chapman
5 months ago
Alice was a highly professional and thorough as an optometrist. I felt like I was in very capable ha...nds. The sales assistant (unfortunately, I can't recall his name) was also very warm and friendly, providing great service. I've had Oscar Wylee glasses for the past few years, and I have found them good quality and great value for money. The range is large with lots of different options.
See more
Glenn Jeffries
5 months ago
very good experience
Diana Mayeli Chavez Meneses
5 months ago
Excellent place! I had the opportunity to get my eye exam and also two pairs of glasses: one pair of... sunglasses and another pair I use every day. Plus, one day my everyday glasses fell off, and I went to the store in Westfield, Hornsby. The girl who helped me was super friendly and fixed them for me at no extra cost. 100% recommended.
See more
Sandy Yap
5 months ago
Alejandro Gonzalez
5 months ago
Great service. The thing about these people is that, if something goes wrong, they fix it, and their... end goal is that the customer is satisfied with a product that works for them. Tiffany is happy, always keen on helping, and somehow has a solution to the needs. Madana is also great and keen to help.
See more
zhenzhen Yang
5 months ago
My glass frame is broken, staff gave me a free one and I was able to see clearly again
Dominic Enthoven
6 months ago
Allan Hunter
7 months ago
Very professional and efficient. Would definitely recommend.
jerri magan
7 months ago
Fast and efficient examination. The staff were polite and friendly. Great range to choose from and c...lear and easy to understand pricing.
See more
Sheryl McGrath
8 months ago
Patrick Kim
9 months ago
I have experienced very kind, smart, competitive and reliable services.
R Reddy
9 months ago
Great work. Thank you for excellent reception by Mandana and explaining everything by optometrist Re...uel.
See more
Leah Tipping
9 months ago
iOS Apps
9 months ago
Excellent service and high-quality eyewear. Highly recommended.
suriya dhilip
9 months ago
Mondana is an amazing CSR she was so nice will surely come back to fix my glasses here she needs a r...aise
See more
Stuart
9 months ago
I'm very happy with my experience at Oscar Wylee. The service was friendly and professional, my glas...ses turned up within a week and a half and cost less than I expected.
See more
Stuart Blundell
9 months ago
I'm very happy with my experience at Oscar Wylee. The service was friendly and professional, my glas...ses turned up within a week and a half and cost less than I expected.
See more
Hadis Khani
9 months ago
Mandana was so helpful and patient! She really took the time to help me find the right choices and m...ade my experience with Oscar Val very pleasant. I wish everyone at work could be as respectful and friendly with customers as she is. Highly recommend!
See more
Amir Sadrossadat
10 months ago
Amanda at Oscar-Wylee Hornsby is wonderful. Made great recommendations on the frames  too. Thanks
Alexander Gold
10 months ago
Amazing Service
Thank you
NR
10 months ago
I've purchased four prescription glasses from Oscar Wylee Hornsby in the last year, and they have be...en very easy and professional to deal with each time. I'm very happy with the pricing and styles available, and will likely return to this store in future
See more
Margaret Booth
10 months ago
Gwen Norris
10 months ago
Fabulous service fixed my glasses for free
Jean-Pierre Berbee
11 months ago
The eye doctor, really took his time to analyse and give me feedback. Good service, recommend.
Rhonda RAMSEY
11 months ago
Oscar Wylee Hornsby are the best optometrists I've ever been to. You never have to wait. Reuel reall...y knows what he is doing.
See more
S A
11 months ago
Adam S
11 months ago
A screw came lose on a pair of glasses that I'd purchased. I spoke to Tiffany and she quickly and ch...eerfully repaired them for me. Thanks very much Tiffany for the excellent service.
See more
Amandas Barr
11 months ago
Dr Jack Phu was extremely professional, patient and knowledgeable. Highly recommend.
Mike Greive
11 months ago
Oscar Wylee Optometrist Hornsby are an excellent place to go to for all of your optometry needs. The...y are very friendly, helpful and knowledgeable. I have to add that Tiffany is the best receptionist that you can find. She is always so lovely and does whatever she can to help you. I just bought glasses from this shop, and at a very reasonable price. Thanks for your help team!
See more
Santy
11 months ago
Very detailed eye test by the Optometrist. He paid personal attention and spent quality time in acce...ssing the condition of my eyes. Very friendly staff at the shop too!
See more
Saskia Eisermann
1 year ago
Amazing service! Tiffany is fabulous, she is always extremely helpful and so lovely. The other staff... are also so great. Definitely recommend and appreciate the effort they always go to.
See more
Group Account
1 year ago
It was the best review ever! Dr examinated my eyes very carefully, found every problem that I get an...d gave me detailed recommendations.
See more
Keesleem
1 year ago
Bought my new glasses from here and I love them! Optometrist was very thorough and professional. Rec...eptionist was kind.
See more
Michelle Lee
1 year ago
Debra Barnard
1 year ago
After going to a bigger 'chain' for optometry I wanted a more one on one personal experience which I... got! polite, professional and did not feel pressured or rushed.
Thank you- can't wait to get my new glasses.
See more
Angelique Goldsworthy
1 year ago
A thorough and professional eye test with the optometrist, who picked up several issues quickly. The... lovely Tiffany helped me choose frames. All in all a very positive experience ✨️ Highly recommended ????
See more
## Find an Optometrist in Hornsby With Oscar Wylee
Come visit us at our Oscar Wylee Hornsby store which neighbours the surrounding suburbs of Berowra and Mount Colah. Oscar Wylee Hornsby offers our experience in optometry and bulk billed eye tests to ensure your vision is healthy. Our optometrists can also identify signs of eye diseases. In-store, you can find a range of both prescription and non-prescription glasses with modern frames to fit every style. We also offer prescription sunglasses which our staff in Oscar Wylee Hornsby will gladly help you with. 
In Oscar Wylee Hornsby, there is a range of parks for biking and hiking, and within walking distance is a beautiful flower garden, Lisgar Gardens, for you to explore while in the area. There are many activities to become involved in while shopping at Westfield Hornsby. On Thursdays from 9 am to 3 pm near the fountain at Westfield, there is a Grower’s Market selling fresh produce and food. There is also ticketless 3 hours free parking, and we are close to the train station and bus services. At Oscar Wylee we have some of the best optometry services, so schedule your next eye appointment with us.        
Meet Our Team
* Optometrist
B.Optom
* Store Manager
Certificate IV in Optical Dispensing
Our Services
* Bulk Billed Eye Examinations
* Professional Frame Styling
* Frame Adjustments and Repairs
Show All
## Find an Optometrist in Hornsby, Sydney for an Eye Health Test
You can find an optometrist in Hornsby, Sydney who can provide a wide selection of eyewear, eye test services and general eye health services. If you don’t want to worry about any out-of-pocket expenses, come get an eye health test in Hornsby at a bulk-billed price courtesy of Australia's Medicare System if you have a valid card. You can receive assistance from our trained optical dispenser, whether it is for eyewear concerns or if you need help with selecting frames. We encourage you to stay on top of your regular eye tests to maintain vision and eye health. If our optometrist identifies any concerns of a more complex eye disease, they can refer you to an eye doctor for further assessment and diagnosis. At Oscar Wylee Hornsby, we also offer a great selection of frames for prescription sunglasses, or non-prescription sunglasses, whatever it is, we’ve got a pair for everyone.
During our comprehensive eye test, our highly-trained team will take you through a few preliminary tests to ensure optimal function and movement of your eyes. The optometrist will then take a closer look inside your eyes. You may find a different price range for the different optometrists in Hornsby, which could be due to possible factors that include the tests required, equipment and the current health of your vision.
## How to Find an Optometrist in Hornsby, Sydney?
To find an optometrist in Hornsby, Sydney you can take certain steps that can help make it easier for you such as searching online, assessing the store’s opening hours and finding the directions to your chosen location. The steps on how to find an optometrist in Hornsby are listed below.
1. Search online using the phrase, Hornsby optometrist near me. This can also be done here on the website via our locations page.
2. Click on the Oscar Wylee link, which will take you directly to our Hornsby optometrist store page.
3. See the store’s opening hours and where the store is located specifically.
4. Use the Hornsby Google Business page link located under store hours to see the directions on how to get to the store.
You can also find an optometrist in Hornsby by searching the keywords optometrist near me. If you have locations enabled on your smartphone and you’re in the Hornsby area, our Hornsby store page should appear easily for you to click on.
### Is it Hard to Get an Eye Appointment in Hornsby, Sydney?
No, it is not hard to get an eye appointment in Hornsby. You can easily book an appointment to see an Oscar Wylee optometrist in Hornsby right here on this page. At Oscar Wylee we have highly qualified optometrists available for bulk billed eye appointments, which can be booked online or in-store.
#### How to Compare Optometrists in Hornsby to Each Other?
To compare optometrists in Hornsby, you can use factors such as eye tests offered, health fund coverage, lens types and add-ons and eyewear offered. To take care of your vision and eye health, it is important to receive an eye test at least once every two years. There are different types of tests that can be performed in an eye test and not all optometrists may offer the same tests. Health funds can be used to help cover some of the cost of your frames and lenses. To find out if your health fund is accepted at Hornsby optometrist in Sydney, visit their website. In the case of Oscar Wylee, we accept all major health funds and provide on-the-spot claims in-store. There are many different lens options available for prescription glasses such as single vision, multifocal and high index lenses. Most optometrists in Hornsby will offer these lenses although it is good to make sure. There are also lens add-ons available to enhance your glasses such as anti-reflective and blue light filters. Finally, if you are looking to purchase a pair of glasses after your eye test, you can compare the different styles and colours you are interested in from Hornsby optometrists in Canberra. Oscar Wylee offers a wide range of frames with vintage and modern inspirations in bold colours and subtle designs.
#### How to Find an Eyeglasses Shop in Hornsby, Sydney?
To find a glasses store in Hornsby, you can try to follow these simple steps including searching online, selecting a convenient location and looking at their health insurance policies. The steps on how to find a glasses store in Hornsby are listed below.
1. Search online using the phrase, glasses store Hornsby. This will provide you with various options for glasses stores in the whole Hornsby area.
2. Select a glasses store that is most convenient for you to travel to.
3. Click the link to find out more information such as opening hours, exact location and directions to the glasses store in Hornsby.
4. Read their health insurance policies to ensure you know what health benefits you have access to.
Our Oscar Wylee glasses store in Hornsby, Sydney offers primary eye care services such as comprehensive eye tests as well as other services performed by an optometrist and offers prescription and non-prescription eyewear.
##### Is it Possible to Purchase Prescribed Sunglasses in Hornsby, Sydney Without Seeing an Optometrist?
Yes and no, it is possible to [purchase prescribed sunglasses](https://www.oscarwylee.com.au/sunglasses.html) in Hornsby, Sydney without seeing an optometrist if you already have a prescription that has not expired. If your prescription is expired, you can book an eye test to receive an updated or new prescription which will require you to see an optometrist. This will ensure your prescription sunglasses are appropriate for your visual needs.
## Where is the Oscar Wylee Hornsby Optometrist in Sydney Located?
The Oscar Wylee Hornsby optometrist in Sydney is located at the Westfield Shopping Centre which can be found at 1069/236 Pacific Highway. The Oscar Wylee Hornsby store can be your first choice for primary optometry services as well as for fashionable frames.
### What is the Phone Number of Oscar Wylee Hornsby Optometrist Store?
The Oscar Wylee Hornsby optometrist store phone number is [(02) 8924 3944](tel:(02) 8924 3944). You can contact the Oscar Wylee Hornsby store between the hours of 9 am and 5:30 pm on Monday, Tuesday, Wednesday and Friday, between 9 am and 9 pm on Thursdays, between 9 am and 5 pm on Saturdays and between 9 am and 5 pm on Sundays.
### What are the Reviews for Oscar Wylee Hornsby Optometrist in Sydney?
The many reviews for Oscar Wylee Hornsby optometrist in Sydney, made by our many customers can be found here on the website and online when you search for Oscar Wylee Hornsby optometrist. The reviews for Oscar Wylee Hornsby optometrist are listed below.
* Dania K:  Very professional and thorough examination. Helpful feedback afterwards also. Thank you!
* Kyle Wilson:  Great professional and friendly staff.
* April Waldron:  I went to Oscar Wylee to check if I had a foreign body. Jack, the young man who examined me was respectful, a very clear and concise communicator even took a photo to show me the scratch on my eyeball. He gave me a script for an antibiotic eye cream to reduce infection risk. I have a follow up booked for 3 pm Tuesday. Very impressed.
* Qiang Chen:  The staff is friendly.
#### What Treatments or Eye Care Processes are Done in the Oscar Wylee Hornsby Optometrist Location?
The treatments or eye care processes done in the Oscar Wylee Hornsby optometrist Sydney location include a tonometry test, a slit lamp exam and a refraction test. Additional tests that may also be performed can include a dilated fundus exam. The treatments or eye-care processes that are done in the Oscar Wylee Hornsby optometrist Sydney location are listed below.
* A Tonometry Test: An optometrist or optical dispenser will conduct a tonometry test which involves the use of a machine that will release small puffs of air into your eyes. This will assist with measuring pressure in the eye.
* Slit Lamp Test: A slit lamp test can be used to evaluate your eye health, by examining your cornea and iris which are the anterior and posterior of the eye.
* Refraction Test: During a refraction test, an optometrist will have you view an image through different lenses and ask you to confirm which helps you see the image clearer.
* Dilated Fundus Exam: A dilated fundus exam can help an optometrist assess your health in more detail by getting a clear view of the retina. This test is typically carried out for patients with diabetes and those who may be at risk of developing retinal damage.
## How Many Optometrists Exist in Hornsby, Sydney?
There are many optometrists that exist in Hornsby, Sydney that are available to provide important health services to monitor and maintain ocular health, including Oscar Wylee. The reason for the current number of optometrists in Hornsby may depend on possible reasons such as the geographical size of the area, the possible demand for eye health services and the residential population.
### What are the Other Closest Optometrist Locations to Hornsby, Sydney in Australia?
The other closest Oscar Wylee optometrist locations to Hornsby, Sydney in Australia are St Ives, Macquarie Centre, Castle Towers and Rouse Hill. The other closest optometrist locations to Hornsby are listed below.
* St Ives:  St Ives is close to Hornsby with around 8 km in between stores and can be found at the St Ives shopping village, which is located at Mona Vale Rd. The [Oscar Wylee St Ives](https://www.oscarwylee.com.au/locations/optometrist-st-ives.html) store is a go-to for St Ives locals with great services to help you care for your vision and browse a wide variety of vintage-inspired frames.
* Macquarie Centre:  Macquarie Centre is close to Hornsby with about 13-19 km in between stores and can provide customers with eye health tests that can identify signs of eye diseases, as well as treatment for minor eye problems. The [Oscar Wylee Macquarie Centre](https://www.oscarwylee.com.au/locations/optometrist-macquarie-centre.html)store can be found at Herring Road &amp; Waterloo Road.
* Castle Towers:  Castle Towers is close to Hornsby with around 13 km in between stores and can be found at the Castle Hill Shopping Centre on level 2, near David Jones. The [Oscar Wylee Castle Towers](https://www.oscarwylee.com.au/locations/optometrist-castle-towers.html) store can offer professional assistance and care for all things optometry. Here you can come get your eyes tested at a bulk billed price as well as ask our team about any general eye health information.
* Rouse Hill:  Rouse Hill is close to Hornsby with a 25-29 km distance between stores and is located at the Rouse Hill Town Centre near JB HI-FI. You can find the [Oscar Wylee Rouse Hill](https://www.oscarwylee.com.au/locations/optometrist-rouse-hill.html) store along White Hart Drive and receive essential eye care services that can help you take care of your eyes and vision.
### Check Your Eyesight in Oscar Wylee Hornsby
Have your eye health tests done with us at Oscar Wylee Hornsby where you can also have your vision health checked and prescription updated. Come in-store where our highly trained staff are carrying out bulk billed eye tests for individuals who have valid Medicare cards. Visit our team at Oscar Wylee Hornsby to shop for a new pair of glasses.
### Health Fund Claims in Hornsby
Have your health fund claim processed at our Oscar Wylee Hornsby store. Oscar Wylee can help with any questions you may have about what you can receive with your health fund. We’ll assist you with any difficult parts of health insurance. Here at Oscar Wylee Hornsby, we’ll endeavour to help you get what you need at an affordable price.
### Fashion-Forward Styles at Affordable Prices
At Oscar Wylee, we care about you walking out of our store with prescription glasses and prescription sunglasses that best suit you. Look no further than our Oscar Wylee Hornsby store for vintage and on-trend styles at an affordable price. We offer prescription lenses that can be customised to meet your visual needs. If you want to try multifocal lenses, photochromic lenses or blue light lenses, our optometrist and retail team can help with any information about our different lens options.
Book Appointment
[Call us: (02) 8924 3944](tel:(02) 8924 3944)
[Leave a Review!](https://g.page/r/CcZI-xZi1wO4EBM/review)