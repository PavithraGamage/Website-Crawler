# Source: https://www.oscarwylee.com.au/glasses/eye/why-does-my-eye-hurt-when-i-blink

# Why Does My Eye Hurt When I Blink?
Updated on March 19th, 2025
Published on October 8th, 2024
Australia
[Australia](https://www.oscarwylee.com.au/glasses/eye/why-does-my-eye-hurt-when-i-blink)
[Canada](https://oscarwylee.ca/glasses/eye/why-does-my-eye-hurt-when-i-blink)
[Canadian French](https://oscarwylee.ca/fr/glasses/eye/why-does-my-eye-hurt-when-i-blink)
Your eyes can hurt when you blink from causes such as
conjunctivitis, blepharitis, cluster headaches, astigmatism, iritis,
keratitis, dry eye, optic neuritis, uveitis, glaucoma, corneal, ulcers,
stye, burns, eye injuries and debris or foreign bodies. While these are possible causes for why your eyes may hurt when blinking,
some of these causes may alleviate on their own but others can be an
indication of an underlying cause. Eye pain when blinking may not be serious
but can be unpleasant, therefore, it is important to see an optometrist or
your GP. It is generally advised to see an optometrist when you notice any
changes to your vision to identify symptoms early. To learn more about what
may be causing pain in the eyes when blinking, continue reading below.
See one of our optometrists for your next eye test
We have dedicated teams and optometrists at all our store locations.
[Book an Eye Test](https://www.oscarwylee.com.au/booking)
[Causes](#Causes) [Home Remedies](#Home-Remedies)
[Seeking Medical Treatment](#Seeking-Medical-Treatment)
[Eye Test](#Eye-Test)
## What are the Common Causes of Eye Pain when Blinking?
The common causes of eye pain when blinking are
conjunctivitis, blepharitis, cluster headaches, astigmatism, iritis,
keratitis, dry eye, optic neuritis, uveitis, glaucoma, corneal ulcers,
stye, burns, eye injuries and debris or foreign bodies. The common causes of eye pain when blinking are listed below.
* Conjunctivitis:  Conjunctivitis or
commonly referred to as pink eye is an eye condition that is generally
caused by either a viral or bacterial infection and causes
inflammation in the conjunctiva.
* Blepharitis: Blepharitis refers to the
inflammation of the eyelids and is characterised by red or swollen
eyelids that may also be itchy, sore or burn.
* Cluster Headaches:  Cluster headaches
are considered to be a rare type of headache that is very painful and
occurs in groups or clusters around the head.
* Astigmatism:  Astigmatism is a
refractive error that can be brought on by a misshapen lens or cornea
that disrupts the eyes’ visual abilities.
* Iritis:  Iritis refers to the
inflammation of the iris, the coloured part of the eye that surrounds
the pupil.
* Keratitis:  Keratitis also known as a
corneal infection or corneal inflammation is characterised as
inflammation in the cornea caused by bacterial or viral infections or
from an injury to the eye.
* Dry Eye:  Dry eyes are defined as
having an insufficient amount of moisture in your eyes due to a lack
of tears or when the tears that are produced evaporate too quickly.
* Optic Neuritis: Optic neuritis is an
eye condition that leads to eye pain and vision loss as a result of
inflammation in the optic nerve.
* Uveitis: Uveitis is defined as eye
inflammation that occurs due to an infection or an autoimmune disease.
.
* Glaucoma:  Glaucoma refers to a group
of eye conditions or diseases in which damage to the optic nerve
causes vision loss.
* Corneal Ulcers:  Corneal ulcers are
open wounds that form on the surface of the eye.
* Stye: A stye is a painful red bump
that usually forms on the edge of the eyelid and can be caused by an
oil gland blockage.
* Burns:  Burns can refer to the
reaction caused by chemical splashes in the eye or irritants entering
the eye.
* Eye Injuries:  Eye injuries can
include burns, bruises, scratches or punctures to the eye and around
the eye.
* Debris or Foreign Bodies: Debris or
foreign bodies in the eye can cause scratches to the cornea resulting
in eye pain.
### 1. Conjunctivitis
Conjunctivitis, also referred to as pink eye,
is an eye infection caused by a virus, bacteria or from allergies
and in some cases, leads to eye pain when blinking.
[Conjunctivitis](https://www.oscarwylee.com.au/glasses/eye/conjunctivitis)
causes the white portion of the eye (sclera) to become red accompanied
by itching, excessive tears and eye discharge. Conjunctivitis may
require antibiotic or antihistamine eye drops, however, this will
depend on the severity of your condition. It is important to see an
optometrist so you can get a professional diagnosis and they can
identify any underlying conditions early.
### 2. Blepharitis
Blepharitis is
a condition that describes the inflammation of the eyelid, which
can most commonly develop from having excessive bacteria on the
eyelids.
[Blepharitis](https://www.oscarwylee.com.au/glasses/eye/eyelids-inflammation)
can be a cause for eye pain when blinking as part of the inflammation.
Blepharitis can stem eye conditions such as from seborrheic
dermatitis, ocular rosacea, dry eyes, eye allergies, blocked oil
glands in eyelids, lice or mites in eyelashes and eye infections.
### 3. Cluster Headaches
Cluster headaches are
characterised by a severe pain felt on one side of the head and
occurs in groups or clusters. Cluster headaches can contribute to eye pain when blinking and can
last between an average of 1 and 3 hours either every other day or
several times a day according to John Hopkins Medicine. The exact
cause of cluster headaches are not yet known, however, potential
triggers can include alcohol consumption or smoking, high altitudes or
bright lights. Other possible triggers may include exercise, heat from
the weather or from a bath, certain foods and drug use. Treating
cluster headaches will depend on your healthcare provider’s findings
from your consultation.
### 4. Astigmatism
Astigmatism is
an eye condition that causes blurry vision due to the abnormal
shape of either the cornea or lens.
[Astigmatism](https://www.oscarwylee.com.au/glasses/eye/astigmatism)
can lead to eye pain as a result of eye strain when trying to see
clearly. Astigmatism can develop from causes such as keratoconus, eye
injuries, old age, eye surgery, genetics or family history and eye
diseases. Astigmatism can be managed with prescription glasses and may
present symptoms such as squinting to see clearly, seeing glares or
halos around lights at night, headaches and eye fatigue.
### 5. Iritis
Iritis is the
inflammation of the iris, the coloured portion of the eye, and is a
possible factor for eye pain when blinking due to inflammation
symptoms.
[Iritis](https://www.oscarwylee.com.au/glasses/eye/iritis)
can develop from causes such as health problems, Behcet’s disease,
Juvenile Idiopathic Arthritis, Sarcoidosis, eye injuries and use of
certain drugs. Other symptoms of iritis can include blurry vision,
light sensitivity, redness around the iris, a pupil that is abnormally
shaped, tearing, vision loss and a headache. It is advisable to see an
optometrist so they can prescribe suitable treatment according to your
condition. However, treating iritis may include solutions such as
steroids, dilating eye drops, antibiotics, and antiviral medications.
### 6. Keratitis
Keratitis is characterised as
inflammation or infection of the cornea, which can cause eye pain
when blinking as one of the early signs of this condition.
[Keratitis](https://www.oscarwylee.com.au/glasses/eye/keratitis)
is caused by an infection or injuries to the eye and can lead to
ciliary congestion, corneal swelling and the entrance of inflammatory
cells. Infectious keratitis can develop from fungal keratitis,
bacterial keratitis, parasitic keratitis and viral keratitis. Causes
of non-infectious keratitis can include injuries to the eye,
poorly-fitted contact lenses, and foreign body in the eye.
### 7. Dry Eye
Dry eye can ensue
when the eye does not produce a sufficient amount of tears or when
the tears that are produced are poor quality.
[Dry eyes](https://www.oscarwylee.com.au/glasses/eye/dry-eyes)
can result in eye pain as the eyes require enough moisture from tears
for optimal function and comfort and therefore can lead to eye pain
when blinking. The lacrimal (tear) glands produce tears consisting of
a combination of water, mucus and oil. Each of these substances help
to create moisture in the eye, while the mucus layer assists in evenly
distributing the tears over the eye. The oil that is created, prevents
the water layer from evaporating too quickly. Poor-quality tears can
result from factors like meibomian gland dysfunction, blinking less,
wearing contact lenses and from certain medications. Meibomian gland
dysfunction is when the meibomian (oil) glands in the eyelid do not
produce enough or quality oil according to the National Institutes of
Health.
### 8. Optic Neuritis
Optic neuritis is
a condition that can arise when the optic nerve becomes inflamed
and swollen
resulting in eye pain, vision impairment and vision loss in certain
cases.
[Optic neuritis](https://www.oscarwylee.com.au/glasses/eye/optic-neuritis)
can arise from potential causes such as autoimmune and inflammatory
conditions and infections. The three main types of this condition
include typical, atypical and paediatric and involve symptoms such as
eye pain, vision loss and flashing lights. Treating optic neuritis may
require intravenous (IV) drugs (steroids) or treating the initial
causes. Treating optic neuritis with IV steroids may be helpful in
alleviating the inflammation, and preventing further damage to the
optic nerve. Addressing the initial causes or contributing factors may
include treating bacterial infections with antibiotics.
### 9. Uveitis
Uveitis is defined as
inflammation of the eye and triggers symptoms such as pain,
redness, severe sensitivity to light, floaters and blurry vision.
[Uveitis](https://www.oscarwylee.com.au/glasses/eye/uveitis)
has different types which are categorised according to the different
region of the eye that is affected. The different parts of the eye
that are affected are the choroid, retina, ciliary body and vitreous.
Uveitis can arise from infections, and autoimmune diseases. Treatment
for uveitis can involve eye drops, tablets, injections and treating
the underlying conditions.
### 10. Glaucoma
Glaucoma is defined as
a group of eye conditions that cause vision loss due to optic nerve
damage, which can lead to eye pain. The exact cause of glaucoma is not known, however, risk factors can
include having a history of glaucoma in the family, older age, certain
medical conditions, steroid use and eye injuries.
[Glaucoma](https://www.oscarwylee.com.au/glasses/eye/glaucoma)
can lead to symptoms such as blurry vision, tunnel vision, redness,
seeing halos around lights, headaches, low vision and vomiting and
nausea. Treating glaucoma may require eye surgery, eye drops or laser
treatment, however, this will depend on the severity of your
condition.
### 11. Corneal Ulcers
Corneal ulcers are characterised as
open wounds that form on the surface of the eye caused by
infections. Corneal ulcers can be painful and are often a consequence of viral
infections, bacterial infections, fungal infections and parasitic
infections according to the American Academy of Ophthalmology. Risk
factors for corneal ulcers can include contact lens wear, history of
shingles or cold sores, use of steroid eye drops, eyelid disorders and
corneal burns or injuries. Treating corneal ulcers may involve an
optometrist or ophthalmologist prescribing antibacterial or antiviral
eye drops and/or pain medication. It is important to see an
optometrist if you experience symptoms or notice any changes to your
symptoms.
### 12. Stye
A stye can cause eye pain when blinking and
refers to a swollen bump that usually forms on the edge of the
eyelid and can ensue from bacterial infections.
[Styes](https://www.oscarwylee.com.au/glasses/eye/anatomy/stye)
can form when the oil glands in your eyelids (meibomian glands) become
blocked according to the Cleveland Clinic. The symptoms of a stye can
include a swollen eyelid, wet or dry eye discharge, sensitivity to
light, pain, itching, excessive tears and foreign body sensation.
Styes usually alleviate on their own after 1-2 weeks. However,
applying a warm compress or gently cleaning the affected area may help
relieve unpleasant symptoms. It is always advisable to see an
optometrist to get professional advice on what is the most suitable
treatment according to your condition.
### 13. Burns
Burns in the eye can come from chemical splashes in the eye.
[Burns](https://www.oscarwylee.com.au/glasses/eye/what-to-do-burn-eye)
can cause eye pain and can arise from soaps, solvents, cosmetics,
disinfectants and household cleaning solutions getting into the eye.
The pain from burns in the eye can range from mild to to severe
depending on the type of substance involved. It is recommended to see
an optometrist to make sure no further damage is caused and so the
optometrist can determine the right form of treatment.
### 14. Eye Injuries
Eye injuries can include
trauma to the eye, scratches, punctures or foreign objects in the
eye which can lead to varying degrees of eye pain.
[Eye injuries](https://www.oscarwylee.com.au/glasses/eye/injuries)
should be examined by an optometrist in a timely manner to prevent
further damage to the eye. The most common symptoms of eye injuries
are continuous pain in the eye, difficulty seeing, a cut eyelid and
one eye not moving as well as the other eye. Other common symptoms
include one eye protruding out of the eye socket farther than the
other eye, an abnormal pupil shape or size, blood in the clear portion
of the eye and debris stuck in the eye according to the American
Academy of Ophthalmology.
### 15. Debris or Foreign Bodies
Debris or foreign bodies in the eye
can cause eye pain due to the high sensitivity of the eye.
Debris or foreign bodies in the eye can be quite painful with there
being more pain receptors in the eye than in other parts of the body.
According to the National Library of Medicine, the cornea is one of
the most sensitive regions to pain in the entire body. Debris or
foreign bodies in the eye can include dust specks, wood chips, sand,
dirt, grass clippings and glass pieces. Some of these examples can be
quite dangerous to the eye and may not be removed with tears in the
eye.
## What are the Home Remedies for Eye Pain when Blinking?
The home remedies for eye pain when blinking include
using a humidifier, a warm compress, eye drops, adjusting the
lighting when using screens and taking frequent breaks from screens. It is important to note that you should always seek advice from a
medical professional first so you can receive treatment that is most
suited for your condition. While these remedies can provide some help
for eye pain, they may not be able to cure eye pain. The home remedies
for eye pain when blinking are listed below.
* Using a humidifier: Using a humidifier
may help with certain symptoms of eye conditions that lead to eye pain
when blinking. A humidifier is a device that helps to increase
moisture in the air when indoors.
* A warm compress:  A warm compress is a
way to increase blood flow to certain areas of the body that may be
painful.
* Eye drops: Eye drops that can restore
moisture to the eyes or alleviate itching and infections may assist
with eye pain when blinking.
* Adjusting the lighting when using screens:
Adjusting the lighting when using screens is often recommended to
reduce the risk of straining your eyes and prevent eye pain.
* Taking frequent breaks from screens:
Taking frequent breaks from screens allows your eyes to rest more and
prevent eye pain that can stem from eye strain or dry eyes.
## 1.Using a Humidifier
Use a humidifier
for dry eyes as they can typically be the cause for eye pain when
blinking. Using a humidifier can help with adding more moisture to the air when
indoors, which may help keep the eyes moist for optimal health and
comfort.
## 2.Warm Compress
A warm compress
may help with painful eyes when blinking as it increases the blood
flow to the applied area. A warm compress is typically made by soaking a face towel with hot
water and wringing out the excess. You then lay the towel onto your eyes
for up to 20 minutes at a time according to Healthline.
## 3.Eye Drops
Eye drops such as
antihistamine eye drops, antibacterial eye drops or lubricating eye
drops may aid with eliminating eye pain when blinking. Using antihistamine eye drops can target the histamine produced in
the body as a result of contact with certain allergens. This can help
stop the pain that often follows when the eyes are inflamed.
Antibacterial eye drops can be used to treat bacterial infections in the
eye which is a likely cause for eye pain. Lubricating eye drops can help
increase moisture in the eyes when they are dry, which is what can
commonly trigger eye pain or discomfort.
## 4.Adjusting the Lighting When Using Screens
Adjusting the lighting when using screens
can provide some relief for eye pain when blinking as overly bright
screens may be overstimulating for the eyes. Adjusting the brightness in your devices or computer according to the
current lighting conditions you are in may prevent eye strain, which is
what commonly leads to eye pain.
## 5.Taking Frequent Breaks From Screens
Taking frequent breaks from screens
can help minimise eye strain symptoms such as eye pain. Eye
strain is a term that encompasses a range of eye and vision symptoms
caused by prolonged use of digital devices such as computers, tablets
and phones. Therefore, it may be helpful to schedule 20 minute breaks
every hour or so to ensure more rest for your eyes.
Visit our team in-store or browse through our wide range of
fashion-forward frames
Here at Oscar Wylee, we prioritise creating an excellent in-store
experience.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
## When does a Person Need to Seek Medical Treatment?
A person needs to seek medical treatment for eye pain when blinking when
experiencing accompanying symptoms such as
pain when moving your eyes, swelling of the eyelids, light
sensitivity, tenderness around your sinuses, unbearable pain, impaired
vision, nausea and vomiting and seeing halos around lights. However, it is advisable to seek medical treatment or care from an
[optometrist](https://www.oscarwylee.com.au/eye-care/optometrist)
when experiencing eye pain regardless of other present symptoms to get a
full diagnosis. Seeing an optometrist also means receiving an eye test,
which can help narrow down the initial cause.
### Will Going to a Checkup Eye Test Determine the Cause of Eye Pain When
Blinking?
Yes, going to a checkup eye test
can help know the cause of the pain when blinking. Eye tests are
essential in diagnosing eye conditions
and detecting their early signs. Therefore, it is always advisable to
get your eyes tested when you notice any changes to your vision and
how your eyes feel. It is important to maintain regular
[check up eye tests](https://www.oscarwylee.com.au/glasses/eye/check-up)
at least once every 2 years unless advised otherwise by an
optometrist.
Read Why Does My Eye Hurt When I Blink? in other Oscar Wylee regions
and their languages.
Australia
[Australia](https://www.oscarwylee.com.au/glasses/eye/why-does-my-eye-hurt-when-i-blink)
[Canada](https://oscarwylee.ca/glasses/eye/why-does-my-eye-hurt-when-i-blink)
[Canadian French](https://oscarwylee.ca/fr/glasses/eye/why-does-my-eye-hurt-when-i-blink)
Ready to book an eye test?
At Oscar Wylee we offer bulk billed eye tests for all eligible
medicare card holders.
[Book an eye test](https://www.oscarwylee.com.au/booking)
Major Health Funds Accepted In-store
For the purchase of frames and lenses, use your private health fund
insurance to limit how much you pay from your own pocket.
[Explore Health funds](https://www.oscarwylee.com.au/health-funds.html)