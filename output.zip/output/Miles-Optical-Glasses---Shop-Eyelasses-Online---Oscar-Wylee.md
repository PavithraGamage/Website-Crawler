# Source: https://www.oscarwylee.com.au/miles-optical.html

# Miles
1
## Frame Design of Miles Glasses
The frame design of Oscar Wylee’s Miles glasses is characterised by a rectangle shape, a low nose bridge fit and an Ultem frame making it ultra light. Miles glasses are a women’s, stylish frame that will work for any occasion, whether the wearer wants to liven up their work style or complement a fun outfit for a night out.
$169    
In stock
Only %1 left
2 pairs from $199
Discount auto-applied at checkout
3 pairs from $249
Discount auto-applied at checkout
Qty
Add to cart
Book an eye test
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
excluding prescription lenses
## About Miles Frames
Ultra light, ultra cool, ultra casual. Makes for the perfect everyday plus one for its versatile style that would work perfectly anytime, anywhere.
| Frame fit | Measurements |
| --- | --- |
| Medium | 52 - 17 - 140 |
These measurements mean lens width, bridge, and temple length in millimetres (mm). They can be found on the inside of the temple arm. If you already have a pair that you like, you can compare it to these measurements.
### Made from Ultem
Oscar Wylee’s Miles frame is an ultra-light, women’s, rectangle glasses frame that is perfect for medium faces and those with round and oval face shapes. The Miles frame is a stylish, widely wearable frame that can be worn every day. The main specs of Oscar Wylee’s Miles glasses frame including dimensions, shape, materials, lenses, nose fit and hinges are listed below.
| Miles Frame Features | Miles Frame Description | Dimensions | Shape | Materials | Lenses | Nose Fit | Hinges |
| --- | --- | --- | --- | --- | --- | --- | --- |
| The dimensions of the Miles frame are measured in millimetres (mm) and are 52 - 17 - 140, meaning the lens width is 52 mm, the bridge is 17 mm and the temple length is 140 mm. |
| The Miles frame is a rectangular frame shape, well suited to round and oval faces. |
| Miles glasses are made from a material called Ultem. |
| The lenses that can be used in the Miles frame are optical lenses, which include single vision and multifocal lenses and non-prescription lenses, which are plain and can have a filter like a blue light filter applied. |
| The nose fit of Miles frames is a low nose bridge fit. |
| The hinges in Miles glasses are normal hinges, also known as standard or barrel hinges. |
Show All
### What Inspired the Frame Design of Oscar Wylee’s Miles Glasses?
The Oscar Wylee Miles frame design was inspired by current fashion trends as rectangle glasses shapes are often in fashion.
## What to Know About Oscar Wylee’s Miles Glasses?
There are many aspects of the Oscar Wylee Miles frames that customers should know about, so they can decide whether this is the right frame for them. The Miles frame is a women’s rectangle-shaped frame made from ultra light materials. Oscar Wylee’s Miles frame is suitable for many face shapes but is particularly compatible with round and oval face shapes. The Miles frame’s simple design means that they are fashionable all year round. Miles glasses feature the standard [parts of glasses](https://www.oscarwylee.com.au/glasses/eye/part-of-glasses) such as a rim, temples, lenses, normal hinge and a low nose bridge.
### What are the Types of Temple Tips or Earpieces Included with Oscar Wylee’s Miles Glasses?
The type of temple tips or earpieces included in Oscar Wylee’s Miles Glasses are made from rubber.
### What Type of Nose Bridge do Oscar Wylee’s Miles Glasses Have?
The type of nose bridge included in Oscar Wylee’s Miles frame is a low nose bridge.
### What Type of Nose Pads are Included with Oscar Wylee’s Miles Glasses?
Oscar Wylee’s Miles frame does not include adjustable silicone nose pads.
### What Type of Lenses do Oscar Wylee’s Miles Glasses Have?
The type of lenses that typically come with the Oscar Wylee Miles [glasses frame](https://www.oscarwylee.com.au/glasses.html) are optical lenses. Optical lenses are glasses lenses that have a prescription within the lens to help correct vision issues such as myopia, hyperopia and astigmatism. Miles glasses can also come with non-prescription lenses, with add-ons such as a blue light filter. Miles frames are currently unavailable as sunglasses online, however, customers can customise in-store and add on tint or polarisation.
### What Material is Used for the Rim of Oscar Wylee’s Miles Glasses?
The material used for the rim of Oscar Wylee’s Miles glasses frames is ultem. Ultem is a lightweight and durable type of thermoplastic material.
### What Type of Hinges are Included with Oscar Wylee’s Miles Glasses?
The type of hinges included with Oscar Wylee’s Miles frames are normal hinges, also known as standard or barrel hinges. These hinges have many interlocking loops that are stabilised with a small screw.
## What Face Types are Most Suitable for Oscar Wylee’s Miles Glasses?
The face types most suitable for Oscar Wylee’s Miles frame are round and oval face shapes. The Miles frame is a rectangle shape, meaning that it complements the structure of round and oval shapes particularly well. The rectangle Miles frames help to balance the features of a [round face shape](https://www.oscarwylee.com.au/glasses/face-shapes/round) and an [oval face shape](https://www.oscarwylee.com.au/glasses/face-shapes/oval), bringing the eyes and brows forward in a flattering way. Rectangle frames help to flatter round and oval face types creating a pleasing visual contrast between sharp angles and rounded features highlighting without overemphasising them. Although there are many [glasses for face shapes](https://www.oscarwylee.com.au/glasses/face-shapes) that may be considered more aesthetically suitable, it is important that people also choose the frames that make them feel most comfortable, and represent their personal style.
## What Size Options are Available for Oscar Wylee’s Miles Glasses?
The size options available for Oscar Wylee’s Miles frame are a medium-frame fit across all colours.
## What Materials are Used to Create Oscar Wylee’s Miles Glasses?
The primary material used to create the Oscar Wylee Miles frame is ultem. Ultem is a thermoplastic material that makes for a perfect lightweight and durable combination for eyewear.
## What’s Included
## OW Case &amp;a Cloth
Protective Case and Lens Cloth
Our high-quality glasses case and lens cloth are included with every purchase of an Oscar Wylee frame. The stylish, magnetic case is made from a hard shell. This sturdy and durable material keeps your glasses protected and safe, wherever you go. Ensure your lenses are clean and scratch-free with our OW microfibre cloth, specifically designed to ensure you have comfortable vision through your lenses.
Oscar Wylee offers:
* Free Shipping for Australian Orders
* 1 Year Warranty on frames and lenses
* Scratch resistance lens coating on all prescriptions
* UV-proof coating on all prescriptions
Health fund rebate: Once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. Learn more about [health funds](https://www.oscarwylee.com.au/health-funds.html).
## Make and Materials
The frames then go through cleaning and strict quality control, and many pairs of crafting hands to be hand-assembled and polished. After your frames have gone through the production process, they are individually examined and packed before making their way to you!We love our Ultem frames! They are super comfortable and very durable. Our Ultem frames are heat resistant, with high dielectric strength and flexible. The material is widely used in medical and chemical instruments. It is currently available in a range of colours for both matte and gloss finish.
## Warranty Information
### Warranty Information
### Warranty Information
Oscar Wylee provides a 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects. 
We will repair or replace faulty or defective frames or lenses free of charge for warranty claims made within 1 year of the delivery.
We also offer repairs or replacement for problems experienced with vision during everyday use for claims made within 30 days of delivery. If the same product has been discontinued or is no longer available, then we may offer an exchange for a similar product or a refund.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Find a Store Location](https://www.oscarwylee.com.au/locations/full-store-list.html)
Recommended
1. [](https://www.oscarwylee.com.au/allan-optical.html)
[Allan](https://www.oscarwylee.com.au/allan-optical.html)
Obsidian