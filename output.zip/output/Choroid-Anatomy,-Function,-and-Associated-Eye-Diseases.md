# Source: https://www.oscarwylee.com.au/glasses/eye/choroid

# Choroid: Anatomy, Function, and Associated Eye Diseases
Published on January 25, 2024
Updated on March 21st, 2025 
Australia
[Australia](https://www.oscarwylee.com.au/glasses/eye/choroid)
[Canada](https://oscarwylee.ca/glasses/eye/choroid)
[Canadian French](https://oscarwylee.ca/fr/glasses/eye/choroid)
The choroid is a layer of blood vessels found between the sclera and the
retina in the anatomy of the eye. The choroid supplies nutrients to the
inner parts of the eye, specifically the posterior layers of the retina.
Choroid function also includes regulating intraocular pressure and the
temperature of the retina. Eye diseases that affect the choroid include choroiditis, choroideremia and posterior uveitis.
The choroid consists of four layers which are Bruch’s membrane, the
choriocapillaris, Sattler’s layer and Haller’s layer. Keep reading to
learn more about the choroid’s anatomy, function and associated eye
diseases.
Have You Had Your Eyes Tested Recently?
Book an appointment with one of our optometrists today to stay on top of
your eye health.
[Book an eye test](https://www.oscarwylee.com.au/booking)
## What is the Choroid?
The choroid is a layer in the eye made up of almost entirely blood vessels.
It is located between the sclera and the retina and supplies the inner
parts of the eye with nutrients. The choroid also helps regulate the
retina’s temperature and intraocular pressure. The choroid is made up of
four layers which are Bruch’s membrane, the choriocapillaris, Sattler’s
layer and Haller’s layer. According to the American Academy of
Ophthalmology, the choroid is part of the uvea which is the middle layer
of the eye and also contains the iris and the ciliary body.
### What is the Medical Term for Choroid?
Choroid is the scientific term for this part of the eye’s anatomy. The
choroid can also be known as the choroidea or choroid coat.
### What Does the Choroid Look Like?
The choroid is
a layer of blood vessels located between the sclera and the retina
in the middle layer of the eye. Below is a diagram illustrating where
the choroid is in the eye’s anatomy.

#### Are Choroid and Iris the Same?
No the choroid and the iris are not the same, they are different parts
of the eye’s anatomy. The choroid is a layer of blood vessels that provides nutrients to
other parts of the eye. The [iris](https://www.oscarwylee.com.au/glasses/eye/anatomy/iris)
is the visible, coloured part of the eye located behind the cornea and
in front of the lens. The iris controls the size of the pupil and the
eye's general ability to let light in.
### Where is the Choroid Located in Eye Anatomy?
The choroid is located between the sclera, which is the whites of the eyes, and the
retina in the [eye’s anatomy](https://www.oscarwylee.com.au/glasses/eye/anatomy). According to All About Vision, the choroid is the middle layer of
tissue in the wall of the eye and is made up of blood vessels.
### What are the 4 Layers of the Choroid?
Four layers make up the structure of the choroid. The four layers of
the choroid are Bruch’s Membrane, the choriocapillaris, Scattler’s layer and Haller’s
layer.
These choroidal layers and their definitions are listed below.
* Bruch’s membrane: Bruch’s membrane is
the innermost layer of the choroid and contains the basement membrane of
the retinal pigment epithelium.
* Choriocapillaris:
The choriocapillaris layer is adjacent to Bruch’s membrane and
consists of branching choroidal vessels.
* Sattler’s layer: Sattler’s layer is one of two vascular layers
in the choroid, consisting of medium blood vessels.
* Haller’s layer: Haller’s layer is the external layer of the
choroid and is one of two vascular layers in its structure. Haller’s
layer consists of large vessels.
#### 1. Bruch’s Membrane
Bruch’s membrane is the innermost layer of the choroid and contains the basement membrane of
the RPE
(retinal pigment epithelium), according to the Retinal Consultants
Medical Group. Bruch’s membrane separates the choroid from the retina,
supplying nutrition and oxygen to the outer retina.
#### 2. Choriocapillaris
The choriocapillaris layer is adjacent to Bruch’s membrane and consists of branching choroidal vessels that form an extensive
capillary network.
The choriocapillaris filters waste from the outer retina and also
provides nourishment to the photoreceptors and the retinal
epithelium.
#### 3. Sattler’s Layer
Sattler’s layer is the internal layer of the choroid and is one of two vascular layers
in its structure.
Sattler’s layer consists of medium blood vessels and is referred to as
the inner choroid, according to an article published in ScienceDirect
titled, Anatomy and Regulation of the Optic Nerve Blood Flow.
#### 4. Haller’s Layer
Haller’s layer is the external layer of the choroid and is one of two vascular layers
in its structure.
Haller’s layer consists of large vessels, especially vortex veins,
according to an article titled, The Anatomy of the Choroid – A Review.
Are You in Need of New Glasses?
Come see our staff in-store for assistance with your vision and to
browse our range of fashionable glasses.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
## What is the Function of the Choroid?
The function of the choroid is to provide nutrients to the retina
according to the Retinal Consultants Medical Group. Another choroid
function is to regulate the temperature of the retina and also regulate
intraocular pressure.
### What Role Does the Choroid Play in Eyesight?
The choroid does not have a direct role in eyesight but it does provide nutrients
and temperature regulation to the retina. The retina plays a major role in eyesight. The retina converts the
light that enters the eye into signals that are then sent to the brain
via the optic nerve to create the images we see.
#### Is the Choroid Affected by Wearing Glasses?
No, the choroid is not affected by [wearing glasses](https://www.oscarwylee.com.au/glasses).
Glasses are used to correct a person’s vision which the choroid is not
directly involved in.
## What are the Eye Diseases that Affect the Choroid?
The eye diseases that affect the choroid include chorioretinitis, choroideremia and choroidal rupture.
These choroidal eye diseases and their definitions are listed below.
* Chorioretinitis: Chorioretinitis is a type
of posterior uveitis that causes inflammation of the choroid and retina
and can cause symptoms such as floaters, flashing lights and loss of
vision. Causes of chorioretinitis can be categorised as infectious and
non-infectious. Infectious causes include tuberculosis and syphilis and
non-infectious causes include eye injuries and rheumatoid arthritis.
* Choroideremia: Choroideremia is an eye condition that affects the choroid causing
progressive vision loss. Symptoms of choroideremia include night
blindness, tunnel vision and decreased visual acuity. This eye disease
most commonly affects men and is caused by a mutation in the CHM gene,
according to the American Academy of Ophthalmology.
* Choroidal rupture: A choroidal rupture is a break in the
choroid, according to the American Academy of Ophthalmology. A choroidal
rupture is caused by trauma to the eye as the force buckles the globe,
leading the choroid to stretch and break. This can occur from sports
injuries due to soccer, basketball, tennis and martial arts.

### How do Optometrists Diagnose Choroid diseases?
An optometrist can diagnose eye diseases that affect the choroid through an eye
test. An [optometrist](https://www.oscarwylee.com.au/eye-care/optometrist)
may also refer patients who have more advanced choroidal diseases to an
ophthalmologist for diagnosis and treatment. Ultrasonography is often
used to diagnose choroidal diseases such as choroidal melanoma,
according to an article published in ScienceDirect titled, Basic Science, Inherited Retinal Disease and Tumors.
#### Does Iritis Affect Choroid?
No, generally,
iritis affects the iris and surrounding structures at the front of the
eye and the choroid is located at the back of the eye. However, if the [iritis](https://www.oscarwylee.com.au/glasses/eye/iritis)
is severe enough this could lead to affecting the choroid. This is
known as posterior uveitis or chorioretinitis.
## How to Take Care of Your Choroid?
While there is nothing specific you can do to take care of your choroid,
there are actions you can take to benefit the overall health of your eye
and vision. This includes booking regular eye tests with an optometrist
so they can monitor your eye for any changes. This allows them to detect
eye diseases early which can be crucial in preventing vision loss. You
should also not smoke as it can negatively impact your eye health.
Finally, it is important to eat a balanced diet full of leafy greens,
omega-3 fats, nuts and seeds to help maintain your eye health.
### How Important is a Regular Eye Exam for Assessing the Health of the
Choroid?
Regular eye exams are extremely important for assessing the health of your choroid and your
overall eye health.
Regular eye tests allow your optometrist to monitor any changes in your
vision or eye that could indicate signs of an eye condition that could
be affecting your choroid or any other issues. We recommend everyone
have an eye test at least once every two years and if you are over the
age of 65, then a yearly review is advised.
### How Can Oscar Wylee Help You Take Care of Your Choroid and Your Eyes?
Oscar Wylee can help you take care of your choroid as our optometrists are available in-store to provide comprehensive eye
tests to assess your vision and eye health.
They will examine the structures of your eye to determine if there are
any signs of eye conditions.
Read Choroid: Anatomy, Function, and Associated Eye Diseases in other
Oscar Wylee regions and their languages.
Australia
[Australia](https://www.oscarwylee.com.au/glasses/eye/choroid)
[Canada](https://oscarwylee.ca/glasses/eye/choroid)
[Canadian French](https://oscarwylee.ca/fr/glasses/eye/choroid)
Keep up-to-date With Your Eye Health
Book your next optometry appointment online or with us in-store.
[Book an eye test](https://www.oscarwylee.com.au/booking)
We Accept Major Health Funds at Oscar Wylee
Visit us in-store and our team will happily assist you in using your
health fund to cover some of the cost of new frames.
[Health Funds](https://www.oscarwylee.com.au/health-funds.html)