# Source: https://www.oscarwylee.com.au/the-oscar-wylee-team

# The Oscar Wylee Team
Oscar Wylee is a fast-growing optometry and eyewear business comprised of hard-working team members who
provide outstanding services to our customers, whether that is in-store or behind the scenes.
Our team is constantly expanding and learning alongside the company, striving for excellence in everything
we do.
Due for an Eye Test?
Book yours today with a skilled Oscar Wylee optometrist for excellent eye
care. We offer bulk billed eye tests for valid Medicare cardholders.
[Book an Eye Test](https://www.oscarwylee.com.au/booking)
## In-store
Oscar Wylee has over 140 stores across Australia, New Zealand and Canada, each consisting of devoted
and skilled staff working with customers to provide eye tests and eyewear
to fit their needs. Each store is run by a dedicated team including store managers, Joint Venture
Partners, optometrists, optical dispensers and retail assistants.
### Oscar Wylee Optometrists
At Oscar Wylee, we have a reliable team of optometrists who provide expert eye care services
such as comprehensive eye tests and prescription updates. In each Oscar Wylee store, we have
friendly optometrists using high-quality equipment to care for our customers’ eyes. An [Oscar Wylee
optometrist](https://www.oscarwylee.com.au/eye-care/optometrist) will perform many tests in an eye exam to check a patient’s
vision and eye health. These tests include a visual acuity test, refraction assessment,
pupil function test, visual field test, slit-lamp examination and tonometry.
### Graduate Optometrists
Oscar Wylee also has the pleasure of working with recently graduated optometrists, providing
the opportunity for them to gain real-world experience in their field. As part of the OW
Optometry Graduate Program, they will learn valuable skills to take into their career such
as customer experience, clinical distinction and store operations. The graduates will be
encouraged to provide the highest standards of clinical expertise in eyecare as well as use
state-of-the-art technology.
### Joint Venture Partnership
Another aspect of Oscar Wylee’s in-store operations is our Joint Venture Partners. Our joint
venture partnership is an opportunity for inspirational business leaders to join Oscar Wylee
as part owners of our stores. We offer optometrist and retail and dispensing partnerships.
Our optometry and retail [Joint
Venture Partners](https://www.oscarwylee.com.au/joint_venture.html) are an essential part of the business. They are experienced
and have an exceptional rapport with our customers, providing outstanding patient care and
customer service.
## Head Office (Behind the Scenes)
To make sure everything runs smoothly in our stores and throughout the wider company, Oscar Wylee has
a valuable team working at head office who provide support wherever needed. The head office team is
also comprised of those in product development who are coming up with exciting ideas for new
eyewear collections, using the trends to interpret what our customers want. Marketing is also
a large part of head office with a collaborative team creating engaging and innovative campaigns to
showcase what Oscar Wylee offers across Australia, New Zealand and Canada.
Eye Health is Important!
Take care of your eyes by booking a bulk billed eye test with a friendly Oscar
Wylee optometrist.
[Book an Eye Test](https://www.oscarwylee.com.au/booking)
Visit a Store Near You
Oscar Wylee has 120 stores in Australia in both metro and regional areas. Find
your closest store to browse our wide range of fashion-forward frames.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)