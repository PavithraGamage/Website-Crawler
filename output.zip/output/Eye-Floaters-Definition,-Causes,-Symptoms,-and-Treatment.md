# Source: https://www.oscarwylee.com.au/glasses/eye/floaters-definition

# Eye Floaters: Definition, Causes, Symptoms, and Treatment
Published on March 24th, 2023
Updated on February 10th, 2025
Updated on January 11th, 2024  
Australia    
[Australia](https://www.oscarwylee.com.au/glasses/eye/floaters-definition)
[Canada](https://oscarwylee.ca/glasses/eye/floaters-definition)
[Canadian French](https://oscarwylee.ca/fr/glasses/eye/floaters-definition)
Eye floaters describe an eye condition where small specks or spots appear in a person’s vision due to changes in the vitreous fluid that fills the eye. This article will discuss the eye floaters definition, causes, symptoms and eye floaters treatment. The eye floater causes include age and diabetic retinopathy. The eye floater symptoms are lines, strings, and black dots in the vision. Eye floaters appear for the person as squiggly lines in their vision and are common for people of an older age. If a person has floaters in the eye it does not typically affect their vision although they can be more noticeable when looking at bright light.
Due for an eye test?
Book an appointment with one of our trusted optometrists for a bulk billed eye test.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Definition](#definition) [Causes](#causes) [Medical Conditions](#conditions) [Symptoms](#symptoms) [Treatments](#treatments)
## What are Eye Floaters?
Eye floaters are spots or lines in a person’s vision that are caused by changes to the vitreous inside the eye. The vitreous is a gel substance found throughout the eye which gives the eye its round shape. The fluid of the vitreous body is clear, gelatinous and has no colour. According to Mayo Clinic, eye floaters are most commonly caused by age as the vitreous contracts and liquifies which creates collagen fibres, causing people to see spots or squiggly lines in their vision. This process is known as posterior vitreous detachment (PVD). Eye floaters are a [common eye problem](https://www.oscarwylee.com.au/glasses/eye/common-problems) experienced as a person ages.
### Is "Seeing Spots in Vision" Related to Eye Floaters?
Seeing spots in vision is usually related to eye floaters as these spots may be parts of the vitreous that have clumped together, floating and drifting across a person’s vision. Spots in a person’s vision are one of the main symptoms of eye floaters and should be checked by an optometrist when first noticed.
### Are "Black Floaters" Connected to Eye Floaters?
Black floaters are connected to eye floaters as it is a common symptom of this eye condition. Black floaters, along with dark spots or squiggly lines, may be caused by the vitreous in the eye forming clumps in the eye as it shrinks with age. Age is not the only cause of eye floaters, so it is important to have your eyes examined by an eye care professional to determine the cause of this condition.
### What are the Other Terms for Eye Floaters?
The other terms for eye floaters include myodesopsias which is the clinical term and muscase volitantes which is the Latin term, which translates to flying flies according to the Ophthalmology Centre Barcelona. More colloquially, eye floaters are sometimes referred to as spots due to the appearance of black spots in the vision and also simply floaters.
### How Common are Eye Floaters?
Eye floaters are a common condition especially as a person gets older. As the eyes naturally age, the fluid that fills the eyeball (vitreous humour) shrinks causing small particles to move and float across your vision. A person is also more likely to develop eye floaters if they are nearsighted and over the age of 50.
## What are the Causes of Eye Floaters?
There are many different causes of eye floaters some of which are more common and others that are rare. The main causes of eye floaters include eye disease, diabetic retinopathy, asteroid hyalosis, eye injury, ageing, bleeding in the eye, retinal detachment and migraines. These causes and their definitions are listed below.
* Eye disease: Many eye diseases may be the cause of eye floaters. Some of these include uveitis and a torn retina.
* Diabetic retinopathy: Diabetic retinopathy occurs due to diabetes which has many symptoms, including eye floaters.
* Asteroid hyalosis: Asteroid hyalosis is a common eye condition that affects the vitreous and its main symptom is eye floaters.
* Eye injury: Trauma to the eye such as eye injuries may result in eye floaters, causing you to see black spots floating across your vision or flashes of light.
* Ageing: As the eye ages, the vitreous shrinks, creating clumps of collagen as it pulls away from the eye’s surface, causing eye floaters in a person’s vision.
* Bleeding in the eye: Bleeding in the eye can have many causes that may lead to eye floaters as the blood cells appear and drift through a person’s vision.
* Retinal detachment: Retinal detachment occurs when the retina at the back of the eye comes away from the part of the eye that provides it with the necessary nutrients and oxygen. If a person complains of eye floaters, an optometrist will immediately investigate whether there is a retinal detachment present.
* Migraines: Migraines may be a cause of eye floaters as the blood vessels in the brain constrict causing dark spots to float through the vision.
### 1. Eye Disease
Many [eye diseases](https://www.oscarwylee.com.au/glasses/eye/how-to-detect-diseases) can cause eye floaters in a person’s vision. Some of the eye diseases include uveitis and a torn retina. According to the National Eye Institute, uveitis is the inflammation in the back of the eye that can cause squiggly lines or dark spots to float across a person’s vision. This is called posterior uveitis and affects the back of the eye, including the retina.
### 2. Diabetic Retinopathy
Diabetic retinopathy is a complication of diabetes where the small blood vessels in the back of the eye are damaged. [Diabetic retinopathy](https://www.oscarwylee.com.au/glasses/eye/diabetic-retinopathy) may be treated with laser treatment, injections and surgery. Eye floaters are a symptom of diabetic retinopathy as the blood vessels can be seen as spots in a person’s vision. This eye condition may lead to vision loss but there are certain steps that can be taken to prevent this such as yearly diabetic eye examinations with your optometrist and seeing an ophthalmologist regularly to have any diabetic retinopathy closely monitored.
### 3. Asteroid Hyalosis
Asteroid hyalosis is a common eye condition that causes calcium-lipid complexes to become suspended in the vitreous. Asteroid hyalosis is typically developed due to genetics but it may also be caused by diabetes. The main symptom of this eye condition is eye floaters that appear in a person's vision. Asteroid hyalosis can be diagnosed by an eye care professional and does not usually require treatment unless it affects a person’s vision.
### 4. Eye Injury
An eye injury caused by trauma to the eye in an accident or through being hit by an object, may cause a person to develop eye floaters. This may cause them to see black spots floating across their vision or flashes of light. [Eye injuries](https://www.oscarwylee.com.au/glasses/eye/injuries) may cause eye floaters as the injury could lead to bleeding in the eye, therefore, the small blood vessels would appear in a person’s vision as small spots or threadlike strands.
### 5. Ageing
As you age, changes occur in your eyes, specifically the vitreous humour, which is a gel substance that fills the eye. According to Better Health, when you grow older the vitreous pulls away from the retina which may cause shreds of the fluid to break away and form floaters in the eye. Many people with age-related floaters will eventually get used to their presence and not require any treatment.
### 6. Bleeding in the Eye
Bleeding in the eye, also known as a vitreous haemorrhage, occurs when there is bleeding into the vitreous which may cause eye floaters. Bleeding in the eye may be caused by diabetes, high blood pressure and retinal tears and detachment. This eye condition can vary from mild which includes symptoms such as eye floaters, but can also be severe leading to vision loss.
### 7. Retinal Detachment
Retinal detachment is a vision-threatening condition that should be assessed by an eye care professional immediately. Retinal detachment occurs when the retina at the back of the eye comes away from the part of the eye that provides it with the necessary nutrients and oxygen. This condition may cause floaters in a person’s vision and requires treatment at the earliest possible moment to prevent permanent vision loss.
### 8. Migraines
Migraines can be a cause of eye floaters as well as flashing lights in a person’s vision. According to the American Academy of Ophthalmology, a migraine occurs due to a spasm of blood vessels in the brain which may cause light flashes that resemble looking through a kaleidoscope. Eye floaters caused by a migraine may appear in one or both eyes and can occur with or without a headache.
#### What are the Medical Conditions that Cause Eye Floaters?
The medical conditions that cause eye floaters include diabetes, posterior uveitis and retinal tears. These are all serious conditions that should be treated by an eye care professional or doctor. These medical conditions and their definitions are listed below.
* Diabetes: People who have diabetes can develop diabetic retinopathy which may lead to eye floaters. This eye condition causes damage to the blood vessels in the eye leading to blurred vision, spots in the vision and vision loss.
* Posterior uveitis: Posterior uveitis is a rare eye condition that causes the choroid to become inflamed. The symptoms of this condition include eye pain, light sensitivity and floaters in the vision.
* Retinal tear: A retinal tear is a serious issue that affects a person’s eyes and can often lead to a more severe condition called retinal detachment. Most retinal tears occur spontaneously although previous eye surgery and trauma can also cause this condition.
Need a new pair of glasses?
Browse our wide range of frames in-store where our team can help you with all your optometry and eyewear needs.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
## What are the Symptoms of Eye Floaters?
There are many symptoms of eye floaters, both common and rare, and these include lines, strings, cobwebs, threadlike strands and black or grey dots. The causes of eye floaters and their definitions are listed below.
* Lines: Squiggly lines are often seen in someone’s vision if they have eye floaters.
* Strings: Transparent strings are another form of eye floaters a person may see in their vision.
* Cobwebs: Eye floaters may resemble cobwebs or spiderwebs and can be nearly transparent.
* Threadlike strands: Eye floaters can appear as threadlike strands that drift in and out of a person’s vision.
* Black or grey dots:  Commonly people with eye floaters will see black or grey spots that appear when they move their eyes.
### 1. Lines
Squiggly lines are often seen in someone’s vision if they have eye floaters. Eye floaters such as lines may appear to disappear when you attempt to look directly at them and they may be light or dark. These eye floaters can sometimes be known as retinal floaters as they cast a shadow on the retina.
### 2. Strings
Transparent strings are a form of eye floaters a person may see in their vision. Strings in the vision will move as your eyes move but when you stop looking around, they will appear to float or drift through your vision. They cannot be rubbed away and are often a harmless but frustrating part of ageing.
### 3. Cobwebs
Eye floaters may resemble cobwebs or spiderwebs which can be nearly transparent and cannot be blinked away from your vision. People interpret their eye floaters differently with some seeing cobwebs or spiderwebs in their vision, whereas other people may describe them as strings or lines.
### 4. Threadlike Strands
Eye floaters can appear as threadlike strands that drift in and out of a person’s vision. According to Better Health, eye floaters are especially visible when looking at a light area such as a white wall, a blank sheet of paper or the sky. Threadlike strands can appear nearly see-through and typically will not go away but become less noticeable over time.
### 5. Black or Grey Dots
People commonly see black or grey dots if they have eye floaters. According to Healthdirect Australia, black or grey dots may drift away from your vision or dart away when you try to look at them. Although these spots appear to be in front of your vision, they are actually floating inside the eye and are made up of gel that is inside the vitreous.
### How are Eye Floaters Diagnosed?
Eye floaters are diagnosed through an eye test performed by an optometrist. They will assess your eye which may include having your eyes dilated to allow the optometrist to better see the vitreous and back of the eye. According to Healthdirect Australia, an optometrist may refer the patient to an ophthalmologist as they can have a closer look at the back of the eye.
#### Where can you Seek an Eye Floaters Diagnosis?
You can seek an eye floaters diagnosis from your local optometrist. They will perform a comprehensive eye test which will involve looking at the vitreous and back of the eye to determine if you have eye floaters. At Oscar Wylee, our optometrists are able to diagnose, manage and treat many eye conditions and will refer patients to an ophthalmologist when necessary.
## What are the Treatments Available for Eye Floaters?
In most cases, there is no treatment required for people with eye floaters as it usually does not impact lifestyle, but for people with eye floaters that affect their daily life or are caused by serious conditions, their eye doctor may suggest eye surgery, laser therapy or simply waiting out the symptoms as they may lessen over time and become tolerable. These treatments and their definitions are listed below.
* Eye surgery: Surgery may be performed by an ophthalmologist to remove the vitreous from the eye to be replaced with a solution so the eye retains its shape.
* Laser therapy: An ophthalmologist can use a laser to disrupt the floaters in a person’s eye to make them less noticeable.
* Waiting: Most of the time, eye floaters do not require treatment and a person can wait until they have adjusted to their presence.
### 1. Eye Surgery
Eye surgery is one of the treatments available for eye floaters and it is performed by an ophthalmologist. According to the Mayo Clinic, the surgery involves the removal of the vitreous from the eye which is replaced with a solution in order to help the eye maintain its shape. Eye surgery reduces the number of eye floaters but may not remove all eye floaters from a person’s vision and it does not prevent eye floaters from developing.
### 2. Laser Therapy
Laser therapy may be used to treat eye floaters as it can disrupt the floaters in a person’s eye to make them less noticeable and in some cases can completely remove them. Laser therapy, also known as vitreolysis, is performed by an ophthalmologist using quick pulses of laser light. According to Healthdirect Australia, the procedure usually takes between 20 and 60 minutes and the treatment usually requires 2 or 3 sessions in order to remove the eye floaters.
### 3. Waiting
Waiting, along with no treatment, is a common choice for people with eye floaters as most of the time this eye condition does not cause any discomfort or disruption to everyday life. When a person first develops eye floaters, on the advice of an eye care professional, waiting instead of undergoing treatment is common, as the floaters can be very frustrating but with time they may become unnoticeable. Once a person has adjusted to eye floaters they tend to see them less often, therefore, other forms of treatment are not necessary.
If eye floaters begin to bother you, speak to an optometrist and they can discuss your treatment options.
#### How are Eye Floaters Prevented?
Eye floaters cannot be prevented according to Health Direct, although they can be managed if they are affecting the person’s vision or everyday life. Although eye floaters cannot be prevented, there are certain people who are more at risk, for example, people who previously had eye surgery, have a family history of retinal detachment and are over 50 years of age.
#### Is the Use of Eyewear Advised for Eye Floaters?
Yes, in some cases, eyewear may be advised to help with the symptoms of eye floaters. While glasses cannot cure eye floaters, they may be helpful for people whose eye floaters are making it difficult to read and write. Glasses with tinted lenses could provide assistance as they block out a certain amount of light which can make eye floaters easier to ignore. Wearing prescription glasses to correct a person’s vision may help them ignore the presence of eye floaters as their clear vision allows them to focus on the task at hand.
#### Can Eye Floaters Cause Red Eyes?
No, eye floaters do not necessarily cause red eyes, however, certain eye conditions can cause symptoms of eye redness and floaters in a person’s vision. Eye conditions or problems that may cause eye floaters and [red eyes](https://www.oscarwylee.com.au/glasses/eye/red-or-bloodshot) include uveitis and bleeding in the vitreous.
Read Eye Floaters: Definition, Causes, Symptoms, and Treatment in other Oscar Wylee regions and their languages.
Australia    
[Australia](https://www.oscarwylee.com.au/glasses/eye/floaters-definition)
[Canada](https://oscarwylee.ca/glasses/eye/floaters-definition)
[Canadian French](https://oscarwylee.ca/fr/glasses/eye/floaters-definition)
We accept all leading health funds
Visit an Oscar Wylee store near you for an eye test or a new pair of frames, and your health fund may help cover the cost.
[Health Funds](https://www.oscarwylee.com.au/health-funds.html)
Prioritise your eye health
At Oscar Wylee, our optometrists are trained to assess your vision, diagnose eye conditions and provide treatment when necessary.
[Book an eye test](https://www.oscarwylee.com.au/booking)