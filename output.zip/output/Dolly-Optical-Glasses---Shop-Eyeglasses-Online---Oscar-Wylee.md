# Source: https://www.oscarwylee.com.au/dolly-optical.html

# Dolly
1
## Frame Design of Dolly Glasses
The frame design of Oscar Wylee’s Dolly glasses is characterised by a round shape, a high nose bridge fit and an acetate and stainless steel frame. Dolly glasses are a women's statement frame that will work for any occasion, whether the wearer wants to liven up their work style or complement a fun outfit for a night out.
$169    
In stock
Only %1 left
2 pairs from $199
Discount auto-applied at checkout
3 pairs from $249
Discount auto-applied at checkout
Qty
Add to cart
Book an eye test
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
excluding prescription lenses
## About Dolly Frames
Dolly is a delicately rounded frame made from mixed materials; acetate and metal. With a medium fit, Dolly is a flattering frame for many face shapes.
| Frame fit | Measurements |
| --- | --- |
| MEDIUM | 50 - 19 - 145 |
These measurements mean lens width, bridge, and temple length in millimetres (mm). They can be found on the inside of the temple arm. If you already have a pair that you like, you can compare it to these measurements.
### Made from Acetate and Stainless Steel
Oscar Wylee’s Dolly frame is a women’s, round glasses frame that is perfect for medium faces and those with square, oval and heart face shapes. The Dolly frame is a stylish, widely wearable frame suited to many personal styles. The main specs of Oscar Wylee’s Dolly glasses frame including dimensions, shape, materials, lenses, nose fit and hinges are listed below.
| Dolly Frame Features | Dolly Frame Description | Dimensions | Shape | Materials | Lenses | Nose Fit | Hinges |
| --- | --- | --- | --- | --- | --- | --- | --- |
| The dimensions of the Dolly frame are measured in millimetres (mm) and are 50 - 19 - 145, meaning the lens width is 50 mm, the bridge is 19 mm and the temple length is 145 mm. |
| The Dolly frame is a round shape, well suited to medium faces. |
| Dolly glasses are made from mostly acetate with stainless steel temples. |
| The lenses that can be used in the Dolly frame are optical lenses, which include single vision and multifocal lenses and non-prescription lenses, which are plain and can have a filter like a blue light filter applied. |
| The nose fit of Dolly frames is a high nose bridge fit. |
| The hinges in Dolly glasses are normal hinges, also known as standard or barrel hinges. |
Show All
### What Inspired the Frame Design of Oscar Wylee’s Dolly Glasses?
The Oscar Wylee Dolly frame design was inspired by current fashion trends as round shapes are often in fashion.
## What to Know About Oscar Wylee’s Dolly Glasses?
There are many aspects of the Oscar Wylee Dolly frames that customers should know about, so they can decide whether this is the right frame for them. The Dolly frame is a woman’s round-shaped frame. Oscar Wylee’s Dolly frame is suitable for many face shapes but particularly compatible with square, oval and heart face shapes. The Dolly frame’s simple design means that they are fashionable all year round. Dolly glasses feature the standard [parts of glasses such as a rim, temples, lenses, normal hinges and a high nose fit.](https://www.oscarwylee.com.au/glasses/eye/part-of-glasses)
### What are the Types of Temple Tips or Earpieces Included with Oscar Wylee’s Dolly Glasses?
The type of temple tips or earpieces included in Oscar Wylee’s Dolly Glasses are made from acetate, while the temples are made from stainless steel.
### What Type of Nose Bridge do Oscar Wylee’s Dolly Glasses Have?
The type of nose bridge included in Oscar Wylee’s Dolly frame is a high nose bridge fit.
### What Type of Nose Pads are Included with Oscar Wylee’s Dolly Glasses?
Oscar Wylee’s Dolly frame does not include any type of nose pads.
### What Type of Lenses do Oscar Wylee’s Dolly Glasses Have?
The type of lenses that typically come with the Oscar Wylee Dolly [glasses frame are optical lenses. Optical lenses are glasses lenses that have a prescription within the lens to help correct vision issues such as myopia, hyperopia and astigmatism. Dolly glasses can also come with non-prescription lenses, with add-ons such as a blue light filter. Dolly frames are currently unavailable as sunglasses online, however, customers can customise in-store and add on tint or polarisation.](https://www.oscarwylee.com.au/glasses.html)
### What Material is Used for the Rim of Oscar Wylee’s Dolly Glasses?
The material used for the rim of Oscar Wylee’s Dolly glasses frames is acetate. The rim refers to the part of a glasses frame that holds the lenses.
### What Type of Hinges are Included with Oscar Wylee’s Dolly Glasses?
The type of hinges included with Oscar Wylee’s Dolly frames are normal hinges, also known as standard or barrel hinges. These hinges have many interlocking loops that are stabilised with a small screw.
## What Face Types are Most Suitable for Oscar Wylee’s Dolly Glasses?
The face types that are most suitable for Oscar Wylee’s Dolly frame are heart, oval and square face shapes. The Dolly frame is a round shape, meaning that it complements the structure of oval faces particularly well. The round Dolly frames help to balance the features of an [oval face shape and a heart face shape, bringing the eyes and brows forward in a flattering way. The Dolly frame is also suitable for a](https://www.oscarwylee.com.au/glasses/face-shapes/oval)[square face shape. Round and oval frames help to bring forward the sharp and striking features of a square face type, highlighting without overemphasising them. Although there are many](https://www.oscarwylee.com.au/glasses/face-shapes/square)[glasses for face shapes that may be considered more aesthetically suitable, it is important that people also choose the frames that make them feel most comfortable, and represent their personal style.](https://www.oscarwylee.com.au/glasses/face-shapes)
## What Size Options are Available for Oscar Wylee’s Dolly Glasses?
The size options available for Oscar Wylee’s Dolly frame are a medium-frame fit across all colours.
## What Materials are Used to Create Oscar Wylee’s Dolly Glasses?
The primary material used to create the Oscar Wylee Dolly frame is acetate with the temples being made from stainless steel. Acetate, also known as cellulose acetate, is a bioplastic, made from cotton fibres or wood pulp.
## What’s Included
## OW Case &amp; Cloth
Protective Case and Lens Cloth
Our high-quality glasses case and lens cloth are included with every purchase of an Oscar Wylee frame. The stylish, magnetic case is made from a hard shell. This sturdy and durable material keeps your glasses protected and safe, wherever you go. Ensure your lenses are clean and scratch-free with our OW microfibre cloth, specifically designed to ensure you have comfortable vision through your lenses.
Oscar Wylee offers:
* Free Shipping for Australian Orders
* 1 Year Warranty on frames and lenses
* Scratch resistance lens coating on all prescriptions
* UV-proof coating on all prescriptions
Health fund rebate: Once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. Learn more about [health funds](https://www.oscarwylee.com.au/health-funds.html).
## Make and Materials
The frames then go through cleaning and strict quality control, and many pairs of crafting hands to be hand-assembled and polished. After your frames have gone through the production process, they are individually examined and packed before making their way to you!Our frames go through numerous stages of production and are hand-polished to ensure a glorious lustre. Featuring a mix of high-quality acetate and polished metal, these mixed materials frames are sure to enhance your eyewear collection.
## Warranty Information
### Warranty Information
### Warranty Information
Oscar Wylee provides a 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects. We will repair or replace faulty or defective frames or lenses free of charge for warranty claims made within 1 year of the delivery. We also offer repairs or replacement for problems experienced with vision during everyday use for claims made within 30 days of delivery. If the same product has been discontinued or is no longer available, then we may offer an exchange for a similar product or a refund.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Find a Store Location](https://www.oscarwylee.com.au/locations/full-store-list.html)