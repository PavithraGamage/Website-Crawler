# Source: https://www.oscarwylee.com.au/peggy-s-optical.html

# Peggy Small
1
## Frame Design of Peggy Small Glasses
The frame design of Oscar Wylee’s Peggy Small glasses is characterised by their classic shape, adjustable nose pads, and an acetate and stainless steel frame. Peggy Small is a female, statement glasses frame that will complement any outfit, day to night.
$169    
In stock
Only %1 left
2 pairs from $199
Discount auto-applied at checkout
3 pairs from $249
Discount auto-applied at checkout
Qty
Add to cart
Book an eye test
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
excluding prescription lenses
## About Peggy Small Frames
Little in size, but she sure packs a punch! Introducing Peggy in small! A hero for petite faces and for those who love a more compact fit.
| Frame fit | Measurements |
| --- | --- |
| MEDIUM | 50 - 20 - 145 |
These measurements mean lens width, bridge, and temple length in millimetres (mm). They can be found on the inside of the temple arm. If you already have a pair that you like, you can compare it to these measurements.
### Made from Acetate and Stainless Steel
Oscar Wylee's Peggy Small frame is a female classic glasses frame that is perfect for those with square, oval and pear face shapes. The Peggy Small frame is a stylish, widely wearable frame that can be worn every day. The main specs of Oscar Wylee's Peggy Small glasses frame, including dimensions, shape, materials, lenses, nose fit and hinges are listed below.
| Peggy Small Frame Features | Peggy Small Frame Description | Dimensions | Shape | Materials | Lenses | Nose Fit | Hinges |
| --- | --- | --- | --- | --- | --- | --- | --- |
| The dimensions of the Peggy Small frame are measured in millimetres (mm) and are 50 - 20 - 145, meaning the lens width is 50 mm, the bridge is 20 mm, and the temple length is 145 mm. |
| Peggy Small is a classic shape, well-suited to medium faces. |
| Peggy Small is made from acetate and stainless steel. |
| The lenses that can be used in the Peggy Small frame include optical lenses, such as single-vision and multifocal, and non-prescription lenses, which are plain and can have a filter, such as a blue-light filter applied. |
| The nose fit for Peggy Small is characterised by adjustable nose pads. |
| The hinges in Peggy Small are normal hinges, also known as standard or barrel hinges. |
Show All
### What Inspired the Frame Design of Oscar Wylee's Peggy Small Glasses?
The Oscar Wylee Peggy Small frame design was inspired by current fashion trends, as classic glasses are a timeless style.
## What to Know About Oscar Wylee's Peggy Small Glasses?
There are many aspects of the Oscar Wylee Peggy Small frames that customers should know about to decide whether this is the right frame for them. The Peggy Small frame is a female classic-shaped frame. Oscar Wylee's Peggy Small frame is suitable for many face shapes, but particularly compatible with square, oval and pear face shapes. The Peggy Small frame's simple design makes them fashionable all year round. Peggy Small features the standard [parts of glasses](https://www.oscarwylee.com.au/glasses/eye/part-of-glasses), such as a rim, temples, lenses, hinges, and adjustable nose pads.
### What are the Types of Temple Tips or Earpieces Included with Oscar Wylee's Peggy Small Glasses?
The type of temple tips or earpieces included in Oscar Wylee's Peggy Small Glasses are made from acetate.
### What Type of Nose Bridge do Oscar Wylee's Peggy Small Glasses Have?
The type of nose bridge included in Oscar Wylee's Peggy Small frame is characterised by adjustable nose pads.
### What Type of Nose Pads are Included with Oscar Wylee's Peggy Small Glasses?
Oscar Wylee's Peggy Small frame includes adjustable nose pads for an optimal fit for many faces.
### What Type of Lenses do Oscar Wylee's Peggy Small Glasses Have?
The type of lenses that typically come with the Oscar Wylee Peggy Small [glasses frame](https://www.oscarwylee.com.au/glasses.html) are optical lenses. Optical lenses are glasses lenses that have a prescription within the lens to help correct vision issues such as myopia, hyperopia, and astigmatism. Peggy Small frames can also come as sunglasses and with non-prescription lenses and add-ons such as a blue-light filter.
### What Material is Used for the Rim of Oscar Wylee's Peggy Small Glasses?
The material used for the rim of Oscar Wylee's Peggy Small glasses frames is a combination of stainless steel and acetate. The rim refers to the part of a glasses frame that holds the lenses.
### What Type of Hinges are Included with Oscar Wylee's Peggy Small Glasses?
The type of hinges included with Oscar Wylee's Peggy Small frames are normal hinges. Normal hinges, also known as barrel hinges or standard hinges. Normal hinges have many interlocking loops that are stabilised with a small screw.
## What Face Types are Most Suitable for Oscar Wylee's Peggy Small Glasses?
The face types that are most suitable for Oscar Wylee's Peggy Small frame are square, oval and pear face types. The Peggy Small frame is a classic shape, meaning that it complements the structure of square, oval and pear faces particularly well. The classic Peggy Small frames help balance the features of [square face shapes](https://www.oscarwylee.com.au/glasses/face-shapes/square), [oval face shapes](https://www.oscarwylee.com.au/glasses/face-shapes/oval) and [pear face shapes](https://www.oscarwylee.com.au/glasses/face-shapes/pear) bringing the eyes and brows forward in a flattering way. Although there are many [glasses for face shapes](https://www.oscarwylee.com.au/glasses/face-shapes) that may be considered more aesthetically suitable, it is important that people also choose frames that make them feel most comfortable and represent their personal style.
## What Size Options are Available for Oscar Wylee's Peggy Small Glasses?
The size options available for Oscar Wylee's Peggy Small frame are a medium fit frame across all colours.
## What Materials are Used to Create Oscar Wylee's Peggy Small Glasses?
The primary material used to create the Oscar Wylee Peggy Small frame is acetate and stainless steel. The rim is made from acetate and stainless steel, the nose bridge and temples are made from stainless steel and the temple tips are made from acetate.
## What’s Included
## OW Case &amp; Cloth
Protective Case and Lens Cloth
Our high-quality glasses case and lens cloth are included with every purchase of an Oscar Wylee frame. The stylish, magnetic case is made from a hard shell. This sturdy and durable material keeps your glasses protected and safe, wherever you go. Ensure your lenses are clean and scratch-free with our OW microfibre cloth, specifically designed to ensure you have comfortable vision through your lenses.
Oscar Wylee offers:
* Free Shipping for Australian Orders
* 1 Year Warranty on frames and lenses
* Scratch resistance lens coating on all prescriptions
* UV-proof coating on all prescriptions
Health fund rebate: Once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. Learn more about [health funds](https://www.oscarwylee.com.au/health-funds.html).
## Make and Materials
Our frames go through numerous stages of production and are hand-polished to ensure a glorious lustre. Featuring a mix of high-quality acetate and polished metal, these mixed materials frames are sure to enhance your eyewear collection. The frames then go through cleaning and strict quality control, and many pairs of crafting hands to be hand-assembled and polished. After your frames have gone through the production process, they are individually examined and packed before making their way to you!
## Warranty Information
### Warranty Information
### Warranty Information
Oscar Wylee provides a 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects. We will repair or replace faulty or defective frames or lenses free of charge for warranty claims made within 1 year of the delivery. We also offer repairs or replacement for problems experienced with vision during everyday use for claims made within 30 days of delivery. If the same product has been discontinued or is no longer available, then we may offer an exchange for a similar product or a refund.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Find a Store Location](https://www.oscarwylee.com.au/locations/full-store-list.html)