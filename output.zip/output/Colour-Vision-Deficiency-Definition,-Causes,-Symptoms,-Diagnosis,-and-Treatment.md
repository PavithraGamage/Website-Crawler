# Source: https://www.oscarwylee.com.au/glasses/eye/colour-vision-deficiency

# Colour Vision Deficiency: Definition, Causes, Symptoms, Diagnosis, and
Treatment
Published on August 2nd, 2023
Updated on Month Date, 2025 
Australia
[Australia](https://www.oscarwylee.com.au/glasses/eye/colour-vision-deficiency)
New Zealand

[Canada](https://oscarwylee.ca/glasses/eye/colour-vision-deficiency)
Canadian French

Colour vision deficiency, also known as colour blindness, refers to an eye
condition in which the eyes have trouble seeing colour properly. There are
three main types of colour blindness or colour vision deficiency:
blue-yellow colour blindness known as tritanopia, red-green colour blindness
known as protanopia and deuteranopia, and complete colour blindness known as
monochromatism. Colour vision deficiency is often caused by a defect in the
cones and rods of the eyes, passed on from parent to child. Colour vision
deficiency can also be caused by certain medical conditions, the use of
certain medications, a stroke, or certain head and eye injuries. Colour
vision deficiency that is not inherited and develops later is called
acquired colour vision deficiency. Colour vision deficiency is diagnosed by
an optometrist or other eye care professional using tests such as a colour
hue test or an Ishihara test. Colour vision deficiency does not have a cure.
Treatment for colour vision deficiency usually involves colour blindness
glasses or contact lenses, however, these will not always work for everyone.
In summary, the human eye works as light is received by the eye, passing through the cornea which bends the
light. The light then passes through the lens to focus on the retina which turns the light into electrical
signals which travel from the retina, to the optic nerve and finally into the brain which turns these signals
into the images we see. Keep reading to learn more about how vision works and what the human eye is capable of.

Make your eye health a priority
Book a bulk billed eye test with one of our skilled optometrists and
prioritise your eye health today.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Definition](#definition) [Causes](#causes)
[Symptoms](#symptoms)
[Different Types](#different-types)
## What is Colour Vision Deficiency or Colour Blindness?
Colour vision deficiency, more colloquially known as colour blindness,
is a condition in which the eyes have difficulty seeing colours in a
normal way.
Colour blindness may make people confuse colours, or make some colours
appear less bright, according to Health Direct. There are three main
types of colour vision deficiency according to Health Direct;
blue-yellow colour blindness known as tritanopia, red-green colour
blindness known as protanopia and deuteranopia, and complete colour
blindness known as monochromatism.
### How Does Colour Vision Deficiency (Colour Blindness) Work?
Colour vision deficiency or colour blindness is
caused by an error in the genes that determine visual photopigments
in the eyes.
Colour blindness is often a genetic condition, meaning it works by
being passed down from family members. When colour blindness is passed
down, it means there is a defect in the genes that are involved in
producing visual photopigments, which are what help the eye see and
absorb light, according to Victoria’s Better Health Channel. Defects
in visual photopigments can affect how the eyes see light and certain
colours, causing colour blindness. Colour blindness or colour
deficiency can also be caused later on in life by things like eye
diseases, although this phenomenon is not as understood as congenital
colour blindness, according to the American Academy of Ophthalmology.
### What Part of the Eye Is Affected by Colour Blindness?
The
[parts of the eye](https://www.oscarwylee.com.au/glasses/eye/anatomy)
that are affected by colour blindness are
cells called the cones and the rods, which are located in the
retina.
The cones and the rods are types of cells that help the eye detect
light. Rods are photoreceptors that are sensitive to light and help
people see in low light. Cones are active in higher levels of light
and help people to see colour. According to the National Institute of
Health, there are three different types of cone cells that detect
colour; blue, green and red. According to the American Academy of
Ophthalmology, if there is an issue or defect with the cones in the
eye, this may affect how the eye sees colour. For example, if one of
the three cones does not work correctly, then the eye may see a
different colour than what is actually present.
## What are the Causes of Colour Vision Deficiency?
The most common and well-understood cause of colour vision deficiency,
or colour blindness is genetics. Most cases of colour blindness
will be congenital, passed down from a parent. When colour blindness
occurs later in life, known as acquired colour blindness, this can be
caused by
head or eye injuries, different eye conditions including glaucoma and
macular degeneration, a stroke, other medical conditions such as liver
diseases or diabetes, use of specific medications and exposure to
certain chemicals.
The possible causes of colour vision deficiency or colour blindness are
listed below.
1. Genetics: Genetics is the most common
cause of colour vision deficiency. Genetics refers to the genes that
produce visual photopigments having defects or problems.
2. Head or Eye Injury: Head or eye
injuries may lead to colour vision deficiency, if the injury has
damaged parts of the eye like the retina, or impacted certain parts of
the brain.
3. Different Eye Conditions Including Glaucoma and Macular
Degeneration:
Different eye conditions may cause colour vision deficiency if the eye
conditions affect the photoreceptors in the eye.
4. Stroke: A stroke may lead to colour
vision deficiency if the stroke has impacted the part of the brain
that helps the eyes see colour.
5. Other Medical Conditions such as Liver Disease and Diabetes:
Liver disease and diabetes are medical conditions that have a
correlation with colour vision deficiency.
6. Use of Specific Medications: The use
of specific medications may lead to colour blindness, which is known
as acquired colour vision defects meaning the colour blindness is not
inherited.
7. Exposure to Certain Chemicals:
Exposure to certain chemicals such as carbon monoxide and carbon
disulphide, may lead to colour vision deficiency.
### 1. Genetics
Genetics is the
most common cause of colour vision deficiency or colour blindness
and refers to the genes that produce visual photopigments having
defects or problems, leading to the eyes not seeing colour
properly.
Colour blindness or colour vision deficiency, is often a genetic
condition, inherited or passed down from family members such as parent
to child. The genes involved in helping the eyes see colour are called
visual photopigments, according to Victoria’s Better Health Channel.
If the visual photopigments have defects, it can affect how the eyes
see light and specific colours, causing colour blindness.
### 2. Head or Eye Injury
A
head or eye injury may lead to colour vision deficiency or colour
blindness, if the injury has affected the retina, or has an impact
on the part of the brain that detects colour.
A head or an
[eye injury](https://www.oscarwylee.com.au/glasses/eye/injuries)
can be broadly defined as physical damage to the eye or the head
areas. If an injury to the eye impacts the retina, this could lead to
colour blindness, as the retina houses the rod and the cones that help
the eye see colour properly. A head injury may also lead to colour
blindness or colour vision deficiency if the injury has affected parts
of the brain that help the eye see colour. Cerebral achromatopsia for
example is a type of colour blindness that is caused by damage to the
ventral medial region of the occipital lobe, which is the part of the
brain that helps people see colour, according to Bartles and Zeki.
### 3. Different Eye Conditions Including Glaucoma and Macular
Degeneration
Different eye
conditions including glaucoma and age-related macular degeneration
(AMD), may cause colour blindness or colour vision deficiency if the
eye conditions affect the retina part of the eye.
Eye conditions encompass a range of issues that affect the eye and its
function, including
[glaucoma](https://www.oscarwylee.com.au/glasses/eye/glaucoma), age-related macular degeneration (AMD) and cataracts. Certain eye
conditions may lead to issues seeing colour properly if the condition
affects the retina part of the eye that houses the rods, cones and
photoreceptors all needed to help a person see colours correctly.
Glaucoma describes a group of eye conditions in which vision is
affected due to damage to the optic nerve. Glaucoma may lead to colour
blindness if the optic nerve is compressed, which can affect how
colour is seen, according to Vision Science Academy. Age-related
macular degeneration (AMD) is an eye disease that affects central
vision due to damage in the macula, located in the retina part of the
eye. Age-related Macular Degeneration may lead to colour blindness as
the photoreceptors that help the eye see light are located in the
macula, which is most affected by AMD. If the photoreceptors are
damaged or not working properly due to AMD, this can lead to issues
seeing colour, according to the Living Well with Low Vision
Organisation.
### 4. Stroke
A stroke
may lead to colour blindness or colour vision deficiency if the
stroke has affected the part of the brain that helps process
colours,
according to the Brain Recovery Project. A stroke occurs when there is
a sudden lack of blood in the brain, which leads to the brain not
receiving the oxygen or nutrients it needs, according to Health
Direct. The lack of oxygen and nutrients to the brain during a stroke
can damage the brain, including the parts of the brain that process
colour, such as the ventral occipital lobe.
### 5. Other Medical Conditions Such as Liver Disease and Diabetes
Other
medical conditions including liver disease and diabetes may lead to
colour vision deficiency. Cirrhosis of the liver, which is a type of liver disease that
causes healthy cells to be replaced by scar tissue, has been found to
be linked to colour blindness. According to a study consisting of a
hospital population, published in the Oxford University Press, there
is a genetic association between cirrhosis of the liver and colour
blindness. In terms of diabetes, according to an article published in
the National Library of Medicine titled,
Color vision abnormalities in type II diabetes: Sankara Nethralaya
Diabetic Retinopathy Epidemiology and Molecular Genetics,
there is a correlation between people with type 2 diabetes and colour
vision abnormalities. This study found that among people with type 2
diabetes, 43% of them also exhibited impaired colour vision.
### 6. Use of Specific Medications
The use of
specific medications may lead to colour blindness, which is known
as acquired colour vision defects meaning the colour blindness is
not inherited.
According to the Colour Blind Awareness Organisation, the medications
that may cause colour blindness include high blood pressure
medications, antibiotics, anti-tuberculosis drugs, barbiturates and
some medications used to treat nervous disorders. The drugs or
medications that may affect a person’s colour vision belong to a wide
range of pharmacological classes.
### 7. Exposure to Certain Chemicals
Exposure to certain chemicals may lead to colour vision deficiency.
According to the Colour Blind Awareness Organisation, there are
certain environmental and industrial chemicals that have been
linked to colour vision deficiency,
such as carbon monoxide and carbon disulphide. Changes to colour
vision caused by chemicals are often found in the blue-yellow axis.
Find your local Oscar Wylee store
Come and visit your nearest Oscar Wylee store for eye care services
including Medicare bulk billed eye tests and new, stylish frames.
[Find an Oscar Wylee store](https://www.oscarwylee.com.au/locations.html)
### Does Damage to the Optic Nerve Cause Colour Vision Deficiency?
Damage to the optic nerve
may cause a degree of colour vision deficiency, or colour
blindness. According to the American Optometric Association, damage to the
[optic nerve](https://www.oscarwylee.com.au/glasses/eye/anatomy/optic-nerve)
may cause a loss of colour recognition. The optic nerve is responsible
for transmitting visual information from the eyes to the brain. If the
optic nerve is damaged, it may affect how colour is transmitted to the
brain.
### Who is at Risk for Colour Vision Deficiency?
Those at risk for having colour vision deficiency or colour blindness
include
men and those with eye conditions such as glaucoma and age-related
macular degeneration (AMD).
According to the National Eye Institute, men are more likely to have
colour blindness than women due to the genetics involved in passing
down the eye condition from parent to child. Colour blindness is
passed down on the X chromosome, which men only have 1 of, whereas
women have two, meaning it is more likely for men to have colour
blindness than women. Those with eye conditions may also be at more
risk of developing colour vision deficiency as certain eye conditions
can affect the retina and photoreceptors within the eye that help the
eye distinguish between colours. People with certain medical
conditions such as Alzheimer’s disease and diabetes may also be at
more risk of developing colour vision deficiency according to the
Colour Blind Awareness Organisation.
#### How Does Being Colour Blind Affect the Individual?
The way being colour blind affects the individual will
depend on how bad the colour blindness is and what type of colour
blindnesses they have.
For most people with colour blindness, they will not see the world
in black and white, they will instead have trouble differentiating
between colours. For example, if a person has red-green colour
blindness, they will have trouble telling the difference between red
and green. According to Health Direct, some of the ways colour
blindness can affect the individual involve not knowing if meat is
cooked, or being able to see the colour of traffic lights. Being
colour blind may also impact career choices. For example, those who
wish to become a pilot may be limited in how much they can do with
colour vision impaired.
#### What is it Like to Live with Colour Blindness?
For most people, living with colour blindness
may cause some troubles, but these can usually be overcome
with the help of optometrists and treatment devices such as glasses.
##### Is There a Benefit to Being Colour Blind?
No,
there do not appear to be many benefits to being colour blind,
with the condition more often being a detriment to vision than a
help.
However, some studies have posited that people who are colour
blind may have better pattern and texture recognition than those
with full-colour vision. According to a 2005 article in Nature,
those who are red-green colour blind may be able to differentiate
between shades of camouflage and khaki that look the same for
those who have full-colour vision.
## What are the Symptoms of Colour Vision Deficiency (Colour Blindness)?
The main symptoms of colour vision deficiency or colour blindness
include
trouble seeing the difference between colours, trouble seeing the
differences in shades of colours and trouble seeing the brightness of
colours. For kids with colour blindness, these symptoms may become obvious in
activities such as colouring or painting. For some, the symptoms of
colour vision deficiency may be so mild that they don’t know they have
it, according to the American Academy of Ophthalmology. The possible
symptoms of colour vision deficiency are listed below.
* Trouble seeing the differences between colours:
Having trouble seeing the differences between colours, such as not
being able to see a difference between the colour red and green, is
one of the main symptoms of colour blindness.
* Trouble seeing the differences in shades of colours:
Trouble seeing the differences in shades of the same colour, such as
not being able to determine the difference between shades of red, may
also be a sign of colour vision deficiency.
* Trouble seeing the brightness of colours:
Having trouble seeing the brightness of colours, such as the colour
red being very dull, may also be a symptom of colour vision deficiency
or colour blindness.
## How is Colour Vision Deficiency (Colour Blindness) Diagnosed?
Colour vision deficiency or colour blindness is most often diagnosed by
an optometrist during an
[eye test](https://www.oscarwylee.com.au/free-eye-test).
Colour vision deficiency can be diagnosed during a
[colour vision test](https://www.oscarwylee.com.au/glasses/eye/test/colour-vision-test)
using a colour arrangement test or an Ishihara test.
### What are the Tests for Diagnosing Colour Vision Deficiency (Colour
Blindness)?
The tests most commonly used for diagnosing colour vision deficiency
or colour blindness are a
colour hue test or an Ishihara test. The tests used to diagnose
colour vision deficiency are listed below.
* Colour Hue Test:  A colour hue test
is a way to see if a person has colour blindness through the process
of ordering coloured blocks.
* Ishihara Test: An Ishihara test,
also known as a colour plate test, consists of circles or plates
made up of dots of a certain colour in varying shades
### 1. Colour Hue Test
A colour hue test is a way to
determine if a person has colour blindness using blocks that are
varying colours.
The aim of the test is for the patient to order the blocks, often in
rainbow order. If the blocks are not in the specified order, it can
indicate colour blindness according to the National Eye Institute.
### 2. Ishihara Test
An Ishihara test or a colour plate test is a way to
determine if a person has colour blindness, using plates made up of
different coloured dots.
An Ishihara test consists of circles or plates made up of dots of a
certain colour in varying shades, with a number in the middle made out
of the same dots but in a different colour. If a person can not see
the number in the middle of an Ishihara test, then they may have
colour blindness as their eyes have not differentiated between the two
colours on the plate.
## What are the Different Types of Colour Vision Deficiency (Colour
Blindness)?
There are several
[different types of colour vision deficiency](https://www.oscarwylee.com.au/glasses/eye/colour-blindness-types)
or colour blindness, with
the main three being blue-yellow colour blindness known as
tritanopia, red-green colour blindness known as protanopia and
deuteranopia, and complete colour blindness known as
monochromatism,
according to Health Direct. Red-green colour blindness refers to colour
blindness in which a person has trouble differentiating between red and
green colours. According to Britannica, red-green colour blindness is
more prominent in males, often passed down from a parent. Blue-yellow
colour blindness refers to colour blindness in which a person has
trouble seeing the difference between yellow and blue and this occurs in
both men and women. Complete colour blindness also known as
monochromatism, is less common than other forms of colour blindness and
refers to a person being unable to see any colour.
### Is Colour Vision Deficiency a Disability?
Yes, colour vision deficiency can be classified as a disability,
depending on the country you live in. In Australia, colour vision
deficiency is considered a disability, according to the Australian
Disability Clearinghouse on Education and Training.
## How is Colour Vision Deficiency (Colour Blindness) Treated?
Colour vision deficiency or colour blindness can
generally be treated through the use of glasses or contact lenses,
however, the effectiveness of these devices will be different for
everyone and are not a cure.
There is not currently any cure for colour blindness that is inherited
from a parent, as inherited colour blindness is concerned with a defect
in the cones within the retina. Colour blind glasses or contact lenses
may be used to help the eyes see colour better, but these are not
guaranteed to always work and their effectiveness can be down to the
individual. Colour blindness glasses work by using a filter across the
lens of glasses to help the brain filter certain wavelengths of light
and allow the brain clearer signals to try and see colours better,
according to the American Academy of Ophthalmology.
### Can Colour Vision Deficiency (Colour Blindness) be Prevented?
No, colour vision deficiency or colour blindness
can not be prevented if it has been inherited from a parent, as
this kind of colour vision deficiency is concerned with genes, and
they can not be altered. A person may help reduce their risk of
developing acquired colour vision deficiency if they book regular eye
tests and have their overall health checked consistently by their
doctor.
### Do Colour Blind Glasses Help Fix Colour Blindness?
No,
colour blind glasses will not fix or cure colour blindness or
colour vision deficiency but may help improve the way you see colour
slightly.
Colour blind glasses work by putting a filter across the lens of
glasses to help filter some of the wavelengths of light, confusing the
brain less and allowing it to perceive colours slightly better
according to the American Academy of Ophthalmology. However, colour
blind glasses may not work for everyone and their level of
effectiveness is down to the individual.
Read Colour Vision Deficiency: Definition, Causes, Symptoms,
Diagnosis, and Treatment in other Oscar Wylee regions and their
languages.
Australia
[Australia](https://www.oscarwylee.com.au/glasses/eye/colour-vision-deficiency)
New Zealand

[Canada](https://oscarwylee.ca/glasses/eye/colour-vision-deficiency)
Canadian French

Oscar Wylee accepts major health funds in-store
Visit Oscar Wylee in-store and our team can help you with your health
fund claims.
[Explore health funds](https://www.oscarwylee.com.au/health-funds.html)
When was your last eye test?
We recommend that everyone should have an eye test with an optometrist
at least once every 2 years.
[Book an eye test](https://www.oscarwylee.com.au/booking)