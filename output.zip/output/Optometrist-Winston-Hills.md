# Source: https://www.oscarwylee.com.au/locations/optometrist-winston-hills.html

# Optometrist Winston Hills
Winston Hills MallShop 21 180/190 Caroline Chisholm DrWinston Hills NSW 2153
* Next to Terry White Pharmacy
Opening hours
Monday9:00am - 5:30pm
Tuesday9:00am - 5:30pm
Wednesday9:00am - 5:30pm
Thursday9:00am - 9:00pm
Friday9:00am - 5:30pm
Saturday9:00am - 5:00pm
Sunday10:00am - 4:00pm
*Store hours reflect local standard trading hours and exclude public holidays
[Visit our Winston Hills Google Business page for directions, reviews, and updates.](https://g.page/r/CZHfysuEvex2EAE)
Book Appointment
[Call us: (02) 8604 8837](tel:(02) 8604 8837)
[Leave a Review!](https://g.page/r/CZHfysuEvex2EAE/review)
Our Reviews
Leah Abbott
1 month ago
Minnie Lam
1 month ago
Sam the optometrist is very detailed and caring. The dispenser is also very helpful and knowledgeabl...e.
See more
jessika morrison
1 month ago
Deborah Salkeld
2 months ago
Tina Mastrodomenico
2 months ago
The girl upfront was very helpful and professional, she is cheerful and happy when serving her custo...mers, helpful in choosing glasses and what deal is best for you. Will be returning again to Winston Hills to have my eye tested next year.
See more
Luisa Gaitau
3 months ago
The team that was working when I had my appointment were amazing! They were patient and very knowled...geable! Will be going back for any future needs!
See more
Angelo Orfanos
3 months ago
Annabelle Jimenez
3 months ago
The trainee that helped us this morning was a breath of fresh air! So lovely and helpful thank you!
Jane Moran
4 months ago
Very helpful and knowledgeable.
Ananda Goonetilleke
4 months ago
Virender singh
4 months ago
I had an amazing experience with Annie. She was incredibly helpful and took the time to properly che...ck my eye, which had been bothering me for several days. She didn’t just stop there—she quickly recognised that I needed further care and recommended a referral to an eye specialist.
What really stood out was her kindness and professionalism, and the fact that she followed up with me afterwards at no extra cost. That level of care is rare these days.
I’m really grateful for her support and would highly recommend Annie to anyone needing eye care. Thank you so much!
See more
Joanne Ng
4 months ago
Annie was very professional during the eye test process (fully covered by medicare). She is very kno...wledgeable and i gained better understanding of my situation. It was easy to make booking. You dont feel pressured to make any purchases. Highly recommended
See more
Pascaline Francis
4 months ago
Very good
mick b
5 months ago
A very exact examination, with very friendly staff
Michael
6 months ago
Linda Holman
6 months ago
Staff are super friendly and extremely helpful in helping to pick frames, they are honest with their... opinion on what looks good and what doesn’t.
See more
marie torkington
6 months ago
The staff at reception and Annie were all very helpful and pleasant. They know their jobs and were d...one with me swiftly and efficiently.
See more
Bron
6 months ago
Winston Hills OW
6 months ago
Jay G
6 months ago
Staff are friendly and very helpful. Been to the shop a few times lately. My glasses lost a screw, s...taff fixed it immediately in store at no cost. They were also very helpful with my newest pair.
See more
Elizabeth Curmi
7 months ago
Madi Quinn
7 months ago
The optometrist I saw was very thorough and explained everything to me really well, and the customer... service staff were very helpful in choosing the frames and types of lenses I needed. Oscar Wylee have a much better selection of frame styles than other stores
See more
Dathipa Halliday
7 months ago
From my very first visit, I was impressed by the exceptionally friendly staff. They provided expert ...advice, and the wide selection of frames available.
See more
Maria Jerome
8 months ago
Awesome people, professionals
Lena
8 months ago
Had an eye check up with Annie today. She's a wonderful optometrist who is knowledgeable and easy go...ing. The whole team was very friendly. They helped my partner and I pick some stylish new glasses. Highly recommend ????????????????????????
See more
annamneedu sreedevi
8 months ago
Belinda Krull
9 months ago
I originally had my eyes tested at another Optometrist. I ended up going to Oscar Wylee because I wa...s having some trouble with the original Optometrist.  From the very beginning, the staff at Oscar Wylee were very helpful and kind. I ordered 2 sets of glasses with the prescription from the original Optometrist. The prescription ended up being wrong and Brenda was very helpful in getting me another eye test with their optometrist and getting my glasses fixed to the correct prescription. Extremely happy with the service and kindness of Brenda and the staff at Oscar Wylee. Thank you.
See more
Neelam Jain
9 months ago
Em Mad4Tennis
10 months ago
A much more welcoming and professional experience than at Specsavers. Optometrist is highly competen...t and gets very accurate readings for prescriptions. She picked up my DH"s double vision problem when Specsavers" one never did. They also carry better quality glasses and has good range of designs even though they are not branded.
See more
Robert Sarpong
10 months ago
Friendly service, good prices. helpful advice and even adjusts specs not bought from them
Russell Cunliffe
10 months ago
This is my 3rd visit to Oscar Wylee Winston Hills. I am always treated with exceptional service
Kaelib Starr
11 months ago
Great reception and work well
Dianne Davidson
11 months ago
The staff were very professional and didn’t take long to help me with my needs.
Flo Mati
11 months ago
Very professional,caring and friendly team at Winston Hills. Easy booking for an appointment.
Annelise Karpos
11 months ago
Marija Brankovic
1 year ago
Helpful staff, easy quick eye test appointment, hassle free service. Would definitely recommend
brenda kwak
1 year ago
Annie, the optometrist is always great. She pays attention to every words you concern. High level of... eye care
See more
Sugalan Nada
1 year ago
It was a pleasant experience!
Chris S
1 year ago
Awesome service.AAA+
Arezoo Taheri
1 year ago
Had my first visit to Oscar Wylee yesterday and it was such a great experience! Got my eyes tested a...nd picked out a new pair of glasses. The team were absolutely lovely – super friendly, helpful, and made everything really easy. Big thanks for the awesome service!
See more
Zouhad Saad
1 year ago
The girls at the Winston Hills branch are awesome !!
Vanita Roy
1 year ago
The eye examination was very thorough. Both the optometrist and the assistant were very efficient an...d professional. Thoroughly recommend them.
See more
Amie Zheng
1 year ago
Julianne Hart
1 year ago
Very professional &amp; caring.
Leah Abbott
1 year ago
Minnie M
1 year ago
A Google User
1 year ago
Thank you for your service &amp; wonderful support, Alanah
Carolyn Birinyi
Thulasee Sri Ganeshan
1 year ago
Great service - friendly, helpful and professional staff!
Steve Timpson
1 year ago
Very friendly and professional service, checked all aspects of my eyes thoroughly, provided crotical... information to my G.P. and helped me choose reading glasses that I desperately needed. A great experience all round.
10/10. Thank you.
See more
Kenson Kung
1 year ago
## Find an Optometrist in Winston Hills With Oscar Wylee
Find our Oscar Wylee Winston Hills store located in the very centre of the Winston Hills Mall, right next to the Terry White Pharmacy. For valid Medicare cardholders, our optometrists at our Oscar Wylee Winston Hills store offer bulk billed eye tests. With Oscar Wylee, you can have your eye health checked, update your prescription, and talk to our friendly team to find your new pair of glasses or prescription sunglasses on the same day! Winston Hills Mall offers ticketless parking for up to 3 hours. There are bus stops right in front of the mall and a taxi rank near Cafe Els. 
Once you’ve found the glasses that are just right for you, why not take a look around Winston Hills Mall? The space is cosy, has many beautiful cafes to take a break in and Winston Hills Mall is never overwhelmingly busy. Or leave the mall for a wonderful park only a short walk away. Come see our friendly team at the Oscar Wylee Winston Hills store for our quality eye care processes.        
Meet Our Team
* Store Manager
Certificate IV in Optical Dispensing
Our Services
* Bulk Billed Eye Examinations
* Professional Frame Styling
* Frame Adjustments and Repairs
Show All
## Find an Optometrist in Winston Hills, Sydney for an Eye Health Test
An optometrist in Winston Hills, Sydney is where you can receive top-of-the-line eye health services such as eye tests and prescription eyewear. At Oscar Wylee, we offer an eye health test in Winston Hills at a bulk billed price courtesy of Australia’s Medicare System. Comprehensive eye tests are helpful for the early detection of eye diseases and for keeping track of any changes to your vision. Our optometrist can even refer you to an eye doctor if required. If you require prescription glasses or prescription sunglasses, our optical dispenser will be able to make sure your frames fit you suitably.
An eye test may involve using a few different tools and methods to assess different regions of the eye. Our team will strive to ensure you are completely informed of the processes involved. The average price for an optometrist in Winston Hills may be based on factors such as how many other available optometrists are in the area, your vision requirements, equipment and operating facilities.
## How to Find an Optometrist in Winston Hills, Sydney?
To find an optometrist in Winston Hills, Sydney you can take certain steps that can help make it easier for you such as searching online, assessing the store’s opening hours and finding the directions to your chosen location. The steps on how to find an optometrist in Winston Hills are listed below.
1. Search online using the phrase, Winston Hills optometrist near me. This can also be done here on the website via our locations page.
2. Click on the Oscar Wylee link, which will take you directly to our Winston Hills optometrist store page.
3. See the store’s opening hours and where the store is located specifically.
4. Use the Winston Hills Google Business page link located under store hours to see the directions on how to get to the store.
You can also find an optometrist in Winston Hills by searching the keywords optometrist near me. If you have locations enabled on your smartphone and you’re in the Winston Hills area, our Winston Hills store page should appear easily for you to click on.
### Is it Hard to Get an Eye Appointment in Winston Hills, Sydney?
No, it is not hard to get an eye appointment in Winston Hills. You can easily book an appointment to see an Oscar Wylee optometrist in Winston Hills right here on this page. At Oscar Wylee we have highly qualified optometrists available for bulk billed eye appointments, which can be booked online or in-store.
#### How to Compare Optometrists in Winston Hills to Each Other?
To compare optometrists in Winston Hills, you can use factors such as eye tests offered, health fund coverage, lens types and add-ons and eyewear offered. To take care of your vision and eye health, it is important to receive an eye test at least once every two years. There are different types of tests that can be performed in an eye test and not all optometrists may offer the same tests. Health funds can be used to help cover some of the cost of your frames and lenses. To find out if your health fund is accepted at Winston Hills optometrist in Sydney, visit their website. In the case of Oscar Wylee, we accept all major health funds and provide on-the-spot claims in-store. There are many different lens options available for prescription glasses such as single vision, multifocal and high index lenses. Most optometrists in Winston Hills will offer these lenses although it is good to make sure. There are also lens add-ons available to enhance your glasses such as anti-reflective and blue light filters. Finally, if you are looking to purchase a pair of glasses after your eye test, you can compare the different styles and colours you are interested in from Winston Hills optometrists in Sydney. Oscar Wylee offers a wide range of frames with vintage and modern inspirations in bold colours and subtle designs.
#### How to Find an Eyeglasses Shop in Winston Hills, Sydney?
To find a glasses store in Winston Hills, you can try to follow these simple steps including searching online, selecting a convenient location and looking at their health insurance policies. The steps on how to find a glasses store in Winston Hills, Sydney are listed below.
1. Search online using the phrase, glasses store in Winston Hills. This will provide you with various options for glasses stores in the whole area of Winston Hills.
2. Select a glasses store that is most convenient for you to travel to.
3. Click the link to find out more information such as opening hours, exact location and directions to the glasses store in Winston Hills.
4. Read their health insurance policies to ensure you know what health benefits you have access to.
Our Oscar Wylee glasses store in Winston Hills, Sydney offers primary eye care services such as comprehensive eye tests as well as other services performed by an optometrist and offers prescription and non-prescription eyewear.
##### Is it Possible to Purchase Prescribed Sunglasses in Winston Hills, Sydney Without Seeing an Optometrist?
Yes and no, it is possible to [purchase prescribed sunglasses](https://www.oscarwylee.com.au/sunglasses.html) in Winston Hills, Sydney without seeing an optometrist if you already have a prescription that has not expired. If your prescription is expired, you can book an eye test to receive an updated or new prescription which will require you to see an optometrist. This will ensure your prescription sunglasses are appropriate for your visual needs.
## Where is the Oscar Wylee Winston Hills Optometrist in Sydney Located?
The Oscar Wylee Winston Hills optometrist is located at the Winston Hills Mall at 180/190 Caroline Chisholm Drive. The Oscar Wylee Winston Hills store can be found next to Terry White Pharmacy.
### What is the Phone Number of Oscar Wylee Winston Hills Optometrist Store?
The Oscar Wylee Winston Hills optometrist store phone number is [(02) 8604 8837](tel:(02) 8604 8837). You can contact the Oscar Wylee Winston Hills store between the hours of 9 am and 5:30 pm on Monday, Tuesday, Wednesday and Friday, on Thursdays between 9 am and 9 pm, on Saturdays between 9 am and 5 pm and on Sundays between 10 am and 4 pm.
### What are the Reviews for Oscar Wylee Winston Hills Optometrist in Sydney?
The many reviews for Oscar Wylee Winston Hills optometrist in Sydney, left by our various customers can be found here on the website and online when you search for Oscar Wylee Winston Hills optometrist. The reviews for Oscar Wylee Winston Hills optometrist are listed below.
* Corinne:  Great experience, friendly and such a great range that it was the easiest time picking out my glasses.
* J L:  5 stars for the young man who works there–so helpful and knowledgeable. He kindly fixed my too loose glasses which were unwearable which the other worker couldn't fix when I picked them up a week ago. Also gave advice on selecting frames. Highly recommend going there.
* Chris Beecher:  Great experience. Thank you to Sahar and the team. Looking forward to my new glasses arriving!
* Upeka Pasqual:  Excellent customer service at Oscar Wylee Winston Hills Mall. Pleasant staff. I got my eyes tested from them this year as well from past year experience and their products. The look of the frame of my glasses suits me very well and highly commented on by my friends and colleagues. Happy to let you know I purchased the same frame this year too.
#### What Treatments or Eye Care Processes are Done in the Oscar Wylee Winston Hills Optometrist Location?
The treatments or eye care processes done in the Oscar Wylee Winston Hills optometrist Sydney location include a tonometry test, a slit lamp exam and a refraction test. Additional tests that may also be performed can include a dilated fundus exam. The treatments or eye-care processes that are done in the Oscar Wylee Winston Hills optometrist Sydney location are listed below.
* A Tonometry Test: An optometrist or optical dispenser will conduct a tonometry test which involves the use of a machine that will release small puffs of air into your eyes. This will assist with measuring pressure in the eye.
* Slit Lamp Test: A slit lamp test can be used to evaluate your eye health, by examining your cornea and iris which are the anterior and posterior of the eye.
* Refraction Test: During a refraction test, an optometrist will have you view an image through different lenses and ask you to confirm which helps you see the image clearer.
* Dilated Fundus Exam: A dilated fundus exam can help an optometrist assess your health in more detail by getting a clear view of the retina. This test is typically carried out for patients with diabetes and those who may be at risk of developing retinal damage.
## How Many Optometrists Exist in Winston Hills, Sydney?
Many optometrists exist in Winston Hills, Sydney to provide eye tests and glasses, including Oscar Wylee. The number of optometrists in Winston Hills may be due to the number of residents in the area and the geographical size of the suburb. If you need essential eye services such as a comprehensive eye test, a wide selection of prescription eyewear and more, then choose Oscar Wylee as your first choice for optometry services.
### What are the Other Closest Optometrist Locations to Winston Hills, Sydney in Australia?
The other closest Oscar Wylee optometrist locations to Winston Hills, Sydney Australia are Blacktown, Parramatta, Merrylands and Castle Towers. The other closest optometrist locations to Winston Hills are listed below.
* Blacktown:  Blacktown is close to Winston Hills with 7-8 km in between stores and is located at 17 Patrick Street. The [Oscar Wylee Blacktown](https://www.oscarwylee.com.au/locations/optometrist-blacktown.html) store can be found near YD and Typo and offers high-quality eye tests available for bulk billing and an abundant selection of fashionable frames.
* Parramatta:  Parramatta is close to Winston Hills with 8 km in between stores and is located at 159-175 Church Street. The [Oscar Wylee Parramatta](https://www.oscarwylee.com.au/locations/optometrist-parramatta.html) store can be found on level 3 near Nike and is the place to look for your next pair of sunglasses or prescription glasses! We can offer our professional assistance and advice in terms of frame styling and your vision requirements.
* Castle Towers:  Castle Towers is close to Winston Hills with 9 km in between stores and provides comprehensive eye tests for prescription eyewear as well as non-prescription eyewear. You can find the [Oscar Wylee Castle Towers](https://www.oscarwylee.com.au/locations/optometrist-castle-towers.html) store on level 2 of the Castle Towers Shopping Centre near David Jones.
* Merrylands:  Merrylands is close to Winston Hills with 10 km in between stores and is located at 1 Pitt Street. The [Oscar Wylee Merrylands](https://www.oscarwylee.com.au/locations/optometrist-merrylands.html) store is where you can get your eyes tested and browse for your desired frames, all on the same day.
### Bulk Billed Eye Tests at Winston Hills
Our eye health tests and vision testing are all conducted by our incredible staff at Oscar Wylee Winston Hills. Come into our eyeglasses shop and have your prescription updated and browse for a new pair of eyeglasses on the same day. Our trained optometrists at Oscar Wylee Winston can update your prescription or issue a new one, usually in under 20 minutes. With the recommended frequency of an eye check-up and vision testing being at least once every two years, Oscar Wylee in Winston Hills will make sure you’re up to date on your eye care needs!
### Health Funds Accepted at Oscar Wylee Winston Hills
Oscar Wylee in Winston Hills accepts major health funds such as HCF, Bupa and Medibank. We can process your claim at our Oscar Wylee Winston Hills store with a valid health fund card, as well as take you through each step of your insurance to make certain you’re getting the best price every single time for all of your prescription glasses needs. We pride ourselves in our quality eye care processes, so make our store your first choice for optometry services.
### Frames Perfect for the Fashion-Minded at Oscar Wylee
Here at our Oscar Wylee Winston Hills store, we’ve got a range of vintage-inspired and modern frames for prescription sunglasses and prescription glasses. You may choose to upgrade your lenses with multifocals. Our optometrists in Oscar Wylee Winston Hills will help you choose what’s best for you, and you’ll leave our store with a pair of prescription glasses or prescription sunglasses that align with your needs and personal style.
Book Appointment
[Call us: (02) 8604 8837](tel:(02) 8604 8837)
[Leave a Review!](https://g.page/r/CZHfysuEvex2EAE/review)