# Source: https://www.oscarwylee.com.au/glasses/eye/optic-atrophy

# Optic Atrophy: Meaning, Causes and Treatment
Published on May 26th, 2026
Optic atrophy refers to damage to the optic nerve, which is responsible for transmitting visual information from the eyes to the brain. Optic atrophy may lead to permanent vision loss and can occur from causes such as brain injury, brain trauma, inflammation, degenerative disorders and tumours, according to Vision Australia. Vision loss from optic atrophy typically varies depending on the severity of the condition, and due to the nerve damage, this condition cannot be treated. However, in some cases, the cause of damage may be treatable. The contents of this article are for informational purposes only and should not be used to participate in any self-diagnosis. If you are concerned, it is important to see your optometrist for a comprehensive examination.
Stay on top of your eye health!
It is recommended to get an eye test at least once every 1-2 years unless advised otherwise by an optometrist.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Definition](#definition) [Causes](#causes) [Symptoms](#symptoms) [Associated Conditions](#associated-conditions)
## What is Optic Atrophy?
Optic atrophy refers to damage to the optic nerve as a result of causes such as brain injury, brain trauma, inflammation, degenerative disorders and tumours. Optic atrophy can lead to vision loss or blindness, and due to the consequential nerve damage, this condition cannot be reversed nor treated, according to Vision Australia. Early detection and treatment of underlying conditions may help reduce the risk of reaching this stage.
### How does Optic Atrophy Affect the Optic Nerve?
Optic atrophy affects the optic nerve as it is the deterioration of the ganglion cell axons, which are the small nerve fibres that deliver visual information from the retina to the brain. As these fibres deteriorate, the [optic nerve](https://www.oscarwylee.com.au/glasses/eye/anatomy/optic-nerve) can no longer send visual signals, resulting in vision loss, reduced field of vision and a pale and white appearance of the optic disc.
### Is Optic Atrophy a Form of Optic Nerve Damage?
Yes, optic atrophy is a form of optic nerve damage. According to Ahmad et al., (2024), optic atrophy is a pathological term referring to optic nerve shrinkage and describes the damage to the anterior visual pathway.
## What Causes Optic Atrophy?
The causes of optic atrophy can include brain injury, inflammation, degenerative disorders and tumours. The causes of optic atrophy are listed below.
* Brain Injury: A brain injury may lead to optic atrophy due to the direct physical impact or from damage that occurred after birth from systemic conditions. Depending on the extent of injury, this can cause the ganglion cells to die shortly after, causing vision loss.
* Inflammation: Inflammation can be a cause of optic atrophy when the inflammation is recurring or ongoing, especially from conditions such as optic neuritis. The myelin coating and internal nerve fibres become damaged.
* Degenerative Disorders: Degenerative disorders such as glaucoma, multiple sclerosis, and Leber hereditary optic neuropathy may lead to optic atrophy, resulting in deterioration of the optic nerve fibres.
* Tumours: Tumours can also lead to optic atrophy due to the resulting physical pressure on the optic nerve, leading to ischemia or restricted blood flow.
#### Can Glaucoma Cause Optic Atrophy?
Yes, glaucoma can cause optic atrophy. Glaucoma, when left untreated or in severe cases, means increased intraocular pressure, which can lead to optic atrophy. According to Dinsdale et al., (2023), glaucoma is classified as a progressive optic neuropathy, which indicates that the appearance and health of the optic nerve will gradually deteriorate.
## How is Optic Atrophy Linked to Rare Genetic Eye Diseases?
Optic atrophy may be linked to rare genetic eye diseases, as they can hinder the function of the mitochondria. Due to the optic nerve's required energy to convert visual information to the brain, it is more vulnerable to genetic errors. This can be inherited through a parent's mitochondrial DNA in the case of Leber's hereditary optic neuropathy from a mother or through autosomal dominant optic atrophy, for example. In turn, the genetic mutation results in a lack of energy for the nerve cells, causing the small fibres in the optic nerve to deteriorate and die, according to Allen et al., (2015) in their paper titled Genetics of Primary Inherited Disorders of the Optic Nerve: Clinical Applications.
### What Genetic Disorders Can Lead to Optic Nerve Degeneration?
The genetic disorders that may lead to optic degeneration can include Leber's hereditary optic neuropathy (LHON), dominant optic atrophy and Leigh Syndrome. The genetic disorders that may lead to optic nerve degeneration are listed below.
* Leber's Hereditary Optic Neuropathy (LHON): Leber's Hereditary Optic Neuropathy is one of the many genetic disorders that can lead to optic nerve degeneration, as it is a rare genetic mitochondrial disease that can cause sudden central vision loss. Mitochondria generate the required energy to power the cells in your body. Therefore, when they are not working properly, reduced energy production can lead to the death of retinal ganglion cells, which convey visual information to the brain.
* Dominant Optic Atrophy: Dominant optic atrophy is the most common inherited condition that can lead to optic nerve degeneration and can be passed down from either your mother or father. Only one copy of the gene is necessary for the disorder to occur, and it presents with bilateral and gradual vision loss, initiating in the first or second decade of life.
* Leigh Syndrome: Leigh syndrome is another genetic eye disorder that can result in optic nerve degeneration as it disrupts the function of the mitochondria and also affects the spinal cord and brain. This condition usually presents symptoms between the ages of three months and two years and involves progressive neurological deterioration.
#### Is Optic Atrophy Considered a Rare Eye Condition?
Yes and no, optic atrophy is considered to be the last stage of optic nerve deterioration. However, this stage can come about during rare eye conditions and other more common eye conditions.
### How is Leber Hereditary Optic Neuropathy (LHON) Linked to Optic Atrophy?
Leber Hereditary Optic Neuropathy (LHON) is a genetic disorder that harms the retinal ganglion cells and hence damages the nerve fibres in the optic nerve. The result of this is optic atrophy.
### How does LHON lead to Optic Nerve Damage and Atrophy?
LHON can lead to optic nerve damage and atrophy through a sequence of cellular issues. Optic nerve damage and atrophy stem from LHON due to certain mutations in mitochondrial DNA, which can then interfere with energy production for the retinal ganglion cells, which crucially require optimal energy to send visual information to the brain. With disrupted energy production, free radicals and reactive oxygen species can accumulate and cause oxidative stress. Oxidative stress refers to the imbalance between free radicals and antioxidant defences in your body, according to Healthline. When there is a lack of energy and a buildup of oxidative stress in the cells of the optic nerve, the cells can deteriorate and die, according to Shemesh et al., in their article titled, Leber's Hereditary Optic Neuropathy.
#### Does LHON Commonly Cause Rapid Vision Loss in Young Adults?
Yes, LHON can commonly cause rapid vision loss in young adults. Vision loss in young adults may be more common between the ages of 18 and 32 years, according to the Centre for Eye Research Australia.
Find Your Nearest OW Store!
We've got knowledgeable teams who are passionate about delivering high-quality care.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
## What are the Symptoms of Optic Atrophy?
The symptoms of optic atrophy may include central vision loss and peripheral vision loss. The vision loss may vary depending on the extent of the atrophy, according to Vision Australia. Due to optic atrophy being the end-stage of optic neuropathies, patients may experience other signs/symptoms of the underlying cause of optic atrophy.
### What Signs Suggest Optic Nerve Damage Is Present?
The signs that may suggest optic nerve damage are present may include vision loss, a pale optic disc and contrast problems. Vision loss from optic nerve damage occurs as a result of the small fibres that send visual information from the eye to the brain being harmed. When cells die, they cannot regenerate, causing blind spots or low peripheral vision. A pale optic disc is a key clinical sign that suggests the optic nerve is damaged, as a healthy optic disc usually appears reddish pink. A pale optic disc can be seen during an eye test and suggests that the optic nerve is damaged. Several instruments allow the optometrist to identify this clinical sign during the eye check-up.
#### Is Blurred Vision a Common Symptom of Optic Atrophy?
Yes, blurred vision can be a common symptom of optic atrophy. However, it is important to note that [blurry vision](https://www.oscarwylee.com.au/glasses/eye/blurred-vision) can occur as a common symptom of many other eye conditions and minor issues. Therefore, it is important to see an optometrist when experiencing any vision changes to rule out any major underlying conditions.
## How is Optic Atrophy Diagnosed?
Optic atrophy can be diagnosed through an eye test. An eye test can examine different regions and functions of the eye and help identify key clinical signs, such as a pale optic disc.
### What Tests Detect Optic Nerve Degeneration?
The tests that can detect optic nerve degeneration can include a visual field test, an OCT scan, and an MRI. The tests that can detect optic nerve degeneration are listed below.
* Visual Field Test: A visual field test can detect optic nerve degeneration as it can examine your central and peripheral vision and identify any compromise of the visual field.
* OCT Scan: An OCT scan can help detect optic nerve degeneration by measuring the thickness of the nerve fibres in the optic nerve.
* MRI: An MRI may be used to detect optic nerve degeneration, depending on the condition you present with. An MRI uses powerful magnets and radio-frequency pulses to generate images of the inside of your body.
#### Is Imaging Needed to Confirm Optic Atrophy?
Yes, imaging may be needed to confirm optic atrophy. Confirming optic atrophy may require structural imaging to determine the initial cause of damage to the optic nerve.
## What Treatment Options are Available for Optic Atrophy?
There are no treatment options available for optic atrophy due to the inability of the optic nerve fibres to regenerate. It is important to address the underlying conditions that can lead to this stage and get your eyes tested when experiencing any changes to your vision to ensure early detection of any problems. Low vision aids may be recommended; however, this will depend on the extent of your condition, and an eye health professional will advise the next steps.
### Can Optic Atrophy be Reversed With Treatment Today?
No, optic atrophy cannot be reversed as there is no current treatment. When the fibres of the optic nerve have deteriorated, they do not regenerate. Optic atrophy is considered the last stage of optic nerve degeneration that can stem from initial eye conditions.
## How do Prescription Glasses Help People With Vision Loss From Optic Atrophy?
Prescription glasses may help people with vision loss from optic atrophy by supporting remaining vision. However, this will depend on the extent of the atrophy and how much vision is still remaining in the patient's condition. An ophthalmologist and/or an optometrist may test the patient's eyes to evaluate the health of the patient's remaining vision. Wearing [UV protection glasses](https://www.oscarwylee.com.au/glasses/eye/uv-protection) can help with some symptoms and maintain its health.
## What Steps can Help Reduce the Risk of Optic Atrophy?
The steps to take that can help reduce the risk of optic atrophy may include regular eye tests, managing underlying health conditions and maintaining a healthy lifestyle. The steps that may help reduce the risk of optic atrophy are listed below.
* Regular Eye Tests: Ensuring regular eye tests can help with staying on top of vision health and ensuring early detection of any potential issues. It is typically advised to get an [eye test](https://www.oscarwylee.com.au/glasses/eye/test-glossary) every 1-2 years unless advised otherwise by an optometrist.
* Managing Underlying Health Conditions: Manage health conditions that may lead to this stage, such as glaucoma, inflammatory conditions and genetic eye conditions by addressing them with an eyecare professional.
* Maintaining a Healthy Lifestyle: Maintaining an overall healthy lifestyle that includes regular exercise, balanced and whole meals, maintaining optimal sleep hygiene and managing stress levels. While these do not necessarily prevent optic atrophy or even other eye conditions, they may help reduce other potentially contributing health factors.
Experience High Quality Eyecare Services From Our Team
Book an appointment online with an Oscar Wylee optometrist today.
[Book an eye test](https://www.oscarwylee.com.au/booking)
Major Health Funds Accepted In-store
For the purchase of frames and lenses, use your private health fund to limit how much you pay from your own pocket.
[Health Funds](https://www.oscarwylee.com.au/health-funds.html)