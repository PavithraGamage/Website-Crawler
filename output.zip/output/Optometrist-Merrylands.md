# Source: https://www.oscarwylee.com.au/locations/optometrist-merrylands.html

# Optometrist Merrylands
Shop 1083, Stockland Merrylands1 Pitt StreetMerrylands NSW 2160
* Opposite ANZ Bank
Opening hours
Monday9:00am - 5:30pm
Tuesday9:00am - 5:30pm
Wednesday9:00am - 5:30pm
Thursday9:00am - 7:00pm
Friday9:00am - 5:30pm
Saturday9:00am - 5:00pm
Sunday10:00am - 4:00pm
*Store hours reflect local standard trading hours and exclude public holidays
[Visit our Merrylands Google Business page for directions, reviews, and updates.](https://g.page/r/CVH02ntdkGXgEBM/)
Book Appointment
[Call us: (02) 8073 2326](tel:(02) 8073 2326)
[Leave a Review!](https://g.page/r/CVH02ntdkGXgEBM/review)
Our Reviews
Karthika Sellathurai
1 week ago
Hi There Osvsr Wyle team
I just wanted to say that your manager Michael at merrylands is the most ob...liging, patient &amp; courtious person. In the stockland's entire centre the best customer service I have ever received from an optomotrist. No one else have ever offered me a service like hom. I truly mean it. I wanted my sunnies hands to be tightened &amp; he's the only one who did it for me. And absolute kind service.  I wish him all the very best  in his carrier.
Thank you
Kat????
See more
Suzanne Reilly
6 months ago
Thank you to Amy for being so understanding and helpful with my order when I changed from ordering m...ultifocal glasses to two different pairs. She made the whole process easy and stress-free, and was far more helpful than the Parramatta store. I truly appreciated her patience and excellent customer service.
See more
Annie
7 months ago
I had an exceptional experience at Oscar Wylee Merrylands today.  Thanks to the incredible care prov...ided by the optometrist, Jason Dhana. His thoroughness during my eye examination was truly impressive — he took the time to check every detail, explain each step clearly, and ensure that my prescription was perfectly accurate. It’s rare to come across someone who goes above and beyond with such genuine patient care, but Dr. Jason absolutely did.
I also want to give a special mention to Geraldine, who provided wonderful assistance in helping me choose and finalise my prescription glasses. She was warm, attentive, and made the entire process smooth and enjoyable.
Overall, the service from both Dr. Jason and Geraldine was exceptional. I left feeling confident, well‑looked‑after, and extremely satisfied. Highly recommended.
See more
M Rehman
8 months ago
Didn't get the assistance name who served me today but I bought some glasses a couple of months back... and the side piece from the glasses kept falling out. Took it back in to see if they could repair them and she gave me a new pair no questions asked. Thank you for a hassle free experience
See more
Trel Alexandre
10 months ago
Went to Oscar Wylee Merrylands to pick up my specs &amp; the delightful LAMIA assisted me with patience ...in the new prescription specs fit. As I wear my specs a particular way she had to several times attempt refitting at the back of ear. Not even once did she whinge or roll her eyes but kept checking the fit &amp; adjusting. Just brilliant customer service &amp; satisfaction. Thank You Lamia ! ????☺️????
See more
Cengiz Gencer
11 months ago
I just wanted to congratulate Amy and Michael from your Merrylands NSW store for their amazing and t...op notch service when I attended on 9 September 2025. They are both a fantastic asset to your organisation and I would appreciate if you could pass this on to them. ????????
See more
Mario Desantis
11 months ago
I had the pleasure of being assisted by Geraldine at the Merrylands store, and I can’t thank her eno...ugh for the outstanding service she provided. She was professional, patient, and very understanding, especially with my fussy choices while selecting new glasses. It’s refreshing to see that amazing old-school customer service still exists — where you feel genuinely looked after rather than rushed. Thank you so much, Geraldine, for making the process easy and enjoyable.
See more
シ
1 year ago
Good
KRISHAN KUMAR
1 year ago
I had a fantastic experience with Geraldine at Merryland . From the moment I walked in, the she were... friendly, professional, and made me feel completely at ease. The clinic is clean, modern, and well-organized.
Geraldine  was incredibly thorough and patient during my eye examination. They took the time to explain every part of the process and answered all of my questions with care and clarity. I never felt rushed, and I appreciated their attention to detail and genuine concern for my eye health.
I was also impressed with the wide selection of frames and how helpful the team was in helping me choose the perfect pair of glasses.
Overall, I highly recommend Geraldine to anyone looking for professional, friendly, and high-quality eye care. I’ll definitely be coming back for my future checkups!
See more
mariam hannoun
1 year ago
I was here last night and Anne was such great help. She was very patient in helping me pick out new ...frames and offered me a variety of different options. She gave her honest opinion on how well they suited me which was amazing. She even cleaned my current glasses while i was trying some on without me asking! Safe to say that she went above and beyond in her customer service &lt;3
See more
Marina Semaan
1 year ago
I just wanted to take a moment to share my appreciation for the outstanding service I received recen...tly &amp; these past few weeks/months
While visiting Oscar Wylee Merrylands for new glasses, I was assisted by a staff member Sera whose kindness, professionalism, and attention to detail truly made the experience exceptional.
Sera's genuine care and willingness to go above and beyond left a lasting impression on me.
Thank You for supporting such high standards — and for making everyday moments like this feel so special.
See more
Britt Rolfe
1 year ago
ANDREWS ODOI OTCHERE
1 year ago
I had a great experience with Oscar Wylee in Merrylands. Friendly staff greeted me as soon as I walk...ed in, making me feel welcome right away. They took the time to understand my needs and helped me find the perfect pair of glasses. The store was well organized, and I appreciated the wide selection of stylish frames available. Overall, it was a pleasant shopping experience that I would highly recommend to others.
See more
98maddyrose
1 year ago
I’ve been coming to this Oscar Wylee in merrylands stocklands for the past few years now, every time... I come to get a new pair I always get the best service from the staff! Geroldine served me and was very sweet very knowledgeable for only being a new staff member! Sera was great at her job and was running between serving other costumers and helping out Geroldine with my purchases as well! 10/10 lovely ladies and a great overall experience! Will be coming back for my next pair for sure!
See more
Bob Dankworth
1 year ago
Wonderfully staff member at Merrylands today very helpful fixed my glasses for free thank you
You no...w have all my eye care
Business  cheers
See more
Cally Coomber
1 year ago
Great place! Love my new glasses
Alexis H
1 year ago
Great service and products but Merrylands is always closed? We’ve come here so many times and checke...d on Google that it’s open but it is just always closed. It’s 11:14am on a Wednesday. This is honestly the 4th or 5th time it’s happened - no sign or anything to say when they’ll be back if they have stepped out.
See more
Vallery Cheruto
1 year ago
Francesco Farina
1 year ago
Amazing customer service with Sera
Michael o'brien
1 year ago
I found Nidhi to be very helpful! Great customer service.
Katherine Battah
1 year ago
Highly recommend. Sera was a great help with fixing my glasses. Quick and a great job. My husband bo...ught glasses here previously and he loves them.
See more
김현진
1 year ago
The lady is so so so kind and skilled! I will visit again next time.
Navil Navil
1 year ago
Mariam was so great. She swapped my lenses into a new frame of the same model. She was very patient ...and kind.
See more
Bahaaldin Bhadli
1 year ago
Highly recommend Oscar Wylee Merrylands. Nidui is very professional, she was very friendly and nice ...person. Great customer service.
See more
alexgringo5000
1 year ago
Sera was lovely and very helpfull.
Merrylands store is my new place
Dorothy Kones
1 year ago
I had a very good experience today, customer service from Mai was amazing, smooth and very friendly.... Would definitely recommend Oscar Wylee.
See more
Cristina Cunanan
1 year ago
Happy with the service I received from Merrylands branch. Mai was attentive and friendly. Thank you
Mohammad Subay
1 year ago
Mia Rebeiro
1 year ago
Mai in Merrylands Store was very helpful and extremely accommodating as my daughter had loose glasse...s. She helped fix these and also cleaned them.
See more
Shirley-Anne Norford (Shirlz)
1 year ago
Always very helpful and the warranty service is 1 class. Thank you OW Merrylands
Jamie n
1 year ago
Mai and Michael were very helpful and gave a lot of good info
Vicki Hack
1 year ago
Joanna Lo
1 year ago
Helpful and friendly staff every time I visit. A shout out to Mai who has been very helpful with my ...glasses with loose nose parts, they’ve been replaced without any charge.
See more
Pauline Melki
1 year ago
MAI is the best. She's so lovely and professional. She's such great help. I highly recommend seeing ...her for all your glasses needs!
See more
Bella
1 year ago
I recently went to Oscar Wylee to get my eyes checked and purchase new glasses. Even though I was qu...ite early to my appointment, Mai and Heidi were very accomodating, and welcomed me to try on frames whilst I waited. Mai and Heidi were so lovely, smiles never left their face.
Michael, the optometrist, was extremely insightful and was honest with his approach.
This also was not a once off experience, as I had a family member attend that very day and had a very pleasant experience similar to myself.
I have recommended this particular store to all my friends and family.
See more
Brittany Miller
1 year ago
Mia was amazing! Absolutely lovely and approachable. She helped me fix me old glasses like new and h...elped me pick new glasses
See more
Gareth D
1 year ago
Awesome  place to get eyes checked and glasses, prices are reasonable and good friendly customer ser...vice from Mai,
See more
brian&amp;fiona dickson
1 year ago
I recently had my eyes tested at your Merrylands shop and I now have 3 pairs of new glasses. I am ex...ceedingly happy with the care and attention I recieved from Michael during my test and Mia and Zahrau made  choosing the new glasses a really fun experience.The glasses arrived very promptly, which is also important to me. So heart felt thanks to everyone involved.
Fiona Dickson
See more
Amy Kay
1 year ago
Pleasant experience in store. My eyes were checked smoothly &amp; then Mai was lovely, patient &amp; kind in... assisting me in finding glasses with honesty on what suited me best which is exactly what I needed! Thank you for the amazing experience
See more
Nicolas Fajloun
1 year ago
Very knowledgeable optometrist Michael and super helpful team working the floor ????
Jinxin Yu
1 year ago
Good customer service. Thanks to Mai and Michael for assisting me.
K WAY
1 year ago
Visited Merrylands Oscar Wylee and had a great support from Mai
Paras Nagrath
1 year ago
Great customer service ???? and very friendly staff
Cigdem Dolcel
1 year ago
I really appreciate the care and  attention to detail May showed through out the process of repairin...g the handle of my glasses. She was professional and handled everything with such precision. Thank you :)
See more
Amy Hibbard
1 year ago
I just went in for a simple tightening of my glasses and the service was impeccable
So many complim...ents and such great service by May thank you so much for making my day
See more
Seini Fifita
1 year ago
Excellent customer service
Santo Mekonen
1 year ago
Thank you may she was really helpful and make it easy for me to understand thank you
Mai Lam
1 year ago
Excellent customer service from staff name Mai
A S
1 year ago
I made an eye exam appointment and was greeted by May who was so friendly and explained everything t...o me. Exceptional customer service too. The optometric Michael was great, I explained my vision concerns and after some tests he explained what the issue was and is very knowledgeable.  May then helped me choose a stylish pair of frames. Awesome team at Merrylands.
See more
Dean Lewis
1 year ago
My wife went in the store a few days ago and wanted me to let you know that the lady who served her ...by the name Heidi, was absolutely wonderful. She assisted her with all her needs and her customer service was exceptional. My wife came home telling me all about it. Lovely young lady with such beautiful mannerisms. Shoutout to Heidi! :)
See more
## Find an Optometrist in Merrylands With Oscar Wylee
Come in and see the team at Oscar Wylee Merrylands, a suburb in Western Sydney located near areas including Holroyd and Granville. Our skilled optometrists perform Medicare, bulk billed eye tests, so you can have your eye health and vision checked and update your prescription. Our friendly retail staff will also help you find your new favourite pair of glasses–all on the same day! 
Our Oscar Wylee store is located in Merrylands Shopping Centre which offers a wide variety of stores, delicious food and exciting events. Travelling to the centre is easy with the Merrylands train station only a five-minute walk away and 2,965 parking spaces available on-site. Plus, there are three locations for bike racks. Plan your trip today to our Oscar Wylee Merrylands store and browse our range of stylish and on-trend frames. These include prescription glasses and prescription sunglasses. Our team at Oscar Wylee Merrylands are qualified in diagnosing eye diseases, so you can expect all essential services at our eyeglasses shop.        
Meet Our Team
* Optometrist
Master of Clinical Optometry
Bachelor of Vision Science
* Store Manager
Our Services
* Bulk Billed Eye Examinations
* Professional Frame Styling
* Frame Adjustments and Repairs
Show All
## Find an Optometrist in Merrylands, Sydney for an Eye Health Test
An optometrist in Merrylands, Sydney can provide residents with prescription sunglasses or non-prescription sunglasses and more. If you need an eye health test in Merrylands, our staff are highly trained and dedicated to conducting excellent services. Our optical dispenser in-store is available to help ensure your glasses fit suitably according to your facial features. If your condition is more serious, you will be referred to an eye doctor, also known as an ophthalmologist here in Australia.
We strongly recommend getting regular eye tests for your vision and making sure there are no symptoms of eye diseases, which you can receive at a bulk billed price if you are registered on Australia’s Medicare System. The average price for an optometrist in Merrylands may depend on factors such as the number of optometrists in the same area, the cost of facilities and equipment and your eye health condition.
## How to Find an Optometrist in Merrylands, Sydney?
To find an optometrist in Merrylands, Sydney, you can take certain steps that can help make it easier for you such as searching online, assessing the store’s opening hours and finding the directions to your chosen location. The steps on how to find an optometrist in Merrylands are listed below.
1. Search online using the phrase, Merrylands optometrist near me. This can also be done here on the website via our locations page.
2. Click on the Oscar Wylee link, which will take you directly to our Merrylands optometrist store page.
3. See the store’s opening hours and where the store is located specifically.
4. Use the Merrylands Google Business page link located under store hours to see the directions on how to get to the store.
You can also find an optometrist in Merrylands by searching the keywords optometrist near me. If you have locations enabled on your smartphone and you’re in the Merrylands area, our Merrylands store page should appear easily for you to click on.
### Is it Hard to Get an Eye Appointment in Merrylands Sydney?
No, it is not hard to get an eye appointment in Merrylands. You can easily book an appointment to see an Oscar Wylee optometrist in Merrylands right here on this page. At Oscar Wylee we have highly qualified optometrists available for bulk billed eye appointments, which can be booked online or in-store.
#### How to Compare Optometrists in Merrylands to Each Other?
To compare optometrists in Merrylands, you can use factors such as eye tests offered, health fund coverage, lens types and add-ons and eyewear offered. To take care of your vision and eye health, it is important to receive an eye test at least once every two years. There are different types of tests that can be performed in an eye test and not all optometrists may offer the same tests. Health funds can be used to help cover some of the cost of your frames and lenses. To find out if your health fund is accepted at Merrylands optometrist in Sydney, visit their website. In the case of Oscar Wylee, we accept all major health funds and provide on-the-spot claims in-store. There are many different lens options available for prescription glasses such as single vision, multifocal and high index lenses. Most optometrists in Merrylands will offer these lenses although it is good to make sure. There are also lens add-ons available to enhance your glasses such as anti-reflective and blue light filters. Finally, if you are looking to purchase a pair of glasses after your eye test, you can compare the different styles and colours you are interested in from Merrylands optometrists in Sydney. Oscar Wylee offers a wide range of frames with vintage and modern inspirations in bold colours and subtle designs.
#### How to Find an Eyeglasses Shop in Merrylands Sydney?
To find a glasses store in Merrylands, you can try to follow these simple steps including searching online, selecting a convenient location and looking at their health insurance policies. The steps on how to find a glasses store in Merrylands Sydney are listed below.
1. Search online using the phrase, glasses store in Merrylands. This will provide you with various options for glasses stores in the whole Merrylands, Sydney area.
2. Select a glasses store that is most convenient for you to travel to.
3. Click the link to find out more information such as opening hours, exact location and directions to the glasses store in Merrylands.
4. Read their health insurance policies to ensure you know what health benefits you have access to.
Our Oscar Wylee glasses store in Merrylands, Sydney offers primary eye care services such as comprehensive eye tests as well as other services performed by an optometrist and offers prescription and non-prescription eyewear.
##### Is it Possible to Purchase Prescribed Sunglasses in Merrylands, Sydney Without Seeing an Optometrist?
Yes and no, it is possible to [purchase prescribed sunglasses](https://www.oscarwylee.com.au/sunglasses.html) in Merrylands, Sydney without seeing an optometrist if you already have a prescription that has not expired. If your prescription is expired, you can book an eye test to receive an updated or new prescription which will require you to see an optometrist. This will ensure your prescription sunglasses are appropriate for your visual needs.
## Where is the Oscar Wylee Merrylands Optometrist in Sydney Located?
The Oscar Wylee Merrylands optometrist is located at the Stockland Merrylands Shopping Centre. You can visit the Stockland Merrylands shopping centre at 1 Pitt Street, Merrylands.
### What is the Phone Number of Oscar Wylee Chatswood Chase Optometrist Store?
The Oscar Wylee Chatswood Chase optometrist store phone number is [(02) 8073 2326](tel:(02) 8073 2326). You can contact the Oscar Wylee Chatswood Chase store between the opening hours of 9 am and 5:30 pm on Monday, Tuesday, Wednesday and Friday, on Thursday between 9 am and 9 pm, on Saturday between 9 am and 5 pm and on Sunday between 10 am and 4 pm.
### What are the Reviews for Oscar Wylee Merrylands Optometrist in Sydney?
The reviews for Oscar Wylee Merrylands optometrist in Sydney, left by our various customers can be found here on the website as well online when you search for Oscar Wylee Merrylands optometrist. The reviews for Oscar Wylee Merrylands optometrist are listed below.
* Sally -  Very professional and excellent service. Thank you Michael, the optometrist for always looking after me!
* Timothy Nguyen -  I saw Michael the optometrist here on Friday. He was very professional as well as knowledgeable and helped fix my vision issues. He further helped me pick stylish frames that made me look more handsome. I would highly recommend seeing him and I can't wait to come back to see him again.
#### What Treatments or Eye Care Processes are Done in the Oscar Wylee Merrylands Optometrist Location?
The treatments or eye care processes done in the Oscar Wylee Merrylands optometrist Sydney location include a tonometry test, a slit lamp exam and a refraction test. Additional tests that may also be performed can include a dilated fundus exam. The treatments or eye-care processes that are done in the Oscar Wylee Merrylands optometrist Sydney location are listed below.
* A Tonometry Test: An optometrist or optical dispenser will conduct a tonometry test which involves the use of a machine that will release small puffs of air into your eyes. This will assist with measuring pressure in the eye.
* Slit Lamp Test: A slit lamp test can be used to evaluate your eye health, by examining your cornea and iris which are the anterior and posterior of the eye.
* Refraction Test: During a refraction test, an optometrist will have you view an image through different lenses and ask you to confirm which helps you see the image clearer.
* Dilated Fundus Exam: A dilated fundus exam can help an optometrist assess your health in more detail by getting a clear view of the retina. This test is typically carried out for patients with diabetes and those who may be at risk of developing retinal damage.
## How Many Optometrists Exist in Merrylands?
Many optometrists exist in Merrylands, Sydney that provide eye tests and glasses, including Oscar Wylee. The reason for the current number of optometrists in Merrylands may depend on the total population in the area, the demand for optometry services and the geographical size of the suburb. Oscar Wylee Merrylands can be your go-to if you’re a Merrylands resident to receive eye health services carried out by our friendly and committed team.
### What are the Other Closest Optometrist Locations to Merrylands, Sydney Australia?
The other closest Oscar Wylee optometrist locations to Merrylands in Australia are Parramatta, Winston Hills, Rhodes, and Bankstown. The other closest optometrist locations to Merrylands are listed below.
* Parramatta:  Parramatta is close to Merrylands with just 3 km in distance between stores and can be found on level 3 on Church Street. The [Oscar Wylee Parramatta](https://www.oscarwylee.com.au/locations/optometrist-parramatta.html) store offers bulk billed eye tests and a wide selection of vintage-inspired frames.
* Winston Hills:  Winston Hills is close to Merrylands with about 10 km in between stores and can be found on Caroline Chisholm Drive. You can visit the [Oscar Wylee Winston Hills](https://www.oscarwylee.com.au/locations/optometrist-winston-hills.html) store when you next shop at the Winston Hills Mall. Here you will find essential eye care services to help you prioritise your eye health.
* Rhodes:  Rhodes is close to Merrylands store, around 13 km in distance and is located at the Rhodes Waterside Shopping Centre at 1 Rider Blvd. The [Oscar Wylee Rhodes](https://www.oscarwylee.com.au/locations/optometrist-rhodes.html) store is perfect for browsing for your next pair of stylish frames. Our team can assist you with selecting the right frame that fits your face according to your face shape.
* Bankstown:  Bankstown is close to Merrylands with 16-19 km in between stores and is located on level 2 of the Bankstown Central Shopping Centre. When you visit the [Oscar Wylee Bankstown](https://www.oscarwylee.com.au/locations/optometrist-bankstown.html) store, you can expect our team to carry out excellent eye tests as they will take the time to explain all processes involved and ensure you feel comfortable and informed.
### Oscar Wylee Offers Eye Tests in Merrylands
Make your next stop at our Oscar Wylee Merrylands store and you’ll be able to receive your yearly eye test. If you have a valid Medicare card you can have your eye tests bulk billed. During the process of an eye test, an optometrist will assess your vision, check your eye health and if necessary, a prescription will be issued. You will be able to browse through our wide selection of frames for your new pair of glasses.
### Major Health Funds Accepted at Oscar Wylee
Leading health funds are accepted at our Oscar Wylee Merrylands store. We have you covered for either new frames or an eye health test. If you have an eligible health fund card our team will be happy to process your claim. Our Merryland optometrist and team will strive to help you with any health fund enquiries you may have and will walk you through the process. Oscar Wylee Merrylands will prioritise helping you get your prescription sunglasses and glasses for an optimal and competitive price.
### Fashionable Glasses Available at Affordable Prices
Oscar Wylee Merrylands have got a style of glasses perfect for you. Our wide range of vintage and modern style frames are inspired by Australia’s coastal landscape. We can meet your needs with our customised prescription lenses which include multifocal lenses and a blue light filter among the many different available options we have to offer. Come to our eyeglasses shop to get fitted for frames with our Oscar Wylee Merrylands staff and they will be happy to assist you during the process.
Book Appointment
[Call us: (02) 8073 2326](tel:(02) 8073 2326)
[Leave a Review!](https://g.page/r/CVH02ntdkGXgEBM/review)