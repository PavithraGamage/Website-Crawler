# Source: https://www.oscarwylee.com.au/myopia-control-lenses

Introducing
# Myopia Control Lenses
Help protect your child’s vision for the future with Essilor® Stellest® Myopia Control Lenses. Stellest® lenses are clinically proven to slow down myopia progression by 67% on average when worn full-time (at least 12 hours a day)¹, compared to standard single-vision lenses, helping to manage worsening eyesight in children.
[Book A Kid’s Eye Test](https://www.oscarwylee.com.au/booking)
## What is Myopia Control?
[Myopia](https://www.oscarwylee.com.au/glasses/eye/nearsightedness), or nearsightedness, is a vision condition in which you can see clearly up close, but distant objects appear blurry. Myopia occurs due to an elongated eyeball or an overly curved cornea, causing the eye to focus and bend light onto the retina incorrectly. Signs of myopia in children include squinting, standing very close to see, and eye rubbing.
Standard glasses and contact lenses only correct blurry distance vision, but do not slow the eye's growth. Myopia control slows the progression of nearsightedness in children and teenagers, with specialised lenses that alter how light hits the retina, signalling the eye to stop growing so fast.
Slows vision worsening
Protects future eye health
Keeps prescriptions lower
[Learn More](https://www.oscarwylee.com.au/glasses/eye/myopia-control-in-children)
## A Message for Parents:Why Act Now?
As parents, we constantly look out for our children's future, but it's easy to overlook how rapidly their eyes are changing. Myopia typically develops and worsens quickly between the ages of 7 and 12, during crucial school years.
Choosing Essilor® Stellest® lenses is more than just giving your child a clearer view of the whiteboard; it’s a proactive choice for their adult life. By slowing down the elongation of their eyes now, you are reducing their reliance on heavy prescriptions later and lowering their lifelong risk of serious vision complications. Early intervention is the best gift for your child's long-term eye health.
[Find Your Nearest Store](https://www.oscarwylee.com.au/locations)
## Why Myopia Control Matters
[Myopia control](https://www.oscarwylee.com.au/glasses/eye/myopia-control-in-children) is important because it improves your child's vision, quality of life, and risk of developing eye health problems.
#### Short-term benefits
Myopia control is designed to help children and teenagers experience fewer changes to their prescription, aiding in stable vision and less visual disruptions.
#### Long-term benefits
Studies indicate that any degree of nearsightedness (myopia) elevates the lifelong risk of developing serious eye conditions, including cataracts, retinal detachment, and macular degeneration. Even mild myopia carries higher risks than perfect vision², while more severe nearsightedness significantly increases the likelihood of permanent vision impairment over a person's lifetime³.
## How Stellest® Lenses Work
The Essilor® Stellest® lens is a next-generation treatment designed to slow down myopia (nearsightedness) progression in children. It uses cutting-edge H.A.L.T. technology (Highly Aspherical Lenslet Target) to create a dual-action design that corrects vision while actively managing eye growth.
### 1. Clear Correction + Growth Control
Essilor® Stellest® lenses utilise cutting-edge H.A.L.T. (Highly Aspherical Lenslet Target) technology to manage myopia progression.
#### The Correction Zone
The central zone of the lens provides clear distance vision, focusing light exactly on the retina, just like a standard lens.
#### The Control Zone
A constellation of 1,021 invisible aspherical lenslets creates a volume of non-focused light in front of the retina. This creates a visual signal that slows down the elongation of the eyeball.
### 2. Signals the Eye to Slow Down
Instead of using a traditional 'add' power, the H.A.L.T. lenslets create a 3D shield of non-focused light called a Volume of Myopic Defocus (VoMD). This volume of light sits right in front of the retina, acting similarly to a biological stop sign that signals the child's eye to slow elongation.
### 3. Clear Vision, Minimal Adaptation
Extensive research shows that this advanced design has virtually no impact on a child's day-to-day visual function.
#### The Golden Rule: Wearing Time Matters
The technology works best when it is consistently in front of the eye. Children who wear their Stellest® lenses full-time (at least 12 hours a day, 7 days a week) experience up to a 60% reduction in eye growth and a 67% reduction in myopia progression compared to standard glasses¹.
## Myopia Control Lens Options
At Oscar Wylee, we make it straightforward and affordable to access premium Essilor® Stellest® technology. Choose the option that best fits your child's lifestyle:
Stellest® Lenses inc. Anti-Reflective
Reducing glare from school screens and devices
(Price includes lenses only. Frame selection sold
separately) 
$550
Stellest® Lenses inc. Anti-Reflective + Tint
Advanced outdoor protection with UV block and glare reduction
(Price includes lenses only. Frame selection sold
separately) 
$580
Price includes lenses only, per pair. Frame selection sold separately.
## Protect your child'svision for the future
[Find Your Nearest Store](https://www.oscarwylee.com.au/locations)
## Popular Kid's Frames
#### Stanislas
[Shop Stanislas](https://www.oscarwylee.com.au/stanislas-optical.html)
#### Lucien
[Shop Lucien](https://www.oscarwylee.com.au/lucien-optical.html)
#### Jorja
[Shop Jorja](https://www.oscarwylee.com.au/jorja-optical.html)
Show All
### Can Myopia Control reverse my child's nearsightedness?
No, myopia control cannot reverse or cure existing nearsightedness. However, it is highly effective at slowing down the progression of the condition while your child's eyes are still developing.
### At what age should my child start Myopia management treatment?
Myopia management treatment, such as Essilor® Stellest® lenses, is recommended as soon as your child is diagnosed with short-sightedness or shows signs of pre-myopia. Myopia control lenses are primarily used for children and teenagers between the ages of 6 and 18, with the absolute sweet spot being ages 6 to 12.
### Are Myopia control lenses safe for young children?
Yes, Essilor® Stellest® lenses have a safety profile comparable to standard single-vision glasses. Your optometrist will evaluate if they are suitable for your child's specific eye health and lifestyle.
### How much do Myopia lenses cost?
At Oscar Wylee, we have two simple lens options to suit your child's lifestyle needs.
* Stellest® Lenses inc. Anti-Reflective Coating: $550
* Stellest® Lenses inc. Anti-Reflective Coating + Tint: $580
Please visit us in-store to speak with our team for more information, and find the perfect fit for your child.
Clinical references
1. Bao J, Huang Y, Li X, Yang A, Zhou F, Wu J, Wang C, Li Y, Lim EW, Spiegel DP, Drobe B, Chen, H. Spectacle lenses with aspherical lenslets for myopia control vs single-vision spectacle lenses: a randomized clinical trial. JAMA ophthalmology. 2022;140(5):472-8. doi:10.1001/jamaophthalmol.2022.0401.
2. Flitcroft DI. The complex interactions of retinal, optical and environmental factors in myopia aetiology. Prog Retin Eye Res. Nov 2012;31(6):622-60.
3. Tideman JWL, Snabel MC, Tedja MS, et al. Association of Axial Length With Risk of Uncorrectable Visual Impairment for Europeans With Myopia. JAMA Ophthalmol. Dec 2016;134(12):1355-1363.
Disclaimer: An eye test is required to determine suitability for myopia control lenses. Individual clinical outcomes may vary.
Essilor Stellest Warranty: Get one complimentary pair of replacement lenses per calendar year if your Oscar Wylee optometrist confirms a prescription change of 0.50 diopters or more (must be fitted into your original frame; new frames incur additional costs).