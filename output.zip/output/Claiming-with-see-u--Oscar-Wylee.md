# Source: https://www.oscarwylee.com.au/health-funds/see-u.html

# see-u at Oscar Wylee
As a member of see-u (formally known as CUA Health), you can claim on optical extras using your health fund’s coverage for optical services, such as prescription frames, lenses or glasses. see-u benefits reset every calendar year, claim your glasses before time runs out! At the end of the year, any extras you don’t use will be lost. With Oscar Wylee, you can have up to 100% coverage on select optical purchases when you shop with us. Look at the table below to see your see-u policy name and the amount of coverage that policy gives when you shop at Oscar Wylee. Your coverage might change or not apply to extras such as add-ons, coatings or tinting.
## Have your eyes tested!
Oscar Wylee offers bulk billed eye tests to all valid Medicare cardholders, come get your sight tested today!
[Book an eye test](https://www.oscarwylee.com.au/booking)
#### Waiting Period
6 Months
#### Benefit Limits Reset
1st of January
#### Claimable Optical Extras %
100%
To learn whether your plan includes single vision lenses, bifocal lenses and/or multifocal lenses, talk to your health insurance provider.
| Your Extras Package Annual Limit:* | Simple 60 | Simple 50 | Starter Extras | SINGLES COVER | 1 Standard OW Pair from $169^ | 2 Standard OW Pairs from $199^ | 3 Standard OW Pairs from $249^ |
| --- | --- | --- | --- | --- | --- | --- | --- |
| $200 | $160 | $150 |
| Covered | Partial Cover | Partial Cover |
| Covered | Partial Cover | Partial Cover |
| Partial Cover | Partial Cover | Partial Cover |
^Excludes add-ons. Standard frames and lenses only. Oscar Wylee's standard product inclusions are calculated based on the optical allowances under each health fund package and may vary. If unsure, please confirm with your provider. Our two pair and three pair deals are only available per person and cannot be split between two people. Only one prescription can be used per offer. If you have a distance and a reading prescription, this is included in the offer as this is considered to be one prescription. Any prescriptions must have the full name of the person claiming and a valid expiry date to be able to order. If you have two different prescribed prescriptions, you will need to visit a store to be eligible for our two pair and three pair deals.
| FAMILY COVER | 1 Standard OW Pair from $169^ | 2 Standard OW Pairs from $199^ | 3 Standard OW Pairs from $249^ |
| --- | --- | --- | --- |
| $400 per policy1 | $320 per policy1 | $300 per policy1 |
| Covered2 | Partial Cover3 | Partial Cover3 |
| Covered2 | Partial Cover3 | Partial Cover3 |
| Partial Cover3 | Partial Cover3 | Partial Cover3 |
^Excludes add-ons. Standard frames and lenses only. Oscar Wylee’s standard product inclusions are calculated based on the optical allowances under each health fund package and may vary. If unsure, please confirm with your provider. Our two pair and three pair deals are only available per person and cannot be split between two people. Only one prescription can be used per offer. If you have a distance and a reading prescription, this is included in the offer as this is considered to be one prescription. Any prescriptions must have the full name of the person claiming and a valid expiry date to be able to order. If you have two different prescribed prescriptions, you will need to visit a store to be eligible for our two pair and three pair deals.
## Worried about your sight?
Taking care of your eyes can be done in only 30 minutes with Oscar Wylee.
[Book&nbsp;today](https://www.oscarwylee.com.au/booking)
*Based on see-u [Cover Guide](https://www.seeuhealthinsurance.com.au/extras/) and product factsheets as presented to the Commonwealth Ombudsman: [1](https://www.privatehealth.gov.au/dynamic/Download/CPS/I15/SCHM10) [2](https://www.privatehealth.gov.au/dynamic/Download/cps/I14/DCEY20) [3](https://www.privatehealth.gov.au/dynamic/Download/CPS/I13/NCDO1D)1 For family cover, per policy means the shared maximum limit between family members that can be claimed within a calendar year. Coverage or partial coverage for our 1,2,3 pair deals is dependent on the per person limit within the annual per policy limit under each extras plan. 2 Full coverage for this deal may only apply to up to two people within a family or a couple based on the per person limit within the per policy limit under each extras plan. More than two family members wanting to purchase glasses may only receive partial coverage. 3 Partial coverage for this deal is calculated based on the per person limit within the overall per policy limit under each extras plan. Information relevant as of August 2026.
## Your eye test explained
Routine eye test appointments are quick and painless. Find out what to expect during an eye exam and how to understand your eye test results.
[Find out more](https://www.oscarwylee.com.au/eye-health/your-eye-test-explained.html)
## Bulk Billing
Find out what bulk billing is and whether you're eligible to receive an eye test free of charge.
[Find out more](https://www.oscarwylee.com.au/eye-health/eye-test-info/bulk-billing.html)
## What is Pupillary Distance? (PD)
Do you know your PD? It's something you'll need to know when ordering glasses online. Find out what Pupillary Distance is and how you can measure your own.
[Read more](https://www.oscarwylee.com.au/eye-care/eye-test/what-is-pupillary-distance.html)
## Book an eye test
Oscar Wylee eye tests are bulk billed through Medicare. This means there will be no out-of-pocket expense for eligible Medicare cardholders.
[Book online](https://www.oscarwylee.com.au/booking/)
## Find a store near you
Contact or visit your nearest store for a full quote.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)