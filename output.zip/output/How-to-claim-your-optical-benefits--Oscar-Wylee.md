# Source: https://www.oscarwylee.com.au/health-funds/how-to-claim-optical-benefits.html

# How to claim benefits
## How do I claim for my glasses?
We make getting new glasses easy by helping you access your rebate on the spot in-store with most health insurers. All you need to do is simply visit one of our stores and our team members will assist you. If you have an eye test with us, we’ll have your prescription on file so all you need to remember is to bring your health fund card to make claiming simple and easy.
## How do I claim for online orders?
After purchasing on our [website](https://www.oscarwylee.com.au/glasses.html), an invoice will be emailed to you with all the information you need to make a claim - including our provider number, item codes, and costs. To claim your rebate, simply send through our invoice with the relevant claim form from your health insurer. Some health funds have an online claim service to make it even easier to claim, so be sure to check with your health insurer.
## Need an up-to-date prescription?
[Eye test near me](https://www.oscarwylee.com.au/booking)
[](https://www.oscarwylee.com.au/health-funds/optical-extras.html)
###### What are optical extras?
Find out about your optical extras and whether there are any out of pocket expenses with your health fund.
[Find out more](https://www.oscarwylee.com.au/health-funds/optical-extras.html)
[](https://www.oscarwylee.com.au/health-funds/what-you-can-claim-with-optical-extras.html)
###### What can be claimed with optical extras?
Find out what you're able to claim with your optical extras.
[Find out more](https://www.oscarwylee.com.au/health-funds/what-you-can-claim-with-optical-extras.html)
[](https://www.oscarwylee.com.au/health-funds.html)
###### Health funds
At Oscar Wylee, we accept all health funds and we offer on the spot quotes and claims for extras cover across all of our retail stores.
[Find out more](https://www.oscarwylee.com.au/health-funds.html)
[](https://www.oscarwylee.com.au/booking/)
###### Book an eye test
Oscar Wylee eye tests are bulk billed through Medicare. This means eligible Medicare card holders get a free eye test.
[Book online](https://www.oscarwylee.com.au/booking/)