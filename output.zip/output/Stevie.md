# Source: https://www.oscarwylee.com.au/stevie-sunglasses.html

# Stevie
1
## Frame Design of Stevie Sunglasses
The frame design of Oscar Wylee’s Stevie sunglasses is characterised by a classic rectangle&nbsp; shape, high nose bridge, and an acetate frame. Stevie glasses are a women's statement frame that will work for any occasion, whether the wearer wants to liven up their work style or complement an outfit for a night out.
$169    
In stock
Only %1 left
2 pairs from $199
Discount auto-applied at checkout
3 pairs from $249
Discount auto-applied at checkout
* 2 &amp; 3 Pair pricing applies to non-prescription sunglasses only. Prescription sunglasses incur additional charges.    
[Non-Prescription](https://www.oscarwylee.com.au/stevie-sunglasses.html#)
Qty
Prescription
Book an eye test
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
excluding prescription lenses
## About Stevie Frames
Take your style to the next level with this seasons must have rectangular frame! Stevie is ultra-cool, with a glossy acetate finish that is truly iconic.
| Frame fit | Measurements |
| --- | --- |
| Medium | 52 - 23 - 148 |
These measurements mean lens width, bridge, and temple length in millimetres (mm). They can be found on the inside of the temple arm. If you already have a pair that you like, you can compare it to these measurements.
### Made from Acetate
Oscar Wylee’s Stevie frame is a women's rectangle sunglasses frame that is perfect for those with round and oval face shapes. The Stevie frame is a sleek, widely wearable frame that can be worn every day. The main specs of Oscar Wylee’s Stevie glasses frame including dimensions, shape, materials, lenses, nose fit and hinges are listed below.
Filter category 3 - General purpose sunglasses. High protection against sunglare. Good UV Protection.Not suitable for driving in twilight, at night or under dull conditions
This frame comes with polarised lenses. An additional $100 will be added to your order total for prescription orders.&lt;/em &gt;&lt;/b &gt; 
| Stevie Frame Features | Stevie Frame Description | Dimensions | Shape | Materials | Lenses | Nose Fit | Hinges |
| --- | --- | --- | --- | --- | --- | --- | --- |
| The dimensions of the Stevie frame are measured in millimetres (mm) and are 52 - 23 - 148, meaning the lens width is 52 mm, the bridge is 23 mm and the temple length is 148 mm. |
| The Stevie frame is a rectangle shape, well suited to medium faces. |
| Stevie glasses are made from acetate. |
| The lenses that can be used in the Stevie frame are sunglass lenses, which provide UV protection. Prescription lenses are also available for the Stevie sunglass frame, however this is only available for in-store purchases. |
| The nose fit of the Stevie frame is a high nose bridge fit. |
| The hinges in Stevie glasses are normal hinges, also known as standard or barrel hinges. |
Show All
### What Inspired the Frame Design of Oscar Wylee’s Stevie Glasses?
The Oscar Wylee Stevie frame design was inspired by current fashion trends as rectangle shapes are often in fashion. A rectangle glass shape is timeless meaning it remains popular throughout the decades while other trends pass.
## What to Know About Oscar Wylee’s Stevie Glasses?
There are many aspects of the Oscar Wylee Stevie frames that customers should know about, so they can decide whether this is the right frame for them. The Stevie frame is a women's rectangle shaped frame. Oscar Wylee’s Stevie frame is suitable for many face shapes but particularly compatible with round and oval face shapes. The Stevie frame’s simple design means that they are fashionable all year round. Stevie glasses feature the standard [parts of glasses](https://www.oscarwylee.com.au/glasses/eye/part-of-glasses) such as a rim, temples, lenses, hinges and a high nose bridge.
### What are the Types of Temple Tips or Earpieces Included with Oscar Wylee’s Stevie Glasses?
The type of temple tips or earpieces included in Oscar Wylee’s Stevie Glasses are made from acetate.
### What Type of Nose Bridge do Oscar Wylee’s Stevie Glasses Have?
The type of nose bridge included in Oscar Wylee’s Stevie is a high nose bridge fit.
### What Type of Nose Pads are Included with Oscar Wylee’s Stevie Glasses?
Oscar Wylee’s Stevie frame does not include adjustable silicone nose pads.
### What Type of Lenses do Oscar Wylee’s Stevie Glasses Have?
The lenses that can be used in the Stevie frame are sunglass lenses, which provide UV protection. UV protection lenses block harmful ultraviolet rays, safeguarding eyes from damage. The Stevie Frame in Obsidian Black comes in Filter Category 3. These are general purpose sunglasses. High protection against sunglare. Good UV Protection. Not suitable for driving in twilight, at night or under dull conditions. Prescription lenses are also available for the Stevie sunglass frame, in-store only.
### What Material is Used for the Rim of Oscar Wylee’s Stevie Glasses?
The material used for the rim of Oscar Wylee’s Stevie glasses frames is acetate. The rim refers to the part of a glasses frame that holds the lenses.
### What Type of Hinges are Included with Oscar Wylee’s Stevie Glasses?
The type of hinges included with Oscar Wylee’s Stevie frames are normal hinges. These provide strength and smooth movement connecting the frame’s arms and lenses.
## What Face Types are Most Suitable for Oscar Wylee’s Stevie Glasses?
The face types that are most suitable for Oscar Wylee’s Stevie frame are round and oval face shapes. The Stevie frame is a rectangle shape, meaning that it complements the structure of round and oval faces particularly well. The Stevie frames help to balance the features of a [round face shape](https://www.oscarwylee.com.au/glasses/face-shapes/round) or [oval face shape](https://www.oscarwylee.com.au/glasses/face-shapes/oval), bringing the eyes and brows forward in a flattering way. Although there are many [glasses for face shapes](https://www.oscarwylee.com.au/glasses/face-shapes) that may be considered more aesthetically suitable, it is important that people also choose the frames that make them feel most comfortable, and represent their personal style.
## What Size Options are Available for Oscar Wylee’s Stevie Glasses?
The size options available for Oscar Wylee’s Stevie frame is a medium frame fit across all colours.
## What Materials are Used to Create Oscar Wylee’s Stevie Glasses?
The primary material used to create the Oscar Wylee Stevie frame is acetate. The rim, nose bridge, temple and temple tips are made from acetate.
## What’s Included
## What's Included
Each pair of glasses comes with a stylish frame case and lens cloth. We offer free shipping across Australia and 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects.
* Free Shipping for Australian Orders
* 1 Year Warranty on frames and lenses
* Scratch resistance lens coating on all prescriptions
* UV-proof coating on all prescriptions
* Stylish case and cloth
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
## Make and Materials
The frames then go through cleaning and strict quality control, and many pairs of crafting hands to be hand-assembled and polished. After your frames have gone through the production process, they are individually examined and packed before making their way to you!Also known as cellulose acetate, these frames are traditionally hand-crafted by skilled craftsmen, with each frame passing through numerous stages of production and are hand-polished to ensure a glorious lustre.
## Warranty Information
### Warranty Information
### Warranty Information
Oscar Wylee provides a 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects. 
We will repair or replace faulty or defective frames or lenses free of charge for warranty claims made within 1 year of the delivery.
We also offer repairs or replacement for problems experienced with vision during everyday use for claims made within 30 days of delivery. If the same product has been discontinued or is no longer available, then we may offer an exchange for a similar product or a refund.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Find a Store Location](https://www.oscarwylee.com.au/locations/full-store-list.html)