# Source: https://www.oscarwylee.com.au/connor-optical.html

# Connor
1
## Frame Design of Connor Glasses
The frame design of Oscar Wylee’s Connor glasses is characterised by their classic shape, high nose bridge, TR90 frame, and lightweight feel. Connor is a wearable men’s glasses frame that you can rely on, day to night.
$169    
In stock
Only %1 left
2 pairs from $199
Discount auto-applied at checkout
3 pairs from $249
Discount auto-applied at checkout
Qty
Add to cart
Book an eye test
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
excluding prescription lenses
## About Connor Frames
Connor is your ever-reliable travel companion. Inspired by our ‘Active’ collection, the sophisticated sporty frame made from TR90 will be the fuss free pair to take you around the world.
| Frame fit | Measurements |
| --- | --- |
| WIDE | 55 - 19 - 140 |
These measurements mean lens width, bridge, and temple length in millimetres (mm). They can be found on the inside of the temple arm. If you already have a pair that you like, you can compare it to these measurements.
### Made from TR90
Oscar Wylee's Connor frame is a men's classic glasses frame that is perfect for those with square, oval, and pear face shapes. The Connor frame is a sleek, versatile frame that can be worn every day. The main specs of Oscar Wylee's Connor glasses frame, including dimensions, shape, materials, lenses, nose fit and hinges are listed below.
| Connor Frame Features | Connor Frame Description | Dimensions | Shape | Materials | Lenses | Nose Fit | Hinges |
| --- | --- | --- | --- | --- | --- | --- | --- |
| The dimensions of the Connor frame are measured in millimetres (mm) and are 55 - 19 - 140, meaning the lens width is 55 mm, the bridge is 19 mm, and the temple length is 140 mm. |
| Connor is a classic shape, well-suited to wide faces. |
| Connor is made from TR90 with rubber temple tips. |
| The lenses that can be used in the Connor frame include optical lenses, such as single-vision and multifocal, and non-prescription lenses, which are plain and can have a filter, such as a blue-light filter applied. |
| The nose fit for Connor is a high nose bridge fit. |
| The hinges in Connor are normal hinges, also known as standard or barrel hinges. |
Show All
### What Inspired the Frame Design of Oscar Wylee's Connor Glasses?
The Oscar Wylee Connor frame design was inspired by current fashion trends, as classic shapes are often in fashion. A classic glasses shape is timeless; it remains popular throughout the decades while other trends come and go.
## What to Know About Oscar Wylee's Connor Glasses?
There are many aspects of the Oscar Wylee Connor frames that customers should know about to decide whether this is the right frame for them. The Connor frame is a men's classic-shaped frame. Oscar Wylee's Connor frame is suitable for many face shapes, but particularly compatible with square, oval, and pear face shapes. The Connor frame's simple design makes them fashionable all year round. Connor features the standard [parts of glasses](https://www.oscarwylee.com.au/glasses/eye/part-of-glasses), such as a rim, temples, lenses, hinges, and a high nose bridge fit.
### What are the Types of Temple Tips or Earpieces Included with Oscar Wylee's Connor Glasses?
The type of temple tips or earpieces included in Oscar Wylee's Connor Glasses are made from rubber.
### What Type of Nose Bridge do Oscar Wylee's Connor Glasses Have?
The type of nose bridge included in Oscar Wylee's Connor frame is a high nose bridge fit.
### What Type of Nose Pads are Included with Oscar Wylee's Connor Glasses?
Oscar Wylee's Connor frame does not include adjustable silicone nose pads.
### What Type of Lenses do Oscar Wylee's Connor Glasses Have?
The type of lenses that typically come with the Oscar Wylee Connor [glasses frame](https://www.oscarwylee.com.au/glasses.html) are optical lenses. Optical lenses are glasses lenses that have a prescription within the lens to help correct vision issues such as myopia, hyperopia, and astigmatism. Connor can also come with non-prescription lenses, with add-ons such as a blue light filter. Connor frames can be customised into sunglasses in-store or online with add-on tints or polarisation.
### What Material is Used for the Rim of Oscar Wylee's Connor Glasses?
The material used for the rim of Oscar Wylee's Connor glasses frames is TR90. The rim refers to the part of a glasses frame that holds the lenses.
### What Type of Hinges are Included with Oscar Wylee's Connor Glasses?
The type of hinges included with Oscar Wylee's Connor frames are normal hinges. These provide strength and smooth movement connecting the frame's arms and lenses.
## What Face Types are Most Suitable for Oscar Wylee's Connor Glasses?
The face types that are most suitable for Oscar Wylee's Connor frame are square, oval, and pear face types. The Connor frame is a classic shape, meaning that it complements the structure of square, oval, and pear faces particularly well. The classic Connor frames help balance the features of a [square face shape](https://www.oscarwylee.com.au/glasses/face-shapes/square), an [oval face shape](https://www.oscarwylee.com.au/glasses/face-shapes/oval), and a [pear face shape](https://www.oscarwylee.com.au/glasses/face-shapes/pear), bringing the eyes and brows forward in a flattering way. Although there are many [glasses for face shapes](https://www.oscarwylee.com.au/glasses/face-shapes) that may be considered more aesthetically suitable, it is important that people also choose frames that make them feel most comfortable and represent their personal style.
## What Size Options are Available for Oscar Wylee's Connor Glasses?
The size options available for Oscar Wylee's Connor frame are a wide-fit frame across all colours.
## What Materials are Used to Create Oscar Wylee's Connor Glasses?
The primary material used to create the Oscar Wylee Connor frame is TR90. TR90 is a form of thermoplastic material, perfect for making flexible, durable, and lightweight glasses.
## What’s Included
## OW Case &amp; Cloth
Protective Case and Lens Cloth
Our high-quality glasses case and lens cloth are included with every purchase of an Oscar Wylee frame. The stylish, magnetic case is made from a hard shell. This sturdy and durable material keeps your glasses protected and safe, wherever you go. Ensure your lenses are clean and scratch-free with our OW microfibre cloth, specifically designed to ensure you have comfortable vision through your lenses.
Oscar Wylee offers:
* Free Shipping for Australian Orders
* 1 Year Warranty on frames and lenses
* Scratch resistance lens coating on all prescriptions
* UV-proof coating on all prescriptions
Health fund rebate: Once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. Learn more about [health funds](https://www.oscarwylee.com.au/health-funds.html).
## Make and Materials
Our TR90 glasses are for the adventurers! TR90 is a thermoplastic material renowned for its lightweight nature, durability and comfort. TR90 is produced through Swiss technology that allows it to be incredibly strong and tough to impact, perfect for the active wearer.The frames go through cleaning and strict quality control.After your frames have gone through the production process, they are individually examined and packed before making their way to you!
## Warranty Information
### Warranty Information
### Warranty Information
Oscar Wylee provides a 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects. We will repair or replace faulty or defective frames or lenses free of charge for warranty claims made within 1 year of the delivery. We also offer repairs or replacement for problems experienced with vision during everyday use for claims made within 30 days of delivery. If the same product has been discontinued or is no longer available, then we may offer an exchange for a similar product or a refund.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Find a Store Location](https://www.oscarwylee.com.au/locations/full-store-list.html)