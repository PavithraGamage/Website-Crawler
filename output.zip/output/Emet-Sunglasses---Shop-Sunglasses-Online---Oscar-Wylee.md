# Source: https://www.oscarwylee.com.au/emet-sunglasses.html

# Emet
1
## Frame Design of Emet Sunglasses
The frame design of Oscar Wylee’s Emet sunglasses is characterised by their square shape, high nose bridge, and acetate frame. Emet is a versatile unisex glasses frame that will complement any outfit or event, day to night.
$169    
In stock
Only %1 left
2 pairs from $199
Discount auto-applied at checkout
3 pairs from $249
Discount auto-applied at checkout
* 2 &amp; 3 Pair pricing applies to non-prescription sunglasses only. Prescription sunglasses incur additional charges.    
[Non-Prescription](https://www.oscarwylee.com.au/emet-sunglasses.html#)
Qty
Prescription
Book an eye test
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
excluding prescription lenses
## About Emet Sunglasses
Emet’s modern allure lies in its pronounced angular square frame and distinctly sculpted nose bridge compatible with all nose shapes.
| Frame fit | Measurements |
| --- | --- |
| MEDIUM | 51 - 22 - 145 |
These measurements mean lens width, bridge, and temple length in millimetres (mm). They can be found on the inside of the temple arm. If you already have a pair that you like, you can compare it to these measurements.
### Made from Acetate
Oscar Wylee’s Emet frame is a unisex square sunglasses frame that is perfect for those with round and oval face shapes. The Emet frame is a stylish, sleek frame that can be worn every day. The main specs of Oscar Wylee’s Emet glasses frame, including dimensions, shape, materials, lenses, nose fit, and hinges are listed below.
Filter category 3 - General purpose sunglasses. High protection against sunglare. Good UV Protection. Not suitable for driving in twilight, at night or under dull conditions.This frame comes with tinted lenses. An additional $30 will be added to your order total for prescription orders.
| Emet Frame Features | Emet Frame Description | Dimensions | Shape | Materials | Lenses | Nose Fit | Hinges |
| --- | --- | --- | --- | --- | --- | --- | --- |
| The dimensions of the Emet frame are measured in millimetres (mm) and are 51 - 22 - 145, meaning the lens width is 51 mm, the bridge is 22 mm, and the temple length is 145 mm. |
| Emet is a square shape, well-suited to medium faces. |
| Emet is made from acetate. |
| The lenses that can be used in the Emet frame are sunglass lenses, which provide UV protection. Emet also comes as optical glasses. Prescription lenses are also available to purchase for the Emet sunglass frame, both online and in-store. |
| The nose fit for Emet is a high nose bridge fit. |
| The hinges in Emet are normal hinges, also known as standard or barrel hinges. |
Show All
### What Inspired the Frame Design of Oscar Wylee's Emet Glasses?
The Oscar Wylee Angelica frame design was inspired by current fashion trends, as square shapes are often in fashion. A square glasses shape is timeless; it remains popular throughout the decades while other trends come and go.
## What to Know About Oscar Wylee's Emet Sunglasses?
There are many aspects of the Oscar Wylee Emet frames that customers should know to decide whether this is the right frame for them. The Emet frame is a unisex square sunglasses frame. Oscar Wylee’s Emet frame is suitable for many face shapes, but particularly compatible with round and oval face shapes. The Emet frame’s simple design makes them fashionable all year round. Emet features the standard [parts of glasses](https://www.oscarwylee.com.au/glasses/eye/part-of-glasses), such as a rim, temples, lenses, normal hinges, and a high nose bridge fit.
### What are the Types of Temple Tips or Earpieces Included with Oscar Wylee's Emet Glasses?
The type of temple tips or earpieces included in Oscar Wylee’s Emet Glasses are made from acetate.
### What Type of Nose Bridge do Oscar Wylee's Emet Glasses Have?
The type of nose bridge included in Oscar Wylee’s Emet frame is a high nose bridge.
### What Type of Nose Pads are Included with Oscar Wylee's Emet Glasses?
Oscar Wylee’s Emet frame does not include adjustable silicone nose pads.
### What Type of Lenses do Oscar Wylee's Emet Sunglasses Have?
The lenses that can be used in the Emet frame are sunglass lenses, which provide UV protection. UV protection lenses block harmful ultraviolet rays, safeguarding eyes from damage. The Emet frame comes in Filter Category 3. These are general purpose sunglasses with high protection against sunglare and good UV protection. They are not suitable for driving in twilight, at night, or under dull conditions. Prescription lenses are also available for the Emet frame, both online and in-store.
### What Material is Used for the Rim of Oscar Wylee's Emet Glasses?
The material used for the rim of Oscar Wylee’s Emet glasses frames is acetate. The rim refers to the part of a glasses frame that holds the lenses.
### What Type of Hinges are Included with Oscar Wylee's Emet Glasses?
The type of hinges included with Oscar Wylee’s Emet frames are normal hinges, also known as standard or barrel hinges. These provide strength and smooth movement connecting the frame's arms and lenses.
## What Face Types are Most Suitable for Oscar Wylee's Emet Glasses?
The face types most suitable for Oscar Wylee’s Emet frame are round and oval face types. The Emet frame is a square shape, meaning they complement the structure of round and oval faces particularly well. The square Emet frames help balance the features of a [round face shape](https://www.oscarwylee.com.au/glasses/face-shapes/round) and an [oval face shape](https://www.oscarwylee.com.au/glasses/face-shapes/oval), bringing the eyes and brows forward in a flattering way. Although there are many different [glasses for face shapes](https://www.oscarwylee.com.au/glasses/face-shapes) that may be considered more aesthetically suitable, it is important that people also choose frames that make them feel most comfortable and represent their personal style.
## What Size Options are Available for Oscar Wylee's Emet Glasses?
The size option available for Oscar Wylee’s Emet frame is a medium-frame fit.
## What Materials are Used to Create Oscar Wylee's Emet Glasses?
The material used to create the Oscar Wylee Emet frame is acetate. Acetate, also known as cellulose acetate, is a bioplastic made from cotton fibres or wood pulp. At Oscar Wylee, acetate glasses are made by adding a dye to cellulose acetate, which is rolled into a sheet. The shape of the glasses is then cut from this sheet.
## What’s Included
## OW Case &amp; Cloth
Protective Case and Lens Cloth
Our high-quality glasses case and lens cloth are included with every purchase of an Oscar Wylee frame. The stylish, magnetic case is made from a hard shell. This sturdy and durable material keeps your glasses protected and safe, wherever you go. Ensure your lenses are clean and scratch-free with our OW microfibre cloth, specifically designed to ensure you have comfortable vision through your lenses.
Oscar Wylee offers:
* Free Shipping on all orders
* 1 Year Warranty on frames and lenses
* Scratch resistance lens coating on all prescriptions
* UV-proof coating on all prescriptions
Health fund rebate: Once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. Learn more about [health funds](https://www.oscarwylee.com.au/health-funds.html).
## Make and Materials
Also known as cellulose acetate, these frames are traditionally hand-crafted by skilled craftsmen, with each frame passing through numerous stages of production and are hand-polished to ensure a glorious lustre. The frames then go through cleaning and strict quality control, and many pairs of crafting hands to be hand-assembled and polished. After your frames have gone through the production process, they are individually examined and&nbsp;packed before making their way to you!
## Warranty Information
### Warranty Information
### Warranty Information
Oscar Wylee provides a 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects. We will repair or replace faulty or defective frames or lenses free of charge for warranty claims made within 1 year of the delivery. We also offer repairs or replacement for problems experienced with vision during everyday use for claims made within 30 days of delivery. If the same product has been discontinued or is no longer available, then we may offer an exchange for a similar product or a refund.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Find a Store Location](https://www.oscarwylee.com.au/locations/full-store-list.html)