# Source: https://www.oscarwylee.com.au/about/our-story.html

# About Us
Oscar Wylee is a proud Australian company that strives to provide high-quality optometry services to customers
across the country and overseas. What started out as its initial showroom operates as the HQ in the heart of
Sydney.
Oscar Wylee is one of the fastest-growing eyewear companies in Australia with a thriving in-store and online
presence across three different countries; Australia, New Zealand and Canada. We are your approachable experts
in the world of eyewear and eye care. We are passionate about eye care with fully trained optometrists and
high-quality equipment in every store. We also believe in providing stylish, affordable, on-trend glasses that
don’t break the bank! Blending fashion with expert eye care, our customers have come to expect our uncomplicated
and enjoyable service.
Our products cover a wide range of styles and sizes for every customer, male, female, kids and senior. Come
visit us for an eye test where you can browse our affordable, high-quality frames and pick up 3 pairs of glasses
from $249.
Learn more about the [Oscar Wylee Team](https://www.oscarwylee.com.au/the-oscar-wylee-team)
including our dedicated optometrists and hardworking head office and retail staff.
## How We Began
Oscar Wylee has grown rapidly since it began as an online eCommerce business in 2012. After moving into retail,
we have continued on this upward trajectory, providing an exciting range of products and exceptional eye care.
Launched our first eCommerce and digital platform, offering Australian customers high-quality fashion eyewear
without the price tag.
The first showroom was located inside the 1875 historic building in the heart of Sydney,
Australia. For the first time, Oscar Wylee introduced on-site optometrists to provide a complete optical
service.
The first store opened in Chatswood NSW, created in the image of the Oscar Wylee style. The curved, wooden
interior design references the Australian sandy coastlines to showcase our designer quality and on-trend
eyewear.
We opened our first two New Zealand Oscar Wylee stores in Ponsonby and St Lukes.
Oscar Wylee branched into Canada with our Edmonton store in Alberta.
We currently have 145 stores across Australia, New Zealand and Canada with plans to continue expanding our
global presence.
## Our Business
### For the community
We are experts in eye care and aim to help all of our customers by providing them with excellent eyewear
and information about their eye health.
### Frames to reflect the people
We are proud that Australia is a melting pot of diverse cultures and perspectives which is reflected in
our products. Our wide range of frames is designed to appeal to our diverse customers as we believe we
have a pair for every person, every mood and every occasion.
### How We Work
We have developed a culture of actively engaged team members who are dedicated to improving the way we do
things to give you the best possible eye care experience. We call this endless improvement Kaizen, and it
is one of our core values at Oscar Wylee.
### Cutting out the middleman
At Oscar Wylee, we’ve cut out the distributor middleman to bring you designer-style glasses, directly
from the source, at affordable prices.
## We are passionate about:
* Providing quality and affordable eye care in both metro and regional areas.
* Keeping your eyes safe from the sun by offering sunglasses with UV protection.
* Our [Joint Venture
Partnership](https://www.oscarwylee.com.au/joint_venture.html), which has a growing number of optometrists and store managers making a commitment to
Oscar Wylee.
* Offering a wide range of lens options and add-ons to suit all customer needs.
* Educating our customers about optometry and how to take care of their eye health.
* Ensuring you get the most out of your health care by accepting all major [health funds.](https://www.oscarwylee.com.au/health-funds.html)
## Our Products
Our frames are affordable and stylish, with a wide range of modern, vintage and on-trend styles with both
international and local inspiration. They are custom made for each person, hand-assembled and hand-checked in
our labs. We ensure our glasses are of the highest quality before they are presented to our customers. Explore
our full [glasses collections page](https://www.oscarwylee.com.au/oscar-wylee-glasses-collections).
### Taking care of your frames
We offer a lifetime adjustment guarantee and a [one-year warranty](https://www.oscarwylee.com.au/legal/oscar-wylee-warranty.html) on our glasses,
meaning you can come back and visit us if you have any issues with your frames. We can clean them, tighten
any screws and readjust your frames to fit correctly.
## Frames for Everyone
[](https://www.oscarwylee.com.au/glasses.html) [](https://www.oscarwylee.com.au/glasses.html) [](https://www.oscarwylee.com.au/glasses.html)
## Our Services
### Bulk billed eye tests
We are grateful that in Australia, Medicare provides a subsidy for Australians to regularly get their eyes
tested. At Oscar Wylee, we provide eye tests to our customers, with no gap or out-of-pocket expenses, for
those with a valid Medicare card.
### BYO
Our commitment to eye health means you can come into our stores for an eye test without buying glasses. You
can also bring in your own prescription, as long as it’s not expired, and we can help you find a pair of
glasses that is right for you.
### Afterpay
Buy now and pay later with [Afterpay](https://www.oscarwylee.com.au/afterpay.html), in-store only at Oscar Wylee. The easy-to-use digital app allows our
customers to buy a pair of frames now and pay for them later. Simply pay off your purchase in 4 instalments
over 6 weeks, interest free!
## The Oscar Wylee experience
At Oscar Wylee, we believe in an excellent customer experience throughout the entire journey. We’ve created a
more casual and uncomplicated in-store experience as opposed to what you might find in a traditional eyewear
store. Our glasses aren’t hidden behind locked cabinets, they are out in the open where you can try them on at
your leisure.
We want you to feel relaxed and comfortable throughout the process, from getting your eyes tested and choosing
your perfect glasses, to using your health fund to claim. You can expect expert and tailored care when shopping
with Oscar Wylee.
 
## Find a store near you
Come visit at us one of our Oscar Wylee locations and our friendly staff can assist you.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
## Due for an eye check up?
[Book an eye test](https://www.oscarwylee.com.au/locations/full-store-list.html)

[14 Natural Home Treatments and Remedies for Sore Eyes](https://www.oscarwylee.com.au/glasses/eye/sore/remedies)
[How to Turn On and Off Blue Light On iPhone and Android](https://www.oscarwylee.com.au/glasses/blue-light/how-to-turn-off)
[Puffy Eyes: Definition, Causes, Symptoms, and Treatment](https://www.oscarwylee.com.au/glasses/eye/puffy-definition)
[Why Do My Eyes Hurt When I Wake Up? 8 Causes and Treatment](https://www.oscarwylee.com.au/glasses/eye/reasons-why-eye-hurts-when-waking-up)
[Eye Twitching: Types, Causes, Symptoms, and Treatments](https://www.oscarwylee.com.au/glasses/eye/twitching-definition)
[Chalazion: Symptoms, Causes, Diagnosis, and Treatments](https://www.oscarwylee.com.au/glasses/eye/chalazion)
[Understanding the Gunk in My Eyes: Causes, Types and Treatments](https://www.oscarwylee.com.au/glasses/eye/reason-of-eye-gunk)
[How to Read an Eyeglasses Prescription](https://www.oscarwylee.com.au/glasses/eye/reading-eyeglasses-prescription)
[Best Glasses for Different Face Shapes: How to Choose Glasses for Male and Female Face
Shapes](https://www.oscarwylee.com.au/glasses/face-shapes)
[Red or Bloodshot Eyes: Causes, Symptoms, Treatment, and Prevention](https://www.oscarwylee.com.au/glasses/eye/red-or-bloodshot)
[8 Different Types of Lenses for Glasses](https://www.oscarwylee.com.au/glasses/eye/types-of-lenses)
[7 Different Types of Eye Drops You Should Know](https://www.oscarwylee.com.au/glasses/eye/types-of-eye-drops)
[Eye Floaters: Definition, Causes, Symptoms, and Treatment](https://www.oscarwylee.com.au/glasses/eye/floaters-definition)
[Seeing Flashing Lights in the Corner of the Eye: What is it, Causes, and Treatment](https://www.oscarwylee.com.au/glasses/eye/seeing-flashing-lights-in-corner-of-eye)
[Blepharitis: Types, Causes, Symptoms, Diagnosis, and Treatments](https://www.oscarwylee.com.au/glasses/eye/eyelids-inflammation)
[Best Glasses for Round Face (Male and Female): Frames, Shapes and Types](https://www.oscarwylee.com.au/glasses/face-shapes/round)
[Eye Allergies: Types, Causes, Symptoms, and Treatments](https://www.oscarwylee.com.au/glasses/eye/allergies)
[Different Types of Glasses, Frames, and Lenses](https://www.oscarwylee.com.au/glasses/types)
[Pinguecula: Causes, Symptoms, Diagnosis, and Treatment](https://www.oscarwylee.com.au/glasses/eye/pinguecula)
[Cataracts: Definition, Types, Causes, Symptoms, Treatment, and Prevention](https://www.oscarwylee.com.au/glasses/eye/cataracts)
More Glasses and Eye Health Guides 