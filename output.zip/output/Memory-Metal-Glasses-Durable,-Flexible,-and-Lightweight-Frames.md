# Source: https://www.oscarwylee.com.au/glasses/memory-metal

# Memory Metal Glasses: Durable, Flexible, and Lightweight Frames
Published on December 9th 2024
Updated on January 11th, 2024 
Memory metal glasses
refer to glasses made with shape-memory alloy, a type of material that
allows the glasses to be bent or twisted lightly, and then return back to
their original shape. Memory metal eyeglasses are designed to be slightly more durable and
flexible than frames made from other materials, but they are not
unbreakable, and shouldn't be treated like a toy. This type of frame is
suitable and stylish for both
[women’s glasses](https://www.oscarwylee.com.au/glasses/collection/womens-glasses.html)
and men’s glasses and every occasion. Keep reading to learn more about
memory metal glasses and if they are the right frame for you.
When was your last eye test?
At Oscar Wylee we offer bulk billed eye tests for all eligible medicare
card holders
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Definition](#definition)
[How They Work](#How-They-Work)
[How to Choose](#How-to-Choose)
[Main Features and Benefits](#Features-and-Benefits)
## What are Memory Metal Glasses?
Memory metal glasses
are a type of glasses made from specialised materials that give the
glasses the ability to bend or twist slightly and then return back to
their original shape. Memory metal glasses are typically made from a shape-memory alloy
material and can be good for those who need a durable, more flexible and
[lightweight glasses](https://www.oscarwylee.com.au/glasses/materials/lightweight.html)
frames than those made from other materials such as acetate. Oscar Wylee
has a range of memory metal frames available as part of our
[Memory Twist collection](https://www.oscarwylee.com.au/glasses/collection/memory-twist-collection.html). At Oscar Wylee, certain parts of our memory metal frames are made
from a
[titanium](https://www.oscarwylee.com.au/glasses/titanium)
alloy. Memory metal glasses are not suitable for those with a nickel
allergy.
### Are Memory Metal Frames Unbreakable?
No, memory metal frames are not unbreakable. Memory metal
frames are designed to be flexible eyeglasses, with the ability to
bounce back into shape if bent or twisted lightly.
Memory metal frames are not designed to be unbreakable, and if
twisted or bent too far or too roughly will break or be damaged. Memory metal frames are designed to have increased flexibility and
durability, but they are not toys to be played with.
### Which Parts of Memory Metal Frames are Twisty?
The parts of memory metal frames that are twisty are
usually the nose bridge and the temples. The rest of a memory
metal frame, such as the rims and temple tips, are typically made from
other materials.
### How does Memory Metal Maintain Frame Shape?
Memory metal frames are able to maintain their shape after light
bending or twisting,
due to the shape-memory alloy material they are made with.
Shape memory alloy (SMA) is a type of metal material that is used in
robotics and medical devices that can bend or twist lightly, and
return to its original shape.
### What Makes Memory Metal Glasses Lightweight and Durable?
What makes memory metal lightweight eyeglasses and durable
is their material.
Memory metal glasses are typically made, to some degree, from
shape-memory alloy (SMA) which is the material that allows these
glasses to be bent or twisted slightly, and then return to their
original shape. Learn more about
[lightweight eyeglasses, including their materials, design and
comfort](https://www.oscarwylee.com.au/glasses/lightweight-frame).
#### Are Memory Metal Glasses Suitable for Active Lifestyles?
Memory metal glasses
may be suitable for people who have more active lifestyles,
however, there may be better alternatives if someone is playing a
lot of sports, such as
[sports sunglasses](https://www.oscarwylee.com.au/glasses/sport-sunglasses)
or even contact lenses. Memory metal glasses are designed to be bent or twisted slightly
and return back to their original shape. This means if someone is
busy or active, or even has kids that like to grab their glasses,
these frames may be able to withstand some everyday life wear and
tear. However, for those who are playing sports, glasses
specifically designed to withstand impact may be a better choice.
Contact lenses may also be a good choice for those who are playing
sports and don’t want to break their glasses. Oscar Wylee does not
sell contact lenses, however, we do have a range of sports
sunglasses called The
[OW Active Collection](https://www.oscarwylee.com.au/sunglasses/collection/active-collection.html).
## Why are Memory Metal Glasses a Popular Choice for Flexibility?
Memory metal glasses
are a popular choice when it comes to frame flexibility as they have
the ability to lightly bend and twist more than the typical frame made
from other materials such as acetate. This flexibility can help to reduce the risk of damage that can come
from accidental dropping or pressure put on the frame, making them more
durable to everyday wear and tear than some other frames. Additionally,
[the growing popularity of thin frame glasses](https://www.oscarwylee.com.au/glasses/thin-frame)
may contribute to memory metal glasses being the popular choice not just
for their functionality but also for its style and aesthetic.
Find Your Local Oscar Wylee Store
Use our store locator page to find your near Oscar Wylee store and
come see the team for all your eyewear and eyecare needs.
[Store locations](https://www.oscarwylee.com.au/locations/)
### How do Memory Metal Frames Enhance Comfort for Daily Use?
Memory metal frames
enhance comfort for daily use due to their lightweight nature.
This makes them easy to wear for long periods of time without causing
too much strain or fatigue. Their flexibility prevents pinching or
pressure points as the frames can adapt to your face contours. Memory
metal glasses contain ergonomic designs such as flexible temples which
further improve the more personalised fit.
#### Are Memory Metal Glasses Ideal for Prescription Eyewear?
Memory metal glasses
are an ideal frame for prescription eyewear as they can support
various lens types including lenses with a prescription. Memory metal frames can function as both
[prescription glasses](https://www.oscarwylee.com.au/glasses/prescription)and non-prescription glasses, capable of holding both types of
lenses, as well as add-ons such as high-index and blue light
filters. At Oscar Wylee, we have a collection of memory metal frames
called the Memory Twist collection, all of which can be made into
both prescription and non-prescription eyewear. Other materials can
also be ideal for prescription eyewear including acetate and TR90.
Learn more about
[TR90 glasses and sunglasses, including their composition and
durability](https://www.oscarwylee.com.au/glasses/tr90).
[](https://www.oscarwylee.com.au/miranda-optical.html)
[Miranda](https://www.oscarwylee.com.au/miranda-optical.html)
$199    
Add to Cart
[Shop Miranda](https://www.oscarwylee.com.au/miranda-optical.html)
[2 pairs from $249](https://www.oscarwylee.com.au/miranda-optical.html)
[](https://www.oscarwylee.com.au/koda-optical.html)
[Koda](https://www.oscarwylee.com.au/koda-optical.html)
$199    
Add to Cart
[Shop Koda](https://www.oscarwylee.com.au/koda-optical.html)
[2 pairs from $249](https://www.oscarwylee.com.au/koda-optical.html)
[](https://www.oscarwylee.com.au/mackenzie-optical.html)
[Mackenzie](https://www.oscarwylee.com.au/mackenzie-optical.html)
$199    
Add to Cart
[Shop Mackenzie](https://www.oscarwylee.com.au/mackenzie-optical.html)
[2 pairs from $249](https://www.oscarwylee.com.au/mackenzie-optical.html)
### Why are Memory Metal Glasses Perfect for Travelers and Outdoor
Activities?
Memory metal glasses
are a good choice for travelers and outdoor activities due to their
increased durability and flexibility. The flexibility of memory metal frames makes them less likely to
break due to accidental drops, a good choice when travelling or being
in harsher outdoor environments.
### How Long-Lasting are Memory Metal Glasses Compared to Traditional
Frames?
Memory metal glasses
are not necessarily more long-lasting when compared to traditional
frames. Whilst memory metal can be more flexible and durable than frames
made from traditional materials such as acetate, that doesn’t
necessarily mean that they will be more long-lasting. Much of the
longevity of frames is down to how well a person looks after them.
Ensuring glasses are put back in a case when not in use are important
to make sure they are not broken and prolonging longevity. Keeping
glasses clean is also important to longevity. Learn more about frames
made from other materials, such as
[acetate glasses, including their material, benefits and caring
tips](https://www.oscarwylee.com.au/glasses/acetate-frame).
### What Innovations Make Memory Metal Eyewear Stand Out?
Shape-memory alloy
is the innovative material that makes memory metal eyewear stand
out among other glasses materials. Shape-memory alloy is the material in memory metal glasses that
allows them to retain their shape after light bending or twisting.
Shape-memory alloy is not a material that is found in another type of
glasses.
### How to Choose the Best Memory Metal Glasses for Your Needs?
The way to choose the best memory metal glasses for your eye care
needs is to consider face shape, face size and personal style.
Like glasses made from other materials, memory metal glasses can come
in a variety of shapes, sizes and colours, available in both
prescription and non-prescription, suitable for a range of eyecare
needs. Some of the steps to choosing the best memory metal glasses for
your needs are listed below.
1. Consider face shape:  Considering
face shape is an important step in choosing the best memory metal
glasses, or any glasses, for your eye care needs. There are several
types of face shapes including square, round, pear and diamond.
Certain glasses will suit certain face shapes better than others.
For example, round glasses will suit square faces well, as the
curves add softness and dimension to this face shape.
2. Consider face size:  Considering
face size is another important step in choosing the best memory
metal glasses. Like face shapes, there are certain glasses that will
suit certain face sizes better than others. For example, those with
larger faces will suit equally large frames well, as these will
bring balance to the face. If a person with a larger face wears
glasses that are too small, these can make the face look larger than
it is.
3. Consider personal style: 
Considering personal style is an important step in choosing memory
metal glasses. Whilst picking frames that are complimentary to your
face shape and face size are important, it is equally important that
a person picks a frame they are comfortable in and best represents
their personal style, even if it doesn’t fully meet those
requirements.
### What are the Main Features and Benefits of High-Quality Memory Metal
Glasses?
The main features and benefits of high-quality memory metal glasses
include their flexibility, durability and lightweight feel. The
main features of high-quality memory metal glasses are listed below.
* Flexibility:  Flexibility is the key
feature of memory metal glasses. Memory metal glasses are designed
to be more flexible than other glasses, returning to their original
shape after light bending or twisting.
* Durability:  Durability is another
main feature of memory metal glasses. The flexibility of
shape-memory alloy means it can withstand slight twisting or bending
in a way that frames made from other materials, such as acetate,
would not be able to.
* Lightweight:  A Lightweight feel is
one of the main features of memory metal glasses. Shape memory
alloy, which is the material most memory glasses are made from, is a
lightweight material.
Do Memory Metal Glasses Have Titanium?
Some memory metal glasses
may have elements of titanium, but that is not the main
material that memory metal glasses are made from. Memory metal glasses are generally made from a shape-memory
alloy material, which allows them to maintain their shape after
light bending or twisting. Some memory metal glasses may have
other types of metal, such as titanium, throughout parts of the
glasses.

Look After Your Eyes at Oscar Wylee
Regular eye tests are an important step in keeping eyes healthy. Book
now and an Oscar Wylee optometrist can provide a Medicare bulk billed
eye test.
[Book an eye test](https://www.oscarwylee.com.au/booking)
Major Health Funds Accepted In-store
For the purchase of frames and lenses, use your private health fund
insurance to limit how much you pay from your own pocket.
[Explore Health funds](https://www.oscarwylee.com.au/health-funds.html)