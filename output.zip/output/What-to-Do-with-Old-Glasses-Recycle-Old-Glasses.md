# Source: https://www.oscarwylee.com.au/glasses/recycle-old-glasses

# What to Do with Old Glasses: Recycle Old Glasses
Published on November 10th, 2025
Updated on March 21st, 2025 
Australia
[Australia](https://www.oscarwylee.com.au/glasses/recycle-old-glasses)
New Zealand

[Canada](https://oscarwylee.ca/glasses/recycle-old-glasses)
Canadian French

Some practical and useful options to get rid of old glasses include donating
them to charity, dropping them off at an eyewear store for recycling, or
giving them to a loved one in need of new glasses. These are better, more
environmentally friendly ways to get rid of old frames, as opposed to
throwing them away.
Oscar Wylee is not affiliated with any of the charities or initiatives
listed in this article. Read on to discover more about how to recycle and give new life to old
glasses.
Experience high-quality eye care and a memorable in-store experience
We have knowledgeable teams at every store location ready to assist you.
[Eye test near me](https://www.oscarwylee.com.au/booking)
[What to Do](#what-to-do)
[Donating Your Glasses](#donating-your-glasses)
[Disposing Damaged Glasses](#disposing-damaged-glasses)
[Repurposing at Home](#repurposing-at-home)
## What Can You Do with Your Old Glasses?
You can do various things with your old glasses, such as
donating them or fitting the frames with new lenses.
Donating your old glasses is a great way to give back to those who are
in need of eyewear but do not have access. Initiatives such as the Lions
Organisation's Recycle For Sight program are an example of this, as they
send around 450,000 pairs of glasses to developing countries every year,
according to the Fred Hollows Foundation. It should be noted that Oscar
Wylee is not associated with the Lions Organisation's Recycle for Sight
program. Alternatively, glasses can be reglazed with new lenses for
those who require a prescription update and want a spare pair of glasses
to have in their collection. Glasses can also be a great gift idea for a
loved one, and they themselves can get the frames refitted with their
own prescription, providing the old glasses with a new life.
### Where Can You Donate Old Glasses in Australia?
You can donate old glasses in Australia
through the organisation Lion Clubs Australia and certain
optometrists.
The organisation Lion Australia runs the Lions Recycle for Sight
Australia, operating throughout Australia and overseas. Donations are
made into refurbished high-quality eyewear for people in need across
countries in Africa, Europe, and Asia. Additionally, certain local
Optometrist branches may accept eyewear donations as part of recycling
programs to turn old eyewear frames into new products. You can contact
your local optometrist or search online for the nearest store that
receives donations.
### How Do You Donate Prescription Glasses to Those in Need?
To donate prescription glasses to those in need,
you have to make sure your eyewear is in good condition and then
search for a place that can accept the donation. Ensure your eyewear does not have any broken parts and that the
lenses are cleaned well with lens cleaner and a microfibre cloth. Keep
your
[prescription glasses](https://www.oscarwylee.com.au/glasses/prescription)
in their case prior to donating so they will be protected from
scratches and other wear and tear.
#### Can You Recycle Old Glasses or Spectacles?
Yes, you can recycle old glasses or spectacles
by bringing them to programs such as Lions Recycle or Sight
Australia.
Groups like the Lions Club that collect old glasses will send
received frames that are suitable for recycling to the Lions Recycle
Centre, where they will quickly assess the glasses to see if they
can be refurbished according to Lions Australia. It is important to
note that glasses cannot be recycled if they are broken or
scratched.
Find Your Local Oscar Wylee Store
Come in and see the team for your eye care needs, including eye
testing. All major health funds are accepted in-store.
[Optometrist near me](https://www.oscarwylee.com.au/locations/full-store-list.html)
## How are Recycled Glasses Collected and Reused?
Recycled glasses and the ways they are collected and reused can
differ slightly from each organisation. Collection is
most common through people physically dropping off glasses at the
donation centre or other drop-off points, or even mailing them to a
specific address. Reusing glasses happens through donations or a
specific process wherein glasses are taken apart and the materials are
reused in the creation of new products, such as outdoor public
furniture.
### Where Can You Take Old Glasses for Recycling or Donation?
You can take old glasses for recycling or donation to several
different institutes or through programs in Australia.
Options such as the Lions Club and local recycling centres can
accept all glasses, while charity shops can take in non-prescription
glasses or sunglasses.
#### Can You Reuse Old Glasses Frames for New Lenses?
Yes, you can reuse old glasses frames for new lenses.
This allows the old glasses to be reused and adapted to your current
vision needs. This is done through a process called reglazing, which
is the process of removing old lenses from your glasses and
replacing them with new lenses. At Oscar Wylee, we allow customers
to reglaze the lenses on their Oscar Wylee glasses at a base cost of
$89, not including any additional lens add-ons they may want.
Conditions may apply.
### How Should You Dispose of Damaged or Broken Glasses?
Disposing of damaged or broken glasses may differ depending on the
severity of the damage.
You can check with your optometrist to assess whether your metal or
[acetate frames](https://www.oscarwylee.com.au/glasses/acetate-frame)
can still be repaired for use or not. If they can no longer be
repaired, you should then safely dispose of them by dropping them
off at a proper recycling collection program, such as Opticycle, Spexcycle, or your local recycling centre that
deals specifically with the materials of your glasses appropriately.
Oscar Wylee is not affiliated with either Opticycle or Spexcycle.
### What Happens to Donated Glasses After Collection?
What happens to donated glasses after collection
will depend on which organisation they are donated to. For example,
Lions Australia examines the glasses by assessing whether they are
prescription or not.
If they are prescription glasses that have been donated, they will be
recycled. If they are non-prescription, such as a pair of sunglasses,
these are encouraged to be given away to people in need around the
area or to your local charity or op shop.
### Why Is Donating or Recycling Old Glasses Important?
Donating or recycling old glasses is important
as it ensures old glasses do not go to waste and into
landfill.
Donating old glasses offers eyewear a new life to someone in need of
glasses as the lenses can be reglazed to fit the new wearer's
prescription glasses. Proper recycling is important for old glasses as
it allows the frame to be repurposed instead of being placed into a
landfill.
#### Can You Send Old Glasses by Mail for Donation?
Yes, certain organisations allow people to send old glasses by
mail.
It is important to check the guidelines of the organisation you are
donating to to confirm whether you can mail your glasses as opposed
to dropping them off at a physical location. The Lions
Organisation's Recycle for Sight is an organisation that sends
glasses to developing countries and accepts eyewear donations via
mail, where donations are expected to be wrapped in bubble wrap or a
padded bag, according to The Fred Hollows Foundation.
## What are The Best Ways to Repurpose Old Glasses at Home?
Some of the best ways to repurpose old glasses at home is to have the
frames reglazed to fit another family member's prescription or use and
store them as a dress-up accessory. If you do not want your old glasses, or do not have a need for them
anymore then giving them to a family member at home is a good way to
give the frames a second life. The lenses can be reglazed to accommodate
their prescription, or even be fitted with non-prescription blue light
filter lenses if they want glasses for multiple purposes. Alternatively,
you can store the old glasses away and use them for a dress-up accessory
when there is an event happening such as a costume party or fancy-dress
dinner. Glasses are a key element for many costume ideas, from Harry
Potter to Velma from Scooby-Doo, allowing for your old glasses to
potentially be an accessory for a future costume.
### How Can You Recycle Reading Glasses and Sunglasses Responsibly?
You can recycle
[reading glasses](https://www.oscarwylee.com.au/glasses/collection/reading.html)
and sunglasses responsibly the same way you would other
eyeglasses.
This is best done professionally by donating to organisations such as
the Lions Clubs International or your local optometrist accepting
glasses donations. These organisations will be able to recycle the
reading glasses and sunglasses in a proper process, or donate them to
those in need.
#### Do Oscar Wylee Take Old Glasses?
No,
[Oscar Wylee](https://www.oscarwylee.com.au/) currently
does not take old glasses.
There are other retailers and initiatives that accept old glasses to
consider. It might be best to contact retailers and stores directly
to confirm whether they are able to take your old glasses before
visiting.
Read What to Do with Old Glasses: Recycle Old Glasses in other Oscar
Wylee regions and their languages.
Australia
[Australia](https://www.oscarwylee.com.au/glasses/recycle-old-glasses)
New Zealand

[Canada](https://oscarwylee.ca/glasses/recycle-old-glasses)
Canadian French

Find Your Local Oscar Wylee Store
Come in and see the team for your eye care needs, including eye
testing. All major health funds are accepted in-store.
[Discover Health Funds](https://www.oscarwylee.com.au/health-funds.html)
Book an Eye Test at Oscar Wylee
If you are an eligible Medicare cardholder, our eye tests will be bulk
billed.
[Eye test near me](https://www.oscarwylee.com.au/booking)