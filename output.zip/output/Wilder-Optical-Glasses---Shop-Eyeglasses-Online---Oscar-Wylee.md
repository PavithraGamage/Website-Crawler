# Source: https://www.oscarwylee.com.au/wilder-optical.html

# Wilder
1
## Frame Design of Wilder Glasses
The frame design of Oscar Wylee’s Wilder glasses is characterised by their rectangle shape, low nose bridge, and acetate frame. Wilder is a female, statement glasses frame that will complement any outfit, day to night.
$169    
In stock
Only %1 left
2 pairs from $199
Discount auto-applied at checkout
3 pairs from $249
Discount auto-applied at checkout
Qty
Add to cart
Book an eye test
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
excluding prescription lenses
## About Wilder Frames
A frame fit for Ryan Reynolds. Wilder will be your new favourite, everyday frame.
| Frame fit | Measurements |
| --- | --- |
| MEDIUM | 53 - 18 - 140 |
These measurements mean lens width, bridge, and temple length in millimetres (mm). They can be found on the inside of the temple arm. If you already have a pair that you like, you can compare it to these measurements.
### Made from Acetate
Oscar Wylee's Wilder frame is a female rectangle glasses frame that is perfect for those with round and oval face shapes. The Wilder frame is a stylish, widely wearable frame that can be worn every day. The main specs of Oscar Wylee's Wilder glasses frame, including dimensions, shape, materials, lenses, nose fit and hinges are listed below.
| Wilder Frame Features | Wilder Frame Description | Dimensions | Shape | Materials | Lenses | Nose Fit | Hinges |
| --- | --- | --- | --- | --- | --- | --- | --- |
| The dimensions of the Wilder frame are measured in millimetres (mm) and are 53 - 18 - 140, meaning the lens width is 53 mm, the bridge is 18 mm, and the temple length is 140 mm. |
| Wilder is a rectangular shape, well-suited to medium faces. |
| Wilder is made from acetate. |
| The lenses that can be used in the Wilder frame include optical lenses, such as single-vision and multifocal, and non-prescription lenses, which are plain and can have a filter, such as a blue-light filter applied. |
| The nose fit for Wilder is characterised by a low nose bridge. |
| The hinges in Wilder are spring hinges, which are more flexible than other types of hinges and can extend past 90 degrees. |
Show All
### What Inspired the Frame Design of Oscar Wylee's Wilder Glasses?
The Oscar Wylee Wilder frame design was inspired by current fashion trends, as rectangle glasses are a timeless style.
## What to Know About Oscar Wylee's Wilder Glasses?
There are many aspects of the Oscar Wylee Wilder frames that customers should know about to decide whether this is the right frame for them. The Wilder frame is a female rectangle-shaped frame. Oscar Wylee's Wilder frame is suitable for many face shapes, but particularly compatible with round and oval face shapes. The Wilder frame's simple design makes them fashionable all year round. Wilder features the standard [parts of glasses](https://www.oscarwylee.com.au/glasses/eye/part-of-glasses), such as a rim, temples, lenses, spring hinges, and a low nose bridge.
### What are the Types of Temple Tips or Earpieces Included with Oscar Wylee's Wilder Glasses?
The type of temple tips or earpieces included in Oscar Wylee's Wilder Glasses are made from acetate.
### What Type of Nose Bridge do Oscar Wylee's Wilder Glasses Have?
The type of nose bridge included in Oscar Wylee's Wilder frame is characterised by a low nose bridge.
### What Type of Nose Pads are Included with Oscar Wylee's Wilder Glasses?
Oscar Wylee's Wilder frame does not include adjustable nose pads.
### What Type of Lenses do Oscar Wylee's Wilder Glasses Have?
The type of lenses that typically come with the Oscar Wylee Wilder [glasses frame](https://www.oscarwylee.com.au/glasses.html) are optical lenses. Optical lenses are glasses lenses that have a prescription within the lens to help correct vision issues such as myopia, hyperopia, and astigmatism. Wilder frames can also come as sunglasses and with non-prescription lenses and add-ons such as a blue-light filter.
### What Material is Used for the Rim of Oscar Wylee's Wilder Glasses?
The material used for the rim of Oscar Wylee's Wilder glasses frames is acetate. The rim refers to the part of a glasses frame that holds the lenses.
### What Type of Hinges are Included with Oscar Wylee's Wilder Glasses?
The type of hinges included with Oscar Wylee's Wilder frames are spring hinges. A spring hinge in a glasses frame refers to hinges that are more flexible than normal hinges and can go slightly beyond 90 degrees. Spring hinges can provide a closer fit to the face.
## What Face Types are Most Suitable for Oscar Wylee's Wilder Glasses?
The face types that are most suitable for Oscar Wylee's Wilder frame are round and oval face types. The Wilder frame is a rectangle shape, meaning that it complements the structure of round and oval faces particularly well. The rectangle Wilder frames help balance the features of [oval face shapes](https://www.oscarwylee.com.au/glasses/face-shapes/oval) and [round face shapes](https://www.oscarwylee.com.au/glasses/face-shapes/round) bringing the eyes and brows forward in a flattering way. Although there are many [glasses for face shapes](https://www.oscarwylee.com.au/glasses/face-shapes) that may be considered more aesthetically suitable, it is important that people also choose frames that make them feel most comfortable and represent their personal style.
## What Size Options are Available for Oscar Wylee's Wilder Glasses?
The size options available for Oscar Wylee's Wilder frame are a medium-fit frame across all colours.
## What Materials are Used to Create Oscar Wylee's Wilder Glasses?
The primary material used to create the Oscar Wylee Wilder frame is acetate. Acetate, also known as cellulose acetate, is a bioplastic, made from cotton fibres or wood pulp. At Oscar Wylee, acetate glasses are made by adding a dye to cellulose acetate, which is rolled into a sheet. The shape of the glasses is then cut from this sheet.
## What’s Included
## OW Case &amp; Cloth
Protective Case and Lens Cloth
Our high-quality glasses case and lens cloth are included with every purchase of an Oscar Wylee frame. The stylish, magnetic case is made from a hard shell. This sturdy and durable material keeps your glasses protected and safe, wherever you go. Ensure your lenses are clean and scratch-free with our OW microfibre cloth, specifically designed to ensure you have comfortable vision through your lenses.
Oscar Wylee offers:
* Free Shipping for Australian Orders
* 1 Year Warranty on frames and lenses
* Scratch resistance lens coating on all prescriptions
* UV-proof coating on all prescriptions
Health fund rebate: Once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. Learn more about [health funds](https://www.oscarwylee.com.au/health-funds.html).
## Make and Materials
The frames then go through cleaning and strict quality control, and many pairs of crafting hands to be hand-assembled and polished. After your frames have gone through the production process, they are individually examined and packed before making their way to you!Also known as cellulose acetate, these frames are traditionally hand-crafted by skilled craftsmen, with each frame passing through numerous stages of production and are hand-polished to ensure a glorious lustre.
## Warranty Information
### Warranty Information
### Warranty Information
Oscar Wylee provides a 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects. 
We will repair or replace faulty or defective frames or lenses free of charge for warranty claims made within 1 year of the delivery.
We also offer repairs or replacement for problems experienced with vision during everyday use for claims made within 30 days of delivery. If the same product has been discontinued or is no longer available, then we may offer an exchange for a similar product or a refund.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Find a Store Location](https://www.oscarwylee.com.au/locations/full-store-list.html)
Recommended
1. [](https://www.oscarwylee.com.au/oliver-optical.html)
[Oliver](https://www.oscarwylee.com.au/oliver-optical.html)
Charcoal Dusk