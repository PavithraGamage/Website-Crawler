# Source: https://www.oscarwylee.com.au/frank-optical.html

Out of stock        
# Frank
## About the Frames
Bask in the serenity of Frank; an abstract frame that brings a softness to the wearer. Choose Frank for its unisex style, rivet detail and strong shape.
### Made from Acetate
Frame fitMedium
Measurements48 - 21 - 142
These measurements mean lens width, bridge, and temple length in millimetres (mm). They can be found on the inside of the temple arm. If you already have a pair that you like, you can compare it to these measurements.
## What’s Included
## OW Case &amp; Cloth
Protective Case and Lens Cloth
Our high-quality glasses case and lens cloth are included with every purchase of an Oscar Wylee frame. The stylish, magnetic case is made from a hard shell. This sturdy and durable material keeps your glasses protected and safe, wherever you go. Ensure your lenses are clean and scratch-free with our OW microfibre cloth, specifically designed to ensure you have comfortable vision through your lenses.
Oscar Wylee offers:
* Free Shipping for Australian Orders
* 1 Year Warranty on frames and lenses
* Scratch resistance lens coating on all prescriptions
* UV-proof coating on all prescriptions
Health fund rebate: Once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. Learn more about [health funds](https://www.oscarwylee.com.au/health-funds.html).
## Make and Materials
The frames then go through cleaning and strict quality control, and many pairs of crafting hands to be hand-assembled and polished. After your frames have gone through the production process, they are individually examined and&nbsp;packed before making their way to you!Also known as cellulose acetate, these frames are traditionally hand-crafted by skilled craftsmen, with each frame passing through numerous stages of production and are hand-polished to ensure a glorious lustre.
## Warranty Information
### Warranty Information
### Warranty Information
Oscar Wylee provides a 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects. We will repair or replace faulty or defective frames or lenses free of charge for warranty claims made within 1 year of the delivery. We also offer repairs or replacement for problems experienced with vision during everyday use for claims made within 30 days of delivery. If the same product has been discontinued or is no longer available, then we may offer an exchange for a similar product or a refund.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Find a Store Location](https://www.oscarwylee.com.au/locations/full-store-list.html)