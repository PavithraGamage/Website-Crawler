# Source: https://www.oscarwylee.com.au/glasses/eye/uv-protection

# 9 Ways to Protect Eyes from Ultraviolet (UV) Light
Published on September 26th, 2023
Updated on March 27th, 2025
Australia
[Australia](https://www.oscarwylee.com.au/glasses/eye/uv-protection)
[Canada](https://oscarwylee.ca/glasses/eye/uv-protection)
[Canadian French](https://oscarwylee.ca/fr/glasses/eye/uv-protection)
Wearing sunglasses is extremely important as it protects the eyes from
ultraviolet light that is emitted by the sun. UV sunglasses are glasses
designed to protect the eyes from the ultraviolet radiation produced by the
sun as prolonged exposure can lead to eye cancer, cataracts and growths on
the eye. UV protection eyeglasses not only shield the eyes from the sun but
also protect the eyes from potentially harmful elements such as wind and
dust, may reduce glare and eye strain and also help protect the skin around
the eyes. The 9 ways to protect the eyes from ultraviolet (UV)
light include
never gazing directly at the sun, putting on sunglasses, wearing a hat
for additional protection, avoiding using low-quality sunglasses, steering
clear of artificial sources of UV radiation, implementing effective sun
protection practices, arranging an annual eye check-up, consider using
transition lenses and safeguarding the eyes of children.
These recommendations and their definitions are listed below.
* Never gaze directly at the sun: To protect
the eyes from ultraviolet light, try to never gaze directly at the sun as
it burns the exposed tissue of the retina in the eyes.
* Put on sunglasses: Sunglasses are the main
way to protect the eyes from ultraviolet rays emitted by the sun.
* Wear a hat for additional protection: UV
sunglasses are not completely effective at protecting the eyes from the
sun which is why you should wear a hat for additional UV protection.
* Avoid using low-quality sunglasses: To
adequately protect the eyes from the sun, it is important to avoid using
low-quality sunglasses.
* Steer clear of artificial sources of UV radiation:
Sources of artificial UV radiation include tanning beds, welding arcs,
mercury vapour lighting, some incandescent lights and some types of
lasers.
* Implement effective sun protection practices:&nbsp;It is important to implement effective sun protection practices to
protect the eyes and your overall health such as wearing sunglasses, a hat
and sunscreen.
* Arrange an annual eye check-up: Booking or
arranging an annual eye check-up is crucial in maintaining the health of
the eyes and detecting signs of sun damage.
* Consider using transition lenses:
Transition lenses are a great solution for people who need vision
correction but don’t want to switch between sunglasses and glasses.
* Safeguard the eyes of children: It is
important to protect and safeguard children's eyes from ultraviolet rays
as children spend much of their time outdoors and their eyes are not fully
developed.
In Need of an Eye Test?
We offer Medicare bulk billed eye tests for valid cardholders.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[9 Ways](#9ways) [Definition](#definition)
[Affect on Eye Health](#affects)
[How to Choose UV Protection Glasses](#choose)
## 1. Never Gaze Directly at the Sun
To protect the eyes from ultraviolet light, try to never gaze directly at the sun as it burns the exposed tissue of the
retina in the eyes.
According to the Australia Academy of Science, this is known as solar
retinopathy and it destroys the cones and rods in the eye and may even
create a blind spot in a person’s central vision, known as a scotoma. To
prevent sun damage to the eyes, never stare directly at the sun and also
wear sunglasses when outside to shield the eyes from damage. If you
believe you may have burned or irritated your eyes by looking at the sun,
book an appointment with an optometrist to have your eyes assessed.
## 2. Put on Sunglasses
Sunglasses are the main way to protect the eyes from ultraviolet rays emitted by the
sun. Sunglasses are a type of eyewear worn to shield the eyes from harm by
reflecting UV rays, acting as a barrier. For maximum protection, [sunglasses](https://www.oscarwylee.com.au/glasses/eye/sunglasses)
with lens category 3 and a wraparound frame are best. The lens category
measures the effectiveness of UV blocking on a scale of 0-4, according to
the Cancer Council. They also recommend that sunglasses should be worn
when the UV level is 3 or above, which is common in Australia as we are
near the equator. Wraparound sunglasses are close fitting frames that
offer high protection from UV rays as they sit close to the face to
prevent the sun from hitting the eyes. Sunglasses should be worn all year
round as the sun can still cause eye damage even when it is cloudy.
## 3. Wear a Hat for Additional Protection
UV sunglasses are not 100% effective at protecting the eyes from the sun
as they are still exposed through the sides of the sunglasses. Wearing a hat can provide additional protection that not only shields the
eyes but also the skin on a person’s face. To get the maximum protection out of wearing a hat, choose one with a
wide brim as it provides more coverage for the eyes and face. A hat is
also a great way to protect your child’s eyes as they may be resistant to
wearing sunglasses or take them off frequently. According to the National
Eye Institute, the simplest way to protect the eyes from ultraviolet light
from the sun is to wear sunglasses and a hat.
## 4. Avoid Using Low-Quality Sunglasses
To adequately protect the eyes from the sun, it is important to avoid
using low-quality sunglasses. Using low-quality sunglasses may leave you at risk of developing eye
conditions that are linked to UV exposure.
These eye conditions include cataracts and eye cancer. Expensive
sunglasses do not mean they will be better at UV protection, rather it is
the lens category that should be considered when choosing sunglasses.
According to the National Eye Institute, you should choose sunglasses that
are marked as a UV400 rationing or provide 99% to 100% protection from UVA
and UVB.
## 5. Steer Clear of Artificial Sources of UV radiation
UV (ultraviolet) light is a type of non-ionising radiation that is
emitted by the sun, but that is not the only source of UV radiation, so
for further eye protection make sure to steer clear of artificial sources
of ultraviolet light. Sources of artificial UV radiation include tanning beds, welding arcs, mercury vapour lighting, some incandescent
lights and some types of lasers
according to the Centers for Disease Control and Prevention. There are
certain jobs and workplaces that come into contact with artificial UV
radiation such as welding, curing lamps, black lights, germicidal lamps
and high-intensity lighting including halogen lights and mercury vapour
lamps according to the Australian Radiation Protection and Nuclear Safety
Agency.
## 6. Implement Effective Sun Protection Practices
It is important to implement effective sun protection practices to
protect the eyes and your overall health. Effective sun protection
practices include wearing sunglasses, wearing a hat, using sunscreen, seeking shade and
wearing protective clothing such as long sleeves. For eye protection, wear sunglasses with at least a lens category of 2,
although the higher the better. For extra protection, wear a wide-brimmed
hat to provide more cover for the eyes. For overall skin protection, seek
shade where possible to limit sun exposure and also wear protective
clothing such as long sleeves and long pants. Use sunscreen and make sure
to reapply often to protect the skin from sun damage.
## 7. Arrange an Annual Eye Check-Up
Booking or arranging an annual eye check-up is crucial in maintaining the health of
the eyes and detecting signs of sun damage. It is recommended that you should have an eye test at least once every
two years and every year if you are over the age of 65. Regular eye tests
allow an optometrist to monitor the health of your eyes and any changes
that have occurred. Eye tests are also key in the early detection of eye
diseases which in some cases can be crucial for preventing vision loss or
other issues. An eye test will involve tests to examine eye health and
assess a person’s vision. If you are in need of an eye test, you can
easily book online at Oscar Wylee and see our friendly optometrists
in-store who will assess your eyes.
## 8. Consider Using Transition Lenses
Transition lenses, also known as photochromic lenses and adaptive lenses,
are
a great solution for people who need vision correction but don’t
want to switch between sunglasses and glasses throughout the day. [Photochromic lenses](https://www.oscarwylee.com.au/glasses/eye/photochromic-lenses)
are made with a chemical coating that causes the lens to darken in response
to direct sunlight. The more rays the adaptive lenses are exposed to, the
darker they will become. At Oscar Wylee, we offer photochromic lenses for
all lens indexes and Transitions® lenses in 1.5,&nbsp; 1.61 and 1.67
indexes. Transitions® GEN S ™ lenses are durable and
long-lasting, available in grey, brown, sapphire, graphite green, ruby,
emerald, amethyst and amber lens colour options.
## 9. Safeguard the Eyes of Children
It is important to protect and safeguard children's eyes from ultraviolet
rays as children spend much of their time outdoors. According to the Mayo Clinic, children’s eyes are still developing and
maturing, therefore, they have more difficulty in filtering out harmful UV
rays as effectively as adults. At Oscar Wylee, we have a children's
sunglasses frame, Chip. Chip is lens category 3 and is a perfect frame for
older kids as a general purpose sunglasses with high protection against
sun glare and good UV Protection. The sunglasses frames are also designed
to be durable, perfectly paired with the energetic lifestyle of kids. Just
as you would make sure your child is protected with sunscreen, it is
important to protect their eyes with sunglasses.
Get a Full Quote in Store
Get fitted for your glasses at Oscar Wylee by visiting us in store and
talk to our friendly staff for a complete quote.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
## What is Ultraviolet Light?
Ultraviolet light, also known as UV light, is a form of electromagnetic radiation that is invisible to humans as it has
a very short wavelength
according to the National Eye Institute. There are three different types
of ultraviolet light which are UVA, UVB and UVC. According to the Centre
for Disease Control and Prevention (CDC), UVA has a wavelength of 315-399
nm and is not absorbed by the ozone layer, UVB has a wavelength of 280-314
nm and some of the light reaches the Earth’s surface and UVC has a
wavelength of 100-279 nm and it is completely absorbed by the ozone
layer.
### How Does Ultraviolet Light Affect Eye Health?
Ultraviolet light can have a negative effect on [eye health](https://www.oscarwylee.com.au/glasses/eye/anatomy)
especially if there is no attempt at protecting the eyes with sunglasses
or a hat.
According to the American Academy of Ophthalmology, excessive sun
exposure can increase a person’s risk of developing cataracts, eye
cancer, growths on or near the eye and sunburned eyes. The sun is also
powerful enough to burn the tissue on a person’s retina if they stare at
it for too long, which is known as solar retinopathy. In summary, UV
light is bad for your eyes as it can lead to serious eye conditions and
also cause immediate damage to your eye health which is why it is
important to wear protective eyewear and take other sun safety
measures.
#### Does Ultraviolet Light Cause Astigmatism?
Ultraviolet light may cause astigmatism due to a growth on the eye. A growth on the eye is called a pterygium and is fleshy tissue that
covers the conjunctiva which usually grows from the inner corner of
the eye, assumed to be caused by exposure to UV light. A pterygium is
a benign growth that can lead to diminished vision as it changes the
curve of the eye, leading to [astigmatism](https://www.oscarwylee.com.au/glasses/eye/astigmatism). Vision can also be affected by a pterygium as the growth grows
large which pulls the cornea or covers the cornea which obstructs a
person's line of vision.
### How Does Ultraviolet Light Differ From Blue Light?
Blue light and ultraviolet light differ in their wavelength as blue light has a wavelength of 400-495 nm
and ultraviolet light measures 10-400 nm
which is not visible to the human eye,&nbsp; according to the Centre for
Science Education. At Oscar Wylee, we offer a blue light filter add-on
for our optical glasses which can be helpful for people who spend
prolonged periods of time on screens such as at work, school or when
gaming.
### What are the Sources of Ultraviolet Light?
The main source of ultraviolet light is the sun but it can also be emitted
from artificial sources including tanning beds, UV lamps and arc
welding.
Phones or other digital devices do not emit UV light. According to the
Centers for Disease Control and Prevention, there are three types of UV
radiation rays which are UVA, UVB and UVC.
## How Do UV Eye Protection Glasses Protect the Eyes?
UV protection sunglasses protect the eyes by acting as a protective
barrier or shield between the eyes and the sun. The lenses in sunglasses
have a special coating which reflects, blocks and absorbs UV light so that
it does not penetrate the eyes. There are different types of [UV eye protection sunglasses](https://www.oscarwylee.com.au/glasses/best-uv-sunglasses-for-eye-protection)
that may be better for your lifestyle or prescription needs.
### How are UV Eye Protection Glasses Made?
UV eye protection glasses are made just like other glasses although the lenses will be tinted and
have a coating applied to shield the eyes from ultraviolet rays. At Oscar Wylee, we have an intricate production process for our
frames; they are hand-crafted and hand-assembled to ensure they meet our
high standards and the standards of our customers. Our process involves
initial production, polishing and tumbling the frames, constructing the
frames, fitting the lenses and quality control.
## How Long Do UV Eye Protection Glasses Last?
Sunglasses eventually lose their UV protection due to wear, tear and extensive
use. According to FOX Weather, you should replace your sunglasses every two
years if you are using them regularly as the UV protection deteriorates.
Scratches on the lens surface and crazing of the lenses can also impede
the sunglasses' ability to block UV light. To protect your sunglasses from
scratches, keep them in a case when they are not being used. To adequately
protect your eyes from ultraviolet light, make sure you are using
sunglasses that have a good UV coating on the glasses and are not too
old.
### How to Choose UV Eye Protection Glasses?
To choose the best UV eye protection sunglasses for you there are three main things to consider; lenses, frames and what they will be
used for.
For lenses, you should select sunglasses that have a lens UV protection
category of at least 2 and preferably 3. Sunglasses frames can be chosen
for many reasons such as style, functionality and eye protection. For
the ultimate protection from UV light, you should choose wraparound
frames that sit close to the face and shield the eyes by blocking the
sun from the side. In terms of what they will be used for, there are
different types of sunglasses lenses that may benefit your lifestyle or
prescription needs. Adaptive lenses are a great option for people who
need vision correction as the lenses go from clear to dark in response
to UV light. Meaning inside, the glasses will be clear but once you are
in the sun they will become tinted to protect the eyes from the sun.
Polarised lenses are another type of sunglasses that are good for people
who fish as they allow the wearer to see through a body of water by
reducing glare on the water’s surface.
#### Where to Buy UV Eye Protection Glasses?
You can buy UV protection lenses and glasses from many different places such as online retailers, and glasses and
sunglasses stores.
At Oscar Wylee, we offer a wide range of sunglasses that offer good UV
protection in different [types of lenses](https://www.oscarwylee.com.au/guides/lenses)
to fit your needs. We have wraparound sunglasses that provide extra
coverage for the eyes as they sit close to the face, blocking more UV
light. You can add polarisation which offers UV protection as well as
filters out reflected light and surface glare for greater clarity. We
offer adaptive lenses which are a great option for people who need
vision correction as these lenses change from clear to dark in
response to UV light.
### How Much Do UV Eye Protection Glasses Cost?
The cost of UV protection glasses varies depending on the frame, lenses, add-ons, level of UV protection
and brand.
At Oscar Wylee, we have multiple lenses for sun protection sunglasses
such as tinted, polarised and adaptive. Our tinted lenses are available
in seven colours which are grey, brown, green, pink, blue, silver and
orange and are an additional $30 on top of the price of a standard pair
of frames. Our polarised lenses offer good UV protection and include our
free Basic Anti-Reflective coating and are $100 on top of the price of
standard frames. Adaptive lenses are another name for photochromic
lenses that darken in response to ultraviolet light and are an
additional $100.
## Who Should Wear UV Eye Protection Glasses?
It is recommended that
everyone should wear UV eye protection glasses as no one is immune from
the damaging rays emitted by the sun.
Both children and adults should wear sunglasses, children especially as
their eyes are not fully developed making it harder to block UV light.
People who work long hours in the sun such as a lifeguard or in
agriculture should take extra precautions such as wearing protective
clothing, wide-brimmed hats and wraparound sunglasses for maximum
coverage, as well as using and reapplying sunscreen throughout the
day.&nbsp;Everyone should wear sunglasses when outside even when it is
cloudy as you can still be affected by the UV light.
### Is it Recommended for Kids to Wear UV Eye Protection Glasses?
Yes, it is recommended for kids to wear UV eye protection sunglasses as they
can shield the eyes from harmful ultraviolet rays.
Kids spend much of their time outdoors meaning their eyes and skin need
to be protected with sunglasses, sunscreen, a hat and protective
clothing. Children are also more vulnerable to ultraviolet rays as their
eyes are not fully developed and cannot filter out harmful light like
adult eyes can, according to the Mayo Clinic. Therefore, children should
be equipped with sunglasses that have good protection against UV
light.
#### Is it OK to Wear UV Eye Protection Glasses All Day?
Yes, it is OK to wear UV eye protection sunglasses all day to shield the
eyes from harmful rays emitted by the sun.
While you can wear sunglasses all day, you do not need to wear them
when inside or in the shade but they can and should be worn at the
beach, when in the car and when outside on a walk or run. A great way
to wear UV eye protection all day without switching glasses is with
adaptive lenses. Adaptive lenses, professionally known as photochromic
lenses, change from clear to darker opacity to adapt to light
conditions.
### Is it OK to Wear UV Eye Protection Glasses at Night?
Yes, it is ok to wear UV eye protection glasses at night although they are
not necessary as there is no sun or ultraviolet light to protect the
eyes from. It is important to not wear tinted lenses when driving at night as
they can impede your vision when on the road. Instead of UV protection
glasses, people should wear glasses that have an anti-reflective coating
at night. An anti-reflective coating is helpful when driving at night as
it reduces glare from other cars such as their headlights as well as
from street lights.
#### Do Night Driving Glasses Have UV Protection?
No, typically night driving glasses do not have UV protection as they are
designed to block reflection from headlights of other vehicles and
from streetlights, not shield the eyes from ultraviolet light. [Night driving glasses](https://www.oscarwylee.com.au/glasses/night-driving)
will often have lenses with an anti-reflective coating and can be
prescription or non-prescription. Sunglasses with UV protection are
worn to protect the eyes from damage caused by the sun.
#### Is Wearing UV Eye Protection Glasses Worth It?
Yes,
wearing UV eye protection sunglasses is worth it as extended exposure
to the sun can increase a person’s risk of eye cancer, cataracts and
growths on the eye such as pterygium. Therefore, wearing sunglasses with UV protection can lower the risk
of developing these eye conditions. UV sunglasses should be good
quality and provide protection against the sun’s UV rays with a
minimum of lens category 2.
#### What are the Benefits of UV Protection Glasses?
There are many benefits of UV protection sunglasses, the most important being
shielding the eyes from harmful ultraviolet rays emitted by the
sun.
Sunglasses also protect the eyes from potentially harmful elements
such as dust, wind, sand and snow. The other benefits include
comfortable vision when it is bright, they may reduce glare and eye
strain and also help protect the skin around the eyes from the
sun.
##### What are the Downsides of UV Protection Glasses?
There are not any particular downsides to UV protection sunglasses, rather
they are extremely beneficial to wear
when outside as they shield the eyes from the sun. The downside
people may experience is having to switch glasses as they need
vision correction, but that can be solved with prescription
sunglasses or adaptive lenses where the lenses darken in response to
UV light. For people who are worried about glare, you can add
polarisation onto the lenses which cut out glare on the horizontal
wavelength, making them great for driving, running and
fishing.
#### Do all Sunglasses Have UV Protection?
No, not all sunglasses have UV protection
and there are different levels of protection that should be considered
when buying sunglasses. The different lens categories of UV protection
according to the Cancer Council are lens category 0 which provides
some UV protection and very limited reduction of sun glare. The next
is lens category 1, which provides limited protection against sun
glare and some UV protection. Lens category 2 provides good UV and sun
glare protection. Next is lens category 3, which provides high
protection against sun glare and UV. Finally, the highest category is
lens category 4 which are special purpose sunglasses that provide good
UV protection and high protection against extreme sun glare. UV
protection on glasses is worth it as it shields the eyes from harmful
sun rays.
### Is UV Protection the Same as SPF
No, UV protection is not the same as SPF. UV is an acronym for ultraviolet which in this context stands for
ultraviolet light or radiation which is emitted from the sun and other
artificial sources. Protection from UV light includes wearing
sunglasses, sunscreen and protective clothing. SPF stands for sun
protection factor and according to the Skin Cancer Foundation, it is
based on the time it takes for UV-exposed skin to redden and refers to
sunscreen.
### What is the Difference Between UV Protection Lenses and Polarised Lenses?
The difference between UV protection lenses and polarised lenses is the
main purpose of the lenses.
UV protection sunglasses are designed to protect the eyes from
ultraviolet radiation emitted by the sun by reflecting or absorbing
these harmful rays. These sunglasses reduce a person’s risk of
developing certain eye conditions that are caused by prolonged sun
exposure such as eye cancer and cataracts. The main role of polarised
lenses is to reduce reflections and glare on surfaces by filtering out
intense reflected waves. Sunglasses with polarisation also offer UV
protection although it varies depending on the type of lenses.
Ultimately in the debate of polarised vs UV protection, it is best to
find a pair of sunglasses that do both.
Read UV Eye Protection Glasses: Importance and Benefits in other Oscar
Wylee regions and their languages.
Australia
[Australia](https://www.oscarwylee.com.au/glasses/eye/uv-protection)
[Canada](https://oscarwylee.ca/glasses/eye/uv-protection)
[Canadian French](https://oscarwylee.ca/fr/glasses/eye/uv-protection)
We Accept Major Health Funds In-Store
Visit Oscar Wylee in-store and our team can help you with your health
fund claims.
[Explore health funds](https://www.oscarwylee.com.au/health-funds.html)
Prioritise Your Eye Health
Book an appointment with one of our trusted and skilled optometrist for
your regular eye check-ups.
[Book an eye test](https://www.oscarwylee.com.au/booking)