# Source: https://www.oscarwylee.com.au/locations/optometrist-forest-hill.html

# Optometrist Forest Hill
Forest Hill Chase Shopping CentreT110, 270 Canterbury RoadForest Hill VIC 3131
* Near Woolworths
Opening hours
Monday9:00am - 5:30pm
Tuesday9:00am - 5:30pm
Wednesday9:00am - 5:30pm
Thursday9:00am - 7:00pm
Friday9:00am - 7:00pm
Saturday9:00am - 5:00pm
Sunday10:00am - 5:00pm
*Store hours reflect local standard trading hours and exclude public holidays
[Visit our Forest Hill Google Business page for directions, reviews, and updates.](https://g.page/r/CbigE_1RHAg0EBM)
Book Appointment
[Call us: (03) 8806 3988](tel:(03) 8806 3988)
[Leave a Review!](https://g.page/r/CbigE_1RHAg0EBM/review)
Our Reviews
Paddy Doyle
1 week ago
Emma and Adam are fantastic. Such great service at Oscar Wyler Forest Hill.
natasha
1 week ago
Oscar Wylee at Forest Hill Shopping Centre have bent over backwards to try and manage the best presc...ription for my glasses. They have been nothing but helpful and supportive in making sure I have the correct glasses. I have very much appreciated all of their assistance.
See more
David Coulson
1 week ago
Awesome all round.
Karen Stewart
2 weeks ago
Excellent service. Staff were very good.
Sigi Gee
3 weeks ago
Helen Sorenson
1 month ago
Excellent friendly service
Mocking Bird
1 month ago
I would like to express my sincere appreciation to the store manager and the staff member who assist...ed me with my recent enquiry.
I had a pair of glasses that were already outside the warranty period, and unfortunately, one of the arms had broken. I was expecting that there might not be much that could be done. However, instead of simply saying no, the store manager went above and beyond by contacting another store and finding a spare part for me.
This level of care and effort was truly unexpected, and it made a huge difference. It’s clear that this wouldn’t have been possible without their help and willingness to go the extra mile.
Thank you both for the excellent customer service and for taking the time to help me. I really appreciate your effort and professionalism. Outstanding service!
See more
Matilda Brokenshire
1 month ago
Very friendly and efficient, straight in and out!
Kathy Battersby
1 month ago
All staff were very helpful and thorough.
Will definitely  visit here again
Sam Grillo
1 month ago
Bannet Gamalath
1 month ago
Jenny Healey
1 month ago
I was very impressed with the service provided.  The optometrist Andrew and his assistant Hannah wer...e outstanding in their professionalism and customer service.  My eye examination was conducted with the utmost knowledge and attention to detail.  My thanks to Andrew and Hannah for their assistance.
See more
Jo Cleeman
1 month ago
The staff have all been very attentive and patient with me, fantastic customer service!
Kate B
1 month ago
Very thorough eye exam with clear explanations from both staff members. Thank you so much for explai...ning things to me and being very personable.
See more
Tommy Mao
2 months ago
Amazing service from Amber &amp; Kevin, highly recommend…will be back!
Daniella Fiumara
2 months ago
Fantastic And excellent examination of my Eyes. A very warm and friendly environment.
Zaiga Bendrups
2 months ago
Just went for regular eye check after 3 years. The Optometrist was welcoming and friendly. He explai...ned to me how my test went in “plain English” so that I could understand. Great experience. The choosing new frames was a breeze. The young lady who helped was also friendly and chose with me some great frames. Thanks to you both for your help and friendliness! Highly recommend going to Oscar Wylee at Forest Hill!
See more
Christian Patone
3 months ago
Nello Nigro
3 months ago
My eye test was great and very quick &amp; efficient.
Supratik Choudhury
3 months ago
Andrew is fantastic
Nirangi de silva
4 months ago
very professional and thorough
Maurice Molan
5 months ago
Great service all the way through the eye test and glasses selection. Good job ????
Julie Hitches
5 months ago
Great customer service, all explained very clearly.
Lauren Conjab
6 months ago
Helpful and lovely boys :)
Jess K
6 months ago
My year old glasses arm snapped off and they popped my lenses into new frames free of charge! Seamle...ss process and so helpful ????????
See more
Jessica Peart
6 months ago
I had such an easy, enjoyable experience here. Hannah and Emma helped me pick out frames that really... suited me and were both so lovely, patient, and kind.
See more
Tania Torres
6 months ago
I had the pleasure of having Emma look after my fiancé and myself, and her service was absolutely wo...nderful. From the moment we walked in, Emma and her team made us feel genuinely welcomed and comfortable.
One staff member kindly assisted me with browsing for glasses while Emma completed the pre-checks for my fiancé’s eyes, which made the whole experience relaxed and stress free. We both received a very thorough and comprehensive eye examination, and honestly, I gained more information from the optometrist Andrew at Oscar Wylee Forrest hill than I ever have from any other optometrist.
Thank you to Emma and the entire team for such exceptional service today. I can’t wait for my new spectacles to arrive!
See more
Anthony Yeo
7 months ago
Very competent
June Hodge
7 months ago
Staff very attentive giving me plenty of time to make my decision.
Andrew was able to answer my ques...tions and gave me options to choose from.
See more
Alexandra Papageorgiou
7 months ago
I had a really great experience at Oscar Wylee. Andrew was extremely professional, efficient, and to...ok the time to explain everything very thoroughly, which I really appreciated. I’ve been going to this store since it opened at Forest Hill, and the level of care and service has always been excellent. I wouldn’t go anywhere else and will definitely continue attending in the future. Highly recommended!
See more
Megan Menezes
9 months ago
I had my eyes tested at Forest Hill this week and the experience was outstanding. Sarju, the optical... dispenser and keyholder, was incredibly patient and talked me through each step of the eye test so I knew exactly what was happening. She also helped me choose frames that suited my face shape perfectly. On top of that, she suggested I consider getting sunglasses as well, as it would be more cost-effective — a great example of her sharp thinking and genuine care for customers. Highly recommend!
See more
florence webster
9 months ago
I recently had an eye test here and had a great experience. The staff were friendly, professional, a...nd made me feel very comfortable throughout the appointment. Everything was clearly explained, and the service was efficient and thorough. Highly recommend—thank you!
See more
Shehzad Bana
10 months ago
The responses given to my questions were very satisfactory. The staff (at reception and doctor) were... welcoming) and good guides. The only request would be to have a more detailed prescription.
Thank you
See more
Josie Angeles
11 months ago
Very approachable staff:)
Nadia Caruso
11 months ago
Friendly staff
sammy cooke
1 year ago
Louise Tse
1 year ago
Danny Pham
1 year ago
The receptionist and Andrew were very friendly and professional.  They checked my vision and eye hea...lth thoroughly and gave me the best option for prescription glasses.  Generally, I am very happy with the frames and the cost that I was quoted.  Highly recommend this store!!!
See more
Ken Russo
1 year ago
Very friendly and thorough service.
David Le
1 year ago
Straight to the point pleasant experience. Job completed
Loztek camp
1 year ago
Amazing and professional services
Staff at Foresthill are fantastic
Melinda Coulson
1 year ago
Andrew the optometrist was thorough and informative and didn’t automatically make me purchase glasse...s like other places. He was considered and easy to understand and I felt comfortable discussing my eyes with him.
See more
Veronique Morel
1 year ago
Thank you , That was really kind of you , I really appreciate your help that means a lot to me I’m s...o grateful for your time and effort ????
See more
ZHANG YOLANDA
1 year ago
Really good experience, very professional advice
Alan Shu
1 year ago
Very good service, eye test was very standard.  Good advice from the optometrist to reduce pressure ...on the eyes.  Overall very happy!
See more
Beverley Goldsworthy
1 year ago
The attention was very thorough, thank you.
Cat Lovely
1 year ago
Highly recommend!
Had a wonderful friendly experience
Hannah was lovely &amp; very helpful
Great range o...f frames to choose from.
See more
Ellen Gildersleve
1 year ago
Had a pleasant and professional experience here for my check-up yesterday. The lovely girl who helpe...d me first was so friendly and we ended up having a really great conversation! Unfortunately didn’t get her name but she was in Thursday morning as the store opened. The Optometrist was also amazing and professional, made sure I understood the whole process. Great experience overall.
See more
Silvia RQ
1 year ago
Excellent experience at Forest Hill branch. I will continue to give them my business. It was a pleas...ure to deal with them. The staff is very professional and empathetic, they go above and beyond. Thank you so much.
See more
Graham Smith
1 year ago
Was a good experience at Oscar Wylee Forest Hill, both professional and friendly, definitely recomme...nd.
See more
## Find an Optometrist in Forest Hill Chase With Oscar Wylee
You can find our Oscar Wylee store in the Forest Hill Chase Shopping Centre. Located on the ground floor opposite Boost Juice, our skilled optometrists can provide Medicare bulk billed eye health tests. Equipped with the latest optometry technology, our Forest Hill Chase team provide important eye care processes including helping customers to get their vision tested, as well as examine the eyes for conditions or eye diseases. If it’s a new pair of stylish and affordable glasses you are after, our knowledgeable retail team can help you shop your perfect frame, whether that’s optical glasses, prescription sunglasses or non-prescription glasses. 
To make your appointment with us you could drive here, with the centre offering over 3500 free car parking spaces, or you could take one of the many buses that service the surrounding streets. Once here, why not make the most of your journey and explore all the retail and entertainment options on offer at Forest Hill Chase. You could catch a movie at Hoyts or shop the latest fashion at Cotton On. If you live close to Blackburn, Burwood or Vermont areas, Oscar Wylee optometrists near you also include Oscar Wylee Doncaster.        
Meet Our Team
* Optometrist
B.Biomed
D.Optom
* Store Manager
Our Services
* Bulk Billed Eye Examinations
* Professional Frame Styling
* Frame Adjustments and Repairs
* Visual Fields Testing
* Digital Retinal Scanning
Show All
## Find an Optometrist in Forest Hill Chase, Victoria for an Eye Health Test
If you are in need of an eye health test, you can find an optometrist in Forest Hill Chase, where there are a variety of optometry services available. At our Oscar Wylee glasses store in Forest Hill Chase, our dedicated optometrists are available in-store to perform eye tests including vision assessment and the detection of eye diseases. Our optometrists can also refer patients to an eye doctor, also known as an ophthalmologist in Australia if advanced care is needed. Our knowledgeable retail staff, including an optical dispenser, are also available in-store to help customers shop for a new pair of stylish frames, including prescription glasses, prescription sunglasses and non-prescription eyewear.
The price of an optometrist appointment in Victoria can be dependent upon a person’s individual eye care needs. However, at Oscar Wylee Forest Hill Chase, Victoria, our eye tests are available at a bulk billed price as part of Australia’s Medicare system. This means there are no out-of-pocket expenses for eligible cardholders. If you are in need of an eye health test in Forest Hill Chase, Victoria come and visit the team at Oscar Wylee for dedicated eye care services.
## How to Find an Optometrist in Forest Hill Chase, Victoria?
To find an optometrist in Forest Hill Chase, Victoria you can take certain steps that can help make it easier for you such as searching online, assessing the store’s opening hours and finding the directions to your chosen location. The steps on how to find an optometrist in Forest Hill Chase, Victoria are listed below.
1. Search online using the phrase, Forest Hill Chase optometrist near me. This can also be done here on the website via our locations page.
2. Click on the Oscar Wylee link, which will take you directly to our Forest Hill Chase optometrist store page.
3. See the store’s opening hours and where the store is located specifically.
4. Use the Forest Hill Chase Google Business page link located under store hours to see the directions on how to get to the store.
You can also find an optometrist in Forest Hill Chase, Victoria by searching the keywords optometrist near me. If you have locations enabled on your smartphone and you’re in the Forest Hill Chase, Victoria area, our Forest Hill Chase store page should appear easily for you to click on.
### Is it Hard to Get an Eye Appointment in Forest Hill Chase, Victoria?
No, it is not hard to get an eye appointment in Belconnen. You can easily book an appointment to see an Oscar Wylee optometrist in Forest Hill Chase, Victoria right here on this page. At Oscar Wylee we have highly qualified optometrists available for bulk billed eye appointments, which can be booked online or in-store.
#### How to Compare Optometrists in Forest Hill Chase, Victoria to Each Other?
To compare optometrists in Forest Hill Chase, Victoria, you can use factors such as eye tests offered, health fund coverage, lens types and add-ons and eyewear offered. To take care of your vision and eye health, it is important to receive an eye test at least once every two years. There are different types of tests that can be performed in an eye test and not all optometrists may offer the same tests. Health funds can be used to help cover some of the cost of your frames and lenses. To find out if your health fund is accepted at an optometrist in Forest Hill Chase, Victoria visit their website. In the case of Oscar Wylee, we accept all major health funds and provide on-the-spot claims in-store. There are many different lens options available for prescription glasses such as single vision, multifocal and high index lenses. Most optometrists in Forest Hill Chase, Victoria will offer these lenses although it is good to make sure. There are also lens add-ons available to enhance your glasses such as anti-reflective and blue light filters. Finally, if you are looking to purchase a pair of glasses after your eye test, you can compare the different styles and colours you are interested in from the optometrists in Forest Hill Chase, Victoria. Oscar Wylee offers a wide range of frames with vintage and modern inspirations in bold colours and subtle designs.
#### How to Find an Eyeglasses Shop in Forest Hill Chase, Victoria?
To find a glasses store in Forest Hill Chase, Victoria you can try to follow these simple steps including searching online, selecting a convenient location and looking at their health insurance policies. The steps on how to find a glasses store in Forest Hill Chase, Victoria are listed below.
1. Search online using the phrase, glasses store in Forest Hill Chase, Victoria. This will provide you with various options for glasses stores in the whole Forest Hill Chase, Victoria area.
2. Select a glasses store that is most convenient for you to travel to.
3. Click the link to find out more information such as opening hours, exact location and directions to the glasses store in Forest Hill Chase.
4. Read their health insurance policies to ensure you know what health benefits you have access to.
Our Oscar Wylee glasses store in Forest Hill Chase, Victoria offers primary eye care services such as comprehensive eye tests as well as other services performed by an optometrist and offers prescription and non-prescription eyewear.
##### Is it Possible to Purchase Prescribed Sunglasses in Forest Hill Chase, Victoria Without Seeing an Optometrist?
Yes and no, it is possible to [purchase prescribed sunglasses](https://www.oscarwylee.com.au/sunglasses.html) in Forest Hill Chase, Victoria without seeing an optometrist if you already have a prescription that has not expired. If your prescription is expired, you can book an eye test to receive an updated or new prescription which will require you to see an optometrist. This will ensure your prescription sunglasses are appropriate for your visual needs.
## Where is the Oscar Wylee Forest Hill Chase, Victoria Optometrist Located?
The Oscar Wylee Forest Hill Chase optometrist is located in the Forest Hill Chase Shopping Centre near Woolworths. The Forest Hill Chase Shopping Centre can be found on Canterbury Road, Forest Hill, which is a suburb in Melbourne, Victoria.
### What is the Phone Number of Oscar Wylee Forest Hill Chase, Victoria Optometrist Store?
The phone number for our Oscar Wylee Forest Hill Chase, Victoria optometrist store is (03) 8806 3988. Our Oscar Wylee Forest Hill Chase, Victoria store is open, and our staff are available to be contacted, between the hours of 9 am and 5:30 pm from Monday to Wednesday, 9 am and 9 pm on Thursdays and Fridays, 9 am and 5 pm on Saturdays and 10 am and 5 pm on Sundays.
### What are the Reviews for Oscar Wylee Forest Hill Chase, Victoria Optometrist?
The reviews left by customers for our Oscar Wylee Forest Hill Chase store can be found here on the website as well as online when you search for Oscar Wylee Forest Hill Chase optometrist. The reviews for Oscar Wylee Forest Hill Chase optometrist are listed below.
* Tara Stapleton:  Amazing service. Staff were friendly, thorough, thoughtful, knowledgeable and really skilled in all aspects of their job, especially choosing the perfect frames to suit my face. I haven’t had such great service in a long time. I would definitely recommend the Forest Hill branch for all your optical needs.
* Natalie Humphries:  Excellent service- optometrist Andrew was very informative and the staff helping choose the glasses were very helpful too.
* Brian Mckelvey:  I came in recently to purchase two pairs of glasses and immediately knew I was in good hands when I saw how well the shop assistants' glasses framed her face! I was unsure of what I needed, but Chelsea was extremely helpful, patient and friendly, making my experience at Oscar Wylee extremely positive and pleasant.
#### What Treatments or Eye Care Processes are Done in the Oscar Wylee Forest Hill Chase, Victoria Optometrist Location?
The treatments or eye care processes done in the Oscar Wylee Forest Hill Chase, Victoria optometrist location include a tonometry test, a digital photograph, a slit lamp exam and a refraction test. Additional tests that may also be performed can include a visual field test and a dilated fundus exam. The treatments or eye-care processes that are done in the Oscar Wylee Forest Hill Chase optometrist location are listed below.
* A Tonometry Test: An optometrist or optical dispenser will conduct a tonometry test which involves the use of a machine that will release small puffs of air into your eyes. This will assist with measuring pressure in the eye.
* A Digital Photograph: An optometrist or optical dispenser may take a digital photograph of your eye which can be kept on record to use in future appointments to evaluate any changes to your eye.
* Slit Lamp Test: A slit lamp test can be used to evaluate your eye health, by examining your cornea and iris which are the anterior and posterior of the eye.
* Refraction Test: During a refraction test, an optometrist will have you view an image through different lenses and ask you to confirm which helps you see the image clearer.
* Visual Field Test: A visual field test can assist with assessing your peripheral vision, which may be beneficial for identifying any signs of glaucoma.
* Dilated Fundus Exam: A dilated fundus exam can help an optometrist assess your health in more detail by getting a clear view of the retina. This test is typically carried out for patients with diabetes and those who may be at risk of developing retinal damage.
## How Many Optometrists Exist in Forest Hill Chase, Victoria?
There are a variety of optometrists that exist in the Forest Hill Chase Shopping Centre in Victoria including Oscar Wylee. The amount of optometrists available in an area will typically depend on the population and the demand for eye care services. At Oscar Wylee Forest Hill Chase, Victoria, our team is passionate about providing our customers with high-quality, dedicated eye care. Our in-store optometrists are available to provide customers with eye tests, bulk billed for eligible Medicare cardholders. Our knowledgeable retail staff are also available to help you choose a new pair of frames from our stylish range and ensure they are the right fit for your eye care needs. If you are looking for an optometrist in Forest Hill Chase, Victoria, visit Oscar Wylee for dedicated eye care services.
### What are the Other Closest Optometrist Locations to Forest Hill Chase, Victoria in Australia?
The other closest Oscar Wylee optometrist locations to Forest Hill Chase, Victoria in Australia are Melbourne Central, Doncaster and Dandenong Plaza. The other closest optometrist locations to Forest Hill Chase, Victoria are listed below.
* Melbourne Central: Melbourne Central is located approximately 26 km away from Forest Hill Chase and is home to several optometrists including Oscar Wylee. [Oscar Wylee Melbourne Central](https://www.oscarwylee.com.au/locations/optometrist-melbourne-central.html) is located in the Melbourne Central Shopping Centre. Come and visit our optometrists at Oscar Wylee Melbourne Central who provide eye tests and prescription updates. You can also find our stylish selection of frames in-store.
* Doncaster:  Doncaster is a suburb in Melbourne, around 10 km away where you will find a range of optometrists. [Oscar Wylee Doncaster](https://www.oscarwylee.com.au/locations/optometrist-doncaster.html) is located in the Doncaster Westfield Shopping Centre, where our optometrists are available to perform eye tests and our retail team can help customers shop new frames.
* Dandenong: Dandenong is a Melbourne suburb, approximately 22 km away from Forest Hill Chase where there are several optometrists available, including Oscar Wylee. [Oscar Wylee Dandenong Plaza](https://www.oscarwylee.com.au/locations/optometrist-dandenong.html) is located on level 3 of the Armada Dandenong Plaza Shopping Centre, where our team provide a range of eye care services including eye tests and new frames.
### Oscar Wylee Forest Hill Medicare Bulk Billed Eye Tests
Oscar Wylee Forest Hill Chase offers a range of eye care services such as Medicare bulk billed eye tests, same-day prescriptions and new frames. Our dedicated and highly trained optometrists can conduct your quick and efficient eye test in approximately 20 minutes. For some of the best optometrist services in Forest Hill, Australia, come and visit the team at Oscar Wylee Forest Hill Chase.
### Health Funds Accepted In-Store
Oscar Wylee Forest Hill Chase accepts major health funds in-store. Come and visit the Forest Hill Chase team and they can process your claim in-store with a valid health fund card, as well as answer any questions about making a claim with us. Whether it’s an eye test or new optical frames that you need, visit Oscar Wylee Forest Hill Chase and your health fund may help cover some of the costs.
### Frames for Every Face Shape
At our Osar Wylee eyeglasses shop in Forest Hill Chase, our store offers prescription glasses, prescription sunglasses and non-prescription glasses, in a variety of modern and vintage-inspired styles. Oscar Wylee also has a range of add-ons including, blue light filter lenses, and more. Our experts in-store at Forest Hill Chase will help you choose what’s best for you, and you’ll leave our store with a pair of prescription glasses that are your perfect fit!
Book Appointment
[Call us: (03) 8806 3988](tel:(03) 8806 3988)
[Leave a Review!](https://g.page/r/CbigE_1RHAg0EBM/review)