# Source: https://www.oscarwylee.com.au/keizel-optical.html

# Keizel
1
## Frame Design of Keizel Glasses
The frame design of Oscar Wylee’s Keizel glasses is characterised by their rectangle shape, adjustable nose pads and stainless steel and memory metal frame. Keizel is a men’s, scholarly glasses frame that will complement any outfit, day to night.
$199    
In stock
Only %1 left
2 pairs from $249
Discount auto-applied at checkout
Qty
Add to cart
Book an eye test
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
excluding prescription lenses
## About Keizel Glasses
Feel the freedom of flexibility with the Kiezel frame. Crafted from memory metal and stainless steel, this pair offers a practical and adaptable design that springs back gently, making it a resilient choice for everyday wear.
| Frame fit | Measurements |
| --- | --- |
| MEDIUM | 55 - 18 - 145 |
These measurements mean lens width, bridge, and temple length in millimetres (mm). They can be found on the inside of the temple arm. If you already have a pair that you like, you can compare it to these measurements.
### Made from Stainless Steel and Memory Metal
Oscar Wylee’s Keizel frame is a men’s rectangle glasses frame that is perfect for those with round and oval face shapes. The Keizel frame is a unique, ultra light frame that can be worn every day. The main specs of Oscar Wylee’s Keizel glasses frame, including dimensions, shape, materials, lenses, nose fit and hinges are listed below.
| Keizel Frame Features | Keizel Frame Description | Dimensions | Shape | Materials | Lenses | Nose Fit | Hinges |
| --- | --- | --- | --- | --- | --- | --- | --- |
| The dimensions of the Keizel frame are measured in millimetres (mm) and are 55 - 18 - 145, meaning the lens width is 55 mm, the bridge is 18 mm, and the temple length is 145 mm. |
| Keizel is a rectangle shape, well-suited to medium faces. |
| Keizel is made from stainless steel and memory metal, with acetate temple tips. |
| The lenses that can be used in the Keizel frame include optical lenses, such as single-vision and multifocal, and non-prescription lenses, which are plain and can have a filter, such as a blue light filter applied. |
| The nose fit for Keizel is characterised by adjustable nose pads. |
| The hinges in Keizel are normal hinges, also known as standard or barrel hinges. |
Show All
### What Inspired the Frame Design of Oscar Wylee’s Keizel Glasses?
The Oscar Wylee Keizel frame design was inspired by current fashion trends, as rectangle glasses are a timeless style.
## What to Know About Oscar Wylee’s Keizel Glasses?
There are many aspects of the Oscar Wylee Keizel frames that customers should know about to decide whether this is the right frame for them. The Keizel frame is a men’s rectangle-shaped frame. Oscar Wylee’s Keizel frame is suitable for many face shapes, but particularly compatible with round and oval face shapes. The Keizel frame’s simple design makes them fashionable all year round. Keizel features the standard [parts of glasses](https://www.oscarwylee.com.au/glasses/eye/part-of-glasses), such as a rim, temples, lenses and hinges.
### What are the Types of Temple Tips or Earpieces Included with Oscar Wylee’s Keizel Glasses?
The type of temple tips or earpieces included in Oscar Wylee’s Keizel Glasses are made from acetate.
### What Type of Nose Bridge do Oscar Wylee’s Keizel Glasses Have?
The type of nose bridge included in Oscar Wylee’s Keizel frame is characterised by adjustable nose pads.
### What Type of Nose Pads are Included with Oscar Wylee’s Keizel Glasses?
Oscar Wylee’s Keizel frame includes adjustable nose pads.
### What Type of Lenses do Oscar Wylee’s Keizel Glasses Have?
The type of lenses that typically come with the Oscar Wylee Keizel [glasses frame](https://www.oscarwylee.com.au/glasses.html) are optical lenses. Optical lenses are glasses lenses that have a prescription within the lens to help correct vision issues such as myopia, hyperopia, and astigmatism. Keizel frames also come as sunglasses, and with non-prescription lenses and add-ons such as a blue-light filter. Keizel frames can be customised into sunglasses in-store or online with add-on tints or polarisation.
### What Material is Used for the Rim of Oscar Wylee’s Keizel Glasses?
The material used for the rim of Oscar Wylee’s Keizel glasses frames is stainless steel. The rim refers to the part of a glasses frame that holds the lenses.
### What Type of Hinges are Included with Oscar Wylee’s Keizel Glasses?
The type of hinges included with Oscar Wylee’s Keizel frames are normal hinges, also known as standard or barrel hinges. These provide strength and smooth movement connecting the frame's arms and lenses.
## What Face Types are Most Suitable for Oscar Wylee’s Keizel Glasses?
The face types that are most suitable for Oscar Wylee’s Keizel frame are round and oval face shapes. The Keizel frame is a rectangle shape, meaning that they complement the structure of round and oval faces particularly well. The rectangle Keizel frames help balance the features of [round faces](https://www.oscarwylee.com.au/glasses/face-shapes/round) and [oval faces](https://www.oscarwylee.com.au/glasses/face-shapes/oval) bringing the eyes and brows forward in a flattering way. Although there are many [glasses for face shapes](https://www.oscarwylee.com.au/glasses/face-shapes) that may be considered more aesthetically suitable, it is important that people also choose frames that make them feel most comfortable and represent their personal style.
## What Size Options are Available for Oscar Wylee’s Keizel Glasses?
The size options available for Oscar Wylee’s Keizel frame are a medium-frame fit across all colours.
## What Materials are Used to Create Oscar Wylee’s Keizel Glasses?
The primary materials used to create the Oscar Wylee Keizel frame are stainless steel and memory metal. Stainless steel is a type of metal commonly used for glasses that is lightweight, durable and corrosion-resistant. Memory metal is made with shape-memory alloy, a type of material that allows glasses to be bent or twisted lightly, and then reverted back to their original shape.
## What’s Included
## What's Included
Each pair of glasses comes with a stylish frame case and lens cloth. We offer free shipping across Australia and 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects.
* Free Shipping for Australian Orders
* 1 Year Warranty on frames and lenses
* Scratch resistance lens coating on all prescriptions
* UV-proof coating on all prescriptions
* Stylish case and cloth
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
## Make and Materials
The frames in our Memory Twist collection are made with a mix of materials including memory metal, titanium alloy and stainless steel. For optimal flexibility and durability, we have incorporated a stainless steel rim around the lenses and a titanium metal mix to allow for a flexible nose bridge and arms. These frames are corrosion-resistant, ultra-light, and able to withstand minor bends and twists that can occur daily.Our frames go through cleaning and strict quality control, and many pairs of crafting hands to be hand-assembled and polished. After your frames have gone through the production process, they are individually examined and packed before making their way to you!
## Warranty Information
### Warranty Information
### Warranty Information
Oscar Wylee provides a 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects. We will repair or replace faulty or defective frames or lenses free of charge for warranty claims made within 1 year of the delivery. We also offer repairs or replacement for problems experienced with vision during everyday use for claims made within 30 days of delivery. If the same product has been discontinued or is no longer available, then we may offer an exchange for a similar product or a refund.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Find a Store Location](https://www.oscarwylee.com.au/locations/full-store-list.html)