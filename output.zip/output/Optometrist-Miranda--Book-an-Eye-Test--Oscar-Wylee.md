# Source: https://www.oscarwylee.com.au/locations/optometrist-miranda.html

# Optometrist Miranda
Westfield Level 2, Shop 2168600 KingswayMiranda NSW 2228
* Near Nespresso
Opening hours
Monday9:30am - 6:00pm
Tuesday9:30am - 6:00pm
Wednesday9:30am - 6:00pm
Thursday9:30am - 9:00pm
Friday9:30am - 6:00pm
Saturday9:00am - 6:00pm
Sunday10:00am - 6:00pm
*Store hours reflect local standard trading hours and exclude public holidays
[Visit our Miranda Google Business page for directions, reviews, and updates.](https://g.page/r/CeOX7se3_-ixEAE)
Book Appointment
[Call us: (02) 9538 2515](tel:(02) 9538 2515)
[Leave a Review!](https://g.page/r/CeOX7se3_-ixEAg/review)
Our Reviews
Agata
23 hours ago
Rachel has been very helpful and I like her honesty when choosing my new glasses.
She is very atten...tive ,profesional and kind.
I feel that she has helped me to choose the best frames for my face shape and my personality.
She is very knowledgeable and provides First Class Customer Service.
I am very happy to be your customer.
Agata ♥️????♥️
See more
Judith Schuler
1 day ago
Everyone was very friendly and patient.
Amanda Edwards
6 days ago
Fabulous experience, highly recommend!
Dorottya Fekete
6 days ago
I had a good experience with this shop , unfortunately one of my new frames arrived damaged to the s...tore just before I was due to leave for Europe ,but Rachel (I believe that was her name ) she made a temporary repair  so I still could use the damaged frame as a spare while I was away and she gave me a guarantee that it would be replaced when I got back , when I arrived back they did change the frame for a new not damaged one . What a legend give her a pay rise ???????????? thank you a lot
See more
Kym Hills
2 weeks ago
Wonderful always , all the staff are always helpful and friendly and always assist in picking glasse...s to suit your face and lifestyle
See more
Liam Piercy
2 weeks ago
The staff there are great - Bianca was very helpful
Mel Werrett
2 weeks ago
Aaron Raper
2 weeks ago
The young ladies that were serving me were very helpful
Ron Edwards
3 weeks ago
Always a good experience at Oscar Wylee Miranda. Friendly people that know what they are doing.
Mike Nolan
1 month ago
Sam
1 month ago
So professional and caring. Highly recommend.
Ally Mooyman
1 month ago
Super busy on a Saturday with quite a bit of waiting around due to not enough staff - although their... customer service and the optometrist is always great ????
See more
Kylie
1 month ago
Very easy process.
andrew jones
2 months ago
Te Staff at Oscar Wylee Miranda very helpful and easy to deal with i highly recomend any person look...ing to get their eyes tested and new Glasses to visit this store
See more
Susie Crick
2 months ago
The optometrist was very knowledgeable and professional at all times.
Ramón Delgado
2 months ago
Allison Howard
2 months ago
Always a fun and enjoyable experience.  Staff are wonderful and service is the best. I always go to ...OW now for my optical needs. Affordable fashion eyewear
See more
Rosie Rudolph
2 months ago
I had an amazing experience! The service was top-notch, and the product exceeded my expectations. I’...ll definitely be coming back and recommending this to all my friends
See more
Patricia Flynn
3 months ago
Service was great optometrist was excellent very thorough good experience.
Terry Ng
3 months ago
Very professional optometrist and clearly explain everything about my eyes.   Shop Manager and her s...taff are very friendly and assists me with all I needed. Thank you.
See more
Jessica Thompson-Laing
3 months ago
Mia Cabahug
3 months ago
Always a good experience at oscar wylee Miranda
sheila taylor
3 months ago
All went well i needed help choosing my glasses and the young assistant was very helpful..
Allyson Bundy
3 months ago
Excellent experience at Oscar Wylee Miranda.
Thoroughly appreciated the efforts of the staff Highly ...recommend
See more
Rhonda Smith
3 months ago
They were very prompt and clear friendly instructions during testing. Great helpful service
Asmita Daya
4 months ago
the optometrist  was very patient and gentle  whilst  doing the examination and I find the glasses f...rames are very fashionable.
See more
Lisa
4 months ago
very knowledgeable and friendly optometrist! the shop on the other hand could do with some seats!
Ana Souza
4 months ago
Helpful staff and excellent service. The test was quick and the consultation was very informative.
Abdul R Kourouche
4 months ago
No over yet ,still waiting for eye test
Ash Saba
4 months ago
Torin O'Connell
5 months ago
Excellent service, optometrist made me feel comfortable and relaxed during the eye test and was help...ful answering questions and assisting to choose what would work best for my situation.
See more
elaine sewell
6 months ago
First time going To this place and was very impressed
nic normand
6 months ago
good shop, the staff was friendly , but one of the frame i really wanted was on display but not avai...lable in stock, please do not put on display in that case , thanks
See more
Frances Batten
6 months ago
Larissa was first rate- the experience was above expectations. She took the time to understand my co...ncerns, test several options &amp; telling me honestly what was/not possible. I've waited until I received my new glasses to write this review- they are perfect &amp; show that she listened &amp; knows her work. Thank you!
See more
grundies542
7 months ago
Very professional and efficient it is good experience staff extremely knowledgeable and helpful
Carla Perry
7 months ago
An urgent appointment due to an eye issue. I was treated well and he thoroughly investigated, to dis...cover the problem. Then a treatment plan was initiated with adequate education.
See more
Isabela Vargas
7 months ago
Robert Carter
7 months ago
Professional and friendly service
meaghan wilson
7 months ago
Eye test was thorough and Keaton explained concerns with my eye and how to obtain better eye health.... Glasses range extensive and advice was appreciated. Always hard to choose new frames. Highly recommend.
See more
Laura Clearkin
7 months ago
Stelina Drimousis
8 months ago
Zseyenne helped me pick the perfect pair! Thank you so much
Rodrigo Fournier
8 months ago
Easy and precise!
Martin Paul
8 months ago
Quick and thorough. The staff are helpful and explained everything to me
Kirstie Milton
8 months ago
Fantastic
Carlos Monteiro
8 months ago
Sylvia Sidharta
9 months ago
Friendly but knowledgeable people ! Great service!!
Ray Carter
9 months ago
Outstanding service from all staff at Oscar Wylie.  Highly recommend them.  My problem was solved wi...thout needing glasses or any other costly solution.  Brilliant.
See more
Luke Reynolds
9 months ago
Caitlin Fricot
9 months ago
Eye test felt very thorough and quick, asked the right questions. Felt like I was given the opportun...ity to pick my glasses without having someone hover over the top of me which I appreciated. Easy experience
See more
matt shepherd
9 months ago
Professional and courteous service
## Find an Optometrist in Miranda With Oscar Wylee
Located just 10 minutes away from the iconic Cronulla beach, our Oscar Wylee store in Miranda can be found in the Miranda Westfield Shopping Centre. You can have your eye tests bulk billed as part of the Australian Medicare system. Take the train to Miranda Station or utilise Westfield’s 3 hours of free parking, and our Oscar Wylee Miranda team can help you shop our range of stylish and affordable glasses. We also carry a range of prescription sunglasses, perfect for those keen to head over to the beach. 
For those who like to surf or enjoy the ocean, Cronulla is a declared National Surfing Reserve and has some of the best breaks in Australia. If you prefer the indoors, Westfield Miranda has plenty of retail, entertainment and dining options to explore. If you live in the Sylvania Waters or Gymea areas, make Oscar Wylee Miranda your next stop for excellent eye care processes.        
Meet Our Team
* Optometrist Partner
B. Optom
Therapeutically Endorsed
* Store Manager
Our Services
* Bulk Billed Eye Examinations
* Professional Frame Styling
* Frame Adjustments and Repairs
* Visual Fields Testing
* Digital Retinal Scanning
Show All
## Find an Optometrist in Miranda, Sydney for an Eye Health Test
An optometrist in Miranda, Sydney is capable of providing prescription eyewear, eye tests and many other services you may need. At our Oscar Wylee store, we offer an eye health test in Miranda at a bulk billed price courtesy of Australia’s Medicare System. Comprehensive eye tests are vital for the early detection of eye diseases and keeping track of any changes to your vision. Our optometrist will happily refer you to an eye doctor if they do detect any serious concerns. If you require prescription glasses or prescription sunglasses, our optical dispenser will be able to make sure your frames fit you suitably.
An eye test may involve using a few different tools and methods to assess different regions of the eye. Our team will strive to ensure you are comfortable and familiar with the processes. The average price for an optometrist in Miranda may be based on factors such as how many other available optometrists are in the area, your vision requirements, equipment and operating facilities.
## How to Find an Optometrist in Miranda, Sydney?
To find an optometrist in Miranda, Sydney you can take certain steps that can help make it easier for you such as searching online, assessing the store’s opening hours and finding the directions to your chosen location. The steps on how to find an optometrist in Miranda are listed below.
1. Search online using the phrase, Miranda optometrist near me. This can also be done here on the website via our locations page.
2. Click on the Oscar Wylee link, which will take you directly to our Miranda optometrist store page.
3. See the store’s opening hours and where the store is located specifically.
4. Use the Miranda Google Business page link located under store hours to see the directions on how to get to the store.
You can also find an optometrist in Miranda by searching the keywords optometrist near me. If you have locations enabled on your smartphone and you’re in the Miranda area, our Miranda store page should appear easily for you to click on.
### Is it Hard to Get an Eye Appointment in Miranda, Sydney?
No, it is not hard to get an eye appointment in Miranda. You can easily book an appointment to see an Oscar Wylee optometrist in Miranda right here on this page. At Oscar Wylee we have highly qualified optometrists available for bulk billed eye appointments, which can be booked online or in-store.
#### How to Compare Optometrists in Miranda to Each Other?
To compare optometrists in Miranda, you can use factors such as eye tests offered, health fund coverage, lens types and add-ons and eyewear offered. To take care of your vision and eye health, it is important to receive an eye test at least once every two years. There are different types of tests that can be performed in an eye test and not all optometrists may offer the same tests. Health funds can be used to help cover some of the cost of your frames and lenses. To find out if your health fund is accepted at Miranda optometrist in Sydney, visit their website. In the case of Oscar Wylee, we accept all major health funds and provide on-the-spot claims in-store. There are many different lens options available for prescription glasses such as single vision, multifocal and high index lenses. Most optometrists in Miranda will offer these lenses although it is good to make sure. There are also lens add-ons available to enhance your glasses such as anti-reflective and blue light filters. Finally, if you are looking to purchase a pair of glasses after your eye test, you can compare the different styles and colours you are interested in from Miranda optometrists in Sydney. Oscar Wylee offers a wide range of frames with vintage and modern inspirations in bold colours and subtle designs.
#### How to Find an Eyeglasses Shop in Miranda, Sydney?
To find a glasses store in Miranda, you can try to follow these simple steps including searching online, selecting a convenient location and looking at their health insurance policies. The steps on how to find a glasses store in Miranda, Sydney are listed below.
1. Search online using the phrase, glasses store in Miranda. This will provide you with various options for glasses stores in the whole area of Miranda .
2. Select a glasses store that is most convenient for you to travel to.
3. Click the link to find out more information such as opening hours, exact location and directions to the glasses store in Miranda.
4. Read their health insurance policies to ensure you know what health benefits you have access to.
Our Oscar Wylee glasses store in Miranda, Sydney offers primary eye care services such as comprehensive eye tests as well as other services performed by an optometrist and offers prescription and non-prescription eyewear.
##### Is it Possible to Purchase Prescribed Sunglasses in Miranda, Sydney Without Seeing an Optometrist?
Yes and no, it is possible to [purchase prescribed sunglasses](https://www.oscarwylee.com.au/sunglasses.html) in Miranda, Sydney without seeing an optometrist if you already have a prescription that has not expired. If your prescription is expired, you can book an eye test to receive an updated or new prescription which will require you to see an optometrist. This will ensure your prescription sunglasses are appropriate for your visual needs.
## Where is the Oscar Wylee Miranda Optometrist in Sydney Located?
The Oscar Wylee Miranda optometrist is located in the Miranda Westfield Shopping Centre on level 2 near Nespresso. Miranda Westfield can be found at 600 Kingsway.
### What is the Phone Number of Oscar Wylee Miranda Optometrist Store?
The Oscar Wylee Miranda optometrist store phone number is [(02) 9538 2515](tel:(02) 9538 2515). You can contact the Oscar Wylee Miranda store between the hours of 9:30 am and 6 pm on Monday, Tuesday, Wednesday and Friday, on Thursday between 9:30 am and 9 pm, on Saturday between 9 am and 6 pm and on Sunday between 10 am and 6 pm.
### What are the Reviews for Oscar Wylee Miranda Optometrist in Sydney?
The many reviews for Oscar Wylee Miranda optometrist in Sydney, left by our various customers can be found here on the website and online when you search for Oscar Wylee Miranda optometrist. The reviews for Oscar Wylee Miranda optometrist are listed below.
* Keirstin Long:  I found the staff to be very helpful. I've found the eye tests very thorough and the range of frames was lovely. I had trouble choosing, I'm very happy with my glasses.
* Monique Soulos:  Great service! Thank you.
* Yvonne Tozzi:  Great selection of frames, great customer service and immediate eye testing. Fantastic service, 5 stars from me.
* Celine Rasmussen:  I have recently bought and fitted reading glasses and bifocals with transition lenses at Miranda with the help of Dan at the store. He has been so helpful in making sure that the glasses not only look good but also making sure that they fit well, especially with my bifocals. I will return to Miranda for my next glasses for sure because the service by Dan makes it worth the switch from a big retailer.
#### What Treatments or Eye Care Processes are Done in the Oscar Wylee Miranda Optometrist Location?
The treatments or eye care processes done in the Oscar Wylee Miranda optometrist Sydney location include a tonometry test, a digital photograph, a slit lamp exam and a refraction test. Additional tests that may also be performed can include a visual field test and a dilated fundus exam. The treatments or eye-care processes that are done in the Oscar Wylee Miranda optometrist Sydney location are listed below.
* A Tonometry Test: An optometrist or optical dispenser will conduct a tonometry test which involves the use of a machine that will release small puffs of air into your eyes. This will assist with measuring pressure in the eye.
* A Digital Photograph: An optometrist or optical dispenser may take a digital photograph of your eye which can be kept on record to use in future appointments to evaluate any changes to your eye.
* Slit Lamp Test: A slit lamp test can be used to evaluate your eye health, by examining your cornea and iris which are the anterior and posterior of the eye.
* Refraction Test: During a refraction test, an optometrist will have you view an image through different lenses and ask you to confirm which helps you see the image clearer.
* Visual Field Test: A visual field test can assist with assessing your peripheral vision, which may be beneficial for identifying any signs of glaucoma.
* Dilated Fundus Exam: A dilated fundus exam can help an optometrist assess your health in more detail by getting a clear view of the retina. This test is typically carried out for patients with diabetes and those who may be at risk of developing retinal damage.
## How Many Optometrists Exist in Miranda, Sydney?
Many optometrists exist in Miranda, Sydney to provide eye tests and glasses, including Oscar Wylee. The number of optometrists in Miranda may be due to the number of residents in the area and the geographical size of the suburb. If you need essential eye services such as a comprehensive eye test, a wide selection of prescription eyewear and more, then choose Oscar Wylee as your first choice for optometry services.
### What are the Other Closest Optometrist Locations to Miranda, Sydney in Australia?
The other closest Oscar Wylee optometrist locations to Miranda, Sydney in Australia are Hurstville, Eastgardens, Burwood and Liverpool. The other closest optometrist locations to Miranda are listed below.
* Hurstville:  Hurstville is close to Miranda with just 10 km in between stores and is found at the Westfield shopping centre next to Footlocker. The [Oscar Wylee Hurstville](https://www.oscarwylee.com.au/locations/optometrist-hurstville.html) store is a reliable option for getting your regular eye tests and receiving professional advice on frame selection and eye care.
* Eastgardens:  Eastgardens is close to Miranda with 21 km in between stores. You can visit the [Oscar Wylee Eastgardens](https://www.oscarwylee.com.au/locations/optometrist-eastgardens.html) store at the Westfield shopping centre on level 2. Here you have access to professional services that help you care for your vision performed by a passionate and dedicated team.
* Burwood:  Burwood is close to Miranda, around 23 km in distance and is located at the Westfield shopping centre. The [Oscar Wylee Burwood](https://www.oscarwylee.com.au/locations/optometrist-burwood.html) store can provide all the essential services for a range of eye conditions and problems. You can book an appointment here online or see our team in-store.
* Liverpool:  Liverpool is close to Miranda, around 35 km in distance and can be found at the Westfield shopping centre. The [Oscar Wylee Liverpool](https://www.oscarwylee.com.au/locations/optometrist-liverpool.html) store is a great destination for assistance with your prescription glasses whether it’s for an update or a new issue. Our team will strive to meet your visual needs.
### Eyes Tests at Oscar Wylee Miranda
You don’t need to search far and wide to get comprehensive eye testing. Oscar Wylee Miranda carries out quality eye health tests for general vision check-ups as well as for eye diseases. For a bulk billed price, you can get your eyes tested, just be sure to bring your Medicare card. Update your prescription, have your eyes tested and browse for new glasses, all on the same day.
### Oscar Wylee Miranda Accepts Major Health Funds
If you’re in need of new glasses or want to have a regular eye health test, your health fund may be able to cover some of the cost! Be sure to bring in your health fund card and we'll be able to inform you of what you might be eligible for. Insurance can often be a tedious process, so that’s why our Oscar Wylee Miranda store will work hard to help you as much as we can.
### Oscar Wylee Offers On-Trend Frames
You can count on our Oscar Wylee Miranda team to help you select glasses that perfectly match your style and needs. You can expect affordable prices for our frames without compromising style. Oscar Wylee Miranda offers prescription lenses that can help you with your visual needs - whether you’re considering our blue light filter option or photochromic lenses, our Miranda team can offer their expert advice and assistance with the selection process.
Book Appointment
[Call us: (02) 9538 2515](tel:(02) 9538 2515)
[Leave a Review!](https://g.page/r/CeOX7se3_-ixEAg/review)