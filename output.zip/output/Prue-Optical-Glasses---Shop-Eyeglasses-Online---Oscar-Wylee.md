# Source: https://www.oscarwylee.com.au/prue-optical.html

# Prue
1
## Frame Design of Prue Glasses
The frame design of Oscar Wylee’s Prue glasses is characterised by their rectangle shape, high nose bridge and acetate frame. Prue glasses are a unisex, statement frame that will work for any occasion, whether the wearer wants to liven up their work style or complement a fun outfit for a night out.
$169    
In stock
Only %1 left
2 pairs from $199
Discount auto-applied at checkout
3 pairs from $249
Discount auto-applied at checkout
Qty
Add to cart
Book an eye test
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
excluding prescription lenses
## About Prue Frames
Prue is a classic rectangular shape, perfect for smaller, more narrow
faces. Made from acetate, this unisex frame adds an intellectual air
to whoever’s wearing it.
| Frame fit | Measurements |
| --- | --- |
| NARROW | 50 - 18 - 140 |
These measurements mean lens width, bridge, and temple length in
millimetres (mm). They can be found on the inside of the temple arm.
If you already have a pair that you like, you can compare it to these
measurements.
### Made from Acetate
Oscar Wylee’s Prue frame is a unisex, rectangle glasses frame that is
perfect for those with round and oval face shapes. The Prue frame is a
stylish, widely wearable frame that can be worn every day. The main
specs of Oscar Wylee’s Prue glasses frame including
dimensions, shape, materials, lenses, nose fit and hinges
are listed below.
| Prue Frame Features | Prue Frame Description | Dimensions | Shape | Materials | Lenses | Nose Fit | Hinges |
| --- | --- | --- | --- | --- | --- | --- | --- |
| The dimensions of the Prue frame are measured in millimetres (mm)
and are 50 - 18 - 140, meaning the lens width is 50 mm, the bridge
is 18 mm and the temple length is 140 mm. |
| The Prue frame is a rectangular shape, well suited to narrow
faces. |
| Prue glasses are made from acetate. |
| The lenses that can be used in the Prue frame are optical lenses,
which include single vision and multifocal lenses and
non-prescription lenses, which are plain and can have a filter
like a blue light filter applied. |
| The nose fit for Prue frames is a high nose bridge fit. |
| The hinges in Prue glasses are spring hinges, which are more
flexible than other types of hinges and can extend past 90
degrees. |
Show All
### What Inspired the Frame Design of Oscar Wylee’s Prue
Glasses?
The Oscar Wylee Prue frame design was inspired by current fashion
trends as rectangle glasses shapes are often in fashion.
## What to Know
About Oscar Wylee’s Prue Glasses?
There are many aspects of the Oscar Wylee Prue frames that
customers should know about, so they can decide whether this is
the right frame for them. The Prue frame is a unisex rectangle
glasses frame. Oscar Wylee’s Prue frame is suitable for many face
shapes but particularly compatible with round and oval face
shapes. The Prue frame’s simple design means that they are
fashionable all year round. Prue glasses feature the standard
[parts of glasses](https://www.oscarwylee.com.au/glasses/eye/part-of-glasses)
such as a rim, temples, lenses, spring hinge and a high nose
bridge.
### What are the
Types of Temple Tips or Earpieces Included with Oscar
Wylee’s Prue Glasses?
The type of temple tips or earpieces included in Oscar Wylee’s
Prue Glasses are made from acetate.
### What Type of Nose Bridge do Oscar Wylee’s Serge Small
Glasses Have?
The type of nose bridge included in Oscar Wylee’s Prue frame is a
high nose bridge fit.
### What Type of Nose Pads are Included with Oscar Wylee’s
Prue Glasses?
Oscar Wylee’s Prue frames do not include adjustable silicone nose
pads.
### What Type of Lenses do Oscar Wylee’s Prue Glasses Have?
The type of lenses that typically come with the Oscar Wylee Prue
[glasses frame](https://www.oscarwylee.com.au/glasses.html)
are optical lenses. Optical lenses are glasses lenses that have a
prescription within the lens to help correct vision issues such as
myopia, hyperopia and astigmatism. Prue glasses can also come with
non-prescription lenses, with add-ons such as a blue light filter.
Prue frames are currently unavailable as sunglasses online,
however, customers can customise in-store and add on tint or
polarisation.
### What Material is Used for the Rim of Oscar Wylee’s Prue
Glasses?
The material used for the rim of Oscar Wylee’s Prue glasses frames
is acetate. The rim refers to the part of a glasses frame that
holds the lenses.
### What Type of Hinges are Included with Oscar Wylee’s
Prue Glasses?
The type of hinges included with Oscar Wylee’s Prue frames are
spring hinges. A spring hinge in a glasses frame refers to hinges
that are more flexible than normal hinges and can go slightly
beyond 90 degrees. Spring hinges can provide a closer fit to the
face.
## What Face Types are Most Suitable for Oscar Wylee’s
Prue Glasses?
The face types that are most suitable for Oscar Wylee’s Prue frame
are round and oval face shapes. The Prue frame is a rectangle
shape, meaning that it complements the structure of round and oval
faces particularly well. The rectangle Prue frames help to balance
the features of a
[round face shape](https://www.oscarwylee.com.au/glasses/face-shapes/round)
and an
[oval face shape](https://www.oscarwylee.com.au/glasses/face-shapes/oval)
face shape. Rectangle frames help to add sharp lines to the
rounded features of a round and oval face, highlighting without
overemphasising them. Although there are many
[glasses for face shapes](https://www.oscarwylee.com.au/glasses/face-shapes)
that may be considered more aesthetically suitable, it is
important that people also choose the frames that make them feel
most comfortable, and represent their personal style.
## What Size Options are Available for Oscar Wylee’s Prue
Glasses?
The size options available for Oscar Wylee’s Prue frame are a
narrow-fit frame across all colours.
## What Materials are Used to Create Oscar Wylee’s Prue
Glasses?
The primary material used to create the Oscar Wylee Prue frame is
acetate. Acetate, also known as cellulose acetate, is a
bioplastic, made from cotton fibres or wood pulp. At Oscar Wylee,
acetate glasses are made by adding a dye to cellulose acetate,
which is rolled into a sheet. The shape of the glasses is then cut
from this sheet.
## What’s Included
## What's Included
Each pair of glasses comes with a stylish frame case and lens cloth. We offer free shipping across Australia and 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects.
* Free Shipping for Australian Orders
* 1 Year Warranty on frames and lenses
* Scratch resistance lens coating on all prescriptions
* UV-proof coating on all prescriptions
* Stylish case and cloth
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
## Make and Materials
The frames then go through cleaning and strict quality control, and many pairs of crafting hands to be hand-assembled and polished. After your frames have gone through the production process, they are individually examined and&nbsp;packed before making their way to you!Also known as cellulose acetate, these frames are traditionally hand-crafted by skilled craftsmen, with each frame passing through numerous stages of production and are hand-polished to ensure a glorious lustre.
## Warranty Information
### Warranty Information
### Warranty Information
Oscar Wylee provides a 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects. We will repair or replace faulty or defective frames or lenses free of charge for warranty claims made within 1 year of the delivery. We also offer repairs or replacement for problems experienced with vision during everyday use for claims made within 30 days of delivery. If the same product has been discontinued or is no longer available, then we may offer an exchange for a similar product or a refund.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Find a Store Location](https://www.oscarwylee.com.au/locations/full-store-list.html)