# Source: https://www.oscarwylee.com.au/locations/optometrist-macquarie-centre.html

# Optometrist Macquarie Centre
Level 2, Shop 2076Cnr Herring Rd &amp; Waterloo RdNorth Ryde NSW 2113
* Next to Sheridan
Opening hours
Monday9:30am - 6:00pm
Tuesday9:30am - 6:00pm
Wednesday9:30am - 6:00pm
Thursday9:30am - 8:00pm
Friday9:30am - 6:00pm
Saturday9:30am - 6:00pm
Sunday10:00am - 5:00pm
*Store hours reflect local standard trading hours and exclude public holidays
[Visit our Macquarie Centre Google Business page for directions, reviews, and updates.](https://g.page/r/CfZOmOlWvkLtEBM)
Book Appointment
[Call us: (02) 8593 1033](tel:(02) 8593 1033)
[Leave a Review!](https://g.page/r/CfZOmOlWvkLtEBM/review)
Our Reviews
Athlete Recovery
1 day ago
Very Thorough examination
Josh Stephens
1 day ago
Fantastic, William was very professional and friendly.
宋美萱
1 week ago
Mark Dawson
1 week ago
A great lady, Julie just repaired my Ray Ban’s after my sister mistaking Sat on them distorting them... out of shape, Julie did a great job and was very nice to boot.
See more
Sagar Rawat
1 week ago
Great team at the Macquarie Park store , both optometrist and the guy in sales, great people. Mr. Ow...ner give them a raise. They have a great vibe.
See more
Jenny Tang
1 week ago
Venus Coneybear
1 week ago
Kota, Dae and team are welcoming, friendly and professional. Really nice and easy experience from st...art to finish! Thanks team ????
See more
Jitendra Gujral
2 weeks ago
Ynnek
3 weeks ago
Excellent service! Clota kindly repaired my glasses free of charge. I really appreciate the help and... highly recommend this shop.
See more
高炜芳
4 weeks ago
The service of the front desk staff and the optometrist was very patient and thoughtful. They receiv...ed me very warmly. They quickly helped me make an appointment for the latest examination, and the examination was also very meticulous and gentle. The clerk and optometrists carefully translated for me when they saw that my English was not good. Even though I was very anxious about my eyes, they comforted me patiently. Thank you very much to all the staff in the store.
See more
Joanie Rankin
4 weeks ago
Amazing team so caring and thorough highly recommend
Toai Nguyen
1 month ago
Received excellent service from the store manager ‘Coda’
Qian Zhang
1 month ago
We recently took our children to Oscar Wylee for comprehensive eye examinations, and we were very fo...rtunate to be looked after by Dae-Yang. He truly understanding and caring for our children’s needs. He went above and beyond to help us understand our options and was always thoughtful, knowledgeable, and supportive.
Thank you again for your outstanding care!
See more
Yvonne Lam
1 month ago
Terrence W
1 month ago
Received excellent service from Bart last month. He was very professional and patient. He wrote me a... referral letter, and I was able to have my floater checked the same day, which gave me peace of mind. Much appreciated!
See more
Chantelle de Kock
1 month ago
Awesome service. The staff are so friendly and took the time to explain and assist us with any quest...ions!
See more
Annie Ky
1 month ago
Friendly staff, fast eye exam. They ran on time.
Yuxi Jin
1 month ago
The staff here is so nice and professional. A boy helped fixing my mom’s glasses in a minute althoug...h it’s not bought from the store. Appreciate it!
See more
Gabriella Do Valle
1 month ago
I had a wonderful experience at this store during my eye examination. The entire process was smooth ...and professional, but what truly made the visit exceptional was the outstanding service I received from the assistance person called Kota.
Kota was incredibly patient, knowledgeable, and attentive throughout the whole experience. He took the time to understand what I was looking for, guided me through the many frame options, and helped me find a pair that suited both my face and my needs. His expertise and honest feedback gave me confidence in my choice, and I never felt rushed despite the large number of frames we looked at.
It's rare to come across someone who combines professionalism, genuine care, and extensive product knowledge so effortlessly. Thank you, Kota, for making what could have been an overwhelming experience so enjoyable.
I highly recommend this store, and if you have the opportunity to be assisted by Kota, you're in excellent hands!
See more
Jane Maughan
1 month ago
Very efficient, informative and helpful
Coby Bonnici
2 months ago
All the guys here are great. Very good service.
Weiting Li
2 months ago
Neha Giduturi
2 months ago
One of the best places around Macquarie University to get your lenses. They even fixed my old glasse...s as service. Truly recommend and a very friendly staff.
See more
Boofy Brods
2 months ago
Great service .
Karina Hiralal
2 months ago
My eye test experience at Oscar Wylee was great ! The optometrist explained all the tests as well as... all the results thoroughly and at a level at which I understood clearly what he meant
See more
Shirley H
2 months ago
Great to stop by today at Macquarie! Kota and Dae looked after me well so well, even though I didn't... live around the area. They both actively listened to my optometry and billing questions, provided the best recommendations and even helped me pick out my favourite pairs of frames.
Even though I didn't get tested in store today (as I needed extra eye scans to check my eye health), I appreciated them going above and beyond to assist me and to save me time the next time I visited a closer store ☺️ and this was close to the closing time of the day too.
Also great to bump into Dae again the same optometrist from the last time I got glasses ???? haha small world!
???? Recommend to visit! Really appreciated the chats and assistance! Looking forward to my next visit to get new glasses ????
See more
Ranu Sinha
2 months ago
Staff were friendly and helpful. Made it an easy experience
Henar Lopez Alos
3 months ago
All perfect! They are super professional.
Eddy Furlong
3 months ago
Linda, the optometrist was punctual, offering excellent advice and, to my eyes,  caring &amp; thorough. ...Staff members Annalise &amp; Joeline were welcoming and friendly, the choice of frames was different from the standard set I find elsewhere, and they were not overwhelmingly varied.
See more
Eric
3 months ago
Helpful and friendly environment.
Honey Gurung
4 months ago
Qasim Aamir
4 months ago
Every single staff member was so nice and helpful. The optometrist was so chill and let me redo my r...etina photos and emailed them to me. The whole staff helped me choose my new frames and I never felt rushed.
See more
Anjali Arun
4 months ago
Dr. Abgail at Macquarie was amazing !!
mina piraste
4 months ago
My experience at Oscar Wylee was great. The staff were welcoming and professional, and as a first-ti...me glasses user, they took the time to thoroughly walk me through everything I needed to know.
See more
Harrison James Hreszczuk
4 months ago
Richard Clarke
5 months ago
Had a great experience at Oscar Wylee. Annalise was friendly, patient, and really took the time to h...elp me find the perfect frames without any pressure. She gave great advice and made the whole process easy and enjoyable. If you want someone relaxed and easygoing, she’s the right person, we even had a good laugh along the way. She’s got a great sense of humour. Really happy with my glasses and the service. Highly recommend her and Oscar Wylee at Macquarie Shopping Centre ! :)
See more
Rexo Rexo
5 months ago
Joelene and Vivianne (optom) on 15th march were both super empathetic, helpful and were so kind to r...eview me today after accidental injury to the eye. Big thanks!!
The shop was clean and had a great selection of glasses too. Will be having wife follow up with them moving forward.
See more
mickayla
5 months ago
Krystal Liu
5 months ago
victoria iskater
5 months ago
Fantastic Customer Service
Lovely Manager and staff here - Outstanding  professionals, highly knowle...dgeable friendly &amp; patient all. I’d give them 6 Stars if I could
Thank you
Victoria
See more
Scott Pye
6 months ago
I had the most amazing experience with Annalise at Oscar Wylee in Macquarie Centre. From the moment ...I walked in she was warm welcoming and incredibly professional. She took the time to truly understand what I was looking for and gave thoughtful honest advice when helping me choose my frames. Her product knowledge was outstanding and she explained everything clearly making the whole process feel effortless and stress free. Nothing felt rushed and she genuinely cared about making sure I was completely happy with my choice. Her attention to detail and friendly personality turned what can sometimes be an overwhelming experience into such an enjoyable one. I highly recommend asking for Annalise if you are visiting as she truly goes above and beyond with exceptional customer service.
See more
Angela Black
6 months ago
I visited the Macquarie Centre location yesterday and was greeted with friendly staff. My assessment... was thorough and explained and I was given options for not only now, but moving forward.
I was guided with frames and helped select two that suit beautifully.
It was great care
See more
Simon Torok
6 months ago
Amazing fast service, great help and advice, expert eye testing, phenomenal all round!
Tadeusz Mazgaj
6 months ago
This was the best examination i ever had. Very happy. Thanks
Samantha Harvey
6 months ago
I never usually leave Google reviews, but this experience was absolutely worth it. Took my elderly d...ad’s glasses to OPSM and was told the repair was “impossible” but they wanted me to pay $80, with no real attempt made.
I then went to Oscar Wylee and was greeted by Annalise, who immediately understood my frustration and said she’d give it a go, no promises. Two minutes later she came back with the glasses completely fixed.
I was honestly amazed. When I asked how she did it, she explained she’s been in the industry for over 8 years, and it really shows. And the best part? She didn’t even charge me for the repair. OPSM said impossible for a fee, Annalise proved otherwise with pure skill, care, and experience. Huge thank you to Annalise for fixing my dad’s glasses! ????????
See more
Sahrear Seraj
7 months ago
As always Vivien was brilliant! I had incorrect prescription from another optometrist and Vivien was... able identify the issue and provided right prescription. I highly recommend Oscar Wylee for your next pair of glasses.
See more
tao jin
7 months ago
Great team, very friendly and helpful. The optometrist was also extremely patient and took the time ...to fully understand my needs, making sure the prescription was perfectly suited to my usage and daily conditions. Highly recommended.
See more
Pascale and Shane Atton
7 months ago
Friendly and welcoming staff. Will come again :-)
Joanna Fong
7 months ago
Fast and friendly service. Got a walk in appointment straight away. Optometrist Abigail was very goo...d and provided detailed info about eye health. Best optical store in Macquarie centre.
See more
G Sming
7 months ago
Excellent service. Thank you very much for your kind assistance.
## Find an Optometrist in Macquarie Centre with Oscar Wylee
Come visit Oscar Wylee Macquarie Centre for all your optometry service and eyewear needs in Sydney’s North Shore. We are situated near areas such as Marsfield and North Ryde and just a stroll away from the Macquarie University metro station. Oscar Wylee Macquarie Centre offers in-store eye tests for same-day prescriptions and a variety of different glasses frames and lenses to suit your needs! You can browse our modern and vintage-inspired prescription glasses as well as a wide range of prescription sunglasses. 
Our store is located on level 2 of the Macquarie Centre, which is a shopping centre located in the suburb of Macquarie Park on Sydney’s North Shore and has a huge range of international and Australian brands, home to over 360 stores across dining and entertainment, fresh food, fashion and more. So come in and see our Oscar Wylee Macquarie Centre team where we ensure that our customers feel welcome to browse our range of high quality eyewear and are able to sit down with a trained optometrist for a thorough, bulk billed eye exam and vision tests.         
Meet Our Team
* Optometrist
Bachelor of Optometry (Hons)
Bachelor of Vision Science
Ocular Therapeutics
* Store Manager
Our Services
* Bulk Billed Eye Examinations
* Professional Frame Styling
* Frame Adjustments and Repairs
* Visual Fields Testing
* Digital Retinal Scanning
Show All
## Find an Optometrist in Macquarie Centre, North Ryde for an Eye Health Test
An optometrist in Macquarie Centre, North Ryde is capable of providing health services to assist you with monitoring your ocular health and checking for signs of eye diseases. At Oscar Wylee, we offer an eye health test in Macquarie Centre, which is available at a bulk billing price thanks to Australia’s Medicare System. While our optometrists are qualified to diagnose a wide range of conditions, you may be referred to an eye doctor if our team does detect signs of more serious conditions. When you visit us in-store, you won’t be disappointed as we take vision, eye health and style seriously. Whether it is for prescription sunglasses or non-prescription glasses, our optical dispenser has got you covered.
During a comprehensive eye examination, our highly-trained staff will take you through some preliminary tests to assess your eye muscle movement, visual fields and more. Our friendly optometrist will then take a closer look inside your eye to make sure everything checks out. Factors such as the equipment used, the status of your condition and the number of available optometrists in the area may be factors for the average price of optometrists in Macquarie Centre.
## How to Find an Optometrist in Macquarie Centre, North Ryde?
To find an optometrist in Macquarie Centre, North Ryde, you can take certain steps that can help make it easier for you such as searching online, assessing the store’s opening hours and finding the directions to your chosen location. The steps on how to find an optometrist in Macquarie Centre are listed below.
1. Search online using the phrase, Macquarie Centre optometrist near me. This can also be done here on the website via our locations page.
2. Click on the Oscar Wylee link, which will take you directly to our Macquarie Centre optometrist store page.
3. See the store’s opening hours and where the store is located specifically.
4. Use the Macquarie Centre Google Business page link located under store hours to see the directions on how to get to the store.
You can also find an optometrist in Macquarie Centre by searching the keywords optometrist near me. If you have locations enabled on your smartphone and you’re in the area of Macquarie Centre, our Macquarie Centre store page should appear easily for you to click on.
### Is it Hard to Get an Eye Appointment in Macquarie Centre, North Ryde?
No, it is not hard to get an eye appointment in Macquarie Centre. You can easily book an appointment to see an Oscar Wylee optometrist in Macquarie Centre right here on this page. At Oscar Wylee we have highly qualified optometrists available for bulk billed eye appointments, which can be booked online or in-store.
#### How to Compare Optometrists in Macquarie Centre to Each Other?
To compare optometrists in Macquarie Centre, you can use factors such as eye tests offered, health fund coverage, lens types and add-ons and eyewear offered. To take care of your vision and eye health, it is important to receive an eye test at least once every two years. There are different types of tests that can be performed in an eye test and not all optometrists may offer the same tests. Health funds can be used to help cover some of the cost of your frames and lenses. To find out if your health fund is accepted at Macquarie Centre optometrist in North Ryde, visit their website. In the case of Oscar Wylee, we accept all major health funds and provide on-the-spot claims in-store. There are many different lens options available for prescription glasses such as single vision, multifocal and high index lenses. Most optometrists in Macquarie Centre will offer these lenses although it is good to make sure. There are also lens add-ons available to enhance your glasses such as anti-reflective and blue light filters. Finally, if you are looking to purchase a pair of glasses after your eye test, you can compare the different styles and colours you are interested in from Macquarie Centre optometrists in North Ryde. Oscar Wylee offers a wide range of frames with vintage and modern inspirations in bold colours and subtle designs.
#### How to Find an Eyeglasses Shop in Macquarie Centre, North Ryde?
To find a glasses store in Macquarie Centre, you can try to follow these simple steps including searching online, selecting a convenient location and looking at their health insurance policies. The steps on how to find a glasses store in Macquarie Centre, North Ryde are listed below.
1. Search online using the phrase, glasses store in Macquarie Centre. This will provide you with various options for glasses stores in the whole Macquarie Centre, North Ryde area.
2. Select a glasses store that is most convenient for you to travel to.
3. Click the link to find out more information such as opening hours, exact location and directions to the glasses store in Macquarie Centre.
4. Read their health insurance policies to ensure you know what health benefits you have access to.
Our Oscar Wylee glasses store in Macquarie Centre, North Ryde offers primary eye care services such as comprehensive eye tests as well as other services performed by an optometrist and offers prescription and non-prescription eyewear.
##### Is it Possible to Purchase Prescribed Sunglasses in Macquarie Centre, North Ryde Without Seeing an Optometrist?
Yes and no, it is possible to [purchase prescribed sunglasses](https://www.oscarwylee.com.au/sunglasses.html) in Macquarie Centre, North Ryde without seeing an optometrist if you already have a prescription that has not expired. If your prescription is expired, you can book an eye test to receive an updated or new prescription which will require you to see an optometrist. This will ensure your prescription sunglasses are appropriate for your visual needs.
## Where is the Oscar Wylee Macquarie Centre Optometrist in North Ryde Located?
The Oscar Wylee North Ryde optometrist is located in Macquarie Centre Westfield Shopping Centre on level 2 next to Sheridan. The Macquarie Centre Westfield Shopping Centre can be found at Herring Road &amp; Waterloo Road, Macquarie Park.
### What is the Phone Number of Oscar Wylee Macquarie Centre Optometrist Store?
The Oscar Wylee Macquarie Centre optometrist store phone number is [(02) 8593 1033](tel:(02) 8593 1033). You can contact the Oscar Wylee Macquarie Centre store between 9:30 am and 6 pm on Monday, Tuesday, Wednesday and Friday, on Thursday between 9 am and 9 pm, on Saturday between 9 am and 6 pm and on Sunday between 10 am and 6 pm.
### What are the Reviews for Oscar Wylee Macquarie Centre Optometrist in North Ryde?
The many reviews for Oscar Wylee Macquarie Centre optometrist in North Ryde, left by our various customers can be found here on the website and online when you search for Oscar Wylee Macquarie Centre optometrist. The reviews for Oscar Wylee Macquarie Centre optometrist are listed below.
* Chen Eric:  It was my first time experiencing OW in MQ centre. Jessica was very helpful and professional. She went through a detailed eye check and tests and found a sign of asteroid hyalosis which I have never been told or heard of. She explained to me in a very patient manner. She is the type of professional that you can trust and call her 'my optometrist'.
* Nelson Motilla:  The optometrist is very experienced and accommodating, even all the staff. The clinic is very clean. Keep up the good work!
* Sohail Ejaz:  Skilful and professional.
* Marion McConnell:  Very professional, friendly and likeable staff.
#### What Treatments or Eye Care Processes are Done in the Oscar Wylee Macquarie Centre Optometrist Location?
The treatments or eye care processes done in the Oscar Wylee Macquarie Centre optometrist North Ryde location include a tonometry test, a digital photograph, a slit lamp exam and a refraction test. Additional tests that may also be performed can include a visual field test and a dilated fundus exam. The treatments or eye-care processes that are done in the Oscar Wylee Macquarie Centre optometrist North Ryde location are listed below.
* A Tonometry Test: An optometrist or optical dispenser will conduct a tonometry test which involves the use of a machine that will release small puffs of air into your eyes. This will assist with measuring pressure in the eye.
* A Digital Photograph: An optometrist or optical dispenser may take a digital photograph of your eye which can be kept on record to use in future appointments to evaluate any changes to your eye.
* Slit Lamp Test: A slit lamp test can be used to evaluate your eye health, by examining your cornea and iris which are the anterior and posterior of the eye.
* Refraction Test: During a refraction test, an optometrist will have you view an image through different lenses and ask you to confirm which helps you see the image clearer.
* Visual Field Test: A visual field test can assist with assessing your peripheral vision, which may be beneficial for identifying any signs of glaucoma.
* Dilated Fundus Exam: A dilated fundus exam can help an optometrist assess your health in more detail by getting a clear view of the retina. This test is typically carried out for patients with diabetes and those who may be at risk of developing retinal damage.
## How Many Optometrists Exist in Macquarie Centre, North Ryde?
Many optometrists exist in Macquarie Centre, North Ryde that are available for comprehensive eye tests and a wide range of eyewear, including Oscar Wylee. The number of optometrists that can be found in Macquarie Centre, North Ryde may depend on reasons including the geographical size and location and the total number of residents in the area. Here at Oscar Wylee Macquarie Centre, you can receive professionally conducted services and care for all your optometry concerns.
### What are the Other Closest Optometrist Locations to Macquarie Centre, North Ryde in Australia?
The other closest Oscar Wylee optometrist locations to Macquarie Centre are Top Ryde, St Ives, Chatswood Chase and Rhodes. The other closest optometrist locations to Macquarie Centre are listed below.
* Top Ryde:  Top Ryde is close to Macquarie Centre, just 5 km in distance and is located at 109/129 Blaxland Road. The [Oscar Wylee Top Ryde](https://www.oscarwylee.com.au/locations/optometrist-top-ryde.html) store is a go-to destination for eye tests and fashionable prescription or non-prescription frames.
* St Ives:  St Ives is close to Macquarie Centre with around 8 km in between stores and can be found near Harris Farm. The [Oscar Wylee St Ives](https://www.oscarwylee.com.au/locations/optometrist-st-ives.html) store is located at 166 Mona Vale Road and is a great optometrist option if you’re a St Ives local. If you’re looking to get your next eye exam done by a team that cares about your eye health just as much as you do, then make Oscar Wylee your first choice.
* Chatswood Chase:  Chatwood is close to Macquarie Centre with just 8-10 km in between stores and can be found on the lower ground of the Chatswood Chase Shopping Centre. The [Oscar Wylee Chatwood](https://www.oscarwylee.com.au/locations/optometrist-chatswood-chase.html) store is located at Victoria Ave and offers important health services to make sure your vision is in optimal condition.
* Rhodes:  Rhodes is close to Macquarie Centre with just 10 km in between stores and can provide all the services you may be looking for. Whether you need prescription glasses or to have your prescription updated, our team can take care of it all. Make an appointment with the [Oscar Wylee Rhodes](https://www.oscarwylee.com.au/locations/optometrist-rhodes.html) store today!
### Oscar Wylee Macquarie optometrists perform bulk billed eye tests
With Oscar Wylee, you can prioritise your eye health and take care of your vision. Just stop by our Oscar Wylee eyeglasses shop in Macquarie Centre where the eye care processes available include prescription updates, eye health tests to assess vision and detect certain eye diseases, and frame shopping. At Oscar Wylee Macquarie Centre, eye tests are bulk billed for eligible Medicare card holders and performed by our dedicated and experienced Oscar Wylee optometrists.
### Oscar Wylee Macquarie Centre accepts major health funds
At Oscar Wylee Macquarie Centre our staff are there to help process your health fund claim in-store and answer any questions about eligibility for your health fund. You don’t have to navigate the most challenging parts of private health insurance alone. Oscar Wylee Macquarie Centre is dedicated to making sure you get what you need at an affordable, competitive price.
### Fashion-forward styles at affordable prices
Oscar Wylee Macquarie Centre is committed to helping you find the perfect pair of frames, with a wide range of modern and vintage-style glasses frames at an affordable cost. Our Oscar Wylee Macquarie Centre optometrists help to provide prescription lenses to fit customer needs whether it’s a blue light filter, multifocal lens, or a polarised lens for your prescription sunglasses, our experts in-store are ready to help you with any of your eyesight requirements.
Book Appointment
[Call us: (02) 8593 1033](tel:(02) 8593 1033)
[Leave a Review!](https://g.page/r/CfZOmOlWvkLtEBM/review)