# Source: https://www.oscarwylee.com.au/vs-bailey-nelson

# Oscar Wylee vs Bailey Nelson Glasses and Eyewear
Published on May 9th, 2025
Updated on June 17th, 2025
Oscar Wylee is
an Australian optical company that provides fashionable spectacles for
both prescription and non-prescription requirements. [Oscar Wylee](https://www.oscarwylee.com.au/) began its
journey in 2012 when it initially launched as an online eCommerce business.
They established their first-ever physical store in Chatswood in Sydney,
NSW, in 2025 and continued growing their business throughout Australia as
well as in New Zealand and Canada. Bailey Nelson was founded in 2012, in
Bondi and similarly, expanded their retail presence not just in Australia
but also in New Zealand and Canada. Bailey Nelson commenced their operations
only offering glasses, but later branched out into contact lenses and
optometry services. While Oscar Wylee and Bailey Nelson both started in
2012, Oscar Wylee currently has over 100 stores across Australia, while
Bailey Nelson currently has around 60 stores in Australia as of May 2, 2025.
Oscar Wylee and Bailey Nelson are both eyewear retail companies that provide
high-quality eyewear and eyecare.
Keep Your Eye Health On Track With Our Team!
We have dedicated optometrists and retail teams at all our stores to
ensure high-quality eye tests.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Oscar Wylee Eyewear Options](#options)
[Distinctions Between Oscar Wylee and Bailey Nelson](#distinctions)
[How to Find an Oscar Wylee Optometrist](#how-to-find)
[Return Policies](#return-policies)
## What are the Advantages of Buying from Oscar Wylee and Bailey Nelson?
The advantages of buying from Oscar Wylee
are their free eye tests for international students. Oscar Wylee
provides eye care accessibility for international students when they
purchase any pair of glasses on the same day. They only require a valid international ID and a student ID to show
to the staff. The advantage of buying from Bailey Nelson includes
their provision of contact lenses. Bailey Nelson's range of contact
lenses includes their own brand of lenses as well as Acuvue, Alcon and
CooperVision. However, both Oscar Wylee and Bailey Nelson similarly provide a wide
range of uniquely designed frames for both prescription and
non-prescription optical glasses and sunglasses.
### What Stylistic Eyewear Options Does Oscar Wylee Offer Compared to
Bailey Nelson?
The stylistic eyewear options that Oscar Wylee offers may include
options such as Oscar Wylee's
Mumford, Parker, Jinky and Humphrey, depending on
your personal style and preferences. Oscar Wylee's stylish
[eyewear](https://www.oscarwylee.com.au/glasses.html)
options include styles that vary between vintage-inspired, modern,
colourful and minimal. Here are some of Oscar Wylee's stylistic
options that customers may consider depending on their preferences,
listed below.
* Mumford: Oscar Wylee's Mumford is a
stylish eyewear option that features a timeless square-round shape,
making it a versatile frame. Mumford can be an ideal style for
everyday outfits, especially for medium faces and those with round
and oval faces, depending on your personal preferences.
* Parker: Oscar Wylee's Parker is
characterised as a square-round frame that can suit medium faces and
may be ideal for individuals with round, oval and heart face shapes.
* Jinky: Oscar Wylee's Jinky features
a high-bridge nose fit with an acetate frame and a bold rim. Its
tapered-square shape is perfect for a modern frame that is easy to
pair with different outfit styles.
* Humphrey: Oscar Wylee's Humphrey is
a perfect fusion of metal and acetate making it sleek, light and
smart. Its square-round shape makes it easy to include in your
everyday eyewear rotation.
[](https://www.oscarwylee.com.au/mumford-optical.html)
[Mumford](https://www.oscarwylee.com.au/mumford-optical.html)
$169    
Add to Cart
[Shop Mumford](https://www.oscarwylee.com.au/mumford-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/mumford-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/mumford-optical.html)
[](https://www.oscarwylee.com.au/parker-optical.html)
[Parker](https://www.oscarwylee.com.au/parker-optical.html)
$169    
Add to Cart
[Shop Parker](https://www.oscarwylee.com.au/parker-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/parker-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/parker-optical.html)
[](https://www.oscarwylee.com.au/jinky-optical.html)
[Jinky](https://www.oscarwylee.com.au/jinky-optical.html)
$169    
Add to Cart
[Shop Jinky](https://www.oscarwylee.com.au/jinky-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/jinky-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/jinky-optical.html)
[](https://www.oscarwylee.com.au/humphrey-optical.html)
[Humphrey](https://www.oscarwylee.com.au/humphrey-optical.html)
$169    
Add to Cart
[Shop Humphrey](https://www.oscarwylee.com.au/humphrey-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/humphrey-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/humphrey-optical.html)
### Why Choose Oscar Wylee or Bailey Nelson for Specialised Lenses?
You may choose Oscar Wylee or Bailey Nelson for specialised lenses as
they both have options that are suitable for your vision and/or
lifestyle needs. Oscar Wylee offers specialised lenses such as multifocal lenses,
photochromic lenses, tinted lenses, high index lenses, single vision
lenses, digital (blue light filter) lenses, polarised lenses and prism
lenses. Bailey Nelson offers specialised lenses such as multifocal
lenses, office and bifocal lenses, high-index lenses, coloured tints,
polarised lenses, and transition lenses.
### Why Choose Oscar Wylee or Bailey Nelson For Blue Light Blocking
Lenses?
You may choose Oscar Wylee or Bailey Nelson for blue light blocking
lenses, as
both brands offer frame options in a wide range of colours, styles
and materials. You may choose either Oscar Wylee
[blue light glasses](https://www.oscarwylee.com.au/glasses/blue-light/review)
or Bailey Nelson blue light glasses, depending on your personal
preferences.
### What are the Deals and Discounts of Oscar Wylee and Bailey Nelson?
Both Oscar Wylee and Bailey Nelson
offer deals and discounts that provide customers with varied
options to choose from.
The current Oscar Wylee deals include 2 pairs from $199 and 3 pairs
from $249 for optical prescription glasses with standard single-vision
lenses. Bailey Nelson currently offers popular 1 and 2 pair deals, 1
and 2 multifocal pair deals and a special discount on glasses and
sunglasses for students. You may decide to choose either Oscar Wylee's
deals and discounts over Bailey Nelson's deals and discounts, and vice
versa, depending on your personal preferences.
Do Oscar Wylee or Bailey Nelson Offer Transition Glasses?
Yes, both Oscar Wylee and Bailey Nelson
offer transition glasses. Oscar Wylee offer both
their brand of transition lenses, referred to as adaptive lenses and
the brand
Transitions®
GEN S™ for $160 on top of your prescription frames. Bailey Nelson's
offer of Transitions® glasses is available at an additional price on
top of your prescription frames.

### How Long Have Oscar Wylee and Bailey Nelson Been in Business?
Oscar Wylee and Bailey Nelson have been in the business
since around 2012. Oscar Wylee opened as an online
store in 2012, which means they have been in the business for around
13 years, achieving the establishment of over 100 stores in Australia
and several stores in New Zealand and Canada. Bailey Nelson, having
also opened in 2012, means that they've been operating for around 13
years, establishing over 50 stores in Australia and several stores
also in Canada and New Zealand.
### What Products and Services Does Oscar Wylee Offer?
The products and services of Oscar Wylee
include both prescription and non-prescription glasses,
comprehensive eye tests and personal styling assistance.
The products and services of Oscar Wylee are listed below.
* Prescription and Non-Prescription Glasses: One of the products and services that Oscar Wylee offers is
prescription and non-prescription glasses. You can find a wide range
of styles, such as minimal, bold and trendy.
* Comprehensive Eye Test: Oscar Wylee
provides comprehensive bulk billed eye tests. Our team and
optometrists will be happy to help with any eye health concerns you
may have.
* Personal Styling Assistance: Oscar
Wylee also offers personal styling assistance when choosing your
glasses and sunglasses. Our team is happy to help with selecting
frames that will suit your eye care needs and your style.
#### Does Oscar Wylee Have In-House Eye Specialists?
No, Oscar Wylee does not have in-house eye specialists, however,
Oscar Wylee does have a highly experienced optometrist in all
stores. Our optometrists are qualified to test for several eye
problems and can refer you to an ophthalmologist
for more complex eye issues. To see an
[eye specialist](https://www.oscarwylee.com.au/eye-health/optometrist-vs-ophthalmologist.html), you will need a referral from either your GP or an optometrist
first, as eye specialists are trained in managing and treating more
complex eye diseases.
#### Can You Order Prescription Glasses Online from Oscar Wylee?
Yes, you can order prescription glasses from Oscar Wylee online.
You will need a recent prescription to add online before ordering
your Oscar Wylee glasses online.
You can upload a photo of it, email it after checkout, have Oscar
Wylee call your optometrist for the prescription, or if you are an
existing customer, we will use the valid prescription we have on
file. After adding the prescription, you will need to choose the
lenses that will be fitted in the frames. We offer lenses such as
single-vision and high-index lenses. For bifocals and multifocals,
you will need to come in-store to be fitted for these lenses. In
addition to choosing the type of lenses, Oscar Wylee also offers
lens add-ons to cater to your vision preferences. The add-ons we
offer include Blue Light Filter, Anti-Reflective and Premium
Anti-Reflective. Once you have selected your frames, lenses and
add-ons, it's time to check out. At checkout, you will be asked to
enter your details so we can ship your glasses directly to your
home.
#### How to Find an Oscar Wylee Optometrist in Australia?
To find an Oscar Wylee optometrist in Australia,
go to our locations page to search for an Oscar Wylee store that
is most convenient for you.
[Finding an optometrist in Australia](https://www.oscarwylee.com.au/find-optometrist)
is quick and simple. Select the store that you would like to visit
for important information such as the store's opening hours, contact
number, the exact floor and position of the store and the option to
make a booking. If you are using a smartphone and have locations
turned on, searching for an Oscar Wylee store should provide store
locations near you. We have stores available in major cities as well
as regional and rural areas.
### What Products and Services Does Bailey Nelson Offer?
The products and services that Bailey Nelson offers include
prescription and non-prescription glasses and sunglasses, and eye
tests. They also offer their own brand of contact lenses as well as other
brands such as Acuvue, Alcon and CooperVision. Bailey Nelson eyewear
provides a blend of distinct patterns, varied colours, and minimal and
trendy styles.
### What Brands Does Bailey Nelson Carry?
Bailey Nelson does not carry any other brands for their eyewear as
they provide their own brand and design of frames.
The brands that Bailey Nelson do have are for contact lenses and
include Acuvue, Alcon and CooperVision according to their website.
#### Does Bailey Nelson Have In-House Eye Specialists?
No, Bailey Nelson
does not have in-house eye specialists. However, they do have
optometrists at every store. An eye specialist refers to an ophthalmologist, whom optometrists
will direct patients to if customers present symptoms of more
complex eye diseases.
Get a Full Quote in Store
Find your nearest Oscar Wylee store and our friendly staff can assist
you.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
## How Do the Product Ranges of Oscar Wylee and Bailey Nelson Differ?
The product ranges of Oscar Wylee and Bailey Nelson may differ
when it comes to some of their product offerings. Both brands
offer eyewear designs that can complement the personal styles of any
individual. The category in which Oscar Wylee and Bailey Nelson may
differ is listed below.
| Categories | Oscar Wylee | Bailey Nelson |
| --- | --- | --- |
| Clip-On Lenses | Oscar Wylee does not provide a clip-on lens product for your
glasses. | Bailey Nelson offers a clip-on lens that allows you to attach a
polarised and UV protection lens to certain Bailey Nelson frames. |
### Where are Oscar Wylee Stores located?
Oscar Wylee stores are located
in Australia, New Zealand and Canada, with their head
office operating in Australia. Most of Oscar Wylee's increasing retail
presence is based in Australia and continues in New Zealand and
Canada. Oscar Wylee stores can easily be found by using our
[locations page](https://www.oscarwylee.com.au/locations/).
#### Can Oscar Wylee Ship Their Products Globally?
No, Oscar Wylee
does not ship its products globally. However,
customers have access to domestic
[shipping](https://www.oscarwylee.com.au/shipping.html)
if they live in Australia, New Zealand and Canada. In Australia, all
domestic shipping orders are free.
### Where are Bailey Nelson Stores Located?
Bailey Nelson stores are located in
Australia, New Zealand and Canada. Their headquarters
are located in Sydney, Australia.
#### Can Bailey Nelson Ship their Products Globally?
No, Bailey Nelson does not ship their products globally.
They currently only ship their products to the US,
within Australia for purchases made on the Australian website, New
Zealand (for purchases made on baileynelson.co.nz), and Canada (for
purchases made on baileynelson.com).
### Which Brand Offers a Better Selection of Glasses, Oscar Wylee or
Bailey Nelson?
The brand that offers the better selection of glasses
will ultimately come down to your personal preferences.
Both Oscar Wylee and Bailey Nelson provide a varied range of styles,
colours, patterns and shapes for frames that stem from considerate
designs.
### What are the Return Policies For Oscar Wylee and Bailey Nelson?
The return policies for Oscar Wylee and Bailey Nelson
both include an aspect of eligible returns or repairs for glasses
when experiencing any manufacturing faults. Bailey Nelson's return policy also includes an offer to remake your
lenses within 30 days of purchase if you have any concerns. They also
offer a remake if you are not satisfied with the collection of your
frames, according to their website.
#### Which Brand Offers a Longer Warranty Period?
Both brands offer the same length of warranty periods.
Both Oscar Wylee and Bailey Nelson allow replacements or repairs
for frames that may be faulty within 1 year
of purchase, according to their respective websites.
### How are the Reviews of Bailey Nelson in Australia?
The reviews of Bailey Nelson overall
are positive reviews. Many customers enjoy the care
and quality reflected in their services during appointments with many
highlights being either the optometrists or retail staff and eyewear
selection.
#### Does Bailey Nelson Offer Repairs?
Yes, Bailey Nelson does offer repairs
for frames with defects related to material or production faults
within 1 year of purchase.
They also offer remakes for frames that don't meet customer
satisfaction upon the collection of your frames. If you have
concerns about your lenses, they may also offer to remake them
within 30 days of purchase, according to their website.
## What are the Main Alternatives to Bailey Nelson?
The main alternatives to Specsavers include
Oscar Wylee, EyeBuyDirect, OPSM, 1001 Optometry, Specsavers and Warby
Parker.
These are the main alternatives to Bailey Nelson, and their
distinguishing characteristics are listed below.
* Oscar Wylee: Oscar Wylee creates
solely in-house glasses for distinguished eyewear that are stylish,
affordable, and suited to every demographic.
[Oscar Wylee](https://www.oscarwylee.com.au/) also offers a
free eye test for international students when they purchase any pair
of glasses on the same day.
* EyeBuyDirect: [EyeBuyDirect](https://www.oscarwylee.com.au/vs-eyebuydirect)
is a budget-friendly eyewear brand that is solely based online, with
home try-ons options for many frame styles.
* OPSM: [OPSM](https://www.oscarwylee.com.au/vs-opsm) is an
Australian eyewear company with a range of glasses, lenses and optical
technology. OPSM also has a global eyecare charity, OneSight and
offers workplace services.
* 1001 Optometry: [1001 Optometry](https://www.oscarwylee.com.au/vs-1001-optometry)
offers many brands of glasses, sunglasses and contact lenses. Some of
their notable branded glasses include Ray-Ban and Burberry.
* Specsavers: [Specsavers](https://www.oscarwylee.com.au/vs-specsavers)
is an English eyewear retailer selling notable designer brands and
popular glasses collaborations alongside optometry and audiology
services.
* Warby Parker: [Warby Parker](https://www.oscarwylee.com.au/vs-warby-parker)
is an American eyewear brand with a variety of glasses, sunglasses and
contact lenses and helpful features such as a Style Quiz.
Major Health Funds Accepted In-store
For the purchase of frames and lenses, use your private health
insurance to limit how much you pay from your own pocket.
[Health funds](https://www.oscarwylee.com.au/health-funds.html)
Do You Have Any Vision Concerns?
Book an appointment with an Oscar Wylee optometrist today.
[Book an eye test](https://www.oscarwylee.com.au/booking)