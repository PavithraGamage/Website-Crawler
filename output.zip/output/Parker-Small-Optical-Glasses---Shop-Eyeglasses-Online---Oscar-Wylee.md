# Source: https://www.oscarwylee.com.au/parker-small-optical.html

# Parker Small
1
## Frame Design of Parker Small Glasses
The frame design of Oscar Wylee’s Parker Small glasses is characterised by their classic shape, high nose bridge, and acetate frame. Parker Small is a timeless unisex glasses frame that will complement any outfit, day to night.
$169    
In stock
Only %1 left
2 pairs from $199
Discount auto-applied at checkout
3 pairs from $249
Discount auto-applied at checkout
Qty
Add to cart
Book an eye test
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
excluding prescription lenses
## About Parker Small Glasses
Say hello to our mini Parkers! Featuring our well-loved classic shape, these frames offer a smart and versatile style that is comfortable for all-day wear. A perfect day-to-night companion for kids and teenagers after a more grown-up look.
| Frame fit | Measurements |
| --- | --- |
| Narrow | 44 - 16 - 132 |
These measurements mean lens width, bridge, and temple length in millimetres (mm). They can be found on the inside of the temple arm. If you already have a pair that you like, you can compare it to these measurements.
### Made from Acetate
Oscar Wylee’s Parker Small frame is a unisex classic glasses frame that is perfect for those with square, oval, and pear face shapes. The Parker Small frame is a stylish, versatile frame that can be worn every day. The main specs of Oscar Wylee’s Parker Small glasses frame, including dimensions, shape, materials, lenses, nose fit, and hinges, are listed below.
Filter category 2 - General purpose sunglasses. Good protection against sunglare. Good UV Protection. Not suitable for driving in twilight, at night or under dull conditions 
This frame comes with tinted lenses. An additional $30 will be added to your order total for prescription orders. 

| parker small Frame Features | Parker small Frame Description | Dimensions | Shape | Materials | Lenses | Nose Fit | Hinges |
| --- | --- | --- | --- | --- | --- | --- | --- |
| The dimensions of the Parker Small frame are measured in millimetres (mm) and are 44 - 16 - 132, meaning the lens width is 44 mm, the bridge is 16 mm, and the temple length is 132 mm. |
| Parker Small is a classic shape, well-suited to narrow faces. |
| Parker Small is made from acetate. |
| The lenses that can be used in the Parker Small frame are optical lenses, such as single-vision, multifocal, and non-prescription lenses, which are plain and can have a filter, such as a blue light filter, applied. |
| The nose fit for Parker Small is characterised by a high nose bridge. |
| The hinges in Parker Small are spring hinges, which are more flexible than other types of hinges and can extend past 90 degrees. |
Show All
### What Inspired the Frame Design of Oscar Wylee's Parker Small Glasses?
The Oscar Wylee Parker Small frame design was inspired by current fashion trends, as classic glasses are a timeless style.
## What to Know About Oscar Wylee's Parker Small Sunglasses?
There are many aspects of the Oscar Wylee Parker Small frames that customers should know about to decide whether this is the right frame for them. The Parker Small frame is a unisex classic-shaped frame. Oscar Wylee’s Parker Small frame is suitable for many face shapes, but particularly compatible with square, oval, and pear face shapes. The Parker Small frame’s simple design makes them fashionable all year round. Parker Small features the standard [parts of glasses](https://www.oscarwylee.com.au/glasses/eye/part-of-glasses), such as a rim, temples, lenses and spring hinges.
### What are the Types of Temple Tips or Earpieces Included with Oscar Wylee's Parker Small Glasses?
The type of temple tips or earpieces included in Oscar Wylee’s Parker Small Glasses are made from acetate.
### What Type of Nose Bridge do Oscar Wylee's Parker Small Glasses Have?
The type of nose bridge included in Oscar Wylee’s Parker Small frame is characterised by a high nose bridge.
### What Type of Nose Pads are Included with Oscar Wylee's Parker Small Glasses?
Oscar Wylee’s Parker Small frame does not include adjustable nose pads.
### What Type of Lenses do Oscar Wylee's Parker Small Sunglasses Have?
The type of lenses that typically come with the Oscar Wylee Parker Small [glasses frame](https://www.oscarwylee.com.au/glasses.html) are optical lenses. Optical lenses are glasses lenses that have a prescription within the lens to help correct vision issues such as myopia, hyperopia, and astigmatism. Parker Small frames can also come with non-prescription lenses, with add-ons such as a blue light filter. Parker Small frames can be customised into sunglasses in-store or online with add-on tints or polarisation.
### What Material is Used for the Rim of Oscar Wylee's Parker Small Glasses?
The material used for the rim of Oscar Wylee’s Parker Small glasses frames is acetate. The rim refers to the part of a glasses frame that holds the lenses.
### What Type of Hinges are Included with Oscar Wylee's Parker Small Glasses?
The type of hinges included with Oscar Wylee’s Parker Small frames are spring hinges. A spring hinge in a glasses frame refers to hinges that are more flexible than normal hinges and can go slightly beyond 90 degrees. Spring hinges can provide a closer fit to the face.
## What Face Types are Most Suitable for Oscar Wylee's Parker Small Glasses?
The face types that are most suitable for Oscar Wylee’s Parker Small frame are square, oval, and pear face types. The Parker Small frame is a classic shape, meaning that it complements the structure of square, oval, and pear faces particularly well. The classic Parker Small frames help balance the features of [square faces](https://www.oscarwylee.com.au/glasses/face-shapes/square), [oval faces](https://www.oscarwylee.com.au/glasses/face-shapes/oval), and [pear faces](https://www.oscarwylee.com.au/glasses/face-shapes/pear), bringing the eyes and brows forward in a flattering way. Although there are many [glasses for face shapes](https://www.oscarwylee.com.au/glasses/face-shapes) that may be considered more aesthetically suitable, it is important that people also choose frames that make them feel most comfortable and represent their personal style.
## What Size Options are Available for Oscar Wylee's Parker Small Glasses?
The size options available for Oscar Wylee’s Parker Small frame are an extra small fit across all colours.
## What Materials are Used to Create Oscar Wylee's Parker Small Glasses?
The material used to create the Oscar Wylee Parker Small frame is acetate. Acetate, also known as cellulose acetate, is a bioplastic made from cotton fibres or wood pulp. At Oscar Wylee, acetate glasses are made by adding a dye to cellulose acetate, which is rolled into a sheet. The shape of the glasses is then cut from this sheet.
## What’s Included
## OW Case &amp; Cloth
Protective Case and Lens Cloth
Our high-quality glasses case and lens cloth are included with every purchase of an Oscar Wylee frame. The stylish, magnetic case is made from a hard shell. This sturdy and durable material keeps your glasses protected and safe, wherever you go. Ensure your lenses are clean and scratch-free with our OW microfibre cloth, specifically designed to ensure you have comfortable vision through your lenses.
Oscar Wylee offers:
* Free Shipping on all orders
* 1 Year Warranty on frames and lenses
* Scratch resistance lens coating on all prescriptions
* UV-proof coating on all prescriptions
Health fund rebate: Once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. Learn more about [health funds](https://www.oscarwylee.com.au/health-funds.html).
## Make and Materials
Also known as cellulose acetate, these frames are traditionally hand-crafted by skilled craftsmen, with each frame passing through numerous stages of production and are hand-polished to ensure a glorious lustre. The frames then go through cleaning and strict quality control, and many pairs of crafting hands to be hand-assembled and polished. After your frames have gone through the production process, they are individually examined and&nbsp;packed before making their way to you!
## Warranty Information
### Warranty Information
### Warranty Information
Oscar Wylee provides a 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects. We will repair or replace faulty or defective frames or lenses free of charge for warranty claims made within 1 year of the delivery. We also offer repairs or replacement for problems experienced with vision during everyday use for claims made within 30 days of delivery. If the same product has been discontinued or is no longer available, then we may offer an exchange for a similar product or a refund.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Find a Store Location](https://www.oscarwylee.com.au/locations/full-store-list.html)
Recommended
1. [](https://www.oscarwylee.com.au/mai-optical.html)
[Mai](https://www.oscarwylee.com.au/mai-optical.html)
Clear Crystal