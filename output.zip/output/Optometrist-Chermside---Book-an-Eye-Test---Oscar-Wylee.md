# Source: https://www.oscarwylee.com.au/locations/optometrist-chermside.html

# Optometrist Chermside
Level 1, Shop 1182Gympie Rd &amp; Hamilton Rd Chermside QLD 4032
* Near Coles
Opening hours
Monday9:00am - 5:30pm
Tuesday9:00am - 5:30pm
Wednesday9:00am - 5:30pm
Thursday9:00am - 9:00pm
Friday9:00am - 5:30pm
Saturday9:00am - 5:00pm
Sunday10:00am - 4:00pm
*Store hours reflect local standard trading hours and exclude public holidays
[Visit our Chermside Google Business page for directions, reviews, and updates.](https://g.page/r/CQCE66ZtLnjNEAE)
Book Appointment
[Call us: (07) 3195 5516](tel:(07) 3195 5516)
[Leave a Review!](https://g.page/r/CQCE66ZtLnjNEAE/review)
Our Reviews
gretel osborne
2 days ago
So lovely and helpful ????. Booked a last minute for a eye appointment. On a Thursday night. And the...y were so helpful with picking out the right pair.
See more
Reese Dacey
4 days ago
Prasanth Vettiazath
5 days ago
Had a very positive experience at Oscar Wylee Optometrist at Westfield Chermside. The customer servi...ce was excellent, staff were polite, friendly and genuinely interested in helping me explore the available frames, without any pressure or pushy sales approach. That made the whole experience very comfortable.
The optometrist was also very good. The appointment was quick and efficient, and they were accommodating when discussing the different lens options and what would work best for me.
I felt the frame collection was a little limited from my personal perspective, but the pricing is very reasonable, especially considering the overall service and experience.
Overall, definitely a store worth checking out if you’re looking for glasses and a straightforward, pressure-free experience.
See more
Marijana Muharemovic
2 weeks ago
Thank you for such a great experience yesterday at Oscar.
From Steph, who took the extra time to ex...plain everything so clearly, to the wonderful optometrist, everyone was so friendly, professional, and helpful.
I truly appreciate the excellent service and care I received. I would happily recommend Oscar to all my family and friends. Thank you again for making my experience such a positive one!
See more
Kacey Brown
2 weeks ago
Not only did I break my only glasses, I was also overdue for a new prescription. However, the lovely... staff were able to squeeze me in for an appointment today (so close to closing too!) so I could order new glasses asap. On top of that, my appointment wasn't rushed at all. I really appreciate today so much! I apologise for not getting names but for the optometrist and sales employee, THANK YOU. You both were so incredibly kind and patient.
This is why I love Oscar Wylee so much ????????????
See more
Robyn Mcg
3 weeks ago
Very professional and super helpful
Paul Armstrong
4 weeks ago
Process was okay. Staff good. Testing not quite as good as expected. I had to get new lenses after f...irst type unsuitable.
See more
Angelo De Gioannis
1 month ago
Very pofessional service
Cassie Ryan
1 month ago
Ronald Rodrigues
1 month ago
This is my second visit within two weeks. It was quick, easy and professional.
Carolyn Theodosiou
1 month ago
First time at OC Chermside, the Optometrist was professional, friendly and very knowledgeable in her... field of expertise.   A previous optometrist elsewhere brushed off my eye issues on my last test, not this time with OC’s best Optometrist in my opinion.  I walked in there a few weeks back and was given great advice by their friendly staff and this time staff were equally friendly and knowledgeable. They also have some nice frames to boot.
See more
World Enough
1 month ago
Trisha Pace
1 month ago
My optometrist was extremely helpful and knowledgeable about my needs.
Leonie Brewer
2 months ago
Ryan was great, fitted me in with no appointment which was greatly appreciated and staff were
Helpfu...l and friendly
See more
Cathie R
2 months ago
Pleasant, helpful staff.  Optometrist Li was excellent, explained everything as she went and made it... a great experience.
See more
Jeung hun Lee
2 months ago
Amanda Gregory
2 months ago
Milla Fargo
2 months ago
Incredible experience. After 4 years between eye tests, the Chermside team was a welcome sight. Thei...r retail staff are so friendly and attentive. The optometrist I saw was incredibly supportive and took the time to extend my appointment to establish a baseline for my “file”, seeing as it had been so long for me. I felt so at ease and learned a lot about how my eyesight operates and what to be mindful of. I wish I got her name, a 100/10 experience.
See more
Sim Arita
2 months ago
The shop has lovely ladies very helpful and fit me in for an eye check as a walk-in which I was very... grateful for
See more
Susan
2 months ago
Happy Soul
2 months ago
Very happy with the service. Staff were very professional and friendly.
Michelle Vanden
2 months ago
Madison Fynn-Waddell
2 months ago
Very quick service by Optician and lovely manner. Very friendly. Charlotte was fantastic and helped ...us choose our new glasses and had lots of laughs. Thanks guys see you soon to collect our glasses. Laura and Daniel
See more
K Doane
2 months ago
Fantastic experience at the Chermside shop.
Rose Humphrey
2 months ago
Andy Hwang
2 months ago
I thoroughly enjoyed the process of this eye exam! The young lady that guided me through it was supe...r kind and chill, the exam itself was quite a unique sensory experience, my eyes have never perceived their own examination, and being able to see up close what it looks like was insightful and fun. The Korean lady was very professional and gave instructions that were easy to follow. Would totally do this again just for fun!
See more
Juli Lakatara
2 months ago
Sunil John
3 months ago
The optometrist was friendly and knowledgeable, overall a good experience!
Karoline Dos Santos
3 months ago
We had an amazing experience with Charlotte. She was so lovely, caring, and gave us really helpful t...ips about glasses and what would suit best. I highly recommend going to see them.
The optometrist was also amazing, very knowledgeable, professional, and not just focused on selling glasses. Thank you so much, guys! We had so much fun!
See more
Dylan McLean
3 months ago
Refik Kanjhan
3 months ago
Excellent! Thank you!
Daniel Boucher
4 months ago
Great advice. Informative and transparent.
Geoff French
4 months ago
Everything went smoothly and quickly. Very happy. Thanks
Janek Kedzia
4 months ago
nice
Loz Kelly
4 months ago
Great experience. Very thorough, honest and professional eye test and I really appreciated the help ...I received when selecting my new frames. Very happy!
See more
Chelsea Ham
4 months ago
The optometrist at Chermside was wonderful. My daughter had seen another and was simply told to stop... using her Ipad so much without explaining her problem. As somebody who is conservative with ipad use, she didn't benefit from this advice. The optometrist at Oscar Wylee properly identified her astigmatism and explained why her issue exists and what can be done. She was the ideal health professional and opened up many opportunities for questions.
See more
Mika Beck
4 months ago
I got an eye test done here, 10/10 experience,, I feel bad for the lady working at the counter who l...ooked awkward after my mother interrupted her multiple times and was trying to do her job. If you're reading this, I am so so sorry,
See more
Sandra Brotzman de Vallejo
4 months ago
Good price and service.
Holy Basil Thai Cuisine
4 months ago
I got superb aervice here.   I ended up with having 2 eyeglasses with them.  The best advice and car...es. Reccomended!!
See more
Flin Purnama
4 months ago
I think it was very good. I got a small accident in my garden and got a red eye that looked bad. The... optometrist expertly had a look and diagnosed the problem. She gave me quite a relieve with her analyses and advice. She and the other staff were quite good, highly recommended.
See more
Curtin 18866559
4 months ago
It was a great experience shopping here for new frames and rechecking my prescription. Very professi...onal store, and without the busy hustle and bustle and long wait times of some of other places. A more chill vibe, upmarket. The optometrist was great and so was the rest of the staff, Emma-Leigh in particular was very friendly and helpful.
See more
Ye Mon Soe
4 months ago
Optometrist was really comprehensive in testing my eye sight and she explained the situation to me r...eally well. ????
The front staff were also friendly and gave me many options from me to choose from.
Seamless experience getting my prescription sunglasses.
See more
Anne Goudie
4 months ago
Very smooth and quick appointment no waiting straight in for test and consultation. Appointment was ...over in 10-15mins
See more
chanelle bennett
4 months ago
Momo Chey
4 months ago
Very friendly young lady that served me with the glasses and the eye specialist was amazing. Very ha...ppy. Can't wait to get my new glasses.
See more
Annemarie Ross
5 months ago
Linda Melit
5 months ago
The team was very professional, friendly and efficient
Ian Morse
5 months ago
joel lopez
5 months ago
Bree Sonter
5 months ago
Excellent service, fantastic optometrist and great range of glasses and sunglasses to choose from.
## Find an Optometrist in Chermside With Oscar Wylee
If you are in the Aspley, Stafford Heights and Geebung areas, our Oscar Wylee Chermside store is your one-stop shop for all things optometry. We provide some of the best optometry services in Chermside. Here our dedicated Oscar Wylee Chermside optometrists can provide Medicare bulk billed eye tests and our friendly store staff can help you shop our affordable and stylish range of glasses - all in one trip! So browse our range for your next pair of prescription sunglasses or prescription glasses today. 
Located on level 1 near Coles, you can reach our Oscar Wylee Chermside store via car with the centre providing 2-hour free parking. The Chermside bus interchange is also situated just outside of the centre with plenty of services running. Once done with your appointment, why not browse some of Westfield’s 100 stores whilst you’re here, from retail and lifestyle to dining. If you want to get outdoors, Chermside Aquatic Centre and Water Park is just down the road, as is Marchant Park, perfect for a relaxing walk. Prioritise your vision and come in and see us at our Oscar Wylee Westfield Chermside store for your next eye health test.        
Meet Our Team
* Optometrist Partner
* Store Manager
Our Services
* Bulk Billed Eye Examinations
* Professional Frame Styling
* Frame Adjustments and Repairs
Show All
## Find an Optometrist in Chermside, Brisbane for an Eye Health Test
An optometrist in Chermside, Brisbane can be visited for an eye health test. For excellent eye care services, visit Oscar Wylee Chermside where you can browse a wide range of frames in optical glasses and prescription sunglasses. At our glasses store in Chermside in Brisbane, we have an optical dispenser that can provide professional frame styling as well as fitting.
There’s no need to have an eye test with an eye doctor as our Oscar Wylee optometrists are qualified to perform comprehensive eye tests so you can get an eye health test in Chermside. An eye test will check eye movement and assess a patient's vision and the health of the eyes which involves checking for any signs of eye diseases. The average price range for an optometrist in Chermside can vary depending on factors such as the patient’s overall age, health and visual needs.
## How to Find an Optometrist in Chermside, Brisbane?
To find an optometrist in Chermside, Brisbane, you can take certain steps that can help make it easier for you such as searching online, assessing the store’s opening hours and finding the directions to your chosen location. The steps on how to find an optometrist in Chermside are listed below.
1. Search online using the phrase, optometrist near me in Chermside. This can also be done here on the website via our locations page.
2. Click on the Oscar Wylee link, which will take you directly to our Chermside optometrist store page.
3. See the store’s opening hours and where the store is located specifically.
4. Use the Chermside Google Business page link located under store hours to see the directions on how to get to the store.
You can also find an optometrist in Chermside by searching the keywords optometrist near me. If you have locations enabled on your smartphone and you’re in the Chermside area, our Oscar Wylee Chermside store page should appear easily for you to click on.
### Is it Hard to Get an Eye Appointment in Chermside, Brisbane?
No, it is not hard to get an eye appointment in Chermside. You can easily book an appointment to see an Oscar Wylee optometrist in Chermside right here on this page. At Oscar Wylee we have highly qualified optometrists available for bulk billed eye appointments, which can be booked online, over the phone, or in-store.
#### How to Compare Optometrists in Chermside to Each Other?
To compare optometrists in Chermside, you can use factors such as eye tests offered, health fund coverage, lens types and add-ons and eyewear offered. To take care of your vision and eye health, it is important to receive an eye test at least once every two years. There are different types of tests that can be performed in an eye test and not all optometrists may offer the same tests. Health funds can be used to help cover some of the cost of your frames and lenses. To find out if your health fund is accepted at an optometrist in Chermside, visit their website. In the case of Oscar Wylee, we accept all major health funds and provide on-the-spot claims in-store. There are many different lens options available for prescription glasses such as single vision, multifocal and high index lenses. Most optometrists in Chermside will offer these lenses although it is good to make sure. There are also lens add-ons available to enhance your glasses such as anti-reflective and blue light filters. Finally, if you are looking to purchase a pair of glasses after your eye test, you can compare the different styles and colours you are interested in from the optometrists in Chermside, Brisbane. Oscar Wylee offers a wide range of frames with vintage and modern inspirations in bold colours and subtle designs.
#### How to Find an Eyeglasses Shop in Chermside, Brisbane?
To find a glasses store in Chermside, you can try to follow these simple steps including searching online, selecting a convenient location and looking at their health insurance policies. The steps on how to find a glasses store in Chermside, Brisbane are listed below.
1. Search online using the phrase, glasses store in Chermside. This will provide you with various options for glasses stores in the whole Chermside, Brisbane area.
2. Select a glasses store that is most convenient for you to travel to.
3. Click the link to find out more information such as opening hours, exact location and directions to the glasses store in Chermside.
4. Read their health insurance policies to ensure you know what health benefits you can access.
Our Oscar Wylee glasses store in Chermside, Brisbane offers primary eye care services such as comprehensive eye tests as well as other services performed by an optometrist and offers prescription and non-prescription eyewear.
##### Is it Possible to Purchase Prescribed Sunglasses in Chermside, Brisbane Without Seeing an Optometrist?
Yes and no, it is possible to [purchase prescribed sunglasses](https://www.oscarwylee.com.au/sunglasses.html) in Chermside, Brisbane without seeing an optometrist if you already have a prescription that has not expired. If your prescription is expired, you can book an eye test to receive an updated or new prescription which will require you to see an optometrist. This will ensure your prescription sunglasses are appropriate for your visual needs.
## Where is the Oscar Wylee Chermside Optometrist Located in Brisbane?
The Oscar Wylee Chermside optometrist is located in Westfield Chermside on level 1 near Coles. Oscar Wylee Chermside offers optometry services for those in Aspley, Stafford Heights and Geebung areas. Westfield Chermside is a regional shopping centre in the north of Brisbane.
### What is the Phone Number of Oscar Wylee Chermside Optometrist Store?
The Oscar Wylee Chermside optometrist store phone number is [(07) 3195 5516](tel:(07) 3195 5516). You can contact the Oscar Wylee Chermside store between the hours of 9 am and 5:30 pm from Monday to Wednesday, 9 am and 9 pm on Thursdays, 9 am and 5:30 pm on Fridays, 9 am to 5 pm on Saturdays and 10 am and 4 pm on Sundays.
### What are the Reviews for Oscar Wylee Chermside Optometrist in Brisbane?
The many reviews for Oscar Wylee Chermside optometrist in Brisbane, left by our various customers can be found here on the website and online when you search for Oscar Wylee Chermside optometrist. The reviews for Oscar Wylee Chermside optometrist are listed below.
* Peter Elliott:  Great friendly service, always there to help. Very professional and efficient with a good range of frames.
* Sally Davison:  Excellent optometrist and staff. I ended up going with 3 pairs of glasses. Easy and friendly experience.
* Kate Hill:  Experienced amazing customer service and care thanks to Ayla at Chermside. Thank you Winny! Your extra care, service and attention to detail are cherished and greatly appreciated. I’ve had a great experience with OW for the last 2 years. Thank you Kate.
* Cara Ferguson:  From welcoming to pre-testing, to walking out the door, it was an exceptional experience. The staff were amazing.
#### What Treatments or Eye Care Processes are Done in the Oscar Wylee Chermside Optometrist Location?
The treatments or eye care processes done in the Oscar Wylee Chermside optometrist, Brisbane location include a tonometry test, a slit lamp exam and a refraction test. Additional tests that may also be performed can include a dilated fundus exam. The treatments or eye-care processes that are done in the Oscar Wylee Chermside optometrist location are listed below.
* A Tonometry Test: An optometrist or optical dispenser will conduct a tonometry test which involves the use of a machine that will release small puffs of air into your eyes. This will assist with measuring pressure in the eye.
* Slit Lamp Test: A slit lamp test can be used to evaluate your eye health, by examining your cornea and iris which are the anterior and posterior of the eye.
* Refraction Test: During a refraction test, an optometrist will have you view an image through different lenses and ask you to confirm which helps you see the image clearer.
* Dilated Fundus Exam: A dilated fundus exam can help an optometrist assess your health in more detail by getting a clear view of the retina. This test is typically carried out for patients with diabetes and those who may be at risk of developing retinal damage.
## How Many Optometrists Exist in Chermside, Brisbane?
There are many optometrists that exist in Chermside, Brisbane to provide eye tests and glasses, including Oscar Wylee. The amount of optometrists available in an area will typically depend on the population. At Oscar Wylee Chermside, we offer excellent optometry services including eye tests performed by skilled optometrists using high-quality equipment. We also have a wide range of fashion-forward frames that customers can browse in a large selection of sizes and colours. If you’re looking for an optometrist in Chermside, choose Oscar Wylee and we will take care of your optometry and eyewear needs.
### What are the Other Closest Optometrist Locations to Chermside, Brisbane in Australia?
The other Oscar Wylee closest optometrist locations to Chermside in Australia are Carindale, Brisbane - Albert St, Strathpine and Indooroopilly. The locations and their distance from Chermside are listed below.
* Carindale:  Carindale is close to Chermside, around 20-21 km. The [Oscar Wylee Carindale](https://www.oscarwylee.com.au/locations/optometrist-carindale.html) store is located in Brisbane’s South Eastern suburbs in Westfield Carindale. Oscar Wylee Carindale offers excellent eyewear and optometry services including comprehensive eye tests and frame adjustments and repairs.
* Brisbane - Albert St:  Albert St is close to Chermside, around 12-14 km. The [Oscar Wylee Brisbane - Albert St](https://www.oscarwylee.com.au/locations/optometrist-albert-st.html) store is located in the Brisbane CBD near Vans. Visit Oscar Wylee Brisbane - Albert St for your annual eye test and you can also browse our wide range of fashion-forward frames.
* Strathpine:  Strathpine is close to Chermside, around 11-13 km. The [Oscar Wylee Strathpine](https://www.oscarwylee.com.au/locations/optometrist-strathpine.html) store is located in the Strathpine Centre near the food court. For Medicare, bulk billed eye tests and fashion-forward frames, visit Oscar Wylee Strathpine.
* Indooroopilly:  Indooroopilly is close to Chermside, around 17-20 km. The [Oscar Wylee Indooroopilly](https://www.oscarwylee.com.au/locations/optometrist-indooroopilly.html) store is in the Indooroopilly Shopping Centre near Coles. Oscar Wylee Strathpine offers high-quality eye tests, professional frame styling and digital retinal scanning.
### Oscar Wylee Chermside Conducts Optometrist Eye Tests
Choose our Oscar Wylee Chermside store for bulk billed eye health tests for valid Medicare cardholders. Have your yearly eye examination, vision testing and shop for your new prescription on the same day. Our comprehensive eye testing is able to identify signs of eye disease and eye conditions, so we encourage you to get your eyes tested at least once every two years.
### Major Health Funds Accepted
At our eyeglasses shop, you can count on our Oscar Wylee Chermside team to walk you through the ins and outs of your health fund. We can process your health fund claim at our Oscar Wylee Chermside store with a valid health fund card. We can also help answer any questions about what your health fund plan makes you eligible for. Here at Oscar Wylee, we care about you receiving the best glasses and prescription sunglasses at affordable prices.
### Stylish Frames at Oscar Wylee Chermside
If you’re in search of glasses that are modern, fashionable and affordable, then Oscar Wylee Chermside is your best option. Like at all our stores, the Oscar Wylee Chermside team will personally assist you with finding the best frames for your face shape and visual needs! And now, you can get styled for less with our prescription glasses frames at 3 pairs from $249. We’ve also got prescription sunglasses, available so don’t miss out on looking your best with Oscar Wylee frames.
Book Appointment
[Call us: (07) 3195 5516](tel:(07) 3195 5516)
[Leave a Review!](https://g.page/r/CQCE66ZtLnjNEAE/review)