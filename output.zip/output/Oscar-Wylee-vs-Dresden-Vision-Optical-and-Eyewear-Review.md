# Source: https://www.oscarwylee.com.au/vs-dresden-vision

# Oscar Wylee vs Dresden Vision Optical and Eyewear Review
Published on July 25th, 2025
Updated on August 23rd, 2024  
Australia
Australia
New Zealand
Canada
Canadian French

Oscar Wylee is an Australian founded eyewear company selling solely in-house designed eyewear, first launching online in 2012. [Oscar Wylee](https://www.oscarwylee.com.au/) then branched into physical stores, with its first store opening in 2015 in Sydney, Australia. Oscar Wylee eventually expanded to New Zealand in 2019 and Canada in 2021. Dresden Vision was co-founded in 2014 by Bruce Jeffreys and Jason McDermott in Sydney, Australia, with physical stores also in Canada, selling solely in-house made glasses. Read on for the similarities, differences and distinctions between these two trusted glasses companies.
Book an Eye Test With Oscar Wylee Today
Our highly trained optometrists are available to provide bulk billed eye tests to eligible Medicare card holders.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Distinctions](#Distinctions) [Product Ranges](#Ranges) [Kids’ Glasses](#Kids)
## What Are The Distinctions Between Oscar Wylee and Dresden Vision?
Some distinctive characteristics of Oscar Wylee compared to Dresden Vision are their larger range of eyewear and international students eye test initiative. Oscar Wylee has a larger range of eyewear in both their optical glasses and sunglasses selection. With over 200 frames sold, there is a wider range of colours, shapes and frame materials available for customers to choose from, as of July 2025. Both Dresden Vision and Oscar Wylee accept bulk billing from Medicare and private health insurance. Oscar Wylee extends extra assistance to international students in Australia and New Zealand. If students buy a pair of Oscar Wylee glasses, then they can receive a free eye test on the same day.
Some distinctive characteristics of Dresden Vision compared to Oscar Wylee are their customisable glasses parts option for customers and online pupillary measurement tool. Dresden Vision allows customers to customise their glasses temples. For example, they can get a Clear Frost frame and customise the arms to be a Sky Blue for a pop of colour and two-toned aesthetic. Dresden Vision has an online pupillary measurement tool that can be convenient for those ordering glasses online. With a phone or computer camera, the tool can measure your pupillary measurement, which is essential for correctly aligning lenses with your eyes.
### What Stylistic Eyewear Options Does Oscar Wylee Offer Compared to Dresden Vision?
Some stylish eyewear options from Oscar Wylee include Peyton, Serge 2, Mesa and Betty. Oscar Wylee offers a variety of glasses in different shapes and materials. Read more about some of the stylish eyewear options at Oscar Wylee compared to EyeQ Optometrists listed below.
* Peyton: The Oscar Wylee Peyton frame is an acetate and metal combination, providing a sleek, striking aesthetic.
* Serge 2: The Oscar Wylee Serge 2 frame is a newer iteration of the iconic Serge frame, with features such as 5-barrel hinges and silicone nose pads.
* Mesa: The Oscar Wylee Mesa frame is characterised by a slightly oversized square shape in a variety of bright colour options for statement eyewear.
* Betty: The Oscar Wylee Betty frame is made from metal with a distinct acetate cat-eye temple tip for a feminine, unique charm.
[](https://www.oscarwylee.com.au/peyton-optical.html)
[Peyton](https://www.oscarwylee.com.au/peyton-optical.html)
$169    
Add to Cart
[Shop Peyton](https://www.oscarwylee.com.au/peyton-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/peyton-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/peyton-optical.html)
[](https://www.oscarwylee.com.au/mesa-optical.html)
[Mesa](https://www.oscarwylee.com.au/mesa-optical.html)
$169    
Add to Cart
[Shop Mesa](https://www.oscarwylee.com.au/mesa-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/mesa-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/mesa-optical.html)
[](https://www.oscarwylee.com.au/betty-optical.html)
[Betty](https://www.oscarwylee.com.au/betty-optical.html)
$169    
Add to Cart
[Shop Betty](https://www.oscarwylee.com.au/betty-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/betty-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/betty-optical.html)
### Why Choose Oscar Wylee Or Dresden Vision For Specialised Lenses?
Oscar Wylee and Dresden Vision both have specialised lens options to customise their glasses so customers can purchase eyewear that accommodates their everyday needs.
#### Oscar Wylee Specialised Lenses
Oscar Wylee provides both prescription and non-prescription lenses. Oscar Wylee specialised lenses include extra thin, super thin and ultimate thin lens options alongside their standard lens to accommodate stronger prescriptions. These Oscar Wylee thin lenses come with a complimentary Basic Anti-Reflective coating. Oscar Wylee has a range of sunglasses for UV protection. Oscar Wylee also has a Premium Anti-Reflective Lens Coating add-on that is also anti-static, scratch, and smudge resistant, while the BLULite Filter reduces potentially harmful blue light from digital screens. Oscar Wylee also has Transitions® GEN S™ lenses available in store, smart lenses that automatically darken in the sun and quickly return to clear indoors.
#### Dresden Vision Specialised Lenses
Dresden Vision does prescription and non-prescription frames. Dresden Vision specialised lenses include blue light lenses for optical glasses, and Mirror lenses, Photochromic, and Polarised add-on lenses for sunglasses. Dresden Vision also has glasses with built-in specialised lenses. These include Reading Glasses with magnification power that can be selected either in-store or online, and blue light glasses that can be worn as non-prescription or prescription frames.
### Why Choose Oscar Wylee or Dresden Vision For Blue Light Blocking Lenses?
Both Oscar Wylee and Dresden Vision offer glasses that have blue light blocking lenses. Oscar Wylee provides[glasses that block blue light](https://www.oscarwylee.com.au/glasses/blue-light/review). Customers simply have to add a blue light filter to any optical prescription with up to a 1.67 index, or non-prescription glasses. Oscar Wylee’s BLULite Filter product includes a basic anti-reflective coating. Dresden Vision allows customers to add a blue light filter to their glasses or alternatively, select from their range of blue light frames, which already have blue light lenses in-built.
#### Do Oscar Wylee or Dresden Vision Offer Repairs, Adjustments, or Warranty Replacements for Glasses?
Yes, Oscar Wylee offers repairs, adjustments or warranty adjustments for glasses. Oscar Wylee customers can head into the store and be assisted by a retail member to repair their glasses. Oscar Wylee has a warranty period of 12 months. If there are production faults, such as material issues, defective frames or damage from the product's manufacturing, Oscar Wylee offers replacement or repair of your purchase, completely free of charge. However, this excludes damage caused by misuse or accidental breakage.
Yes, Dresden Vision offers repairs, adjustments or warranty replacements for glasses. If a Dresden Vision frame breaks within the first ten years of its purchase, it will be replaced, which can be done by bringing it into a store or posting it. Dresden Vision lenses come with a 2-year manufacturer's warranty, covering defects like crazing and discolouration; however, improper handling defects are not covered under this. Under Australian Consumer Law, Dresden Vision offers customers a replacement or a refund for a major failure and compensation for any other reasonably foreseeable loss or damage.
### How Long Have Oscar Wylee and Dresden Vision Been in Business?
Oscar Wylee has been in business since 2012, beginning as an E-commerce store. Oscar Wylee's first physical store opened in Chatswood Interchange in Sydney, Australia in 2015. Dresden Vision was co-founded in 2014 by Bruce Jeffreys and Jason McDermott with its first store opening in Newtown, a suburb in Sydney, Australia.
### What Products And Services Does Oscar Wylee Offer?
Oscar Wylee provides [prescription glasses](https://www.oscarwylee.com.au/glasses.html), non-prescription glasses, and sunglasses. Services at Oscar Wylee include bulk billed eye tests and a lifetime guarantee of adjustments or professional cleaning for Oscar Wylee glasses.
#### Does Oscar Wylee Have In-House Eye Specialists?
No, Oscar Wylee does not have in-house [eye care professionals](https://www.oscarwylee.com.au/eye-health/optometrist-vs-ophthalmologist.html) such as ophthalmologists. However, Oscar Wylee does have optometrists who conduct extensive eye tests, diagnose eye problems and write prescriptions. These Oscar Wylee optometrists can refer you to an ophthalmologist for more serious eye issues. Oscar Wylee also has retail staff at their stores that provide stylistic assistance and advice to customers so they can pick out fashionable glasses that complement their face.
#### Can You Order Prescription Glasses Online From Oscar Wylee?
Yes, you can order prescription glasses online from Oscar Wylee. This can be done directly on the Oscar Wylee website during checkout. You can provide them with your optometrist's contact information, and Oscar Wylee will get in touch with them, or you can upload a prescription copy, or click "send later" and send Oscar Wylee a copy via email. These can be delivered to your doorstep or collected in-store.
#### How to Book An Eye Test With Oscar Wylee In Australia?
To [find an Oscar Wylee Optometrist](https://www.oscarwylee.com.au/find-optometrist) in Australia is simple. On the website, click the ‘Book an Eye Test’ button, select a store, select a date and time and provide your contact details. Read more on these steps on how to book an eye test with Oscar Wylee in Australia below.
1. Click the ‘Book An Eye Test’ Button: Click the ‘Book An Eye Test’ button on the Oscar Wylee website. This can be found at the top right of the website or at the footer under the heading 'Eye Test.'
2. Select a Store: Select an Oscar Wylee store that is most convenient for you. To make this easier, enter your postcode in the search bar to find the nearest Oscar Wylee optometrist to your home or desired location.
3. Select a Date and Time: Select the date and time you would like your eye test to be.
4. Provide Your Contact Details: Provide your contact details so the store can contact you closer to the appointment.
Update Your Prescription Today.
See our team in-store to update your prescription. We offer bulk billed eye tests and quality eye care assistance.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
## What Products and Services Does Dresden Vision Offer?
Dresden Vision products encompass prescription and non-prescription glasses and sunglasses, contact lenses and eyewear accessories. Dresden Vision services include eye tests available to customers.
### What Brands Does Dresden Vision Carry?
Dresden Vision does not carry any branded glasses. Dresden Vision solely sells its own branded eyewear, which is made in Australia.
#### Does Dresden Vision Offer Access to Optometrists or Prescription Validation?
Yes, Dresden Vision offers access to Optometrists who give prescription validation. Dresden Vision optometrist services are on-site and they conduct eye tests and write prescriptions so customers can get prescriptive eyewear.
## How do the Product Ranges of Oscar Wylee and Dresden Vision Differ?
The product ranges of Oscar Wylee and Dresden Vision differ through their brands, collections, and eye test offerings. The product range differences between Oscar Wylee and Dresden Vision are listed below.
| Category | Oscar Wylee | Dresden Vision |
| --- | --- | --- |
| Variety of Frames | Oscar Wylee has over 200 optical glasses and sunglasses sold in a variety of colours, shapes and materials. | Dresden Vision has two frames at the time of writing this article: The Original and Capote. However, these come in a variety of colours and can be customised with different temples. |
| Accessories | Oscar Wylee offers lens cleaners, glasses cases and tote bags as their accessories. | Dresden Vision offers eyeglass cases, lens spray and wipes, eye care products, glasses straps, and glasses clips. |
| Kids Collection | Oscar Wylee has a Kids Collection of glasses in bright colours, made from impact-resistant materials | Dresden Vision does not have a specific Kids Collection for its eyewear. |
### Where Can You Visit Oscar Wylee Physical Stores?
You can visit Oscar Wylee's physical stores across Australia, New Zealand and Canada, where there are[stores nearby](https://www.oscarwylee.com.au/locations/full-store-list.html) across multiple states and provinces.
#### Can Oscar Wylee Ship Its Products Globally?
No, Oscar Wylee does not ship its products globally. However, Oscar Wylee customers are eligible for domestic [shipping](https://www.oscarwylee.com.au/shipping.html) if they live in Australiam, New Zealand and Canada. In Australia, all Oscar Wylee domestic shipping orders are free.
#### Can Dresden Vision Ship Its Products Globally?
Yes, Dresden Vision can ship its products globally, with international shipping incurring a $9.95 shipping fee. Domestic shipping is available for Australian and Canadian customers with free shipping on orders over $125.
#### Do Oscar Wylee or Dresden Vision Offer Virtual Try-On Tools?
No, neither Oscar Wylee nor Dresden Vision offer virtual try-on tools for their [prescription glasses](https://www.oscarwylee.com.au/glasses.html). However, Dresden Vision offers an Online Pupillary Distance Measuring Tool to measure pupillary distance for accurate, well-fitting glasses.
#### Do Oscar Wylee or Dresden Vision Offer Glasses For Kids?
Yes, Oscar Wylee offers glasses for kids. Oscar Wylee has a [Kids Glasses](https://www.oscarwylee.com.au/glasses/collection/kids-collection.html) collection with colourful frames made from impact-resistant materials such as TR90 to accommodate kids’ play-filled lifestyles. Dresden Vision does not offer glasses specifically designed for kids; however, their smaller frames can work well for children’s wear.
## What are the Main Alternatives to Dresden Vision?
The main alternatives to George &amp; Matilda Eyecare include Oscar Wylee, EyeBuyDirect, OPSM, 1001 Optometry, Bailey Nelson, Specsavers, Vision Direct, Quay, Le Specs, and Laubman and Pank. The main alternatives to Dresden Vision are listed below.
* Oscar Wylee: [Oscar Wylee](https://www.oscarwylee.com.au/) creates solely in-house glasses for distinguished eyewear that are stylish, affordable, and suited to every demographic. Oscar Wylee also offers a free eye test for international students when they purchase any pair of glasses on the same day.
* EyeBuyDirect: [EyeBuyDirect](https://www.oscarwylee.com.au/vs-eyebuydirect) is a budget-friendly eyewear brand that is solely based online, with home try-on options for many frame styles.
* OPSM: [OPSM](https://www.oscarwylee.com.au/vs-opsm) is an Australian eyewear company with a range of glasses, lenses and optical technology. OPSM also has a global eyecare charity, OneSight.
* 1001 Optometry: [1001 Optometry](https://www.oscarwylee.com.au/vs-1001-optometry) offers many brands of glasses, sunglasses and contact lenses. Some of their notable branded glasses include Prada and Gucci.
* Bailey Nelson: [Bailey Nelson’s](https://www.oscarwylee.com.au/vs-bailey-nelson) wide glasses range are designed in Australia. They also have accessories such as clip-on’s which are polarised lenses that can be attached to the front of prescription glasses using a simple clip mechanism.
* Specsavers: [Specsavers](https://www.oscarwylee.com.au/vs-specsavers) is an English eyewear retailer selling notable designer brands and popular glasses collaborations alongside optometry and audiology services.
* Vision Direct: [Vision Direct](https://www.oscarwylee.com.au/vs-vision-direct) is an Australian eyewear company focused on affordable and accessible glasses.
* Quay: [Quay](https://www.oscarwylee.com.au/vs-quay) is an Australian sunglasses brand that is known for trendy sunglasses often worn at live music events and festivals.
* Le Specs: [Le Specs](https://www.oscarwylee.com.au/vs-le-specs) has a wide range of sunglasses, all from their own brand for trendy accessories perfect for a sunny day.
* EyeQ: [EyeQ](https://www.oscarwylee.com.au/vs-eyeq) is an Australian optometrist brand selling glasses, notable for their knowledgeable optometrist team and eyecare services.
* Laubman and Pank: [Laubman and Pank](https://www.oscarwylee.com.au/vs-laubman-and-pank) is an Australian-founded eyewear company selling in-house designed glasses.
ReadWire Frame Glasses: The Timeless Frame Style in other Oscar Wylee regions and their languages.
Australia
Australia
New Zealand
Canada
Canadian French
 
Are you due for an eye test?
At Oscar Wylee we offer bulk billed eye tests for eligible medicare card holders.
[Book an eye test](https://www.oscarwylee.com.au/booking)
Major Health Funds Accepted In-store
For the purchase of frames and lenses, use your private health fund insurance to minimise how much you pay from your own pocket.
[Explore Health Funds](https://www.oscarwylee.com.au/health-funds.html)