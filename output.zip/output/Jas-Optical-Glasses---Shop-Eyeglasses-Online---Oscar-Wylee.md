# Source: https://www.oscarwylee.com.au/jas-optical.html

# Jas
1
## Frame Design of Jas Glasses
The frame design of Oscar Wylee’s Jas glasses is characterised by their classic shape, nose pads and a stainless steel, copper, and acetate frame. Jas glasses are a unisex, sophisticated glasses frame that will complement any outfit, day to night.
$169    
In stock
Only %1 left
2 pairs from $199
Discount auto-applied at checkout
3 pairs from $249
Discount auto-applied at checkout
Qty
Add to cart
Book an eye test
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
excluding prescription lenses
## About Jas Frames
Jas imbues a quiet luxury, with its square frame shape and spring hinges perfect for bringing a refined, comfortable focal point look to your formalwear.
| Frame fit | Measurements |
| --- | --- |
| MEDIUM | 52 - 20 - 140 |
These measurements mean lens width, bridge, and temple length in millimetres (mm). They can be found on the inside of the temple arm. If you already have a pair that you like, you can compare it to these measurements.
### Made from Stainless Steel, Copper, and Acetate
Oscar Wylee’s Jas frame is a unisex, classic glasses frame that is perfect for those with square, oval, and pear face shapes. The Jas frame is a sleek, flattering frame that can be worn every day. The main specs of Oscar Wylee’s Jas glasses frame, including dimensions, shape, materials, lenses, nose fit, and hinges, are listed below.
| Jas Frame Features | Jas Frame Description | Dimensions | Shape | Materials | Lenses | Nose Fit | Hinges |
| --- | --- | --- | --- | --- | --- | --- | --- |
| The dimensions of the Jas frame are measured in millimetres (mm) and are 52 - 20 - 140, meaning the lens width is 52 mm, the bridge is 20 mm, and the temple length is 140 mm. |
| Jas is a classic shape with a thin rim, well suited to medium faces. |
| Jas glasses are made from a combination of stainless steel, copper, and acetate. |
| The lenses that can be used in the Jas frame are optical lenses, which include single vision and multifocal lenses and non-prescription lenses, which are plain and can have a filter like a blue light filter, applied. |
| The nose fit for the Jas frame is characterised by nose pads. |
| The hinges in Jas are spring hinges, which are more flexible than other types of hinges and can extend past 90 degrees. |
Show All
### What Inspired the Frame Design of Oscar Wylee's Jas Glasses?
The Oscar Wylee Jas frame design was inspired by current fashion trends, as classic shapes are often in fashion.
## What to Know About Oscar Wylee's Jas Glasses?
There are many aspects of the Oscar Wylee Jas frames that customers should know about, so they can decide whether this is the right frame for them. The Jas frame is a unisex, medium-fit, classic glasses frame. Oscar Wylee's Jas frame is suitable for many face shapes, but particularly compatible with square, oval, and pear face shapes. Jas features the standard [parts of glasses](https://www.oscarwylee.com.au/glasses/eye/part-of-glasses) such as a rim, temples, lenses, spring hinges and nose pads.
### What are the Types of Temple Tips or Earpieces Included with Oscar Wylee's Jas Glasses?
The type of temple tips or earpieces included in Oscar Wylee’s Jas glasses are made from acetate.
### What Type of Nose Bridge do Oscar Wylee's Jas Glasses Have?
The type of nose bridge included in Oscar Wylee's Jas frame is characterised by nose pads.
### What Type of Nose Pads are Included with Oscar Wylee's Jas Glasses?
Oscar Wylee's Jas frame includes standard nose pads. Nose pads are adjustable for a perfect fit.
### What Type of Lenses do Oscar Wylee's Jas Glasses Have?
The type of lenses that typically come with the Oscar Wylee Jas [glasses frame](https://www.oscarwylee.com.au/glasses.html) are optical lenses. Optical lenses are glasses lenses that have a prescription within the lens to help correct vision issues such as myopia, hyperopia and astigmatism. Jas can also come with non-prescription lenses, with add-ons such as a blue light filter. Jas frames are currently unavailable as sunglasses online, however, customers can customise in-store and add on tint or polarisation.
### What Material is Used for the Rim of Oscar Wylee's Jas Glasses?
The material used for the rim of Oscar Wylee's Jas glasses frames is stainless steel. The rim refers to the part of a glasses frame that holds the lenses.
### What Type of Hinges are Included with Oscar Wylee's Jas Glasses?
The type of hinges included with Oscar Wylee's Jas frames are spring hinges. A spring hinge in a glasses frame refers to hinges that are more flexible than normal hinges and can go slightly beyond 90 degrees. Spring hinges can provide a closer fit to the face.
## What Face Types are Most Suitable for Oscar Wylee's Jas Glasses?
The face types that are most suitable for Oscar Wylee's Jas frame are square, oval, and pear face types. The Jas frame is a bold classic shape, meaning that it complements the structure of square, oval, and pear faces particularly well. The classic Jas frames help to balance the features of a [square face shape](https://www.oscarwylee.com.au/glasses/face-shapes/square), an [oval face shape](https://www.oscarwylee.com.au/glasses/face-shapes/oval), or a [pear face shape](https://www.oscarwylee.com.au/glasses/face-shapes/pear), bringing the eyes and brows forward in a flattering way. Although there are many [glasses for face shapes](https://www.oscarwylee.com.au/glasses/face-shapes) that may be considered more aesthetically suitable, it is important that people also choose the frames that make them feel most comfortable and represent their personal style.
## What Size Options are Available for Oscar Wylee's Jas Glasses?
The size options available for Oscar Wylee's Jas frame are a medium-frame fit across all colours.
## What Materials are Used to Create Oscar Wylee's Jas Glasses?
The materials used to create the Oscar Wylee Jas frame are stainless steel, copper, and acetate. Stainless steel is a durable iron based alloy. Acetate, also known as cellulose acetate, is a bioplastic made from cotton fibres or wood pulp. At Oscar Wylee, acetate glasses are made by adding a dye to cellulose acetate, which is rolled into a sheet. The shape of the glasses is then cut from this sheet.
## What’s Included
## OW Case &amp; Cloth
Protective Case and Lens Cloth
Our high-quality glasses case and lens cloth are included with every purchase of an Oscar Wylee frame. The stylish, magnetic case is made from a hard shell. This sturdy and durable material keeps your glasses protected and safe, wherever you go. Ensure your lenses are clean and scratch-free with our OW microfibre cloth, specifically designed to ensure you have comfortable vision through your lenses.
Oscar Wylee offers:
* Free Shipping on all orders
* 1 Year Warranty on frames and lenses
* Scratch resistance lens coating on all prescriptions
* UV-proof coating on all prescriptions
Health fund rebate: Once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. Learn more about [health funds](https://www.oscarwylee.com.au/health-funds.html).
## Make and Materials
As part of our durable frame family, some of our most popular styles, are now in stainless steel. These frames are hypoallergenic, corrosion resistant, light weight, and not sensitive to temperature changes. The frames then go through cleaning and strict quality control, and many pairs of crafting hands to be hand-assembled and polished. After your frames have gone through the production process, they are individually examined and packed before making their way to you!
## Warranty Information
### Warranty Information
### Warranty Information
Oscar Wylee provides a 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects. We will repair or replace faulty or defective frames or lenses free of charge for warranty claims made within 1 year of the delivery. We also offer repairs or replacement for problems experienced with vision during everyday use for claims made within 30 days of delivery. If the same product has been discontinued or is no longer available, then we may offer an exchange for a similar product or a refund.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Find a Store Location](https://www.oscarwylee.com.au/locations/full-store-list.html)