# Source: https://www.oscarwylee.com.au/glasses/materials/lightweight.html

18 Products        
Showing 15 of 18
1. [](https://www.oscarwylee.com.au/leigh-optical.html)
[Leigh](https://www.oscarwylee.com.au/leigh-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/leigh-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/leigh-optical.html)
2. [](https://www.oscarwylee.com.au/miles-optical.html)
[Miles](https://www.oscarwylee.com.au/miles-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/miles-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/miles-optical.html)
3. [](https://www.oscarwylee.com.au/allan-optical.html)
[Allan](https://www.oscarwylee.com.au/allan-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/allan-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/allan-optical.html)
4. [](https://www.oscarwylee.com.au/franklin-optical.html)
[Franklin](https://www.oscarwylee.com.au/franklin-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/franklin-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/franklin-optical.html)
5. [](https://www.oscarwylee.com.au/amanda-optical.html)
[Amanda](https://www.oscarwylee.com.au/amanda-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/amanda-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/amanda-optical.html)
6. [](https://www.oscarwylee.com.au/marvin-optical.html)
[Marvin](https://www.oscarwylee.com.au/marvin-optical.html)
$199    
[2 pairs from $249](https://www.oscarwylee.com.au/marvin-optical.html)
7. [](https://www.oscarwylee.com.au/mackenzie-optical.html)
[Mackenzie](https://www.oscarwylee.com.au/mackenzie-optical.html)
$199    
[2 pairs from $249](https://www.oscarwylee.com.au/mackenzie-optical.html)
8. [](https://www.oscarwylee.com.au/koda-optical.html)
[Koda](https://www.oscarwylee.com.au/koda-optical.html)
$199    
[2 pairs from $249](https://www.oscarwylee.com.au/koda-optical.html)
9. [](https://www.oscarwylee.com.au/miranda-optical.html)
[Miranda](https://www.oscarwylee.com.au/miranda-optical.html)
$199    
[2 pairs from $249](https://www.oscarwylee.com.au/miranda-optical.html)
10. [](https://www.oscarwylee.com.au/sammie-optical.html)
[Sammie](https://www.oscarwylee.com.au/sammie-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/sammie-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/sammie-optical.html)
11. [](https://www.oscarwylee.com.au/bowie-optical.html)
[Bowie](https://www.oscarwylee.com.au/bowie-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/bowie-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/bowie-optical.html)
12. [](https://www.oscarwylee.com.au/ruthie-optical.html)
[Ruthie](https://www.oscarwylee.com.au/ruthie-optical.html)
$169
13. [](https://www.oscarwylee.com.au/keizel-optical.html)
[Keizel](https://www.oscarwylee.com.au/keizel-optical.html)
$199    
[2 pairs from $249](https://www.oscarwylee.com.au/keizel-optical.html)
14. [](https://www.oscarwylee.com.au/siena-optical.html)
[Siena](https://www.oscarwylee.com.au/siena-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/siena-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/siena-optical.html)
15. [](https://www.oscarwylee.com.au/fariza-optical.html)
[Fariza](https://www.oscarwylee.com.au/fariza-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/fariza-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/fariza-optical.html)
18 Products        
Showing 15 of 18
Choosing Lightweight Glasses Best Material &amp; Characteristics Colour Fit &amp; Lenses Price &amp; Shipping
## How to Choose the Best Lightweight Glasses for Women?
To choose the [best lightweight glasses for women](https://www.oscarwylee.com.au/glasses/best-women), you should select a women’s lightweight frame, consider personal style preferences, and try it on for comfort. Read more on how to choose the best lightweight glasses for women below.
* Select a Women’s Lightweight Frame: Select a women’s lightweight frame. Lightweight frames come in women’s, men's and unisex options. Women may prefer the aesthetic, colour and fit of women’s lightweight glasses, however unisex frames may also be viable options for a more gender neutral style.
* Consider Personal Style Preferences: Consider personal style preferences when selecting the best lightweight glasses for women. This can encompass material, colour, frame thickness and even pattern.
* Try the Glasses on for Comfort: Try the glasses on for comfort. Assess if the frame feels light on your face alongside other factors such as temple fit and how it feels across the nose.
## How to Choose the Best Lightweight Glasses for Men?
To choose the [best lightweight glasses for men](https://www.oscarwylee.com.au/glasses/best-men-eyeglasses-for-every-face-shape), you should select a men’s lightweight frame, consider personal style preferences, and try it on for comfort. Read more on how to choose the best lightweight glasses for men below.
* Select a Men’s Lightweight Frame: Select a men’s lightweight frame. Lightweight frames come in men's glasses, [women’s glasses](https://www.oscarwylee.com.au/glasses/collection/womens-glasses.html) and unisex options. Men may prefer the aesthetic, colour varieties and fit of men’s lightweight glasses, however unisex frames may also be viable options for a more gender neutral aesthetic.
* Consider Personal Style Preferences: Consider personal style preferences when selecting the best lightweight glasses for women. This includes material, colour, frame thickness and shape and even pattern.
* Try the Glasses on for Comfort: Try the glasses on for comfort and to see how lightweight it feels on the face. Alongside lightweightedness, check whether the temples are too long or short and how it sits on the nose. Comfort is key, so ensuring a snug fit will allow for seamless vision correction in your everyday life.
## How to Choose the Best Lightweight Glasses According to Face Shape?
To choose the best lightweight glasses according to face shape you should assess your face shape, pick a frame that suits your style, and try the glasses on. Read on for how to choose the best lightweight glasses according to face shape below.
* Assess Your Face Shape: Assess your face shape to see which frame shape will complement you best. For example round faces are well-suited to rectangular or square frames, square faces work well with round or oval glasses, pear faces look good in rectangular or square glasses, oval faces with rectangular frames, and heart faces with aviators or square glasses.
* Pick a Frame That Suits Your Style: Pick a lightweight glasses frame that best suits your style. Material, colour, frame thickness, and pattern are factors to consider when picking out a frame that reflects your identity and aesthetic.
* Try The Glasses On: Try the glasses on as this will allow you to see how the frame shape truly fits your face, as well as the size of the frames. A good rule of thumb is to ensure the lens doesn't come above the eyebrows.
## Which Material is Best for Lightweight Glasses?
The best material for lightweight glasses are ones that are renowned for their lightweightedness, such as memory metal and titanium. The common materials that are best for lightweight glasses include an acetate and metal combination, memory metal, titanium, TR90, and ultem. The materials that are best for lightweight glasses are listed below.
* Acetate and Metal: Acetate and metal provide a strength and a striking aesthetic with the contrasting combination.
* Memory Metal: Memory metal, with its extra flexibility and lightweightedness makes for practical eyewear. For more information on memory metal, read [Memory Metal Glasses: Durable, Flexible, and Lightweight Frames](https://www.oscarwylee.com.au/glasses/memory-metal).
* Titanium: Titanium is a [metal](https://www.oscarwylee.com.au/glasses/materials/metal-frame.html) that provides a sleek profile and lightweightedness for a durable comfortability.
* TR90: TR90 is a thermoplastic material that is flexible and lightweight, perfect for physical activity.
* Ultem: Ultem is a thermoplastic material renowned for its strength and flexibility.
### Acetate and Metal
Acetate and metal lightweight glasses provide a combination of the strength and contrasting aesthetics that both materials provide. The metal, often made from stainless steel, can provide durability alongside the acetate, which provides interesting colourways. For more information on acetate read the article [Acetate Glasses: Material, Benefits and Caring Tips](https://www.oscarwylee.com.au/glasses/acetate-frame).
### Memory Metal
[Memory metal](https://www.oscarwylee.com.au/glasses/memory-metal) is a shape-memory alloy, allowing glasses to be bent or twisted lightly, then return back to their original shape, perfect for those who are accident prone. Memory metal glasses provide this useful characteristic alongside lightweightedness for a seamless fit.
### Titanium
[Titanium lightweight glasses](https://www.oscarwylee.com.au/glasses/titanium) refer to frames made from the metal titanium. They are lightweight, durable and corrosion-resistant. They provide a sleek profile perfect for minimalist eyewear.
### TR90
TR90 glasses refer to eyewear made from thermoplastic material known for its optimal flexibility, lightweightedness and durability. This high-tech material is notable for compatible for wear during physical activity due to its high impact resistance. Read more about TR90 in the article [TR90 Glasses and Sunglasses: Composition and Durability](https://www.oscarwylee.com.au/glasses/tr90).
### Ultem
Ultem is a high performing thermoplastic, perfect for glasses frames as it is tough and flexible. Its lightweightedness and often thin profile makes for an effortlessly modern aesthetic, due to [the growing popularity of thin frame glasses.](https://www.oscarwylee.com.au/glasses/thin-frame)
### What Are Lightweight Glasses?
Lightweight glasses refer to eyewear constructed with materials that allow frames to feel less heavy resting on the face. They allow for seamless wearing for extended periods, minimizing potential discomfort. The weight depends on factors such as frame materials, lens materials, and design. While many lightweight frames are thin, this does not always mean the glasses will be lightweight. Read more about lightweight glasses and their characteristics in [Lightweight Eyeglasses: Materials, Design, and Comfort](https://www.oscarwylee.com.au/glasses/lightweight-frame).
#### Do All Lightweight Glasses Have Thin Frames?
No, not all lightweight glasses have thin frames. Some can have a standard level of thickness. This is because lightweightedness depends on factors beyond thinness such as frame material, lens material, and design.
## Which Colour Pattern is Best for Lightweight Glasses?
There is no best colour pattern for lightweight glasses, it depends on the pattern preferences of the wearer. Some glasses colour patterns include matte, solid, tortoise, transparent and two-toned. Read on for the various colour patterns that could be the best for lightweight glasses.
* Matte: Matte lightweight glasses refer to a low-gloss, flat-looking finish for a chic-looking frame.
* Solid: Solid colour lightweight glasses are classic and versatile, able to provide a subtly stylish accessory to any outfit.
* Tortoise: Tortoiseshell lightweight glasses patterns offer a blend of often warm tones and are an effortlessly stylish accessory, perfect for any occasion.
* Transparent: Transparent lightweight glasses are popular due to their minimalist, modern look, offering subtle style and a weightless feel.
* Two-toned: Two-toned lightweight glasses create a striking, visual aesthetic for a unique accessory.
### Which Frame Colours Work Best for Lightweight Glasses?
There is no particular frame colour that best complements lightweight glasses. It is ultimately up to personal preference as to which colour lightweight glasses is best for you. At Oscar Wylee we have a variety of lightweight frame colours, such as black, blue, brown, gold, clear, green, grey, red, silver, purple, pink, and white. Read on for more on the variety of colours that lightweight glasses come in.
* Black: Black is a classic frame colour for lightweight glasses, perfect for any face and occasion.
* Blue: Blue is a colour rich in beauty, perfect for lightweight glasses, coming in shades such as electric, baby blues, or navy tones.
* Brown: Brown lightweight glasses are great for providing a natural looking warmth to the face, such as through a dark chestnut or two-toned frame.
* Gold: Gold lightweight glasses provide a luxurious edge for a striking look to enhance your outfit.
* Clear: Clear lightweight glasses exude a modern, minimalist look that readily complements any outfit.
* Green: Whether a mint or emerald frame, green lightweight glasses provide a rich intrigue to any face.
* Grey: Grey lightweight glasses are a sophisticated option, perfect for formal, business or workplace-related events, whether a light or dark tone.
* Red: Red lightweight glasses provide a statement accessory for those who seek [bold](https://www.oscarwylee.com.au/glasses/collection/bold.html) eyewear.
* Silver: Silver lightweight glasses provide a sleek, effortlessly modern look perfect for contemporary attire.
* Purple: Purple lightweight glasses provide a fun, feminine flair to diversify your accessory colour palette.
* Pink: Pink lightweight glasses exude a chic charm, with its effortless femininity making for a fashion-forward accessory.
* White: White lightweight glasses are perfect for a clean, stark look, often combined with other colours.
[](https://www.oscarwylee.com.au/allan-optical.html)
[Allan](https://www.oscarwylee.com.au/allan-optical.html)
$169    
Add to Cart
[Shop Allan](https://www.oscarwylee.com.au/allan-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/allan-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/allan-optical.html)
[](https://www.oscarwylee.com.au/amanda-optical.html)
[Amanda](https://www.oscarwylee.com.au/amanda-optical.html)
$169    
Add to Cart
[Shop Amanda](https://www.oscarwylee.com.au/amanda-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/amanda-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/amanda-optical.html)
[](https://www.oscarwylee.com.au/mackenzie-optical.html)
[Mackenzie](https://www.oscarwylee.com.au/mackenzie-optical.html)
$199    
Add to Cart
[Shop Mackenzie](https://www.oscarwylee.com.au/mackenzie-optical.html)
[2 pairs from $249](https://www.oscarwylee.com.au/mackenzie-optical.html)
  
 
## What Types of Nose Shapes Complement Lightweight Glasses Best?
There is no best nose shape that best complements lightweight glasses. Lightweight glasses can accommodate any nose shape seamlessly. To ensure a good fit before purchasing, try them on in store to see how it feels on different parts of the face.
### Are Lightweight Glasses Good for People with Small Noses?
Yes, lightweight glasses can be good for people with small noses. However, they are not just good for people with small noses. All nose types and faces can enjoy the feeling lightweight glasses provide.
### Are Lightweight Glasses Best for All-Day Wear?
Yes, lightweight glasses can be best for all-day wear. This is particularly true if you find glasses to be irritating on parts of your face. A pair of lightweight glasses can alleviate some of the weight and allow for a lighter, more unobtrusive fit. However, it is up to individual preference whether they are the best option for all-day wear.
### Are Lightweight Glasses Suitable for Progressive Lenses?
Yes, lightweight glasses are suitable for progressive lenses. [Progressive lenses](https://www.oscarwylee.com.au/glasses/eye/progressive-lenses) refer to lenses that are designed with magnification for near, middle and far distance vision, all in one lens. Lightweight glasses, like other types of glasses, are able to accommodate progressive lenses well.
#### Are Lightweight Glasses Suitable for Sports and Active Use?
Yes, lightweight glasses can be suitable for sports and active use. This is particularly true for TR90 glasses. Sports and active glasses are often made from this, however you should also look for other features that make them wearable for sport. Silicone nose grips, larger frames, and even little air vents in the temples are classic features of sports glasses. Oscar Wylee offers an [Active Collection](https://www.oscarwylee.com.au/sunglasses/collection/active-collection.html) for eyewear specifically designed for physical activity.
## What are the Price Factors for Lightweight Glasses?
The price factors for lightweight glasses at Oscar Wylee will vary depending on elements such as the range of glasses, add-ons and lens types. One pair of lightweight glasses starts from $169, 2 pairs from $199 and 3 pairs from $249. It should be noted that lens thickness and other add-ons will affect overall pricing. See our full [price guide](https://www.oscarwylee.com.au/price-guide/).
### What is the Duration of Shipment for Lightweight Glasses?
The average shipping duration for lightweight glasses at [Oscar Wylee](https://www.oscarwylee.com.au/) is typically within 7-10 business days. If you are having them delivered to your home, this can take up to 2 weeks. An email will be sent to you confirming the order alongside an order tracking link.
[Prescription Glasses](https://www.oscarwylee.com.au/glasses.html)
[Women’s Glasses](https://www.oscarwylee.com.au/glasses/collection/womens-glasses.html)
[Men’s Glasses](https://www.oscarwylee.com.au/glasses/collection/mens-glasses.html)
[Senior Glasses](https://www.oscarwylee.com.au/glasses/collection/seniors.html)
[Glasses for Kids](https://www.oscarwylee.com.au/glasses/collection/kids-collection.html)