# Source: https://www.oscarwylee.com.au/glasses/eye/types-of-eye-drops

# 7 Different Types of Eye Drops You Should Know
Published May 12th, 2023
Updated on February 13th, 2025
Australia
[Australia](https://www.oscarwylee.com.au/glasses/eye/types-of-eye-drops)
[Canada](https://oscarwylee.ca/glasses/eye/types-of-eye-drops)
[Canadian French](https://oscarwylee.ca/fr/glasses/eye/types-of-eye-drops)
Eye drops are a type of liquid solution, often medicated, that is applied to
the eye via an eye dropper. There are various different eye drops that can
be used to help treat eye conditions, eye injuries and allergies that affect
the eyes. This article will explore the different types of eye drops and
their uses. Among the different types of eye drops you should know are
artificial tears, antihistamine eye drops, antibiotic eye drops, glaucoma
eye drops, steroid eye drops, antiviral eye drops and anti-redness eye
drops.
Some of the different types of eye drops are listed below.
* Artificial tears: Artificial tears, also
known as lubricating eye drops, are types of eye drops that help bring
moisture to the eyes and reduce dryness.
* Antihistamine eye drops: Antihistamine eye
drops are a type of medicated eye drops that help to reduce the symptoms
of eye allergies.
* Antibiotic eye drops: Antibiotic eye drops
are a type of medicated eye drops that generally treat bacterial
infections in the eye.
* Glaucoma eye drops: Glaucoma eye drops can
be used to help treat the eye condition glaucoma by helping to reduce the
pressure in the eye.
* Steroid eye drops: Steroid eye drops are a
type of medicated eye drops that help to reduce inflammation in the eye.
* Antiviral eye drops: Antiviral eye drops
are a type of medicated eye drops that assist in treating infections
caused by viruses.
* Anti-redness eye drops: Anti-redness eye
drops are a type of eye drops that help to reduce the appearance of
redness in the eyes.
Are you due for an eye test?
Our experienced and dedicated Oscar Wylee optometrists provide bulk billed
eye tests for eligible Medicare card holders.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[How to Use](#use)
[Eye Drops for Irritated Eyes](#eye-drops)
[Moisturising Eye Drops](#moisturising)
[Glaucoma Eye Drops](#glaucoma)
Eye drops are a type of medication and should not be used without first
consulting a healthcare professional.
What are the Best Eye Drops for Dry Eyes?
The best eye drops for dry eyes are lubricating eye drops or artificial
tears, as they help to bring moisture back into the eye.
## 1. Artificial Tears
Artificial tears, also known as lubricating eye drops, are a type of eye
drop that aim to bring moisture to the eyes. Artificial tears are
commonly used when the eyes are dry, and not producing enough tears to
lubricate the surface of the eye. The surface of the eye is covered with
a tear film, which produces tears and keeps the eyes lubricated. The
tear film is made up of an oily outer layer, a watery middle layer and a
mucous-like inner layer, according to the American Academy of
Ophthalmology. If there is a problem with one or all of the layers in
the tear film, the lack of lubrication as a result can lead to dry eyes.
According to the Victorian Government’s Better Health Channel, dry eyes
can be caused by a variety of issues including health conditions such as
rheumatoid arthritis, as well as menopause, general ageing and climate
conditions such as wind. Artificial tears, or lubricating eye drops,
help to alleviate the symptoms of dry eyes by bringing moisture to the
surface of the eye.
Artificial tears are available over-the-counter. Artificial tears do not
usually need a prescription, however, it is
important to consult with a healthcare professional before using any
type of medication.
The pro of artificial tears is that they help bring lubrication
to the eye and can be generally purchased at your local pharmacy. The
con of artificial tears is that they are generally only a
temporary solution to alleviate symptoms of conditions such as dry eyes,
they are not a longtime solution or cure.
## 2. Antihistamine Eye Drops
Antihistamine eye drops are a type of medicated eye drops that
help to alleviate symptoms of allergies. Allergies generally
refer to the body’s immunological reaction to allergens or irritants
such as pollen, grass and animal dander. Eye allergies, or allergic
conjunctivitis, refer to a type of allergy that specifically affects the
eyes. When the eyes, specifically the conjunctiva, the membrane that
covers the whites of the eyes and inner eyelids, are exposed to an
allergen such as pollen, the body will release a chemical called
histamine, which works to get rid of the allergen from the system. As
histamine expels an allergen from the body, it can cause sneezing,
itching and eye irritation such as red eyes, watery eyes and swollen
eyes. Antihistamine medication helps to relieve and treat some of the
symptoms caused by histamine. Antihistamine eye drops can be applied to
the eyes via an eye dropper to try and prevent some of the symptoms of
eye allergies.
Antihistamine eye drops are generally available over-the-counter and do
not usually require a prescription. However, it is always
advisable to consult with a healthcare professional before using any
type of medication. The pro of antihistamine eye drops is that they can help to
relieve symptoms of eye allergies such as red eyes, watery eyes, itchy
eyes and swollen eyes. The con of antihistamine eye drops is that
they will not cure eye allergies.
## 3. Antibiotic Eye Drops
Antibiotic eye drops are a type of medicated eye drops that are used to
treat bacterial infections in the eye. Antibiotics are a
medication that treats infections or illnesses that have been caused by
bacteria. Bacteria are single-celled microbes that can reproduce quickly
in the human body, release toxins that can damage tissues and cause
illness, according to the American Agency for Healthcare Research and
Quality. Antibiotics work by weakening the bacteria that is causing the
infection so your body can better fight it, according to Health Direct,
Australia’s virtual public health information service. If bacteria comes
into contact with the eye, it can cause bacterial infections such as
bacterial conjunctivitis or pink eye. Antibiotic eye drops are applied
to the eye to help fight the bacteria that are causing infection.
Antibiotic eye drops are not available over-the-counter. Antibiotics are
prescribed medication, meaning a person will need a doctor or healthcare
professional to provide a prescription to receive this medication. The
pros of antibiotic eye drops are that they can help to kill the
bacteria causing the infection and promote healing. The
con of antibiotic eye drops is that antibiotics are a medication
that may not work for everyone, some people can be allergic to
antibiotics and some bacteria can be resistant to antibiotics, meaning
they will not help.
It is important to consult with a healthcare professional before
using any antibiotics.
## 4. Glaucoma Eye Drops
Glaucoma eye drops are a type of medicated eye drops
that help to treat the eye condition glaucoma by helping to reduce
intraocular eye pressure, according to Glaucoma Australia.
Glaucoma refers to a group of eye conditions in which the optic nerve is
damaged, leading to vision loss, according to the National Eye
Institute. The optic nerve eye is a nerve that transmits images that the
eye sees, to the brain. The exact cause of glaucoma is unknown, however,
it is theorised to be related to issues with fluid in the eye and eye
pressure. Glaucoma eye drops are a type of non-surgical treatment that
can help to treat glaucoma by reducing pressure in the eye, which is a
risk factor for contracting the condition. According to Glaucoma
Australia, glaucoma eye drops help to treat glaucoma by either helping
fluid drain from the eye or reducing the amount of fluid released into
the eye, in turn, attempting to reduce eye pressure.
Glaucoma eye drops are not available over-the-counter, they will need to
be prescribed by a healthcare professional. The
pro of glaucoma eye drops is that they can help reduce pressure
in the eye which may help to manage glaucoma progression. A
con of glaucoma eye drops is that they do not improve a person’s
vision, they instead work to prevent vision from getting worse,
according to the National Eye Institute. This means that some people
often stop taking their eye drops as they believe they are not working,
which can hinder the effectiveness of the eye drops.
## 5. Steroid Eye Drops
Steroid eye drops or corticosteroid eye drops, are a type of eye drops
that help to treat inflammation in the eye. According to the NHS,
steroids are a replica of a hormone that is usually produced by the
adrenal glands and can help to reduce inflammation in the body. Steroid
eye drops are a type of steroid that is applied to the surface of the
eye via an eye dropper. Steroid eye drops are used to treat eye
conditions that cause inflammation, such as conjunctivitis or pink eye,
and eye herpes or HSV keratitis. Inflammation in the eye may present as
symptoms such as red eyes, swollen eyes, or itchy eyes.
HSV Keratitis is a serious condition. You should seek medical
attention immediately if you believe you have this condition.
Steroid eye drops are not available over-the-counter. Steroid eye drops
will require a prescription to purchase. The
pros of steroid eye drops are that they can help to reduce
inflammation in the eye and promote healing. The
cons of steroid eye drops are that they may cause some mild
discomfort or blurry vision when first put in the eye.
It is important to consult with a healthcare professional if these
symptoms persist.
## 6. Antiviral Eye Drops
Antiviral eye drops are a type of medicated eye drops that
help treat eye infections caused by viruses, such as viral
conjunctivitis.
A virus refers to a type of infectious agent or microbe that multiplies
or replicates inside living organisms and can cause illness. The common
cold, COVID-19 and the flu are types of illnesses that are caused by a
virus. Viral conjunctivitis is an eye condition that is caused by a
virus. Antiviral medication aims to help combat virus-driven illnesses
by stopping the virus from multiplying in the body. Antiviral eye drops
are a type of antiviral medication applied to the surface of the eye via
an eye dropper, to try and stop the virus in the eye multiplying and
causing infection.
Antiviral eye drops are not generally available over-the-counter. A
healthcare professional will decide if you need antiviral eye drops and
prescribe them accordingly. The pro of antiviral eye drops is
that they may help to fight the virus causing a viral eye infection. The
cons of antiviral eye drops can include antiviral resistance, in
which the virus develops a resistance to the medication if it is not
taken as prescribed, hindering its effectiveness in stopping the virus,
according to the Cleveland Clinic.
## 7. Anti-Redness Eye Drops
Anti-redness eye drops or redness relieving eye drops, are a type of eye
drops that are
used to help reduce the appearance of red eyes, usually a red
conjunctiva, the membrane that covers the surface of the eye and the
inner eyelids.
Red eyes may be caused by a range of things including conjunctivitis,
allergies and fatigue. Anti-redness eye drops aim to reduce the redness
in the eye. Anti-redness eye drops are made with a type of decongestant
medication called tetrahydrozoline according to the American Academy of
Ophthalmology. Tetrahydrozoline aims to reduce the swelling of the blood
vessels in the eye which is what causes the eye to become red in
appearance.
Anti-redness eye drops will not be suitable for all people to use. Those
with glaucoma for example, could worsen their condition if they use
anti-redness eye drops, according to the American Academy of
Ophthalmology. Anti-redness eye drops may be available over-the-
counter, non-prescription, but it is important to
consult with your healthcare professional before using any
medication.
The pros of anti-redness eye drops are that they may help to
reduce a red appearance in the eyes. The
cons of anti-redness eye drops are that by attempting to get rid
of the redness and whiten the eye, a person could mask the symptoms of a
serious eye condition, according to the American Academy of
Ophthalmology.
Find your nearest Oscar Wylee
Come and see your local Oscar Wylee for your optometry needs including
eye tests and stylish new frames.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
## How to Use Eye Drops?
The way to use eye drops involves
getting prepared for the eye drops by washing your hands, tilting
your head back, applying the drops to the eye and closing the eye.
It is important that before using eye drops that you read any
instructions and consult with a healthcare professional so you are aware
of how many drops need to be applied and how often. It is also important
that you do not touch the eye when applying eye drops as this may cause
bacteria or dirt to enter the eye. The general steps to use eye drops
are listed below.
1. Firstly, get prepared for the drops by washing your hands so you do
not get any dirt or bacteria in the eye, and take out any contact
lenses.
2. Secondly, get your eye drops out and nearby for easy access.
3. Thirdly, tilt your head back and look upwards, so the eye drops stay
in the eye.
4. Fourth, squeeze the eyedropper tool or bottle of eye drops slowly, and
apply as many drops as the instructions or your healthcare
professional has advised. Make sure the bottle does not touch the eye.
5. Fifth, close your eyes and press gently on the tear ducts, or the
inner corner of the eye, for a minute or two, so the medication stays
in place.
### How Often Should You Use Eye Drops?
How often you should use eye drops is
dependent upon the eye drops you are using, for what reason and
what an optometrist or healthcare professional has advised.
For example, someone using artificial tears is generally advised to
not use these eye drops more than four times a day, according to the
Cleveland Clinic.
## How to Choose the Best Eye Drops for Dry Eyes?
The way to choose the best eye drops for dry eyes is to
first consult with your doctor, optometrist, or other healthcare
professional,
as these people will be able to diagnose your condition and prescribe
the right eye drops.
### What Type of Eye Drop is for Irritated Eyes?
The type of eye drop that is used for irritated eyes will
depend on what is causing the eye irritation and what a healthcare
professional has recommended.
If irritated eyes are a result of dry eyes, then artificial tears may
help to bring moisture back into the eyes and reduce irritation. If a
person has conjunctivitis or HSV keratitis, then steroid eye drops may
be used to help reduce inflammation and resulting irritation that
these conditions can cause. The eye drops for irritation will be
prescribed by a healthcare professional after a diagnosis.
### What Type of Eye Drop is for Dry Eyes?
The type of eye drops for dry eyes treatment is generally artificial tears or lubricating eye drops. Artificial tears help to bring moisture to the surface of the
eye, which can help to reduce [dry eyes](https://www.oscarwylee.com.au/glasses/eye/dry-eyes).
### What Type of Eye Drop is for Severe Dry Eyes?
The type of eye drop for severe dry eyes
will be determined by an optometrist or healthcare professional.
If artificial tears are not doing enough to provide relief from dry
eye symptoms, it is important to consult your healthcare professional
for the next best treatment option.
### What Type of Eye Drop is for Moisturising?
The type of eye drop that can be used to moisturise or bring more
hydration to the eye,
are artificial tears or lubricating eye drops. Artificial tears
are made of some of the same elements natural tears are, according to
the American Academy of Ophthalmology, and help to bring extra
moisture to the eyes. If you think you require eye drops for eye
moisture, consult with a healthcare professional.
### What Type of Eye Drop is for Glaucoma?
The type of eye drops used for the treatment of glaucoma
are made specifically for the condition and are prescription
only.
According to Glaucoma Australia, glaucoma eye drops help to treat
[glaucoma](https://www.oscarwylee.com.au/glasses/eye/glaucoma)
by reducing the pressure in the eye, either by helping to reduce the
amount of fluid in the eye or helping fluid to drain from the eye.
### What Type of Eye Drop is for Allergies?
The type of eye drop used to help treat eye allergies and relieve
allergy symptoms such as itchy, swollen or red eyes
are antihistamine eye drops. Histamine is released from the
body as an immunological response to the presence of allergens. When
allergens come into contact with the eye, the histamine response can
cause symptoms such as itchy, red or swollen eyes.
Antihistamine eye drops can help to relieve the symptoms of[eye allergies](https://www.oscarwylee.com.au/glasses/eye/allergies).
### What is the Most Expensive Type of Eye Drop?
The most expensive type of eye drop is
dependent upon what eye drop you need and the retailer you are
buying them from.
Oscar Wylee does not sell eye drops.
#### Are There Eye Drops that Don't Burn?
Eye drops should not burn the eyes. If you are using eye
drops and are having a burning sensation or any other reaction, it
is important to seek medical attention.
#### Are Over-The-Counter Eye Drops Safe?
The safety of over-the-counter eye drops from chemists or
pharmacies is dependent upon the person and what eye conditions they may
have. It is important to seek advice from your optometrist or
healthcare professional before using any eye drops.
#### Can You Use Eye Drops for Hydrating Your Eyes Only?
Yes,
artificial tears or lubricating eye drops, are a type of eye drop
that aims to bring hydration to the surface of the eyes
and help prevent dry eyes. Artificial tears can come as unmedicated,
over-the-counter eye drops or OTC eye drops, with the sole purpose
of hydrating the eyes.
#### Is There an Eye Drop for Pink Eye?
The eye drop that may be used during the treatment of
[pink eye, or conjunctivitis](https://www.oscarwylee.com.au/glasses/eye/conjunctivitis)
is steroid eye drops. Steroid eye drops help to reduce
inflammation in the eye, which can cause symptoms such as red,
swollen or itchy eyes.
#### Is There an Eye Drop for Lazy Eye?
Yes, there is a type of eye drop that is used to treat
[amblyopia or lazy eye](https://www.oscarwylee.com.au/glasses/eye/lazy-definition), called atropine eye drops. According to the Government of
South Australia’s Women’s and Children’s Hospital, atropine eye
drops are put into the stronger eye, that is less or not affected by
amblyopia, which lessens its ability to function. Weakening the
stronger eye means that the brain starts using the eye affected by
amblyopia more, which may help the eye become stronger over time.
Atropine eye drops are a treatment mainly used for children.
#### Does the Pupil React When Using an Eye Drop?
Whether the pupil reacts or not when using an eye drop is
dependent upon what type of eye drops are being used.
Generally, over-the-counter eye drops, antibiotic eye drops or
steroid eye drops should not make the
[pupil](https://www.oscarwylee.com.au/glasses/eye/anatomy/pupil)
react in a major way. Dilating eye drops are intended to make the
pupil react, widening it so an optometrist can look at the deeper
structures of the eye. According to the American Association for
Pediatric Opthalmology and Strabismus, there is also an eye drop
that relaxes the pupil’s ability to focus. Any pupil reaction when
using dilating eye drops should be temporary. If symptoms last for
longer than a few hours, it is important to seek medical help.
Read 7 Different Types of Eye Drops You Should Know in other Oscar
Wylee regions and their languages.
Australia
[Australia](https://www.oscarwylee.com.au/glasses/eye/types-of-eye-drops)
[Canada](https://oscarwylee.ca/glasses/eye/types-of-eye-drops)
[Canadian French](https://oscarwylee.ca/fr/glasses/eye/types-of-eye-drops)
Leading health funds accepted in-store
Visit us in-store for an eye test or a new pair of frames, and your
health fund may help cover some of the cost.
[Health Funds](https://www.oscarwylee.com.au/health-funds.html)
Prioritise your eye health at Oscar Wylee
Our Oscar Wylee optometrists provide bulk billed eye tests for
eligible medicare card holders, so you can look after your eyes.
[Book an eye exam](https://www.oscarwylee.com.au/booking)