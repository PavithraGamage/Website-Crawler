# Source: https://www.oscarwylee.com.au/glasses/senior-eye-health

# Eye Problems with Age: How to Improve Eye Health
Published on June 30th, 2025
Updated on August 23rd, 2024  
Australia
Australia
New Zealand
Canada
Canadian French

As people age, they may experience weakened vision and even encounter more vision related problems. Eye conditions such as Age-Related Macular Degeneration (AMD) and presbyopia are examples of vision-related conditions that are more apparent in older people. For seniors, it is important to regularly monitor and take care of eye health to maintain healthy vision in later years. Read on for more common age-related vision conditions, warning signs, and advice on how to take care of senior’s eye health.
Experience High-Quality Eye Care Services at Oscar Wylee
We have dedicated teams and optometrists at all our stores.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Common Eye Problems](#EyeProblems) [Improve Eye Sight for Seniors](#Seniors) [Preventing Ageing Eyes](#Preventing) [Resources for Senior Vision Loss](#Resources)
## What are the Most Common Eye Problems with Age?
The most common eye problems with age include presbyopia, cataracts, age-related macular degeneration (AMD), Glaucoma, Diabetic Retinopathy, Dry Eye Syndrome, Floaters and Flashes and Reduced Contrast Sensitivity. Common eye problems that may develop with age are listed below.
* Presbyopia: Presbyopia is an age-related condition wherein the eyes become less able to focus over time.
* Cataracts: Cataracts occur mainly as you age, when the eye’s lens becomes cloudy.
* Age-Related Macular Degeneration: Age-Related Macular Degeneration is an eye condition that affects the macula, distorting vision.
* Glaucoma: Glaucoma is usually caused by an increase in Intraocular Pressure (IOP) which causes damage to the optic nerve, leading to gradual blindness.
* Diabetic Retinopathy: Diabetic Retinopathy is a diabetic complication that damages blood vessels in the retina.
* Dry Eye Syndrome: Dry Eye Syndrome occurs when the eyes do not produce good-quality tears, a common occurrence in elderly people.
* Floaters and Flashes: Floaters and flashes are small shapes and brief streaks that flash in the vision, particularly in older people.
* Reduced Contrast Sensitivity: Reduced contrast sensitivity is the reduced ability to distinguish between subtle shades of light and dark, worsening with age.
### 1. Presbyopia
Presbyopia is a condition in which the eyes lose the ability to focus. It can start early, at around 40 years old and is caused by the lens in the eye becoming harder and less flexible with time. [Presbyopia](https://www.oscarwylee.com.au/glasses/eye/presbyopia) will be diagnosed by an optometrist or ophthalmologist during an eye exam. It will be treated with an updated prescription for your glasses or even contact lenses.
### 2. Cataracts
Cataracts are a condition when the lens of the eye becomes cloudy, affecting vision. It is a condition that can be treated with surgery. [Cataracts](https://www.oscarwylee.com.au/glasses/eye/cataracts)&nbsp;can be prevented by wearing sunglasses regularly in bright conditions, quitting smoking, and eating a diet rich in fish and vegetables, according to Health Direct.
### 3. Age-Related Macular Degeneration
Age-related Macular Degeneration (AMD) is a chronic disease of the macula, which is part of the retina. Age-related macular degeneration causes progressive loss of central vision but leaves the peripheral vision intact. [Age-related Macular Degeneration](https://www.oscarwylee.com.au/glasses/eye/age-related-macular-degeneration) is responsible for half of all blindness and severe vision loss in Australia, according to the Macular Disease Foundation Australia. It is diagnosed after an eye exam conducted by an eye health professional.
### 4. Glaucoma
Glaucoma is when vision is lost due to damage to the optic nerve. It is caused by an increase in intraocular pressure (IOP), which is fluid pressure inside the eye. [Glaucoma](https://www.oscarwylee.com.au/glasses/eye/glaucoma) risk factors include being over the age of 50 and having diabetes. Treatment options include eye drops, laser surgery, or traditional surgery.
### 5. Diabetic Retinopathy
Diabetic retinopathy is a complication of diabetes, caused by damage to the small blood vessels in the retina. Up to a third of Australians over the age of 50 living with diabetes have some evidence of suffering from [Diabetic Retinopathy](https://www.oscarwylee.com.au/glasses/eye/diabetic-retinopathy). Treatments include taking Fenofibrate to lower the risk of progression, undergoing laser treatment, or doing intravitreal injections.
### 6. Dry Eye Syndrome
Dry eye disease occurs when your tears aren't able to provide sufficient lubrication for your eyes, often due to a lack of tear production. Causes of insufficient tears can include hormone changes, autoimmune diseases, ageing inflamed eyelid glands or allergic eye disease, according to the Mayo Clinic. Treatment measures for [dry eyes](https://www.oscarwylee.com.au/glasses/eye/dry-eyes) can include eye drops and tear-stimulating medicines prescribed by an eye specialist.
### 7. Floaters And Flashes
Floaters, or [eye floaters](https://www.oscarwylee.com.au/glasses/eye/floaters-definition), refer to small specks, strands or cloud-like visuals that move across your eyesight. It can be caused by eye trauma, shortsightedness or have had cataract surgery. Floaters can be diagnosed by your doctor. Eye floaters are common as you age, and it isn’t common to have treatment when they occur. However if they start to really impede your vision, you can get surgery to remove the floater, or get laser treatment. Flashes look like flashing lights or lightning streaks in your field of vision. Some people compare them to seeing “stars” after being hit on the head. You might see flashes on and off for weeks, or even months. Flashes happen when the vitreous rubs or pulls on your retina. As people age, it is common to see flashes occasionally. Any new floaters or flashes should be examined by your ophthalmologist.
### 8. Reduced Contrast Sensitivity
Reduced contrast sensitivity refers to a lessened ability to perceive shape and clear outlines of small objects and an inability to identify differences in shades and patterns. People with reduced contrast sensitivity may see glare and halos during the night and may need extra lighting to read. The use of yellow-tinted glasses helps in improving contrast sensitivity as they increase the sharpness perception during the daytime, according to the Contrast Sensitivity article published in the National Library of Medicine.
Update Your Prescription Today.
See our team in-store to update your prescription. We offer bulk billed eye tests and quality eye care assistance.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
## How Does Ageing Affect Vision Changes?
Ageing affects vision changes as there may be an increased risk of certain eye conditions that can potentially lead to vision loss such as glaucoma and Age-Related Macular Degeneration.
### When Does Eyesight Typically Start To Deteriorate?
Eyesight can typically start to deteriorate earlier, at around 40 years old. This is when presbyopia will often start to occur, a condition in which the eyes start to lose the ability to focus at objects up close.
### What are the Early Signs of Ageing Eyes?
The early signs of ageing eyes include difficulty seeing things up close, trouble adjusting to changing light levels and having trouble distinguishing colours, according to the National Institute of Ageing. Read more about these early signs of ageing eyes below.
* Difficulty seeing things up close: Difficulty seeing things up close is a sign of ageing eyes, and prescription glasses to accommodate this change might be needed.
* Trouble adjusting to changing light levels: You might have trouble adjusting to changing light levels as your eyes start to age. In home settings, having warm lighting is a good lifestyle change to make your environment more comfortable.
* Trouble distinguishing colours: You may have trouble distinguishing certain colours, such as blue and black, or other closely linked colours to each other.
## How to Improve Eye Health for Seniors?
To improve eye health for seniors, you should eat a balanced diet, get regular eye checks, manage dry eyes and use proper lighting. Read on for these tips on how to improve eye health for seniors with changing vision circumstances.
* Eat a Balanced Diet: Eating a balanced diet rich in omega-3 fatty acids, lutein, zinc, and vitamins C is important. These include fish, nuts, seeds, leafy greens, yellow and orange fruits.
* Quit Smoking: Quitting smoking is important for improving eye health. Smoking is proven to lead to an increased risk of diseases such as cataracts and age-related macular degeneration. It is important that measures are taken in order to ease, or stop regular smoking, if an elderly person still does so.
* Manage Dry Eyes: Managing dry eyes is important as ageing can lead to slower tear production, which can lead to eye inflammation, abrasion of the corneal surface or corneal ulcers. Seniors should manage dry eyes by regularly taking eye drops. A medical professional or pharmacist should prescribe the most suitable eye drops for seniors to use.
* Use Proper Lighting: Using proper lighting whenever possible is important for seniors. Whether they are reading or using digital devices, it is important that lighting provides a warm glow to mitigate glare and strain.
### What Vitamins and Nutrients Support Good Eyesight?
Vitamins and nutrients that support good eyesight include Vitamin A, E and Lutein. Read on to see how these vitamins and nutrients support good eyesight.
* Vitamin A: Vitamin A is crucial for good vision as it helps protect the cornea and is essential for maintaining low-light vision.
* Vitamin E: Vitamin E has been shown through research to potentially be the most beneficial vitamin for the prevention of age-related macular degeneration (AMD).
* Lutein: Lutein is an antioxidant that protects and improves eye function. It is also said to prevent or slow macular degeneration and cataracts.
#### Can Diet Help Reverse Ageing Eyesight Changes?
Diet cannot reverse ageing eyesight changes entirely. However, a diet rich in nutrients that are proven to strengthen eyesight can slow down the progression of eye conditions that emerge as a result of ageing.
### Which Eye Exercises are Beneficial For Seniors to Maintain Eye Health?
There are many [eye exercises](https://www.oscarwylee.com.au/glasses/eye/exercises-techniques-and-tips) that are easy and beneficial for seniors to maintain eye health, such as tracing, the 20-20-20 exercise, and the near and far exercise. Read on for more details on how to do these eye exercises below.
* Tracing: Tracing is when you choose an item in your direct field of vision, such as a piece of artwork, and slowly trace the outline of that object with your eyes. Once done, trace the object in the opposite direction to strengthen your eyes’ focus and muscles.
* Pencil Push-Ups: Pencil push-ups are a simple exercise where you take a pencil and hold it out in front of the face. Slowly bring the pencil toward the nose while focusing on the eraser. Once the pencil reaches your nose, slowly pull it away, maintaining your focus on the eraser. The goal of this exercise is to maintain a single and clear vision throughout. Pencil push-ups can improve the way your eyes work together to focus clearly on near objects.
* Near and Far Exercise: The near and far exercise involves shifting your focus between things both near and far away. Hold a finger about 25 cm from your face. Focus on it for 15 seconds. Then, shift your focus to an item about five metres away and focus on that for 15 seconds. This helps train your eyes to maintain vision clarity.
## What are The Best Practices for Daily Eye Care for Seniors?
The best practices for daily eye care for seniors include eating a balanced diet, having proper lighting, and wearing sunglasses outside. Read on for more details on the best practices for daily eye care for seniors.
* Eat a Balanced Diet: Eating a balanced diet including fish, nuts, seeds, leafy greens, and orange fruits.
* Having proper lighting: Having proper lighting is important for activities such as reading and cooking so seniors don’t have to strain their eyes.
* Wearing sunglasses outside: Wearing sunglasses outside is important for seniors to protect their eyes against harsh UV rays. Wearing sunglasses or even wraparound sunglasses will provide great eye protection and coverage.
[](https://www.oscarwylee.com.au/evie-optical.html)
[Evie](https://www.oscarwylee.com.au/evie-optical.html)
$169    
Add to Cart
[Shop Evie](https://www.oscarwylee.com.au/evie-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/evie-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/evie-optical.html)
[](https://www.oscarwylee.com.au/crane-optical.html)
[Crane](https://www.oscarwylee.com.au/crane-optical.html)
$169    
Add to Cart
[Shop Crane](https://www.oscarwylee.com.au/crane-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/crane-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/crane-optical.html)
[](https://www.oscarwylee.com.au/serge-sunglasses.html)
[Serge](https://www.oscarwylee.com.au/serge-sunglasses.html)
$169    
Add to Cart
[Shop Serge](https://www.oscarwylee.com.au/serge-sunglasses.html)
[2 pairs from $199](https://www.oscarwylee.com.au/serge-sunglasses.html)
[3 pairs from $249](https://www.oscarwylee.com.au/serge-sunglasses.html)
[](https://www.oscarwylee.com.au/arnaud-optical.html)
[Arnaud](https://www.oscarwylee.com.au/arnaud-optical.html)
$169    
Add to Cart
[Shop Arnaud](https://www.oscarwylee.com.au/arnaud-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/arnaud-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/arnaud-optical.html)
## How Important are Regular Eye Tests for the Elderly?
Regular eye exams for the elderly are very important to ensure that there can be early detection of potential eye issues. It is recommended that the elderly have an eye test either once or twice a year, according to Health Direct.
### How Can Seniors Protect Their Eyes from UV Damage?
Seniors can protect their eyes from UV damage by frequently wearing sunglasses and hats outdoors on sunny days. The Cancer Council Australia recommends protecting the eyes by wearing close-fitting, wraparound style sunglasses in categories 2, 3 or 4 and wearing a broad-brimmed, bucket or legionnaire hat, which also covers the neck for optimal [UV protection](https://www.oscarwylee.com.au/glasses/eye/uv-blocking).
## Are There Technologies that Help with Changing Senior Vision?
Yes, there are many technologies that help with senior vision. Talking aids are good to have to undergo everyday tasks with greater ease. There are talking scales, microwaves, clocks, and watches for example.
### What Role do Glasses and Contacts Play in Senior Vision?
Glasses and contacts will play an important role in maintaining senior vision. Prescription lenses will be important for seniors with unclear vision. This is why it is important to undergo an eye test at least once a year, particularly when there are changes to your vision to ensure you have an accurate prescription.
## Is Surgery an Option for Age-Related Eye Conditions?
Yes, surgery can be an option for age-related eye conditions. For example, Cataract Surgery is commonly undertaken to remove cataracts, and those with Glaucoma can undergo laser surgery which will aim to lower eye pressure. Whether surgery is an option will depend on the eye condition.
### What are the Risks of Cataract Surgery?
The risks of [cataract surgery](https://www.oscarwylee.com.au/glasses/eye/surgery/cataract) include infection, increased eye pressure and a detached retina. &nbsp;During cataract surgery, your cataract will be removed, which refers to the crystalline lens, which should usually be clear. A cloudy crystalline lens can make your vision blurry or hazy, so during surgery your cloudy natural lens is removed and replaced with a clear artificial lens. Read more about the risks of cataract surgery below.
* Infection: An infection can occur if bacteria enter your eye during surgery. Symptoms of this include eye pain, light sensitivity and blurry vision. An antibiotic medication will usually be prescribed to prevent this risk.
* Increased Eye Pressure: Increased eye pressure can occur, which is where intraocular pressure, which is the fluid inside the eye, rises to the point of affecting vision. If this occurs, your eye doctor may prescribe eye drops, injections, or oral medication.
* Detached Retina: A detached retina can occur as a risk of cataract surgery, which is when the retina pulls away from its normal position. Symptoms of this can include vision loss, visual floaters, and flashes of light.
## Can Ageing Eye Problems be Prevented?
Ageing eye problems can be mitigated, however there is no conclusive evidence to suggest that they can be completely prevented. Early detection can allow for a quickened treatment of any age-related eye problems that may emerge. That is why it is important for seniors to have eye tests once a year so early detection of eye issues can be made by a professional.
### What Lifestyle Habits Harm Senior Eye Health?
Lifestyle habits such as a poor diet and excessive smoking can harm senior eye health. A diet high in sugar and fats can lead to worsened eye health. A senior’s diet should be rich in antioxidants, Omega 3 fatty acids and vitamins C and E to maintain healthy eyesight. Consuming food such as leafy green vegetables, fish, nuts and citrus fruits are considered good for eye health.
## How Can Caregivers Support Seniors with Changing Vision?
Caregivers can support seniors with changing vision through making their home living situation more accessible. Consider installing stronger lighting fixtures around the house, especially in areas that require sharp vision, such as their reading chair and the kitchen. Make their hobbies more accessible. Get large-print books or they can even try audiobooks where there is a range of titles available. A screen-reading software can be invaluable when installed onto their computers or tablets&nbsp; which allows digital text to be spoken.
## What Resources Are Available for Seniors with Changing Vision?
There are Australian resources and organisations available for seniors dealing with changing vision. Vision Australia is the leading Australian not-for-profit organisation providing blindness and [low vision](https://www.oscarwylee.com.au/glasses/eye/low-vision) services through online and physical service centres. They have many healthcare professionals available for the visually impaired, support groups, and are the sole national supplier of guide dogs in Australia.
### Should Seniors Use Supplements for Eye Health?
Seniors may want to use supplements for eye health to maintain healthy vision. There is evidence that dietary antioxidants and anti-inflammatories may decrease the risk of age-related eye disease. The Age-Related Eye Disease Study (AREDS), sponsored by The National Eye Institute, found that supplements with vitamins C and E, zinc and copper taken at levels well above the recommended daily allowances reduced the risk of developing advanced Age-related Macular Degeneration by about 25%. It would be beneficial for seniors to take these vitamins to allow for better eye health in old age.
Read Eye Problems with Age: How to Improve Eye Health in other Oscar Wylee regions and their languages.
Australia
Australia
New Zealand
Canada
Canadian French
 
Book an Eye Test Today
At Oscar Wylee bulk billed eye tests are offered for eligible medicare card holders.
[Book an eye test](https://www.oscarwylee.com.au/booking)
Major Health Funds Accepted at Oscar Wylee
For the purchase of frames and lenses at Oscar Wylee, use your private health fund insurance to minimize how much you pay from your own pocket.
[Explore Health Funds](https://www.oscarwylee.com.au/health-funds.html)