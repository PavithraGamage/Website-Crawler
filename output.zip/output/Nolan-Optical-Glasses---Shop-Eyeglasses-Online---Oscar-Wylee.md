# Source: https://www.oscarwylee.com.au/nolan.html

[Skip to the end of the images gallery](#gallery-next-area)
[Skip to the beginning of the images gallery](#gallery-prev-area)
# Nolan
1
## Frame Design of Nolan Glasses
The frame design of Oscar Wylee’s Nolan glasses is characterised by their square shape, high nose bridge, and bio-acetate and stainless steel frame. Nolan is a men’smale, statement glasses frame that will complement any outfit, day to night.
Prescription
Choose your lenses
What do you use your glasses for?
Distance
For being able to see far away objects clearly. Distance glasses are ideal for activities such as driving and watching TV.                
Reading
For magnifying nearby objects. These are ideal for close-up activities such as reading books and working on the computer.                
Multifocal Lenses
For clarity in both distance and reading vision. Multifocal lenses are helpful for those who require a certain prescription strength for reading and a different prescription strength for distance.                    
We currently do not offer multifocal lenses for purchase online, as they require an in-store fitting. To complete an order with multifocal lenses, visit us at your nearest Oscar Wylee store.
[Find a location](https://www.oscarwylee.com.au/locations/full-store-list.html/)
Non prescription
Clear lenses for those who do not require prescription glasses and vision correction.                
Please note that we cannot accept expired prescriptions. If your prescription has expired, [book an eye test](https://www.oscarwylee.com.au/booking/) with us.        
Add your prescription
back
I’m an existing customer                        We'll use your prescription we have on file, or contact you if more info is needed.
We'll use your prescription we have on file, or contact you if more info is needed.                    
Upload a photo of it                        This is the quickest option!
Please upload an image (in jpg, png or pdf) of your prescription.                    
images over 800px high or wide, will be resized before saving
Send it to us later                        Email us your prescription after checkout.
You can send us your prescription by:
|
|
| Email:[[email&nbsp;protected]](/cdn-cgi/l/email-protection#4e272028210e213d2d2f3c3937222b2b602d2123) |
Don't forget to include your prescription and the email address that you will be entering during checkout step.
Have us call your optometrist                        We will get your prescription from your optometrist.
Enter in your optometrist’s information, and we’ll reach out to obtain your prescription information.
Patient’s full name
Patient’s date of birth
Optometrist’s business name
Optometrist’s phone number
Choose another method to add prescription
Lens Options
Your Lenses
Pupillary Distance (PD)                            
[What is Pupillary Distance?](https://dj3im2gm3txew.cloudfront.net/pub/media/catalog/PD_measurement_tool.pdf)
I have 2 PD values
Select your PD (Right)25.025.526.026.527.027.528.028.529.029.530.030.531.031.532.032.533.033.534.034.535.035.536.036.537.037.538.0                                    
Select your PD (Left)25.025.526.026.527.027.528.028.529.029.530.030.531.031.532.032.533.033.534.034.535.035.536.036.537.037.538.0                                    
Select your PD505152535455565758596061626364656667686970717273747576                                
I confirm that this information is correct.
Pupillary Distance (PD)                            
[What's Pupillary Distance?](https://dj3im2gm3txew.cloudfront.net/pub/media/catalog/PD_measurement_tool.pdf)
I have 2 PD values
Select your PD (Right)25.025.526.026.527.027.528.028.529.029.530.030.531.031.532.032.533.033.534.034.535.035.536.036.537.037.538.0                                    
Select your PD (Left)25.025.526.026.527.027.528.028.529.029.530.030.531.031.532.032.533.033.534.034.535.035.536.036.537.037.538.0                                    
Select your PD505152535455565758596061626364656667686970717273747576                                
I confirm that this information is correct.
### Lens Thickness
Standard                            1.5 index lens
Recommended for prescriptions for power +/- 3.00
INCLUDED                            
Extra Thin                            1.61 index lens
Recommended for prescriptions for power +/- 3.00 to +/- 4.00
+$110                    
Super Thin                            1.67 index lens
Recommended for prescriptions for power +/- 4.00 to +/- 5.00
+$160                    
Ultimate Thin                            1.74 index lens
Recommended for strong prescriptions, power higher than +/- 5.00
+$260                    
Types of Glasses
Clear Glasses
Our clear glasses have optical lenses without any tint, designed to provide vision correction for a wide range of prescriptions.                            
Sunglasses
Our sunglasses have tinted lenses that protect your eyes from the sun’s harmful rays and reduce glare for clearer, more comfortable vision.                            
Sun Protection
800px 
Tinted Lenses
Tinted lenses for style and comfort
+$30
Grey
Category 3
Brown
Category 3
Green
Category 3
800px 
Gradient Tint Lenses
Lenses that are darker on top and lighter below
+$30
Grey
Category 2
Brown
Category 2
Green
Category 2
800px 
Polarised Lenses
Polarised lenses for enhanced clarity
+$100
Grey
Category 3
Brown
Category 2
Green
Category 3
800px 
Photochromic and Transitions® Lenses
Lenses that darken in sunlight
from
$100
Adaptive Lenses
Changes from clear to darker opacity to adapt to light conditions.                                    
+$100
Grey
Category 3
Transitions® Gen S™
Transitions® branded photochromic lenses, quickly change from clear to a darker opacity to adapt to light conditions.                                    
+$160
Grey
Category 3
Brown
Category 3
Ruby
Category 3
Sapphire
Category 3
Graphite Green
Category 3
Amethyst
Category 3
Emerald
Category 3
Amber
Category 3
ⓘ
What are Lens Categories?
* Filter category 2:
General purpose sunglasses. Good protection against sun-glare. Good UV protection. Not suitable for driving in twilight or at night or under dull conditions.
* Filter category 3:
General purpose sunglasses. High protection against sun-glare. Good UV protection. Not suitable for driving in twilight or at night or under dull conditions.
Lens Add Ons*
Clear
INCLUDED
None
Anti-Reflective*
Reduces annoying reflection
Improves cosmetic appearance
Scratch resistant hard coating
INCLUDED
Premium Anti-Reflective*
Highly recommended
Reduces annoying reflections for clearer vision
Scratch and smudge resistant, anti-static
Improves cosmetic appearance
Can reduce eye strain due to glare
+$10
Blue Light Filter*
Filters blue light from digital screens
Scratch-resistant, anti-reflective lenses
+$80
Blue Light Filter Premium*
(Blue Light Filter + Premium Anti-Reflective)
Best Value
Includes Blue Light Filter
Includes Premium Anti-Reflective coating
Scratch and smudge resistant, anti-static
+$90
*Please note that lens add-ons cannot be added to your glasses after the order has been placed.            
*on the back of sunglasses lenses only            
Review Your Selections
Free domestic shipping with every order
Edit Selections
Discounts will be calculated at checkout
$169    
In stock
Only %1 left
2 pairs from $199
Discount auto-applied at checkout
3 pairs from $249
Discount auto-applied at checkout
Qty
Add to cart
Book an eye test
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
excluding prescription lenses
## About Nolan Frames
The frame design of Oscar Wylee’s Nolan glasses is characterised by their square shape, high nose bridge, and bio-acetate and stainless steel frame. Nolan is a men’s, statement glasses frame that will complement any outfit, day to night.
| Frame fit | Measurements |
| --- | --- |
| WIDE | 58 - 17 - 145 |
These measurements mean lens width, bridge, and temple length in millimetres (mm). They can be found on the inside of the temple arm. If you already have a pair that you like, you can compare it to these measurements.
### Made from TR90
Oscar Wylee’s Nolan frame is a men’s square glasses frame that is perfect for those with round and oval face shapes. The Nolan frame is a stylish, widely wearable frame that can be worn every day. The main specs of Oscar Wylee’s Nolan glasses frame, including dimensions, shape, materials, lenses, nose fit, and hinges are listed below.
| Nolan Frame Features | Nolan Frame Description | Dimensions | Shape | Materials | Lenses | Nose Fit | Hinges |
| --- | --- | --- | --- | --- | --- | --- | --- |
| The dimensions of the Nolan frame are measured in millimetres (mm) and are 58 - 17 - 145, meaning the lens width is 586 mm, the bridge is 176 mm, and the temple length is 134 mm. |
| Nolan is a square shape, well-suited to wide faces. |
| Nolan is made from TR90 with rubber temple tips. |
| The lenses that can be used in the Nolan frame include optical lenses, such as single-vision and multifocal, and non-prescription lenses, which are plain and can have a filter, such as a blue light filter applied. |
| The nose fit for Nolan is characterised by a low nose bridge. |
| The hinges in Nolan are normal hinges, also known as standard or barrel hinges. |
Show All
### What Inspired the Frame Design of Oscar Wylee’s Nolan Glasses?
The Oscar Wylee Nolan frame design was inspired by current fashion trends, as square glasses are a timeless style.
## What to Know About Oscar Wylee’s Nolan Glasses?
There are many aspects of the Oscar Wylee Nolan frames that customers should know about to decide whether this is the right frame for them. The Nolan frame is a men’s square shaped frame. Oscar Wylee’s Nolan frame is suitable for many face shapes, but particularly compatible with round and oval face shapes. The Nolan frame’s simple design makes them fashionable all year round. Nolan features the standard [parts of glasses](https://www.oscarwylee.com.au/glasses/eye/part-of-glasses), such as a rim, temples, lenses and hinges.
### What are the Types of Temple Tips or Earpieces Included with Oscar Wylee’s Nolan Glasses?
The type of temple tips or earpieces included in Oscar Wylee’s Nolan Glasses are made from rubber.
### What Type of Nose Bridge do Oscar Wylee’s Nolan Glasses Have?
The type of nose bridge included in Oscar Wylee’s Nolan frame is characterised by a high nose bridge.
### What Type of Nose Pads are Included with Oscar Wylee’s Nolan Glasses?
Oscar Wylee’s Nolan frame does not include adjustable nose pads.
### What Type of Lenses do Oscar Wylee’s Nolan Glasses Have?
The type of lenses that typically come with the Oscar Wylee Nolan [glasses frame](https://www.oscarwylee.com.au/glasses.html) are optical lenses. Optical lenses are glasses lenses that have a prescription within the lens to help correct vision issues such as myopia, hyperopia, and astigmatism. Nolan frames can also come as sunglasses and with non-prescription lenses and add-ons such as a blue light filter. Nolan frames can be customised into sunglasses in-store or online with add-on tints or polarisation.
### What Material is Used for the Rim of Oscar Wylee’s Nolan Glasses?
The material used for the rim of Oscar Wylee’s Nolan glasses frames is TR90. The rim refers to the part of a glasses frame that holds the lenses.
### What Type of Hinges are Included with Oscar Wylee’s Nolan Glasses?
The type of hinges included with Oscar Wylee’s Nolan frames are normal hinges, also known as standard or barrel hinges. These provide strength and smooth movement connecting the frame's arms and lenses.
## What Face Types are Most Suitable for Oscar Wylee’s Nolan Glasses?
The face types that are most suitable for Oscar Wylee’s Nolan frame are round and oval face types. The Nolan frame is a square shape, meaning that it complements the structure of oval and round faces particularly well. The oval and round Nolan frames help balance the features of [round faces](https://www.oscarwylee.com.au/glasses/face-shapes/round) and [oval faces](https://www.oscarwylee.com.au/glasses/face-shapes/oval) and bring the eyes and brows forward in a flattering way. Although there are many [glasses for face shapes](https://www.oscarwylee.com.au/glasses/face-shapes) that may be considered more aesthetically suitable, it is important that people also choose frames that make them feel most comfortable and represent their personal style.
## What Size Options are Available for Oscar Wylee’s Nolan Glasses?
The size options available for Oscar Wylee’s Nolan frame are a wide-frame fit across all colours.
## What Materials are Used to Create Oscar Wylee’s Nolan Glasses?
The primary material used to create the Oscar Wylee Nolan frame is TR90. TR90 is used for the rim, nose bridge, and temple, and the temple tips are made from rubber.
## What’s Included
## OW Case &amp; Cloth
Protective Case and Lens Cloth
Our high-quality glasses case and lens cloth are included with every purchase of an Oscar Wylee frame. The stylish, magnetic case is made from a hard shell. This sturdy and durable material keeps your glasses protected and safe, wherever you go. Ensure your lenses are clean and scratch-free with our OW microfibre cloth, specifically designed to ensure you have comfortable vision through your lenses.
Oscar Wylee offers:
* Free Shipping for Australian Orders
* 1 Year Warranty on frames and lenses
* Scratch resistance lens coating on all prescriptions
* UV-proof coating on all prescriptions
Health fund rebate: Once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. Learn more about [health funds](https://www.oscarwylee.com.au/health-funds.html).
## Make and Materials
Our TR90 glasses are for the adventurers! TR90 is a thermoplastic material renowned for its lightweight nature, durability and comfort. TR90 is produced through Swiss technology that allows it to be incredibly strong and tough to impact, perfect for the active wearer.The frames go through cleaning and strict quality control.After your frames have gone through the production process, they are individually examined and packed before making their way to you!
## Warranty Information
### Warranty Information
### Warranty Information
Oscar Wylee provides a 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects. We will repair or replace faulty or defective frames or lenses free of charge for warranty claims made within 1 year of the delivery. We also offer repairs or replacement for problems experienced with vision during everyday use for claims made within 30 days of delivery. If the same product has been discontinued or is no longer available, then we may offer an exchange for a similar product or a refund.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Find a Store Location](https://www.oscarwylee.com.au/locations/full-store-list.html)