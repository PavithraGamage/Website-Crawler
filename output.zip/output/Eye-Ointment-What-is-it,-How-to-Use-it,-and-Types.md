# Source: https://www.oscarwylee.com.au/glasses/eye/ointment

# Eye Ointment: What is it, How to Use it, and Types
Published on October 30th, 2023
Updated on Month Date, 2025 
Australia
[Australia](https://www.oscarwylee.com.au/glasses/eye/ointment)
New Zealand

[Canada](https://oscarwylee.ca/glasses/eye/ointment)
Canadian French

Eye ointments are an eye medication, similar to eye drops, that are a thick,
gel-like eye paste that is directly applied to the lower eyelid in a small
quantity. Eye ointments are typically used as a method to directly apply a
necessary medication to the eye, without having to dilute the medicine
itself. Eye ointment can be prescribed or bought
over-the-counter (OTC). Prescribed eye ointment or eye ointment OTC can be
purchased and used as eye infection cream against bacteria or virus
infections, or as an eye paste or eye moisturising ointment that can be
applied to prevent dry eyes and eye swelling, depending on the conditions of
the eye and the full diagnosis and recommendation of a doctor or other
health professional.
Gave your eyes tested
Oscar Wylee offers bulk billed eye tests in stores for valid Medicare
cardholders.
[Book your eye test](https://www.oscarwylee.com.au/booking)
[Definition](#definition)
[How to Use](#how-to-use)
[Different Types](#different-types)
[Benefits](#benefits)
## What is an Eye Ointment?
Eye ointment, also known as ophthalmic ointment, is
a thick, gelatinous substance that is composed of a type of
medication, such as antibiotic or antiviral liquids. Eye ointment is thick and
semisolid when it is directly applied to the inside of the lower eyelid,
it is the body's heat which melts the substance and spreads the liquid
into smaller drops that linger where they were applied. Eye ointments
are used to treat different types of eye conditions, such as infections
or dry eyes. Eye ointment is most commonly applied to the eyelid at
night.
## What is the Importance of Eye Ointment?
Eye ointment is important as a choice of treatment for
when eye drops aren’t working or if a health professional feels they
are more suited to treatment than eye drops.
The substance eye ointment is typically made of, stays in the eyes for
longer than eye drops, possibly making treatment faster and enabling
medication to stay in long term contact with the eye.
## What is the Use of Eye Ointment?
Eye ointment is used to
treat conditions such as dry eyes, eye infections and eye
allergies.
## How to Use Eye Ointment?
To use eye ointment,
clean your hands, take a hold of the tube, lean your head back a
little, hold the ointment tube against your eye, pull down your lower
lid slowly, put a small bit of eye ointment into your eye, drop your
eyelid, close your eye gently for a minute and wipe off the excess
with a clean tissue. The following steps explain how to apply eye ointment.
* Clean your hands: Clean your hands to ensure there is
no dirt, infection or bacteria that could be passed into the eye.
* Take a hold of the tube: Take a hold of the tube
gently, the heat from the hand may soften the ointment and allow it to
flow out more smoothly.
* Lean your head back a little: Lean your head back a
little, to find a comfortable position to stay in.
* Hold the ointment tube up to your eye: Hold the
ointment tube up to your eye to prepare to apply the liquid. Do not
touch the eye with the tube.
* Pull down your lower lid slowly: Pull down your lower
lid slowly in order to apply the eye ointment to the inside of it.
* Put a small bit of eye ointment into your eye: Put a
small bit of eye ointment into your eye, specifically the lower
eyelid, to apply the eye ointment.
* Drop your eyelid: Drop your eyelid by gently letting
go of it in order to spread the ointment.
* Close your eye gently for a minute: Close your eye
gently for a minute to spread the ointment across the eye and allow
the ointment to settle.
* Wipe off the excess with a clean tissue: Wipe off the
excess with a clean tissue to ensure no remaining eye ointment will
disrupt your vision.
### 1. Clean Your Hands
Before handling any medication or eye ointments, it is important to
clean your hands. Washing with liquid soap is preferable, but any
soaps without essential oils, shea butter or other additives is a good
choice for completely sterile and clean hands. A clean towel should
also be used, as dirt or debris from a towel or hands may get into the
oil or the eye as you take a hold of the tube.
### 2. Take a Hold of the Tube
Take a hold of the tube in your hands to prepare to squeeze it onto
the eyes, and also to heat the tube and ointment slightly so that it
may flow out easier. Ensure that you are holding the tube and are not
squeezing it, as the tube may burst or cause a leakage, which means
you might have to wash your hands again. Finding a decent grip on the
tube will allow you to hold the tube comfortably as you lean your head
back a little.
### 3. Lean Your Head Back a Little
Lean your head back a little, until the eye can see the ceiling.
Finding a comfortable position for your head to tilt in will greatly
assist in the next steps and stop you from having to constantly
readjust as you hold the ointment tube against your eye.
### 4. Hold the Ointment Tube Up to Your Eye
Hold the ointment tube up to your eye in order to prepare to apply the
liquid in the most comfortable and smoothest way possible. Holding the
ointment tube up to your eye before you pull down your lower lid
slowly can result in a quicker and easier process for applying eye
ointment. Do not touch the eye with the ointment tube.
### 5. Pull Down Your Lower Lid Slowly
Pull down your lower lid slowly but gently to prepare for the eye
ointment. The lower eyelid should be pulled to have just enough space
to put a small bit of eye ointment into your eye. The space in the
eyelid should be about pocket-sized, and for the most effective
application of the eye ointment, find a position that can be held for
a minute or less.
### 6. Put a Small Bit of Eye Ointment Into Your Eye
Put a small bit of eye ointment into your eye, more specifically into
the pocket of the eye that has been opened up by the previous step of
pulling down the lower lid slowly. First, put one small drop, the size
of a grain, into your eye. Then, pull the eyelid slightly more and
apply the ointment across the bottom eyelid, in a short line.
### 7. Drop Your Eyelid
Drop and let go of your eyelid gently in order to keep the eye
ointment in your eye, and be sure to press down on the corner of your
eye close to the bridge of the nose. This will prevent any medication
from going down your nose. This can reduce the discomfort as you close
your eyes gently for a minute.
### 8. Close Your Eyes Gently for a Minute
Close your eyes gently for a minute in order to apply the ointment
placed across your lids directly around and across the eye itself. If
possible look downwards with your eyes closed. Closing your eyes may
cause a stinging sensation but is important for keeping the ointment
that reached your eye inside your eyelids as any excess that was not
trapped is wiped off.
### 9. Wipe Off the Excess With a Clean Tissue
Wipe off the excess with a clean tissue in order to keep your vision
clear and, additionally, to not have too much eye ointment in contact
with your eyes and face. Wiping off the excess will also keep you from
inhaling or swallowing the eye ointment or from the ointment going
into your nose.
#### How Much Eye Ointment Should You Put on Your Eye?
1 cm of eye ointment along the lower eyelids is the best amount to
apply to the eye,
according to Moorfields Eye Hospital, a hospital in association with
the United Kingdom's National Health Service.
## What are the Different Types of Eye Ointment?
The different types of eye ointment are
antibiotic ointments, antiviral ointments, anti-inflammatory
ointments, tear duct plug ointments and artificial tear
ointments.
The different types of eye ointment are listed below.
* Antibiotic ointments: Antibiotic ointments are eye
ointments that are used to treat eye infections, most commonly
bacterial infections.
* Antiviral ointments: Antiviral ointments are eye
ointments that are used to treat viral infections, such as eye herpes.
* Anti-inflammatory ointments: Anti-inflammatory
ointments are eye ointments that are used to treat inflammation and
swelling caused by eye conditions such as eye allergies.
* Tear duct plug ointments: Tear duct plug ointments
are eye ointments that are used to treat dry eyes by forcing the tears
to stay in place and lubricate the eye.
* Artificial tear ointments: Artificial tear ointments
are eye ointments that are used to treat dry eyes and similar
conditions by coating the eye with lubricating substances.
Stop by your nearest Oscar Wylee!
Find your latest pair of fashion-forward and cost-effective frames
at your closest Oscar Wylee store.
[Locate your store](https://www.oscarwylee.com.au/locations/full-store-list.html)
### 1. Antibiotic Ointments
Antibiotic eye ointments refers to
eye ointments that contain antibiotic and antibacterial substances
such as chloramphenicol, bacitracin, polymyxin or neomycin. Antibiotic ointments are used to treat bacterial eye infections,
which can cause conditions such as red eyes, eyelid infections, styes
or blepharitis. Antibiotic ointments are best used for bacterial eye
infections and may not be as effective in treating viral eye
infections or similar conditions. Antibiotic ointments are most
commonly prescription medications and may only be purchased with a
health professional’s recommendation.
### 2. Antiviral Ointments
Antiviral ointments refers to
eye ointments that contain antibiotic, anti-inflammatory and
antiviral substances.
Antiviral ointments are used to treat viral eye infections such as
infectious keratitis or eye herpes. Antiviral ointments are varied in
purpose and construction, it is highly recommended to rely on an
expert’s opinion on the exact medication to use instead of trusting
external or irrelevant sources. Antiviral ointments are most commonly
prescription medications and may only be purchased with a health
professional’s recommendation.
### 3. Anti-inflammatory Ointments
Anti-inflammatory ointments refers to
eye ointments that contain antihistamines and other
anti-inflammatory substances, such as corticosteroids, NSAIDS and
mast cell stabilisers.
Anti-inflammatory ointments are used to treat eye conditions that
cause swelling and inflammation, such as eye allergies or eye
injuries. Anti-inflammatory ointments are most commonly prescription
medications and may only be purchased with a health professional’s
recommendation.
### 4. Tear Duct Plug Ointments
Tear duct plug ointments, also known as punctal plugs, refers to
eye ointments that are made of thick collagens that may dissolve
over time.
Tear duct plug ointments are used to treat dry eyes, by plugging the
possible spaces where the tears may be flowing out of the eyes,
forcing the tears in place and keeping the eyes lubricated. Tear duct
plug ointments are a prescription treatment and this
type of treatment should only be considered after extensive
discussion with an eye health professional.
### 5. Artificial Tear Ointments
Artificial tear ointments refers to
eye ointments that contain substances such as
carboxymethylcellulose or povidone.
Artificial tear ointments are used to treat dry eyes or relieve
symptoms of conditions such as eye allergies or inflammation by
providing the eye with lubrication it may not be receiving. Artificial
tear ointments are over-the-counter medications that can be purchased
without a prescription. Please do not use artificial tear ointments without an expert's
recommendation.
### What Are the Most Commonly Used Eye Ointments?
The most commonly used eye ointments are
chloramphenicol and tobramycin. The
following are the most commonly used eye ointments.
* Chloramphenicol: Chloramphenicol is an antibiotic
used to treat infections such as bacterial conjunctivis.
* Tobramycin: Tobramycin is an antibiotic that is
used to treat bacterial eye infections and may additionally act as
an antiseptic.
#### 1. Chloramphenicol
Chloramphenicol is an eye
ointment form that helps to treat bacterial eye infections such as
conjuncitivis.
Chloramphenicol eye ointment is an antibiotic that helps combat eye
infections by slowing the growth of bacteria. It can be used to treat
bacterial eye infections that include bacterial conjuncitivis.
#### 2. Tobramycin
Tobramycin is an eye ointment that is
used to treat severe infections and may also be used as an
antiseptic.
Tobramycin eye ointment is an antibiotic eye ointment and is commonly
used to treat bacterial eye infections by killing the bacteria, and is
a possible antiseptic for use after an eye injury or eye surgery.
Tobramycin is a prescription medication and cannot be purchased
over-the-counter.
#### What Type of Eye Ointment is for Dry Eyes?
Artificial tear eye ointments may be used to treat
[dry eyes](https://www.oscarwylee.com.au/glasses/eye/dry-eyes)
and similar conditions, as these ointments help bring lubrication to
the eyes.Please do not use artificial tear ointments without an expert's
recommendation.
#### What Type of Eye Ointment is for Red Eyes?
Antibiotic, antiviral, anti-inflammatory and artificial tear
ointments
may all possibly be used in order to treat
[red eyes](https://www.oscarwylee.com.au/glasses/eye/red-or-bloodshot), as each ointment may be effective in treating the cause of the red
eye, such as swelling, dry eyes or infection.
It is recommended to see a health professional to determine the
possible cause and treatments of red eye.
#### What Type of Eye Ointment is for Conjunctivitis?
Antibiotic eye ointments may be used to treat
[conjunctivitis](https://www.oscarwylee.com.au/glasses/eye/conjunctivitis)and conjunctival infections and may include specific eye ointments
such as gentamicin or erythromycin,
which is also used to treat other eye infections. 
It is recommended to see a health professional to determine the
possible cause and treatments of red eye.
#### What Type of Eye Ointment is for Blepharitis?
Anti-inflammatory eye ointments that may be used to treat
[blepharitis](https://www.oscarwylee.com.au/glasses/eye/eyelids-inflammation)
may include
corticosteroids or antibiotic eye ointments such as Siguent Hycor
or chloramphenicol eye ointment.
This will reduce inflammation or prevent bacteria from causing the
uncomfortable symptoms of blepharitis. 
Do not use anti-inflammatory eye ointments without an expert's
recommendation.
#### What Type of Eye Ointment is for Bacterial Infections?
Antibiotic eye ointments may be used to treat
bacterial infection and may include specific eye ointments such as
bacitracin or ciprofloxacin, which is specifically
targeted towards addressing bacterial eye infections.
Antibiotic eye ointments are prescription medicines and should only
be used with a health expert's diagnosis.
## What are the Benefits of Eye Ointment?
The benefits of eye ointment are
thicker drops, multiple conditions treated, and faster
treatment.
The benefits of eye ointment are listed below.
* Thicker drops: Thicker drops are a benefit of eye
ointment because it allows any treatments or medicines being applied
to the eye to last longer than other medication such as eye drops.
* Multiple conditions treated: Multiple conditions
treated is a benefit of eye ointment because the types of medication
contained in eye ointments in combination with the thicker drops, may
result in multiple eye conditions being treated when the medication is
used.
* Faster treatment: Faster treatment is a benefit of
eye drops because eye ointments can directly make contact with the
conditions they are treating and will stay on the eye for longer once
they are applied, allowing for stronger treatment.
## What are the Side Effects of Eye Ointment?
It is important to seek medical attention if you experience any side
effects from eye ointments.
The potential side effects of eye ointment can depend on exactly which
eye ointment was used. Possible side effects of eye ointments may be
blurred vision, red eyes, eye pain and watery eyes.
* Blurred vision: Blurred vision is a possible side
effect of eye ointment because the thicker drops of eye ointment
interfere with vision more than standard eye drops.
* Red eyes: Red eyes may be a side effect of eye
ointments because, as the ointment is applied, it might sting and
cause mild discomfort due to the thickness of the drops.
* Eye discomfort: Eye discomfort may be a side effect
of eye ointment because the sensation of the drops being applied to a
sensitive area of the eyes and the time it takes for the drops to
break up, may cause a stinging or otherwise disconcerting sensation.
* Watery eyes: Watery eyes are a possible side effect
of eye ointment because the thickness of the substance may irritate
the eye as it’s applied, causing a short discharge of tears.
## How Long Should You Keep Using Eye Ointment?
Eye ointment should stay in use for as long as an eye health
professional has prescribed it, however, it is important to be aware of
the expiration date of eye ointments.
Eye ointments commonly expire 4 weeks after opening them,
according to Health Navigator, a New Zealand-based health information
organisation, however this can differ. You should be sure to check any
eye ointment for an expiry date before use.
### How Effective are Eye Ointments in Treating Different Eye Problems?
The effectiveness of eye ointments in treating different
[eye problems](https://www.oscarwylee.com.au/glasses/eye/common-problems)
depends on the ointment’s type and the conditions being treated, such
as antibiotic eye ointments being effective at treating bacterial eye
infections or antiviral eye ointments being effective at treating
viral eye infections. For this reason,
it is highly recommended that specialist expertise is sought before
using any forms of eye drops.
#### Which is More Effective, Eye Ointments or Eye Drops?
Eye ointment is considered more effective than
[eye drops](https://www.oscarwylee.com.au/glasses/eye/types-of-eye-drops)
because
the substance is thicker, the effects are more potent and the
treatment can take effect while a person sleeps,
according to Queensway Optometric, a Canadian optometry practice.
#### Why is Eye Ointment Only Applied at Night?
Eye ointments are only applied at night because
the thicker, more gel-like substance eye ointments are made of can
interfere with regular vision if applied during the day,
according to the United Kingdom's National Health Service.
##### Are Over-the-counter Eye Ointments Effective?
Over-the-counter eye ointment's effectiveness
depends on the conditions they are treating and if
the ointment used is relevant and useful to the person who is applying
it or was recommended by a relevant health expert. For any eye treatments, whether over-the-counter or prescribed,
please seek a specialist's advice before using any treatment.
Read Eye Ointment: What is it, How to Use it, and Types in other Oscar
Wylee regions and their languages.
Australia
[Australia](https://www.oscarwylee.com.au/glasses/eye/ointment)
New Zealand

[Canada](https://oscarwylee.ca/glasses/eye/ointment)
Canadian French

We welcome leading health funds
Check our handy guide to see your health funds policies and how they
apply to Oscar Wylee.
[Discover your health fund](https://www.oscarwylee.com.au/health-funds.html)
Book an eye test
Visiting an optometrist every 2 years is recommended for the best
possible eye health. Oscar Wylee offers bulk billed eye tests for
eligible Medicare cardholders.
[Book an eye test](https://www.oscarwylee.com.au/booking)