# Source: https://www.oscarwylee.com.au/crew-sunglasses.html

Out of stock        
# Crew
## About Crew Sunglasses
This sporty style will protect you from the sun and keep you looking stylish. Fitted with rubber grip arms, a lightweight build and polarised lenses to reduce glare. Add this sunglass frame to your crew.
| Frame fit | Measurements |
| --- | --- |
| WIDE | 58 - 16 - 135 |
These measurements mean lens width, bridge, and temple length in millimetres (mm). They can be found on the inside of the temple arm. If you already have a pair that you like, you can compare it to these measurements.
### Made from TR90
Oscar Wylee’s Crew frame is a men's square sunglasses frame that is perfect for those with round and oval face shapes. The Crew frame is a sporty and versatile frame that can be worn every day. The main specs of Oscar Wylee’s Crew glasses frame, including dimensions, shape, materials, lenses, nose fit, and hinges are listed below.
Filter category 3 - General purpose sunglasses. High protection against sunglare. Good UV Protection.Not suitable for driving in twilight, at night or under dull conditionsThis frame comes with polarised lenses. An additional $100 will be added to your order total for prescription orders.
| Crew Frame Features | Crew Frame Description | Dimensions | Shape | Materials | Lenses | Nose Fit | Hinges |
| --- | --- | --- | --- | --- | --- | --- | --- |
| The dimensions of the Crew frame are measured in millimetres (mm) and are 58 - 16 - 135, meaning the lens width is 58 mm, the bridge is 16 mm, and the temple length is 135 mm. |
| Crew is a square shape, well-suited to wide faces. |
| Crew is made from TR90, with TR90 and rubber temple tips. |
| The lenses that can be used in the Crew frame are sunglass lenses, which provide UV protection. Prescription lenses are also available to purchase for the Crew sunglass frame, both online and in-store. |
| The nose fit for Crew is a low nose bridge fit. |
| The hinges in Crew are spring hinges, which are more flexible than other types of hinges and can extend past 90 degrees. |
Show All
### What Inspired the Frame Design of Oscar Wylee's Crew Glasses?
The Oscar Wylee Crew frame design was inspired by current fashion trends, as square shapes are often in fashion. A square glasses shape is timeless; it remains popular throughout the decades while other trends come and go.
## What to Know About Oscar Wylee's Crew Sunglasses?
There are many aspects of the Oscar Wylee Crew frames that customers should know to decide whether this is the right frame for them. The Crew frame is a men's square sunglasses frame. Oscar Wylee’s Crew frame is suitable for many face shapes, but particularly compatible with round and oval face shapes. The Crew frame’s simple design makes them fashionable all year round. Crew features the standard [parts of glasses](https://www.oscarwylee.com.au/glasses/eye/part-of-glasses), such as a rim, temples, lenses, spring hinges, and a low nose bridge.
### What are the Types of Temple Tips or Earpieces Included with Oscar Wylee's Crew Glasses?
The type of temple tips or earpieces included in Oscar Wylee’s Crew Glasses are made from TR90 and rubber.
### What Type of Nose Bridge do Oscar Wylee's Crew Glasses Have?
The type of nose bridge included in Oscar Wylee’s Crew frame is a low nose bridge fit.
### What Type of Nose Pads are Included with Oscar Wylee's Crew Glasses?
Oscar Wylee’s Crew frame does not include adjustable silicone nose pads.
### What Type of Lenses do Oscar Wylee's Crew Sunglasses Have?
The lenses that can be used in the Crew frame are sunglass lenses, which provide UV protection. UV protection lenses block harmful ultraviolet rays, safeguarding eyes from damage. The Crew frame comes in Filter Category 3. These are general purpose sunglasses. low protection against sunglare. Good UV protection. They are not suitable for driving in twilight, at night, or under dull conditions. Prescription lenses are also available for the Crew frame, both online and in-store.
### What Material is Used for the Rim of Oscar Wylee's Crew Glasses?
The material used for the rim of Oscar Wylee’s Crew glasses frames is TR90. The rim refers to the part of a glasses frame that holds the lenses.
### What Type of Hinges are Included with Oscar Wylee's Crew Glasses?
The type of hinges included with Oscar Wylee’s Crew frames are spring hinges. A spring hinge in a glasses frame refers to hinges that are more flexible than normal hinges and can go slightly beyond 90 degrees. Spring hinges can provide a closer fit to the face.
## What Face Types are Most Suitable for Oscar Wylee's Crew Glasses?
The face types most suitable for Oscar Wylee’s Crew frame are round and oval face types. The Crew frame is a square shape, meaning it complements the structure of round and oval faces particularly well. The square Crew frames help balance the features of a [round face shape](https://www.oscarwylee.com.au/glasses/face-shapes/round) and an [oval face shape](https://www.oscarwylee.com.au/glasses/face-shapes/oval), bringing the eyes and brows forward in a flattering way. Although there are many different [glasses for face shapes](https://www.oscarwylee.com.au/glasses/face-shapes) that may be considered more aesthetically suitable, it is important that people also choose frames that make them feel most comfortable and represent their personal style.
## What Size Options are Available for Oscar Wylee's Crew Glasses?
The size option available for Oscar Wylee’s Crew frame is a wide-frame fit.
## What Materials are Used to Create Oscar Wylee's Crew Glasses?
The primary material used to create the Oscar Wylee Crew frame is TR90. TR90 is a form of thermoplastic material, perfect for making flexible, durable, and lightweight glasses.
## What’s Included
## What's Included
Each pair of glasses comes with a stylish frame case and lens cloth. We offer free shipping across Australia and 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects.
* Free Shipping for Australian Orders
* 1 Year Warranty on frames and lenses
* Scratch resistance lens coating on all prescriptions
* UV-proof coating on all prescriptions
* Stylish case and cloth
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
## Make and Materials
The frames then go through cleaning and strict quality control, and many pairs of crafting hands to be hand-assembled and polished. After your frames have gone through the production process, they are individually examined and&nbsp;packed before making their way to you!We love our Ultem frames! They are super comfortable and very durable. Our Ultem frames are heat resistant, with high dielectric strength and flexible. The material is widely used in medical and chemical instruments. It is currently available in a range of colours for both matte and gloss finish.
## Warranty Information
### Warranty Information
### Warranty Information
Oscar Wylee provides a 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects. 
We will repair or replace faulty or defective frames or lenses free of charge for warranty claims made within 1 year of the delivery.
We also offer repairs or replacement for problems experienced with vision during everyday use for claims made within 30 days of delivery. If the same product has been discontinued or is no longer available, then we may offer an exchange for a similar product or a refund.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Find a Store Location](https://www.oscarwylee.com.au/locations/full-store-list.html)