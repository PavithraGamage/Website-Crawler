# Source: https://www.oscarwylee.com.au/health-funds.html

For the purchase of frames and lenses, use your private health fund insurance to limit how much you pay from your own pocket.
Looking for information about your private health fund provider? We’ve collected all the details you’ll need, making it easy to understand how much allowance and cover you have to use at Oscar Wylee.
# Private Health Fund Insurance
* [Bupa](https://www.oscarwylee.com.au/health-funds/bupa.html)
* [Medibank](https://www.oscarwylee.com.au/health-funds/medibank.html)
* [HCF](https://www.oscarwylee.com.au/health-funds/hcf.html)
* [NIB](https://www.oscarwylee.com.au/health-funds/nib.html)
* [HBF](https://www.oscarwylee.com.au/health-funds/hbf.html)
* [AHM](https://www.oscarwylee.com.au/health-funds/ahm.html)
* [Australian Unity](https://www.oscarwylee.com.au/health-funds/australian-unity.html)
* [CBHS Health](https://www.oscarwylee.com.au/health-funds/cbhs-health-fund.html)
* [see-u](https://www.oscarwylee.com.au/health-funds/see-u.html)
* [Defence Health](https://www.oscarwylee.com.au/health-funds/defence-health.html)
* [Doctors Health Fund](https://www.oscarwylee.com.au/health-funds/doctors-health-fund.html)
* [Frank](https://www.oscarwylee.com.au/health-funds/frank.html)
* [GMHBA](https://www.oscarwylee.com.au/health-funds/gmhba.html)
* [Health Partners](https://www.oscarwylee.com.au/health-funds/health-partners.html)
* [Healthcare Insurance](https://www.oscarwylee.com.au/health-funds/health-care-insurance.html)
* [HIF](https://www.oscarwylee.com.au/health-funds/hif.html)
* [Navy Health](https://www.oscarwylee.com.au/health-funds/navy-health.html)
* [Nurses &amp; Midwives Health](https://www.oscarwylee.com.au/health-funds/nurses-and-midwives.html)
* [onemedifund](https://www.oscarwylee.com.au/health-funds/onemedifund.html)
* [Peoplecare](https://www.oscarwylee.com.au/health-funds/peoplecare.html)
* [Phoenix Health Fund](https://www.oscarwylee.com.au/health-funds/phoenix-health-fund.html)
* [Police Health](https://www.oscarwylee.com.au/health-funds/police-health.html)
* [Qantas](https://www.oscarwylee.com.au/health-funds/qantas.html)
* [Queensland Country Health Fund](https://www.oscarwylee.com.au/health-funds/queensland-country.html)
* [RT Health Fund](https://www.oscarwylee.com.au/health-funds/rt-health.html)
* [Reserve Bank Health Society](https://www.oscarwylee.com.au/health-funds/reserve-bank-health-society.html)
* [St Luke's Health](https://www.oscarwylee.com.au/health-funds/st-lukes-health.html)
* [Suncorp](https://www.oscarwylee.com.au/health-funds/suncorp.html)
* [Teachers Health Fund](https://www.oscarwylee.com.au/health-funds/teachers-health-fund.html)
* [Uni Health Insurance](https://www.oscarwylee.com.au/health-funds/uni-health-insurance.html)
* [Westfund Health Insurance](https://www.oscarwylee.com.au/health-funds/westfund.html)
## Due for an eye test?
Get your no-gap, bulk billed eye exam with zero dollars out-of-pocket expense. Update your prescription and find your favourite pair.
[Book an eye test](https://www.oscarwylee.com.au/booking)
## Shop our glasses in-store
Visit our friendly staff in one of our Oscar Wylee stores to try on our wide range of glasses. From bold colours to subtle designs, we’ve got frames for everyone!
[Find your nearest location](https://www.oscarwylee.com.au/locations/full-store-list.html)
## Health funds at Oscar Wylee
At Oscar Wylee, we accept all health funds listed above, and we offer on the spot quotes and claims for extras cover across all our retail stores.
## What is health fund insurance?
Private health insurance helps cover the cost of your health care. Health fund cover is divided into ‘hospital’ and ‘extras’. Extras cover is used to claim on non-hospital services like optical or dental. Some policies will include ‘optical extras’ cover which you can use to pay towards the cost of new glasses.
### Oscar Wylee is part of CBHS Optical Choice Network
Being part of the CBHS Optical Choice Network will allow it's members to get the most from their membership cover when shopping in our [stores](https://www.oscarwylee.com.au/locations.html).
## Have you had your eyesight checked?