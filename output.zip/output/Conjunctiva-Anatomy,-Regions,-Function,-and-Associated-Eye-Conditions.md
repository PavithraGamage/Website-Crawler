# Source: https://www.oscarwylee.com.au/glasses/eye/anatomy/conjunctiva

# Conjunctiva: Anatomy, Function, and Associated Eye Conditions
Published on March 15th, 2024
Australia    
[Australia](https://www.oscarwylee.com.au/glasses/eye/anatomy/conjunctiva)
[Canada](https://oscarwylee.ca/glasses/eye/anatomy/conjunctiva)
[Canadian French](https://oscarwylee.ca/fr/glasses/eye/anatomy/conjunctiva)
The conjunctiva is a part of the eye’s anatomy and its main function is to keep the eyes lubricated and also protected from outside bacteria and infections. The conjunctiva is located in the outer layer of the eye and covers the sclera and the inside of the eyelids. The most common eye condition that affects the conjunctiva is conjunctivitis. Other conjunctiva-related eye problems include pterygium, subconjunctival haemorrhage and chemosis. A person can take care of their conjunctiva by booking regular eye tests, practising good hygiene and maintaining a healthy diet. Keep reading to learn more about the conjunctiva.
In Need of an Eye Test?
Easily book online or in-store for a bulk billed eye test by a trusted Oscar Wylee optometrist.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Definition](#definition) [Regions](#regions) [Related Problems](#problems) [Care](#care)
## What is the Conjunctiva?
The conjunctiva, also referred to as a mucous membrane, is the clear tissue that covers the sclera, the white part of the eye, and the inside of the eyelids, according to the American Academy of Ophthalmology. The conjunctiva covers the whites of the eye and lines the inside of the eyelid. The conjunctiva secretes fluids that keep the eyes lubricated and protected from infections and outside bacteria. The second function of the conjunctiva is to ensure no foreign body or object slips behind the eye, such as contact lenses.
## What is the Structure of the Conjunctiva?
The structure of the conjunctiva is made up of three regions which are the bulbar conjunctiva, the conjunctiva fornix and the palpebra conjunctiva. According to an article published in the National Library of Medicine, the conjunctiva has an average thickness of 33 microns (micrometres).
### What Colour is the Conjunctiva?
The conjunctiva is a clear membrane that covers the sclera, making it appear white. While the conjunctiva does not have a colour, a person with conjunctivitis may have red or pink-appearing eyes due to inflammation and the enlargement of blood vessels.
### Where is the Conjunctiva Located?
The conjunctiva is located at the front of the eye, covering the inside of the eyelid and the sclera, the white of the eye, according to the Cleveland Clinic. The conjunctiva covers the front part of the eye except for the cornea.
### What is the Conjunctiva Made of?
The conjunctiva is a clear membrane made of three different parts or regions which are the bulbar conjunctiva, the conjunctiva fornix and the palpebra conjunctiva. The conjunctiva is made of tissues and cells including goblet cells which secrete mucus and stratified squamous epithelium, according to Very Well Health.
### What are the Regions of the Conjunctiva?
The regions of the conjunctiva are the bulbar conjunctiva, the conjunctiva fornix and the palpebra conjunctiva. The regions of the conjunctiva and their definitions are listed below.
* Bulbar conjunctiva: The bulbar conjunctiva covers the eyeball and protects the sclera which is the white of the eye. The bulbar conjunctiva is the section that covers the sclera but not the cornea.
* Conjunctiva fornix: The conjunctiva fornix joins the bulbar conjunctiva and the palpebra conjunctiva and it protects the sclera. The conjunctiva allows the eyelid and eyeball freedom of movement.
* Palpebra conjunctiva: The palpebra conjunctiva is the lining of a person’s eyelids, both its upper and lower parts. This region is further divided into the marginal, tarsal, and orbital regions.
## What is the Function of the Conjunctiva?
The main function of the conjunctiva is to secrete fluids that keep the eyes lubricated and protected from infections and outside bacteria and bodies such as dust. According to an article published in the National Library of Medicine titled, Anatomy, Head and Neck, Eye Conjunctiva, the conjunctiva plays an important role in immune surveillance. Another [eye function](https://www.oscarwylee.com.au/glasses/eye/anatomy) of the conjunctiva is to ensure no foreign body or object slips behind the eye, such as contact lenses.
Visit Your Local Oscar Wylee
Our team in-store can help you find your perfect fit. We have a wide range of glasses in different styles, sizes and colours.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
## What are the Eye Problems that can Affect the Conjunctiva?
There are many eye conditions and problems that can affect the conjunctiva, with the most common being conjunctivitis. Other conditions include pterygium, pinguecula, subconjunctival haemorrhage, chemosis, conjunctiva nevus and conjunctival lymphoma. These eye problems and their definitions are listed below.
* Pink eye (conjunctivitis): Conjunctivitis, also known as pink eye, is an eye condition characterised by inflammation or infection of the conjunctiva. The types of conjunctivitis include bacterial conjunctivitis, viral conjunctivitis and allergic conjunctivitis.
* Pterygium: A pterygium, also known as surfer’s eye, is a fleshy, triangular growth extending from the cornea of a person’s eye across the conjunctiva. Symptoms of this eye condition include dry eyes, reduced vision, mild pain and redness.
* Pinguecula: A pinguecula is a yellowish-raised, benign growth on the conjunctiva that may be caused by exposure to UV light.&nbsp; Symptoms of a pinguecula include itchy eyes, red eyes and dry eyes. While a pterygium and pinguecula both affect the conjunctiva, they are different eye conditions.
* Subconjunctival haemorrhage: A subconjunctival haemorrhage is a broken blood vessel in the eye that turns the white of the eye (sclera) red. The blood vessels are located under the conjunctiva which cannot absorb blood quickly leading to the eye becoming red.
* Chemosis: Chemosis is an eye irritation that causes the conjunctiva to look like a blister and that it has fluid in it. In severe cases of chemosis, the conjunctiva swells so much that a person is unable to close their eyes properly.
* Conjunctival nevus: A conjunctival nevus, according to the National Library of Medicine, is a benign, melanocytic tumour of the conjunctiva that is relatively common. It appears as slightly elevated lesions on the conjunctiva.
* Conjunctival lymphoma: Conjunctival lymphoma is a tumour found on the surface of the eye appearing as a pink, fleshy patch. Conjunctival lymphoma and other ocular surface tumours can be diagnosed using optical coherence tomography.
### Why do People Wear Glasses When They Have Conjunctivitis?
It is advised by optometrists for people to wear glasses instead of contact lenses when they have the eye condition conjunctivitis. Conjunctivitis is the inflammation, irritation or infection of the conjunctiva, causing symptoms such as tearing, red eyes, scratchy and stinging eyes, distorted vision and discharge in the eyes. A person should wear glasses instead of contacts if they have conjunctivitis as contact lenses may slow the healing process down and continuously irritate the eyes. Continuously taking the contacts in and out could spread the pink eye to the other eye or to the lens case.
## What are the Different Ways to Take Care of the Conjunctiva?
The different ways a person can take care of their conjunctiva include booking regular eye tests, practising good hygiene, staying hydrated, maintaining a healthy diet and avoiding smoking. These methods for taking care of the conjunctiva and their definitions are listed below.
* Book regular eye tests: Booking regular eye tests is an important part of caring for the conjunctiva and overall eye health. In an eye test, an optometrist can examine the conjunctiva for signs of eye diseases or problems.
* Practise good hygiene: Practising good hygiene by washing your hands regularly is beneficial for eye health as it reduces the risk of irritants entering the eye. It is also very important to practise good hygiene when handling contact lenses.
* Stay hydrated: Staying hydrated by drinking plenty of water can help you take care of your eyes and conjunctiva. Dehydration can cause the eyes to become dry, red, blurry and cause problems focusing.
* Maintain a healthy diet: Eating a healthy and balanced diet is beneficial for overall eye health including the conjunctiva. By eating well, you give your body the fuel it needs, helping to boost immunity and health.
* Avoid smoking: Smoking is very detrimental to a person’s overall health, including eye health as it has been shown to cause damage to the macula and the retina. Smoking is also linked to an increased risk of age-related macular degeneration.
### How do Optometrists Diagnose Conjunctiva-Related Problems?
Optometrists play a crucial role in diagnosing conjunctival conditions, by conducting eye tests. In the case of diagnosing conjunctivitis, the optometrist will ask about the patient's symptoms and examine the eye. According to Health Direct, an [optometrist](https://www.oscarwylee.com.au/eye-care/optometrist) may also take a sample of the discharge from the eye to test.
#### What is the Difference Between the Conjunctiva and the Sclera?
The difference between the conjunctiva and the sclera is their anatomy and function. The conjunctiva secretes mucus and tears to lubricate the eyes whereas the sclera maintains the shape of the eyeball. The conjunctiva is the membrane that covers the eyelids and the surface of the eye and the [sclera](https://www.oscarwylee.com.au/glasses/eye/anatomy/sclera) is the white part of the eye.
#### What is the Difference Between the Conjunctiva and the Cornea?
The difference between the conjunctiva and the cornea includes their function and anatomy. While the [cornea](https://www.oscarwylee.com.au/glasses/eye/cornea) is directly involved in vision, the main function of the conjunctiva is to protect the eyes from infections and keep the eyes lubricated. The cornea is the clear outer layer of the eye, covering the pupil, iris and anterior chamber and the conjunctiva covers the sclera and the inside of the eyelids.
Read Conjunctiva: Anatomy, Function, and Associated Eye Conditions in other Oscar Wylee regions and their languages.
Australia    
[Australia](https://www.oscarwylee.com.au/glasses/eye/anatomy/conjunctiva)
[Canada](https://oscarwylee.ca/glasses/eye/anatomy/conjunctiva)
[Canadian French](https://oscarwylee.ca/fr/glasses/eye/anatomy/conjunctiva)
Oscar Wylee Accepts Leading Health Funds In-Store
Visit our knowledgeable team in-store who can answer any questions about what your health fund may cover at Oscar Wylee.
[Explore Health Funds](https://www.oscarwylee.com.au/health-funds.html)
Are You Due For An Eye Test?
It is recommended that you have an eye test at least once every two years, or as otherwise advised by an optometrist.
[Book an eye test](https://www.oscarwylee.com.au/booking)