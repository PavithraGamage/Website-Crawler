# Source: https://www.oscarwylee.com.au/glasses/eye/rare-genetic-eye-diseases

# 20 Rare Genetic Eye Diseases
Published on April 29th, 2026
Australia
Australia
New Zealand
Canada
Canadian French

Rare genetic eye diseases are
conditions caused by gene mutations that can lead to vision loss.
Rare genetic
[eye diseases](https://www.oscarwylee.com.au/glasses/eye/health)
are often inherited, and symptoms may include progressive
night blindness, tunnel vision, or colour vision loss, depending on the
disease. Glasses and sunglasses can act as essential, non-invasive tools to
support people with rare genetic eye diseases, by potentially maximising
remaining vision, protecting against further damage, and addressing light
sensitivity. This article will detail 20 rare genetic eye diseases to inform
and raise awareness.
It is important to note that Oscar Wylee offers optometry services only;
this article is solely for educational purposes and is not a substitute
for professional medical advice, diagnosis, or treatment. Rare genetic
conditions are often complex and require multidisciplinary care from
ophthalmologists and geneticists.
Prioritise Your Eye Health
Our team can help you stay up to date with regular eye tests to keep your
eyes healthy!
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Causes](#causes)
[Symptoms](#symptoms)
[Diagnosis](#diagnosis)
[Vision Support Options](#vision-support)
[Treatment](#treatment)
## 1. Retinitis Pigmentosa
[Retinitis Pigmentosa](https://www.oscarwylee.com.au/glasses/eye/retinitis-pigmentosa)
is the name given to a
rare, inherited, and diverse group of eye disorders that affect the
[retina](https://www.oscarwylee.com.au/glasses/eye/anatomy/retina)
at the back of the eye, according to the Macular Disease Foundation Australia. Retinitis
Pigmentosa is considered a rare eye disease because it affects a
relatively small percentage of the global population. In Australia, it
is estimated that around 1 in 3000 people have the disease, equating to
about 8,900 individuals, according to Retina Australia.
## 2. Leber Congenital Amaurosis (LCA)
Leber Congenital Amaurosis (LCA) is an
inherited retinal disease that appears at birth or within the first
few months of life, according to Retina Australia. The severity of the condition varies,
but vision loss can occur in some cases. Leber Congenital Amaurosis
(LCA) is considered a rare eye disease because it affects only 2 to 3
per 100,000 newborns, or roughly 1 in 80,000 people, according to Retina
Australia. Combined, inherited retinal diseases affect around 1 in 4000
people or over 2 million people worldwide, according to the Centre for
Eye Research Australia.
## 3. Stargardt Disease
[Stargardt disease](https://www.oscarwylee.com.au/glasses/eye/stargardt-disease), also known as Stargardt dystrophy or fundus flavimaculatus, is a
genetic eye disease that causes dysfunction to the macula (the
central part of the retina), according to the Macular Disease Foundation Australia. Stargardt
Disease is considered a rare eye disease because it affects about 1 in
10,000 people, according to the Macular Disease Foundation Australia.
Find Your Nearest OW Store!
We've got knowledgeable teams who are passionate about delivering
high-quality care.
[Find a store](https://www.oscarwylee.com.au/locations)
## 4. Usher Syndrome
Usher syndrome (USH) is a
rare genetic condition that can affect vision, hearing, and sometimes
balance, according to the Centre for Eye Research Australia. Vision loss
associated with
[Usher syndrome](https://www.oscarwylee.com.au/glasses/eye/usher-syndrome)
is due to retinitis pigmentosa. Usher syndrome is considered a rare eye
disease because it affects only 4 to 17 per 100,000 people globally,
according to the National Institutes of Health.
## 5. Choroideremia
Choroideremia is an X-linked
inherited retinal disease, meaning that males are more commonly
affected, according to Retina Australia. Choroideremia is considered a rare eye
disease because it affects a small percentage of the population,
approximately 1 in 50,000 people, according to M. Brambati, E. Borelli,
R. Sacconi, F. Bandello, and G. Querques's research article titled
'Choroideremia: Update On Clinical Features And Emerging Treatments',
published in 2019.
## 6. Aniridia
[Aniridia](https://www.oscarwylee.com.au/glasses/eye/aniridia)
is the
partial or complete absence of the
[iris](https://www.oscarwylee.com.au/glasses/eye/anatomy/iris), according to K. Tripathy and B. Salini's research paper titled
'Aniridia', published in 2019. Aniridia is a
rare, genetic eye disorder. Aniridia is considered a
rare eye condition because it occurs in approximately 1 in 40,000
newborns worldwide, according to the National Organisation for Rare
Disorders.
## 7. Achromatopsia
Achromatopsia is a
rare inherited disease that affects the cone photoreceptors, according to Retina Australia. Achromatopsia is considered a very
rare eye disease because it affects approximately 1 in 30,000 people
around the world, or about 880 people in Australia, according to Retina
Australia.
## 8. Genetic Optic Atrophy
Genetic optic atrophy
results from degeneration or damage to the
[optic nerve](https://www.oscarwylee.com.au/glasses/eye/anatomy/optic-nerve), which transports visual information from the eye to the
brain, according to Vision Australia. Genetic optic atrophy is generally
considered to be a rare eye disease, and its prominence depends on the
underlying cause of the condition.
## 9. Best Disease (Best Vitelliform Macular Dystrophy)
Best Disease (Best Vitelliform Macular Dystrophy) is an
inherited eye disorder that can cause progressive vision loss, according to the Macular Disease Foundation Australia. Best Disease
is considered a rare eye condition, as it is estimated to affect between
1 in 10,000 and 1 in 21,000 people, according to the National Institutes
of Health.
## 10. Bardet-Biedl Syndrome
Bardet-Biedl Syndrome (BBS) is an
inherited retinal disease that affects several parts of the
body, according to Retina Australia. Bardet-Biedl Syndrome is considered a
rare syndrome, affecting an estimated 1 in 160,000 newborns in North
America and Europe, and similar numbers are estimated in Australia.
Find Your Nearest OW Store!
We’ve got knowledgeable teams who are passionate about delivering
high-quality care.
Find a store

## 11. Cone-Rod Dystrophy
[Cone-Rod Dystrophy](https://www.oscarwylee.com.au/glasses/eye/cone-rod-dystrophy)
is
a group of genetic or inherited eye diseases that affect the retina
and can cause vision loss, according to the Centre for Eye Research Australia. Cone-rod
dystrophy is considered a rare eye disease, affecting an estimated 1 in
30,000 to 40,000 individuals, according to the National Institutes of
Health.
## 12. Juvenile X-Linked Retinoschisis
Juvenile X-linked retinoschisis is
a rare inherited retinal disease that primarily affects young boys
and young men, according to Retina Australia. Juvenile X-linked retinoschisis is
considered a rare eye disease because it affects approximately 1 in
5,000 to 25,000 people worldwide, according to Retina Australia.
## 13. Norrie Disease
Norrie Disease is
a rare, genetic condition that causes congenital blindness
(significant vision loss or total blindness present at birth),
progressive hearing loss, and sometimes, developmental delays, according to the Norrie Disease Foundation Australia. Norrie Disease
is considered a rare eye disease because it is estimated to affect
approximately 1 in 100,000 people, primarily males, due to its X-linked
inheritance pattern.
## 14. Ocular Albinism
Ocular albinism is
a rare, inherited genetic condition that mainly affects the
pigmentation of the eyes and can cause low vision, according to Vision Australia. Ocular albinism is X-linked, making it
a lot less common in women. Ocular albinism is considered a rare
condition, affecting about 1 in every 50,000 to 60,000 men.
## 15. Primary Congenital Glaucoma
[Primary congenital glaucoma](https://www.oscarwylee.com.au/glasses/eye/glaucoma/childhood-glaucoma)
is
a rare type of childhood glaucoma caused by abnormal development of
the eye's draining system, leading to increased intraocular
pressure, according to K. Kaur, M. Zeppieri, and B. Gurnani's research paper
titled 'Primary Congenital Glaucoma', published in 2024. Primary
congenital glaucoma is considered to be a rare disease, affecting
approximately 1 in 5,000 to 10,000 children under 2.
## 16. Congenital Cataracts
[Congenital cataracts](https://www.oscarwylee.com.au/glasses/eye/childhood-cataracts)
are
a condition in which the
[lens](https://www.oscarwylee.com.au/glasses/eye/anatomy/crystalline-lens)
inside the eye is cloudy instead of clear, according to the Sydney Children's Hospitals Network. Babies may be
born with cataracts, or they may develop cataracts in the first year of
life, according to the Sydney Children's Hospitals Network. Congenital
cataracts are considered a rare condition, affecting approximately 1 to
15 per 10,000 live births worldwide.
## 17. Microphthalmia
Microphthalmia is
a rare congenital developmental eye disorder, according
to P. Harding, D. L. Cunha, and M. Moosajee's research paper titled
'Animal and cellular models of microphthalmia', published in 2021.
Microphthalmia is rare, affecting approximately 1 in 7000 births,
according to P. Harding, D. L. Cunha, and M. Moosajee.
## 18. Coloboma
Colobomas are
congenital ocular defects that may affect the iris, the lens, the
[choroid](https://www.oscarwylee.com.au/glasses/eye/choroid), the retina, and the optic nerve, according to S. Vegunta and B. C. Patel's research paper titled
'Optic Nerve Coloboma', published in 2023. Coloboma is rare, affecting
approximately 1 in every 10,000 births.
## 19. Keratoconus
[Keratoconus](https://www.oscarwylee.com.au/glasses/eye/keratoconus)
is
a progressive corneal disorder that may involve cone-like steepening
of the cornea, irregular stromal (tissue) thinning, and significant
vision loss, according to G. Asimellis and E. J. Kaufman's research paper titled
'Keratoconus', published in 2024. Keratoconus used to be considered a
rare disorder, with estimates published as 1 in every 2000 people in the
general population in the 1980s, according to Keratoconus Australia.
However, improved screening techniques now indicate it may be as high as
1 in every 750 people worldwide, according to Keratoconus Australia.
While historically rare, it is now considered a relatively common
corneal dystrophy in modern optometry. Keratoconus still requires
specialised monitoring, even if its prevalence is higher than previously
thought.
## 20. Familial Exudative Vitreoretinopathy (FEVR)
Familial Exudative Vitreoretinopathy (FEVR) is
an inherited disorder involving deficient vascularisation (the
biological process where tissues or organs develop blood vessels) of
the peripheral retina, which leads to retinal ischemia, according to J. R. Luvisi and K. Blair's research paper titled
'Familial Exudative Vitreoretinopathy (FEVR)', published in 2025.
Familial Exudative Vitreoretinopathy is considered to be a rare
disorder, and its prevalence is currently unknown at the time of
writing.
### How are Rare Genetic Eye Diseases Defined in Ophthalmology?
Rare genetic eye diseases are defined as
inherited or gene-related disorders that affect eye structure or
function and occur in a small percentage of the population
in ophthalmology. They often involve retinal, corneal, or optic nerve
abnormalities that lead to vision impairment. In ophthalmology, they
are defined by low prevalence and genetic origin,
often requiring specialised diagnosis and care.
#### Are Rare Genetic Eye Diseases Always Inherited?
No,
rare genetic eye diseases are not always inherited,
according to the Prevent Blindness Organisation. Rare genetic eye
diseases are caused by DNA mutations, but sometimes these changes
can occur spontaneously in a patient, meaning neither of their
parents carries the gene.
## What Causes Rare Genetic Eye Diseases?
Rare genetic eye diseases are
mainly caused by mutations or changes in one or more genes that are
responsible for the structure or function of the eye, according to the Centre for Eye Research Australia. The causes of
rare genetic eye diseases vary case by case, but may include
gene mutations, inherited genetic defects, new genetic mutations,
chromosomal abnormalities, disruption of retinal cell function,
defects in cellular structures, errors in visual signal processing
pathways, abnormal eye development, and rare multifactorial gene
interactions. These possible causes of rare genetic eye diseases are explained
below.
* Gene mutations affecting retinal or eye development: Gene mutations affecting retinal or eye development can be described
as 'mistakes' in one or more genes that are essential for the correct
structure, function, and development of retinal cells, according to
Retina Australia.
* Inherited genetic defects: Inherited
genetic defects in the DNA that affect the structure or function of
retinal or optic nerve cells are the primary cause of rare genetic eye
diseases. Inherited genetic defect patterns include autosomal
dominant, autosomal recessive, X-linked, and mitochondrial
inheritance.
* New (de novo) genetic mutations: New
(de novo) genetic mutations can cause rare genetic diseases in the
same way inherited genetic mutations do, by disrupting retinal or
optic nerve cells, according to Retina Australia.
* Chromosomal abnormalities: Chromosomal
abnormalities, specifically deletions, duplications, and
rearrangements, physically disrupt, remove, or duplicate genes that
are essential for normal eye development and function, according to M.
Mihelec's research paper titled 'Chromosomal rearrangements and novel
genes in disorders of eye development, cataract and glaucoma',
published in 2008.
* Disruption of retinal cell function: Disruption of retinal cell function happens when there are faults or
variants in genes, leading to progressive degeneration of
photoreceptors (rods and cones) and the retinal pigment epithelium
(RPE), ultimately leading to significant vision loss, according to H.
Chawla, K. Tripathy, and V. Vohra's research paper titled 'Retinal
Dystrophies', published in 2024.
* Defects in cellular structures like cilia: Defects in cellular structures like cilia often cause rare genetic
eye diseases, which are known specifically as ocular ciliopathies,
according to M. Shivanna, M. Anand, S. Chakrabarti, and H. Khanna’s
research paper titled ‘Ocular Ciliopathies: Genetic and Mechanistic
Insights into Developing Therapies’, published in 2020. This happens
when genes are mutated that affect the formation, maintenance, or
function of cilia, which are microscopic, hair-like structures found
on the surface of most cells, according to H. May-Simera, K.
Nagel-Wolfrum, and U. Wolfrum’s research paper titled ‘Cilia - The
sensory antennae in the eye’, published in 2017.
* Errors in visual signal processing pathways: Errors in visual signal processing pathways can cause rare genetic
eye diseases, referring to genetic errors that can specifically
disrupt the visual signal processing pathways, which leads to the
death of photoreceptor cells (rods and cones) and possible vision
loss, according to H. Chawla, K. Tripathy, and V. Vohra's research
paper titled 'Retinal Dystrophies', published in 2024.
* Abnormal eye development during embryonic growth: Abnormal eye development during embryonic growth can cause rare
genetic eye diseases, as mutations in genes can disturb the eye
formation process, according to the Fight for Sight Organisation.
* Rare multifactorial gene interactions: Rare multifactorial gene interactions can cause rare genetic eye
diseases, which involve rare genetic mutations, complex interactions
between multiple genes, and environmental or lifestyle influences. The
relative contribution of environmental factors is recognised but
currently unknown, according to A. Gordon-Shaag, M. Millodot, E.
Shneor, and Y. Liu's research paper titled 'The Genetic and
Environmental Factors for Keratoconus', published in 2015.
### Which Gene Mutations Lead to Rare Eye Conditions?
Rare genetic eye conditions are caused by mutations in over 300
different genes, according to Retina Australia. Key mutations
include genes such as RPE65, ABCA4, RPGR, RP2, and USH2A, according to Retina Australia. These genes are essential for
retinal cell function and visual processing. Different mutations
produce different conditions and severity levels, and differ widely
depending on the condition.
#### Can a Single Mutation Cause Severe Vision Loss?
Yes,
a single gene mutation can cause severe vision loss. Some mutations strongly disrupt retinal function or eye
structure, which can lead to early-onset or rapidly progressive
visual impairment.
Find Your Nearest OW Store!
We've got knowledgeable teams who are passionate about delivering
high-quality care.
[Find a store](https://www.oscarwylee.com.au/locations)
## What Symptoms do Rare Genetic Eye Diseases Cause?
The symptoms of rare genetic eye diseases are varied and are different
depending on the disease, but commonly
include gradual or sudden vision loss, night blindness, tunnel
vision, blurred or distorted vision, blind spots, light sensitivity,
colour vision problems, eye pain or discomfort, rapid eye movements,
crossed or misaligned eyes, poor depth perception, difficulty focusing
or tracking objects, vision loss present from birth or early
childhood, progressive worsening of vision over time, and floaters or
visual distortions. A list of the symptoms that may be caused by rare genetic eye
diseases can be read below.
* Gradual or sudden vision loss: Gradual
or sudden
[vision loss](https://www.oscarwylee.com.au/glasses/eye/visual-impairment)
is common in rare genetic eye diseases, often involving a slow,
progressive decline in vision.
* Night blindness: [Night blindness](https://www.oscarwylee.com.au/glasses/eye/night-blindness)
is a common symptom caused by retinitis pigmentosa, including
difficulty seeing in dim environments and tunnel vision.
* Tunnel vision (loss of peripheral vision): Tunnel vision, or loss of peripheral vision, is a common symptom of
retinitis pigmentosa. This involves deterioration of, or complete loss
of 'side' vision.
* Blurred or distorted vision: Blurred
or distorted vision is a symptom of rare genetic eye diseases,
involving blurry spots or wavy vision.
* Blind spots in central or peripheral vision: Blind spots in central or peripheral vision are associated with rare
genetic eye diseases, involving progressive blind areas in central
and/or peripheral vision.
* Light sensitivity (photophobia): [Light sensitivity](https://www.oscarwylee.com.au/glasses/eye/light-sensitivity), or photophobia, is commonly associated with rare genetic eye
diseases. Light sensitivity is defined as an abnormal sensitivity to
light, according to K. B. Digre and KC. Brennan's research paper
titled 'Shedding Light on Photophobia', published in 2013.
* Colour vision problems: Colour vision
problems are a symptom of rare genetic diseases, which are described
as a reduced perception of colour, according to Vision Australia.
* Eye pain or discomfort: Eye pain or
discomfort is a symptom of some rare genetic conditions. Eye pain or
discomfort can include chronic aching, stabbing, or throbbing pain.
* Rapid eye movements (nystagmus): Rapid
eye movements, or
[nystagmus](https://www.oscarwylee.com.au/glasses/eye/nystagmus), are associated with some rare genetic eye diseases. Rapid eye
movements are rapid, involuntary eye movements that cause the eyes to
flicker, according to Vision Australia.
* Crossed or misaligned eyes (strabismus): Crossed or misaligned eyes, or
[strabismus](https://www.oscarwylee.com.au/glasses/eye/crossed-definition), is a symptom of some rare genetic eye diseases. Strabismus is
classified by how the eyes align relative to each other, according to
M. M. Sanchez and M. C. Whitman's research paper titled 'Genetics of
strabismus', published in 2023. One eye could be fixated, and the
other eye can deviate inwards, outwards, or vertically, according to
M. M. Sanchez and M. C. Whitman.
* Poor depth perception: Poor depth
perception is a common symptom of rare genetic eye diseases. Poor
depth perception refers to the reduced ability to judge changes in
surface levels, according to the Centre for Eye Research Australia.
* Difficulty focusing or tracking objects: Difficulty focusing or tracking objects is a side effect of rare
genetic eye diseases, involving farsightedness, difficulty or
inability to focus on close objects, and impaired ability to track
moving objects, often caused by nystagmus or strabismus.
* Vision loss present from birth or early childhood: Vision loss present from birth or early childhood is a symptom of
rare genetic eye diseases that manifest in early childhood.
* Progressive worsening of vision over time: Progressive worsening of vision over time is a primary symptom of
rare genetic eye diseases, according to Retina Australia. Progressive,
gradual worsening of vision over time can result in significant visual
impairment, and sometimes, legal blindness, according to Retina
Australia.
* Floaters or visual distortions: [Floaters](https://www.oscarwylee.com.au/glasses/eye/floaters-definition)
or visual distortions are a symptom present in some retinal disorders.
Eye floaters are characterised by small moving spots that appear in
the field of vision, according to the Better Health Channel, Victoria.
Visual distortions are commonly seen as wavy lines in the field of
vision.
If you are experiencing any of the above symptoms, it is important to
consult an optometrist or other medical professional for proper care
and advice.
### How do Vision Problems Develop in Rare Eye Conditions?
Vision problems in rare genetic eye conditions
develop gradually or are present from birth, depending on the
mutation. Retinal cells or components of the optic pathways may progressively
dysfunction over time, which can lead to worsening visual clarity
and/or visual field loss.
#### Are Early Symptoms Easy to Miss in Genetic Eye Disorders?
Yes, early symptoms are often easy to miss in
genetic eye disorders. Initial symptoms such as mild night blindness
or blurred vision can be subtle and hard to notice. Many patients
are diagnosed only after noticeable progression. Because these early
changes are gradual, many patients are not diagnosed until the
condition has progressed further, according to N. Cross, C. van
Steen, Y. Zegaoui, A. Satherley, and L. Angelillo's research paper
titled 'Retinitis Pigmentosa: Burden of Disease and Current Unmet
Needs', published in 2022.
## How are Rare Eye Diseases Diagnosed?
Rare eye diseases are diagnosed using
[eye tests](https://www.oscarwylee.com.au/eye-care/eye-test), imaging tests, and genetic testing. A standard eye test is the first step in detecting rare genetic eye
diseases, but they often require further testing, including imaging
tests and genetic testing. Key imaging tests include
[Optical Coherence Tomography (OCT)](https://www.oscarwylee.com.au/glasses/eye/oct-fundus-test), Fundus Autofluorescence (FAF), and
[Fluorescein Angiography](https://www.oscarwylee.com.au/glasses/eye/fluorescein-angiography). Patients will often be asked about their general health, and if
anyone in their family has vision problems, according to the Centre for
Eye Research Australia. In these tests, retinal structure and visual
function can be tested. Genetic testing involves having a small blood or
saliva sample collected and sent to a laboratory, according to the
Centre for Eye Research Australia. Often, a combination of tests can
confirm the exact condition a patient has.
Optometrists can detect signs of rare eye diseases during an eye
test, but may refer you to an ophthalmologist for a definitive
diagnosis.
Oscar Wylee provides primary eye care and optical solutions; medical
or surgical treatments for genetic eye diseases must be managed by
specialist medical practitioners. To learn more about Oscar Wylee eye
tests, visit our
[eye test](https://www.oscarwylee.com.au/glasses/eye/check-up)
page or book an eye test
[here](https://www.oscarwylee.com.au/booking).
### What Tests are Used to Detect Rare Eye Disorders?
The tests used to detect rare eye disorders are
varied, and include comprehensive eye tests, visual acuity tests,
slit-lamp examinations, dilated fundus examinations, optical
coherence tomography (OCT), fundus photography, fluorescein
angiography, electroretinography (ERG), electrooculography (EOG),
visual field testing, colour vision testing, genetic testing,
corneal topography, ultrasound of the eye, and magnetic resonance
imaging (MRI) or CT scans.
A list of the tests that may be used to detect rare genetic eye
diseases can be read below.
* Comprehensive eye tests: Comprehensive eye tests involve specialised imaging and functional
testing to detect rare genetic eye diseases, according to the
Macular Disease Foundation Australia.
* Visual acuity test: [Visual acuity tests](https://www.oscarwylee.com.au/glasses/eye/test/visual-acuity)
are usually a starting point for rare genetic disease detection,
measuring central vision clarity. Visual acuity tests are also known
as eye chart tests, and are only one part of a comprehensive
ophthalmologic examination, according to H. F. Dalber and D. M.
Gnugnoli’s research paper titled ‘Visual Acuity’, published in 2023.
* Slit-lamp examination: A
[slit-lamp examination](https://www.oscarwylee.com.au/glasses/eye/slit-lamp-exam)
is a fundamental test to detect a range of rare eye disorders, as it
provides a 3D, cross-sectional view of the structure of the eye.
* Dilated fundus examination: A
[dilated fundus examination](https://www.oscarwylee.com.au/glasses/eye/dilated-pupil-exam)
is an integral part of a comprehensive eye examination. A dilated
fundus examination can detect, diagnose, and monitor rare eye
disorders by providing a view of the back of the eye, including the
retina, optic nerve, and macula.
* Optical coherence tomography (OCT): Optical coherence tomography is a non-invasive technique for
cross-sectional tissue imaging, according to S. Aumann, S. Donner,
J. Fischer, and F. Müller’s book titled ‘High Resolution Imaging in
Microscopy and Ophthalmology: New Frontiers in Biomedical Optics’,
published in 2019. Optical coherence tomography is a foundational
test in detecting and monitoring several rare genetic eye diseases.
* Fundus photography: Fundus
photography takes an image of the retina, optic nerve head, macula,
retinal blood vessels, choroid, and the vitreous, according to C.
Mishra and K. Tripathy’s research paper titled ‘Fundus Camera’,
published in 2023.
* Fluorescein angiography: Fluorescein
angiography refers to an invasive diagnostic procedure that helps
assess retinal and choroidal circulation, according to S. Ruia and
K. Tripathy's research paper titled 'Fluorescein Angiography',
published in 2023.
* Electroretinography (ERG): Electroretinography is a test used to assess the retina in eye
diseases, according to D. J. Creel's book titled 'Webvision: The
Organisation of the Retina and Visual System', published in 2015.
* Electrooculography (EOG): Electrooculography is a test that measures the resting electrical
potential between the cornea and the retina, specifically testing
how the retinal pigment epithelium (RPE) is functioning.
* Visual field testing: [Visual field testing](https://www.oscarwylee.com.au/visual_field.html)
is used to measure how well a patient can see throughout visual
space, according to Glaucoma Australia.
* Colour vision testing: [Colour vision testing](https://www.oscarwylee.com.au/glasses/eye/test/colour-vision-test)
is a non-invasive method that can aid in diagnosing rare genetic eye
diseases. Colour vision testing involves a variety of tests,
including checking for blue-yellow defects and red-green defects.
* Genetic testing: Genetic testing is
the primary method to confirm a rare genetic eye disease. It
involves analysing a patient's DNA through a blood or saliva sample,
according to C. Méjécase's research paper titled 'Practical guide to
genetic screening for inherited eye diseases', published in 2020.
* Corneal topography: Corneal
topography is a non-invasive imaging test that maps the cornea and
is an important tool for corneal-related disorders.
* Ultrasound of the eye: Ultrasound of
the eye, or an ocular ultrasound, is a non-invasive imaging test
that visualises the eye's interior.
* Magnetic resonance imaging (MRI) or CT scan: Magnetic resonance imaging (MRI) or CT scans are an important tool
for detecting rare genetic eye diseases, particularly their
structural or neurological cause.
Oscar Wylee provides primary eye care and optical solutions;
medical or surgical treatments for genetic eye diseases must be
managed by specialist medical practitioners. To learn more about
Oscar Wylee eye tests, visit our
[eye test](https://www.oscarwylee.com.au/glasses/eye/check-up)
page or book an eye test
[here](https://www.oscarwylee.com.au/booking).
#### Is Genetic Testing Required for Rare Eye Disease Diagnosis?
Genetic testing is not always strictly 'required' for an initial
clinical diagnosis of a rare eye disease, but
it has become a critical standard of care for the definitive
diagnosis and management
of rare genetic eye diseases, according to D. Mustafi, F. M. Hisama,
J. Huey, and J. R. Chao's research paper titled 'The current state
of genetic testing platforms for inherited retinal diseases',
published in 2023.
## What Vision Support Options are Available for Rare Genetic Eye Diseases?
There are various vision support options available for patients with
rare genetic eye diseases. These vision support options
include prescription glasses or specialised lenses, high-powered
magnifiers, electronic magnification devices, screen readers and
text-to-speech software, Braille devices and Braille displays,
large-print books and materials, smartphone accessibility features,
adaptive lighting and high-contrast settings, mobility aids, low
vision rehabilitation therapy, occupational therapy for daily living
skills, tinted lenses or filters for light sensitivity, adaptive
devices for writing, reading, and daily tasks, vision assistance apps,
and support services and counselling for visual impairment
adaptation. A list of vision support options available for patients with rare
genetic eye diseases can be read below.
* Prescription glasses or specialised lenses: Prescription glasses or specialised lenses can help support patients
with rare genetic diseases. Prescription glasses can improve clarity
and reduce visual strain, optimising remaining vision; however, they
can not correct vision loss from these conditions. Specialised lenses,
such as magnifying spectacles and telescopic glasses, can
significantly aid in daily functioning for patients with rare genetic
eye diseases.
* High-powered magnifiers: High-powered
magnifiers, including handheld or stand magnifiers, are designed to
maximise remaining vision in several rare genetic eye diseases,
according to the Macular Disease Foundation Australia. High-powered
magnifiers are commonly used by patients with rare genetic eye
diseases such as retinitis pigmentosa and ocular albinism.
* Electronic magnification devices: Electronic magnification devices can support patients with rare
genetic eye diseases, as they can zoom in with the click of a button,
according to Vision Australia. Electronic magnification devices are
especially useful for people using computers, according to the Macular
Disease Foundation Australia.
* Screen readers and text-to-speech software: Screen readers and text-to-speech software are assistive technologies
that can support patients with rare genetic eye diseases. Screen
readers allow users to navigate computer operating systems more
easily, according to the Australian Disability Clearinghouse on
Education and Training. Text-to-speech software, or screen reading
systems, consist of a voice synthesiser and a screen reading program,
according to Vision Australia.
* Braille devices and Braille displays: Braille devices and Braille displays include Braille embossers,
Braille translation software, and electronic or refreshable Braille
displays, which can help patients with rare genetic eye diseases with
low vision or blindness and can read Braille on access computers,
according to Vision Australia.
* Large-print books and materials: Large-print books and materials are specialised resources to help
support patients with rare genetic eye diseases, including converted,
accessible documents to make reading easier.
* Smartphone accessibility features: Smartphone accessibility features are beneficial for patients with
rare genetic eye diseases experiencing low vision or blindness,
according to Vision Australia. These accessibility features include
keypad buttons that make a noise when pressed, display settings
allowing improved contrast, and speed dials for commonly used numbers,
according to Vision Australia.
* Adaptive lighting and high-contrast settings: Adaptive lighting and high-contrast settings are key supports for
daily function for people with rare genetic eye diseases, according to
the Centre for Eye Research Australia. Adaptive lighting refers to
enhanced lighting, glare management, and lighting tools for patients.
High-contrast settings are tools such as electronic video magnifiers
(CCTVs) and apps that allow increased contrast, as well as general use
of bold-lined paper and high-contrast kitchen items for everyday use.
* Mobility aids: Mobility aids offer
vision support for patients with rare genetic eye diseases through
tools such as white canes, guide dogs, electronic travelling aids
(ETAs), and sighted guides.
* Low vision rehabilitation therapy: 
Low vision rehabilitation therapy for patients with rare genetic eye
diseases focuses on maximising remaining vision and maintaining
independence, according to Vision Australia. Low vision rehabilitation
therapy involves assistive technology training, optical devices,
orientation and mobility training, visual training, daily living
skills training, and counselling and support groups.
* Occupational therapy for daily living skills:
Occupational therapy for daily living skills provides new strategies
and different methods of completing daily tasks for people who have
low vision or blindness, according to the Better Health Channel,
Victoria.
* Tinted lenses or filters for light sensitivity: [Tinted lenses](https://www.oscarwylee.com.au/glasses/eye/types-of-lenses)
or filters for light sensitivity are important tools to manage light
sensitivity symptoms experienced by some patients with rare genetic
diseases, such as Retinitis Pigmentosa, Stargardt disease, and
Aniridia. Tinted lenses or filters help to enhance contrast and reduce
glare.
* Adaptive devices for writing, reading, and daily tasks: Adaptive devices for writing, reading, and daily tasks involve tools
such as electronic video magnifiers (CCTVs), signature and writing
guides, and household aids, designed to maximise remaining vision for
some patients with rare genetic eye diseases.
* Vision assistance apps: Vision
assistance apps include AI and remote assistance apps, navigation and
environmental apps, and reading and identification apps to support
patients with rare genetic eye diseases.
* Support services and counselling for visual impairment adaptation: Support services and counselling for visual impairment adaptation are
a key resource with patients with rare genetic eye diseases. Whether
patients completely lose their sight or are blind, support services
are available to help individuals and families cope, according to
Retina Australia.
### How can Prescription Glasses Help Manage Vision Problems Caused by
Rare Eye Conditions?
[Prescription glasses](https://www.oscarwylee.com.au/glasses/prescription)
can improve clarity and reduce visual strain, optimising remaining
vision
in rare genetic eye conditions. However, prescription glasses can not
cure the disease; instead, they may help to improve daily visual
performance.
#### Can Updated Lenses Improve Daily Vision Comfort?
Yes,
[updated lenses](https://www.oscarwylee.com.au/glasses/eye/types-of-lenses)
may improve daily visual comfort. Updated lenses,
correct to an updated prescription,
correct
[refractive errors](https://www.oscarwylee.com.au/glasses/eye/refractive-errors), and enhance clarity. This reduces eye strain and maximises remaining vision.
## How can Glasses Support People With Rare Genetic Eye Diseases?
[Glasses](https://www.oscarwylee.com.au/) can support vision
in patients with rare genetic eye diseases
by enhancing focus, contrast, and clarity. Glasses can
help people perform daily tasks more easily. It is important to remember
that they are part of broader low vision management. Specialised glasses
and low-vision aids can improve the quality of life for patients with
rare genetic eye diseases, because they help maximise remaining vision,
enhance contrast, and reduce light sensitivity. While prescription
glasses cannot halt the progression of genetic diseases, they are
essential for optimising functional vision.
### How can Sunglasses Support People With Rare Genetic Eye Diseases?
[Sunglasses](https://www.oscarwylee.com.au/glasses/eye/sunglasses)
can
reduce glare and protect sensitive eyes from bright light, which can support people with rare genetic diseases. Sunglasses can
improve comfort in outdoor environments, which is
especially helpful for patients who experience light sensitivity as a
result of their condition.
## What is the Treatment for Rare Genetic Eye Diseases?
The treatment options for rare genetic diseases differ widely depending
on the specific condition, but
include gene therapy, retinal gene replacement therapy,
pharmacological treatments, anti-VEGF injections, retinal implants or
bionic eye devices, stem cell therapy, surgery, management of
associated conditions, and clinical trial participation for emerging
therapies. A list of possible treatment options for rare genetic diseases can be
read below.
* Gene therapy: Gene therapy is
available as a treatment for patients with specific inherited retinal
diseases. Gene therapy is available as a broad range of treatment
methods, including retinal gene replacement therapy.
It is important to note that gene therapy is an emerging,
specialist treatment.
* Retinal gene replacement therapy: Retinal gene replacement therapy can treat rare genetic eye diseases
by the delivery of a functional gene to retinal cells via subretinal
injection, according to R. Jain and S. Daigavane's research paper
titled 'Advances and Challenges in Gene Therapy for Inherited Retinal
Dystrophies: A Comprehensive Review', published in 2024.
It is important to note that gene therapy is an emerging,
specialist treatment.
* Pharmacological treatments: Pharmacological treatments for patients with rare genetic eye
diseases include eye drops and oral medications to manage symptoms.
* Anti-VEGF injections: Anti-VEGF
(anti-vascular endothelial growth factor) injections can stop the
growth of abnormal blood vessels and fluid leakage, which is
beneficial for some retinal conditions, according to the Macular
Disease Foundation Australia.
* Retinal implants or bionic eye devices: Retinal implants or bionic eye devices give patients a ‘sense of
sight’, including lights and flashes that can help them navigate
spaces independently, according to the Centre for Eye Research
Australia. It is important to note that there may be limited
availability of these devices.
It is important to note that retinal implants are an emerging,
specialist treatment.
* Stem cell therapy: Stem cell therapy
is being explored for developing treatments for people with inherited
retinal diseases, including age-related macular degeneration,
Stargardt disease, and retinitis pigmentosa, according to Retina
Australia. There are no stem cell treatments currently available
commercially, according to Retina Australia.
* Surgery: Surgery for rare genetic eye
diseases involves surgical interventions for related complications
such as cataracts and retinal detachment, according to Retina
Australia.
* Management of associated conditions: Management of associated conditions related to rare genetic eye
diseases involves helping patients preserve vision and address
conditions such as hearing loss and neurological symptoms through
specialised interventions, according to the Centre for Eye Research
Australia.
* Clinical trial participation for emerging therapies: Clinical trial participation for emerging therapies involve patients
being involved in clinical trials that are exploring innovative
treatment approaches to rare genetic eye diseases, which are mostly
related to gene therapies and regenerative medicine, according to the
Fighting Blindness Foundation.
Oscar Wylee provides primary eye care and optical solutions; medical
or surgical treatments for genetic eye diseases must be managed by
specialist medical practitioners. To learn more about Oscar Wylee eye
tests, visit our
[eye exam](https://www.oscarwylee.com.au/glasses/eye/check-up)
page or book an eye test
[here](https://www.oscarwylee.com.au/booking).
It is important to note that Oscar Wylee offers optometry services
only; this article is solely for educational purposes and is not a
substitute for professional medical advice, diagnosis, or
treatment.
Read 20 Rare Genetic Eye Diseases in other Oscar Wylee regions and
their languages.
Australia
Australia
New Zealand
Canada
Canadian French

Experience High Quality Eyecare Services From Our Team
Book an appointment online with an Oscar Wylee optometrist today.
[Book an eye test](https://www.oscarwylee.com.au/booking)
Major Health Funds Accepted
In-store
For the purchase of frames and lenses, use your private health fund to
limit how much you pay from your own pocket.
[Health Funds](https://www.oscarwylee.com.au/health-funds.html)