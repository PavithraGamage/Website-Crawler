# Source: https://www.oscarwylee.com.au/glasses/eye/uv-400-protection

# UV400 Protection: How It Works, Types and Materials
Published on October 1st, 2024
Updated on Month Date, 2025 
Australia
[Australia](https://www.oscarwylee.com.au/glasses/eye/uv-400-protection)
New Zealand

[Canada](https://oscarwylee.ca/glasses/eye/uv-400-protection)
Canadian French

UV400 protection
refers to lens features, often a coating or built into a lens, that
protects the eyes from UV rays up to 400 nanometres (nm). UV400 protection is important as UV light can be harmful to the eyes if
they are exposed to it for prolonged periods. UV light can cause eye issues
such as cataracts, eye cancers such as ocular melanoma and eye growths such
as pinguecula. The benefits of UV400 protection is that it acts as a barrier
between the eyes and UV light, helping to prevent these issues. UV400
protection can be applied to most lens types, including optical lenses and
sunglasses lenses. Lenses that are photochromic, polarised or tinted will
also typically have UV400 protection. At Oscar Wylee, all of our lenses come
with UV400 protection. Keep reading to learn more about UV400 protection.
Book an Oscar Wylee Eye Test
We recommend that everyone should have an eye test with an optometrist at
least once every 2 years.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Definition](#Definition)
[How They Work](#How-They-Work)
[UV vs Lens Categories](#UV-vs-Lens-Categories)
[Benefits](#Benefits) [Lens Types](#Lens-Types)
[Health Risks](#Health-Risks)
## What is UV400 Protection?
UV400 protection refers
to a lens feature that protects the eyes from UV rays up to 400
nanometres (nm). UV light, also known as Ultraviolet light or radiation, is a type of
light emitted from the sun. UV light can be harmful to the eyes if a
person is exposed to it for extended periods of time. Extended exposure
to UV can lead to eye growths, cataracts and potentially cancer.
According to the Cancer Council, UV light is also responsible for 95% of
skin cancers. UV400 protection helps to protect the eyes against this
potentially harmful UV light. UV400 can be a coating applied to a lens,
or embedded within the lens.
### How does UV400 Protection Work?
UV400 protection
works by acting as a barrier between the eyes and UV light of up to
400 nanometres. A UV400 lens coating will contain a thin layer of chemicals that
help to either block, absorb or reflect UV radiation, preventing it
from hitting the eye.
### Why is UV400 Protection Important for Eyewear?
UV400 is
an important coating to have for eyewear as it helps to prevent UV
light from hitting the eye directly. UV light or radiation can be dangerous for the eyes if they are
exposed to it for extended periods of time. Eyewear that does not have
UV400 protection will not be as effective in protecting the eyes.
## Is UV 400 Protection Different to the Protection Outlined in Sunglasses
Lens Categories?
The difference between UV400 protection and the protection offered by
sunglasses as outlined in lens categories standards, is that
lens categories refer to shades of lens tint and protection from
sunglare. In contrast, UV protection is concerned with UV rays. The different sunglass categories are governed by mandatory standards
set out in the
Consumer Goods (Sunglasses and Fashion Spectacles) Safety Standard
2017. The categories include Category 0, Category 1, Category 2, Category 3
and Category 4, referring to the level of tint on sunglass lenses, which
helps protect the eyes from sunglare and brightness, not necessarily
providing UV protection. It is important to note that the primary purpose of lens tint is to
aid with protection from the sun’s brightness and glare. This means lens
shade does not necessarily equate to UV protection. UV protection refers
to protection from UV rays specifically, including UVA and UVB. UV400
protection will protect the eyes from UV rays. It is generally
recommended to use category 2 or 3 sunglasses when you are out in direct
sunlight.
## What are the Benefits of Wearing Sunglasses with UV400 Protection?
The benefit of wearing sunglasses with UV400 protection
is that they protect the eyes from potentially damaging UV light.
UV light can cause eye issues such as cataracts, eye cancers such as
ocular melanoma and eye growths if the eyes are exposed to it for
prolonged periods of time.
[Sunglasses](https://www.oscarwylee.com.au/glasses/eye/sunglasses)
with UV400 protection help to act as a barrier between the eyes and UV
rays of up to 400 nanometres.
### How Can You Tell If Your Sunglasses Have UV400 Protection?
The best way to know if your sunglasses have UV400 protection
is to ask the retailer or optometry company you are buying the
frame from. As UV400 protection can be applied to the lens as a coating or
embedded in the lens, it would be hard for someone to tell whether
they have UV400 protection just by sight.
#### Do Safety Glasses Block UV?
Yes,
most safety glasses should block UV light. Safety glasses refer
to a range of protective eyewear that are worn to protect the
eyes. Safety glasses can be designed in different ways, and made from
different materials, depending on what they are being worn for.
Generally, safety glasses for most occupations or purposes should
have some level of
[UV protection](https://www.oscarwylee.com.au/glasses/eye/uv-blocking). A person may wear safety glasses whilst working outside to
protect their eyes from the sun and debris. A person is also
generally required to wear safety glasses if working in welding. As
welders tend to work with infrared and ultraviolet light, it is
especially important that safety glasses have a high level of UV
protection to protect the eyes.
## What Types of Lenses Offer UV400 Protection?
At Oscar Wylee, all of our lens types offer UV400 protection, including
prescription and non-prescription glasses. A customer will receive UV400
protection across a variety of our lenses, from
optical lenses to photochromic lenses, tinted lenses and polarised
lenses. The types of lenses that offer UV protection are listed below.
* Optical lenses:  Optical or
prescription lenses refer to lenses that are designed to help correct
refractive errors such as myopia, hyperopia or presbyopia. Optical
lenses will help a person to see clearer. At Oscar Wylee our
prescription lenses come with UV400 protection and can be used in
normal glasses, or sunglasses.
* Photochromic lenses:  Photochromic
lenses are lenses that change colour from clear to a dark tint
resembling sunglasses when exposed to light. Photochromic lenses are
designed so people who need optical lenses do not have to switch to
sunglasses everytime they go outside. At Oscar Wylee our photochromic
lenses come with UV400 protection.
* Tinted lenses:  Tinted lenses refer to
sunglasses lenses that have a tint. Tints come in a range of colours,
including brown, grey and green, and are designed to protect the eyes
from the sun. At Oscar Wylee our tinted lenses come with UV400
protection.
* Polarised lenses:  Polarised lenses
refer to lenses that have a layer applied to reduce excessive glare
and darken the lens to help with UV protection. At Oscar Wylee, our
polarised lenses have UV400 protection.
### What are the Health Risks of Not Using UV400 Protection for Your Eyes?
The health risks of not using glasses that have UV400 protection can
include eye issues such as
eye growths, cataracts and eye cancers such as ocular melanoma.
If a person does not wear sunglasses, or any glasses without UV400
protection, they increase their exposure to UV light which can be
damaging to the eyes over prolonged periods of exposure. The health
risks of not using UV400 protection for your eyes are listed below.
* Eye growths:  Eye growths, including
pterygium and pinguecula, can occur as a result of not using UV400
or sun protection. Both pterygium and pinguecula can be caused by
long term exposure to UV light. Wearing sunglasses will help to
minimise the risk of developing these growths.
* Cataracts:  Cataracts are an eye
condition where the lens of the eye clouds, making it hard to see.
Not using UV400 protection or sunglasses in general, can increase
the risk of developing cataracts. According to a paper published in
the National Eye Institute, exposure to UV light increases the risk
of cataracts, as it causes a process called oxidative stress.
* Ocular Melanoma:  Ocular Melanoma
refers to a range of different cancers that can affect the
structures of the eye. Whilst the cause of some eye cancers such as
ocular melanoma are unknown, exposure to UV light may increase the
risk of developing certain eye cancers.
### How Does UV400 Protection Benefit Outdoor Athletes and Enthusiasts?
UV 400 protection is of benefit to outdoor athletes and enthusiasts as
it
can help to protect the eyes from the risks of prolonged UV
exposure. Those who spend a lot of time outdoors, whether for sport,
recreation or work, are more likely to develop eye issues related to
prolonged UV exposure. Whilst UV400 protection is beneficial and
important for everyone when going outside, it is of special importance
for those spending many hours outside under the sun.
## What Materials are Used in Making UV400 Protective Lenses?
The exact material used in making UV protective lenses
will differ company to company. UV400 protection is
typically a chemical coating applied to a lens. Lenses can be
made from a range of materials including glass and plastic. The coating
used for UV400 protection is typically made of a thin layer of
chemicals, including metal oxide, that help to absorb, block or reflect
UV radiation.
Visit an Oscar Wylee Store Near You
We have highly qualified teams in-store, dedicated to helping with
your eye care needs.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
### Are all UV400 Lenses Polarized?
No, not all UV400 lenses will be polarised. Polarisation is a
type of sunglasses coating that darkens a lens to help minimise glare
from the sun. Not all sunglasses come with polarised lenses. It is
important to check with the company you are buying your frames from to
check whether they have polarised lenses.
## What are the Differences Between UV400 and Polarised Lenses?
The main
[difference between UV400 and polarised](https://www.oscarwylee.com.au/glasses/eye/polarised-vs-uv-protection)
lenses is their primary purpose. UV400 is designed to protect the
eyes from UV rays up to 400nm, whereas the primary purpose of polarised
lenses is to protect the eyes from glare.
### How Often Should you Replace Sunglasses with UV400 Protection?
How often a person should
replace their sunglasses is typically dependent on their
prescription, and the state of their sunglasses. If a person has prescription in their sunglasses, they may need to
replace the sunglasses when their prescription changes. A person will
know if their prescription has changed after an eye test, typically
every two years or yearly for those over 65. A person may also replace
sunglasses if they are broken, out of fashion or have been through
wear and tear.
#### Do Prescription Glasses Offer UV400 Protection?
Yes,
at Oscar Wylee our prescription glasses offer UV400 protection. All lenses at Oscar Wylee will come with UV400 protection,
without an additional fee. Prescription glasses refer to glasses
that have a prescription over or in the lenses, to help correct
refractive errors such as myopia, hyperopia or astigmatism.
Prescription glasses will typically help a person see clearer.
### What Brands are Known for Offering High-quality UV400 Protection
Eyewear?
Oscar Wylee is a brand that offers high quality UV400 protection
eyewear. At Oscar Wylee, all of our glasses and sunglasses lenses come with
UV400 protection to help keep your eyes safe from UV light.
#### Can UV400 Protection Lenses Block Blue Light?
UV400 protective coatings do not typically block blue light.
According to the University Of California Davis Health, blue light
is a type of visible light, meaning it can be seen by the human eye.
Blue light is emitted from the sun, but can also come from
artificial sources such as phone and computer screens. UV400
protection will not generally protect the eyes from blue light, as
the light usually vibrates around the 450-490nm wavelength according
toUCAR, and UV400 protection only protects the eye from a maximum of
400 nm.
### How Effective are UV400 Protection Lenses in Low-light Conditions?
As UV400 protection is
typically applied as a coating on a lens, it will be effective and
constantly working in all light conditions including low-light. However, if the UV400 protection is in sunglasses, it is not
recommended they are worn. Wearing sunglasses in low-light conditions
can darken vision and make it hard to see.
### How does UV400 Protection Contribute to Overall Eye Health?
UV400 protection
contributes to overall eye health by protecting the eyes from UV
light and its potentially damaging long term effects. UV light can be detrimental to eye health if the eyes are exposed
to it for prolonged periods of time. UV light can cause
[eye problems](https://www.oscarwylee.com.au/glasses/eye/common-problems)
such as cataracts, ocular melanoma and eye growths. Wearing sunglasses
with UV400 protection can help
[keep the eyes healthy](https://www.oscarwylee.com.au/glasses/eye/health-tips-keeping-eyesight-healthy), alongside other measures such as exercising regularly, eating a
balanced and healthy diet, not smoking, and gettin regular eye tests.
#### Do Contact Lenses Offer UV400 protection?
Contact lenses
do not typically offer enough UV protection to prevent sun or uv
related eye damage, according to the American Academy of
Ophthalmology. Whilst some contact lenses may come with a UV protection coating
or tint, they do not cover the same surface area of the eye and
surrounding structures as Sunglasses do.
Read UV400 Protection: How It Works, Types and Materials in other
Oscar Wylee regions and their languages.
Australia
[Australia](https://www.oscarwylee.com.au/glasses/eye/uv-400-protection)
New Zealand

[Canada](https://oscarwylee.ca/glasses/eye/uv-400-protection)
Canadian French

Are You Due for an Eye test?
Book online and our Oscar Wylee optometrists will perform a Medicare
bulk billed eye test to keep your eye health on track.
[Book an eye test](https://www.oscarwylee.com.au/booking)
Oscar Wylee Accepts Major Health Funds In-store
Visit Oscar Wylee in-store for eye care services and your health fund
may help cover some of the cost.
[Explore health funds](https://www.oscarwylee.com.au/health-funds.html)