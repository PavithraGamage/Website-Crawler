# Source: https://www.oscarwylee.com.au/amanda-optical.html

# Amanda
1
## Frame Design of Amanda Glasses
The frame design of Oscar Wylee’s Amanda glasses is characterised by their classic shape, a low nose bridge, and ultra light Ultem frame. Amanda is a women's statement glasses frame that will complement any outfit, day to night.
$169    
In stock
Only %1 left
2 pairs from $199
Discount auto-applied at checkout
3 pairs from $249
Discount auto-applied at checkout
Qty
Add to cart
Book an eye test
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
excluding prescription lenses
## About Amanda Frames
Find all-day comfort in Amanda. An ultra-light frame with delicate proportions, specifically designed for narrow faces and those with a low nose bridge.
| Frame fit | Measurements |
| --- | --- |
| MEDIUM | 52 - 14 - 135 |
These measurements mean lens width, bridge, and temple length in millimetres (mm). They can be found on the inside of the temple arm. If you already have a pair that you like, you can compare it to these measurements.
### Made from Ultem
Oscar Wylee’s Amanda frame is a women's classic glasses frame that is perfect for those with square, oval and pear face shapes. The Amanda frame is a classic, stylish frame that can be worn every day. The main specs of Oscar Wylee’s Amanda glasses frame, including dimensions, shape, materials, lenses, nose fit, and hinges, are listed below.
| Amanda Frame Features | Amanda Frame Description | Dimensions | Shape | Materials | Lenses | Nose Fit | Hinges |
| --- | --- | --- | --- | --- | --- | --- | --- |
| The dimensions of the Amanda frame are measured in millimetres (mm) and are 52 - 14 - 135, meaning the lens width is 52 mm, the bridge is 14 mm, and the temple length is 135 mm. |
| Amanda is a classic shape, well-suited to medium faces. |
| Amanda is made from Ultem. |
| The lenses that can be used in the Amanda frame include optical lenses, such as single-vision and multifocal, and non-prescription lenses, which are plain and can have a filter, such as a blue light filter applied. |
| The nose fit for Amanda is characterised by a low nose bridge. |
| The hinges in Amanda are normal hinges, also known as standard or barrel hinges. |
Show All
### What Inspired the Frame Design of Oscar Wylee’s Amanda Glasses?
The Oscar Wylee Amanda frame design was inspired by current fashion trends, as classic glasses are a timeless style.
## What to Know About Oscar Wylee’s Amanda Glasses?
There are many aspects of the Oscar Wylee Amanda frames that customers should know about to decide whether this is the right frame for them. The Amanda frame is a women's classic-shaped frame. Oscar Wylee’s Amanda frame is suitable for many face shapes, but particularly compatible with square, oval and pear face shapes. The Amanda frame’s simple design makes them fashionable all year round. Amanda features the standard [parts of glasses](https://www.oscarwylee.com.au/glasses/eye/part-of-glasses), such as a rim, temples, lenses and hinges.
### What are the Types of Temple Tips or Earpieces Included with Oscar Wylee’s Amanda Glasses?
The type of temple tips or earpieces included in Oscar Wylee’s Amanda Glasses are made from rubber.
### What Type of Nose Bridge do Oscar Wylee’s Amanda Glasses Have?
The type of nose bridge included in Oscar Wylee’s Amanda frame is a low nose bridge.
### What Type of Nose Pads are Included with Oscar Wylee’s Amanda Glasses?
Oscar Wylee’s Amanda frame does not include adjustable nose pads.
### What Type of Lenses do Oscar Wylee’s Amanda Glasses Have?
The type of lenses that typically come with the Oscar Wylee Amanda [glasses frame](https://www.oscarwylee.com.au/glasses.html) are optical lenses. Optical lenses are glasses lenses that have a prescription within the lens to help correct vision issues such as myopia, hyperopia, and astigmatism. Amanda frames can also come as sunglasses and with non-prescription lenses and add-ons such as a blue light filter. Amanda frames can be customised into sunglasses in-store or online with add-on tints or polarisation.
### What Material is Used for the Rim of Oscar Wylee’s Amanda Glasses?
The material used for the rim of Oscar Wylee’s Amanda glasses frames is Ultem. The rim refers to the part of a glasses frame that holds the lenses.
### What Type of Hinges are Included with Oscar Wylee’s Amanda Glasses?
The type of hinges included with Oscar Wylee’s Amanda frames are normal hinges, also known as standard or barrel hinges. These provide strength and smooth movement connecting the frame's arms and lenses.
## What Face Types are Most Suitable for Oscar Wylee’s Amanda Glasses?
The face types that are most suitable for Oscar Wylee’s Amanda frame are square, oval and pear face types. The Amanda frame is a classic shape, meaning that it complements the structure of square, oval and pear faces particularly well. The classic Amanda frames help balance the features of [square faces](https://www.oscarwylee.com.au/glasses/face-shapes/square), [oval faces](https://www.oscarwylee.com.au/glasses/face-shapes/oval) and [pear faces](https://www.oscarwylee.com.au/glasses/face-shapes/pear) and bring the eyes and brows forward in a flattering way. Although there are many [glasses for face shapes](https://www.oscarwylee.com.au/glasses/face-shapes) that may be considered more aesthetically suitable, it is important that people also choose frames that make them feel most comfortable and represent their personal style.
## What Size Options are Available for Oscar Wylee’s Amanda Glasses?
The size options available for Oscar Wylee’s Amanda frame are a medium-frame fit across all colours.
## What Materials are Used to Create Oscar Wylee’s Amanda Glasses?
The primary material used to create the Oscar Wylee Amanda frame is Ultem. Ultem is used for the rim, nose bridge and temples. The temple tips are made from rubber.
## What’s Included
## OW Case &amp;a Cloth
Protective Case and Lens Cloth
Our high-quality glasses case and lens cloth are included with every purchase of an Oscar Wylee frame. The stylish, magnetic case is made from a hard shell. This sturdy and durable material keeps your glasses protected and safe, wherever you go. Ensure your lenses are clean and scratch-free with our OW microfibre cloth, specifically designed to ensure you have comfortable vision through your lenses.
Oscar Wylee offers:
* Free Shipping for Australian Orders
* 1 Year Warranty on frames and lenses
* Scratch resistance lens coating on all prescriptions
* UV-proof coating on all prescriptions
Health fund rebate: Once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. Learn more about [health funds](https://www.oscarwylee.com.au/health-funds.html).
## Make and Materials
The frames then go through cleaning and strict quality control, and many pairs of crafting hands to be hand-assembled and polished. After your frames have gone through the production process, they are individually examined and packed before making their way to you!We love our Ultem frames! They are super comfortable and very durable. Our Ultem frames are heat resistant, with high dielectric strength and flexible. The material is widely used in medical and chemical instruments. It is currently available in a range of colours for both matte and gloss finish.
## Warranty Information
### Warranty Information
### Warranty Information
Oscar Wylee provides a 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects. We will repair or replace faulty or defective frames or lenses free of charge for warranty claims made within 1 year of the delivery. We also offer repairs or replacement for problems experienced with vision during everyday use for claims made within 30 days of delivery. If the same product has been discontinued or is no longer available, then we may offer an exchange for a similar product or a refund.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Find a Store Location](https://www.oscarwylee.com.au/locations/full-store-list.html)