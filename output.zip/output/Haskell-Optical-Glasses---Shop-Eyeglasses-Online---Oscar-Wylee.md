# Source: https://www.oscarwylee.com.au/haskell-optical.html

# Haskell
1
## Frame Design of Haskell Glasses
The frame design of Oscar Wylee’s Haskell glasses is characterised by a round shape, nose pads and a metal frame. Haskell glasses are a unisex, statement frame that will work for any occasion, whether the wearer wants to liven up their work style or complement a fun outfit for a night out.
$169    
In stock
Only %1 left
2 pairs from $199
Discount auto-applied at checkout
3 pairs from $249
Discount auto-applied at checkout
Qty
Add to cart
Book an eye test
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
excluding prescription lenses
## About Haskell Frames
Kato’s little brother, Haskell is a subtle take on our most coveted round frame. Packed up with a slightly smaller fit, Haskell comes with stainless steel and acetate.
| Frame fit | Measurements |
| --- | --- |
| NARROW | 48 - 23 - 145 |
These measurements mean lens width, bridge, and temple length in millimetres (mm). They can be found on the inside of the temple arm. If you already have a pair that you like, you can compare it to these measurements.
### Made from Stainless Steel and metal finish.
Oscar Wylee’s Haskell frame is a unisex, round glasses frame that is perfect for narrow faces and those with square, oval and heart face shapes. The Haskell frame is a stylish, widely wearable frame suited to many personal styles. The main specs of Oscar Wylee’s Haskell glasses frame including dimensions, shape, materials, lenses, nose fit and hinges are listed below.
| Haskell Frame Features | Haskell Frame Description | Dimensions | Shape | Materials | Lenses | Nose Fit | Hinges |
| --- | --- | --- | --- | --- | --- | --- | --- |
| The dimensions of the Haskell frame are measured in millimetres (mm) and are 48 - 23 - 145, meaning the lens width is 48 mm, the bridge is 23 mm and the temple length is 145 mm. |
| The Haskell frame is a round shape, well suited to narrow faces. |
| Haskell glasses are made from mostly metal with acetate temple tips. |
| The lenses that can be used in the Haskell frame are optical lenses, which include single vision and multifocal lenses and non-prescription lenses, which are plain and can have a filter like a blue light filter applied. |
| The Haskell frame is fitted with nose pads. |
| The hinges in Haskell glasses are normal hinges, also known as standard or barrel hinges. |
Show All
### What Inspired the Frame Design of Oscar Wylee’s Haskell Glasses?
The Oscar Wylee Haskell frame design was inspired by current fashion trends as round glasses shapes are often in fashion.
## What to Know About Oscar Wylee’s Haskell Glasses?
There are many aspects of the Oscar Wylee Haskell frames that customers should know about, so they can decide whether this is the right frame for them. The Haskell frame is a unisex round-shaped frame. Oscar Wylee’s Haskell frame is suitable for many face shapes but particularly compatible with square, oval and heart face shapes. The Haskell frame’s simple design means that they are fashionable all year round. Haskell glasses feature the standard [parts of glasses such as a rim, temples, lenses, spring hinges and nose pads.](https://www.oscarwylee.com.au/glasses/eye/part-of-glasses)
### What are the Types of Temple Tips or Earpieces Included with Oscar Wylee’s Haskell Glasses?
The type of temple tips or earpieces included in Oscar Wylee’s Haskell glasses are made from acetate.
### What Type of Nose Bridge do Oscar Wylee’s Haskell Glasses Have?
The type of nose bridge included in Oscar Wylee’s Haskell frame is nose pads.
### What Type of Nose Pads are Included with Oscar Wylee’s Haskell Glasses?
Oscar Wylee’s Haskell frame includes standard nose pads. Nose pads are great for comfort and can also be adjusted for the perfect fit.
### What Type of Lenses do Oscar Wylee’s Haskell Glasses Have?
The type of lenses that typically come with the Oscar Wylee Haskell [glasses frame are optical lenses. Optical lenses are glasses lenses that have a prescription within the lens to help correct vision issues such as myopia, hyperopia and astigmatism. Haskell glasses can also come with non-prescription lenses, with add-ons such as a blue light filter. Haskell frames are also available as sunglasses with polarised lenses.](https://www.oscarwylee.com.au/glasses.html)
### What Material is Used for the Rim of Oscar Wylee’s Haskell Glasses?
The material used for the rim of Oscar Wylee’s Haskell glasses frames is stainless steel. The rim refers to the part of a glasses frame that holds the lenses.
### What Type of Hinges are Included with Oscar Wylee’s Haskell Glasses?
The type of hinges included with Oscar Wylee’s Haskell frames are normal hinges, also known as standard or barrel hinges. These hinges have many interlocking loops that are stabilised with a small screw.
## What Face Types are Most Suitable for Oscar Wylee’s Haskell Glasses?
The face types most suitable for Oscar Wylee’s Haskell frame are heart, oval and square face shapes. The Haskell frame is a round shape, meaning that it complements the structure of oval faces particularly well. The round Haskell frames help to balance the features of an [oval face shape and a heart face shape, bringing the eyes and brows forward in a flattering way. The Haskell frame is also suitable for a](https://www.oscarwylee.com.au/glasses/face-shapes/oval)[square face shape. Round frames help to bring forward the sharp and striking features of a square face type, highlighting without overemphasising them. Although there are many](https://www.oscarwylee.com.au/glasses/face-shapes/square)[glasses for face shapes that may be considered more aesthetically suitable, it is important that people also choose the frames that make them feel most comfortable, and represent their personal style.](https://www.oscarwylee.com.au/glasses/face-shapes)
## What Size Options are Available for Oscar Wylee’s Haskell Glasses?
The size options available for Oscar Wylee’s Haskell frame are a narrow-frame fit across all colours.
## What Materials are Used to Create Oscar Wylee’s Haskell Glasses?
The primary materials used to create the Oscar Wylee Haskell frame are metal and acetate. The rim, nose bridges and temples are made from stainless steel while the temple tips are made from acetate.
## What’s Included
## What's Included
Each pair of glasses comes with a stylish frame case and lens cloth. We offer free shipping across Australia and 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects.
* Free Shipping for Australian Orders
* 1 Year Warranty on frames and lenses
* Scratch resistance lens coating on all prescriptions
* UV-proof coating on all prescriptions
* Stylish case and cloth
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
## Make and Materials
The frames then go through cleaning and strict quality control, and many pairs of crafting hands to be hand-assembled and polished. After your frames have gone through the production process, they are individually examined and packed before making their way to you!As part of our durable frame family, some of our most popular styles, are now in stainless steel. These frames are hypoallergenic, corrosion resistant, light weight, and not sensitive to temperature changes.
## Warranty Information
### Warranty Information
### Warranty Information
Oscar Wylee provides a 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects. 
We will repair or replace faulty or defective frames or lenses free of charge for warranty claims made within 1 year of the delivery.
We also offer repairs or replacement for problems experienced with vision during everyday use for claims made within 30 days of delivery. If the same product has been discontinued or is no longer available, then we may offer an exchange for a similar product or a refund.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Find a Store Location](https://www.oscarwylee.com.au/locations/full-store-list.html)
Recommended
1. [](https://www.oscarwylee.com.au/kato-optical.html)
[Kato](https://www.oscarwylee.com.au/kato-optical.html)
Brushed Obsidian
2. [](https://www.oscarwylee.com.au/soma-optical.html)
[Soma](https://www.oscarwylee.com.au/soma-optical.html)
Gold