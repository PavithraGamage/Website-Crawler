# Source: https://www.oscarwylee.com.au/farrell-sunglasses.html

# Farrell
1
## Frame Design of Farrell Sunglasses
The frame design of Oscar Wylee’s Farrell sunglasses is characterised by their geometric shape, adjustable nose pads, and stainless steel frame. Farrell is a wearable unisex glasses frame that will complement any outfit or event, day to night.
$169    
In stock
Only %1 left
2 pairs from $199
Discount auto-applied at checkout
3 pairs from $249
Discount auto-applied at checkout
* 2 &amp; 3 Pair pricing applies to non-prescription sunglasses only. Prescription sunglasses incur additional charges.    
[Non-Prescription](https://www.oscarwylee.com.au/farrell-sunglasses.html#)
Qty
Prescription
Book an eye test
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
excluding prescription lenses
## About Farrell Sunglasses
These stainless steel frames are a wardrobe staple. Farrell's unique hexagonal features and matte finish are accompanied by adjustable nose pads and a wide fit. This frames distinctive shape is suitable for a variety of face shapes, including Oval, Round and Square.
| Frame fit | Measurements |
| --- | --- |
| MEDIUM | 52 - 19 - 145 |
These measurements mean lens width, bridge, and temple length in millimetres (mm). They can be found on the inside of the temple arm. If you already have a pair that you like, you can compare it to these measurements.
### Made from Stainless Steel and Acetate
Oscar Wylee’s Farrell frame is a unisex geometric sunglasses frame that is perfect for those with round and oval face shapes. The Farrell frame is a distinct and versatile frame that can be worn every day. The main specs of Oscar Wylee’s Farrell glasses frame, including dimensions, shape, materials, lenses, nose fit, and hinges are listed below.
Filter category 2 - General purpose sunglasses. Good protection against sunglare. Good UV Protection.Not suitable for driving in twilight, at night or under dull conditionsThis frame comes with gradient lenses. An additional $30 will be added to your order total for prescription orders.
| Farrell Frame Features | Farrell Frame Description | Dimensions | Shape | Materials | Lenses | Nose Fit | Hinges |
| --- | --- | --- | --- | --- | --- | --- | --- |
| The dimensions of the Farrell frame are measured in millimetres (mm) and are 52 - 19 - 145, meaning the lens width is 52 mm, the bridge is 19 mm, and the temple length is 145 mm. |
| Farrell is a geometric shape, well-suited to medium faces. |
| Farrell is made from stainless steel, with acetate temple tips. |
| The lenses that can be used in the Farrell frame are sunglass lenses, which provide UV protection. Prescription lenses are also available to purchase for the Farrell sunglass frame, both online and in-store. |
| The nose fit for Farrell is characterised by adjustable nose pads. |
| The hinges in Farrell are normal hinges, also known as standard or barrel hinges. |
Show All
### What Inspired the Frame Design of Oscar Wylee's Farrell Glasses?
The Oscar Wylee Farrell frame design was inspired by current fashion trends, as geometric shapes are often in fashion. A geometric glasses shape is timeless; it remains popular throughout the decades while other trends come and go.
## What to Know About Oscar Wylee's Farrell Sunglasses?
There are many aspects of the Oscar Wylee Farrell frames that customers should know to decide whether this is the right frame for them. The Farrell frame is a unisex, geometric sunglasses frame. Oscar Wylee’s Farrell frame is suitable for many face shapes, but particularly compatible with round and oval face shapes. The Farrell frame’s simple design makes them fashionable all year round. Farrell features the standard [parts of glasses](https://www.oscarwylee.com.au/glasses/eye/part-of-glasses), such as a rim, temples, lenses, hinges, and adjustable nose pads.
### What are the Types of Temple Tips or Earpieces Included with Oscar Wylee's Farrell Glasses?
The type of temple tips or earpieces included in Oscar Wylee’s Farrell Glasses are made from acetate.
### What Type of Nose Bridge do Oscar Wylee's Farrell Glasses Have?
The type of nose bridge included in Oscar Wylee’s Farrell frame is characterised by adjustable nose pads.
### What Type of Nose Pads are Included with Oscar Wylee's Farrell Glasses?
Oscar Wylee’s Farrell frame includes adjustable silicone nose pads.
### What Type of Lenses do Oscar Wylee's Farrell Sunglasses Have?
The lenses that can be used in the Farrell frame are sunglass lenses, which provide UV protection. UV protection lenses block harmful ultraviolet rays, safeguarding eyes from damage. The Farrell frame comes in Filter Category 2. These are general purpose sunglasses. Good protection against sunglare. Good UV Protection. Not suitable for driving in twilight, at night or under dull conditions. Prescription lenses are also available for the Farrell frame, both online and in-store.
### What Material is Used for the Rim of Oscar Wylee's Farrell Glasses?
The material used for the rim of Oscar Wylee’s Farrell glasses frames is stainless steel. The rim refers to the part of a glasses frame that holds the lenses.
### What Type of Hinges are Included with Oscar Wylee's Farrell Glasses?
The type of hinges included with Oscar Wylee’s Farrell frames are normal hinges, also known as standard or barrel hinges. These provide strength and smooth movement connecting the frame's arms and lenses.
## What Face Types are Most Suitable for Oscar Wylee's Farrell Glasses?
The face types most suitable for Oscar Wylee’s Farrell frame are round and oval face types. The Farrell frame is a geometric shape, meaning it complements the structure of round and oval faces particularly well. The geometric Farrell frames help balance the features of a [round face shape](https://www.oscarwylee.com.au/glasses/face-shapes/round) and [oval face shape](https://www.oscarwylee.com.au/glasses/face-shapes/oval), bringing the eyes and brows forward in a flattering way. Although there are many different [glasses for face shapes](https://www.oscarwylee.com.au/glasses/face-shapes) that may be considered more aesthetically suitable, it is important that people also choose frames that make them feel most comfortable and represent their personal style.
## What Size Options are Available for Oscar Wylee's Farrell Glasses?
The size options available for Oscar Wylee’s Farrell frame are a medium-frame fit across all colours.
## What Materials are Used to Create Oscar Wylee's Farrell Glasses?
The primary material used to create the Oscar Wylee Farrell frame is stainless steel. Stainless steel is notable for its strength, durability and thin profile.
## What’s Included
## What's Included
Each pair of glasses comes with a stylish frame case and lens cloth. We offer free shipping across Australia and 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects.
* Free Shipping for Australian Orders
* 1 Year Warranty on frames and lenses
* Scratch resistance lens coating on all prescriptions
* UV-proof coating on all prescriptions
* Stylish case and cloth
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
## Make and Materials
The frames then go through cleaning and strict quality control, and many pairs of crafting hands to be hand-assembled and polished. After your frames have gone through the production process, they are individually examined and&nbsp;packed before making their way to you!As part of our durable frame family, some of our most popular styles, are now in stainless steel. These frames are hypoallergenic, corrosion resistant, light weight, and not sensitive to temperature changes.
## Warranty Information
### Warranty Information
### Warranty Information
Oscar Wylee provides a 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects. 
We will repair or replace faulty or defective frames or lenses free of charge for warranty claims made within 1 year of the delivery.
We also offer repairs or replacement for problems experienced with vision during everyday use for claims made within 30 days of delivery. If the same product has been discontinued or is no longer available, then we may offer an exchange for a similar product or a refund.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Find a Store Location](https://www.oscarwylee.com.au/locations/full-store-list.html)