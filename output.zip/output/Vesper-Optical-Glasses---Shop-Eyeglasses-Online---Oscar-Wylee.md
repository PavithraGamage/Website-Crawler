# Source: https://www.oscarwylee.com.au/vesper-optical.html

# Vesper
1
## Frame Design of Vesper Glasses
The frame design of Oscar Wylee’s Vesper glasses is characterised by their square shape, high nose bridge, and bio acetate frame. Vesper is a unisex, statement glasses frame that will complement any outfit, day to night.
$169    
In stock
Only %1 left
2 pairs from $199
Discount auto-applied at checkout
3 pairs from $249
Discount auto-applied at checkout
Qty
Add to cart
Book an eye test
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
excluding prescription lenses
## About Vesper Frames
You can’t go wrong with Vesper’s square frame. This classic shape will be a reliable accessory, whether you’re putting pen to paper or taking in endless scenery.
| Frame fit | Measurements |
| --- | --- |
| MEDIUM | 55 - 16 - 145 |
These measurements mean lens width, bridge, and temple length in millimetres (mm). They can be found on the inside of the temple arm. If you already have a pair that you like, you can compare it to these measurements.
### Made from Bio Acetate
Oscar Wylee's Vesper frame is a unisex square glasses frame that is perfect for those with round and oval face shapes. The Vesper frame is a stylish, widely wearable frame that can be worn every day. The main specs of Oscar Wylee's Vesper glasses frame, including dimensions, shape, materials, lenses, nose fit and hinges are listed below.
| Vesper Frame Features | Vesper Frame Description | Dimensions | Shape | Materials | Lenses | Nose Fit | Hinges |
| --- | --- | --- | --- | --- | --- | --- | --- |
| The dimensions of the Vesper frame are measured in millimetres (mm) and are 55 - 16 - 145, meaning the lens width is 55 mm, the bridge is 16 mm, and the temple length is 145 mm. |
| Vesper is a square shape, well-suited to medium faces. |
| Vesper is made from bio acetate. |
| The lenses that can be used in the Vesper frame include optical lenses, such as single-vision and multifocal, and non-prescription lenses, which are plain and can have a filter, such as a blue-light filter applied. |
| The nose fit for Vesper is characterised by a high nose bridge. |
| The hinges in Vesper are spring hinges, which are more flexible than other types of hinges and can extend past 90 degrees. |
Show All
### What Inspired the Frame Design of Oscar Wylee's Vesper Glasses?
The Oscar Wylee Vesper frame design was inspired by current fashion trends, as square glasses are a timeless style.
## What to Know About Oscar Wylee's Vesper Glasses?
There are many aspects of the Oscar Wylee Vesper frames that customers should know about to decide whether this is the right frame for them. The Vesper frame is a unisex square-shaped frame. Oscar Wylee's Vesper frame is suitable for many face shapes, but particularly compatible with round and oval face shapes. The Vesper frame's simple design makes them fashionable all year round. Vesper features the standard [parts of glasses](https://www.oscarwylee.com.au/glasses/eye/part-of-glasses), such as a rim, temples, lenses, spring hinges, and a high nose bridge.
### What are the Types of Temple Tips or Earpieces Included with Oscar Wylee's Vesper Glasses?
The type of temple tips or earpieces included in Oscar Wylee's Vesper Glasses are made from bio acetate.
### What Type of Nose Bridge do Oscar Wylee's Vesper Glasses Have?
The type of nose bridge included in Oscar Wylee's Vesper frame is characterised by a high nose bridge.
### What Type of Nose Pads are Included with Oscar Wylee's Vesper Glasses?
Oscar Wylee's Vesper frame does not include adjustable nose pads.
### What Type of Lenses do Oscar Wylee's Vesper Glasses Have?
The type of lenses that typically come with the Oscar Wylee Vesper [glasses frame](https://www.oscarwylee.com.au/glasses.html) are optical lenses. Optical lenses are glasses lenses that have a prescription within the lens to help correct vision issues such as myopia, hyperopia, and astigmatism. Vesper frames can also come as sunglasses and with non-prescription lenses and add-ons such as a blue-light filter.
### What Material is Used for the Rim of Oscar Wylee's Vesper Glasses?
The material used for the rim of Oscar Wylee's Vesper glasses frames is bio acetate. The rim refers to the part of a glasses frame that holds the lenses.
### What Type of Hinges are Included with Oscar Wylee's Vesper Glasses?
The type of hinges included with Oscar Wylee's Vesper frames are spring hinges. A spring hinge in a glasses frame refers to hinges that are more flexible than normal hinges and can go slightly beyond 90 degrees. Spring hinges can provide a closer fit to the face.
## What Face Types are Most Suitable for Oscar Wylee's Vesper Glasses?
The face types that are most suitable for Oscar Wylee's Vesper frame are round and oval face types. The Vesper frame is a square shape, meaning that it complements the structure of round and oval faces particularly well. The square Vesper frames help balance the features of [oval face shapes](https://www.oscarwylee.com.au/glasses/face-shapes/oval) and [round face shapes](https://www.oscarwylee.com.au/glasses/face-shapes/round) bringing the eyes and brows forward in a flattering way. Although there are many [glasses for face shapes](https://www.oscarwylee.com.au/glasses/face-shapes) that may be considered more aesthetically suitable, it is important that people also choose frames that make them feel most comfortable and represent their personal style.
## What Size Options are Available for Oscar Wylee's Vesper Glasses?
The size options available for Oscar Wylee's Vesper frame are a medium-fit frame across all colours.
## What Materials are Used to Create Oscar Wylee's Vesper Glasses?
The primary material used to create the Oscar Wylee Vesper frame is bio acetate. Bio acetate, also known as cellulose bio acetate, is a bioplastic, made from cotton fibres or wood pulp. At Oscar Wylee, bio acetate glasses are made by adding a dye to cellulose bio acetate, which is rolled into a sheet. The shape of the glasses is then cut from this sheet.
## What’s Included
## OW Case &amp; Cloth
Protective Case and Lens Cloth
Our high-quality glasses case and lens cloth are included with every purchase of an Oscar Wylee frame. The stylish, magnetic case is made from a hard shell. This sturdy and durable material keeps your glasses protected and safe, wherever you go. Ensure your lenses are clean and scratch-free with our OW microfibre cloth, specifically designed to ensure you have comfortable vision through your lenses.
Oscar Wylee offers:
* Free Shipping for Australian Orders
* 1 Year Warranty on frames and lenses
* Scratch resistance lens coating on all prescriptions
* UV-proof coating on all prescriptions
Health fund rebate: Once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. Learn more about [health funds](https://www.oscarwylee.com.au/health-funds.html).
## Make and Materials
Eco-consciousness meets durability with bio-acetate. Replacing unbiodegradable plasticisers with plant based alternatives, bio-acetate allows a biodegradable lens frame, leaving a reduced carbon footprint on the environment.The frames then go through cleaning and strict quality control, and many pairs of crafting hands to be hand-assembled and polished. After your frames have gone through the production process, they are individually examined and&nbsp;packed before making their way to you!
## Warranty Information
### Warranty Information
### Warranty Information
Oscar Wylee provides a 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects. We will repair or replace faulty or defective frames or lenses free of charge for warranty claims made within 1 year of the delivery. We also offer repairs or replacement for problems experienced with vision during everyday use for claims made within 30 days of delivery. If the same product has been discontinued or is no longer available, then we may offer an exchange for a similar product or a refund.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Find a Store Location](https://www.oscarwylee.com.au/locations/full-store-list.html)