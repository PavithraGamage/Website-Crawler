# Source: https://www.oscarwylee.com.au/allan-optical.html

# Allan
1
## Frame Design of Allan Glasses
The frame design of Oscar Wylee’s Allan glasses is characterised by a rectangle shape, a high nose bridge fit and an Ultem frame. Allan glasses are a men’s, essential frame that will work for any occasion.
$169    
In stock
Only %1 left
2 pairs from $199
Discount auto-applied at checkout
3 pairs from $249
Discount auto-applied at checkout
Qty
Add to cart
Book an eye test
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
excluding prescription lenses
## About Allan Frames
Presenting Allan. This frame is our refined take on the most
coveted rectangle eyewear design. This version is sleek and bold
in its glory.
| Frame fit | Measurements |
| --- | --- |
| WIDE | 55 - 16 - 145 |
These measurements mean lens width, bridge, and temple length in
millimetres (mm). They can be found on the inside of the temple
arm. If you already have a pair that you like, you can compare it
to these measurements.
### Made from Ultem material
Oscar Wylee’s Allan frame is a men’s, rectangle glasses frame that
is perfect for wide faces and those with round and oval face
shapes. The Allan frame is a stylish, widely wearable frame that
can be worn every day. The main specs of Oscar Wylee’s Allan
glasses frame including
dimensions, shape, materials, lenses, nose fit and hinges
are listed below.
| Allan Frame Features | Allan Frame Description | Dimensions | Shape | Materials | Lenses | Nose Fit | Hinges |
| --- | --- | --- | --- | --- | --- | --- | --- |
| The dimensions of the Allan frame are measured in millimetres
(mm) and are 55 - 16 - 145, meaning the lens width is 55 mm,
the bridge is 16 mm and the temple length is 145 mm. |
| The Allan frame is a rectangle frame shape, well suited to
wide faces. |
| Allan glasses are made from a type of thermoplastic material
called Ultem, with rubber temple tips. |
| The lenses that can be used in the Allan frame are optical
lenses, which include single vision and multifocal lenses and
non-prescription lenses, which are plain and can have a filter
like a blue light filter applied. |
| The nose fit of Allan frames is a high nose bridge fit. |
| The hinges in Allan glasses are spring hinges, which are more
flexible than other types of hinges and can extend past 90
degrees. |
Show All
### What Inspired the Frame Design of Oscar Wylee’s
Allan Glasses?
The Oscar Wylee Allan frame design was inspired by current
fashion trends as rectangle glasses shapes are widely wearable
and always in style.
## What to Know About Oscar Wylee’s Allan Glasses?
There are many aspects of the Oscar Wylee Allan frames that
customers should know about, so they can decide whether this
is the right frame for them. The Allan frame is a men’s
rectangle-shaped frame. Oscar Wylee’s Allan frame is suitable
for many face shapes but particularly compatible with round
and oval face shapes. The Allan frame’s classic design means
that they are fashionable all year round. Allan glasses
feature the standard
[parts of glasses](https://www.oscarwylee.com.au/glasses/eye/part-of-glasses)
such as a rim, temples, lenses, spring hinge and a high nose
bridge fit.
### What are the
Types of Temple Tips or Earpieces Included with
Oscar Wylee’s Allan Glasses?
The type of temple tips or earpieces included in Oscar Wylee’s
Allan Glasses are made from rubber.
### What Type of Nose Bridge do Oscar Wylee’s Allan
Glasses Have?
The type of nose bridge included in Oscar Wylee’s Allan frame
is a high nose bridge.
### What Type of Nose Pads are Included with Oscar
Wylee’s Allan Glasses?
Oscar Wylee’s Allan frame does not include any type of nose
pads.
### What Type of Lenses do Oscar Wylee’s Allan Glasses
Have?
The type of lenses that typically come with the Oscar Wylee
Allan
[glasses frame](https://www.oscarwylee.com.au/glasses.html)
are optical lenses. Optical lenses are glasses lenses that
have a prescription within the lens to help correct vision
issues such as myopia, hyperopia and astigmatism. Allan
glasses can also come with non-prescription lenses, with
add-ons such as a blue light filter. Allan frames are
currently unavailable as sunglasses online, however, customers
can customise in-store and add on tint or polarisation.
### What Material is Used for the Rim of Oscar Wylee’s
Allan Glasses?
The material used for the rim of Oscar Wylee’s Allan glasses
frames is Ultem. The rim refers to the part of a glasses frame
that holds the lenses.
### What Type of Hinges are Included with Oscar Wylee’s
Allan Glasses?
The type of hinges included with Oscar Wylee’s Allan frames
are spring hinges, A spring hinge in a glasses frame refers to
hinges that are more flexible than normal hinges and can go
slightly beyond 90 degrees. Spring hinges can provide a closer
fit to the face.
## What Face Types are Most Suitable for Oscar Wylee’s
Allan Glasses?
The face types most suitable for Oscar Wylee’s Allan frame are
round and oval face shapes. The Allan frame is a rectangle
shape, meaning that it complements the structure of round and
oval shapes particularly well. The rectangle Allan frames
helps to balance the features of a
[round face shape](https://www.oscarwylee.com.au/glasses/face-shapes/round)
and an
[oval face shape](https://www.oscarwylee.com.au/glasses/face-shapes/oval)
, bringing the eyes and brows forward in a flattering way.
Rectangle frames help to flatter round and oval face types by
bringing structure to the face. Although there are many
[glasses for face shapes](https://www.oscarwylee.com.au/glasses/face-shapes)
that may be considered more aesthetically suitable, it is
important that people also choose the frames that make them
feel most comfortable, and represent their personal style.
## What Size Options are Available for Oscar Wylee’s
Allan Glasses?
The size options available for Oscar Wylee’s Allan frame are a
wide-frame fit across all colours.
## What Materials are Used to Create Oscar Wylee’s
Allan Glasses?
The primary material used to create the Oscar Wylee Allan
frame is Ultem, with rubber temple tips. Ultem is a
high-performing thermoplastic, perfect for glasses frames as
it is tough and flexible, with the ability to bend and return
to its original shape.
## What’s Included
## What's Included
Each pair of glasses comes with a stylish frame case and lens cloth. We offer free shipping across Australia and 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects.
* Free Shipping for Australian Orders
* 1 Year Warranty on frames and lenses
* Scratch resistance lens coating on all prescriptions
* UV-proof coating on all prescriptions
* Stylish case and cloth
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
## Make and Materials
The frames then go through cleaning and strict quality control, and many pairs of crafting hands to be hand-assembled and polished. After your frames have gone through the production process, they are individually examined and packed before making their way to you!We love our Ultem frames! They are super comfortable and very durable. Our Ultem frames are heat resistant, with high dielectric strength and flexible. The material is widely used in medical and chemical instruments. It is currently available in a range of colours for both matte and gloss finish.
## Warranty Information
### Warranty Information
### Warranty Information
Oscar Wylee provides a 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects. 
We will repair or replace faulty or defective frames or lenses free of charge for warranty claims made within 1 year of the delivery.
We also offer repairs or replacement for problems experienced with vision during everyday use for claims made within 30 days of delivery. If the same product has been discontinued or is no longer available, then we may offer an exchange for a similar product or a refund.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Find a Store Location](https://www.oscarwylee.com.au/locations/full-store-list.html)
Recommended
1. [](https://www.oscarwylee.com.au/cape-optical.html)
[Cape](https://www.oscarwylee.com.au/cape-optical.html)
Black Matte
2. [](https://www.oscarwylee.com.au/windsor-optical.html)
[Windsor](https://www.oscarwylee.com.au/windsor-optical.html)
Citrus