# Source: https://www.oscarwylee.com.au/arnaud-optical.html

# Arnaud
1
## Frame Design of Arnaud Glasses
The frame design of Oscar Wylee’s Arnaud glasses is characterised by a rectangular shape, nose pads and a metal and acetate frame. The Arnaud frame is simple, sophisticated and stylish and will pair well with any outfit or occasion.
$169    
In stock
Only %1 left
2 pairs from $199
Discount auto-applied at checkout
3 pairs from $249
Discount auto-applied at checkout
Qty
Add to cart
Book an eye test
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
excluding prescription lenses
## About Arnaud Frames
Meet Arnaud, a flattering, rectangular shaped frame. With its
clean, sleek lines, Arnaud brings intrigue to the eyes and helps
add sophistication to your look.
| Frame fit | Measurements |
| --- | --- |
| WIDE | 56 - 18 - 140 |
These measurements mean lens width, bridge, and temple length in
millimetres (mm). They can be found on the inside of the temple
arm. If you already have a pair that you like, you can compare it
to these measurements.
### Made from metal
Oscar Wylee’s Arnaud frame is a men’s, rectangular glasses frame
that is a wide fit, ideal for those with round and oval face
shapes. The Arnaud frame is a simple, stylish, widely wearable
frame that is perfect for any day of the week. The specs of Oscar
Wylee’s Arnaud glasses frame including
dimensions, shape, materials, lenses, nose fit and hinges
are listed below.
| Arnaud Frame Features | Arnaud Frame Description | Dimensions | Shape | Materials | Lenses | Nose Fit | Hinges |
| --- | --- | --- | --- | --- | --- | --- | --- |
| The dimensions of the Arnaud frame are measured in millimetres
(mm) and are 56 - 18 - 140, meaning the lens width is 56 mm,
the bridge is 18 mm and the temple length is 140 mm. |
| The Arnaud frame is a rectangular shape, well suited to wide
faces. |
| Arnaud glasses are made from a combination of metal materials
and acetate. |
| The lenses that can be used in the Arnaud frame are optical
lenses, which include single-vision lenses, multifocal lenses
and non-prescription lenses, which are plain and can have a
filter like a blue light filter applied. |
| The nose fit of Arnaud is characterised by nose pads. |
| The hinges in Arnaud are spring hinges, which are more
flexible than other types of hinges and can extend past 90
degrees. |
Show All
### What Inspired the Frame Design of Oscar Wylee’s
Arnaud Glasses?
The Oscar Wylee Arnaud frame design was inspired by current
fashion trends as rectangular-shaped glasses are often in
fashion and widely wearable.
## What to Know About Oscar Wylee’s Arnaud Glasses?
There are many aspects of the Oscar Wylee Arnaud frames that
customers should know about, so they can decide whether this
is the right frame for them. The Arnaud frame is a rectangular
shape, suitable for many face shapes but particularly
compatible with oval and round-shaped faces. The Arnaud
frame’s simple design means that they are fashionable all year
round. Arnaud glasses feature the standard
[parts of glasses](https://www.oscarwylee.com.au/glasses/eye/part-of-glasses)
such as a rim, temples, lenses, spring hinges and nose pads.
### What are the
Types of Temple Tips or Earpieces Included with
Oscar Wylee’s Arnaud Glasses?
The type of temple tips or earpieces included in Oscar Wylee’s
Arnaud Glasses are made from acetate, with the temples made
from brass.
### What Type of Nose Bridge do Oscar Wylee’s Arnaud
Glasses Have?
The type of nose bridge included in Oscar Wylee’s Arnaud frame
is characterised by nose pads.
### What Type of Nose Pads are Included with Oscar
Wylee’s Arnaud Glasses?
Oscar Wylee’s Arnaud frame includes standard nose pads. Nose
pads are great for comfort and can also be adjusted for the
perfect fit.
### What Type of Lenses do Oscar Wylee’s Arnaud Glasses
Have?
The type of lenses that typically come with the Oscar Wylee
Arnaud
[glasses frame](https://www.oscarwylee.com.au/glasses.html)
are optical lenses. Optical lenses are glasses lenses that
have a prescription within the lens to help correct vision
issues such as myopia, hyperopia and astigmatism. Arnaud
glasses can also come with non-prescription lenses, with
add-ons such as a blue light filter. Arnaud frames are
currently unavailable as sunglasses online, however, customers
can customise in-store and add on tint or polarisation.
### What Material is Used for the Rim of Oscar Wylee’s
Arnaud Glasses?
The material used for the rim of Oscar Wylee’s Arnaud glasses
frames is stainless steel. The rim refers to the part of a
glasses frame that holds the lenses.
### What Type of Hinges are Included with Oscar Wylee’s
Arnaud Glasses?
The type of hinges included with Oscar Wylee’s Arnaud frames
are spring hinges. A spring hinge in a glasses frame refers to
hinges that are more flexible than normal hinges and can go
slightly beyond 90 degrees. Spring hinges can provide a closer
fit to the face.
## What Face Types are Most Suitable for Oscar Wylee’s
Arnaud Glasses?
The face types that are most suitable for Oscar Wylee’s Arnaud
frame are round and oval face shapes. The Arnaud frame is a
rectangular shape, meaning that it complements the structure
of round and oval faces particularly well. The solid lines of
the rectangular Arnaud frames help to balance the features of
an
[oval face shape](https://www.oscarwylee.com.au/glasses/face-shapes/oval)
or a
[round face shape](https://www.oscarwylee.com.au/glasses/face-shapes/round), bringing the eyes and brows forward in a flattering way.
Although there are many
[glasses for face shapes](https://www.oscarwylee.com.au/glasses/face-shapes)
that may be considered more aesthetically suitable than those
mentioned above, it is important that people also choose the
frames that make them feel most comfortable, and represent
their style.
## What Size Options are Available for Oscar Wylee’s
Arnaud Glasses?
The size options available for Oscar Wylee’s Arnaud frame are
a wide-frame fit across all colours.
## What Materials are Used to Create Oscar Wylee’s
Arnaud Glasses?
The materials used to create the Oscar Wylee Arnaud frame are
a combination of stainless steel for the rim, high nickel for
the nose bridge, brass for the temples and acetate for the
temple tips.
## What’s Included
## What's Included
Each pair of glasses comes with a stylish frame case and lens cloth. We offer free shipping across Australia and 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects.
* Free Shipping for Australian Orders
* 1 Year Warranty on frames and lenses
* Scratch resistance lens coating on all prescriptions
* UV-proof coating on all prescriptions
* Stylish case and cloth
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
## Make and Materials
The frames then go through cleaning and strict quality control, and many pairs of crafting hands to be hand-assembled and polished. After your frames have gone through the production process, they are individually examined and packed before making their way to you!As part of our durable frame family, some of our most popular styles, are now in stainless steel. These frames are hypoallergenic, corrosion resistant, light weight, and not sensitive to temperature changes.
                            
## Warranty Information
### Warranty Information
### Warranty Information
Oscar Wylee provides a 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects. We will repair or replace faulty or defective frames or lenses free of charge for warranty claims made within 1 year of the delivery. We also offer repairs or replacement for problems experienced with vision during everyday use for claims made within 30 days of delivery. If the same product has been discontinued or is no longer available, then we may offer an exchange for a similar product or a refund.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Find a Store Location](https://www.oscarwylee.com.au/locations/full-store-list.html)