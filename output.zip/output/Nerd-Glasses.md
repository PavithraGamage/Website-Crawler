# Source: https://www.oscarwylee.com.au/glasses/silhouette/nerd.html

34 Products        
Showing 15 of 34
1. [](https://www.oscarwylee.com.au/aaron-optical.html)
[Aaron](https://www.oscarwylee.com.au/aaron-optical.html)
$199    
[2 pairs from $249](https://www.oscarwylee.com.au/aaron-optical.html)
2. [](https://www.oscarwylee.com.au/martha-optical.html)
[Martha](https://www.oscarwylee.com.au/martha-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/martha-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/martha-optical.html)
3. [](https://www.oscarwylee.com.au/marvin-optical.html)
[Marvin](https://www.oscarwylee.com.au/marvin-optical.html)
$199    
[2 pairs from $249](https://www.oscarwylee.com.au/marvin-optical.html)
4. [](https://www.oscarwylee.com.au/mackenzie-optical.html)
[Mackenzie](https://www.oscarwylee.com.au/mackenzie-optical.html)
$199    
[2 pairs from $249](https://www.oscarwylee.com.au/mackenzie-optical.html)
5. [](https://www.oscarwylee.com.au/miranda-optical.html)
[Miranda](https://www.oscarwylee.com.au/miranda-optical.html)
$199    
[2 pairs from $249](https://www.oscarwylee.com.au/miranda-optical.html)
6. [](https://www.oscarwylee.com.au/lincoln-optical.html)
[Lincoln](https://www.oscarwylee.com.au/lincoln-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/lincoln-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/lincoln-optical.html)
7. [](https://www.oscarwylee.com.au/orville-optical.html)
[Orville](https://www.oscarwylee.com.au/orville-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/orville-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/orville-optical.html)
8. [](https://www.oscarwylee.com.au/bryce-optical.html)
[Bryce](https://www.oscarwylee.com.au/bryce-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/bryce-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/bryce-optical.html)
9. [](https://www.oscarwylee.com.au/emet-optical.html)
[Emet](https://www.oscarwylee.com.au/emet-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/emet-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/emet-optical.html)
10. [](https://www.oscarwylee.com.au/elodie-optical.html)
[Elodie](https://www.oscarwylee.com.au/elodie-optical.html)
$199    
[2 pairs from $249](https://www.oscarwylee.com.au/elodie-optical.html)
11. [](https://www.oscarwylee.com.au/kristof-optical.html)
[Kristof](https://www.oscarwylee.com.au/kristof-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/kristof-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/kristof-optical.html)
12. [](https://www.oscarwylee.com.au/hunter-optical.html)
[Hunter](https://www.oscarwylee.com.au/hunter-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/hunter-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/hunter-optical.html)
13. [](https://www.oscarwylee.com.au/harris-optical.html)
[Harris](https://www.oscarwylee.com.au/harris-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/harris-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/harris-optical.html)
14. [](https://www.oscarwylee.com.au/ezra-optical.html)
[Ezra](https://www.oscarwylee.com.au/ezra-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/ezra-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/ezra-optical.html)
15. [](https://www.oscarwylee.com.au/minh-optical.html)
[Minh](https://www.oscarwylee.com.au/minh-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/minh-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/minh-optical.html)
34 Products        
Showing 15 of 34
Product Identity and Style Understanding Frame Construction and Material Quality Glasses and Eyewear Basics Face Shape and Fit Orders, Shipping and Returns
## What are Nerd Glasses?
Nerd glasses, also known as 'geek-chic' glasses, are usually thick-framed, [round-shaped](https://www.oscarwylee.com.au/glasses/silhouette/round-glasses.html), dark coloured glasses designed to exude an intellectual and modern vibe. Nerd glasses may sound geeky, but they are becoming increasingly trendy, with many celebrities embracing thick black-rimmed frames, round Harry Potter-style glasses, and stylised cat eye frames.
### Why are Nerd Glasses Popular in Modern Eyewear?
Nerd glasses are popular in modern eyewear because they subvert the traditional geeky idea of glasses. Nerd glasses blend elements of a geek-chic aesthetic with a high-fashion look that promotes confidence and individuality.
### What Makes Nerd Glasses Different From Other Thick-Frame Glasses?
Nerd glasses are different from other thick-frame glasses as they are designed to be a fashion statement and promote an ironic, retro, and intellectual vibe. Nerd glasses are often worn despite their seemingly 'uncool' appearance, which only adds to this individualistic aesthetic.
### What Types of Nerd Glasses are Best Suited for Women?
The types of nerd glasses best suited for [women's eyeglasses](https://www.oscarwylee.com.au/glasses/best-women) are often popular choices like oversized and bold frames, round styles, thick black or brown rimmed glasses, cat eye styles, and unique geometric shapes. However, customers should purchase frames in which they feel the most comfortable and confident.
### What Types of Nerd Glasses are Best Suited for Men?
The types of nerd glasses best suited for [men's glasses](https://www.oscarwylee.com.au/glasses/collection/mens-glasses.html) are often popular choices like thick, black, rectangle frames, rounded shapes, geometric glasses, oversized square frames, and browline frames. However, customers should purchase frames in which they feel the most comfortable and confident.
#### Do I Need an Eye Test Before Buying Prescription Nerd Glasses?
Yes, a valid and up-to-date prescription is required before buying prescription nerd glasses or any prescription eyewear at Oscar Wylee. You can book an [eye test](https://www.oscarwylee.com.au/eye-care/eye-test) with an Oscar Wylee optometrist or bring in a current prescription from another provider.
#### Are Nerd Glasses Similar to Thick-Frame Prescription Glasses in Terms of Style?
Yes, nerd glasses are similar to thick-frame prescription glasses in terms of style. Both nerd glasses and thick-frame [prescription glasses](https://www.oscarwylee.com.au/glasses.html) can be identified by their thick, acetate frames and often oversized, exaggerated shape.
## Why is Acetate (Cellulose Acetate) a Popular Material for Nerd Glasses Frames?
Acetate, also known as cellulose acetate, is a popular material for nerd glasses frames because they are lightweight, durable, comfortable, versatile, and stylish. Acetate has the ability to create deep, complex colours often seen in nerd glasses frames, such as rich tortoiseshell, and dark solid colours like [brown](https://www.oscarwylee.com.au/glasses.html) and [black](https://www.oscarwylee.com.au/glasses.html). Acetate can also be crafted into thick, bold, nerdy-looking glasses frames due to its strength and flexibility. Acetate is known for its luxurious appearance, as it can be polished into a glossy finish. Acetate glasses are made through a process that involves adding dye to cellulose acetate, rolling this material into a sheet, cutting the frame shapes from it, polishing and then constructing. At Oscar Wylee, popular [acetate glasses frames](https://www.oscarwylee.com.au/glasses/materials/acetate.html) include Parker in Auburn Tortoise, Jinky in Obsidian Black, and Kent in Clear Crystal.
[](https://www.oscarwylee.com.au/parker-optical.html)
[Parker](https://www.oscarwylee.com.au/parker-optical.html)
$169    
Add to Cart
[Shop Parker](https://www.oscarwylee.com.au/parker-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/parker-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/parker-optical.html)
[](https://www.oscarwylee.com.au/jinky-optical.html)
[Jinky](https://www.oscarwylee.com.au/jinky-optical.html)
$169    
Add to Cart
[Shop Jinky](https://www.oscarwylee.com.au/jinky-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/jinky-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/jinky-optical.html)
[](https://www.oscarwylee.com.au/kent-optical.html)
[Kent](https://www.oscarwylee.com.au/kent-optical.html)
$169    
Add to Cart
[Shop Kent](https://www.oscarwylee.com.au/kent-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/kent-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/kent-optical.html)
### Are Acetate Nerd Glasses Durable for Everyday Wear?
Yes, acetate nerd glasses are durable for everyday wear. Acetate glasses are known for their durability and strength, while also being lightweight and comfortable enough for everyday wear. [Acetate](https://www.oscarwylee.com.au/glasses/acetate-frame) glasses are also generally considered to be hypoallergenic, making them a great choice for everyday wear.
### What Makes TR90 Thermoplastic Nerd Glasses Lightweight and Flexible?
[TR90](https://www.oscarwylee.com.au/glasses/tr90) thermoplastic nerd glasses are lightweight and flexible because they are made from an advanced nylon-based polymer developed by EMS, a Swiss chemical and industrial group. They provide flexibility, durability, and are lightweight, ideal for everyday wear.
#### What are the Advantages of Polycarbonate (PC) Lenses in Nerd Glasses?
The advantages of [polycarbonate (PC) lenses](https://www.oscarwylee.com.au/glasses/eye/polycarbonate-lenses) in nerd glasses are their UV protection, lightweight and flexible fit, high impact resistance, and their style versatility. The advantages of polycarbonate (PC) lenses in nerd glasses are explained in more detail below.
* UV protection: Polycarbonate lenses provide protection from UV light, meaning there is no need for a protective coating as they shield the eyes from harmful UVA and UVB rays.
* Lightweight and flexible: Polycarbonate lenses are lightweight and flexible because they are made from a high-performance thermoplastic polymer, making them ideal for everyday wear.
* High impact resistance: Polycarbonate lenses are known for their durability. They are not completely shatter-proof, but they are impact-resistant, meaning they are more durable than other lenses.
* Style versatility: Polycarbonate lenses are versatile; they can have many add-ons applied and suit a number of different glasses styles.
## What is the Difference Between Nerd Glasses and Regular Fashion Glasses?
The difference between nerd glasses and regular fashion glasses is their size, dark colour, frame thickness, and the intellectual aesthetic they exude. Nerd glasses are usually characterised by their bold or oversized shape, black or brown colours, thick rims, and a geek-chic aesthetic.


### What Types of Lenses Can Be Used in Nerd Glasses?
At Oscar Wylee, the types of lenses that can be used in nerd glasses are the same as the rest of our glasses range. These lenses include mirror tints, fashion tints, polarised tints, single vision lenses, progressive lenses, photochromic lens options (including Transitions® GEN S™ lenses), non-prescription lenses and blue light filtering. These types of lenses are explained in more detail below.
* Mirror tints: [Mirror tints](https://www.oscarwylee.com.au/glasses/mirror-sunglasses) at Oscar Wylee come in pink, blue, silver, and orange colours.
* Fashion tints: Fashion tints at Oscar Wylee come in yellow, blue, red and pink colours.
* Polarised tints: [Polarisation](https://www.oscarwylee.com.au/glasses/eye/polarised-lenses) is a coating that is applied to the lens to darken it and add colour. This also reduces glare on the horizontal wavelength. Oscar Wylee glasses offer UV 400 protection across the entire range. Our polarised lenses are available in grey, brown, and green. Depending on your prescription, polarisation may not be available with other lens options. Ask our knowledgeable team in-store what works best for your prescription.
* Single vision lenses: [Single vision lenses](https://www.oscarwylee.com.au/guides/lenses/single-vision.html) refer to lenses that contain one prescription over the entire lens, which is used to correct a single vision issue, including near vision and distance vision.
* Progressive lenses: Progressive lenses are [multifocal lenses](https://www.oscarwylee.com.au/glasses/eye/multifocal-lenses) that have three prescriptions within the lenses for people who experience problems with near, far and intermediate vision.
* Photochromic lenses: [Photochromic lenses](https://www.oscarwylee.com.au/glasses/eye/photochromic-lenses) are clear lenses that tint when exposed to UV light. Oscar Wylee has a range of colours available in our brand of photochromic lenses, referred to as adaptive lenses, and we also offer [Transitions® GEN S™ lenses](https://www.oscarwylee.com.au/transitions-lenses) at an additional price on top of your frames. Transitions® GEN S™ lenses are available in 1.5, 1.61, and 1.67 indexes. At Oscar Wylee, the different Transitions® GEN S™ lens colours available include grey, brown, sapphire, graphite green, ruby, emerald, amethyst and amber.
* Non-prescription lenses: [Non-prescription lenses](https://www.oscarwylee.com.au/guides/lenses/non-prescription-glasses) are available in all Oscar Wylee glasses for customers who don't want their prescription in their lenses or don't need one.
* Blue light filtering: [Blue light](https://www.oscarwylee.com.au/blue-light-glasses.html) filtering involves a special coating in your lenses to neutralise the blue light emitted from LCD/LED screens, such as computers, TV screens and smartphones. Blue light filters are designed for digital comfort when using screens. It is important to note that blue light filtering is a non-therapeutic cosmetic coating. This filter is only available for clear lenses and is unavailable for sunglasses due to the tint. Our Blue Light Filter is only available in standard 1.5, 1.6 and 1.67 index lenses. For more information, please visit our [Blue Light Glasses](https://www.oscarwylee.com.au/blue-light-glasses.html) page.
#### Can Nerd Glasses Be Made With Prescription Lenses?
Yes, nerd glasses can be made with prescription lenses at Oscar Wylee, just like the rest of our glasses range. At Oscar Wylee, customers can choose from any of our glasses, including round, thick-framed, and oversized styles, and have them fitted with tinted or polarised prescription lenses.
## What Face Shapes Suit Nerd Glasses Best?
The face shapes that suit nerd glasses the best are faces that suit sharper lines and angles, such as round, oval, and heart-shaped faces. Round, oval, and heart-shaped faces often have softer features, meaning thick-framed square or round nerd glasses will suit them well. However, everyone can find a frame that suits them, and should choose glasses that make them feel their best.
### How Do You Choose Nerd Glasses Based on Face Shape?
To choose nerd glasses based on your [face shape](https://www.oscarwylee.com.au/glasses/face-shapes), you need to identify your face shape, choose a nerd glasses frame based on your face shape, and try on your nerd glasses. These steps are explained further below.
* Identify your face shape: Identifying your face shape is the first step in choosing nerd glasses. The 6 different face types for glasses are round, oval, heart, square, pear, and diamond.
* Choose a nerd glasses frame based on your face shape: Nerd glasses are usually more rounded, but you can choose similar thick-rimmed or oversized styles depending on your face shape. The recommended glasses for face shapes often help to complement your facial features to bring a sense of balance to your appearance.
* Try on your nerd glasses: Try on a few different frames to decide which fits you best and your personal preference. Ensure the glasses fit comfortably on your nose bridge, and don't slide down or touch your cheeks. Conversely, make sure the glasses don't sit uncomfortably high or restrict your vision.
See the recommended Oscar Wylee nerd glasses for each face shape listed below.
* Round face shape: [Round face shapes](https://www.oscarwylee.com.au/glasses/face-shapes/round) benefit from angular glasses shapes, such as rectangle, square and browline glasses.
* Oval face shape: [Oval face shapes](https://www.oscarwylee.com.au/glasses/face-shapes/oval) often suit wider, sharper glasses, such as rectangle, square, or round glasses.
* Heart face shape: [Heart face shapes](https://www.oscarwylee.com.au/glasses/face-shapes/heart) will most likely suit square, classic, and aviator shapes.
* Square face shape: [Square face shapes](https://www.oscarwylee.com.au/glasses/face-shapes/square) often suit contrasting shapes like round or browline glasses.
* Pear face shape: [Pear face shapes](https://www.oscarwylee.com.au/glasses/face-shapes/pear) benefit from round, rectangle, or cat eye glasses shapes.
* Diamond face shape: [Diamond face shapes](https://www.oscarwylee.com.au/glasses/face-shapes/diamond) most often suit rectangle, square, and oval glasses frames.
### What Makes Nerd Glasses Look Balanced on the Face?
Nerd glasses are often oversized, dark, and have thick frames, meaning that to look balanced on the face, they need to contrast facial features and act as a focal point on the face. This is why they often complement rounder, softer facial features the best.
### Do Nerd Glasses Suit the Same Face Shapes as Square Frame Glasses?
Yes, nerd glasses typically will suit the same face shapes as traditional square frame glasses. Both of these frame styles are angular and bold, and usually suit people with round, oval, and heart-shaped faces, as their sharp lines contrast with the softer facial features of these face shapes.
### How do Different Nose Shapes Affect the Fit of Nerd Glasses?
Different nose shapes affect the fit of all glasses, including nerd glasses, because they often do not have adjustable [nose pads](https://www.oscarwylee.com.au/glasses/nose-pad), which generally provide a more customisable fit. If you have a [lower nose bridge](https://www.oscarwylee.com.au/glasses/low-bridge-fit-glasses.html), standard nerd glasses may slide down or sit too low, and conversely, if you have a [higher nose bridge](https://www.oscarwylee.com.au/glasses/nose-bridge-types/high-nose), nerd glasses may sit too high or protrude off the face. To choose the right pair of nerd glasses for your nose shape, select the right bridge type, whether it's keyhole, saddle, or adjustable, that aligns with your specific type of nose bridge. At Oscar Wylee, we have professionally trained [optical dispensers](https://www.oscarwylee.com.au/eye-care/optometrist/what-is-an-optical-dispenser.html) that specialise in helping you choose the right glasses for you, and can assist you in finding a well-fitting pair of nerd glasses in-store.
#### Are Nerd Glasses Suitable for Small or Narrow Faces?
Yes, nerd glasses can be suitable for small or narrow faces, provided you choose the right proportions. For small or narrow faces, choose smaller-sized frames, such as a pair from our [petite range](https://www.oscarwylee.com.au/glasses/collection/petite-collection.html).
## Where Can I Buy Nerd Glasses Online from Oscar Wylee?
You can buy nerd glasses online from [Oscar Wylee](https://www.oscarwylee.com.au/) on our [glasses page](https://www.oscarwylee.com.au/glasses.html) on our website. There are different filters you can choose from to select your favourite nerd glasses. We also have a [round glasses page](https://www.oscarwylee.com.au/glasses/silhouette/round-glasses.html), an [acetate glasses page](https://www.oscarwylee.com.au/glasses/materials/acetate.html), and a [browline glasses page](https://www.oscarwylee.com.au/glasses/silhouette/browline.html), which may contain our most nerdy-looking glasses.
### What Shipping Options Are Available for Oscar Wylee Nerd Glasses?
Oscar Wylee provides free shipping on all orders within Australia, New Zealand, and Canada. Customers may also choose to have their order shipped to an Oscar Wylee store for pick up. Read more about these shipping options below.
* Free shipping: [Free shipping](https://www.oscarwylee.com.au/shipping.html) is available for customers within Australia, New Zealand, and Canada. Shipping times can vary, but orders are typically dispatched within 7-10 business days, as lenses are cut to prescription.
* Store pickup: In-store pickup is also available for Oscar Wylee customers. Our staff will inform you when your order is ready to be collected.
### How Can I Track My Nerd Glasses Order from Oscar Wylee?
To track your nerd glasses from Oscar Wylee, or any product orders, you can use our [online tracking portal](https://tracking.oscarwylee.com/) using your order number in your confirmation email. For in store deliveries, we recommend allowing up to 10 business days for your order to be ready for collection.
#### How Long Does It Take to Process Refunds for Oscar Wylee Orders?
Refunds for Oscar Wylee orders can take up to 10 business days to process. Our full [returns policy](https://www.oscarwylee.com.au/legal/terms-and-conditions.html#warrantiesexchangesrefunds) is available on our website.
[Prescription Glasses](https://www.oscarwylee.com.au/glasses.html)
[Women’s Glasses](https://www.oscarwylee.com.au/glasses/collection/womens-glasses.html)
[Men’s Glasses](https://www.oscarwylee.com.au/glasses/collection/mens-glasses.html)
[Senior Glasses](https://www.oscarwylee.com.au/glasses/collection/seniors.html)
[Glasses for Kids](https://www.oscarwylee.com.au/glasses/collection/kids-collection.html)