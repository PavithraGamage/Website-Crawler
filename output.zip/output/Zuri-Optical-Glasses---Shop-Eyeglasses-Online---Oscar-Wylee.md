# Source: https://www.oscarwylee.com.au/zuri-optical.html

# Zuri
1
## Frame Design of Zuri Glasses
The frame design of Oscar Wylee’s Zuri glasses is characterised by their square shape, low nose bridge, and an acetate frame. Zuri is a female, statement glasses frame that will complement any outfit, day to night.
$169    
In stock
Only %1 left
2 pairs from $199
Discount auto-applied at checkout
3 pairs from $249
Discount auto-applied at checkout
Qty
Add to cart
Book an eye test
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
excluding prescription lenses
## About Zuri Frames
Zuri’s sleek square frame and unique stepped rim offers texture and an intellectual form.
| Frame fit | Measurements |
| --- | --- |
| MEDIUM | 52 - 18 - 140 |
These measurements mean lens width, bridge, and temple length in millimetres (mm). They can be found on the inside of the temple arm. If you already have a pair that you like, you can compare it to these measurements.
### Made from Acetate
Oscar Wylee’s Zuri frame is a female square glasses frame that is perfect for those with round and oval face shapes. The Zuri frame is a stylish, widely wearable frame that can be worn every day. The main specs of Oscar Wylee’s Zuri glasses frame, including dimensions, shape, materials, lenses, nose fit, and hinges are listed below.
| Zuri Frame Features | Zuri Frame Description | Dimensions | Shape | Materials | Lenses | Nose Fit | Hinges |
| --- | --- | --- | --- | --- | --- | --- | --- |
| The dimensions of the Zuri frame are measured in millimetres (mm) and are 52 - 18 - 140, meaning the lens width is 52 mm, the bridge is 18 mm, and the temple length is 140 mm. |
| Zuri is a square shape, well-suited to medium faces. |
| Zuri is made from acetate. |
| The lenses that can be used in the Zuri frame include optical lenses, such as single-vision and multifocal, and non-prescription lenses, which are plain and can have a filter, such as a blue light filter applied. |
| The nose fit for Zuri is characterised by a low nose bridge. |
| The hinges in Zuri are spring hinges, which are more flexible than other types of hinges and can extend past 90 degrees. |
Show All
### What Inspired the Frame Design of Oscar Wylee’s Zuri Glasses?
The Oscar Wylee Zuri frame design was inspired by current fashion trends, as square glasses are a timeless style.
## What to Know About Oscar Wylee’s Zuri Glasses?
There are many aspects of the Oscar Wylee Zuri frames that customers should know about to decide whether this is the right frame for them. The Zuri frame is a female square shaped frame. Oscar Wylee’s Zuri frame is suitable for many face shapes, but particularly compatible with round and oval face shapes. The Zuri frame’s simple design makes them fashionable all year round. Zuri features the standard [parts of glasses](https://www.oscarwylee.com.au/glasses/eye/part-of-glasses), such as a rim, temples, lenses, hinges, and a low nose bridge.
### What are the Types of Temple Tips or Earpieces Included with Oscar Wylee’s Zuri Glasses?
The type of temple tips or earpieces included in Oscar Wylee’s Zuri Glasses are made from acetate.
### What Type of Nose Bridge do Oscar Wylee’s Zuri Glasses Have?
The type of nose bridge included in Oscar Wylee’s Zuri frame is characterised by a low nose bridge.
### What Type of Nose Pads are Included with Oscar Wylee’s Zuri Glasses?
Oscar Wylee’s Zuri frame does not have adjustable nose pads.
### What Type of Lenses do Oscar Wylee’s Zuri Glasses Have?
The type of lenses that typically come with the Oscar Wylee Zuri [glasses frame](https://www.oscarwylee.com.au/glasses.html) are optical lenses. Optical lenses are glasses lenses that have a prescription within the lens to help correct vision issues such as myopia, hyperopia, and astigmatism. Zuri frames can also come as sunglasses and with non-prescription lenses and add-ons such as a blue light filter.
### What Material is Used for the Rim of Oscar Wylee’s Zuri Glasses?
The material used for the rim of Oscar Wylee’s Zuri glasses frames is acetate. The rim refers to the part of a glasses frame that holds the lenses.
### What Type of Hinges are Included with Oscar Wylee’s Zuri Glasses?
The type of hinges included with Oscar Wylee’s Zuri frames are spring hinges. Normal hinges, also known as barrel hinges or standard hinges have many interlocking loops that are stabilised with a small screw.
## What Face Types are Most Suitable for Oscar Wylee’s Zuri Glasses?
The face types that are most suitable for Oscar Wylee’s Zuri frame are round and oval face types. The Zuri frame is a square shape, meaning that it complements the structure of oval &amp; round faces particularly well. The oval &amp; round Zuri frames help balance the features of [round face shapes](https://www.oscarwylee.com.au/glasses/face-shapes/round) and [oval face shapes](https://www.oscarwylee.com.au/glasses/face-shapes/oval) and bringing the eyes and brows forward in a flattering way. Although there are many [glasses for face shapes](https://www.oscarwylee.com.au/glasses/face-shapes) that may be considered more aesthetically suitable, it is important that people also choose frames that make them feel most comfortable and represent their personal style.
## What Size Options are Available for Oscar Wylee’s Zuri Glasses?
The size options available for Oscar Wylee’s Zuri frame are a medium-frame fit across all colours.
## What Materials are Used to Create Oscar Wylee’s Zuri Glasses?
The primary material used to create the Oscar Wylee Zuri frame is acetate. Acetate is used for the rim, nose bridge, and temples and temple tips.
## What’s Included
## OW Case &amp; Cloth
Protective Case and Lens Cloth
Our high-quality glasses case and lens cloth are included with every purchase of an Oscar Wylee frame. The stylish, magnetic case is made from a hard shell. This sturdy and durable material keeps your glasses protected and safe, wherever you go. Ensure your lenses are clean and scratch-free with our OW microfibre cloth, specifically designed to ensure you have comfortable vision through your lenses.
Oscar Wylee offers:
* Free Shipping on all orders
* 1 Year Warranty on frames and lenses
* Scratch resistance lens coating on all prescriptions
* UV-proof coating on all prescriptions
Health fund rebate: Once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. Learn more about [health funds](https://www.oscarwylee.com.au/health-funds.html).
## Make and Materials
Also known as cellulose acetate, these frames are traditionally hand-crafted by skilled craftsmen, with each frame passing through numerous stages of production and are hand-polished to ensure a glorious lustre. The frames then go through cleaning and strict quality control, and many pairs of crafting hands to be hand-assembled and polished. After your frames have gone through the production process, they are individually examined and&nbsp;packed before making their way to you!
## Warranty Information
### Warranty Information
### Warranty Information
Oscar Wylee provides a 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects. We will repair or replace faulty or defective frames or lenses free of charge for warranty claims made within 1 year of the delivery. We also offer repairs or replacement for problems experienced with vision during everyday use for claims made within 30 days of delivery. If the same product has been discontinued or is no longer available, then we may offer an exchange for a similar product or a refund.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Find a Store Location](https://www.oscarwylee.com.au/locations/full-store-list.html)