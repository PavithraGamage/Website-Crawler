# Source: https://www.oscarwylee.com.au/steph-sunglasses.html

# Steph
1
## Frame Design of Steph Sunglasses
The frame design of Oscar Wylee’s Steph sunglasses is characterised by their geometric shape, adjustable nose pad fit, and stainless steel frame. Steph is a trendy female glasses frame that will complement any outfit or event, day to night.
$169    
In stock
Only %1 left
2 pairs from $199
Discount auto-applied at checkout
3 pairs from $249
Discount auto-applied at checkout
* 2 &amp; 3 Pair pricing applies to non-prescription sunglasses only. Prescription sunglasses incur additional charges.    
[Non-Prescription](https://www.oscarwylee.com.au/steph-sunglasses.html#)
Qty
Prescription
Book an eye test
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
excluding prescription lenses
## About Steph Sunglasses
Steph steps out into the sun with grace. Its geometric frame exudes a sophisticated presence, perfect for the Cosmopolitan individual.
| Frame fit | Measurements |
| --- | --- |
| WIDE | 58 - 17 - 142 |
These measurements mean lens width, bridge, and temple length in millimetres (mm). They can be found on the inside of the temple arm. If you already have a pair that you like, you can compare it to these measurements.
### Made from Stainless Steel and Acetate
Oscar Wylee’s Steph frame is a female, geometric sunglasses frame that is perfect for those with round and oval face shapes. The Steph frame is a stylish, widely wearable frame that can be dressed up or down depending on the occasion. The main specs of Oscar Wylee’s Steph glasses frame, including dimensions, shape, materials, lenses, nose fit, and hinges, are listed below.
Filter category 3 - General purpose sunglasses. High protection against sunglare. Good UV Protection. Not suitable for driving in twilight, at night or under dull conditions
This frame comes with tinted lenses. An additional $30 will be added to your order total for prescription orders.
| Steph Frame Features | Steph Frame Description | Dimensions | Shape | Materials | Lenses | Nose Fit | Hinges |
| --- | --- | --- | --- | --- | --- | --- | --- |
| The dimensions of the Steph frame are measured in millimetres (mm) and are 58 - 17 - 142, meaning the lens width is 58 mm, the bridge is 17 mm, and the temple length is 142 mm. |
| Steph is a geometric shape, well-suited to wide faces. |
| Steph is made from a combination of stainless steel and acetate. |
| The lenses that can be used in the Steph frame are sunglass lenses, which provide UV protection. Prescription lenses are also available to purchase for the Steph sunglass frame, both online and in-store. |
| The nose fit for Steph is characterised by nose pads. |
| The hinges in Steph are spring hinges, which are more flexible than other types of hinges and can extend past 90 degrees. |
Show All
### What Inspired the Frame Design of Oscar Wylee's Steph Glasses?
The Oscar Wylee Steph frame design was inspired by current fashion trends, as geometric shapes are a must-have for those who like to go bold with their accessories by taking a step up from classic and essential shapes.
## What to Know About Oscar Wylee's Steph Sunglasses?
There are many aspects of the Oscar Wylee Steph frames that customers should know about, so they can decide whether this is the right frame for them. The Steph frame is a female geometric-shaped frame. Oscar Wylee's Steph frame is suitable for many face shapes, but particularly compatible with round and oval face shapes. The Steph frame's unique design makes them fashionable all year round. Steph features the standard [parts of glasses](https://www.oscarwylee.com.au/glasses/eye/part-of-glasses) such as a rim, temples, lenses, spring hinges and nose pads.
### What are the Types of Temple Tips or Earpieces Included with Oscar Wylee's Steph Glasses?
The type of temple tips or earpieces included in Oscar Wylee's Steph Glasses are made from acetate.
### What Type of Nose Bridge do Oscar Wylee's Steph Glasses Have?
The type of nose bridge included in Oscar Wylee's Steph frame is characterised by nose pads.
### What Type of Nose Pads are Included with Oscar Wylee's Steph Glasses?
Oscar Wylee's Steph frame includes standard nose pads. Nose pads are adjustable for a perfect fit.
### What Type of Lenses do Oscar Wylee's Steph Sunglasses Have?
The lenses that can be used in the Steph frame are sunglass lenses, which provide UV protection. UV protection lenses block harmful ultraviolet rays, safeguarding eyes from damage. The Steph frame comes in Filter Category 3. These are general purpose sunglasses. High protection against sunglare. Good UV Protection. Not suitable for driving in twilight, at night, or under dull conditions. Prescription lenses are also available for the Steph sunglasses frame, both online and in-store.
### What Material is Used for the Rim of Oscar Wylee's Steph Glasses?
The material used for the rim of Oscar Wylee's Steph glasses frames is stainless steel. The rim refers to the part of a glasses frame that holds the lenses.
### What Type of Hinges are Included with Oscar Wylee's Steph Glasses?
The type of hinges included with Oscar Wylee's Steph frames are spring hinges. A spring hinge in a glasses frame refers to hinges that are more flexible than normal hinges and can go slightly beyond 90 degrees. Spring hinges can provide a closer fit to the face.
## What Face Types are Most Suitable for Oscar Wylee's Steph Glasses?
The face types that are most suitable for Oscar Wylee's Steph frame are round and oval face types. The Steph frame is a geometric shape, meaning that it complements the structure of round and oval faces particularly well. The geometric Steph frames help to balance the features of a [round face shape](https://www.oscarwylee.com.au/glasses/face-shapes/round) and an [oval face shape](https://www.oscarwylee.com.au/glasses/face-shapes/oval), bringing the eyes and brows forward in a flattering way. Geometric frames help to flatter round and oval face types, creating a pleasing visual contrast between sharp angles and rounded features, highlighting without overemphasising them. Although there are many [glasses for face shapes](https://www.oscarwylee.com.au/glasses/face-shapes) that may be considered more aesthetically suitable, it is important that people also choose the frames that make them feel most comfortable and represent their personal style.
## What Size Options are Available for Oscar Wylee's Steph Glasses?
The size options available for Oscar Wylee's Steph frame are a wide-fit frame across all colours.
## What Materials are Used to Create Oscar Wylee's Steph Glasses?
The primary material used to create the Oscar Wylee Steph frame is stainless steel, with acetate temple tips. Stainless steel is a durable iron based alloy. Acetate, also known as cellulose acetate, is a bioplastic made from cotton fibres or wood pulp. At Oscar Wylee, acetate glasses are made by adding a dye to cellulose acetate, which is rolled into a sheet. The shape of the glasses is then cut from this sheet.
## What’s Included
## OW Case &amp; Cloth
Protective Case and Lens Cloth
Our high-quality glasses case and lens cloth are included with every purchase of an Oscar Wylee frame. The stylish, magnetic case is made from a hard shell. This sturdy and durable material keeps your glasses protected and safe, wherever you go. Ensure your lenses are clean and scratch-free with our OW microfibre cloth, specifically designed to ensure you have comfortable vision through your lenses.
Oscar Wylee offers:
* Free Shipping on all orders
* 1 Year Warranty on frames and lenses
* Scratch resistance lens coating on all prescriptions
* UV-proof coating on all prescriptions
Health fund rebate: Once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. Learn more about [health funds](https://www.oscarwylee.com.au/health-funds.html).
## Make and Materials
As part of our durable frame family, some of our most popular styles, are now in stainless steel. These frames are hypoallergenic, corrosion resistant, light weight, and not sensitive to temperature changes. The frames then go through cleaning and strict quality control, and many pairs of crafting hands to be hand-assembled and polished. After your frames have gone through the production process, they are individually examined and packed before making their way to you!
## Warranty Information
### Warranty Information
### Warranty Information
Oscar Wylee provides a 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects. We will repair or replace faulty or defective frames or lenses free of charge for warranty claims made within 1 year of the delivery. We also offer repairs or replacement for problems experienced with vision during everyday use for claims made within 30 days of delivery. If the same product has been discontinued or is no longer available, then we may offer an exchange for a similar product or a refund.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Find a Store Location](https://www.oscarwylee.com.au/locations/full-store-list.html)