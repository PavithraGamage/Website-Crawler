# Source: https://www.oscarwylee.com.au/glasses/eye/papilledema

# Papilledema: Stages, Symptoms, Causes, Diagnosis, and Treatment
Published on June 10th, 2024
Australia   
[Australia](https://www.oscarwylee.com.au/glasses/eye/papilledema)
[Canada](https://oscarwylee.ca/glasses/eye/papilledema)
[Canadian French](https://oscarwylee.ca/fr/lunettes/oeil/oedeme-papillaire)
Papilledema refers to swelling of the optic disc due to raised intracranial pressure. The symptoms of papilledema can include headaches, nausea and vomiting, double vision, visual changes and transient visual obscurations. Papilledema and raised intracranial pressure is a serious medical condition. If you have symptoms of papilledema seek medical attention as soon as possible. The causes of papilledema can be caused by a range of medical conditions including trauma, a brain tumour, high blood pressure, bleeding in the brain, blood clots, brain infection and idiopathic intracranial hypertension. An optometrist, an ophthalmologist or a medical doctor will diagnose papilledema. Treatment for papilledema is usually dependent upon what underlying issue is causing the papilledema. Keep reading to learn more about papilledema.
Prioritise Your Eye Health at Oscar Wylee
Oscar Wylee optometrists are available to perform bulk billed eye tests, with no out-of-pocket expenses for eligible Medicare cardholders.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Definition](#definition) [Symptoms](#symptoms) [Causes](#causes) [Treatment](#treatment)
## What is Papilledema?
Papilledema refers to swelling of the optic disc, due to an increase in intracranial pressure. The optic disc is a structure around the end of the optic nerve that connects this nerve to the retina. Intracranial pressure refers to increased pressure in the cranium, according to the National Institute of Health. Heightened intracranial pressure is a serious medical issue and should be treated by a healthcare professional as soon as possible. Intracranial pressure can cause issues with the spine and the brain, as well as issues in the eyes, such as papilledema.
### What Part of the Eye Does Papilledema Affect?
Papilledema affects the part of the eye called the optic disc, also known as the optic nerve head. The [optic disc](https://www.oscarwylee.com.au/glasses/eye/anatomy/optic-disc) is located at the back of the eye, surrounding the optic nerve where it leaves the eye and goes towards the brain. Papilledema occurs when intracranial pressure, or pressure within the cranium, makes the optic disc swell.
### Is Papilledema a Common Eye Condition?
Papilledema, when caused by idiopathic intracranial hypertension, is an eye condition more common in women and those considered overweight. According to Havard Health, one of the health conditions that can cause papilledema is idiopathic intracranial hypertension, which occurs when the body makes too much spinal fluid. This [eye condition](https://www.oscarwylee.com.au/glasses/eye/common-problems) is more common in women of childbearing age and those considered overweight.
## What is the Grading System for Papilledema?
The grading system for papilledema is called the Frisen scale and has 5 stages or grades. According to the American Academy of Ophthalmology, the grades of papilledema are stage 0 normal optic disc, stage 1 early papilledema, stage 2 very early papilledema, stage 3 moderate, stage 4 marked papilledema and stage 5, severe papilledema.
## What are the Symptoms of Papilledema?
Papilledema may present with or without symptoms and symptoms may worsen the longer the condition goes untreated. The symptoms of papilledema can include headaches, nausea and vomiting, double vision, visual changes and transient visual obscurations. Papilledema is a serious medical condition. If a person has symptoms of papilledema, it is important to seek medical help as soon as possible. The possible symptoms of papilledema are listed below.
* Headaches:  Headaches are a common symptom of papilledema caused by the increased pressure in the cranium.
* Nausea and Vomiting:  Nausea and vomiting are possible symptoms of papilledema, caused by raised intracranial pressure.
* Double Vision:  Double vision, or diplopia is a possible symptom of papilledema.
* Visual changes:  Visual changes can be a symptom of papilledema and include having a smaller field of vision with a blind spot.
* Transient visual obscurations:  Transient visual obscurations refer to a brief, usually a few seconds, in which a person has a visual ‘blackout’ and cannot see.
### 1. Headaches
Headaches are one of the most common papilledema symptoms, caused by increased intracranial pressure. According to the American Academy of Ophthalmology, headaches associated with papilledema may be worse in the mornings or when lying down.
### 2. Nausea and Vomiting
Nausea and vomiting are common papilledema symptoms, caused by increased pressure in the cranium. Nausea and vomiting associated with papilledema are usually accompanied by headaches.
### 3. Double Vision
Double vision, also known as diplopia, is a possible symptom of papilledema. Double vision refers to seeing two images of one object. Double vision associated with papilledema is related to a non-localising sixth nerve palsy, according to Rigi, Almarzouqi, Morgan and Lee in the paper, Papilledema: epidemiology, etiology, and clinical management, meaning that there has been damage to the sixth cranial nerve. The sixth cranial nerve helps move a muscle called the lateral rectus muscle, which plays a part in eye movement.
### 4. Visual Changes
Visual changes refer to a change in how a person’s vision usually looks and can be a symptom of papilledema. Visual changes related to papilledema include blurry vision as well as a smaller field of vision with a blind spot, according to Harvard Health.
### 5. Transient Visual Obscurations
Transient visual obscurations are a possible symptom of papilledema and refer to a brief period, usually a few seconds, in which vision goes black, grey or white. Transient visual obscurations can be described as a visual blackout, where a person cannot see. According to Jun B in the paper, Diagnostic Considerations in Patients Presenting with Transient Vision Loss, transient visual obscurations related to papilledema may be binocular meaning it occurs in both eyes, or monocular which is just one eye.
## What are the Causes of Papilledema?
Papilledema occurs due to increased intracranial pressure, which can be caused by a range of medical conditions including head injury, a brain tumour, inflammation of the brain, high blood pressure, bleeding in the brain, and idiopathic intracranial hypertension. The possible causes of papilledema are listed below.
* Head injury:  A head injury can cause papilledema as trauma to the head may lead to raised intracranial pressure.
* A Brain Tumor:  A brain tumour can cause papilledema as the mass can raise pressure in the cranium, leading to swelling of the optic nerve.
* Inflammation of the Brain: Inflammation of the brain, specifically a condition called encephalitis, may cause papilledema.
* High Blood Pressure: High blood pressure, also known as hypertension, can lead to an increase in intracranial pressure, which may cause papilledema.
* Bleeding in the Brain:  Bleeding of the brain may cause papilledema as this condition often leads to raised intracranial pressure.
* Idiopathic intracranial hypertension:  Idiopathic intracranial hypertension can cause papilledema as this condition is characterised by increased intracranial pressure.
### 1. Head Injury
A head injury may cause raised intracranial pressure, which can lead to swelling of the optic disc. Head injury refers to a range of injuries that affect the head, including the skull, brain and blood vessels, according to John Hopkins Medicine. Head injuries can lead to swelling in the cranium, which can raise pressure and lead to swelling of the optic nerve.
### 2. A Brain Tumour
A brain tumour can be a cause of papilledema as a brain tumour can raise pressure in the head, which can lead to swelling of the optic disc. According to an article by Havangi Prakash, Basavaraju and Gowda called, Papilledema and Anemia: A Rare Association, a brain tumour is a space-occupying lesion that can raise pressure in the cranium. According to Havard Health, a significant proportion of people who are diagnosed with brain tumours will also have some evidence of papilledema.
### 3. Inflammation of the Brain
Inflammation of the brain may cause papilledema as inflammation may raise intracranial pressure, leading to swelling of the optic disc. Inflammation of the brain is called encephalitis and is either caused by an infection or the immune system mistakenly attacking the brain cells, according to Health Direct. Meningitis, which is an infection of the meninges or the membrane covering the brain and spinal cord, may also lead to papilledema.
### 4. High Blood Pressure
High blood pressure may be a cause of papilledema. According to Havard Health, a rise in pressure in the cranium due to high blood pressure can lead to swelling of the optic disc and papilledema. High blood pressure, also known as hypertension, refers to a condition in which the pressure pushing blood around the body through the veins, is too high.
### 5. Bleeding of the Brain
Bleeding of the brain, also known as a haemorrhage, may cause papilledema as this condition can raise intracranial pressure, leading to a swelling of the optic nerve. Bleeding of the brain may be caused by head trauma, high blood pressure and blood clotting disorders.
### 6. Idiopathic Intracranial Hypertension
Idiopathic intracranial hypertension may cause papilledema as this condition causes increased pressure in the cranium, which can lead to swelling of the optic nerve. Idiopathic intracranial hypertension refers to an increase of pressure in the cranium and around the brain, due to a build-up of cerebrospinal fluid. Idiopathic intracranial pressure is more common in those of childbearing age with a higher BMI, according to The Brain Tumour Charity. Idiopathic intracranial hypertension can be caused by a range of factors including medication, such as antibiotics or lithium, as well as hormone conditions and iron deficiency anemia.
Find an Oscar Wylee Store Near You
Come and visit your local Oscar Wylee store where our friendly team will help you shop our range of stylish and affordable frames, and assist with your eye care needs.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
## How Long Does Papilledema Take to Develop?
Papilledema may take hours to weeks to develop, depending on how fast intracranial pressure rises. According to the American Academy of Ophthalmology, rapid changes in pressure can lead to papilledema symptoms developing in a few hours to a day. Slower rises in intracranial pressure may mean papilledema takes weeks to develop.
### Is Papilledema Hereditary?
Papilledema is not itself hereditary, but the underlying causes of papilledema may be hereditary. High blood pressure is a possible cause of papilledema due to the pressure it can cause in the cranium. If a person has a family history of papilledema, then they may be at a higher risk of developing it.
## How do Eye Doctors Diagnose Papilledema?
An eye doctor, also known as an ophthalmologist in Australia, or another eye care professional such as an optometrist, can diagnose papilledema using an ophthalmoscope and an MRI. A medical doctor may also be involved in the diagnosis of papilledema as the condition can have underlying medical causes. An ophthalmoscope is an instrument featuring a magnifying lens and a light that is used to examine the back of the eye including the retina and optic nerve. An MRI (magnetic resonance image) may also be used to get a more detailed picture of the optic disc and help diagnose papilledema.
### Is it Easy to Diagnose Papilledema?
Diagnosing papilledema can be a relatively easy and straightforward process for an optometrist or eye care professional. It may be harder and require more extensive testing to diagnose the underlying cause of papilledema, such as idiopathic intracranial hypertension or a brain tumour.
### How Long Does it Take to Diagnose Papilledema?
It may only take the length of an eye test for an optometrist to diagnose papilledema, around 20-30 minutes. If an optometrist requires more extensive testing, such as an MRI, this may take longer.
#### Can Fundus Photography Detect Papilledema?
Yes, fundus photography can be used to detect papilledema. [Fundus photography](https://www.oscarwylee.com.au/glasses/eye/oct-fundus-test) describes images taken of the back of the eye using a fundus camera. A fundus camera takes photos of the retina, optic nerve and optic disc, meaning it can detect papilledema which affects the optic disc.
## What are the Treatments for Papilledema?
The treatment for papilledema is usually dependent upon what underlying issue is causing the papilledema. If papilledema is being caused by idiopathic intracranial hypertension, lumbar punctures may be used to remove excess cerebrospinal fluid and bring tension in the skull down, or through medication, according to Harvard Health. If papilledema is caused by a brain tumour, surgery or radiation may be used to treat this condition and relieve pressure in the skull.
### How Long Does Treatment Last for Papilledema?
The length of time treatment lasts for papilledema depends on what underlying issue is being treated and what treatment method is used. If a person is being treated for idiopathic intracranial hypertension, it may take several weeks for medication to become effective in draining fluid and lowering intracranial pressure.
#### What Might Happen if Papilledema is Left Untreated?
If papilledema is left untreated it could lead to serious vision loss and blindness. It is important to seek immediate treatment if you have symptoms to prevent vision loss as well as to protect general health. Papilledema is generally caused by underlying health conditions which can be an emergency.
### Can Papilledema be Treated at Home?
In certain cases of papilledema, at-home treatment can occur and primarily include weight loss. According to Kupersmith, Gamell, Turbin, Peck, Spiegel and Wall in the study, Effects of weight loss on the course of idiopathic intracranial hypertension in women, it was found that weight loss was associated with quicker recovery times for those with papilledema.
### Do You Need Eye Surgery to Treat Papilledema?
Eye surgery is not typically the main treatment for papilledema, but it can occur. Treatment for papilledema usually involves treating the underlying condition causing the papilledema, such as taking medication for idiopathic intracranial hypertension. According to the NHS, [eye surgery](https://www.oscarwylee.com.au/glasses/eye/surgery) may be used to relieve pressure and help fluid drain away. A type of eye surgery called optic nerve sheath fenestration may be used to relieve pressure on the optic disc by opening the protective layer around the optic nerve.
### Can Papilledema be Treated Permanently?
Papilledema may be treated or resolved permanently if treatment is swift, the underlying health condition is resolved and vision loss has not occurred.
### Can Papilledema be Prevented?
Prevention of papilledema primarily revolves around preventing a rise of intracranial pressure and conditions that cause it, which leads to swelling of the optic disc. To prevent head injuries, for example, it may be advised to wear protective headgear. To prevent high blood pressure, it may help to maintain a healthy weight, quit smoking and eat a balanced diet.
Read Papilledema: Stages, Symptoms, Causes, Diagnosis, and Treatment in other Oscar Wylee regions and their languages.
Australia   
[Australia](https://www.oscarwylee.com.au/glasses/eye/papilledema)
[Canada](https://oscarwylee.ca/glasses/eye/papilledema)
[Canadian French](https://oscarwylee.ca/fr/lunettes/oeil/oedeme-papillaire)
Are You Due for an Eye test?
Book online and our Oscar Wylee optometrists will perform a Medicare bulk billed eye test to keep your eye health on track.
[Book an Eye Test](https://www.oscarwylee.com.au/booking)
Oscar Wylee Accepts Major Health Funds In-store
Visit Oscar Wylee in-store for eye care services and your health fund may help cover some of the cost.
[Explore Health Funds](https://www.oscarwylee.com.au/health-funds.html)