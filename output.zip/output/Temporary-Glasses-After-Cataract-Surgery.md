# Source: https://www.oscarwylee.com.au/glasses/wear-after-cataract-surgery

# Temporary Glasses After Cataract Surgery
Published on April 1st, 2025
Updated on March 21st, 2025 
Australia
[Australia](https://www.oscarwylee.com.au/glasses/wear-after-cataract-surgery)
New Zealand

[Canada](https://oscarwylee.ca/glasses/wear-after-cataract-surgery)
Canadian French

After cataract surgery,
it may be recommended to wear temporary reading glasses. According to
the Mayo Clinic, cataract surgery is defined as a procedure to remove the
lens of the eye and replace it with an artificial lens. This is due to the
presence of a cataract, which causes the lens to become cloudy and can
eventually affect vision. The optometrist will likely recommend waiting
until being discharged from ophthalmology care following cataract surgery,
until getting new glasses. This can be about 5-6 weeks but can be longer
depending on the patient's post-operative recovery. In this period it is
important to take care of your eyes post surgery, which may include wearing
temporary glasses. Read on for all there is to know about wearing temporary
glasses after cataract surgery.
Ready to book an eye test?
At Oscar Wylee we offer bulk billed eye tests for eligible Medicare card
holders.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Wearing Old Glasses](#old_glasses)
[How Soon to Get New Glasses](#how_soon_get_new)
[Clear Vision after Cataract Surgery](#after_cataract)
[Importance of Wearing Sunglasses](#importance_of_sunglasses)
## Should I Wear My Old Glasses After Cataract Surgery on One Eye?
It is generally
not recommended to wear old glasses after cataract surgery on one
eye. This is because the prescription may not be accurate to what your eye
needs anymore. Cataract surgery results in significant vision change, so
old glasses can cause discomfort or blurry vision. Typically, your
surgeon will advise you to wait until your eye fully heals and your
vision stabilizes before wearing glasses again.
### How Soon After Cataract Surgery Can I Get New Glasses?
It is not advised to get new glasses straight after cataract surgery.
According to Cataract Surgery SA, your optometrist will likely
recommend you
wait a minimum of 5-6 weeks after your procedure for new glasses
if they are required and as directed by your
[cataract](https://www.oscarwylee.com.au/glasses/eye/cataracts)
surgeon. This will allow your vision to stabilize so the prescription
you get is the most accurate to what your eye requires post-surgery.
### How Will I Know if I Need New Glasses After Cataract Surgery?
You will know if you need new glasses after cataract surgery
based on your doctors advice and your own assessment of your
vision. According to NVision, a leading eye clinic, your doctor will
examine your eyes carefully before surgery, and after that exam, will
be able to gauge whether you will still need glasses after cataract
surgery. If you have underlying eye health issues, or are experiencing
age-related sight changes, you may need glasses after cataract
surgery. You may need glasses after surgery if you can’t see clearly
when your eyes have healed. If you experience blurry distant vision,
blurry close vision, and headaches due to eye strain, then you will
likely need glasses.
#### Do I Need Glasses after Cataract Surgery?
You
may still need glasses after
[cataract surgery](https://www.oscarwylee.com.au/glasses/eye/surgery/cataract). Generally after cataract surgery people do not need glasses for
distance viewing. However, some people still may need glasses for
reading or near work. This is true of certain intraocular lenses
(IOL) which refer to the lens implants that are given during the
cataract surgery. For example, monocular lenses are a common lens
selection that have one focusing power. Most people have monofocal
lenses for distance vision which means they will probably still need
glasses for close-up vision. EDOF lenses are another option that
give you excellent distance vision and improved mid-range vision but
likely still require near vision glasses.
## When are Temporary Glasses Needed After Cataract Surgery?
Temporary glasses will likely be needed after cataract surgery.
According to Dr Chang, a Cataract Surgeon from the Ophthalmologist
Centre Chang Cataract,
most eyes will regain significant vision improvement during the first
to second week
though full recovery can take a few months.
Before this point, inexpensive, over-the-counter reading glasses
can be used to help with reading and other near vision tasks.
### How to Care for Vision After Cataract Surgery Without Glasses?
There are many ways to care for your vision after cataract surgery
without using glasses. According to Armadale Eye Clinic, some of the
important ways to care for your vision after cataract surgery without
glasses include
administering post-surgery eye drops, restricting strenuous
activities, and protecting your eye from trauma and contamination. While your doctor will have more specific instructions tailored to
your post-surgery situation, such as wearing reading glasses to combat
[nearsightedness](https://www.oscarwylee.com.au/glasses/eye/nearsightedness), these tips listed in detail below will allow you to care for your
vision while you wait to get new prescription glasses.
* dministering Post-Surgery Eye Drops: Administering post-surgery eye drops will be an essential part of
your recovery. These drops help prevent infection, reduce swelling,
and control eye pressure.Make sure you follow your eye surgeon’s
instructions carefully to administer them accurately.
* Avoid Strenuous Activities: Avoid
strenuous activities to prevent eye complications. This includes
activities such as heavy lifting, intense field sports and swimming
for several weeks.
* Protecting your Eye from Trauma and Contamination: Protecting your eye from trauma and contamination includes avoiding
contact sports, playing with energetic pets, going outdoors on a
very hot day and staying away from dusty or dirty environments. Some
eye surgeons will recommend you to avoid washing your hair for the
first couple of days so that no shower water and shampoo
accidentally run into your operated eye.
### Why Do I Have Difficulty Reading After Cataract Surgery?
You may have difficulty reading after cataract surgery. This can be
due to
the need for proper healing time after the surgery and for new
glasses. Your close-up vision will be different after cataract surgery
particularly depending on the intraocular lens you received. For
instance, if you got the Extended Depth of Focus intraocular lens,
which enhances vision at intermediate distances, you may still require
reading glasses. Your prescription for reading glasses will be likely
most accurate once you are discharged from ophthalmological care and
have had a full recovery, usually five to six weeks minimum. This is
why there will be difficulty reading in the meantime after cataract
surgery.
### What Kind of Glasses Will I Need After Cataract Surgery?
The kind of glasses you will need after cataract surgery will
depend on your vision issues and the lens implanted during your
cataract surgery. After a visual acuity test done by an eye specialist, you will know
what sort of correction is required.
#### Do You Need Glasses After Cataract Surgery If You Have Multifocal
Lenses?
Whether you need glasses after cataract surgery is dependent on the
individuals’ eye health post surgery. According to the Cleveland
Clinic, it is
less likely you will need glasses after cataract surgery if you
have
[multifocal lenses](https://www.oscarwylee.com.au/glasses/eye/multifocal-lenses). If you elect to have multifocal lenses for your cataract surgery,
they will improve your close-up and distance vision. This will
reduce your need for glasses. Your brain adjusts to the close up and
distance vision multifocal lenses provide and chooses the focusing
power needed for the task at hand. However this is not the case for
all patients, who may require glasses at some point depending on
where their vision is weak.
Find Your Local Oscar Wylee Store
Use our store locator page to find your nearest Oscar Wylee store and
come see the team for all your eyecare needs.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
## How Long After Cataract Surgery Can You See Clearly Without Glasses?
Undergoing cataract surgery does not necessarily mean you will be able
to see clearly without glasses.
After cataract surgery, you may still need glasses but with a less
strong prescription. According to the Armadale Eye Clinic, an improvement in vision can
happen within a few days, although it can take a few weeks for your
vision to stabilise fully. Once healed,
your doctor will be able to assess whether you require glasses.
#### Can I Use My Old Glasses After Cataract Surgery for Long Distance
Vision?
Old glasses will more than likely not be ideal for
[long distance vision](https://www.oscarwylee.com.au/glasses/eye/hyperopia)
after cataract surgery. After surgery, your ophthalmologist will wait
about 5 to 6 weeks before testing you for a new vision prescription.
This is because after your cataract surgery patients that opt for a
distance correcting intraocular lens will see their long distance
vision is significantly improved, and there will be no need for an
older, stronger prescription.
### What Happens if You Don’t Wear Sunglasses After Cataract Surgery?
Wearing
[sunglasses](https://www.oscarwylee.com.au/sunglasses.html)
after cataract surgery is
important to ensure your eyes are protected and less prone to light
sensitivity during this period. Allen Eghrari, ophthalmologist with the Wilmer Eye Institute,
recommends wraparound sunglasses to accommodate the eye’s sensitivity
stating they will ‘protect you from exposure to dust, dirt and pollen,
but also help with sensitivity to light.’
#### Will I Need Reading Glasses After Cataract Surgery?
Often people will need reading glasses after they have
undergone cataract surgery. According to Cataract Surgery CA, the
need for reading glasses after cataract surgery depends on the type
and focus of the implant (IOL) placed behind your eye’s pupil after
your cataract is removed: Monofocal, Trifocal or Extended Depth of
Focus. For example, monofocal focus provides clear vision at one
distance, usually for long distance vision. This makes those with
monofocal focus likely to need reading glasses.
#### Should I Buy New Glasses for Reading After Cataract Surgery?
You may need new glasses for reading after cataract surgery.
However, this is best not to be done straight after surgery. Your
vision will need time to stabilise which can take around 4-6 weeks.
After stabilization, you will be able to get an accurate
prescription. Before then, you can always get over-the-counter
[reading glasses](https://www.oscarwylee.com.au/reading_glasses.html)
to ensure your near vision is improved during this time.
Read Temporary Glasses After Cataract Surgery in other Oscar Wylee
regions and their languages.
Australia
[Australia](https://www.oscarwylee.com.au/glasses/wear-after-cataract-surgery)
New Zealand

[Canada](https://oscarwylee.ca/glasses/wear-after-cataract-surgery)
Canadian French

Major Health Funds Accepted In-store
For the purchase of frames and lenses, use your private health fund
insurance to limit how much you pay from your own pocket.
[Explore Health funds](https://www.oscarwylee.com.au/health-funds.html)
Are You Due for an Eye Test?
Regular eye tests help keep eyes healthy. Book now and an Oscar Wylee
optometrist can provide an eye test.
[Book an eye test](https://www.oscarwylee.com.au/booking)