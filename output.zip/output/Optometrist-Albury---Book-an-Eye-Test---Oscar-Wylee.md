# Source: https://www.oscarwylee.com.au/locations/optometrist-albury.html

# Optometrist Albury
549 Dean Street Albury NSW 2640
* Opposite Murray Art Museum
Opening hours
Monday9:30am - 5:00pm
Tuesday9:00am - 5:30pm
Wednesday9:00am - 5:30pm
Thursday9:00am - 6:00pm
Friday9:00am - 5:30pm
Saturday10:00am - 4:00pm
SundayClosed
*Store hours reflect local standard trading hours and exclude public holidays
[Visit our Albury Westfield Google Business page for directions, reviews, and updates.](https://g.page/r/CVXlZNHUvk3_EBM)
Book Appointment
[Call us: (02) 6066 9903](tel:(02) 6066 9903)
[Leave a Review!](https://g.page/r/CVXlZNHUvk3_EBM/review)
Our Reviews
Eliza
4 days ago
Russell Johnson
1 week ago
I haven't had my eyes tested for a few years so I booked an appointment with Oscar Wylee at their Al...bury office.
From the moment I stepped inside I was pleasantly greeted by the store Manager who explained everything I needed to know. I was then introduced to my Optometrist who performed a series of eye checks and tests.
The staff were extremely efficient and thorough and guided me through the process of selecting my new frames and lenses.
I have no hesitation in recommending Oscar Wylee for all of your optical needs.
See more
Mary Rea
3 weeks ago
Very efficient
Steven Kitos
3 weeks ago
Friendly, smooth and efficient
service.
Nyengeterai Midzi
1 month ago
Christine Holliday
1 month ago
Best experience with an optometrist I've had. Explained everything, great pricing, they gave great a...dvice and were so very helpful when trying on frames. Can't wait to receive my glasses.
See more
Melissa Leathem
1 month ago
I would love to add photos however I didn’t take any the customer service at the Albury shop could n...ot have been more pleasant than what it was fun , honest and down right awesome- I will most definitely be going back and can not wait to get my new eyes
Thank you
See more
Murray Both
1 month ago
Excellent Optometrist for professional eye care!
VANESSA MUDGE
1 month ago
The Optometrist was friendly and professional.  The support staff also very friendly and professiona...l. I was very happy with my visit. And shall recommend Oscar Wylee Optometrist in Albury  to friends.
See more
vivienne George
2 months ago
Very professional,  very easy, staff were amazing.  Was able to get same day booking.
Kristy Holt
3 months ago
They were so accommodating, I got an eye test on the spot and new glasses ordered within 45mins. Fri...endly and knowledgeable staff.
See more
Renee Porter
3 months ago
Kevin Snaidero
3 months ago
Staff from front of house to the optometrist was a great experience. Would recommend to anyone with ...poor eyes.
See more
chantelle zanghellini
4 months ago
Astrid Pianto
4 months ago
Customer service 10/10, amazing prices, great range of frames, optometrist was spot on and explained... everything loved her Glaswegian accent.  Front of house staff - factual, helpful, funny, efficient- super stoked.  Can’t wait to try my new frames.
See more
Narelle McKimmie
4 months ago
Michelle Tee
4 months ago
My experience with Oscar Wylee was very good. Optometrist was very informative, more so than my prev...ious eye tests with another company.
The staff at Albury NSW are very friendly and helpful, and also have agreat sense of humour.
I rarely give a review, thus us my 3rd ever, but I  think they are worthy of one!!!
See more
Barbara Gray
4 months ago
The staff were all very friendly and welcoming.
Caroline Both
4 months ago
Rosemary Halonkin
5 months ago
Thank you to Albury Oscar Wyler! Weekend away and my glasses broke, the super helpful gentleman repl...aced my frames quickly and I was able to enjoy my weekend away!
See more
Olivia-Rose Lum-Welch
6 months ago
Went for an eye test recently and could not recommend this place more! Staff were incredibly nice, f...riendly and helpful. The optometrist I saw was very thorough and explained properly what was going on with my vision, he answered my questions in great detail and was very informative about everything - plus he was immensely kind and welcoming which made what is typically an anxious visit relaxing.
See more
Sarah Campbell
7 months ago
I had a Great first Visit, lovely frames, stress free experience.
Graeme Coonan
7 months ago
Jane Leah Zahra
7 months ago
Kerry-anne Reid
7 months ago
WendyJoy Smith
8 months ago
Monty is a 5 star optometrist
So professional
Such a lovely human
Ruth Forrest
8 months ago
Rowena Turner
8 months ago
dianne jeffreys
8 months ago
I believe that Oscar Wylie has give a way better eye experience answering all your questions and rea...lly help you to find the right glasses
See more
Alice Ross
9 months ago
Monty was great - thorough and careful, and very knowledgeable.
Chris Kent
9 months ago
Great service and friendly staff
Dani Gunther
9 months ago
My son and I saw Monty and he was wonderful, he tested me from scratch as I wasn't happy with the gl...asses I had, and he was very gentle and relaxed with my 10-year old's test. I would 100% recommend this store.
See more
Michele Herson
9 months ago
Stacey Corrin
9 months ago
A second visit , yet again fantastic service , friendly , welcoming , they guys here really go out o...f their way to look after their customers . Thank you merry Christmas
.. 1st visit .. After getting something in my eye whilst on the quad bike , naturally I went to the hospital (twice), after 4 days my eye was still arrayed , looking online I found their website so I thought I’d give them a try. As soon as I walked in the door I was greeted with a friendly enthusiastic and very helpful gentleman .. and was quickly in seeing the optometrist .  Best thing I did ,  was super thorough , very informative , friendly , compassionate , and after 24 hrs my eye was feeling soooo much better .  Thank you very much .
See more
Bec S
9 months ago
Monty is fantastic.  The manager was very patient in helping me choose my glasses
Yvonne Wantling
10 months ago
Excellent service, great range &amp; reasonable price. Definitely my new optometrist!
Belinda Shelton
10 months ago
Great customer service from start to finish. Very informative and kind with a great variety of glass...es to choose from. Would highly recommend
See more
Cindy Latessa
10 months ago
My appointment went really well. Very professional, pleasant gentleman looked after me. Answered all... questions. In no hurry. Great choice of glasses.
I am very happy.
See more
Georgia Hutchinson
10 months ago
The Optometrist was so nice and I appreciated him explaining every bit of the eye exam/test, as it w...as my first one. I am excited to get my glasses and not as nervous anymore. Thank you for making the experience actually fun, rather than bad haha.
See more
Will Hobbs
10 months ago
Great experience thanks guys.
Ness Ayres
10 months ago
stephanie campbell
11 months ago
Thanks to Tep for once again amazing customer service in choosing new glasses frames????
Matthew Taylor
11 months ago
Great people great service till the end of eye test and picked glasses
They want full payment not a ...deposit before they make your glasses
So I’ve diverted elsewhere where a deposit is welcome , never paid full price before I see the product , never will ????
See more
Arthur Mudd
11 months ago
The people and service was excellent. Very helpful. Thank you.
Lysa Ward
11 months ago
Donald Lloyd
11 months ago
Thank you to all the staff at Oscar Wylee Albury.
Helpful, informative and pleasant they take their ...time to make sure their customers are well looked after with follow up calls as well.
See more
Sheree Feuerherdt
1 year ago
It's always a pleasure to have an eye test and get new glasses each year at Oscar Wylee. The team ar...e alway so nice and helpful.
See more
Cath Menzie
1 year ago
Wonderful staff and amazing customer service thankyou
BILLY BUTTON BABYSITTING
1 year ago
This is my second visit to the Albury Branch and without a fail I was greeted with a smile. Tep who ...manages the branch is knowledgeable and very professional. The optometrist was great at explaining my needs and very professional. Highly recommend using Oscar Wylee. A very happy customer, Lindy
See more
judy mills
1 year ago
Great service and aftercare. Friendly and professional service from start to finish.
I will be going... back
See more
## Find an Optometrist in Albury With Oscar Wylee
Located on Dean St directly across from the Murray Art Museum Albury (MAMA) and QEII Square, Oscar Wylee Albury is the perfect place to find modern and vintage-inspired prescription glasses and prescription sunglasses. Eye tests at Oscar Wylee Albury are bulk billed in-store, so you can get your vision tested, update your prescription and shop for your glasses on the same day! Only a 12-minute walk from Albury train station or a 10-minute drive from Glenroy and Lavington, Oscar Wylee Albury is next to the main bus stop and has a large parking complex nearby. 
While in the area for your eye test with our optometrists at Oscar Wylee Albury, you can grab a coffee from the many cafes nearby, or relax in QEII Square with some lunch. You can also explore the Murray Art Museum Albury (MAMA) which showcases local art and offers community workshops. Oscar Wylee Albury is in southern New South Wales, close to the Victorian Border. For those who live in the area, Oscar Wylee optometrists nearest to you include Oscar Wylee Shepparton and Oscar Wylee Wagga Wagga. 
With our dedicated eye care professionals, high-quality customer service and fashion-forward frames, Oscar Wylee has some of the best optometrist services in Albury, Australia!        
Meet Our Team
* Optometrist
BOptom (Hons)
* Store Manager
Our Services
* Bulk Billed Eye Examinations
* Professional Frame Styling
* Frame Adjustments and Repairs
* Visual Fields Testing
Show All
## Find an Optometrist in Albury, New South Wales for an Eye Health Test
An optometrist in Albury, New South Wales is available for primary eye care services that do not require an eye doctor. Our eye health tests in Albury are thorough and intended to monitor vision and eye health and identify any signs of eye diseases. We have an optical dispenser at all store locations that can assist with any eyewear concerns and care. Come visit our glasses store to browse our wide range of optical eyewear or if you require prescription glasses or prescription sunglasses. The procedure for testing eye health typically involves examining multiple parts of the eye and takes around 20 minutes.
The average price range for an optometrist in Albury has a varied range depending on location and what your vision condition requires. At Oscar Wylee our eye tests are available at a bulk billing price courtesy of Australia’s Medicare System.
## How to Find an Optometrist in Albury, New South Wales?
To find an optometrist in Albury, NSW, you can take certain steps that can help make it easier for you such as searching online, assessing the store’s opening hours and finding the directions to your chosen location. The steps on how to find an optometrist in Albury, NSW are listed below.
1. Search online using the phrase, Albury optometrist near me. This can also be done here on the website via our locations page.
2. Click on the Oscar Wylee link, which will take you directly to our Albury, NSW optometrist store page.
3. See the store’s opening hours and where the store is located specifically.
4. Use the Albury, NSW Google Business page link located under store hours to see the directions on how to get to the store.
You can also find an optometrist in Albury by searching the keywords optometrist near me. If you have locations enabled on your smartphone and you’re in the Albury area, our Albury store page should appear easily for you to click on.
### Is it Hard to Get an Eye Appointment in Albury, NSW?
No, it is not hard to get an eye appointment in Albury, NSW. You can easily book an appointment to see an Oscar Wylee optometrist in Albury right here on this page. At Oscar Wylee we have highly qualified optometrists available for bulk billed eye appointments, which can be booked online or in-store.
#### How to Compare Optometrists in Albury NSW to Each Other?
To compare optometrists in Albury NSW, you can use factors such as eye tests offered, health fund coverage, lens types and add-ons and eyewear offered. To take care of your vision and eye health, it is important to receive an eye test at least once every two years. There are different types of tests that can be performed in an eye test and not all optometrists may offer the same tests. Health funds can be used to help cover some of the cost of your frames and lenses. To find out if your health fund is accepted at Albury, NSW, visit their website. In the case of Oscar Wylee, we accept all major health funds and provide on-the-spot claims in-store. There are many different lens options available for prescription glasses such as single vision, multifocal and high index lenses. Most optometrists in Albury will offer these lenses although it is good to make sure. There are also lens add-ons available to enhance your glasses such as anti-reflective and blue light filters. Finally, if you are looking to purchase a pair of glasses after your eye test, you can compare the different styles and colours you are interested in from Albury, NSW Oscar Wylee offers a wide range of frames with vintage and modern inspirations in bold colours and subtle designs.
#### How to Find an Eyeglasses Shop in Albury, NSW?
To find a glasses store in Albury, you can try to follow these simple steps including searching online, selecting a convenient location and looking at their health insurance policies. The steps on how to find a glasses store in Albury, NSW are listed below.
1. Search online using the phrase, glasses store in Albury. This will provide you with various options for glasses stores in the whole Albury, NSW area.
2. Select a glasses store that is most convenient for you to travel to.
3. Click the link to find out more information such as opening hours, exact location and directions to the glasses store in Albury.
4. Read their health insurance policies to ensure you know what health benefits you have access to.
Our Oscar Wylee glasses store in Albury, NSW offers primary eye care services such as comprehensive eye tests as well as other services performed by an optometrist and offers prescription and non-prescription eyewear.
##### Is it Possible to Purchase Prescribed Sunglasses in Albury, NSW Without Seeing an Optometrist?
Yes and no, it is possible to [purchase prescribed sunglasses](https://www.oscarwylee.com.au/sunglasses.html) in Albury without seeing an optometrist if you already have a prescription that has not expired. If your prescription is expired, you can book an eye test to receive an updated or new prescription which will require you to see an optometrist. This will ensure your prescription sunglasses are appropriate for your visual needs.
## Where is the Oscar Wylee Albury Optometrist in Albury Located?
The Oscar Wylee Albury optometrist is located in Albury and can be found along Dean Street, next to South Cali Cantina.
### What is the Phone Number of Oscar Wylee Albury Optometrist Store?
The Oscar Wylee Albury optometrist store phone number is (02) 6066 9903. You can contact the Oscar Wylee Albury store between the hours of 9 am and 5:30 pm on Tuesday, Wednesday and Friday, 9 am and 6 pm on Thursdays and from 10 am to 2 pm on Saturdays.
### What are the Reviews for Oscar Wylee Albury Optometrist in NSW?
The reviews for Oscar Wylee Albury optometrist in NSW, left by our various customers can be found here on the website as well as online when you look up Oscar Wylee Albury optometrist. The reviews for Oscar Wylee Albury optometrist are listed below.
* Robyn Fulford:  Great service, friendly staff.
* Laura Eyles: Great visit. Felt welcome and heard. Test was thorough and well done.
* Mark Gul:  Absolutely fantastic
* Renee Knight:  Amazing service, very helpful staff and my optometrist Monty was lovely overall great first experience.
* Zoe Barnes:  I took my daughter to the Albury location after she saw some of their glasses. The man doing her eye test was beyond amazing! He spent so much time checking everything and actually talking to my daughter about it all. Then the two out the front were great with helping her with her selections.
#### What Treatments or Eye Care Processes are Done in the Oscar Wylee Albury Optometrist Location?
The treatments or eye care processes done in the Oscar Wylee Albury optometrist NSW location include a tonometry test, a digital photograph, a slit lamp exam and a refraction test. Additional tests that may also be performed can include a visual field test and a dilated fundus exam. The treatments or eye-care processes that are done in the Oscar Wylee Albury optometrist NSW location are listed below.
* A Tonometry Test: An optometrist or optical dispenser will conduct a tonometry test which involves the use of a machine that will release small puffs of air into your eyes. This will assist with measuring pressure in the eye.
* A Digital Photograph: An optometrist or optical dispenser may take a digital photograph of your eye which can be kept on record to use in future appointments to evaluate any changes to your eye.
* Slit Lamp Test: A slit lamp test can be used to evaluate your eye health, by examining your cornea and iris which are the anterior and posterior of the eye.
* Refraction Test: During a refraction test, an optometrist will have you view an image through different lenses and ask you to confirm which helps you see the image clearer.
* Visual Field Test: A visual field test can assist with assessing your peripheral vision, which may be beneficial for identifying any signs of glaucoma.
* Dilated Fundus Exam: A dilated fundus exam can help an optometrist assess your health in more detail by getting a clear view of the retina. This test is typically carried out for patients with diabetes and those who may be at risk of developing retinal damage.
## How Many Optometrists Exist in Albury NSW?
There are many optometrists that exist in Albury NSW to provide eye tests and glasses, including Oscar Wylee. At Oscar Wylee Albury located in NSW, we cover a range of essential eye care services carried out by our optometrists, optical dispensers and retail team. There is no accurate number of how many optometrists are in each suburb, however, we can guarantee that you will be able to find all things optometry right here at Oscar Wylee.
### What are the Other Closest Optometrist Locations to Albury NSW in Australia?
There are no other Oscar Wylee optometrist locations close to Albury in Australia however we have many stores in Queensland, Western Australia and Victoria. If you are looking for an optometrist near you, you can find the locations of our many stores on our full store page.
### Oscar Wylee Albury optometrists perform bulk billed eye tests
With Oscar Wylee, you can prioritise your eye health and take care of your vision. Just stop by our Oscar Wylee eyeglasses shop in Albury, Australia, where the eye care processes available include prescription updates, eye health tests to assess vision and detect certain eye diseases, and frame shopping. At Oscar Wylee Albury eye tests are bulk billed for eligible Medicare card holders and performed by our dedicated and experienced Oscar Wylee optometrists.
### Oscar Wylee Albury accepts major health funds
Here at Oscar Wylee Albury, we can process your health fund claim in-store with a valid health fund card. We'll help answer any questions about what you’re eligible for with your health fund. You don’t have to navigate the hardest parts of health insurance alone - here at Oscar Wylee Albury, we’re here to make sure you get what you need at an affordable, competitive price.
### Fashion-forward styles at affordable prices
Oscar Wylee Albury is committed to helping you find your perfect pair of frames, offering modern and vintage-style glasses frames at an affordable cost. Our Oscar Wylee Albury optometrists help to provide prescription lenses to fit customer needs - whether it’s a blue light filter, multifocal lens, or a polarised lens for your prescription sunglasses, our experts in-store are ready to help you with any of your eyesight requirements.
Book Appointment
[Call us: (02) 6066 9903](tel:(02) 6066 9903)
[Leave a Review!](https://g.page/r/CVXlZNHUvk3_EBM/review)