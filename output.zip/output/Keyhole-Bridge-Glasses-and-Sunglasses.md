# Source: https://www.oscarwylee.com.au/glasses/nose-bridge-types/keyhole

# Keyhole Bridge Glasses and Sunglasses
Published on August 1st, 2025
Updated on March 21st, 2025 
Australia
Australia
New Zealand
Canada
Canadian French

Keyhole bridge glasses and sunglasses are characterised by their distinctive bridges that resemble the shape of a
vintage keyhole. This shape is typically round and wider at the top,
narrowing down the centre and rests evenly on the sides of the
nose. Keyhole bridge glasses are widely available in a variety of colours,
patterns and frame styles, and depending on the frame shape, can suit many
different face shapes. They provide elegant style and comfort due to their
functional design, which helps distribute the weight of the glasses
evenly. At Oscar Wylee, you can find prime options for keyhole bridge
glasses and sunglasses such as Heba, Zeke, Humphrey, Francis, Luca and
Connor, which come in varied styles and colours. Continue reading below to
learn more about this unique [nose bridge](https://www.oscarwylee.com.au/glasses/nose-bridge-types) style.
Have You Had a Recent Eye Test?
We have passionate and dedicated optometrists at every store ready to help
you!
[Book an eye test](https://www.oscarwylee.com.au/booking)
[How to Choose The Best Keyhole Bridge Glasses](#how-to-choose)
[Materials](#materials)
[Types of Nose Shapes For Keyhole Bridge Glasses](#types)
## How to Choose the Best Keyhole Bridge Glasses
To choose the best keyhole bridge glasses,
think about your visual requirements, consider your nose shape and
assess your lifestyle needs. The steps on how to choose the best keyhole bridge glasses are listed
below.
* Think about your visual requirements:
Firstly, think about your visual requirements when choosing the best
keyhole bridge glasses. After getting an eye test, the optometrist
will be able to help with recommending frames that may be more
suitable for your vision.
* Consider your nose shape: Consider
your nose shape as keyhole bridge glasses may be more suited to
certain sizes and structures of noses in terms of comfort and proper
fit. Wider noses and low nose bridges may be more suitable for keyhole
bridge glasses, as the wider and round top of the keyhole shape
naturally creates more space and therefore, more comfort and even
weight distribution.
* Assess your lifestyle needs: Lastly,
assess your lifestyle needs when selecting the best keyhole bridge
glasses. If you typically use your glasses during physical activities,
you may want to consult with the optometrist to determine if they are
the most optimal frames.
[](https://www.oscarwylee.com.au/humphrey-optical.html)
[Humphrey](https://www.oscarwylee.com.au/humphrey-optical.html)
$169    
Add to Cart
[Shop Humphrey](https://www.oscarwylee.com.au/humphrey-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/humphrey-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/humphrey-optical.html)
[](https://www.oscarwylee.com.au/heba-optical.html)
[Heba](https://www.oscarwylee.com.au/heba-optical.html)
$169    
Add to Cart
[Shop Heba](https://www.oscarwylee.com.au/heba-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/heba-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/heba-optical.html)
[](https://www.oscarwylee.com.au/francis-optical.html)
[Francis](https://www.oscarwylee.com.au/francis-optical.html)
$169    
Add to Cart
[Shop Francis](https://www.oscarwylee.com.au/francis-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/francis-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/francis-optical.html)
### How to Choose the Best Keyhole Bridge Glasses According to Skin Tone?
Skin tone does not play a major role in choosing the best keyhole
bridge glasses, but can be used if someone wishes to pick a colour
of keyhole bridge glasses that suits them best.
To choose the best keyhole frame according to skin tone, a person
needs first to identify their skin undertone and then pick a
complementary colour. A person can determine their skin tone by
looking at the veins on the inner wrist. If the veins are blue or
purple, this usually indicates a cooler tone. If the veins are more
blue-green, then a person may have neutral undertones. If the veins
are more yellow or green-looking, this can indicate a warm undertone.
For warmer skin undertones, frames in warm and earth colours, such as
oranges and browns, will look good. For cooler skin tones, cooler
colours such as blues, pinks and purples are suitable.
### How to Choose the Best Keyhole Nose Bridge Glasses According to Face
Shape?
The ways to choose the best keyhole nose bridge according to face
shape
involve identifying what face shape you have and what glasses will
best complement this face shape. The nose itself is what will help to determine the best nose
bridge, with face shape more playing a role in ensuring the glasses
are suitable for the overall look of the face. The
most common face shapes are round face shapes, square face shapes,
pear face shapes, oval face shapes and heart face shapes. The ways to choose the best keyhole nose bridges according to face
shape are listed below.
* Round face shapes:
[Round face shapes](https://www.oscarwylee.com.au/glasses/face-shapes/round)
are characterised by a round, softer look. Round face shapes are
well-suited to rectangular or square-shaped frames, as these help to
bring structure to the face.
* Square face shapes:
[Square face shapes](https://www.oscarwylee.com.au/glasses/face-shapes/square)
are generally as wide as they are long and look angular. Glasses
that suit this face shape include round, cat-eye, oval and aviator
glasses, as the roundness of these frame types helps to soften the
angular features of square faces.
* Pear face shapes:
[Pear face shapes](https://www.oscarwylee.com.au/glasses/face-shapes/pear)
are characterised by a narrow forehead and fuller jaw. Rectangular
and square glasses are well-suited to pear face shapes, as they add
width to the forehead and help balance the face.
* Oval face shape:
[Oval face shapes](https://www.oscarwylee.com.au/glasses/face-shapes/oval)
resemble an oblong shape and have smooth curves. Frames that suit an
oval face shape include rectangular and square-shaped frames, as
they help to balance the cut how round the face and bring balance to
features.
* Heart face shape: A heart-shaped
face is characterised by a wider forehead and a smaller chin. Frames
that suit a heart-shaped face are round and square, as these shapes
help to balance out the wider forehead.
### How to Choose the Best Keyhole Bridge Glasses According to Eye Colour?
To choose the best keyhole bridge glasses according to eye colour,
identify your eye colour, consider frames that complement your eye
colour and consider frames that contrast with your eye
colour. The steps on how to choose keyhole glasses according to eye colour
are listed below.
* Identify your eye colour: Firstly,
identify your eye colour, whether you have brown, hazel, green or
blue eyes. For lighter colours, it may be helpful to look during the
day when the room is filled with sunlight, to ensure the most
accurate colour under natural lighting.
* Consider frames that complement your eye colour:
Consider frames that complement your eye colour by trying on
different frame colours that may fall in the same palette as your
eye colour. For example, if you have brown eyes, you may want to opt
for tortoise patterns as they typically include a mixture of browns,
amber and gold tones.
* Consider frames that contrast with your eye colour:
Lastly, consider frames that contrast with your eye colour by trying
on frame colours that can make your eye colour pop. For example, if
you have blue eyes, try different brown shades, gold frames or
tortoise patterns, which can help emphasise the natural colour of
your eyes more.
Experience High-Quality Eye Care
Our team strives to prioritise your eye health and provide a memorable
in-store experience.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
## Which Material is Best for Keyhole Bridge Glasses?
The materials that may be best for keyhole bridge glasses
can include acetate, TR90 and stainless steel. Acetate
is an optimal material for crafting stylish glasses that are
lightweight, while stainless steel and titanium are ideal materials for
creating strong and lightweight glasses.
It is important to note that Oscar Wylee does not sell titanium or
stainless steel keyhole bridge glasses.

### 1. Acetate Keyhole Bridge Glasses
Acetate keyhole bridge glasses are
lightweight, durable and made through a special process to ensure a
high-quality material.
The process involves adding dye to cellulose acetate, rolling this
material into a sheet, cutting the frame shapes from it and then
finally polishing and constructing. Oscar Wylee
[acetate frames](https://www.oscarwylee.com.au/glasses/acetate-frame)
for keyhole bridge glasses can vary in price depending on your vision
requirements and potential add-ons. Acetate is advantageous for
creating strong and durable frames while still maintaining its
lightweight nature and creating glasses that are rich in colour.
[](https://www.oscarwylee.com.au/kent-optical.html)
[Kent](https://www.oscarwylee.com.au/kent-optical.html)
$169    
Add to Cart
[Shop Kent](https://www.oscarwylee.com.au/kent-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/kent-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/kent-optical.html)
[](https://www.oscarwylee.com.au/billy-optical.html)
[Billy](https://www.oscarwylee.com.au/billy-optical.html)
$169    
Add to Cart
[Shop Billy](https://www.oscarwylee.com.au/billy-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/billy-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/billy-optical.html)
[](https://www.oscarwylee.com.au/kevin-optical.html)
[Kevin](https://www.oscarwylee.com.au/kevin-optical.html)
$169    
Add to Cart
[Shop Kevin](https://www.oscarwylee.com.au/kevin-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/kevin-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/kevin-optical.html)
[](https://www.oscarwylee.com.au/harris-optical.html)
[Harris](https://www.oscarwylee.com.au/harris-optical.html)
$169    
Add to Cart
[Shop Harris](https://www.oscarwylee.com.au/harris-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/harris-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/harris-optical.html)
[](https://www.oscarwylee.com.au/moya-optical.html)
[Moya](https://www.oscarwylee.com.au/moya-optical.html)
$169    
Add to Cart
[Shop Moya](https://www.oscarwylee.com.au/moya-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/moya-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/moya-optical.html)
### 2. TR90 Keyhole Bridge Glasses
TR90 keyhole bridge glasses
refer to frames made from TR90 and are a type of thermoplastic
material crafted to ensure lightweightness and flexibility.
Here at Oscar Wylee, our
[TR90 frames](https://www.oscarwylee.com.au/glasses/tr90)
are placed through conditions ensuring they will maintain their
properties in extreme temperatures, including extremely humid or dry
climates. TR90's distinctive lightweight nature can vary depending on
the particular style and/or when other materials are used. Many TR90
frames at Oscar Wylee can make optimal lightweight glasses options.
[](https://www.oscarwylee.com.au/nolan-sunglasses.html)
[Nolan](https://www.oscarwylee.com.au/nolan-sunglasses.html)
$169    
Add to Cart
[Shop Nolan](https://www.oscarwylee.com.au/nolan-sunglasses.html)
[2 pairs from $199](https://www.oscarwylee.com.au/nolan-sunglasses.html)
[3 pairs from $249](https://www.oscarwylee.com.au/nolan-sunglasses.html)
[](https://www.oscarwylee.com.au/connor-optical.html)
[Connor](https://www.oscarwylee.com.au/connor-optical.html)
$169    
Add to Cart
[Shop Connor](https://www.oscarwylee.com.au/connor-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/connor-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/connor-optical.html)
### What is the Keyhole Bridge in Glasses?
The keyhole bridge in glasses refers to the specific shape of the
glasses frame, which
resembles the shape of a vintage-style keyhole. A keyhole bridge is
characterised by its wide and round-shaped top, which narrows down
the centre.
The centre of the keyhole bridge sits evenly on the sides of the
wearer's nose and can provide a secure fit and comfort. According to
the College of Optometrists, keyhole bridge glasses, also known as
"Prince-nez" glasses, originated in the 19th century, and the name
translates to 'pinching the nose'.
[](https://www.oscarwylee.com.au/louie-optical.html)
[Louie](https://www.oscarwylee.com.au/louie-optical.html)
$169    
Add to Cart
[Shop Louie](https://www.oscarwylee.com.au/louie-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/louie-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/louie-optical.html)
[](https://www.oscarwylee.com.au/dolly-optical.html)
[Dolly](https://www.oscarwylee.com.au/dolly-optical.html)
$169    
Add to Cart
[Shop Dolly](https://www.oscarwylee.com.au/dolly-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/dolly-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/dolly-optical.html)
[](https://www.oscarwylee.com.au/zeke-optical.html)
[Zeke](https://www.oscarwylee.com.au/zeke-optical.html)
$169    
Add to Cart
[Shop Zeke](https://www.oscarwylee.com.au/zeke-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/zeke-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/zeke-optical.html)
[](https://www.oscarwylee.com.au/luca-optical.html)
[Luca](https://www.oscarwylee.com.au/luca-optical.html)
$169    
Add to Cart
[Shop Luca](https://www.oscarwylee.com.au/luca-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/luca-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/luca-optical.html)
[](https://www.oscarwylee.com.au/mischa-optical.html)
[Mischa](https://www.oscarwylee.com.au/mischa-optical.html)
$169    
Add to Cart
[Shop Mischa](https://www.oscarwylee.com.au/mischa-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/mischa-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/mischa-optical.html)
[](https://www.oscarwylee.com.au/charlie-optical.html)
[Charlie](https://www.oscarwylee.com.au/charlie-optical.html)
$169    
Add to Cart
[Shop Charlie](https://www.oscarwylee.com.au/charlie-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/charlie-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/charlie-optical.html)
### Why Does the Nose Bridge Matter in Choosing Keyhole Bridge Glasses?
The nose bridge matters in choosing keyhole bridge glasses as it
can influence how the glasses will sit on your face, the level of
comfort and fit.
Keyhole bridge glasses may enhance comfort and help distribute the
weight of your
[prescription glasses](https://www.oscarwylee.com.au/glasses/prescription)
more evenly.
### Which Colour Pattern is Best for Keyhole Bridge Glasses Frames?
The colour pattern that may be best for keyhole bridge glasses frames
can include options such as
matte, solid, striped, tortoise, transparent and two-tone.
The colour patterns that may be best for keyhole bridge glasses frames
are listed below.
* Matte: Matte can be an ideal choice
for keyhole bridge glasses as it can offer the wearer a subtle
elevation in style and may be less prone to fingerprint smudges.

[](https://www.oscarwylee.com.au/francis-optical.html)

[](https://www.oscarwylee.com.au/sadie-optical.html)
* Solid: A solid colour pattern can be
an ideal choice for keyhole bridge glasses as it helps bring more
focus to the distinct shape of the keyhole bridge and offers the
wearer a classic and clean look.

[](https://www.oscarwylee.com.au/winston-optical.html)
[](https://www.oscarwylee.com.au/billy-sunglasses.html)

[](https://www.oscarwylee.com.au/luca-optical.html)
[](https://www.oscarwylee.com.au/billy-sunglasses.html)
* Striped: A striped colour pattern
can be an ideal choice for keyhole bridge glasses as it elevates
visual interest in addition to the distinct keyhole bridge design.
* Tortoise: A tortoise colour pattern
can be an ideal choice for keyhole bridge glasses, as the browns,
ambers, blacks, and golds can create warmth and depth. Due to its
versatile colour palette, a tortoise pattern can suit a range of
skin tones.

[](https://www.oscarwylee.com.au/kent-optical.html)
[](https://www.oscarwylee.com.au/heba-optical.html)

[](https://www.oscarwylee.com.au/kent-optical.html)
[](https://www.oscarwylee.com.au/heba-optical.html)
* Transparent: A transparent colour
pattern can be an ideal choice for keyhole bridge glasses as it
offers wearers a smart, modern and minimalist look. Transparent
colour patterns can help subtly enhance your facial features without
adding too much visual clutter.

[](https://www.oscarwylee.com.au/humphrey-optical.html)
[](https://www.oscarwylee.com.au/chamberlain-sunglasses.html)

[](https://www.oscarwylee.com.au/humphrey-optical.html)
[](https://www.oscarwylee.com.au/chamberlain-sunglasses.html)
* Two-Tone: A two-tone colour pattern
can be an ideal choice for keyhole bridge glasses as it offers a
unique but modern twist on a classic keyhole bridge frame. A
two-tone pattern can be an easy way to achieve a more bold look.

[](https://www.oscarwylee.com.au/zeke-optical.html)
[](https://www.oscarwylee.com.au/trixie-optical.html)

[](https://www.oscarwylee.com.au/zeke-optical.html)
[](https://www.oscarwylee.com.au/trixie-optical.html)
### What Types of Nose Shapes Work Best with Keyhole Bridge Glasses?
The types of nose bridges that work best with keyhole bridge glasses
may include wider noses or a low nose bridge. The
keyhole shape of the frame bridge is wider and rounder at the top and
therefore, allowing for more space and comfort. Certain
[types of nose shapes](https://www.oscarwylee.com.au/glasses/nose-types)
may be more suited to specific types of frame bridge shapes than
others, so it can be helpful to visit your local store to try on
various frame shapes and styles in person.
#### Are Keyhole Bridge Glasses Better for Persons with Small Noses?
Keyhole bridge glasses can be
better for people with small noses. This is because
keyhole bridges distribute weight more evenly across the nose,
allowing for a snug fit to accommodate a smaller nose.
#### What is the Difference Between a Keyhole Bridge and a Low Nose
Bridge?
The
difference between a keyhole bridge and low nose bridge is that
the first is a type of glasses bridge and is designed based,
whereas a low nose bridge describes the physical features of a
nose.
A keyhole bridge refers to an eyewear frame bridge design that
resembles the shape of a vintage keyhole. A low nose bridge refers
to the midline of the nose called the "bridge", wherein the bridge
is closer to the face, often resulting in a flatter profile, less
pronounced than the high nose bridge. It should be noted that a
keyhole bridge is a glasses frame bridge design, whereas a
[low nose bridge](https://www.oscarwylee.com.au/glasses/low-bridge-fit-glasses.html)
is used to describe the bridge of the nose on the face.
##### Do Cat-Eye Frame Glasses Feature Keyhole Bridge Designs?
Yes,
[cat-eye frame](https://www.oscarwylee.com.au/glasses/cat-eye-frame)
glasses can feature keyhole bridge designs. However, cat-eye frame glasses do not just have keyhole bridges
and can also have saddle bridges. You should try the cat-eye
glasses on regardless of bridge type before purchasing to see how
it suits and fits your face.
##### Are Keyhole Bridge Glasses Suitable for Sports and Active Use?
No, keyhole bridge glasses are not often found in glasses for
sports and active use.
Sports and
[active use glasses](https://www.oscarwylee.com.au/sunglasses/collection/active-collection.html)
often have saddle nose bridges. Most importantly, they should have
adjustable or rubber nose pads for strong gripping to ensure the
glasses sit securely on the face during physical activity.
## What are the Price Factors for Keyhole Bridge Glasses?
The price factors for keyhole bridge glasses may include
your prescription requirements and potential lens add-ons. At Oscar Wylee, many of our frames, including our keyhole bridge
glasses, have a starting price that can be influenced by the level of
prescription you need for vision correction and/or if you require
special lens add-ons such as photochromic lenses or multifocal lenses.
### What is the Duration of Shipment for Keyhole Bridge Glasses?
The duration of shipment for keyhole bridge glasses is usually
within 7-10 business days at Oscar Wylee. Oscar Wylee
offers domestic shipping for keyhole bridge glasses ordered on the
website. An email will be sent to you confirming the order for your
keyhole bridge glasses purchase, alongside an order tracking link.
### What is the Warranty Policy for Keyhole Bridge Glasses?
Oscar Wylee has a warranty policy that
covers production faults within 12 months of delivery or purchase
of your keyhole bridge glasses.
This encompasses production faults, such as material issues, defective
frames or damage from the product's manufacturing. Oscar Wylee's
satisfaction guarantee offers replacement or repair of your purchase,
free of charge. Oscar Wylee also offers a repair or replacement for
problems experienced with vision during everyday use for claims
made within 30 days of delivery or receipt of
purchase.
Goods damaged in transit also fall under our 12-month guarantee and
will allow you to undertake the same actions you can do when you
have a faulty product.
If you wish to replace a faulty product that has been discontinued or
is no longer available, we may offer you an exchange for a similar
product or a refund. All customers who purchase Oscar Wylee glasses
are able to have lifetime cleaning and adjustment. For more
information, please visit
[our warranty policy page](https://www.oscarwylee.com.au/legal/oscar-wylee-warranty.html).
Read Keyhole Bridge Glasses and Sunglasses in other Oscar Wylee
regions and their languages.
Australia
Australia
New Zealand
Canada
Canadian French

Major Health Funds Accepted In-store
For the purchase of frames and lenses, use your private health
insurance to limit how much you pay from your own pocket.
[Explore health funds](https://www.oscarwylee.com.au/health-funds.html)
Do You Have Any Vision Concerns?
Book an appointment with an Oscar Wylee optometrist today.
[Book an eye test](https://www.oscarwylee.com.au/booking)