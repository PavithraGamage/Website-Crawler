# Source: https://www.oscarwylee.com.au/hugh-optical.html

# Hugh
1
## Frame Design of Hugh Glasses
The frame design of Oscar Wylee’s Hugh glasses is characterised by their rectangle shape, high nose bridge, Ultem frame, and lightweight feel. Hugh is a versatile men’s glasses frame that you can rely on, day to night.
$199    
In stock
Only %1 left
2 pairs from $249
Discount auto-applied at checkout
Qty
Add to cart
Book an eye test
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
excluding prescription lenses
## About Hugh Frames
Hugh’s slightly smaller fit will flatter any face shape. This classic rectangle frame will take you from breakfast to dinner - so light you might not want to take them off!
| Frame fit | Measurements |
| --- | --- |
| MEDIUM | 54 - 17 - 146 |
These measurements mean lens width, bridge, and temple length in millimetres (mm). They can be found on the inside of the temple arm. If you already have a pair that you like, you can compare it to these measurements.
### Made from Ultem
Oscar Wylee's Hugh frame is a men's rectangle glasses frame that is perfect for those with round and oval face shapes. The Hugh frame is a sleek, modern frame that can be worn every day. The main specs of Oscar Wylee's Hugh glasses frame, including dimensions, shape, materials, lenses, nose fit and hinges are listed below.
| Hugh Frame Features | Hugh Frame Description | Dimensions | Shape | Materials | Lenses | Nose Fit | Hinges |
| --- | --- | --- | --- | --- | --- | --- | --- |
| The dimensions of the Hugh frame are measured in millimetres (mm) and are 54 - 17 - 146, meaning the lens width is 54 mm, the bridge is 17 mm, and the temple length is 146 mm. |
| Hugh is a rectangle shape, well-suited to medium faces. |
| Hugh is made from Ultem with rubber temple tips. |
| The lenses that can be used in the Hugh frame include optical lenses, such as single-vision and multifocal, and non-prescription lenses, which are plain and can have a filter, such as a blue-light filter applied. |
| The nose fit for Hugh is a high nose bridge fit. |
| The hinges in Hugh are spring hinges, which are more flexible than other types of hinges and can extend past 90 degrees. |
Show All
### What Inspired the Frame Design of Oscar Wylee's Hugh Glasses?
The Oscar Wylee Hugh frame design was inspired by current fashion trends, as rectangle shapes are often in fashion. A rectangle glasses shape is timeless; it remains popular throughout the decades while other trends come and go.
## What to Know About Oscar Wylee's Hugh Glasses?
There are many aspects of the Oscar Wylee Hugh frames that customers should know about to decide whether this is the right frame for them. The Hugh frame is a men's rectangle-shaped frame. Oscar Wylee's Hugh frame is suitable for many face shapes, but particularly compatible with round and oval face shapes. The Hugh frame's simple design makes them fashionable all year round. Hugh features the standard [parts of glasses](https://www.oscarwylee.com.au/glasses/eye/part-of-glasses), such as a rim, temples, lenses, spring hinges, and a high nose bridge fit.
### What are the Types of Temple Tips or Earpieces Included with Oscar Wylee's Hugh Glasses?
The type of temple tips or earpieces included in Oscar Wylee's Hugh Glasses are made from rubber.
### What Type of Nose Bridge do Oscar Wylee's Hugh Glasses Have?
The type of nose bridge included in Oscar Wylee's Hugh frame is a high nose bridge fit.
### What Type of Nose Pads are Included with Oscar Wylee's Hugh Glasses?
Oscar Wylee's Hugh frame does not include adjustable silicone nose pads.
### What Type of Lenses do Oscar Wylee's Hugh Glasses Have?
The type of lenses that typically come with the Oscar Wylee Hugh [glasses frame](https://www.oscarwylee.com.au/glasses.html) are optical lenses. Optical lenses are glasses lenses that have a prescription within the lens to help correct vision issues such as myopia, hyperopia, and astigmatism. Hugh can also come with non-prescription lenses, with add-ons such as a blue light filter. Hugh frames can be customised into sunglasses in-store or online with add-on tints or polarisation.
### What Material is Used for the Rim of Oscar Wylee's Hugh Glasses?
The material used for the rim of Oscar Wylee's Hugh glasses frames is Ultem. The rim refers to the part of a glasses frame that holds the lenses.
### What Type of Hinges are Included with Oscar Wylee's Hugh Glasses?
The type of hinges included with Oscar Wylee's Hugh frames are spring hinges. A spring hinge in a glasses frame refers to hinges that are more flexible than normal hinges and can go slightly beyond 90 degrees. Spring hinges can provide a closer fit to the face.
## What Face Types are Most Suitable for Oscar Wylee's Hugh Glasses?
The face types that are most suitable for Oscar Wylee's Hugh frame are round and oval face types. The Hugh frame is a rectangle shape, meaning that it complements the structure of round and oval faces particularly well. The rectangle Hugh frames help balance the features of a [round face shape](https://www.oscarwylee.com.au/glasses/face-shapes/round) and an [oval face shape](https://www.oscarwylee.com.au/glasses/face-shapes/oval), bringing the eyes and brows forward in a flattering way. Although there are many [glasses for face shapes](https://www.oscarwylee.com.au/glasses/face-shapes) that may be considered more aesthetically suitable, it is important that people also choose frames that make them feel most comfortable and represent their personal style.
## What Size Options are Available for Oscar Wylee's Hugh Glasses?
The size options available for Oscar Wylee's Hugh frame are a medium-fit frame across all colours.
## What Materials are Used to Create Oscar Wylee's Hugh Glasses?
The primary material used to create the Oscar Wylee Hugh frame is Ultem. Ultem is a high-performing thermoplastic, perfect for glasses frames as it is tough and flexible, with the ability to bend and return to its original shape.
## What’s Included
## What's Included
Each pair of glasses comes with a stylish frame case and lens cloth. We offer free shipping across Australia and 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects.
* Free Shipping for Australian Orders
* 1 Year Warranty on frames and lenses
* Scratch resistance lens coating on all prescriptions
* UV-proof coating on all prescriptions
* Stylish case and cloth
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
## Make and Materials
The frames then go through cleaning and strict quality control, and many pairs of crafting hands to be hand-assembled and polished. After your frames have gone through the production process, they are individually examined and packed before making their way to you!We love our Ultem frames! They are super comfortable and very durable. Our Ultem frames are heat resistant, with high dielectric strength and flexible. The material is widely used in medical and chemical instruments. It is currently available in a range of colours for both matte and gloss finish.
## Warranty Information
### Warranty Information
### Warranty Information
Oscar Wylee provides a 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects. 
We will repair or replace faulty or defective frames or lenses free of charge for warranty claims made within 1 year of the delivery.
We also offer repairs or replacement for problems experienced with vision during everyday use for claims made within 30 days of delivery. If the same product has been discontinued or is no longer available, then we may offer an exchange for a similar product or a refund.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Find a Store Location](https://www.oscarwylee.com.au/locations/full-store-list.html)
Recommended
1. [](https://www.oscarwylee.com.au/logan-optical.html)
[Logan](https://www.oscarwylee.com.au/logan-optical.html)
Primary Blue
2. [](https://www.oscarwylee.com.au/miles-optical.html)
[Miles](https://www.oscarwylee.com.au/miles-optical.html)
Hazelnut Tortoise
3. [](https://www.oscarwylee.com.au/allan-optical.html)
[Allan](https://www.oscarwylee.com.au/allan-optical.html)
Obsidian