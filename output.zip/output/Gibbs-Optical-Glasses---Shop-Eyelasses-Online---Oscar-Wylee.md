# Source: https://www.oscarwylee.com.au/gibbs-optical.html

# Gibbs
1
## Frame Design of Gibbs Glasses
The frame design of Oscar Wylee’s Gibbs glasses is characterised by a rectangle shape, nose pads and a metal and acetate frame. The Gibbs frame is a unisex pair of glasses that will work for any occasion, whether the wearer wants to liven up their work style or complement a fun outfit for a night out.
$169    
In stock
Only %1 left
2 pairs from $199
Discount auto-applied at checkout
3 pairs from $249
Discount auto-applied at checkout
Qty
Add to cart
Book an eye test
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
excluding prescription lenses
## About Gibbs Frames
A sleek, sharp looking frame fit for agent Leroy Jethro Gibbs. Boasting spring hinges and an adjustable nose fit, this angular frame is perfect for the special agent in all of us.
| Frame fit | Measurements |
| --- | --- |
| MEDIUM | 55 - 17 - 140 |
These measurements mean lens width, bridge, and temple length in millimetres (mm). They can be found on the inside of the temple arm. If you already have a pair that you like, you can compare it to these measurements.
### Made from Metal
Oscar Wylee’s Gibbs frame is a unisex, rectangle glasses frame that is suited for medium faces and those with round or oval face shapes. The Gibbs frame is a widely wearable frame that can be worn every day. The main specs of Oscar Wylee’s Gibbs glasses frame including dimensions, shape, materials, lenses, nose fit and hinges are listed below.
| Gibbs Frame Features | Gibbs Frame Description | Dimensions | Shape | Materials | Lenses | Nose Fit | Hinges |
| --- | --- | --- | --- | --- | --- | --- | --- |
| The dimensions of the Gibbs frame are measured in millimetres (mm) and are 55 - 17 - 140, meaning the lens width is 55 mm, the bridge is 17 mm and the temple length is 140 mm. |
| The Gibbs frame is a rectangle shape, well suited to medium faces. |
| Gibbs glasses are made from metal with acetate temple tips. |
| The lenses that can be used in the Gibbs frame are optical lenses, which include single vision and multifocal lenses and non-prescription lenses, which are plain and can have a filter like a blue light filter applied. |
| The Gibbs frames include nose pads which are adjustable for a comfortable fit. |
| The hinges in Gibbs glasses are spring hinges, which are more flexible than other types of hinges and can extend past 90 degrees. |
Show All
### What Inspired the Frame Design of Oscar Wylee’s Gibbs Glasses?
The Oscar Wylee Gibbs frame design was inspired by current fashion trends as rectangle shapes are often in fashion. They are also part of the growing geek chic trend which are slim, wired-rimmed glasses, popular in the 2000s.
## What to Know About Oscar Wylee’s Gibbs Glasses?
There are many aspects of the Oscar Wylee Gibbs [glasses frame that customers should know about, so they can decide whether this is the right frame for them. The Gibbs frame is a unisex rectangular-shaped frame. Oscar Wylee’s Gibbs frame is suitable for many face shapes but is particularly compatible with round and oval face shapes. The Gibbs frame’s simple design means that they are fashionable all year round. Gibbs glasses feature the standard](https://www.oscarwylee.com.au/glasses.html)[parts of glasses such as a rim, temples, lenses, spring hinge and nose pads.](https://www.oscarwylee.com.au/glasses/eye/part-of-glasses)
### What are the Types of Temple Tips or Earpieces Included with Oscar Wylee’s Gibbs Glasses?
The type of temple tips or earpieces included in Oscar Wylee’s Gibbs Glasses are made from acetate.
### What Type of Nose Bridge do Oscar Wylee’s Gibbs Glasses Have?
The type of nose bridge included in Oscar Wylee’s Gibbs frame is characterised by nose pads.
### What Type of Nose Pads are Included with Oscar Wylee’s Gibbs Glasses?
Oscar Wylee’s Gibbs frame includes standard nose pads. Nose pads are great for comfort and can also be adjusted for the perfect fit.
### What Type of Lenses do Oscar Wylee’s Gibbs Glasses Have?
The type of lenses that typically come with the Oscar Wylee Gibbs frame are optical lenses. Optical lenses are glasses lenses that have a prescription within the lens to help correct vision issues such as myopia, hyperopia and astigmatism. Gibbs glasses can also come with non-prescription lenses, with add-ons such as a blue light filter. Gibbs frames are currently unavailable as sunglasses online, however, customers can customise in-store and add on tint or polarisation.
### What Material is Used for the Rim of Oscar Wylee’s Gibbs Glasses?
The material used for the rim of Oscar Wylee’s Gibbs glasses frames is stainless steel. The rim refers to the part of a glasses frame that holds the lenses.
### What Type of Hinges are Included with Oscar Wylee’s Gibbs Glasses?
The type of hinges included with Oscar Wylee’s Gibbs frames are spring hinges. A spring hinge in a glasses frame refers to hinges that are more flexible than normal hinges and can go slightly beyond 90 degrees. Spring hinges can provide a closer fit to the face.
## What Face Types are Most Suitable for Oscar Wylee’s Gibbs Glasses?
The face types that are most suitable for Oscar Wylee’s Gibbs frame are round and oval face types. The Gibbs frame is a rectangle shape, meaning that it complements the structure of round and oval faces particularly well. The Gibbs frames help to balance the features of an [oval face shape or a](https://www.oscarwylee.com.au/glasses/face-shapes/oval)[round face shape, bringing the eyes and brows forward in a flattering way. Although there are many](https://www.oscarwylee.com.au/glasses/face-shapes/round)[glasses for face shapes that may be considered more aesthetically suitable, it is important that people also choose the frames that make them feel most comfortable, and represent their personal style.](https://www.oscarwylee.com.au/glasses/face-shapes)
## What Size Options are Available for Oscar Wylee’s Gibbs Glasses?
The size options available for Oscar Wylee’s Gibbs frame are a medium-frame fit across all colours.
## What Materials are Used to Create Oscar Wylee’s Gibbs Glasses?
The primary material used to create the Oscar Wylee Gibbs frame is metal. The rim is made out of stainless steel and the nose bridge and temples are made from cupronickel, which is an alloy of copper and nickel. Finally, the temple tips are made from acetate. Acetate, also known as cellulose acetate, is a bioplastic, made from cotton fibres or wood pulp.
## What’s Included
## What's Included
Each pair of glasses comes with a stylish frame case and lens cloth. We offer free shipping across Australia and 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects.
* Free Shipping for Australian Orders
* 1 Year Warranty on frames and lenses
* Scratch resistance lens coating on all prescriptions
* UV-proof coating on all prescriptions
* Stylish case and cloth
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
## Make and Materials
The frames then go through cleaning and strict quality control, and many pairs of crafting hands to be hand-assembled and polished. After your frames have gone through the production process, they are individually examined and&nbsp;packed before making their way to you!As part of our durable frame family, some of our most popular styles, are now in stainless steel. These frames are hypoallergenic, corrosion resistant, light weight, and not sensitive to temperature changes.
                            
## Warranty Information
### Warranty Information
### Warranty Information
Oscar Wylee provides a 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects. We will repair or replace faulty or defective frames or lenses free of charge for warranty claims made within 1 year of the delivery. We also offer repairs or replacement for problems experienced with vision during everyday use for claims made within 30 days of delivery. If the same product has been discontinued or is no longer available, then we may offer an exchange for a similar product or a refund.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Find a Store Location](https://www.oscarwylee.com.au/locations/full-store-list.html)
Recommended
1. [](https://www.oscarwylee.com.au/dusty-optical.html)
[Dusty](https://www.oscarwylee.com.au/dusty-optical.html)
Satin Orion Grey
2. [](https://www.oscarwylee.com.au/brody-optical.html)
[Brody](https://www.oscarwylee.com.au/brody-optical.html)
Silver
3. [](https://www.oscarwylee.com.au/cole-optical.html)
[Cole](https://www.oscarwylee.com.au/cole-optical.html)
Brushed Ash