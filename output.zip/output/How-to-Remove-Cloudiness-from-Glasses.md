# Source: https://www.oscarwylee.com.au/glasses/how-clean-cloudy-glasses

# How to Remove Cloudiness from Glasses
Published on November 13th, 2025
Updated on Month Date, 2025 
Australia
[Australia](https://www.oscarwylee.com.au/glasses/how-clean-cloudy-glasses)
New Zealand

[Canada](https://oscarwylee.ca/glasses/how-clean-cloudy-glasses)
Canadian French

To remove cloudiness from glasses you should first wash your hands, rinse your glasses under lukewarm water, dry with
a microfibre cloth, spray lens cleaner on the lenses, buff the lenses with
the microfibre cloth.
These tips are thorough for removing cloudiness from glasses, to ensure a
clean and clear lens providing optimal visual clarity.
Prioritise Your Eye Health at Oscar Wylee
Oscar Wylee optometrists are available to perform high quality eye tests,
bulk billed for eligible Medicare card holders.
[Eye test near me](https://www.oscarwylee.com.au/booking)
[Why Glasses Get Cloudy](#Cloudy)
[Reasons for Fogginess](#Fogginess)
[Preventing Cloudiness](#Cloudiness)
[Deep Cleaning Eyeglasses](#Eyeglasses)
To remove cloudiness from glasses you should first
wash your hands, rinse your glasses under lukewarm water, dry with a
microfibre cloth, spray lens cleaner on the lenses, buff the lenses
with the microfibre cloth. The steps to remove cloudiness from glasses are listed below.
* Wash Your Hands:
Wash your hands to ensure clean handling of the frames.
* Rinse Glasses Under Lukewarm Water: Rinse glasses under lukewarm water to get rid of initial
debris
* Apply a Drop of Mild Dish Soap: Apply a drop of mild dish soap to help remove cloudiness and dust.
* Rinse Thoroughly Again: Rinse thoroughly again to remove dish soap
* Dry with a Microfibre Cloth: Dry your glasses with a microfibre cloth to remove remaining
liquid.
* Use Lens Cleaner: Use lens cleaner to add a shine to your
glasses.
## 1. Wash Your Hands
Wash your hands
thoroughly with soap for 20 seconds under running tap water. This will
ensure your glasses are handled in a cleanly fashion.
## 2. Rinse Glasses Under Lukewarm Water
Rinse glasses under lukewarm water to get rid of initial debris and
cloudiness.
You will want to do this under a gentle stream of lukewarm water. Hot
water is likely to damage any lens coatings you may have. Cold water
may be used however lukewarm water is more preferred.
## 3. Dry With A Microfibre Cloth
Dry your lightly rinsed glasses with a microfibre cloth.
A microfibre cloth is the best drying method as it is a sensitive
material, unlikely to cause abrasions to your lenses.
## 4. Spray Lens Cleaner on the Lenses
Spray lens cleaner on the lenses generously. At Oscar Wylee, we offer
high quality lens cleaners to prevent cloudy or dirty lenses.
## 5. Buff Lenses with Microfibre Cloth
Buff and shine your lenses with a microfibre cloth for a finishing
gleam to your lenses. This will be the final step to ensuring a clear
lens free from cloudy residue.
Prioritise Your Eye Health at Oscar Wylee
Oscar Wylee optometrists are available to perform high quality eye
tests, bulk billed for eligible Medicare card holders.
[Optometrist near me](https://www.oscarwylee.com.au/locations/full-store-list.html)
## Why Do My Glasses Get Cloudy or Hazy Over Time?
Glasses can get cloudy or hazy over time mainly due to weather conditions. Dusty, foggy&nbsp; or polluted conditions can lead to a build up of
debris and fog up the lenses of your glasses. Even breathing, namely
heavy breathing or mouth breathing, can lead to foggy glasses.
### What Causes a White Film to Form on Eyeglass Lenses?
A white film can form on eyeglass lenses if they are cleaned with soaps or other substances with harsh
chemicals. Harsh soaps and liquid cleaners should never be used when
cleaning eyeglass lenses as these can strip lens coatings and lead
to a white film forming. Instead, mild, fragrance-free and
lotion-free soaps are more gentle and effective for cleaning. Makeup
and oils can also lead to a white film if they consistently rub off
on your lenses. To combat the formation of a white film, it is
important to clean your [prescription glasses](https://www.oscarwylee.com.au/glasses/prescription) regularly.
### Why are My Glasses Foggy Even After Cleaning?
Your glasses may be foggy even after cleaning due to residual moisture, damaged lens coating or face oils
that transfer onto your frames. The reasons for glasses being foggy
even after cleaning are listed below.
1. Residual Moisture:
Residual moisture from the liquid cleaner and water used to clean
your lenses may still be present on the surface. Ensure it is
wiped down thoroughly to avoid the lenses fogging up.
2. Damaged Lens Coating: A damaged lens coating may mean glasses are foggy after cleaning.
Reasons include frames having contact with hot or warm water or
harsh cleaning products. This can lead to crazing which is where a
web of tiny cracks that can appear on the lenses, often leading to
cloudiness.
3. Face Oils: Face oils emerge from oily skin and even oils from makeup
products. These can transfer to your glasses lenses and create a
film of grime, contributing to a foggy frame.
### Why do My Glasses Get Greasy or Smudged So Easily?
Your glasses can get greasy or smudged easily due to factors such
as handling with unclean hands, face oils and condensation from
breath. Ensure you are handling your glasses with clean hands and
avoiding touching the lenses, instead handling them through the
temples. Face oils and condensation from the breath will happen
naturally as you wear the glasses, particularly on days with extreme
weather conditions. It is important to have your lens cloth on hand
so you can wipe your lenses gently whenever there is grease present,
to avoid build-up.
### Why Do Polycarbonate Lenses Become Cloudy?
Polycarbonate lenses can become cloudy due to the environment they
are worn in. Polycarbonate lenses are glasses lenses made from a type of
thermoplastic that is thin, lightweight and impact resistant. These
properties make polycarbonate lenses desirable for children’s
eyewear, safety glasses and sports goggles. Safety glasses for
example are worn in environments such as woodworking spaces or
gardening, leaving them exposed to elements such as dust, debris and
fog. As a result, the polycarbonate lenses on these glasses can
become cloudy and foggy.
## What Should You Avoid When Cleaning Glasses with a Coating?
You should avoid hot water, alcohol based cleaning products and abrasive
materials when cleaning glasses with a coating. This also applies to every type
of glasses lens, not solely glasses with a coating. Read more about
the things to avoid when cleaning glasses with a coating.
* Hot Water: Hot water is not good for cleaning glasses with a coating. Hot
water can damage lens coatings and even warp the frame material of
your glasses. Stick to lukewarm water.
* Alcohol Based Cleaning Products: Alcohol based cleaning products should not be used when cleaning
glasses with a coating. These are too strong and can damage the lens
coatings. Instead use a mild, fragrance-free and lotion-free dish
soap to gently clean the lenses.
* Abrasive Materials:
Abrasive materials should not be used when drying the glasses after
cleaning, such as paper towels or hand towels. Instead, use a
microfibre cloth to dry the lenses as this is a gentle material.
### What is the Safest Way to Clean Plastic or Polycarbonate Lenses?
The safest way to clean plastic or polycarbonate lenses is with lens cleaner and a microfibre cloth.
This can be done regularly and the safest and easiest way to clean
lenses. Simply spray the surface of the lens with a lens cleaner,
such as the Oscar Wylee lens cleaner, and rub and buff it gently
with a microfibre cloth.
## How Can You Prevent Glasses From Getting Cloudy Again?
You can prevent glasses from getting cloudy by cleaning your glasses regularly with lens cleaner and a microfibre
cloth. Preventing cloudiness can happen when you regularly clean lenses with
a generous amount of lens cleaner, alongside wiping them with a
microfibre cloth. If there is a build-up that is hard to clean, gently
washing under lukewarm water alongside the lens cleaner might be
effective. You might like to try an anti-fog spray as a preventative measure to
ensure your glasses don't get cloudy easily. While it is unlikely you
will never have foggy glasses again after implementing measures such
as these, they will ultimately be less likely to fog if there is
regular care.
### How Often Should You Deep Clean Your Eyeglasses?
You should deep clean your eyeglasses at least once a week or
whenever necessary depending on how often they are used. This will encompass gently washing your frames and potentially
using a mild dish soap for cleaning the frames. For the lenses you
should generously spray them with a lens cleaner and buff them with
a microfibre cloth. For a quicker clean to maintain your eyeglasses
lens quality, you should wipe your lenses daily at minimum, or when
they start to get dirty or smudged.
#### Can Improper Cleaning Make Eyeglasses Look Cloudy Permanently
Yes, in some cases improper cleaning can make eyeglasses look
cloudy permanently. For example, if you use cleaner with harsh chemicals this can
lead to a cloudy film forming over the lenses. However, it may not
be permanent damage in all cases if improper cleaning occurs, and
cloudiness may just be a temporary issue. Check out this article for more tips on [how to clean glasses](https://www.oscarwylee.com.au/eye-care/guides/how-to-clean-glasses).
#### Can Super Glue Make the Eyeglasses Cloudy?
Yes, super glue can make eyeglasses lenses cloudy.
Superglue may be used by people to repair glasses if there are
damaged parts, despite this being an unreliable method. Some of
this superglue can rub off on the lenses and as a result turn them
cloudy. To remove super glue from eyeglasses, mild, soapy water might be
the gentlest and safest option.
Read How to Clean Cloudy Eyeglasses in other Oscar Wylee regions and
their languages.
Australia
[Australia](https://www.oscarwylee.com.au/glasses/how-clean-cloudy-glasses)
New Zealand

[Canada](https://oscarwylee.ca/glasses/how-clean-cloudy-glasses)
Canadian French

Take Care of Your Eyes at Oscar Wylee
It is recommended that you have an eye test with an optometrist at
least once every 2 years, unless otherwise advised. Book your eye test
at Oscar Wylee today.
[Book an Eye Test](https://www.oscarwylee.com.au/booking)
Oscar Wylee Accepts Major Health Funds In-store
Visit Oscar Wylee in-store for eye care services and your health fund
may help cover some of the cost.
[Explore Health Funds](https://www.oscarwylee.com.au/health-funds.html)