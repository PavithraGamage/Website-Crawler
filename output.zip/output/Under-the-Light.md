# Source: https://www.oscarwylee.com.au/sunglasses/collection/under-the-light.html

# Under the Light Eyewear Collection
## For the ones who don’t just want to show up, but shine.
Introducing Under the Light, a collection of glasses for the ones
who don’t just want to show up, but shine. Featuring oversized
classics and trend-centred silhouettes. These frames channel
confidence, glamour and effortless sophistication. Under the Light
brings you eyewear intended for high exposure and to elevate you.
Check out the
[Under the Light lookbook.](https://www.oscarwylee.com.au/pub/media/wysiwyg/pdf/Oct25-Under-the-Light-Public-Lookbook.pdf)
15 Products        
Showing 15
1. [](https://www.oscarwylee.com.au/cruz-sunglasses.html)
[Cruz](https://www.oscarwylee.com.au/cruz-sunglasses.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/cruz-sunglasses.html)
[3 pairs from $249](https://www.oscarwylee.com.au/cruz-sunglasses.html)
2. [](https://www.oscarwylee.com.au/amelia-sunglasses.html)
[Amelia](https://www.oscarwylee.com.au/amelia-sunglasses.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/amelia-sunglasses.html)
[3 pairs from $249](https://www.oscarwylee.com.au/amelia-sunglasses.html)
3. [](https://www.oscarwylee.com.au/shae-sunglasses.html)
[Shae](https://www.oscarwylee.com.au/shae-sunglasses.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/shae-sunglasses.html)
[3 pairs from $249](https://www.oscarwylee.com.au/shae-sunglasses.html)
4. [](https://www.oscarwylee.com.au/ash-sunglasses.html)
[Ash](https://www.oscarwylee.com.au/ash-sunglasses.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/ash-sunglasses.html)
[3 pairs from $249](https://www.oscarwylee.com.au/ash-sunglasses.html)
5. [](https://www.oscarwylee.com.au/jessie-sunglasses.html)
[Jessie](https://www.oscarwylee.com.au/jessie-sunglasses.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/jessie-sunglasses.html)
[3 pairs from $249](https://www.oscarwylee.com.au/jessie-sunglasses.html)
6. [](https://www.oscarwylee.com.au/duckworth-sunglasses.html)
[Duckworth](https://www.oscarwylee.com.au/duckworth-sunglasses.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/duckworth-sunglasses.html)
[3 pairs from $249](https://www.oscarwylee.com.au/duckworth-sunglasses.html)
7. [](https://www.oscarwylee.com.au/anela-sunglasses.html)
[Anela](https://www.oscarwylee.com.au/anela-sunglasses.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/anela-sunglasses.html)
[3 pairs from $249](https://www.oscarwylee.com.au/anela-sunglasses.html)
8. [](https://www.oscarwylee.com.au/easten-sunglasses.html)
[Easten](https://www.oscarwylee.com.au/easten-sunglasses.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/easten-sunglasses.html)
[3 pairs from $249](https://www.oscarwylee.com.au/easten-sunglasses.html)
9. [](https://www.oscarwylee.com.au/christina-sunglasses.html)
[Christina](https://www.oscarwylee.com.au/christina-sunglasses.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/christina-sunglasses.html)
[3 pairs from $249](https://www.oscarwylee.com.au/christina-sunglasses.html)
10. [](https://www.oscarwylee.com.au/olivia-sunglasses.html)
[Olivia](https://www.oscarwylee.com.au/olivia-sunglasses.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/olivia-sunglasses.html)
[3 pairs from $249](https://www.oscarwylee.com.au/olivia-sunglasses.html)
11. [](https://www.oscarwylee.com.au/gaia-sunglasses.html)
[Gaia](https://www.oscarwylee.com.au/gaia-sunglasses.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/gaia-sunglasses.html)
[3 pairs from $249](https://www.oscarwylee.com.au/gaia-sunglasses.html)
12. [](https://www.oscarwylee.com.au/gisele-sunglasses.html)
[Gisele](https://www.oscarwylee.com.au/gisele-sunglasses.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/gisele-sunglasses.html)
[3 pairs from $249](https://www.oscarwylee.com.au/gisele-sunglasses.html)
13. [](https://www.oscarwylee.com.au/jett-sunglasses.html)
[Jett](https://www.oscarwylee.com.au/jett-sunglasses.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/jett-sunglasses.html)
[3 pairs from $249](https://www.oscarwylee.com.au/jett-sunglasses.html)
14. [](https://www.oscarwylee.com.au/laura-sunglasses.html)
[Laura](https://www.oscarwylee.com.au/laura-sunglasses.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/laura-sunglasses.html)
[3 pairs from $249](https://www.oscarwylee.com.au/laura-sunglasses.html)
15. [](https://www.oscarwylee.com.au/duckworth-optical.html)
[Duckworth](https://www.oscarwylee.com.au/duckworth-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/duckworth-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/duckworth-optical.html)
15 Products        
Showing 15
Theme The Frames Choosing Glasses From Under the Light Pricing and Shipping
## What is the Theme of Under the Light?
The eyewear collection theme “Under the Light” centres around the concept of stylish sunglasses that cover you, whether it’s from camera flashes or the sun. This sunglasses collection is reminiscent of a timeless movie star's glamour when they’re making their way through the paparazzi, often having to shield their eyes from all the flashing lights. Under the Light intends to capture the true essence of glasses that are not only perfect for optimal sun protection but also to exude a high-profile and sophisticated look.
### What is the Fashion Inspiration Behind Under the Light Collection?
The fashion inspiration behind Oscar Wylee’s eyewear collection, “Under the Light,” comes from the idea of being the best dressed in the room and having all eyes on you, ready for whatever life throws at you. Celebrities are often photographed out and about, donning casual, market-ready outfits, elevated streetwear styles, or serving office-core, off-duty model vibes, weekend brunch energy and everything in between and always paired with the perfect frame to complete the fit. Frames from Under the Light are crafted to capture just that and elevate you.
## What are the Frame Options from Under the Light Collection?
The frame options that are available from Under the Light collection include the Gaia frame, Cruz frame, Gisele frame, Shae frame, Ash frame, the Laura frame and colour extensions for Amelia, Anela, Christina, Duckworth, Easten, Jessie, Jett and Olivia. The frame options from Under the Light collection are listed below.
* Gaia:  Amongst the glitz and glamour, Gaia is your bodyguard, reliable and trusty with unobtrusive silicone nosepads. A classic oversized shape coupled with gold rivets and embellishments, Gaia is born for the spotlight.
* Cruz:  The sleek, oval Cruz will keep you sun-protected and camera-ready. Featuring a metallic logo and accommodating silicone nosepads, Cruz commands attention in any space.
* Gisele:  Gisele brings a timeless charm with its striking aviator shape. The oversized frame is the ultimate protector from the flashing camera lights.
* Shae:  Shae has got you covered from both the sun and camera flashes. Shae’s oversized cat-eye and metal temple embellishments have a classic movie-star allure, making you red carpet ready!
* Ash:  Ash knows how to keep her cool. These subtle geometric frames, coupled with metallic temple detailing, are effortlessly glam, perfect for braving the heat and the spotlight.
* Laura:  Laura is a classic oversized beauty with metal embellishments on the temples alongside a luxe logo for a chic flair. Laura protects from the sun and is poised for the camera.
* Amelia:  Our familiar Amelia frame is now available in a trendy Butterscotch Tortoise colour. Amelia’s classic cat-eye shape truly captures the essence of frames designed for the spotlight.
* Anela:  Anela is a classic frame now available in a brilliant Gold Amethyst colourway, a bold and perfectly glamorous look for any occasion.
* Christina:  Our beloved Christina frame, available in Cioccolato, boasts a bold rectangular frame designed to be the finishing touch on any look.
* Duckworth:  The Duckworth frame is a unisex, aviator glasses frame to elevate you and is now available in more colours, Cioccolato, Seaside and Blonde Tortoise.
* Easten:  The Easten frame embodies timeless elegance and sophistication, a look for the lights and sleek coverage under the sun, now available in Beryl Tortoise, Chocolate Chip and Brown Dapple.
* Jessie:  There’s even more to love about Jessie with more colourways to help you thrive in the spotlight, now available in Panther and Cacao Tortoise
* Jett:  Jett is a go-to with its simple but essential rectangle frame design, now available in Navy Forest.
* Olivia:  See the Olivia frame in another light, now available in Chocolate Chip, serving a timeless and high-profile look.
### What are the Materials of the Glasses From Under the Light Collection?
The materials of the glasses from Under the Light include bioacetate, metals and TR90. The materials of glasses from Under the Light are listed below.
* Bioacetate:  Bio-acetate is a material mainly made from plant-based matter such as wood pulp and cotton fibres. Bio-acetate is notable for being a more sustainable material as it uses fewer oil-based plasticisers in its creation compared to regular acetate.
* Metals:  Metals such as stainless steel, titanium, and memory metal. These materials provide durability and strength, making them particularly long-lasting. Some types of metal, such as titanium, are renowned for being lightweight and having a certain amount of natural flexibility.
* TR90: TR90 is a thermoplastic material known for its optimal flexibility, lightweight nature, and durability. This high-tech material helps provide comfortable and resilient frames that can be more resistant to daily wear and tear than frames made from other materials
#### What are the Colours and Colour Patterns of the Frames From Under the Light?
The colours of the frames from Under the Light include varying brown shades, black, blue and different tortoise patterns.
### How to Choose Glasses From Under the Light?
To choose glasses from Under the Light, choose the style of frame that fits and suits you best by trying on different options. To know if a frame fits you appropriately, the frame width typically shouldn’t exceed your temple width or extend above your eyebrows. They should sit comfortably on your nose without slipping, especially when looking downwards. Dare to go bold or create a seamless match between your frames and fit, glasses from Under the Light offers options for both!
### How to Choose Glasses From Under the Collection According to the Nose Bridge?
To choose glasses from Under the Light according to nose bridge, identify your nose bridge type, choose frames for your nose bridge type and prioritise comfort. Under the Light offers glasses with a low nose bridge and a high nose bridge. The steps on how to choose glasses according to the nose bridge are listed below.
1. Identify your nose bridge type:  Identify your nose bridge type by seeing if the level of your nose bridge aligns with or is below your pupils, which may indicate a low nose bridge. If your nose bridge is elevated away from the face and more pronounced in appearance, then this is characteristic of a high nose bridge.
2. Choose frames for a low nose bridge:  Choose frames for a low nose bridge by opting for frames that feature deeper nose pads, a narrower nose bridge to potentially avoid pinching at the bridge.
3. Choose frames for a high nose bridge:  Choose frames for a high nose bridge by opting for frames that sit high on the nose or closer to the browline.
4. Prioritise comfort:  Prioritise comfort when choosing the best square glasses by ensuring your chosen frame sits securely on your nose bridge and doesn’t slide down your nose
## How to Choose Glasses from Under the Light by Oscar Wylee According to Width?
Choosing glasses from Under the Light is a simple process and depends on your personal preferences. There are many glasses available in differing widths to accommodate a range of face sizes. These width sizes include Narrow, Medium or Wide. The list of frame widths available in this collection are listed below.
* Narrow:  Under the Light features the Christina frame, which is a narrow width option, good for petite and narrow faces.
* Medium:  Under the Light features Gaia, Shae, Anela, Jessie, which are medium-width options available in a range of colours and shapes. Medium frames are well-suited to those with average or medium-sized faces.
* Wide:  Under the Light features Gisele, Laura, Cruz, Ash, Amelia, Duckworth, Easten, Jett and Olivia, which are a wide width option. Wide frames are good for those with wider, larger faces.
## What are the Price Factors For Glasses From Under the Light?
The price factors for glasses from Under the Light will vary depending on the range of glasses, add-ons and lens types. One pair of glasses at Oscar Wylee starts from $169, 2 pairs from $199 and 3 pairs from $249. It should be noted that lens thickness and other add-ons will affect overall pricing.
### What is the Duration of Shipment for Oscar Wylee Glasses?
The average shipping duration for glasses at [Oscar Wylee](https://www.oscarwylee.com.au/) is typically within 7-10 business days. An email will be sent to you confirming the order alongside an order tracking link.
[Prescription Glasses](https://www.oscarwylee.com.au/glasses.html)
[Women’s Glasses](https://www.oscarwylee.com.au/glasses/collection/womens-glasses.html)
[Men’s Glasses](https://www.oscarwylee.com.au/glasses/collection/mens-glasses.html)
[Senior Glasses](https://www.oscarwylee.com.au/glasses/collection/seniors.html)
[Glasses for Kids](https://www.oscarwylee.com.au/glasses/collection/kids-collection.html)