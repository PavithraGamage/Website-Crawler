# Source: https://www.oscarwylee.com.au/locations/optometrist-southport.html

# Optometrist Southport
Australia Fair Shopping CentreTenancy G077, 42 Marine ParadeSouthport QLD 4215
* Opposite Goldmark
Opening hours
Monday9:00am - 5:30pm
Tuesday9:00am - 5:30pm
Wednesday9:00am - 5:30pm
Thursday9:00am - 7:00pm
Friday9:00am - 5:30pm
Saturday9:00am - 5:00pm
Sunday10:00am - 4:00pm
*Store hours reflect local standard trading hours and exclude public holidays
[Visit our Australia Fair Google Business page for directions, reviews, and updates.](https://g.page/r/CfnQUp9M44ygEAE)
Book Appointment
[Call us: (07) 5661 1102](tel:(07) 5661 1102)
[Leave a Review!](https://g.page/r/CfnQUp9M44ygEAE/review)
Our Reviews
liz Williams
4 days ago
Amazing service by all the staff .Very friendly and efficient.  Loved Ellie as she was so helpful wi...th the  selection of my glasses , she explained everything about my new transition lenses . Such a bubbly friendly lady . She organised for my glasses to be sent to my home state .
See more
praveen singh
5 days ago
Very good
Ian Maxwell
1 week ago
Excellent refraction (bulk billed) Rachel Nguon
Charming and efficient receptionist
No sneaky extra ...cost
Good advice and print out of refraction (never had that before) Usually kept (to entrap you).
Trustworthy +++
****** 6 stars  Very happy to recommend
Dr Ian Maxwell
See more
Min Zhu
1 week ago
Michelle O'Neill
2 weeks ago
Rachel was just so thorough and so lovely
Shelley O'Sullivan
3 weeks ago
Everyone friendly and very helpful. I've been a few years now. Can't fault their service.
Lance Meredith
1 month ago
Excellent. Very friendly, knowledgeable, professional staff. Thorough consultation, no upsells, High...ly recommend.
See more
Karlene Teao
1 month ago
I had the best service from the two lovely ladies at Oscar Wyler today. From the minute I walked in ...they were so
Friendly and helpful. The optometrist was lovely and explained everything to me.
Then the lovely lady helping me choose my glasses was lovely too. Very helpful and knowledgeable.
See more
沈敏
1 month ago
The staff is very attentive and gentle. Perfect
Lívia Goulart
1 month ago
Paul Duncan
1 month ago
Good service, friendly staff and very efficient service, will happily return when I need help with m...y eyes again
See more
Pei-Ying Hsieh
1 month ago
S
1 month ago
Nayara Miranda
1 month ago
I just to thank Lana for her amazing service today, she is so nice and kind!
Trunknet Trunknet
1 month ago
Elaine S
2 months ago
Thank you to the lovely ladies at Oscar Wylee Australia Fair. I had a great experience as soon as I ...entered the store. I was welcomed by the Store Manager, Ellie, who arranged my smooth check in. My consult with the optometrist Rachel was also appreciated as she took the time to listen to my concerns and check everything in detail. It is not often that you can experience old fashioned quality service from a retail store. I really felt they cared. I have now collected my glasses and am loving the frames. Definitely going back each year for my annual check ups!!
See more
Vera Crema
2 months ago
Professional and perfect
Happy with my glasses, Staff are friendly proficient and very helpful defin...itely recommend Oscar Wylee Australia Fair
See more
Ty Phan
2 months ago
The front staff and optometrist were so welcoming and professional!!
Lola Watson Tan
2 months ago
Staff are so friendly, there's an incredible choice of frames that are well made, stylish, and my or...der came within a week. The eye test process is the quickest and easiest one I've ever done, I never feel rushed or judged when comparing different lenses and all the assistance when choosing my frames really makes the experience stand out against other optometrist experiences.
See more
Camila Molina
2 months ago
Everyone was lovely and I had the best of the experiences.
Lana Watson Tan
2 months ago
Always excellent customer service,  thorough and professional eye examinations and fantastic range o...f frames to choose from! I love my local Oscar Wylee store at Australia Fair - wouldn't go anywhere else!
See more
Janine Clark
2 months ago
Very professional and helpful
delta lin
2 months ago
Sandeep Kaur
2 months ago
Experiences was great. Everyone was really helpful.
Yue Leong
2 months ago
The staff were extremely helpful and friendly throughout my visit. Rachel, the optometrist, was high...ly professional and guided me through every step of the eye examination process. The team also provided excellent assistance in helping me choose a pair of glasses that I absolutely love. Overall, it was a fantastic experience, and I will definitely be returning for my next eye check-up and glasses selection. Highly recommended!
See more
Lynette Adamson
3 months ago
I had, had an eye test at a well known optometrist chain a few months ago but was not happy with the... results.
Yesterday I popped into Oscar Wylee at Australia Fairto just check out their range of eyewear.
I told them I was not happy with my previous eye test and they did another one for me with very different results.
I was able to buy 3 pairs of very stylish glasses from their extensive range for $249.
Lovely staff and very helpful.
I will certainly return there next year.
See more
Chris Pirika
3 months ago
Lovely ladies at the Australiafair shop.  Very supportive and helpful when choosing glasses felt ver...y comfortable. Also the eye testing was very caring and gentle. Totally recommend Oscar Wylee Southport
See more
Tas Net
3 months ago
Easy to book online with not many details required. Lady at reception was pleasant but was having to... deal with an unhappy customer when I arrived for my eye test appointment. Optometrist Vanshika Kumar was lovely but the booked appointment was quite disorganised as I was unable to have my peripheral vision test, due to the reception lady being too busy with 2 other clients. I was asked to come back later which I couldn’t do, so a further time was rebooked in a week. I have since cancelled this, as it’s just not convenient. They were kind enough to email my updated script. I try to give the smaller companies business but unfortunately will be returning to the global one as they seem more organised. Sorry!
See more
Noriyuki Yamaguchi
3 months ago
The explanation was easy to understand and very helpful.
Dennis Bellini
3 months ago
Great personal attentive service
Lionel Turnbull
3 months ago
Service was excellent, would recommend  it to my mother.
Rebecca Taylor
4 months ago
Staff were welcoming and friendly. Good first time experience at the optometrist ????????
ping sun
4 months ago
Neil McKay
5 months ago
I received exceptionally courteous, professional and friendly care from the ophthalmologist at Oscar... Wylee Optometrist in Australia Fair, Southport; they took the time to explain each step clearly, demonstrated genuine attentiveness throughout the consultation, and created an experience that felt both reassuring and highly competent, leaving me with full confidence in the quality of their service,
See more
kaitlyn frear
5 months ago
Summer Flynn
5 months ago
The optometrist was excellent ????
Annie Siu
5 months ago
Mechel Gilo
5 months ago
wendy xu
5 months ago
Patricia Hyman
5 months ago
Excellent Wellcome Reception on Arrival
Examination Process  explained
Optometrist very Through &amp; Co...nfident
Thank you Patricia
See more
Victor Olaria Martinez
5 months ago
Muqsit Rawoot
6 months ago
Efficiency was tops. What I appreciated the most is that they were honest and didn’t push me to get ...a prescription. I was told that there is no urgency for a prescription and that I should continue to do regular eye test. I highly recommend visiting these guys at the Australia Fair branch.
See more
Glenis Frawley
6 months ago
Brad Mulligan
6 months ago
Optometrist Michelle Lee and receptionist
were busy but first rate.
Kelly Lucena
6 months ago
Excellent job! ✨
Tom Gerrard
7 months ago
Great service and staff polite and very professional
Li Jenny
7 months ago
The staffs at Oscar Wylee Optometrist, Australia Fair Southport, are very friendly and provided help...ful suggestions. Highly recommended!
See more
Rose Scheerlinck
7 months ago
Katrina Urquhart
7 months ago
Always love getting my test here so efficient and easy.
Kimmee kay
7 months ago
The examiner was very professional. Delightful actually. The range of glasses was decent but pricey ...plus they didnt even have one pair of semi frames which is the only ones I use.
See more
## Find an Optometrist in Southport - Australia Fair With Oscar Wylee
Located on the ground floor of Australia Fair Shopping Centre, Oscar Wylee Southport is across from Goldmark and is close to the food court. Our beautiful range of stylistic frames covers almost every aesthetic, whether you are looking for chunky modern with a pop of colour or a classic vintage with a feminine feline flick! With Medicare, bulk billed eye tests, acceptance of all major health funds and our international student eye test special, you can have it all at Oscar Wylee Southport! Australia Fair has 2-hour parking and is accessible by G-Link trams within walking distance of the centre. 
Australia Fair is located only 2 km away from the stunningly scenic Surfers Paradise and has gorgeous views of the beach, inside and outside the main centre. When you have finished browsing our wide, trendy and inclusive collection, you can explore everything this by-the-sea suburb has to offer. Come in and see the team to experience some of the best eye care processes in Southport, Australia. For those who live in the area, Oscar Wylee optometrists nearest to you include Oscar Wylee Pacific Fair.        
Meet Our Team
* Store Manager
Bachelor of International Business
* Optometrist
Our Services
* Bulk Billed Eye Examinations
* Professional Frame Styling
* Frame Adjustments and Repairs
* Visual Fields Testing
* Digital Retinal Scanning
Show All
## Find an Optometrist in Southport - Australia Fair, Gold Coast for an Eye Health Test
If you are looking for an optometrist in Southport - Australia Fair, Gold Coast, choose Oscar Wylee as we have dedicated optometrists who can provide high-quality eye tests. At Oscar Wylee Australia Fair, you can browse our wide range of optical glasses and prescription sunglasses at our glasses store. At Oscar Wylee Southport - Australia Fair in the Gold Coast, you can also receive assistance from an optical dispenser for your eyewear needs and concerns.
There won't be any need to see an eye doctor for your check-up, as our Oscar Wylee optometrists are qualified and trained so you can expect all the necessities of an eye health test in Southport - Australia Fair. An eye test typically involves checking eye movement, the health of a patient's vision and whether there are any signs of eye diseases. Our eye tests are available at a bulk billed price as part of Australia’s Medicare system so there are no out-of-pocket expenses for eligible Medicare cardholders. The average price range for an optometrist in Southport - Australia Fair can vary depending on factors such as the patient’s overall health, age and visual needs. Visit Oscar Wylee Australia Fair for all your eye care needs.
## How to Find an Optometrist in Southport - Australia Fair, Gold Coast?
To find an optometrist in Southport - Australia Fair, Gold Coast you can take certain steps that can help make it easier for you such as searching online, assessing the store’s opening hours and finding the directions to your chosen location. The steps on how to find an optometrist in Southport - Australia Fair are listed below.
1. Search online using the phrase, optometrist near me in Australia Fair. This can also be done here on the website via our locations page.
2. Click on the Oscar Wylee link, which will take you directly to our Southport - Australia Fair optometrist store page.
3. See the store’s opening hours and where the store is located specifically.
4. Use the Australia Fair Google Business page link located under store hours to see the directions on how to get to the store.
You can also find an optometrist in Southport by searching the keywords optometrist near me. If you have locations enabled on your smartphone and you’re in the Southport area, our Australia Fair store page should appear easily for you to click on.
### Is it Hard to Get an Eye Appointment in Southport - Australia Fair, Gold Coast?
No, it is not hard to get an eye appointment in Southport - Australia Fair. You can easily book an appointment to see an Oscar Wylee optometrist in Southport - Australia Fair right here on this page. At Oscar Wylee we have highly qualified optometrists available for bulk billed eye appointments, which can be booked online or in-store.
#### How to Compare Optometrists in Southport to Each Other?
To compare optometrists in Southport, you can use factors such as eye tests offered, health fund coverage, lens types and add-ons and eyewear offered. To take care of your vision and eye health, it is important to receive an eye test at least once every two years. There are different types of tests that can be performed in an eye test and not all optometrists may offer the same tests. Health funds can be used to help cover some of the cost of your frames and lenses. To find out if your health fund is accepted at an optometrist in Southport in the Gold Coast visit their website. In the case of Oscar Wylee, we accept all major health funds and provide on-the-spot claims in-store. There are many different lens options available for prescription glasses such as single vision, multifocal and high index lenses. Most optometrists in Southport will offer these lenses although it is good to make sure. There are also lens add-ons available to enhance your glasses such as anti-reflective and blue light filters. Finally, if you are looking to purchase a pair of glasses after your eye test, you can compare the different styles and colours you are interested in from Southport optometrists in the Gold Coast. Oscar Wylee offers a wide range of frames with vintage and modern inspirations in bold colours and subtle designs.
#### How to Find an Eyeglasses Shop in Southport, Gold Coast?
To find a glasses store in Southport - Australia Fair, you can try to follow these simple steps including searching online, selecting a convenient location and looking at their health insurance policies. The steps on how to find a glasses store in Southport, Gold Coast are listed below.
1. Search online using the phrase, glasses store in Southport. This will provide you with various options for glasses stores in the whole Southport, Gold Coast area.
2. Select a glasses store that is most convenient for you to travel to.
3. Click the link to find out more information such as opening hours, exact location and directions to the glasses store in Southport.
4. Read their health insurance policies to ensure you know what health benefits you have access to.
Our Oscar Wylee glasses store in Southport, Gold Coast offers primary eye care services such as comprehensive eye tests as well as other services performed by an optometrist and offers prescription and non-prescription eyewear.
##### Is it Possible to Purchase Prescribed Sunglasses in Southport - Australia Fair, Gold Coast Without Seeing an Optometrist?
Yes and no, it is possible to [purchase prescribed sunglasses](https://www.oscarwylee.com.au/sunglasses.html) in Southport - Australia Fair without seeing an optometrist if you already have a prescription that has not expired. If your prescription is expired, you can book an eye test to receive an updated or new prescription which will require you to see an optometrist. This will ensure your prescription sunglasses are appropriate for your visual needs.
## Where is the Oscar Wylee Southport - Australia Fair Optometrist in the Gold Coast Located?
The Oscar Wylee Southport - Australia Fair optometrist is located on the ground floor of the Australia Fair Shopping Centre opposite Goldmark and close to the food court. Our store in Australia Fair is 2km away from Surfers Paradise, known for its scenic beaches.
### What is the Phone Number of Oscar Wylee Australia Fair Optometrist Store?
The Oscar Wylee Australia Fair optometrist store phone number is (07) 5661 1102. You can contact the Oscar Wylee Southport - Australia Fair store between the hours of 9 am and 5:30 pm from Monday to Wednesday, 9 am and 7 pm on Thursdays, 9 am and 5:30 pm on Fridays, 9 am to 5 pm on Saturdays and 10 am and 4 pm on Sundays.
### What are the Reviews for Oscar Wylee Southport - Australia Fair Optometrist in the Gold Coast?
The many reviews for Oscar Wylee Southport - Australia Fair optometrist in the Gold Coast, left by our various customers can be found here on the website as well online when you search for Oscar Wylee Australia Fair optometrist. The reviews for Oscar Wylee Australia Fair optometrist are listed below.
* Angella Chidzungu:  Everyone was helpful and friendly, really enjoyed the experience. Thank you.
* Catherine Robertson:  The eye test was seamless and they have cool frames. Prices were lower than I expected.
* Linda Jackman:  Fantastic experience at the Australia Fair store. Both the optometrist and receptionist were amazing. Friendly, welcoming and helpful.
* Jessica Sheffield:  Excellent optometrist. Eye test and check were very good and David the optometrist explained things and was very helpful. Customer service was great and very helpful with choosing frames.
#### What Treatments or Eye Care Processes are Done in the Oscar Wylee Southport - Australia Fair Optometrist Location?
The treatments or eye care processes done in the Oscar Wylee Southport - Australia Fair optometrist, Gold Coast location include a tonometry test, a digital photograph, a slit lamp exam and a refraction test. Additional tests that may also be performed can include a visual field test and a dilated fundus exam. The treatments or eye-care processes that are done in the Oscar Wylee Southport - Australia Fair optometrist, Gold Coast location are listed below.
* A Tonometry Test: An optometrist or optical dispenser will conduct a tonometry test which involves the use of a machine that will release small puffs of air into your eyes. This will assist with measuring pressure in the eye.
* A Digital Photograph: An optometrist or optical dispenser may take a digital photograph of your eye which can be kept on record to use in future appointments to evaluate any changes to your eye.
* Slit Lamp Test: A slit lamp test can be used to evaluate your eye health, by examining your cornea and iris which are the anterior and posterior of the eye.
* Refraction Test: During a refraction test, an optometrist will have you view an image through different lenses and ask you to confirm which helps you see the image clearer.
* Visual Field Test: A visual field test can assist with assessing your peripheral vision, which may be beneficial for identifying any signs of glaucoma.
* Dilated Fundus Exam: A dilated fundus exam can help an optometrist assess your health in more detail by getting a clear view of the retina. This test is typically carried out for patients with diabetes and those who may be at risk of developing retinal damage.
## How Many Optometrists Exist in Southport, Gold Coast?
There are many optometrists that exist in Southport to provide eye tests and glasses, including Oscar Wylee. The amount of optometrists available in an area will typically depend on the population. At Oscar Wylee Australia Fair in Southport, we offer excellent optometry services including eye tests performed by skilled optometrists using high-quality equipment. We also have a wide range of fashion-forward frames that customers can browse in a large selection of sizes and colours. If you’re looking for an optometrist in Southport, choose Oscar Wylee and we will take care of your optometry and eyewear needs.
### What are the Other Closest Optometrist Locations to Southport, Gold Coast in Australia?
The other closest Oscar Wylee optometrist locations to Southport in Australia are Helensvale, Pacific Fair and Robina. The locations and their distance from Southport are listed below.
* Helensvale:  Helensvale is close to Southport, around 12-13 km. The [Oscar Wylee Helensvale](https://www.oscarwylee.com.au/locations/optometrist-helensvale.html) store is located in Westfield Helensvale, opposite Cotton On. Our Helensvale optometrists are available to provide Medicare, bulk billed eye tests and you can also browse our wide range of products.
* Pacific Fair:  Pacific Fair is close to Southport, around 10-12 km. The [Oscar Wylee Pacific Fair](https://www.oscarwylee.com.au/locations/optometrist-pacific-fair.html) store is located in the Pacific Fair Shopping Centre, opposite OPSM in Broadbeach, Queensland. Oscar Wylee Pacific Fair is dedicated to providing excellent optometry services.
* Robina: Robina is close to Southport, around 12-15 km. The [Oscar Wylee Robina](https://www.oscarwylee.com.au/locations/optometrist-robina.html) store is located in the Robina Town Centre, opposite Boost Juice. Visit Oscar Wylee Robina for bulk billed eye tests for eligible Medicare cardholders as well as professional frame styling.
### Bulk Billed Eye Tests for Medicare Cardholders
We offer Medicare, bulk billed eye health tests in-store at Oscar Wylee Southport, Australia Fair. Come in and have your prescription updated and shop for a new pair of eyeglasses on the same day. Our trained optometrists provide vision testing, eye health checks and can examine the eyes for certain diseases. Book an eye test online today at Oscar Wylee in Southport so you can stay up-to-date on your eyesight and eye health needs.
### Health Funds Accepted in Southport
Oscar Wylee Southport Australia Fair accepts major health funds including NIB, Bupa and HBF. Have your claim processed in-store by our friendly retail staff if you have a valid health fund card. We can also provide on-the-spot quotes for our glasses. At Oscar Wylee Southport, you won’t have to navigate the hardest parts of insurance alone. Our team are on-site to make sure you’re getting the best price every single time for all of your prescription glasses needs.
### Fashion-Forward Frames in On-Trend Styles
Here at our eyeglasses shop in Australia Fair Shopping Centre, Oscar Wylee offers prescription eyeglasses and prescription sunglasses, with both local and international inspirations including Australia’s coastal landscape. Our customers can choose to add an anti-reflective coating, a blue light filter, and more! With experts in-store to help you choose what’s best for you, you’ll be able to find a frame that suits your style and prescription needs.
Book Appointment
[Call us: (07) 5661 1102](tel:(07) 5661 1102)
[Leave a Review!](https://g.page/r/CfnQUp9M44ygEAE/review)