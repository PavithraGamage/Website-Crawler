# Source: https://www.oscarwylee.com.au/locations/optometrist-epping.html

# Optometrist Epping
Pacific EppingLevel G, Shop 269571-583 High StreetEpping VIC 3076
* Near Platypus Shoes
Opening hours
Monday9:00am - 5:30pm
Tuesday9:00am - 5:30pm
Wednesday9:00am - 5:30pm
Thursday9:00am - 9:00pm
Friday9:00am - 9:00pm
Saturday9:00am - 5:00pm
Sunday10:00am - 5:00pm
*Store hours reflect local standard trading hours and exclude public holidays
[Visit our Pacific Epping Google Business page for directions, reviews, and updates.](https://g.page/r/CQRa7PBsAMnVEBA)
Book Appointment
[Call us: (03) 9424 1546](tel:(03) 9424 1546)
[Leave a Review!](https://g.page/r/CQRa7PBsAMnVEAg/review)
Our Reviews
Chris N
4 days ago
The crew at Epping are always very helpful and very knowledgeable ????️ the optometrist is great too... and explains what’s happening with your eye health in detail. fantastic experience.
See more
Yahya Akkad
5 days ago
(Translated by Google) It was very good and the service was very nice.
(Original)
كان جيد جداً والم...عاملة كانت كتير لطيفه
See more
Hayley
2 weeks ago
Had a really good experience here! I walked in for an eye test and barely had to wait, which was gre...at. The optometrist was really friendly and knowledgeable and made the whole process easy.
It was also my first time buying glasses, and there was such a big range to choose from. I was expecting to wait a while for them, but they were ready in just a week!
Really happy with the service and how quickly everything was done. Would definitely recommend!
See more
carol parker
2 weeks ago
Staff very very helpful and informative
Shalu Khanna
4 weeks ago
K G
1 month ago
I had an excellent experience at my optometrist appointment. The optometrist was incredibly professi...onal, thorough, and caring. She took the time to explain everything clearly and made sure every part of the eye examination was done carefully. I really appreciated the attention to detail.
The staff were also amazing—friendly, welcoming, and very helpful throughout the entire visit. Everything was well organized, and the whole experience was smooth from start to finish. I highly recommend this clinic to anyone looking for exceptional eye care!
See more
Yaser Almasto
1 month ago
The staff were exceptionally friendly, respectful, and cooperative.
Kashmala Burney
1 month ago
Special shoutout to Eylona who works there!! She fixed my sunglasses in seconds with a smile!! So be...autiful inside out. Bless xx
See more
nahida haroon
1 month ago
Effie Passakos
1 month ago
The staff were very helpful and friendly. The Optometrist went above and beyond my advice. She was a...mazing and had a lot of patience with my case because it was very difficult. She took her time until she got to the bottom of my case.
Highly recommended them!!!!
See more
Jatinder Kumar
1 month ago
Receptionist &amp; Optometrist both were great
Very helpful &amp; professional
Alice Partridge
1 month ago
Americanguy23
1 month ago
Sally Collins
2 months ago
A very pleasant and professional experience at OW, Epping Plaza store. All staff were extremely kind... and helpful. Received some great advice regarding eye health from Jennie (optometrist)and the order for my glasses was put through efficiently with plenty of assistance from staff in choosing suitable frames, etc.
I felt very looked after. Thank you.
See more
Rebecca Dungey
2 months ago
Oscar wylee Epping was great, explained everything really clearly. Ray was super helpful when I was ...picking my frames, thanks for the great experience
See more
Lynnett Moyo
2 months ago
Optometrist was very thorough and explained things to me unlike other experiences I've had. Would de...finitely go back there
See more
Zein Najme
3 months ago
Steve Czerny
3 months ago
Jennie at Pacific Epping plaza was most professional and answered all of my concerns and provided ad...vice moving forward. The staff at the front point of contact were welcoming and  proficient.
See more
Dora Ilov
3 months ago
Amazing experience and service. Highly recommend.
Angelo Maricchiolo
3 months ago
I can highly recommend Oscar Wylee. They are very professional, polite and knowledgable. I'm a first... time user of their services and am impressed. I will certainly be an ongoing client with them.
See more
Josie Vitale
3 months ago
Highly recommended. Outstanding Service.
Souzan Beauty
3 months ago
Great experience, very professional and helpful. Really happy with the eye check-up service. Highly ...recommend.
See more
Jennifer Eagles
3 months ago
Nasser Shah
3 months ago
Absolutely perfect, they make you feel like a VIP.
Frances Zois
3 months ago
Knowledgable and thorough optometrist with friendly staff.
preet pannu
3 months ago
The optometrist is great and given genuine advice.
Dahlia Tufuga
3 months ago
Thank you for your services ????????
Antonio Scardamaglia
3 months ago
Very good
Munish Thakur
4 months ago
Perfect is the only word and fantastic is the only complement I have for OW at Epping Plaza. Jenny, ...thanks a lot for your exquisite expertise and support, thorough insight and vast knowledge that educated and gruntled me. I extend heartiest appreciation. ????????????????????????????????????????????????????????????????????????????????
See more
Juliet Pereira
4 months ago
Excellent service. The dr too was very patient and took time rather than rushing things. I am very h...appy with my glasses and I can see very well though them.
See more
jamil jammas
4 months ago
Amber Middleton
4 months ago
Very helpful staff are lovely &amp; on time with appts
steven bazenski
4 months ago
I took my mum to have her eyes tested and  we were both extremely impressed. Optometrist was profess...ional and did a thorough check of her eye health. Staff were all friendly and genuine and didn't try to push her to buy unnecessary extras. Mum chose 2 pairs of glasses and they came in pretty quickly and look great. Wouldn't go anywhere else ????
See more
Elias naveed
4 months ago
Elena Popovska
5 months ago
My glasses broke and I totally freaked out. It was literally 5:10 PM when I called the store and thi...s super nice person answered. I told them what happened, and in like 10 minutes, I was there. Adam, my hero, thank you so much for replacing my frames, for being so patient and helpful, and for staying late just for me. You're a huge asset to the company, and I can't thank you enough.
See more
Denise Lechmere
5 months ago
Friendly and efficient staff at Epping Plaza. Would recommend their service. No pressure and easy. A...m very happy to recommend.
See more
Tiffany D
5 months ago
My mum and I had a great experience with Jennie at Epping. She was incredibly detailed and thorough ...throughout the entire eye exam. She took the time to explain everything clearly and made sure all my questions were answered, which made me feel very comfortable and confident in the care I received.
She is professional, friendly, and genuinely cares about her patients. I highly recommend Jennie to anyone looking for a knowledgeable and attentive optometrist.
See more
Nii Odartey
5 months ago
This was my best experience so far! The doctor I had on the 26/03/ was exceptional. She’s explained ...what’s wrong with my eyes and how it may give off wrong figures to the machine. She was patient and kind. Prescribed me two prescriptions for distance and near use.
I’ll recommend Oscar Wylee compared to the others!
See more
Gerry Butler
5 months ago
Optometrist was knowledgeable and had good people skills, thanks
Kylie K
5 months ago
Optometrist on duty 21/3/26 was lovely, she did great with my boys, kind, informative and very profe...ssional.
See more
Hong Nguyen
5 months ago
JASSI BATTH
5 months ago
Mini Gopan
5 months ago
My eye tests with Oscar Wylee have always been smooth. The optometrist are excellent and always take... the time to explain their findings. Although bit on an expensive side, the frame and lens options are great too.
See more
fadiuf
5 months ago
Great service, the staff were patient and understanding ????. Thank you ????
Kay Harmes
5 months ago
Great service.  Good variety of frames.
Li P
6 months ago
Bernie R
6 months ago
Had an eye test yesterday at the Epping Plaza store. Could not have asked for better service. From w...alking in and having the pretests to the full examination, the service was outstanding. I need a new script and was under no pressure to choose a particular frame, lenses or add ons. Everything was totally left up to me to decide my options and what I could afford. There was no hard sell, which I’ve experienced elsewhere before to choose a particular frame, lenses or add ons. Great service, thank you.
See more
Denise Stevens
6 months ago
Excellent service and very friendly
Joe
6 months ago
Chantalle Afif
6 months ago
## Find an Optometrist in Epping With Oscar Wylee
Only a short walk away from Epping station, you can find our Oscar Wylee eyeglasses shop close to Wollert and Thomastown, right in Melbourne’s north. Oscar Wylee’s Pacific Epping optometrists are equipped to carry out eye care processes including bulk billed eye tests for anyone with a valid Medicare card. Our team is available any day of the week, and the store’s large collection is sure to fit any style. From classic vintage to frames inspired by new trends, there’s a pair for everyone at Oscar Wylee Pacific Epping. 
When done with your appointment, why don’t you check out Pacific Epping, which has over 230 choices of shops and services inside, including a childcare centre, a hotel and a gym. Located perfectly for public transport, the mall also offers great parking for those driving in. Come to Oscar Wylee Pacific Epping for the best in fashion-forward frames at affordable prices. For those who live in the Epping area or surrounds, Oscar Wylee optometrists near you also include Oscar Wylee Greensborough and Oscar Wylee Doncaster.        
Meet Our Team
* Optometrist
O.D
B.Biomed
Our Services
* Bulk Billed Eye Examinations
* Professional Frame Styling
* Frame Adjustments and Repairs
Show All
## Find an Optometrist in Epping Victoria for an Eye Health Test
Find an optometrist in Epping, Victoria for your eyecare and eyewear needs. At our Oscar Wylee glasses store in Epping, Victoria, our dedicated team are available in-store to provide a range of eye care services including eye tests, and prescription updates. Our knowledgeable retail staff and optical dispensers are also in-store to help customers shop a range of eyewear such as prescription glasses, prescription sunglasses and non-prescription frames.
Book an eye health test in Epping, Victoria with our Oscar Wyle optometrists who will assess the health of a patient's vision and whether there are any signs of eye diseases. Our optometrists can also refer people to an eye doctor, known as an ophthalmologist in Australia, if advanced care is needed. Our eye tests at Oscar Wylee Epping are available at a bulk billed price as part of Australia’s Medicare system for eligible cardholders. The average price range to see an optometrist in Epping can vary depending on factors such as the patient’s overall health, age and visual needs.
## How to Find an Optometrist in Epping Victoria?
To find an optometrist in Epping, Victoria you can take certain steps that can help make it easier for you such as searching online, assessing the store’s opening hours and finding the directions to your chosen location. The steps on how to find an optometrist in Epping are listed below.
1. Search online using the phrase, Epping optometrist near me. This can also be done here on the website via our locations page.
2. Click on the Oscar Wylee link, which will take you directly to our Epping optometrist store page.
3. See the store’s opening hours and where the store is located specifically.
4. Use the Epping Google Business page link located under store hours to see the directions on how to get to the store.
You can also find an optometrist in Epping by searching the keywords optometrist near me. If you have locations enabled on your smartphone and you’re in the Epping area, our Epping store page should appear easily for you to click on.
### Is it Hard to Get an Eye Appointment in Epping Victoria?
No, it is not hard to get an eye appointment in Epping. You can easily book an appointment to see an Oscar Wylee optometrist in Epping right here on this page. At Oscar Wylee we have highly qualified optometrists available for bulk billed eye appointments, which can be booked online or in-store.
#### How to Compare Optometrists in Epping to Each Other?
To compare optometrists in Epping, you can use factors such as eye tests offered, health fund coverage, lens types and add-ons and eyewear offered. To take care of your vision and eye health, it is important to receive an eye test at least once every two years. There are different types of tests that can be performed in an eye test and not all optometrists may offer the same tests. Health funds can be used to help cover some of the cost of your frames and lenses. To find out if your health fund is accepted at Epping optometrist in Victoria, visit their website. In the case of Oscar Wylee, we accept all major health funds and provide on-the-spot claims in-store. There are many different lens options available for prescription glasses such as single-vision, multifocal and high-index lenses. Most optometrists in Epping will offer these lenses although it is good to make sure. There are also lens add-ons available to enhance your glasses such as anti-reflective and blue light filters. Finally, if you are looking to purchase a pair of glasses after your eye test, you can compare the different styles and colours you are interested in from Epping optometrists in Victoria. Oscar Wylee offers a wide range of frames with vintage and modern inspirations in bold colours and subtle designs.
#### How to Find a Eyeglasses Shop in Epping Victoria?
To find a glasses store in Epping, you can try to follow these simple steps including searching online, selecting a convenient location and looking at their health insurance policies. The steps on how to find a glasses store in Epping Victoria are listed below.
1. Search online using the phrase, glasses store in Epping. This will provide you with various options for glasses stores in the whole Epping Victoria area.
2. Select a glasses store that is most convenient for you to travel to.
3. Click the link to find out more information such as opening hours, exact location and directions to the glasses store in Epping.
4. Read their health insurance policies to ensure you know what health benefits you have access to.
Our Oscar Wylee glasses store in Epping Victoria offers primary eye care services such as comprehensive eye tests as well as other services performed by an optometrist and offers prescription and non-prescription eyewear.
##### Is it Possible to Purchase Prescribed Sunglasses in Epping Victoria Without Seeing an Optometrist?
Yes and no, it is possible to [purchase prescribed sunglasses](https://www.oscarwylee.com.au/sunglasses.html) in Epping Victoria without seeing an optometrist if you already have a prescription that has not expired. If your prescription is expired, you can book an eye test to receive an updated or new prescription which will require you to see an optometrist. This will ensure your prescription sunglasses are appropriate for your visual needs.
## Where is the Oscar Wylee Epping Optometrist in Victoria Located?
Oscar Wylee’s Epping optometrist is located in the Pacific Epping Shopping Centre across from Just Jeans. The Pacific Epping Shopping Centre can be found on High Street in Epping, a suburb of Melbourne.
### What is the Phone Number of Oscar Wylee Epping, Victoria Optometrist Store?
The Oscar Wylee Epping optometrist store phone number is (03) 9424 1546. You can contact the Oscar Wylee Epping store between the hours of 9 am and 5:30 pm from Monday to Wednesday, 9 am and 9 pm on Thursdays and Fridays, 9 am and 5 pm on Saturdays and 10 am and 5 pm on Sundays.
### What are the Reviews for Oscar Wylee Epping Optometrist in Victoria?
The customer reviews left for our Oscar Wylee Epping optometrist in Victoria, can be found here on the website as well as online when you search for Oscar Wylee Epping optometrist. The reviews for Oscar Wylee Epping optometrist are listed below.
* Sue Crispe:  Very happy with Cam the optometrist. She listened to my concerns and followed through with everything. She clearly explained what was wrong and what I needed to do and made a follow-up appointment. Thank you.
* N Nguyen:  Great service. Staff are nice, friendly and very thorough. I would recommend this optometrist.
* Racquel Rocca:  Fantastic service, great variety of glasses, friendly, beautiful staff. Highly recommend it.
#### What Treatments or Eye Care Processes are Done in the Oscar Wylee Epping Optometrist Location?
The treatments or eye care processes done in the Oscar Wylee Epping optometrist Victoria location include a tonometry test, a slit lamp exam and a refraction test. Additional tests that may also be performed can include a dilated fundus exam. The treatments or eye-care processes that are done in the Oscar Wylee Epping, Victoria optometrist location are listed below.
* A Tonometry Test: An optometrist or optical dispenser will conduct a tonometry test which involves the use of a machine that will release small puffs of air into your eyes. This will assist with measuring pressure in the eye.
* Slit Lamp Test: A slit lamp test can be used to evaluate your eye health, by examining your cornea and iris which are the anterior and posterior of the eye.
* Refraction Test: During a refraction test, an optometrist will have you view an image through different lenses and ask you to confirm which helps you see the image clearer.
* Dilated Fundus Exam: A dilated fundus exam can help an optometrist assess your health in more detail by getting a clear view of the retina. This test is typically carried out for patients with diabetes and those who may be at risk of developing retinal damage.
## How Many Optometrists Exist in Epping Victoria?
There is a range of optometrists that exist in Epping, Victoria. The exact number of optometrists available in an area typically depends on the population. Oscar Wylee is an optometrist located in Epping. At Oscar Wylee Epping, our dedicated team offers excellent optometrist services including eye tests using high-quality equipment. We also have a wide range of fashion-forward frames in a variety of sizes and colours. If you’re looking for an optometrist in Epping, choose Oscar Wylee and we will take care of your optometry and eyewear needs.
### What are the Other Closest Optometrist Locations to Epping Victoria in Australia?
The other closest Oscar Wylee optometrist locations to Epping in Australia are Moonee Ponds, Northlands in Preston and Melbourne Central. The other closest optometrist locations to Epping are listed below.
* Moonee Ponds: Moonee Ponds is a location close to Epping, Victoria, around 26 km away. [Oscar Wylee Moonee Ponds](https://www.oscarwylee.com.au/locations/optometrist-moonee-ponds.html) is located in the Moonee Ponds Central shopping centre on Hall Street. At Moonee Ponds Oscar Wylee, our team provide Medicare, bulk billed eye tests and new, stylish frames.
* Northlands:  The Northlands shopping centre, located in the suburb of Preston, is a location close to Epping, Victoria, around 14 km away. [Oscar Wylee Northlands](https://www.oscarwylee.com.au/locations/optometrist-northland.html) is located on the ground level of the Northlands shopping centre, where our team are available to provide eye tests and help you shop a new pair of frames.
* Melbourne Central: Melbourne Central is a shopping centre located in Melbourne, Victoria, around 14 km away from Oscar Wylee Epping. At [Oscar Wylee Melbourne Central](https://www.oscarwylee.com.au/locations/optometrist-melbourne-central.html), our optometrists are available in-store to provide eye tests, and our friendly staff can help you shop our range of stylish frames.
### Optometrist Eye Tests at Oscar Wylee Pacific Epping
Get an eye test at Oscar Wylee Pacific Epping without any out-of-pocket cost for valid Medicare cardholders and shop for your new glasses on the same day. It is recommended you go in for an eye health test every two years, or as otherwise advised by your optometrist, to make sure your prescription is up-to-date and your vision is at its best. Eye tests are also important as they can help detect eye conditions and eye diseases. For some of the best optometrist services in Epping, Australia, visit Oscar Wylee Pacific Epping.
### Oscar Wylee Accepts Major Health Funds
No matter if you’re buying a pair of prescription glasses or prescription sunglasses, Oscar Wylee Pacific Epping has you covered. At Oscar Wylee Pacific Epping, our team can process health fund claims in-store with a valid health fund card. Our team also can help answer any questions about what you’re eligible for with your health fund.
### Frame Advice with Oscar Wylee Pacific Epping
Oscar Wylee will help you find the perfect eyewear, whether it's optical glasses, prescription sunglasses or non-prescription frames, our experienced team will find the frame that is right for you. Get fitted for glasses frames, choose from our different lens options, and even choose from our different lens coatings to customise and optimise your new pair of glasses.
Book Appointment
[Call us: (03) 9424 1546](tel:(03) 9424 1546)
[Leave a Review!](https://g.page/r/CQRa7PBsAMnVEAg/review)