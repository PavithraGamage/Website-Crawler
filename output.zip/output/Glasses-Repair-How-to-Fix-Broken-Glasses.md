# Source: https://www.oscarwylee.com.au/glasses/eye/glasses-repair

# Glasses Repair: How to Fix Broken Glasses
Published on October 13th, 2023
Updated on October 8th, 2024
Australia
[Australia](https://www.oscarwylee.com.au/glasses/eye/glasses-repair)
[Canada](https://oscarwylee.ca/glasses/eye/glasses-repair)
[Canadian French](https://oscarwylee.ca/fr/glasses/eye/glasses-repair)
Glasses should be repaired
by a professional to ensure that they are properly handled. Glasses
repair may involve correcting bent frames, broken nose bridges, broken
hinges and scratched lenses.
However, the type of repair needed can differ depending on whether the
frames are metal or plastic. Metal eyeglasses repair normally requires
expertise and certain equipment in order to bend the materials accordingly.
However, to fix glasses made from plastic, you may be capable of correcting
some issues at home.
[Repairing Glasses](#Repairing-Glasses)
[Repairing Lenses](#Repairing-Lenses)
[Repairing Frames](#Repairing-Frames)
[Prevention](#Prevention)
## Can Glasses be Repaired?
Yes and no, glasses can likely be repaired
if the issues are minor and depend on the nature of the issue. Broken glasses may be repaired
if the issues involved are separated arms from missing screws, loose
arms or misaligned [nose pads for glasses](https://www.oscarwylee.com.au/glasses/nose-pad). However, if the arm or hinges are broken, this
cannot be fixed and will require a replacement, this also applies to
metal frames. Broken glasses lenses cannot be fixed and will also
require a replacement.
Do Your Glasses Need an Update?
Come see our staff in-store to get your eyes tested and your
prescription updated if needed.
[Book an Eye Test](https://www.oscarwylee.com.au/booking)
### Why Do Glasses Break?
Glasses can break due to various factors such as
rough handling, incorrect storage, being mishandled by children or
pets and accidentally standing or sitting on them.
### What Parts of Glasses Commonly Break Down?
The parts of glasses that commonly break down are
the frame and bridge as they can easily be bent out of
shape.
The more fragile parts of glasses that are vulnerable to breakage need
more care, therefore, it is strongly recommended by optometrists to
handle your glasses with more caution. You can take care of your
glasses by taking them off with both hands to prevent stretching or
bending the frames and storing them in their case when you are not
using them. For more information on the various glasses components,
read
[Parts of Glasses: A Guide to the Anatomy of Glasses](https://www.oscarwylee.com.au/glasses/eye/part-of-glasses).
## How To Fix Glasses' Nose Pads and Hinges?
To fix glasses’ nose pads and hinges,
it is recommended to take your glasses to the optometrist for
professional repairs. It may only be possible to fix nose pads and
hinges if they are missing screws or are loose and require
tightening.
If nose pads or hinges have broken off, it may be best to go back to
your optometrist as they will need to replace your glasses. It is
important to note that attempting to fix your glasses with glue will
void your warranty as part of Oscar Wylee’s policy.
## How To Repair Scratched or Broken Glasses’ Lenses
To repair scratched or broken glasses lenses,
it is best to take your glasses to the optometrist for professional
lens replacement.
Scratched or broken glasses lenses cannot be fixed at home, therefore,
it is strongly advised to have an optometrist or optical dispenser
assess their condition and they may likely replace the lenses.
### Is it a Good Idea to Put Old Glasses Lenses in New Frames?
No, it is not a good idea to put old glasses lenses in new frames as
your old glasses lenses may not fit in your new frames. Old glasses
may require an updated or new prescription,
therefore, the optometrist will need to assess your old glasses first.
However, it is possible to insert old glasses in new frames if they
are the same as your old frames.
## How To Fix Different Broken Glasses Frames?
Fixing different broken glasses’ frames
will require an optical dispenser’s assessment of the damage to
determine whether repairs are possible or if replacement is needed.
However, a replacement will be likely for most cases of broken
[glasses frames](https://www.oscarwylee.com.au/glasses/types)
to ensure your glasses are optimal for use. The ways to fix different
broken glasses’ frames are listed below.
* Plastic Frames: Plastic frames may be
easier to fix depending on the damage caused. Tape may be a temporary
solution that can keep the glasses frames together before taking it
back to the optometrist.
* Metal Frames: Metal frames generally
require an expert and certain tools to fix any damages. Therefore, it
is best to take metal frames to the optometrist if they are broken as
they will need to be replaced.
* Rimless Glasses: Rimless glasses do
not have a frame, therefore, it may be more suitable to bring them to
your optometrist for repairs.
## How Much Does Repair For an Average Pair of Glasses Cost?
The cost for repairs for an average pair of glasses
can range between different prices depending on the material of the
frames and the nature of the repair process that is required.
At Oscar Wylee, we offer repairs or replacements for problems
experienced with vision during everyday use for claims made within 30
days of delivery or receipt of purchase.
Visit a Store Near You
We have highly qualified teams dedicated to helping with your eye care
needs.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
### Do Eye Doctors Repair Glasses?
No, eye doctors do not repair glasses,
they are qualified for treating, diagnosing and managing eye
diseases and conditions. Eye doctors are trained to perform eye
surgeries
and are typically who the optometrist or medical professional will
refer patients to. In Australia eye doctors are known as
ophthalmologists and while optometrists are not considered eye doctors
in Australia, they are also qualified and skilled to conduct repairs
for glasses.
### How Long Does it Take to Repair Glasses?
It may take between a few hours to several days to repair
glasses, however, this can vary between places. At Oscar Wylee, it
can take up to 2 weeks for a replacement to arrive if it is
necessary.
### What is the Effect of Broken Glasses on the Eyes and in Health?
The effects of broken glasses on the eyes and for eye health revolve
around unclear vision and an inconvenience in daily life. Broken
glasses
may cause slightly distorted or unclear vision and discomfort,
depending on the condition of the broken glasses.
Broken glasses may not affect your ability to see or the physical
condition of your
[eyes](https://www.oscarwylee.com.au/glasses/eye/anatomy)
but rather how you see when wearing them. Broken glasses may sit
uncomfortably on the face due to broken or loose arms or a broken
frame. Broken or scratched lenses may bring on distorted or unclear
vision if the scratches are severe, therefore, it is important to take
damaged lenses to an optometrist for assessment and a possible
replacement.
### When to Replace Glasses?
It may be recommended to replace your glasses
every two or three years, which is around the same length of time
you should have your eyes tested.
Therefore it may be suitable to stay up to date with your regular eye
tests in order to have your glasses prescription updated or replaced
as advised by the optometrist.
## What are Ways to Prevent Eyeglasses From Breaking?
The ways to prevent eyeglasses from breaking are to
always use the glasses case for storage, consider memory metal
frames, handle glasses during workouts with care, stay away from
extreme temperatures, check where your glasses are before you sit,
remove glasses gently from both frame sides, avoid using glasses in
your hair as an accessory and avoid keeping glasses alone in pockets
or bags.
These habits will help ensure you are handling your glasses properly and
with care. The ways to prevent eyeglasses from breaking are listed
below.
* Always use the glasses case for storage:
Always use the case when not using your glasses to protect them from
damage.
* Consider memory metal frames: Consider
memory metal frames as their material enables them to revert back to
their original shape if they are accidentally bent.
* Handle glasses during workouts with care:
Handle glasses during workouts with care by either opting for contact
lenses or using a strap to prevent them from falling off.
* Stay away from extreme temperatures:
Stay away from extreme temperatures as it could result in changes to
the form of your glasses frame, arms and lenses.
* Check where your glasses are before you sit:
Check where your glasses are before you sit as it is very common and
likely for your glasses to end up in the places you frequently sit and
to avoid accidental damage from sitting on the glasses.
* Remove glasses gently from both frame sides:
Remove glasses gently from both frame sides to prevent bending them
out of shape or breaking the arms.
* Avoid using glasses in your hair as an accessory:
Avoid using glasses in your hair as an accessory to prevent stretching
the arms and the risk of them falling off your head.
* Avoid keeping glasses alone in pockets or bags:
Avoid keeping glasses alone in pockets or bags without their case as
they can be prone to minor scratches and scuffing.
### 1. Always use the glasses case for storage
Always use the case
to keep your glasses in proper storage and protected from any
damage such as scuffs and scratches or accidentally sitting on
them.
Using the case provided with your glasses will help ensure that even
if they do fall, the case can prevent any breakage from the impact.
### 2. Consider memory metal frames
Consider memory metal frames as
they are made out of a titanium alloy that results in more frame
flexibility, which enables them to return to their original shape
when they are severely bent.
Memory metal frames may be a suitable option for those who are prone
to dropping or mishandling their glasses. It is important to note that
Oscar Wylee does not offer metal frames of this kind, however, our
metal frames have assured durability to wear and corrosion.
### 3. Handle glasses during workouts with care
Handle workouts with care by
opting for contact lenses instead of wearing your glasses or using
straps to keep the glasses secure on your head.
You can handle glasses with more care during workouts by ensuring they
fit you correctly. They should be able to rest on your nose without
feeling any pressure or tightness and they should not be able to move
or slip around when you are moving.
### 4. Stay away from extreme temperatures
Stay away from extreme temperatures as
your glasses may be damaged from extreme heat or freezing
temperatures. Extreme temperatures can cause warping especially on
plastic frames and lenses and alter their shape.
It may be best to keep them in their case in your bag or pocket if
they can fit and avoid leaving them in your car especially during hot
temperatures.
### 5. Check where your glasses are before you sit
Check where your glasses are before you sit
to prevent breaking your glasses, as the risk of your glasses
ending up on a chair or couch is likely.
Practicing the habit of returning your glasses to their case after
each use can be helpful in preventing being sat on.
### 6. Remove glasses gently from both frame sides
Remove glasses gently from both frame sides
to prevent them from misaligning or accidentally breaking off the
arms.
Using both hands to remove your glasses ensures you are taking your
glasses off in a straight position without too much resistance on the
arms.
### 7. Avoid using glasses in your hair as an accessory
Avoid using glasses in your hair as an accessory
as pushing them onto your head may cause them to stretch as the top
of your head has a larger surface area than your face.
Avoid leaving your glasses in your hair as they could easily fall off
and break.
### 8. Avoid keeping glasses alone in pockets or bags
Avoid keeping glasses alone in pockets or bags
as they may get scratched or damaged without their case. Keep
your glasses in their provided case when you are not using them and
are storing them in your pocket or bag. The provided case can assist
with preventing potential minor but frustrating damages.
Read Glasses Repair: How to Fix Broken Glasses in other Oscar Wylee
regions and their languages.
Australia
[Australia](https://www.oscarwylee.com.au/glasses/eye/glasses-repair)
[Canada](https://oscarwylee.ca/glasses/eye/glasses-repair)
[Canadian French](https://oscarwylee.ca/fr/glasses/eye/glasses-repair)
We Accept Leading Health Funds In-store
Visit Oscar Wylee for your eye care needs, and your health fund may
help cover some of the cost.
[Health funds](https://www.oscarwylee.com.au/health-funds.html)
Renew Your Prescription
Don’t let your eye health get away from you. Renew your glasses
prescription with an Oscar Wylee optometrist today.
[Book an eye test](https://www.oscarwylee.com.au/booking)