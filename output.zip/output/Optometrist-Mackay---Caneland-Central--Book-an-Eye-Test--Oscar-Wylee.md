# Source: https://www.oscarwylee.com.au/locations/optometrist-mackay.html

# Optometrist Mackay
Caneland CentralShop GD 2062, 2 Mangrove RoadMackay QLD 4740
* Opposite Best &amp; Less
Opening hours
Monday9:00am - 5:30pm
Tuesday9:00am - 5:30pm
Wednesday9:00am - 5:30pm
Thursday9:00am - 5:00pm
Friday9:00am - 5:30pm
Saturday9:00am - 4:00pm
SundayClosed
*Store hours reflect local standard trading hours and exclude public holidays
[Visit our Mackay Google Business page for directions, reviews, and updates.](https://g.page/r/CaD72kOUF4WiEAE)
Book Appointment
[Call us: (07) 4846 0223](tel:(07) 4846 0223)
[Leave a Review!](https://g.page/r/CaD72kOUF4WiEAE/review)
Our Reviews
Van Sandr
5 days ago
Cheryl Ah Wang
2 weeks ago
The Team at Canelands Oscar Wylee optometrist Mackay are Amazing.
Friendly and very helpful, highly ...recommended them.
See more
Gillian Siganto
2 weeks ago
Absolutely lovely staff....helpful and i enjoy my visits
Lyn Hile
2 weeks ago
katelyn jacobson
2 weeks ago
The optometrist Jenny was the nicest optometrist i’ve had the pleasure of meeting, she was super tra...nsparent about the results and walked us through everything she was doing and why, I have never had such a good experience at the optometrist! Jenny made my younger sister feel super comfortable and even mentioned how much she was laughing!
The ladies at the front were so helpful when we came in early and got us prescreened so that we could be seen as soon as our appointment time came up, one of the ladies was extremely helpful when it came to helping my sister choose a frame, helping her find a frame that suited her face and that she felt confident in without any pressure.
Our experience was definitely one to note, I’d definitely recommend oscar wylee canelands
See more
Joanne Stark
4 weeks ago
Clee Stephenson
1 month ago
The staff were friendly and more than happy to assist.. they also had a wide variety of designer fra...mes
See more
Joanne Milwain
1 month ago
Exceptional service. Went here after going to specsavers my whole life.... will never go back...
Was... treated so well... optometrist was very thorough, full eye check and found out more then I ever have about my eyes.
Gypsy served me and was exceptional, walked out extremely happy and spent a good $300 less then i have in the past .. . I honestly could not be happier...highly recommend.
See more
Johanna Shenfield
1 month ago
Oscar Whylee in Mackay is my usual optometrist. I always come back the staff are lovely and very hel...pful.
See more
Bazz Harmer
1 month ago
Extremly helpful the reception girls were so kind to my needs and full of smiles i could'nt of had a... better appointment..Thanks for being real..
See more
Chloe Ross
2 months ago
Amazing experience! Nicest people there and so helpful!!
M A
2 months ago
Sara from Oscar Wylee Mackay is amazing. She was very helpful and she provided me with excellent cus...tomer service. Thanks Sara
See more
Susan Deakin
2 months ago
Great service.  Professional and friendly.  Thank you ????
Paula Smith
3 months ago
Great experience from beginning to end. Very friendly and helpful staff.
Skyla Bradford
3 months ago
Amazing service! Everyone is so nice and helpful
Stacey Quakawoot
3 months ago
They staff were very helpful, polite, the range of glasses were awesome. Glad I changed from spec sa...vers to Oscar Wylee, will be telling friends and family
See more
Charlotte Jooste
3 months ago
Staff very helpful and friendly. The optician was very patient in listening to my concerns and expla...in them away.
See more
Chloe Cooper
4 months ago
A customer service shout out.
Hope it reaches the sales lady that served me today at Oscar Wylee Mac...kay
Saterday 18th April
Thankyou sooo much for you kind and paitiant and bubbly service today (think her name was) Gypsy
You were very attentive and helped me with no hesitation at all you were very kind.  Fixing my glasses and helping me pick out other new ones I needed.
Keep up your great customer service I loved it and felt very welcomed
See more
Clarissa Welchman
4 months ago
Lovely service . Excellent staff
doug lake
5 months ago
Optometrist was very thorough and professional. Thank you!
Porak Posing
5 months ago
Awesome service
lynella simpson
5 months ago
Wonderful service really happy and was confident with the Optometrist she was very thorough and expl...ained everything. All staff were very helpful when choosing glasses.
See more
mike clarke
5 months ago
I was very pleased with the eye test.  The optition was helpful with my access to the equipment as I... was in a wheelchair.  She explained each part of the tests in detail.
I will return in a year for another assessment.
See more
carol Anthony
5 months ago
A really great experience, I just leant so much that I didn't know. I can see that all the staff mem...bers really care about doing their very best for you. Thank you to you Chai for sharing all your knowledge with me, it really does make that difference.
See more
Janet Young
5 months ago
Wow! Chai, and the ladies are fantastic. Chai is extremely Knowledgeable and explained so much to me.... The whole family have now been to her and we are all so super impressed.
See more
John Flanagan
5 months ago
I had made an appointment and arrived 10 minutes early.. did not have to wait and had a thorough eye... examination before an eye test to determine the lens l would require for my new glasses. The optometrist was very thorough and took time to explain each procedure. On completion l was asked to choose frames .. the range of frames was incredible which made my choice difficult because there was so many to choose from. I would highly recommend Oscar. Wyler to anyone looking to upgrade their glasses
See more
Judie Barbour
5 months ago
Totally professional, helpful, non-pushy.
⭐️⭐️⭐️⭐️⭐️
Stephanie Rodriguez
5 months ago
Sarah was really helpfulwith my eyeglass adjustment  ! Great service and place! Iwill come here agai...n!
See more
Kate Runner
5 months ago
Thank you for your excellent service.
My eyexamination was explained to me very well. And a my quest...ions were answered in detail.i also received good advice.  Thank you.
See more
Therese Balanzategui
6 months ago
The optometrist was friendly and thorough. I felt confident that she knew her stuff. Staff were not ...at all pushy about recommendations, just provided answers to all my questions. Also a very wide range of frames at competitive prices. My new specs should arrive in a couple of weeks, so the proof will be in the pudding.
See more
Jed Hull
6 months ago
Very professional and smooth eye testing great fitting of glasses
Justine Sturgiss
6 months ago
I went for an appointment after religiously attending another optometrist for over 15 years. I didn'...t realise how much I was actually missing out on until I went to Oscar Wylee. The optometrist was so lovely and so knowledgeable. She taught me things that I had never been advised in all my years of going to someone else. The process was easy, the staff assisting in choosing glasses were truthful and helpful (not just telling me everything looked great on me) and the price was actually less than the previous store who purports to be 'the cheapest' ...if you catch my drift. I can confidently say I am converted and am looking forward to my next check up already! Would highly highly recommend!!!
See more
Brenda Willans
6 months ago
I always have a great experience at Oscar Wylie. The customer service is excellent, the eye test is ...quick yet thorough, and the staff were very helpful when I was choosing frames. I especially appreciated their honest second opinion—it made me feel confident in my choice.
See more
Fleur Levitz
6 months ago
Great service. Very thorough and explained clearly and easily through my eye test. Highly recommende...d. Thankyou.
See more
carole Davis
6 months ago
I really like the lady optometrist at my Oscar Wylee. My glasses have lasted 4yrs and I fall asleep ...in them. Great service, great glassss
See more
Leanne Leggett
7 months ago
Service is exceptional as always. Great range of eye wear and very informative Optometrist. Service ...at front counter was outstanding
See more
Robert McDowell
7 months ago
leanne albury
7 months ago
What a wonderful experience. Very knowledgeable and super friendly. Nothing too much trouble. Thank ...you ????
See more
Samantha Voysey
7 months ago
I have never had such a fantastic optometrist for myself and my children. Firstly so great with my k...ids (all on the spectrum). Secondly, very thorough with her testing explained things with my eyes that others haven’t told me and I’ve had glasses since I was 6. My kids absolutely adore the Dr and the staff are amazing. This will definitely be our usual store from now on.
See more
Danielle Gervais
7 months ago
Sara Rushby
8 months ago
Great customer service and attention to detail! Definitely recommend!
Amy Paton
9 months ago
I highly recommend Oscar Wylee at canelands. Staff were excellent and really informative!
Ivy Hodson
9 months ago
Fredina Mondido
10 months ago
Staff and the dr are all fantastic, accommodating and lovely. My daughter didn’t get scared at all....
See more
Carla Adams
10 months ago
My optometrist was on time and pleasant. I picked out my first pair of reading glasses, lots of opti...ons that fit my face.
See more
Alan Joel Ferreyra
10 months ago
Excellent attention and service. They were very patient and kind with my little boy. Thank you.
Ryan Christensen
10 months ago
J M
10 months ago
Love my optometrist! Great team and awesome options for prescription sunnies and glasses
Drew Formosa
10 months ago
Very thorough and informative
Jay Weerasinghe
10 months ago
I popped in for some assistance with a pair of glasses that I didn't even purchase from this store. ...Jazmine was absolutely amazing. She went out of her way to help when she didn't need to even. What a lovely team. Thank you.
See more
## Find an Optometrist in Mackay With Oscar Wylee
Discover our Oscar Wylee Mackay store located in the heart of Caneland Central Shopping Centre, close to Best &amp; Less. Here our Mackay optometrists offer bulk billed eye tests to valid Medicare cardholders. At Oscar Wylee Mackay you can have your eye health checked, update your prescription, and find your new favourite pair of glasses, all on the same day! Caneland Central has over 3000 parking spots available and as well as public transport close by. 
Why not go for some retail therapy when you’re done renewing your prescriptions with our Caneland Central optometrist? With over 240 stores, you will find something worth exploring here! When you’ve had your fill of shopping, Caneland Central is located right next to the stunning Pioneer River. See the beautiful sights of Mackay’s biggest river with your new prescription glasses, or go fishing with a perfect pair of polarised lenses! Plan a trip to experience some of the best optometry services in Mackay, Australia with Oscar Wylee.        
Meet Our Team
* Optometrist
BVisSci
MOptom
* Store Manager
Our Services
* Bulk Billed Eye Examinations
* Professional Frame Styling
* Frame Adjustments and Repairs
* Visual Fields Testing
Show All
## Find an Optometrist in Mackay for an Eye Health Test
Find an optometrist in Mackay to have your regular eye checkup. At Oscar Wylee Mackay - Caneland Central, you can receive a high-quality eye test performed by dedicated optometrists as well as browse a wide range of stylish frames available in optical glasses and prescription sunglasses. At our glasses store in Mackay - Caneland Central, you can also receive assistance from an optical dispenser who can provide frame styling and fitting.
We do not have an eye doctor in-store, however, our Oscar Wylee optometrists are qualified and trained so you can expect all the necessities of an eye health test in Mackay - Caneland Central. Our eye tests are available at a bulk billed price as part of Australia’s Medicare system so there are no out-of-pocket expenses for eligible Medicare cardholders. The average price range for an optometrist in Mackay - Caneland Central can vary depending on factors such as the patient’s overall health, age and visual needs. An eye test typically involves assessing a patient's vision and checking the health of the eyes which includes looking for any signs of eye diseases.
## How to Find an Optometrist in Mackay - Caneland Central?
To find an optometrist in Mackay, you can take certain steps that can help make it easier for you such as searching online, assessing the store’s opening hours and finding the directions to your chosen location. The steps on how to find an optometrist in Mackay are listed below.
1. Search online using the phrase, optometrist near me in Mackay. This can also be done here on the website via our locations page.
2. Click on the Oscar Wylee link, which will take you directly to our Mackay Caneland Central store page.
3. See the store’s opening hours and where the store is located specifically.
4. Use the Mackay Google Business page link located under store hours to see the directions on how to get to the store.
You can also find an optometrist in Mackay by searching the keywords optometrist near me. If you have locations enabled on your smartphone and you’re in the Mackay area, our Mackay store page should appear easily for you to click on.
### Is it Hard to Get an Eye Appointment in Mackay - Caneland Central?
No, it is not hard to get an eye appointment in Mackay - Caneland Central. You can easily book an appointment to see an Oscar Wylee optometrist in Mackay - Caneland Central right here on this page. At Oscar Wylee we have highly qualified optometrists available for bulk billed eye appointments, which can be booked online or in-store.
#### How to Compare Optometrists in Mackay to Each Other?
To compare optometrists in Mackay, you can use factors such as eye tests offered, health fund coverage, lens types and add-ons and eyewear offered. To take care of your vision and eye health, it is important to receive an eye test at least once every two years. There are different types of tests that can be performed in an eye test and not all optometrists may offer the same tests. Health funds can be used to help cover some of the cost of your frames and lenses. To find out if your health fund is accepted at an optometrist in Mackay, visit their website. In the case of Oscar Wylee, we accept all major health funds and provide on-the-spot claims in-store. There are many different lens options available for prescription glasses such as single vision, multifocal and high index lenses. Most optometrists in Mackay will offer these lenses although it is good to make sure. There are also lens add-ons available to enhance your glasses such as anti-reflective and blue light filters. Finally, if you are looking to purchase a pair of glasses after your eye test, you can compare the different styles and colours you are interested in from the optometrists in Mackay. Oscar Wylee offers a wide range of frames with vintage and modern inspirations in bold colours and subtle designs.
#### How to Find an Eyeglasses Shop in Mackay?
To find a glasses store in Mackay, you can try to follow these simple steps including searching online, selecting a convenient location and looking at their health insurance policies. The steps on how to find a glasses store in Mackay are listed below.
1. Search online using the phrase, glasses store in Mackay. This will provide you with various options for glasses stores in the whole Mackay area.
2. Select a glasses store that is most convenient for you to travel to.
3. Click the link to find out more information such as opening hours, exact location and directions to the glasses store in Mackay.
4. Read their health insurance policies to ensure you know what health benefits you have access to.
Our Oscar Wylee glasses store in Mackay - Caneland Central offers primary eye care services such as comprehensive eye tests as well as other services performed by an optometrist and offers prescription and non-prescription eyewear.
##### Is it Possible to Purchase Prescribed Sunglasses in Mackay Without Seeing an Optometrist?
Yes and no, it is possible to [purchase prescribed sunglasses](https://www.oscarwylee.com.au/sunglasses.html) in Mackay without seeing an optometrist if you already have a prescription that has not expired. If your prescription is expired, you can book an eye test to receive an updated or new prescription which will require you to see an optometrist. This will ensure your prescription sunglasses are appropriate for your visual needs.
## Where is the Oscar Wylee Mackay - Caneland Central Optometrist Located?
The Oscar Wylee Mackay optometrist is located in Caneland Central Shopping Centre, opposite Best &amp; Less. Caneland Central is a regional shopping centre located next to the Pioneer River in Mackay, Queensland.
### What is the Phone Number of Oscar Wylee Mackay - Caneland Central Optometrist Store?
The Oscar Wylee Mackay - Caneland Central optometrist store phone number is (07) 4846 0223. You can contact the Oscar Wylee Mackay - Caneland Central store between the hours of 9 am and 5:30 pm from Monday to Wednesday, 9 am and 7 pm on Thursdays, 9 am and 5:30 pm on Fridays, 9 am to 4 pm on Saturdays and 10 am and 4 pm on Sundays.
### What are the Reviews for Oscar Wylee Mackay - Caneland Central Optometrist?
The many reviews for Oscar Wylee Mackay - Caneland Central optometrist, left by our various customers can be found here on the website and online when you search for Oscar Wylee Mackay - Caneland Central optometrist. The reviews for Oscar Wylee Mackay - Caneland Central optometrist are listed below.
* TCatherine Youngberry:  Always friendly, knowledgeable staff on hand. The range of styles is never disappointing, and the pricing is much nicer than other places!
* Andrew Barrett:  Excellent eye test. Very thorough and not rushed at all. Felt very confident I was given the correct prescription.
* Shani Li:  Absolutely great experience with the optometrist, she was nice and professional, explained everything about my eye health, was very clear and provided great information to address my concerns.
* Caitlin Lawson:  By far the best customer service I have ever had in regards to my eye tests, and spectacle choices. Will be advising all to make the switch to OW!
#### What Treatments or Eye Care Processes are Done in the Oscar Wylee Mackay - Caneland Central Optometrist Location?
The treatments or eye care processes done in the Oscar Wylee Mackay - Caneland Central optometrist location include a tonometry test, a slit lamp exam and a refraction test. Additional tests that may also be performed can include a visual field test and a dilated fundus exam. The treatments or eye-care processes that are done in the Oscar Wylee Mackay - Caneland Central optometrist location are listed below.
* A Tonometry Test: An optometrist or optical dispenser will conduct a tonometry test which involves the use of a machine that will release small puffs of air into your eyes. This will assist with measuring pressure in the eye.
* Slit Lamp Test: A slit lamp test can be used to evaluate your eye health, by examining your cornea and iris which are the anterior and posterior of the eye.
* Refraction Test: During a refraction test, an optometrist will have you view an image through different lenses and ask you to confirm which helps you see the image clearer.
* Visual Field Test: A visual field test can assist with assessing your peripheral vision, which may be beneficial for identifying any signs of glaucoma.
* Dilated Fundus Exam: A dilated fundus exam can help an optometrist assess your health in more detail by getting a clear view of the retina. This test is typically carried out for patients with diabetes and those who may be at risk of developing retinal damage.
## How Many Optometrists Exist in Mackay?
There are many optometrists that exist in Mackay to provide eye tests and glasses, including Oscar Wylee. The amount of optometrists available in an area will typically depend on the population. At Oscar Wylee Mackay in Caneland Central Shopping Centre, we offer excellent optometry services including eye tests performed by skilled optometrists using high-quality equipment. We also have a wide range of fashion-forward frames that customers can browse in a large selection of sizes and colours. If you’re looking for an optometrist in Mackay, choose Oscar Wylee and we will take care of your optometry and eyewear needs.
### What are the Other Closest Optometrist Locations to Mackay - Caneland Central in Australia
There are no other Oscar Wylee optometrist locations close to Mackay - Caneland Central in Australia however, we have many stores in New South Wales, Western Australia and Victoria. If you are looking for an optometrist near you, you can find the locations of our many stores on our [full store locations page.](https://www.oscarwylee.com.au/locations.html)
### Bulk Billing Available in Mackay
Oscar Wylee offers optometrist-led eye health tests in-store at Caneland Central Mackay. Our trained optometrists can conduct eye care processes including updating your prescription or issuing a new one as well as assess your eyes for certain conditions and diseases. We recommend you visit an Oscar Wylee optometrist for an eye check-up and vision testing at least once every two years, or unless otherwise advised. Choose Oscar Wylee Mackay to keep you up-to-date on your eyesight and eye health needs.
### Health Funds Accepted
Oscar Wylee in Caneland Central Mackay accepts all major health funds, including HCF, Medibank and Bupa. With excellent staff on-site, we can process your claim in-store with a valid health fund card, as well as help you navigate the ins and outs of your insurance. Visit Oscar Wylee Mackey to get the best price for all of your prescription glasses needs.
### Styling In-Store at Oscar Wylee
Here at our eyeglasses shop in Mackay, Oscar Wylee offers prescription eyewear including prescription glasses and prescription sunglasses in a variety of on-trend and vintage-inspired styles. Our customers can choose to add on anti-reflective lenses, blue light filter lenses, and more for an additional price. With experts in-store, you can get help with finding the best frames and lenses to suit your needs. From bold styles to subtle statement pieces, we've got something for everyone.
Book Appointment
[Call us: (07) 4846 0223](tel:(07) 4846 0223)
[Leave a Review!](https://g.page/r/CaD72kOUF4WiEAE/review)