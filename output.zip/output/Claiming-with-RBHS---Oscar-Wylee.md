# Source: https://www.oscarwylee.com.au/health-funds/reserve-bank-health-society.html

# Reserve Bank Health Society at Oscar Wylee
As a member of RBHS, you can claim on optical extras using your health
fund’s coverage for optical services, such as prescription frames,
lenses or glasses. RBHS benefits can roll over to a maximum amount of
$920 after 2 rolling years per person. With Oscar Wylee, you
can have up to 90% coverage on select optical purchases when you shop
with us. Look at the table below to see your RBHS policy’s name and the
amount of coverage that policy gives when you shop at Oscar Wylee.Your
coverage might change or not apply to extras such as add-ons, coatings
or tinting.
## Are you seeing double?
Taking care of your eyes can be done in only 30 minutes with Oscar
Wylee.
[Book an eye test](https://www.oscarwylee.com.au/booking)
#### Waiting Period
12 Months
#### Benefit Limits Reset
1st of January1
#### Claimable Benefits %
90%
To learn whether your plan includes single-vision lenses, bifocal lenses
and/or multifocal lenses, talk to your health insurance provider.
| Your Extras Package Annual Limit:* | Premium Extras Cover | SINGLES COVER | 1 Standard OW Pair
from $169^ | 2 Standard OW Pairs
from $199^ | 3 Standard OW Pairs
from $249^ |
| --- | --- | --- | --- | --- | --- |
| $460 |
| Partial Cover |
| Partial Cover |
| Partial Cover |
^Excludes add-ons. Standard frames and lenses only. Oscar Wylee’s
standard product inclusions are calculated based on the optical
allowances under each health fund package and may vary. If unsure,
please confirm with your provider. Our two pair and three pair deals are
only available per person and cannot be split between two people. Only
one prescription can be used per offer. If you have a distance and a
reading prescription, this is included in the offer as this is
considered to be one prescription. Any prescriptions must have the full
name of the person claiming and a valid expiry date to be able to order.
If you have two different prescribed prescriptions, you will need to
visit a store to be eligible for our two pair and three pair deals.
| FAMILY COVER | 1 Standard OW Pair
from $169^ | 2 Standard OW Pairs
from $199^ | 3 Standard OW Pairs
from $249^ |
| --- | --- | --- | --- |
| $460 per person |
| Partial Cover |
| Partial Cover |
| Partial Cover |
^Excludes add-ons. Standard frames and lenses only. Oscar Wylee’s
standard product inclusions are calculated based on the optical
allowances under each health fund package and may vary. If unsure,
please confirm with your provider. Our two pair and three pair deals are
only available per person and cannot be split between two people. Only
one prescription can be used per offer. If you have a distance and a
reading prescription, this is included in the offer as this is
considered to be one prescription. Any prescriptions must have the full
name of the person claiming and a valid expiry date to be able to order.
If you have two different prescribed prescriptions, you will need to
visit a store to be eligible for our two pair and three pair deals.
## Due for an eye test?
We recommend that everyone should have an eye test with an
optometrist at least once every 2 years.
[Book an an eye test](https://www.oscarwylee.com.au/booking)
*Based on Reserve Bank Health Society’s
[Cover Guide](https://www.myrbhs.com.au/help-centre/download-forms/)
and product factsheet as presented to the Commonwealth Ombudsman
[1](https://www.myrbhs.com.au/siteassets/documents/cover-descriptions/premium-extras.pdf). The benefit limit for frames after 1 year is $180 and $360 after 2
years and for single vision lenses, $185 after 1 year and $370 after 2
years.1 With Reserve Bank Health Society, all
multiple year benefits (2 years and over) are calculated on a rolling
year basis, that is, from the first date of service, instead of
calculation on a calendar year basis. This means a limit of $460 becomes
$920 after 2 rolling years. Get in contact with your health fund
provider to learn your benefit limitation period.
Information correct as of November 2024.
## Your eye test explained
Routine eye test appointments are quick and painless. Find out
what to expect during an eye exam and how to understand your eye
test results.
[Find out more](https://www.oscarwylee.com.au/eye-health/your-eye-test-explained.html)
## Bulk Billing
Find out what bulk billing is and whether you're eligible to
receive an eye test free of charge.
[Find out more](https://www.oscarwylee.com.au/eye-health/eye-test-info/bulk-billing.html)
## What is Pupillary Distance? (PD)
Do you know your PD? It's something you'll need to know when
ordering glasses online. Find out what Pupillary Distance is and
how you can measure your own.
[Read more](https://www.oscarwylee.com.au/eye-care/eye-test/what-is-pupillary-distance.html)
## Book an eye test
Oscar Wylee eye tests are bulk billed through Medicare. This
means there will be no out-of-pocket expense for eligible
Medicare cardholders.
[Book online](https://www.oscarwylee.com.au/booking/)
## Find a store near you
Contact or visit your nearest store for a full quote.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)