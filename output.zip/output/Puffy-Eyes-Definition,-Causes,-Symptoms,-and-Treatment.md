# Source: https://www.oscarwylee.com.au/glasses/eye/puffy-definition

# Puffy Eyes: Treatment, Causes and Symptoms
Updated on June 5th, 2026
Published on February 21st, 2023
Australia    
[Australia](https://www.oscarwylee.com.au/glasses/eye/puffy-definition)
[New Zealand](https://www.oscarwylee.co.nz/glasses/eye/puffy-definition)
[Canada](https://oscarwylee.ca/glasses/eye/puffy-definition)
[Canadian French](https://oscarwylee.ca/fr/glasses/eye/puffy-definition)
Puffy eyes are an eye condition where the skin around and under the eyes appears inflamed, swollen or puffed out. Puffy eyes, also known as periorbital puffiness, can be caused by multiple factors, but most commonly, puffy eyes are caused by fluid gathering in the skin under the eyes which causes this area to appear puffed out.
Causes of puffy eyes include allergies, aging, diet, poor sleep or genetics. Puffy eye symptoms include swollen under eyes, puffy eyelids on the top and bottom of the eyes, red and itching eyes, and bags under the eyes and loose or sagging skin. Puffy eye treatments include home remedies, such as a cool cloth on the face, or lifestyle changes, such as less salt in the diet, and avoidance of allergens. It should be noted that this information is general in nature and does not replace professional medical advice.
Book an eye test
Oscar Wylee offers in-store eye tests performed by fully qualified optometrists.
[Eye test booking](https://www.oscarwylee.com.au/booking)
[Definition](#definition) [Causes](#causes) [Waking Up](#waking-up) [Treatments](#treatment)
## What are Puffy Eyes?
Puffy eyes, medically known as periorbital edema, is an eye and skin condition where the skin around and under the eyes appears swollen. Puffy eyes may also be red and itchy, and other symptoms of the eye condition may be bags under the eyes and skin under the eyes that appears loose and saggy. Puffy eyes are an eye and skin condition that affects the physical appearance of the skin under the eyes.
### What are Puffy Eyes?
The following image is a demonstration of what puffy eyes look like — a side by side of a puffy eye and a regular eye.
### How do Puffy Eyes Form Around the Lower Lid?
Puffy eyes can form around the lower lid as the fat that helps support the eyes can move to this area, causing them to appear puffy or swollen, according to Mayo Clinic. Fluid may also be retained and accumulated under the eyes, causing a puffy appearance.
#### Are Puffy Eyes the Same as Under Eye Bags?
No, puffy eyes are not necessarily the same as under eye bags, although both often go hand in hand. Puffy eyes refer to an eye condition wherein the skin around and under the eyes appears inflamed or swollen. Eye bags are solely under the eye and can look different for each person, such as loose skin, puffiness or prominent dark circles.
## What Causes Puffy Eyes?
Puffy eyes are caused by multiple factors related to age, lifestyle and genetics. Some causes include allergies, eyelid fat prolapse, family history, sleep issues, diet, fluid retention and aging. The causes of puffy eyes are listed below.
* Allergies: Allergies can cause puffy and [irritated](https://www.oscarwylee.com.au/glasses/eye/irritation-causes) eyes because the body's reaction to an allergen creates inflammation in the eyes and body.
* Eyelid fat prolapse: Eyelid fat can cause puffy eyes because aging tissue, muscle and fat in the skin result in fat placing itself in the skin under the eyes.
* Family history: Family history and family genetics can cause puffy eyes because a parent who is prone to having puffy eyes may pass that gene onto their offspring.
* Sleep issues: Sleep issues can cause puffy eyes because they weaken the muscles around the eye, causing more liquid and tears to collect around the skin.
* Diet: Diet is a cause of puffy eyes because eating an excess of salt can cause puffiness across the whole body.
* Fluid Retention: Fluid retention is when the fluid that regularly leaks into body tissues doesn't naturally leave the tissues, according to Better Health Channel. This commonly happens as a result of hormonal fluctuations, particularly during menstruation or pregnancy, leading to temporary puffiness, according to the International Centre for Cosmetic Medicine.
* Aging: Aging can cause puffy eyes because the soft tissue and muscle allows fat to slide under the eye.
### 1. Allergies
[Allergies](https://www.oscarwylee.com.au/glasses/eye/allergies) is a term that refers to the reaction the immune system has to certain foreign substances that may be normally harmless but can cause severe and uncomfortable symptoms in certain people.
### 2. Eyelid Fat Prolapse
Eyelid fat prolapse refers to a type of puffy eyes that occurs due to the skin stretching and the muscles of the eyes getting weaker due to a buildup of fat.
Eyelid fat causes the skin around the eyes to stretch, and fat then sags into the area under the eyes.
### 3. Family History
Family history, or genetics, refers to the passing of certain traits and features from a hereditary body, such as a parent.
If your parents had eye bags or were prone to puffy eyes themselves, then their descendants will share the same genetic propensity. If a parent had sagging or clear eye bags, then the child is very likely to look the same.
### 4. Sleep Issues
Sleep issues refers to any problems or irregular disruptions with a person's natural sleep cycle, such as not getting enough bed rest, or possibly getting too much.
Sleep issues can cause puffy eyes due to fluid retention around the eyes. Puffy eyes occur naturally during sleep and will fade with time. Puffy eyes that do not fade are caused by the muscles and soft tissue of the eyes weakening, allowing excess fluid into the area of skin under the eyes, causing puffiness.
The dark rings around the eyes associated with lack of sleep are because a lack of sleep causes an increase in blood flow. This increased blood flow is clearer in the thinner skin around the eyes.
### 5. Diet
Diet refers to a person's daily intake of food and the nutritional value and effects the food has on the body. A poor diet can cause puffy eyes if there is an excess of salt in meals. Too much salt in a diet can make the body retain more water to compensate, causing additional puffiness around the entire body and creating bags under the eyes.
### 6. Fluid Retention
Fluid retention is when the fluid that regularly leaks into body tissues doesn't naturally leave the tissues, according to Better Health Channel. This commonly happens as a result of hormonal fluctuations, particularly during menstruation or pregnancy, leading to temporary puffiness, according to the International Centre for Cosmetic Medicine.
### 7. Aging
Aging refers to the natural process of the body growing older as time goes on. Aging can affect many parts of the body, causing these parts to grow weaker or possibly lose the complete functionality the part of the body once had.
Aging can cause puffy eyes because as the eyes age, soft tissue and muscle around the eyes lose strength and eventuate towards a more puffy appearance. This can also present as eye bags.
### Why are My Eyes Puffy in the Morning?
Your eyes may be puffy in the morning due to reasons such as fluid retention, lack of sleep, dehydration, or allergies.
#### Is Fluid Retention the Main Reason for Morning Puffiness?
Fluid retention can be a key reason for morning puffiness; however, not necessarily the main one. Fluid regularly leaks into the body tissues from the blood. Your lymphatic system is a series of tubes that drain this fluid called lymph. Fluid retention occurs when lymph is not removed from body tissues normally, according to Better Health Channel. This phenomenon can occur around the eyes during sleep, leading to morning puffiness.
## How does Eye Discharge Relate to Puffy Eyes?
Eye discharge relates to puffy eyes as both often go hand in hand when people wake up in the morning, and both can occur in the eye. In more serious cases, the presence of excessive [eye discharge](https://www.oscarwylee.com.au/glasses/eye/discharge) and puffy eyes can indicate infection.
### Why do I Get Sticky or Watery Discharge When I Wake Up?
It is normal to wake up with some discharge in the corner of the eye, and this is not a concern. However, excessively sticky or watery discharge can be a sign of eye conditions such as Blepharitis or Conjunctivitis, according to Healthline. Make sure to consult a health professional if large amounts of sticky or watery discharge occur when you wake up.
#### Is Eye Discharge a Sign of Infection?
Eye discharge can sometimes be a sign of infection. It will depend on factors such as the amount of eye discharge, its colour, and other symptoms. You may find you experience puffy eyes alongside eye discharge in some cases. Normal eye discharge is usually white or a pale cream colour, according to Health Direct. A large amount of green or yellow discharge should be checked by a health professional.
## Why do I Wake Up with Puffy Eyes and Pain?
You may wake up with puffy eyes and pain if you have slept harshly on your sides, with your eyes making harsh contact with the pillow. Minor puffiness can sometimes occur depending on your sleeping position; however, actual eye pain is not standard. If you experience eye pain, it is important to seek medical advice.
#### Can Dry Eye Syndrome Lead to Puffy and Sore Eyelids?
Yes, dry eye syndrome can lead to puffy and sore eyelids. Some people with [dry eyes](https://www.oscarwylee.com.au/glasses/eye/discharge) can experience inflammation of the eyelids, formally known as blepharitis, which gives the appearance of puffy eyelids, according to Better Health Channel.
Find an Oscar Wylee near you
Come in and see the team for all your eye care and optical needs.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
## What are the Common Symptoms of Puffiness?
The symptoms of puffy eyes are swelling under the eyes, swelling on the eyelid, swelling around the orbit, bags under the eye, saggy or loose skin and watery eyes. The following are the symptoms of puffy eyes.
* Swelling under the eyes: Swelling under the eyes is a symptom of puffy eyes, where the skin under the eyes appears swollen or inflamed.
* Swelling on the eyelid: Swelling on the eyelid is a symptom of puffy eyes, where the top eyelid becomes swollen and bloated.
* Swelling around the orbit: Swelling around the orbit is a symptom of puffy eyes, where the wide area of the skin under the eyes becomes heavily and clearly swollen and puffy.
* Bags under the eye: Bags under the eye are a symptom of puffy eyes, where there is light but clear swelling and puffiness in the skin under the eyes.
* Saggy or loose skin: Saggy or loose skin is a symptom of puffy eyes, where the skin appears to be sagging and loose due to fat falling under the eyelids.
* Watery eyes: [Watery eyes](https://www.oscarwylee.com.au/glasses/eye/watery) can often coincide with puffiness, as well as irritation and redness.
### How can you Distinguish Between Swelling and Redness?
You can distinguish between swelling and redness as swelling refers to the eyelids and surrounding skin of the eyes appearing puffy and inflamed, while redness of the eye usually refers to the eye surface, the cornea, appearing red or pink. However, both are likely to appear hand in hand.
#### Is It Normal to Have Eyelid Swelling Without Pain?
Yes, it is normal to have eyelid swelling without pain. This can be due to allergies or lack of sleep and will often go away on its own.
## What are the Most Effective Treatments for Eye Bags?
The most effective treatments available for puffy eyes include nonsurgical cosmetic treatments, cosmetic surgery, changes to lifestyle, home remedies and over-the-counter medications. These are also effective swelling under the eye treatments. The following are the most effective treatments for puffy eyes.
* Non Surgical Cosmetic Treatments: Non surgical cosmetic treatments for treating puffy eyes involve using injections and chemical peels in order to reduce puffiness and sagging skin around the eyes.
* Cosmetic surgery: Cosmetic surgery for treating puffy eyes involves using invasive surgical procedures in order to treat the skin around and under the eyes.
* Changes to lifestyle: Changes to lifestyle treat puffy eyes by removing the possible causes of the eyes swelling or sources of eye inflammation.
* Home remedies: Home remedies for treating puffy eyes involve actions such as placing ice packs over the eyes and using natural remedies to reduce puffiness and swelling.
* Over-the-counter medications: Over-the-counter medications for treating puffy eyes involve taking antihistamine medication for allergies or using creams to reduce puffiness around the eyes.
### Can Oversleeping Cause Eye Bags?
Yes, numerous sources indicate that oversleeping can cause eye bags, as well as not getting enough sleep.
### Do Puffy Eyes Mean Dehydration?
In some cases, puffy eyes can mean dehydration. You should ensure you drink 8 eight glasses of water a day to stay hydrated.
### Does Drinking Water Help Swollen Eyes?
Yes, drinking water can help swollen eyes. Staying hydrated will flush your system and allow for puffiness to disappear, according to Advanced Dermatology. They advise that you also avoid drinks that dehydrate you, such as alcohol and coffee.
### How do Medical Treatments Compare to Home Remedies for Puffy Eyes?
Medical treatments will likely not be necessary to treat puffy eyes. [Home remedies](https://www.oscarwylee.com.au/glasses/eye/sore/remedies) such as cold compresses, applying tea bags around the swollen skin or eye creams will often allow the swelling to go down. However, you may want to consult a doctor for treatment if you believe the cause of the puffy eyes is allergy related.
#### Can Eye Creams Reduce Bags Under Eyes?
Eye creams may reduce bags under the eyes. However, this will vary for each individual and the brand of cream.
## What Causes One Eyelid to Swell More Than the Other?
The causes that would lead to one eyelid to swell more than the other include an insect bite, chalazion and your sleeping position. Read more about these causes of singular eye swelling below.
* Insect bite: An insect bite, such as from a mosquito, that occurs on just one eye can lead to that eye becoming swollen more than the other. This can happen while you're walking on the street or while you are sleeping.
* Chalazion: A chalazion refers to when there is an inflamed lump or cyst on the eyelid caused by the blockage of an oil gland in the eyelid, according to the Royal Victorian Eye and Ear Hospital. It can lead to tenderness and swelling on the eyelid.
* Sleeping Position: Your sleeping position can lead to one eyelid swelling more than the other. For example, if you sleep on your left side, your left eye may swell due to harsh contact with the pillow.
### Why is a Single Eye Swollen After Sleeping?
A single eye may be swollen after sleeping if you have slept on the corresponding side of that eye. Your eye may be swollen as a result of harsh contact with the pillow.
#### How can Sunglasses Help Protect Sensitive Eyes with Puffiness?
Sunglasses will protect sensitive eyes from puffiness as they do regular eyes. Sunglasses help protect the eyes from the sun and its UV rays. However, they are not a cure for puffiness.
### Can UV Protection Reduce Inflammation That Worsens Puffy Eyes?
[UV protection](https://www.oscarwylee.com.au/glasses/eye/uv-400-protection) will likely not reduce inflammation that worsens puffy eyes. There is little evidence that points to UV exposure as a source of puffy eyes. While it is important to wear sunglasses in high UV settings for protection against UV rays, they will not reduce inflammation or prevent it from occurring.
#### How can Prescription Glasses Improve Eye Strain Linked to Puffiness?
Prescription glasses will likely not improve eye strain linked to puffiness. Eye strain may be a cause of puffy eyes, such as due to lack of sleep. While prescription glasses or [sunglasses](https://www.oscarwylee.com.au/sunglasses.html) allow for lessened strain on visually unclear eyes, it is important to address the cause of eye strain to combat eye puffiness.
## How Can You Prevent Puffy Eyes?
Puffy eyes can be prevented by taking such actions as consuming less salt and meals high in salt in a daily diet, getting better rest, drinking less liquids before going to sleep or placing a cold compress over the affected areas of the eye.
It should be noted that this information is general in nature and does not replace professional medical advice.
Read Puffy Eyes: Treatment, Causes and Symptoms in other Oscar Wylee regions and their languages.
Australia    
[Australia](https://www.oscarwylee.com.au/glasses/eye/puffy-definition)
[New Zealand](https://www.oscarwylee.co.nz/glasses/eye/puffy-definition)
[Canada](https://oscarwylee.ca/glasses/eye/puffy-definition)
[Canadian French](https://oscarwylee.ca/fr/glasses/eye/puffy-definition)
At Oscar Wylee all major health funds are accepted in-store
Come and see your local Oscar Wylee team for your eye care needs and your health fund may help cover some of the cost
[Health Funds](https://www.oscarwylee.com.au/health-funds.html)
Book an eye test at Oscar Wylee and prioritise your eye health.
Our skilled optometrists perform bulk billed eye tests for eligible Medicare Card Holders.
[Book an eye test](https://www.oscarwylee.com.au/booking)