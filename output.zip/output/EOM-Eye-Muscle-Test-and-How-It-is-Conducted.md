# Source: https://www.oscarwylee.com.au/glasses/eye/muscle-test

# EOM: Eye Muscle Test and How It is Conducted
Published on June 5th, 2024
Updated on November 7th, 2024 
Australia
[Australia](https://www.oscarwylee.com.au/glasses/eye/muscle-test)
[New Zealand](https://www.oscarwylee.co.nz/glasses/eye/muscle-test)
[Canada](https://oscarwylee.ca/glasses/eye/muscle-test)
[Canadian French](https://oscarwylee.ca/fr/glasses/eye/muscle-test)
The eye muscle test (EOM)
is a type of test carried out during a routine eye exam to evaluate how
your eyes are moving and their function. During an eye movement test, the optometrist may look out for signs such
as shaking eyes (nystagmus), inaccurate eye movements, crossed eyes and
double vision. The optometrist will conduct an EOM test by getting you to
sit up straight while staring at an object in front of you as they move the
object in different directions. An eye muscle test is a simple and painless
process and is an essential component of the regular eye test process.
Prioritise Your Eye Health at Oscar Wylee
See one of our optometrists for a comprehensive eye test today!
[Eye test near me](https://www.oscarwylee.com.au/booking)
[Definition](#definition) [Procedure](#procedure)
[Results](#results) [Common Disorders](#disorders)
## What is an Extraocular Muscle Test?
An extraocular muscle test
is an eye test carried out to examine any weaknesses or abnormalities
in your eye muscles. An eye muscle test is part of the standard process when getting your
[eyes checked](https://www.oscarwylee.com.au/glasses/eye/check-up)
and typically involves the optometrist moving an object side-to-side, up
and down and having your eyes follow the object. This will allow the
optometrist to identify any signs of eye conditions that affect eye
movement and position such as crossed eyes (strabismus), nystagmus
(rapid and involuntary eye movement) and lazy eye (amblyopia).
### What is the Purpose of an Extraocular Muscle Test?
The purpose of an extraocular muscle test is
to determine whether your eyes are moving normally and ensure that
both eyes are moving together. The optometrist will be able to see if you are exhibiting any signs
of eye conditions that can impair normal eye movement. Therefore, it
is important to maintain regular eye tests so you can have an eye
movement test done.
## How is an Extraocular Muscle Test Conducted?
An extraocular muscle test is conducted
with an optometrist holding an object such as a penlight around 40 cm
away from your face. They will then ask you to follow the object with
your eyes while they move the pen up, down and side-to-side. The optometrist will carry out an extraocular muscle test along with
other tests that also make up a comprehensive eye examination. These
other tests can include a visual field test, a visual acuity test, a
slit-lamp exam, a pressure test, a colour vision test, retinoscopy and a
corneal topography test.
Looking for your next pair of glasses?
Find your nearest Oscar Wylee store and our friendly staff can assist
you. All major health funds are accepted in-store.
[Optometrist near me](https://www.oscarwylee.com.au/locations/full-store-list.html)
## When is an Extraocular Muscle Test Recommended?
An extraocular muscle test
is not necessarily recommended as it is one of the several tests
included in an overall standard eye test. If you are noticing any changes to your vision, you would then be
recommended to have an eye test, which will then involve an eye muscle
test. Therefore, EOM testing would not be recommended on its own as the
optometrist will need to check all other parts of your eye.
### How are the Results of an Extraocular Muscle Test Interpreted?
The results of an extraocular muscle test
are interpreted by the optometrist when visually assessing your eye
movement. The optometrist will check whether your eyes are moving together or
not and if they are moving smoothly without any jerking. These results
may not appear in your prescription but that will depend on the type
of eye movement-related eye condition you might have and its severity.
## What are the Common Disorders Diagnosed with Extraocular Muscle Tests?
The common disorders diagnosed with extraocular muscle tests
are crossed eyes (strabismus), nystagmus (rapid and involuntary eye
movement) and lazy eye (amblyopia). The common disorders diagnosed with extraocular muscle tests are
listed below.
* Crossed Eyes (Strabismus):  Crossed
eyes (strabismus) is an eye condition that commonly affects children
and develops when one eye turns in a different direction than the
other eye. Patients with strabismus have lesser control of eye
movement hindering normal ocular alignment.
* Nystagmus:  Nystagmus is characterised
as an eye condition that affects eye movement. Nystagmus causes the
eyes to involuntarily and rapidly move in up and down (vertical
nystagmus), circular, or side-to-side (horizontal nystagmus) motions.
Nystagmus can occur possibly due to malfunctioning regions of the
brain that control eye movement or from issues related to the ear’s
balance.
* Lazy Eye (Amblyopia):  Lazy eye
(amblyopia) is an eye condition where one of the eyes has worse vision
than the other, due to developmental issues. Lazy eyes can occur when
one eye does not develop the same level of vision skills as the other,
causing the brain to favour the unaffected eye.
### What Should Patients Know About Preparing for an Extraocular Muscle
Test?
Patients should know
that there is no special preparation necessary for extraocular
muscle testing. However, it can be helpful for patients to try to
avoid overexerting their eyes
before their eye test to ensure their eyes are not fatigued.
### How Does an Extraocular Muscle Test Compare to Other Eye Diagnostic
Tools?
An extraocular muscle
test is different compared to other diagnostic eye tests as it only
involves looking at how your eyes move
and does not typically require any special equipment. Other eye
diagnostic tests usually employ certain tools to look further into the
eye and to assess the quality of your vision.
#### Do Optometrists Conduct Extraocular Muscle Tests?
Yes, optometrists do conduct extraocular muscle tests.
An optometrist will perform an extraocular muscle test as part of
your routine eye test. The process will require you to follow an object with your eyes
as the
[optometrist](https://www.oscarwylee.com.au/eye-care/optometrist)
moves it in different directions while examining how smoothly your
eyes move.
#### Can Children Undergo Extraocular Muscle Tests?
Yes, children can undergo extraocular muscle tests.
Children do have extraocular muscle tests performed as they are
one of the components of normal eye test procedures. Children need to have
[regular eye tests](https://www.oscarwylee.com.au/glasses/eye/exam-for-children)
as their vision is still developing and are typically more
vulnerable to developing eye diseases according to the American
Academy of Ophthalmology.
Read EOM: Eye Muscle Test and How It is Conducted in other Oscar Wylee
regions and their languages.
Australia
[Australia](https://www.oscarwylee.com.au/glasses/eye/muscle-test)
[New Zealand](https://www.oscarwylee.co.nz/glasses/eye/muscle-test)
[Canada](https://oscarwylee.ca/glasses/eye/muscle-test)
[Canadian French](https://oscarwylee.ca/fr/glasses/eye/muscle-test)
Experience High Quality Optometry Services From Our Optometrists
Book an appointment online with a qualified Oscar Wylee optometrist
today.
[Eye test near me](https://www.oscarwylee.com.au/booking)
Major Health Funds Accepted In-store
For the purchase of frames and lenses, use your private health fund to
limit how much you pay from your own pocket.
[Discover Health Funds](https://www.oscarwylee.com.au/health-funds.html)