# Source: https://www.oscarwylee.com.au/glasses/best-men-eyeglasses-for-every-face-shape

# 10 Glasses Frames for Men's Face Shape
Updated on November 17, 2025
Published February 9th, 2023
Australia
[Australia](https://www.oscarwylee.com.au/glasses/best-men-eyeglasses-for-every-face-shape)
[New Zealand](https://www.oscarwylee.co.nz/glasses/best-men-eyeglasses-for-every-face-shape)
[Canada](https://oscarwylee.ca/glasses/best-men-eyeglasses-for-every-face-shape)
[Canadian French](https://oscarwylee.ca/fr/glasses/best-men-eyeglasses-for-every-face-shape)
The 10 best glasses frames for men’s face shapes can be found in this buyer's guide. This guide contains the best glasses for oval, round, square, pear and heart faces. The 10 best eyeglasses frames for men are largely defined by personal preference although there are some commonalities between men’s glasses such as darker colours and sharper, more angular shapes such as rectangle and square. To choose the best glasses styles for men, the shape of the face informs what styles and shapes to look out for. The criteria for the best eyeglasses for men will be a combination of style, shape, frame, colour and function.
Prioritise your eye health and book an eye test at Oscar Wylee.
Our dedicated optometrists perform bulk billed eye tests for eligible Medicare Card Holders.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Importance of choosing the right frame](#types)&nbsp;[Complimenting hair and
skin tone](#definition)&nbsp;[Pricing](#choose)
Glasses for men can be compared by using a criteria for the best pair. Colours can be
compared, light and dark, patterned or solid, frames can also be compared such as the type of nose bridge, whether
that’s nose pads or built into the frame as well as the type of arms and hinges. Eyeglasses are optical devices most
often used for vision correction. They consist of a frame that holds the corrective lenses and sits in front of the
eyes by resting on the ears and nose.
The 10 best eyeglasses for men are a combination of classic styles and bold shapes. The best
men’s glasses for different face shapes and their definitions are listed below.
1. Clear Eyeglasses Frames: A modern classic, clear glasses are a staple for many
men as they are effortlessly chic and go with everything.
2. Vintage Round Frames: Vintage round glasses are a much-loved shape that has
stood the test of time, perfect for contrasting the angular features of a square and heart-shaped face.
3. Oversized Eyeglasses Frames: Oversized frames add a touch of drama to the
appearance and are great for balancing out certain features.
4. Browline Glasses Frames: This trendy frame is a combination of bold and subtle with a thicker upper rim and lower bottom rim, helping to draw the eye upwards which is great for pear face shapes.
5. Hipster Eyeglasses Frames: Walking the line between nerdy and chic, hipster
glasses are a bold choice perfect for making a statement no matter what face shape you have.
6. Flat Top Glasses Frames: With the signature bold shape, flat top glasses are
fashionable and cool and add intrigue to all male face shapes.
7. Classic Square Eyeglasses Frames: Nothing beats a classic pair of square glasses
which are great at contrasting the rounded features of men with round and oval face shapes.
8. Aviator Glasses Frames: Aviator glasses are a versatile accessory for both men
and women that are paired with business attire or casual clothes.
9. Tortoiseshell Eyeglasses Frames:  Tortoiseshell is a popular pattern that adds a
touch of sophistication to any pair of glasses. This pattern works with all men’s face shapes.
10. Streamlined Aviator Eyeglasses Frames: Just like classic aviators, streamlined
aviator frames have cleaner lines and curves to offset the angular features of square and heart-shaped faces.
## 1. Clear Eyeglasses Frames
Clear eyeglasses frames are
glasses made with a clear material, often acetate, that appears see-through or white depending on the pair.
Clear glasses can be any shape or style but they are defined by their clear appearance. As the name implies, the
key features of clear frames are the clear colour and material. Clear frames do not come in any other colours,
however, they do come in many different sizes to fit men with narrow, medium or wide faces.
Clear glasses frames are a popular choice because of their universally flattering colour
and appearance. Suitable to be paired with any outfit or attire and are appropriate for many occasions such as
casual work wear or on a night out. Clear eyeglasses frames are currently in demand as they have become a
popular style sold by many glasses retailers.
At Oscar Wylee, our best choice of clear eyeglasses frame is Francis. An
essential shape, Francis is a modern staple. Practical, simple and universally flattering. Francis is a
medium-fit frame made from acetate and comes in Clear Crystal. The frame Francis is a much-loved pair of glasses
for men, one of the best choices for clear glasses at Oscar Wylee and can be purchased from $169.
[](https://www.oscarwylee.com.au/francis-optical.html)
[](https://www.oscarwylee.com.au/francis-optical.html)
## 2. Vintage Round Frames
Vintage round frames are
defined by their rounded shape that holds the lenses. Round frames have been a staple style of
glasses since these corrective devices were invented, making them a vintage style. These perfectly circular
frames come in a variety of colours and are usually made from wire, giving them that vintage and classic look.
Vintage round frames typically come in a smaller size which is perfect for people with narrow face shapes
although they can also be found in a medium and wide fit.
Vintage round frames are a very popular choice among men of different face shapes as they
are always in style. They are used to contrast and soften the harsh angles of certain face shapes such as heart
and square. Key features of the round glasses frame include a circular shape that holds the lens, and often a
thin wire material will make up the frame.
At Oscar Wylee, a good choice for a vintage round frame is Haskell.
Haskell is a subtle take on our most coveted round frame. Packed up with a slightly smaller fit, Haskell comes
with a titanium and metal finish. Haskell can be purchased from $169 and is available in a variety of colours
including Obsidian Black Matte, Rose Gold, and Silver. This classic frame is always in demand and is one of our
best round frames.
[](https://www.oscarwylee.com.au/haskell-optical.html)
[](https://www.oscarwylee.com.au/haskell-optical.html)
## 3. Oversized Eyeglasses Frames
Oversized eyeglasses frames are
glasses that are larger than the average frame. Oversized glasses will have larger lenses to
fill the frame and come in a variety of colours. The shape of oversized eyeglasses vary from round, square,
oval, cat-eye and butterfly as these shapes are simply bigger than their traditional sizes.
Oversized glasses are a popular choice amongst men as they are daring, courageous, and
outstanding as well as versatile and will complement any outfit, perfect for grabbing attention. Due to the
nature of oversized glasses, they are best fit for larger faces with wide proportions. The key features of
oversized glasses are the large shape and bold appearance.
At Oscar Wylee, our best choice of oversized eyeglasses frame is Mesa.
Mesa is a modern-day upgrade of the trusty square frames. They are slightly oversized yet light so you don’t
have to compromise comfort for style. Mesa is made from acetate and is available in a wide array of colours
which are Auburn Tortoise, Blackberry, Chartreuse, Clear Crystal, Electric Pink, Indigo Tortoise, Mustard
Tortoise, Obsidian Black Matte and Prosecco Tortoise. The frame Mesa is a much-loved pair of glasses for men,
one of the best choices for oversized glasses at Oscar Wylee and can be purchased from $169.
[](https://www.oscarwylee.com.au/mesa-optical.html)
[](https://www.oscarwylee.com.au/mesa-optical.html)
## 4. Browline Glasses Frames
Browline glasses frames are a striking pair of glasses that have a thicker upper rim and a thinner lower rim often made with acetate on top and wire on the bottom rim. Browline glasses are characterised by their bold upper section of the frame and they come in a wide variety of colours, shapes and styles.
Browline frames are a popular choice among men as they make a bold statement while still being a minimalist style that complements a variety of face shapes and personal styles. Browline glasses are not currently in demand but they remain a favourite style for many men.
At Oscar Wylee, a great option for a browline glasses frame is Marco. A classic browline glasses reimagined, Marco has spring hinges and an adjustable nose fit for maximum comfort and style. Marco is available in two classic colours, Clear Crystal and Obsidian Black Matte and is a wide fit made from acetate. This frame is a much-loved pair of glasses for men, one of the best choices for browline glasses at Oscar Wylee and can be purchased from $169.
[](https://www.oscarwylee.com.au/marco-optical.html)
[](https://www.oscarwylee.com.au/marco-optical.html)
## 5. Hipster Eyeglasses Frames
Hipster eyeglasses frames are best described as more of an aesthetic than a specific type
of frame. Hipster glasses are a
combination of nerdy and chic, giving off a vintage and intellectual vibe. They are bold and a
bit quirky and come in an array of colours, shapes and styles.
Hipster glasses are a popular choice because of their fun and cool aesthetic which has
bold shapes and quirky styles. Hipster glasses are currently in demand for their adventurous and intriguing
look. They come in all different fits, small, medium and wide, which complements many face shapes.
At Oscar Wylee, a great choice of hipster eyeglasses frame is Duckworth.
Think aviator frames with a modern-day upgrade. Slightly oversized yet light, Duckworth is a wide-fit frame made
of acetate and can be purchased from $169. This high-demand hipster frame comes in multiple colours including
Candy Brown, Citrus, Clear Crystal, Moonstone Grey and Obsidian Black Matte. The frame Duckworth is a well-loved
pair of glasses for men, one of the best choices for hipster eyeglasses.
[](https://www.oscarwylee.com.au/duckworth-optical.html)
[](https://www.oscarwylee.com.au/duckworth-optical.html)
Come in and see the team at your local Oscar Wylee store.
Find your nearest store and our Oscar Wylee staff can help you with your eye care needs.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
## 6. Flat Top Glasses Frames
Flat top glasses frames are a bold style of glasses that have
a distinctive flat top spanning the frame. Flat top glasses are a very fashionable style that
is oversized and typically square or rectangular in shape. These frames come in a wide range of colours to suit
every style.
Flat top glasses are a popular choice for men as they help boost confidence and elevate
their style instantly. The key characteristic of flat top glasses is the straight, flat line at the top of the
glasses that make the shape distinctive and recognisable. This glasses style is more niche than others,
therefore, it is not in high demand.
At Oscar Wylee, a great choice for a flat top glasses frame is Bishop.
Bishop’s sleek and sharp lines make a bold statement. The understated metals allow the unique design to truly
shine and it comes in the sleek colour Obsidian Black Matte. Bishop has spring hinges, adjustable nose pieces
and acetate tips to provide comfort to this unique frame. The frame Bishop is a much-loved pair of glasses for
men, one of the best choices for flat top glasses at Oscar Wylee and can be purchased from $169.
[](https://www.oscarwylee.com.au/glasses/silhouette/bishop-optical.html)
[](https://www.oscarwylee.com.au/glasses/silhouette/bishop-optical.html)
## 7. Classic Square Eyeglasses Frames
Classic square eyeglasses frames are
characterised by their proportionate square shape that has sharp, angular lines and edges. The
classic frame is defined by the simple yet flattering square shape that works to contrast the soft features of
certain face shapes such as round and oval.
Classic square glasses come in a variety of colours and sizes and are a popular choice for
their simplistic elegance. Key features of these glasses include the square shape that has proportionate sides.
Classic square frames are consistently in demand due to their timeless style that work for many different face
shapes.
At Oscar Wylee, a great choice of classic square eyeglasses frame is Cliff.
Cliff is a classic square frame that is large and in charge! It has spring hinges that make for an extremely
comfortable fit and comes in three colours, Eclipse, Obsidian Black and Smoke. These square glasses are a wide
fit, made from acetate and can be purchased from $169. The frame Cliff is a well-loved pair of glasses for men,
one of the best choices for classic square glasses.

[](https://www.oscarwylee.com.au/cliff-optical.html)
[Cliff](https://www.oscarwylee.com.au/cliff-optical.html)
$169    
Add to Cart
[Shop Cliff](https://www.oscarwylee.com.au/cliff-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/cliff-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/cliff-optical.html)
## 8. Aviator Glasses Frames
Aviator glasses frames are a
style of military glasses typically made out of thin wires with large lenses that are wider on the outside than the inside of the frame.
Aviator glasses are a very versatile accessory for both men and women and complement a variety of face shapes.
Aviator glasses are always a highly popular choice and have remained in demand since they
became a military sunglasses invention. You can pair aviators with your business attire or keep it casual.
Aviator glasses are usually made from wire material but come in different colours.
At Oscar Wylee, a good choice of aviator glasses frame is Reno. This
vintage-inspired aviator is anything but old. The titanium frame, adjustable nose fit and sleek bridge design
bring this classic style straight into the 21st century. Reno is a trendy frame that comes in Gold, Rose Gold
and Silver. The wide-fit frame can be purchased from $199 and is a well-loved pair of glasses for men, one of
the best choices for aviator glasses.
[](https://www.oscarwylee.com.au/deus-optical.html)
[](https://www.oscarwylee.com.au/deus-optical.html)
## 9. Tortoiseshell Eyeglasses Frames
Tortoiseshell eyeglasses frames are a type of glasses pattern that are found on a variety
of frame styles and shapes. The tortoiseshell pattern is
a retro mixture of two different colours most commonly using brown and black although can be made using any array of colours.
The vintage print works as a statement piece for all face shapes.
Tortoiseshell glasses are available in a variety of glasses shapes such as square,
rectangle, round and oval. The key feature of tortoiseshell glasses is the pattern which is defined as a mix of
two colours that appears mottled or speckled in a natural, fluid pattern. Tortoiseshell is always a popular,
in-demand colour as it adds a touch of intrigue to the appearance.
At Oscar Wylee, one of the great choices of tortoiseshell eyeglasses frame is Benny.
A big and bold frame, Benny is a thick, rectangular frame that boasts spring hinges, a unisex design and is
perfect for men with round faces. Benny is a wide-fit frame, made from acetate and can be purchased from $169.
[](https://www.oscarwylee.com.au/glasses/materials/benny-optical.html)
[](https://www.oscarwylee.com.au/glasses/materials/benny-optical.html)
## 10. Streamlined Aviator Eyeglasses Frames
Streamlined aviator glasses frames are similar to aviator glasses but have a more
sleek and refined shape. Streamlined aviator glasses have a distinct shape with lenses that are
wider on the outside than the inside and have a thin nose bridge as well as another line running the entire top
of the frame.
Streamlined aviator glasses are a consistently popular frame choice and have remained in
demand since they became a military sunglasses invention. The streamlined nature of the frames means they can be
paired with many outfits and complement the majority of the different face shapes.
At Oscar Wylee, a great choice for a popular streamlined aviator eyeglasses frame is Atomix.
A funky and fresh aviator style, Atomix has a splay bridge for broader noses, a double bar for stability
creating a paired-back look. This frame is a wide fit made from stainless steel and comes in a striking Trophy
Gold colour. Atomix is a well-loved pair of glasses for men, one of the best choices for streamlined aviator
eyeglasses and can be purchased for $169.
## What is the Importance of Choosing the Best Frames for Men's Glasses?
Choosing the best frames for men’s glasses is important, as the wrong frame may impact vision, frame fit and personal style. The best frames for men’s glasses are the frames that best suit the wearer’s eye care needs. This involves several aspects, including [different lenses, frames](https://www.oscarwylee.com.au/glasses/types), fit and size. A frame must fit a person’s face properly, so it does not fall down or pinch too tightly on the ears or nose areas. Choosing the right frame, including lenses, is also an important choice, as lenses can impact how well a person sees. A person should undergo an eye test to determine what lenses are best for them, including single vision or multifocal. Finally, choosing the best frames for men’s glasses is important for the overall look of a frame. A person should choose a frame that best suits their personal style, as well as one that suits their face shape. There are certain frames that are better suited for certain face shapes. For example, a manwith a round face would best suit rectangle frames, as these help bring structure to the face.
[](https://www.oscarwylee.com.au/glasses/silhouette/atomix-optical.html)
[](https://www.oscarwylee.com.au/glasses/silhouette/atomix-optical.html)
## What are Eyeglasses?
Eyeglasses are a device used for vision correction. Eyeglasses are also
known simply as glasses and consist of two lenses, which hold the prescription that will correct vision and
other necessary additions. Glasses typically have a nose bridge, arms, temples, hinges, screws and a rim.
Eyeglasses were invented by British optician, Edward Scarlett, in 1727 with the first pairs of glasses made from
wood, copper and lead frames.
The purpose of [eyeglasses](https://www.oscarwylee.com.au/glasses/types) is to correct vision problems. Most of the time these will be refractive errors
such as long-sightedness and short-sightedness which occur when the light entering the eye does not hit the
retina properly.
### Which are the Best Men's Eyeglasses for Oval Faces?
The best men’s [eyeglasses for oval faces](https://www.oscarwylee.com.au/glasses/face-shapes/oval) include
frames with angular shapes and classic styles. The best glasses for men with oval faces are
listed below.
1. Logan:  The best Oscar Wylee glasses for men with oval faces is Logan.
This pair of eyeglasses is a modern take on the classic rectangular design which offsets the rounded curves
of an oval face.
2. Oliver:  The next best men’s eyeglasses at Oscar Wylee for oval faces is
Oliver. A stylish rectangle-shaped frame with a defined double bolt detailing complements an oval
appearance.
3. Parker:  The third best glasses for men with oval faces at Oscar Wylee is
Parker. Parker has a perfectly angular shape to make an oval face look sharp any day of the week.
[](https://www.oscarwylee.com.au/logan-optical.html)
[](https://www.oscarwylee.com.au/oliver-optical.html)
[](https://www.oscarwylee.com.au/parker-optical.html)
[](https://www.oscarwylee.com.au/logan-optical.html)
[](https://www.oscarwylee.com.au/oliver-optical.html)
[](https://www.oscarwylee.com.au/parker-optical.html)
### Which are the Best Men's Eyeglasses for Round Faces?
The best men’s [eyeglasses for round faces](https://www.oscarwylee.com.au/glasses/face-shapes/round) include
glasses that have sharp angles to contrast the curved appearance. The best glasses for men
with round faces are listed below.
1. Brosque:  The best glasses for men with round faces at Oscar Wylee is
Brosque. These glasses have a strong and reliable style with a wide, rectangular shape that perfectly
complements a rounded face.
2. Dusty: The next best Oscar Wylee men’s eyeglasses for round faces is
Dusty. Dusty is an aviator frame and has a sturdy shape with a sharp line on the bridge to offset the curved
features of a round face.
3. Neal:  The third best glasses at Oscar Wylee for men with round faces is
Neal. With a sleek rectangular frame, Neal has a subtle browline accent that offsets the proportionate
rounded face and brings attention to the gaze.
[](https://www.oscarwylee.com.au/brosque-optical.html)
[](https://www.oscarwylee.com.au/glasses/silhouette/dusty-optical.html)
[](https://www.oscarwylee.com.au/neal-optical.html)
[](https://www.oscarwylee.com.au/brosque-optical.html)
[](https://www.oscarwylee.com.au/glasses/silhouette/dusty-optical.html)
[](https://www.oscarwylee.com.au/neal-optical.html)
### Which are the Best Men's Eyeglasses for Square Faces?
The best men’s [eyeglasses for square faces](https://www.oscarwylee.com.au/glasses/face-shapes/square) include
frames that have
smooth and curved shapes in order to soften the angular feature of a square face. The best
glasses for men with square faces are listed below.
1. Parker Large: The best Oscar Wylee glasses for men with square faces is
Parker Large. This stylish pair of eyeglasses has a softly rectangular shape and a wide fit to soften the
harsh proportions of a square face.
2. Kato: The next best men’s eyeglasses at Oscar Wylee for square faces is
Kato. Kato is a charming, modern, and minimalist frame with a round shape and sleek design, perfect for a
square appearance.
3. Kent:  The third best glasses for men with square faces at Oscar Wylee is
Kent. Inspired by Clark Kent's iconic look, Kent is an oblong shape that adds width to the proportionate
square face and softens a strong, sharp jaw.
[](https://www.oscarwylee.com.au/parker-l-optical.html)
[](https://www.oscarwylee.com.au/kato-optical.html)
[](https://www.oscarwylee.com.au/kent-optical.html)
[](https://www.oscarwylee.com.au/parker-l-optical.html)
[](https://www.oscarwylee.com.au/kato-optical.html)
[](https://www.oscarwylee.com.au/kent-optical.html)
### Which are the Best Men's Eyeglasses for Pear Faces?
The best men’s eyeglasses for pear faces include glasses that
balance the narrow forehead and wider jawline of the pear shape. The best glasses for men
with pear faces are listed below.
Hunter:  The best Oscar Wylee
glasses for men with pear faces is Hunter. A vintage-inspired
classic half frame, Hunter’s horn-rimmed look draws attention up to
the forehead and away from the jawline, perfect for pear faces.

1. Marco:  The best Oscar Wylee glasses for men with pear faces is Marco. A
vintage-inspired classic half frame, Marco’s horn-rimmed look draws attention up to the forehead and away
from the jawline, perfect for pear faces.
2. Wilder: The next best men’s eyeglasses for pear faces at Oscar Wylee is
Wilder. Wilder is a rectangular pair of glasses that are wider than they are tall and help to balance out
the full jawline of a pear face.
3. Leigh Large:  The third best glasses for men with pear faces at Oscar
Wylee is Leigh Large. This frame is a contemporary rectangular style made from ultra-light material that
draws the eye upwards to the smallest part of a pear face.
[](https://www.oscarwylee.com.au/marco-optical.html)
[](https://www.oscarwylee.com.au/glasses/silhouette/wilder-optical.html)
[](https://www.oscarwylee.com.au/leigh-l-optical.html)
[](https://www.oscarwylee.com.au/marco-optical.html)
[](https://www.oscarwylee.com.au/glasses/silhouette/wilder-optical.html)
[](https://www.oscarwylee.com.au/leigh-l-optical.html)
### Which are the Best Men's Eyeglasses for Heart Faces?
The best men’s eyeglasses for heart faces include glasses that
contrast the wide forehead and narrower jawline of the heart shape. The best glasses for men
with heart faces are listed below.
1. Dusty:  The best glasses for men with heart faces at Oscar Wylee is Dusty.
This stylish pair of eyeglasses is universally flattering and its oval shape is perfect for heart faces as
the curves contrast the angular features.
2. Deus: The next best men’s eyeglasses for heart faces at Oscar Wylee is
Deus. Deus is a classic aviator pair of glasses with a wire frame that makes the eyes the main focal point
of the heart-shaped face.
3. Luca:  The third best Oscar Wylee glasses for men with heart faces is
Luca. This intriguing oval frame has a distinctive keyhole nose bridge, a perfect style to complement men
with heart-shaped faces.
[](https://www.oscarwylee.com.au/dusty-optical.html)
[](https://www.oscarwylee.com.au/glasses/materials/deus-sunglasses-1.html)
[](https://www.oscarwylee.com.au/luca-optical.html)
[](https://www.oscarwylee.com.au/dusty-optical.html)
[](https://www.oscarwylee.com.au/glasses/materials/deus-sunglasses-1.html)
[](https://www.oscarwylee.com.au/luca-optical.html)
## How to Choose the Best Men's Eyeglasses for Every Face Shape?
The most suitable way to choose the best men’s eyeglasses for every face shape is to
select glasses that complement the different features of the 5 main face shapes. In order to
complement a certain face shape, glasses should highlight the most flattering aspect of the face, and draw
attention away from the less desirable features. For example, for men with pear faces, glasses should be chosen
to highlight the narrow forehead and draw attention away from a fuller jawline. But for heart-shaped faces, the
opposite is recommended with glasses that compliment an angular chin and balance a wide forehead. Men can also
use a [face shape guide](https://www.oscarwylee.com.au/glasses/face-shapes) which will instruct them
on which shape their face is closest to and the frames that complement their features and dimensions.
The best men’s eyeglasses for oval faces are square and rectangular. For round faces, the
best glasses shapes are geometric and square. The best glasses for men with square faces are round and oval. Men
with pear faces should look for browlines and rectangle glasses and finally, the best men’s glasses for
heart-shaped faces are aviator and oval.
### How Can Men Choose the Best Glasses Frames that Compliment Their Hair Colour and
Hairstyle?
Men can choose the best glasses frames that complement their hair colour and hairstyle by firstly experimenting with what colours feel and look best with their hair colour, and then what frames help their hairstyle look better. Considering hair colour is a good way to select a complementary glasses colour. Brunettes will suit deeper colours such as black, tortoiseshell or maroon for a rich contrast. If you have blonde hair, go for lighter frame colours such as pastels, soft metallics or clear frames to complement your light hair. Black hair will be well-suited to bold colours such as deep reds, as well as neutrals such as black and grey. When it comes to hairstyles, shorter and more textured hair will make your eyewear a focal point on the face. It may then be best to choose a thinner face that will not overpower the face. Medium length hair is versatile when it comes to frames that look good, so you might want to consider thickness and style when it comes to glasses frames
#### What Should Men Look for When Buying Prescription Glasses?
Men should look for a few things when buying prescription glasses, including shape, size and lens type. The most important consideration when buying prescription glasses is lens types. A person needs to have an eye test with an optometrist to determine if or what prescription needs they have. This will then inform the prescription glasses they need including plus or minus power, and whether a single vision of multifocal lens is appropriate. The shape of prescription glasses is important, as certain frame shapes suit certain face shapes better. For example, round prescription glasses are well-suited to rectangular faces, as they help to bring a softness and structure to the face. Size is also important, as glasses need to fit the face well and not slip off, or be too tight.
#### How do you Match Men’s Eyeglasses with Skin Tone?
To match men's eyeglasses with skin tone, a man should identify the undertone of their skin and pick a complementary eyeglasses colour. Skin undertones can be determined by looking at the veins on the inner wrist. If the veins are blue or purple, this usually indicates a cooler tone. If the veins are more blue-green, then a person may have neutral undertones. If the veins are more yellow or green looking, this can indicate a warm undertone. For cooler skin undertones, cooler frame colours such as blue, silver, grey and green will be complimentary. For warmer skin undertones, frames in similarly warmer colours like tortoiseshell, brown, gold, or other earthy tones will be well-suited. Neutral skin tones are relatively versatile in complementing many colours.
## Where is the Best Place to Buy Men's Glasses?
The best place to buy men’s glasses depends on what the consumer is looking for. Great glasses are found in stores or on online websites. At Oscar Wylee, you can [buy men’s glasses](https://www.oscarwylee.com.au/glasses/collection/mens-glasses.html)
[online](https://www.oscarwylee.com.au/glasses/collection/mens-glasses.html) that are suitable for oval, round, square, pear and heart-shaped faces. With bold designs to subtle, everyday pairs, we've got glasses to suit everyone.
### What is the Price Range for Men's Glasses?
There is a wide price range for men’s glasses depending on the brand, style and prescription needs. For example, designer men’s glasses will be more expensive than glasses you buy from online fashion websites or news agencies. Also, purchasing glasses with multifocal or high-index lenses will significantly increase the price of the frames. At Oscar Wylee, a standard pair of men’s glasses from our core range starts from $169, 2 from $199 and 3 from $249.
### What are the Best Eyeglasses for Men in 2025?
The best eyeglasses for men in 2025 include transparent glasses frames, round frames, square glasses and metal frames. The [best eyeglasses for men in 2025](https://www.oscarwylee.com.au/glasses/eyetrend-2024) are a combination of classic and statement shapes that will suit a variety of occasions and personal styles, whilst remaining on trend.
Read 10 Best Men's Eyeglasses Frames for Every Face Shape: Buyer's Guide in other Oscar
Wylee regions and their languages.
Australia
[Australia](https://www.oscarwylee.com.au/glasses/best-men-eyeglasses-for-every-face-shape)
[New Zealand](https://www.oscarwylee.co.nz/glasses/best-men-eyeglasses-for-every-face-shape)
[Canada](https://oscarwylee.ca/glasses/best-men-eyeglasses-for-every-face-shape)
[Canadian French](https://oscarwylee.ca/fr/glasses/best-men-eyeglasses-for-every-face-shape)
Locate your nearest Oscar Wylee store
Find your local Oscar Wylee team who will help you shop our range of fashion-forward
frames.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
Book and eye test at Oscar Wylee
Oscar Wylee eye tests are bulk billed for eligible Medicare Card Holders
[Book an eye test](https://www.oscarwylee.com.au/booking)