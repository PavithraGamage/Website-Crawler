# Source: https://www.oscarwylee.com.au/julia-optical.html

# Julia
1
## Frame Design of Julia Glasses
The frame design of Oscar Wylee’s Julia glasses is characterised by a square-round shape, nose pads and a metal and acetate frame. The Julia frame is a women’s, statement glasses frame that will work for any occasion, whether the wearer wants to liven up their work style or complement a fun outfit for a night out.
$169    
In stock
Only %1 left
2 pairs from $199
Discount auto-applied at checkout
3 pairs from $249
Discount auto-applied at checkout
Qty
Add to cart
Book an eye test
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
excluding prescription lenses
## About Julia Frames
Julia is the square-round you won’t have to worry about getting perfect! The sleek, fine rim makes it an excellent addition to any outfit, effortlessly elevating your style.
| Frame fit | Measurements |
| --- | --- |
| NARROW | 51 - 17 - 140 |
These measurements mean lens width, bridge, and temple length in millimetres (mm). They can be found on the inside of the temple arm. If you already have a pair that you like, you can compare it to these measurements.
### Made from Metal
Oscar Wylee’s Julia frame is a women’s, square-round glasses frame that is perfect for narrow faces and those with round and oval face shapes. The Julia frame is a stylish, widely wearable frame suited to many personal styles. The main specs of Oscar Wylee’s Julia glasses frame including dimensions, shape, materials, lenses, nose fit and hinges are listed below.
| Julia Frame Features | Julia Frame Description | Dimensions | Shape | Materials | Lenses | Nose Fit | Hinges |
| --- | --- | --- | --- | --- | --- | --- | --- |
| The dimensions of the Julia frame are measured in millimetres (mm) and are 51 - 17 - 140, meaning the lens width is 51 mm, the bridge is 17 mm and the temple length is 140 mm. |
| The Julia frame is a square-round shape, well suited to narrow-width faces. |
| Julia glasses are made from a combination of metals with acetate temple tips. |
| The lenses that can be used in the Julia frame are optical lenses, which include single vision and multifocal lenses and non-prescription lenses, which are plain and can have a filter like a blue light filter applied. |
| The Julia frame is fitted with nose pads. |
| The hinges in Julia glasses are spring hinges, which are more flexible than other types of hinges and can extend past 90 degrees. |
Show All
### What Inspired the Frame Design of Oscar Wylee’s Julia Glasses?
The Oscar Wylee Julia frame design was inspired by current fashion trends as square-round glasses shapes are often in fashion.
## What to Know About Oscar Wylee’s Julia Glasses?
There are many aspects of the Oscar Wylee Julia frames that customers should know about, so they can decide whether this is the right frame for them. The Julia frame is a women’s square-round-shaped frame. Oscar Wylee’s Julia frame is suitable for many face shapes but particularly compatible with round and oval face shapes. The Julia frame’s simple design means that they are fashionable all year round. Julia glasses feature the standard [parts of glasses such as a rim, temples, lenses, spring hinges and nose pads.](https://www.oscarwylee.com.au/glasses/eye/part-of-glasses)
### What are the Types of Temple Tips or Earpieces Included with Oscar Wylee’s Julia Glasses?
The type of temple tips or earpieces included in Oscar Wylee’s Julia Glasses are made from acetate.
### What Type of Nose Bridge do Oscar Wylee’s Julia Glasses Have?
The type of nose bridge included in Oscar Wylee’s Julia frame is nose pads.
### What Type of Nose Pads are Included with Oscar Wylee’s Julia Glasses?
Oscar Wylee’s Julia frame includes standard nose pads. Nose pads are great for comfort and can also be adjusted for the perfect fit.
### What Type of Lenses do Oscar Wylee’s Julia Glasses Have?
The type of lenses that typically come with the Oscar Wylee Julia [glasses frame are optical lenses. Optical lenses are glasses lenses that have a prescription within the lens to help correct vision issues such as myopia, hyperopia and astigmatism. Julia glasses can also come with non-prescription lenses, with add-ons such as a blue light filter. Julia frames are currently unavailable as sunglasses online, however, customers can customise in-store and add on tint or polarisation.](https://www.oscarwylee.com.au/glasses.html)
### What Material is Used for the Rim of Oscar Wylee’s Julia Glasses?
The material used for the rim of Oscar Wylee’s Julia glasses frames is stainless steel. The rim refers to the part of a glasses frame that holds the lenses.
### What Type of Hinges are Included with Oscar Wylee’s Julia Glasses?
The type of hinges included with Oscar Wylee’s Julia frames are spring hinges. A spring hinge in a glasses frame refers to hinges that are more flexible than normal hinges and can go slightly beyond 90 degrees. Spring hinges can provide a closer fit to the face.
## What Face Types are Most Suitable for Oscar Wylee’s Julia Glasses?
The face types that are most suitable for Oscar Wylee’s Julia frame are round and oval face shapes. The Julia frame is a square-round shape, meaning that it complements the structure of round and oval faces particularly well. The Julia frames help to balance the features of an [oval face shape or a](https://www.oscarwylee.com.au/glasses/face-shapes/oval)[round face shape, bringing the eyes and brows forward in a flattering way. Although there are many](https://www.oscarwylee.com.au/glasses/face-shapes/round)[glasses for face shapes that may be considered more aesthetically suitable, it is important that people also choose the frames that make them feel most comfortable, and represent their personal style.](https://www.oscarwylee.com.au/glasses/face-shapes)
## What Size Options are Available for Oscar Wylee’s Julia Glasses?
The size options available for Oscar Wylee’s Julia frame are a narrow-frame fit across all colours.
## What Materials are Used to Create Oscar Wylee’s Julia Glasses?
The primary material used to create the Oscar Wylee Julia frame is metal. The rim is made from stainless steel, the nose bridge is made from high nickel, the temples from brass and the temple tips from acetate.
## What’s Included
## OW Case &amp;a Cloth
Protective Case and Lens Cloth
Our high-quality glasses case and lens cloth are included with every purchase of an Oscar Wylee frame. The stylish, magnetic case is made from a hard shell. This sturdy and durable material keeps your glasses protected and safe, wherever you go. Ensure your lenses are clean and scratch-free with our OW microfibre cloth, specifically designed to ensure you have comfortable vision through your lenses.
Oscar Wylee offers:
* Free Shipping for Australian Orders
* 1 Year Warranty on frames and lenses
* Scratch resistance lens coating on all prescriptions
* UV-proof coating on all prescriptions
Health fund rebate: Once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. Learn more about [health funds](https://www.oscarwylee.com.au/health-funds.html).
## Make and Materials
The frames then go through cleaning and strict quality control, and many pairs of crafting hands to be hand-assembled and polished. After your frames have gone through the production process, they are individually examined and packed before making their way to you!As part of our durable frame family, some of our most popular styles, are now in stainless steel. These frames are hypoallergenic, corrosion resistant, light weight, and not sensitive to temperature changes.
## Warranty Information
### Warranty Information
### Warranty Information
Oscar Wylee provides a 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects. We will repair or replace faulty or defective frames or lenses free of charge for warranty claims made within 1 year of the delivery. We also offer repairs or replacement for problems experienced with vision during everyday use for claims made within 30 days of delivery. If the same product has been discontinued or is no longer available, then we may offer an exchange for a similar product or a refund.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Find a Store Location](https://www.oscarwylee.com.au/locations/full-store-list.html)