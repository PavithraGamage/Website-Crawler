# Source: https://www.oscarwylee.com.au/glasses/eye/black

# Black Eye (periorbital haematoma): Causes, Symptoms, Risk Factors and
Treatment
Published on  May 12th, 2023
Updated on June 19th, 2024
Australia
[Australia](https://www.oscarwylee.com.au/glasses/eye/black)
[Canada](https://oscarwylee.ca/glasses/eye/black)
[Canadian French](https://oscarwylee.ca/fr/glasses/eye/black)
A black eye, or a periorbital haematoma, is an area of skin around the eye
that is bruised or discoloured. This article will explore the black eye
definition, black eye symptoms, black eye causes, black eye risk factors and
black eye treatments. A black eye can have a range of causes, the most
common being a hit or blow to the face that causes trauma or injury. Other
causes of a black eye may include surgery and allergies. The symptoms of a
black eye include bruising or discolouration around the eye area and
swelling. Treatment for a black eye should be undertaken at the
recommendation of a healthcare professional, though people may be able to
relieve symptoms such as swelling at home with a cold compress. The risk
factors for a black eye include playing contact or collision sports.
A black eye can be a sign of a serious medical issue. It is important to
seek medical attention if you have a back eye.
Prioritise your eyes at Oscar Wylee
Book an Oscar Wylee eye test, bulk billed for valid medicare
cardholders, and look after your eye health.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Definition](#definition)
[Causes](#causes)
[Symptoms](#symptoms)
[Treatments](#treatments)
## What is a Black Eye?
A black eye is
a general term that refers to bruising around the eye. The
medical term for a black eye is a periorbital haematoma. According to
the American Academy of Ophthalmology, a black eye is commonly caused by
an injury or trauma to the face, usually near or around the eye. If the
area around the eye is injured, it may break the small blood vessels
under the skin, leading to the bruising or discoloration around the eye.
The tissue in this area will also fill with blood and fluid, causing
swelling of the skin.
## What are the Other Terms for Black Eye?
The other terms for a black eye include the scientific term as well as
the colloquial term. The scientific term for a black eye is a
periorbital haematoma. The colloquial term for a black eye is a
shiner.
## How Does a Black Eye Develop?
A black eye will commonly develop due to trauma or injury to the face
and eye area, which leads to a buildup of blood and fluids in the
surrounding tissues. According to Health Direct, Australia’s virtual
public health information service,
the build-up of fluid in the eye tissues as well as broken blood
vessels underneath the skin will cause swelling, black or bluish
discolouration of the skin or a black-looking eye.
A black eye may also develop as a result of allergies, in which the
congestion and swelling makes it difficult for blood to drain from the
face.
## What are the Causes of a Black Eye?
The causes of a black eye include
a knock to the face, contact or collision sports, surgery, a skull
fracture, and allergies or sinus infections.
What causes black eyes to form is swelling and discolouration of the
skin, which has many causes such as trauma or injury to the facial area,
or congestion from allergies. The causes of a black eye are listed
below.
* Knock to the face: A knock to the area
surrounding the eye may lead to swelling and bruising, or a black eye.
* Contact or collision sports: Contact
sports such as basketball and collision sports such as rugby, where a
person is in constant contact with other people or objects, receiving
knocks to the head and face, can often cause black eyes.
* Surgery: Certain surgeries that focus
on the face, such as dental surgery or rhinoplasty can cause a black
eye due to trauma they may have on the facial structures.
* Skull fracture: Trauma from a skull
fracture around the eye may cause a black eye.
Eye infection:
Eye fatigue is a symptom of nearsightedness because the eyes have strained themselves attempting to
focus through the visual issues caused by myopia, resulting in fatigue and eye exhaustion.

* Allergies or sinus infections:
Allergies or sinus infections may cause a black eye due to nasal
congestion and the pressure it can cause around the eyes.
### 1. Knock to the Face
A knock to the face is a common cause of a black eye as
forceful contact with the face can cause injury or trauma, leading
to swelling and discolouration of the skin around the eye.
A knock to the area refers to a knock, a hit, or a blow to the face or
head. A knock to the area surrounding the eye can cause a black eye as
it may cause injury or trauma, which leads to swelling and bruising
and a black eye. A knock to the eye can be caused by a number of
situations including an accident such as walking into something,
falling onto the face, or following a fight where a person is hit in
the face.
### 2. Contact and Collision Sports
Contact sports and collision sports such as basketball, rugby, ice
hockey and boxing, are common causes of black eyes as
the force of contact in these sports can cause injury to the eye
area.
According to Gillette Children’s medical organisation, contact sports
refer to sports such as basketball in which a person is in regular
contact with other people as part of the game. Collision sports refer
to sports such as ice hockey, boxing and rugby when people come into
contact with each other with significant force, including being
punched during boxing or tackled in rugby. In Australia, AFL and rugby
league are considered collision sports, according to Monash
University. Contact and collision sports are common causes of a black
eye as constant forceful contact with other people in the form of
tackles or punches, can cause trauma to the face and the areas
surrounding the eye, leading to a black eye.
### 3. Surgery
Surgery may cause a black eye if
the surgery carried out has a focus on the facial structures,
especially near the eyes, such as rhinoplasty.
Surgery refers to a procedure to treat medical conditions, often by
invasive means such as cutting into the tissue. Surgery may also be
cosmetic in nature. According to Health Direct, surgeries that may
cause a black eye include dental surgery, nasal surgery, and cosmetic
surgery, such as a rhinoplasty or a nose job. Surgery can cause trauma
to the area surrounding the eyes which can lead to swelling and
bleeding under the tissues near the eye, causing a black eye. For
instance, people who have a rhinoplasty or a nose job often suffer
from black eyes due to the trauma to the nasal area during this
procedure which may cause bleeding under the skin and swelling.
### 4. Skull Fracture
A skull fracture may cause a black eye if
it occurs near the eyes. According to the American Academy of
Ophthalmology, a skull fracture may also cause a black eye if
blood from nearby fractures leaks into the tissue near the eyes.
A skull fracture is defined as a fracture or breaking of the skull or
the cranial bones, according to Cedars-Sinai, a Californian healthcare
organisation. A skull fracture may cause a black eye if it occurs on
the cranial bones near the eyes, such as the eyebrows or bones below
the eyes. This is called an orbital fracture. The fracturing of the
bones around the eyes can cause swelling and bleeding in the tissue
near the eye, causing black eyes. A skull fracture can also cause a
black eye if the blood that has been caused by a less localised,
nearby fracture leaks into the tissues near the eyes, causing bruising
and discolouration.
### 5. Allergies or Sinus Infections
Allergies or sinus infections may lead to a black eye as
the pressure these conditions cause around the eye area can result
in swelling and dark discolouration around the eyes.
Allergies are defined as an immunological reaction in which the body’s
immune system releases a substance called histamine, to help fight
what is perceived to be an allergen, such as pollen or animal dander.
Sinus infections are defined as infections that affect the sinuses,
which are cavities or spaces in the face that connect to the nose,
according to Cambridge Dictionary. Both allergies and sinus infections
can cause congestion, which is a build-up of fluid or mucus in the
nasal passages. Congestion can cause a stuffy or full feeling in the
nose. If congestion is particularly bad, it can cause pressure and
swelling around the nose and the eyes. According to Medical News
Today, the swelling of the eye area may make it hard for blood to
drain from the veins in the face, leading to skin discolouration under
the eye, or a black-looking eye. Black eyes that are caused by
allergies are referred to as allergic shiners.
Find an Oscar Wylee store near you
Visit your local Oscar Wylee store and our friendly staff can help you
with your eye care needs, from eye tests to the purchase of stylish
frames.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
## What are the Symptoms of Black Eye?
The symptoms of a black eye include
pain around the eye, swelling around the eye, discolouration, and a
headache.
The most common symptoms of a black eye are black and bluish
discolouration of the tissue around the eye and swelling of these
tissues. However, symptoms may vary depending on what caused the black
eye. The possible black eye symptoms are listed below.
* Pain around the eye: If a black eye
has been caused by trauma to the face or the area around the eye, a
dull or achy pain around the eye can be an indication a black eye may
develop.
* Swelling around the eye: Swelling
around the eye is a common symptom of a black eye and is caused by the
body’s inflammatory response, which tries to heal the injured or
infected part of the body.
* Discolouration: Discolouration is the
most common symptom of a black eye and refers to the blue or black
bruising around the eye, giving the condition its colloquial name.
* Headache: If a black eye has been
caused by injury to the face, or allergies, a headache may be a
symptom of a black eye.
### 1. Pain Around the Eye
Pain around the eye can be a symptom of a black eye
if there has been an injury or trauma to the eye area. Pain
around the eye refers to a dull, or achy feeling around the eye area,
including the eyebrow, nasal and cheekbone areas. Pain around the eye
may be a symptom of a black eye if a person has been hit in the face,
or suffered another injury or type of trauma to the face. Pain around
the eye may be accompanied by swelling, then bruising, causing a
black-looking eye.
### 2. Swelling Around the Eye
Swelling around the eye is a common symptom of a black eye if the
black eye is caused by an injury, infection or allergies, in
which the tissues swell as a result of the inflammatory response.
Swelling refers to a part of the body becoming enlarged due to illness
or injury, according to Cambridge Dictionary. Swelling is part of the
body’s inflammation response, which is deployed to help heal areas of
the body that have been injured or are sick. Swelling around the eye
looks like red or puffy skin around the eyes or an enlargement of the
tissues around the eye. Swelling around the eye can be a symptom of a
black eye if the black eye is caused by an injury or infection around
the eye or allergies. According to Britannica, infection or injury
around the eye may trigger the inflammatory response in the body that
helps to heal the affected tissues by removing the damaged tissue.
Swelling around the eye may blur the vision temporarily, but this
should revert back to normal after the swelling goes down.
If you have blurred vision alongside a black eye, it is important
to seek medical attention.
### 3. Discolouration
Discolouration is the most common symptom of a black eye and is
what gives the condition its colloquial name. Discolouration in
regards to a black eye refers to the black and bluish colour that is
visible in the tissues around the eye. Discolouration around the eye
is caused by a breaking of the small blood vessels underneath the
skin, leading to this black, bluish bruising. In the case of allergic
shiners, discolouration of the tissues around the eye is caused by
congestion-induced swelling that stops the blood from draining from
the face.
### 4. Headache
If a black eye is caused by an
injury or trauma to the face, it may cause a headache. A
headache may also be a symptom of a black eye if the black eye is
caused by allergies or a sinus infection, as the pressure and
inflammation from congestion may lead to a sinus headache.
Headaches may feel like a sharp pain or a throbbing sensation in the
head and the face. Headaches can be felt in many different places,
including behind the eyes and in the sinus areas. A headache may be a
symptom of a black eye if the black eye has been caused by injury,
trauma to the eye area, an allergic shiner or sinus infection.
If a headache that occurs alongside a black eye is painful or
persists, it is important to seek medical attention as soon as
possible.
### When Should You Seek Medical Attention for Your Black Eye?
It is important to
seek medical attention if you have a black eye. Though black
eyes are sometimes a minor case of bruising, they can also indicate a
more serious medical issue, meaning you should see a medical
professional as soon as possible to receive the appropriate treatment.
There are several indicators that suggest a black eye is part of a
more serious medical condition that requires treatment including
blurred vision, double vision, vision changes, light sensitivity or
seeing flashes of light, eye pain, persistent headaches, bleeding in
the eye, or if you lost consciousness when you got the black eye.
The serious symptoms of a black eye that indicate a person may need
immediate medical attention are listed below.
* Blurred vision: Blurred vision may
be caused by a black eye swelling, but can also be caused by trauma
to the eye. Blurred vision in conjunction with a black eye requires
immediate medical assessment.
* Double vision: Double vision refers
to a person seeing two images of the same object. If a black eye has
been caused by an injury or trauma to the face or head area, double
vision may be an indicator of a more serious medical condition and
requires immediate medical attention.
* Vision changes: Vision changes such
as decreased vision and eye floaters, or spots in vision, alongside
a black eye may indicate a more serious medical condition like a
concussion or injury to the eye, requiring medical attention.
* Light sensitivity or flashes of light:
If the cause of a black eye is an injury or trauma to the face, this
may also injure the eye itself, leading to possible light
sensitivity or flashes of light. Any changes to vision require
immediate medical attention so the appropriate treatment can be
given.
* Eye pain: Severe pain in the eye or
around the eye area, is a black eye symptom that requires immediate
medical attention as it may suggest a problem with the eye itself,
or the surrounding areas, such as a fractured eye socket.
* Persistent headaches: A black eye
that is caused by trauma or injury to the face may cause a headache.
If the headache that accompanies a black eye is severe and persists,
it is important to seek medical attention as this may suggest a more
serious medical condition.
* Bleeding in the eye: Bleeding from
the eye, inside the eye or on the surface of the eye, in conjunction
with a black eye, can indicate a serious medical condition such as
damage to the eye. It is recommended to seek medical attention as
soon as possible.
* Loss of consciousness: According to
Health Direct, a person who has lost consciousness whilst sustaining
the injury or trauma that led to a black eye should seek immediate
medical attention, as this can be an indication of a serious medical
issue.
### Can a Black Eye Indicate a More Serious Underlying Condition?
Yes,
a black eye can indicate a more serious underlying condition.
If a black eye has been caused by an injury or trauma to the eye or
area around the eye, a black eye, in conjunction with other symptoms
such as bleeding in the eye, eye pain, persistent headaches, light
sensitivity, vision changes or a loss of consciousness when receiving
the black eye, can indicate a more serious medical condition. It is
important to seek medical attention if you have a black eye,
especially in conjunction with these serious symptoms.
### When Do Black Eye Symptoms Usually Occur?
The most common black eye symptoms which are bruising and swelling
around the eye, may start to develop
1 to 2 days from the time of the injury or trauma to the face that
has caused the black eye. This time may change depending on the
exact cause of the black eye.
According to Health Direct, the blue or black discolouration around
the eye will generally fade to a green or yellow colour after a few
days.
### Will a Black Eye Lead to Any Complications or Long-term Eyesight
Issues?
A black eye may lead to complications or long-term eyesight issues,
depending on the cause of the black eye. A black eye that is
the result of an injury or trauma to the area around the eye, may lead
to complications if the eye has been damaged or the injury is severe.
Black eyes that are caused by allergic shiners will not generally have
any complications or long-term sight issues.
It is important to seek medical attention for a black eye to
receive the appropriate treatment and avoid any complications.
### How Long Until a Black Eye Is Healed?
The healing time for a black eye is
dependent upon what has caused the black eye and how severe the
black eye is.
Generally, it will take 2 weeks for the black eye bruising or
discolouration to fade, as the blood is reabsorbed into the body,
according to Health Direct.
#### Does a Black Eye Naturally Disappear?
Yes, a black eye will generally disappear naturally. The
bruising or discolouration that gives a black eye its name, is the
result of small blood vessels under the skin breaking from trauma or
injury, which leaks blood into the skin. The body will naturally
reabsorb the blood back into the body during the healing process.
## What are the Risk Factors of Black Eye?
The risk factors for a black eye include playing
contact or collision sports, having surgery on areas of the face and
working in high-risk workplaces such as building sites.
The possible risk factors of a black eye are listed below.
* Playing contact or collision sports:
According to Health Direct, Australia’s virtual public health
information service, a hit to the face that causes injury or trauma is
one of the most common causes of a black eye. This means that people
who play contact or collision sports, such as soccer and rugby, are at
a higher risk of getting a black eye. People who play contact or
collision sports are often in forceful contact with others, which may
lead to injury or trauma to the face and head, possibly resulting in a
black eye.
* Surgery to areas of the face: People
who have facial surgery, such as a nose job are also at a higher risk
of getting a black eye as this may cause trauma to the area around the
eye, resulting in a black eye.
* High-risk workplaces: You may be at
risk of a black eye if you work in an environment where you may have
unexpected objects come into contact with the facial area, such as
building sites.
### What are the Black Eye Complications?
The complications from a black eye
mainly revolve around potential vision damage if the black eye has
been caused by trauma or injury to the eye area.
If the eye has been damaged, it may lead to vision issues such as
hyphema and retinal detachment, which can threaten sight.
It is important that you seek medical attention for a black eye to
prevent any complications that may affect your sight.
Some of the potential black eye complications are listed below.
* Hyphema: If a black eye has been
caused by trauma to the eye such as a hit or a blow, this may lead
to hyphema. Hyphema refers to blood collecting at the front of the
eye. A hyphema can lead to vision issues if not treated.
* Retinal detachment: If a black eye
has been caused by trauma to the eye area, this trauma may cause
retinal detachment in serious cases. A retinal detachment requires
urgent care as it is a very severe eye condition. Symptoms of
retinal detachment include the sudden appearance of blurred vision,
flashes of light, eye floaters, and a gradual diminishing of
peripheral vision.
### How is Black Eye Diagnosed?
A black eye will be diagnosed
by a healthcare professional, such as a doctor, a nurse or an
emergency service worker.
The medical professional will assess the eye and determine the cause
of the black eye and how to treat it.
#### Where can you seek Black Eye Diagnosis?
You can seek a diagnosis for a black eye
from a medical professional, at a doctor’s office, or at the
hospital,
such as the emergency room.
## What are the Treatments Available for Black Eye?
The treatment available for a black eye will be
dependent upon the cause of the black eye. If the black eye has
been caused by trauma or injury to the face, a medical professional will
recommend the appropriate treatment. If the black eye is caused by
allergies, known as an allergic shiner, then allergy medication and
decongestant medication may help ease the congestion and swelling that
is causing the black eye.
You should always consult with a healthcare professional before
taking any medication.
At-home treatment methods for a black eye can include pain relief and
icing the area with a cool pack to relieve symptoms of redness and
swelling.
A black eye should only be treated at home after consultation with a
healthcare professional.
### What are the Home Remedies and Treatments for Black Eye?
The home remedies or treatments for a black eye should only be used
after consultation with a healthcare professional.
The home remedies for a black eye revolve around reducing inflammation
and managing pain. The home remedies or treatments for a black eye
include icing and over-the-counter pain relief.
* Icing the area around the eye: Icing
the eye area using a cold compress can be used as a home treatment
for a black eye. Icing involves taking an ice pack wrapped in a
towel or using cold compress, such as a cloth soaked in cool water,
and applying it to the affected area. Icing or using a cold compress
can help reduce swelling and inflammation and promote healing for a
black eye.
* Over-the-counter pain relief: If the
black eye is causing pain, over-the-counter medication may be used
to help relieve this pain.
You should always consult with a healthcare professional before
taking any medication. Do not stop or start medication without
first consulting with a healthcare professional.
### Will Certain Drugs or Supplements Worsen a Black Eye?
A pharmaceutical drug or medication that can make a black eye worse is
aspirin. Aspirin is a type of medication that thins the blood and
helps it to clot. Aspirin can make it easier for the skin to bruise,
according to Health Direct, and may worsen the bruising of a black
eye.
If you have a black eye and are taking aspirin, consult a
healthcare professional for advice on forms of treatment and pain
relief.
### Can Eye Drops Treat a Black Eye?
Eye drops are not a common treatment for a black eye, as the
main symptoms of a black eye are discolouration and swelling around
the eye, not in the eye, which is the area that eye drops are commonly
used. Eye drops are a type of medication that is applied to the
surface of the eyes in liquid form, via an eye dropper.
## How to Prevent a Black Eye?
A black eye
may be prevented in certain situations such as on a worksite or
whilst playing sports.
A black eye that is caused by injury or trauma to the face during
contact or collision sports such as boxing or rugby, may be prevented by
wearing headgear. Headgear is a type of coverage that covers the head,
which can help to prevent direct contact with the head. A black eye may
also be prevented by wearing protective glasses on worksites, such as
building sites, to help prevent debris from entering and injuring the
eye.
### Does Wearing Protective Glasses Prevent a Black Eye?
Yes,
wearing protective glasses may help to prevent a black eye if a
person is working on a building site, or other workplaces
in which there are objects or debris, that may cause injury if contact
is made with the face or the eye area.
Read Black Eye (periorbital haematoma): Causes, Symptoms, Risk Factors and Treatment in other
Oscar Wylee regions and their languages.
Australia
[Australia](https://www.oscarwylee.com.au/glasses/eye/black)
[Canada](https://oscarwylee.ca/glasses/eye/black)
[Canadian French](https://oscarwylee.ca/fr/glasses/eye/black)
Leading health funds accepted in-store
Come and visit your local Oscar Wylee store and your health fund may
help cover some of the cost of an eye test or new frames.
[Health Funds](https://www.oscarwylee.com.au/health-funds.html)
Are you due for an eye test?
Oscar Wylee offers bulk billed eye tests with our experienced and
dedicated optometrists, so you can keep on top of your eye health.
[Book an eye test](https://www.oscarwylee.com.au/booking)