# Source: https://www.oscarwylee.com.au/afterpay.html

Afterpay is now available, in-store only, at Oscar Wylee Australia! Afterpay is a digital payment platform that allows you to purchase now and pay later.
# How does Afterpay work?
Afterpay works in the same simple and fuss free way as your credit card. All you need to do in-store is tap the Afterpay card at the EFTPOS terminal. You then pay off your purchase in 4 instalments over 6 weeks, interest free! At Oscar Wylee, you can use Afterpay for any of our eye care services. Eye tests are bulk billed for eligible Medicare card holders, however, you can use Afterpay for eye tests if needed and for the purchase of our stylish frames.
## How to Purchase Using Afterpay
Using Afterpay is simple, just like using a normal EFTPOS card.
1. Download the Afterpay app and sign-up. You can do this on all phones including Apple and Android phones.
1. Add the Afterpay card to your digital wallet. Afterpay can be used with Apple Pay, Google Pay, or Samsung Pay.
1. Come in to Oscar Wylee and pick a pair of frames or have an eye test with our skilled optometrists. Our Afterpay is available in-store only.
1. Using your phone, tap the Afterpay card at the EFTPOS terminal. The payment will go through like a normal EFTPOS payment.
1. You will then repay the purchase in 4 instalments over 6 weeks, with no interest.
## Refunds
Afterpay refunds work in the same way as normal EFTPOS refunds. All you have to do is tap your card at the EFTPOS terminal in the original store of purchase and we will refund your purchase. It is important to note that Afterpay refunds can be processed in-store only. If you have any issues with refunds, contact Afterpay Customer Support.
## Due for an eye test? Book now:
[Book an eye test](https://www.oscarwylee.com.au/booking)
We recommend that everyone should have an eye test with an optometrist at least once every 2 years. Oscar Wylee offers bulk billed eye tests, so there are no out-of-pocket expenses for eligible Medicare card holders.
## Find a store near you
Contact your nearest Oscar Wylee store to have your eyes tested.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)