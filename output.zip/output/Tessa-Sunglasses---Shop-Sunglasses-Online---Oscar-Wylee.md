# Source: https://www.oscarwylee.com.au/tessa-sunglasses.html

# Tessa
1
## Frame Design of Tessa Sunglasses
The frame design of Oscar Wylee’s Tessa sunglasses is characterised by their oval and round shape, high nose bridge fit, and acetate frame. Tessa is a striking women's glasses frame that will complement any outfit or event, day to night.
$169    
In stock
Only %1 left
2 pairs from $199
Discount auto-applied at checkout
3 pairs from $249
Discount auto-applied at checkout
* 2 &amp; 3 Pair pricing applies to non-prescription sunglasses only. Prescription sunglasses incur additional charges.    
[Non-Prescription](https://www.oscarwylee.com.au/tessa-sunglasses.html#)
Qty
Prescription
Book an eye test
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
excluding prescription lenses
## About Tessa Sunglasses
Have your moment in the sun with Tessa, a contemporary rounded frame with a bold upper rim. This wide-fit frame can take you from the beach to a festival.
| Frame fit | Measurements |
| --- | --- |
| Wide | 53 - 21 - 145 |
These measurements mean lens width, bridge, and temple length in millimetres (mm). They can be found on the inside of the temple arm. If you already have a pair that you like, you can compare it to these measurements.
### Made from Acetate
Oscar Wylee’s Tessa frame is a women's oval and round sunglasses frame that is perfect for those with square, oval, heart, pear, and diamond face shapes. The Tessa frame is a chic and fashionable frame that can be worn every day. The main specs of Oscar Wylee’s Tessa glasses frame, including dimensions, shape, materials, lenses, nose fit, and hinges, are listed below.
Filter category 3 - General purpose sunglasses. High protection against sunglare. Good UV Protection.Not suitable for driving in twilight, at night or under dull conditions
This frame comes with polarised lenses. An additional $100 will be added to your order total for prescription orders.
| tessa Frame Features | tessa Frame Description | Dimensions | Shape | Materials | Lenses | Nose Fit | Hinges |
| --- | --- | --- | --- | --- | --- | --- | --- |
| The dimensions of the Tessa frame are measured in millimetres (mm) and are 53 - 21 - 145, meaning the lens width is 53 mm, the bridge is 21 mm, and the temple length is 145 mm. |
| Tessa is an oval and round shape, well-suited to wide faces. |
| Tessa is made from acetate. |
| The lenses that can be used in the Tessa frame are sunglass lenses, which provide UV protection. Prescription lenses are also available to purchase for the Tessa sunglass frame, both online and in-store. |
| The nose fit for Tessa is a high nose bridge fit. |
| he hinges in Tessa are normal hinges, also known as standard or barrel hinges. |
Show All
### What Inspired the Frame Design of Oscar Wylee's Tessa Glasses?
The Oscar Wylee Tessa frame design was inspired by current fashion trends, as oval and round shapes are often in fashion. An oval and round glasses shape is timeless; it remains popular throughout the decades while other trends come and go.
## What to Know About Oscar Wylee's Tessa Sunglasses?
There are many aspects of the Oscar Wylee Tessa frames that customers should know to decide whether this is the right frame for them. The Tessa frame is a women's oval and round sunglasses frame. Oscar Wylee’s Tessa frame is suitable for many face shapes, but particularly compatible with square, oval, heart, pear, and diamond face shapes. The Tessa frame’s simple design makes them fashionable all year round. Tessa features the standard [parts of glasses](https://www.oscarwylee.com.au/glasses/eye/part-of-glasses), such as a rim, temples, lenses, hinges, and a high nose bridge.
### What are the Types of Temple Tips or Earpieces Included with Oscar Wylee's Tessa Glasses?
The type of temple tips or earpieces included in Oscar Wylee’s Tessa Glasses are made from acetate.
### What Type of Nose Bridge do Oscar Wylee's Tessa Glasses Have?
The type of nose bridge included in Oscar Wylee’s Tessa frame is a high nose bridge fit.
### What Type of Nose Pads are Included with Oscar Wylee's Tessa Glasses?
Oscar Wylee’s Tessa frame does not include adjustable silicone nose pads.
### What Type of Lenses do Oscar Wylee's Tessa Sunglasses Have?
The lenses that can be used in the Tessa frame are sunglass lenses, which provide UV protection. UV protection lenses block harmful ultraviolet rays, safeguarding eyes from damage. The Tessa frame comes in Filter Category 3. These are general purpose sunglasses with high protection against sunglare and good UV protection. They are not suitable for driving in twilight, at night, or under dull conditions. Prescription lenses are also available for the Tessa frame, both online and in-store.
### What Material is Used for the Rim of Oscar Wylee's Tessa Glasses?
TThe material used for the rim of Oscar Wylee’s Tessa glasses frames is acetate. The rim refers to the part of a glasses frame that holds the lenses.
### What Type of Hinges are Included with Oscar Wylee's Tessa Glasses?
The type of hinges included with Oscar Wylee’s Tessa frames are normal hinges, also known as standard or barrel hinges. These provide strength and smooth movement, connecting the frame's arms and lenses.
## What Face Types are Most Suitable for Oscar Wylee's Tessa Glasses?
The face types most suitable for Oscar Wylee’s Tessa frame are square, oval, heart, pear, and diamond face types. The Tessa frame is an oval and round shape, meaning it complements the structure of square, oval, heart, pear, and diamond faces particularly well. The oval and round Tessa frames help balance the features of a [square face shape](https://www.oscarwylee.com.au/glasses/face-shapes/square), an [oval face shape](https://www.oscarwylee.com.au/glasses/face-shapes/oval), a [heart face shape](https://www.oscarwylee.com.au/glasses/face-shapes/heart), a [pear face shape](https://www.oscarwylee.com.au/glasses/face-shapes/pear), and a [diamond face shape](https://www.oscarwylee.com.au/glasses/face-shapes/diamond), bringing the eyes and brows forward in a flattering way. Although there are many different [glasses for face shapes](https://www.oscarwylee.com.au/glasses/face-shapes) that may be considered more aesthetically suitable, it is important that people also choose frames that make them feel most comfortable and represent their personal style.
## What Size Options are Available for Oscar Wylee's Tessa Glasses?
The size option available for Oscar Wylee’s Tessa frame is a wide-frame fit.
## What Materials are Used to Create Oscar Wylee's Tessa Glasses?
The material used to create the Oscar Wylee Tessa frame is acetate. Acetate, also known as cellulose acetate, is a bioplastic made from cotton fibres or wood pulp. At Oscar Wylee, acetate glasses are made by adding a dye to cellulose acetate, which is rolled into a sheet. The shape of the glasses is then cut from this sheet.
## What’s Included
## What's Included
Each pair of glasses comes with a stylish frame case and lens cloth. We offer free shipping across Australia and 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects.
* Free Shipping for Australian Orders
* 1 Year Warranty on frames and lenses
* Scratch resistance lens coating on all prescriptions
* UV-proof coating on all prescriptions
* Stylish case and cloth
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
## Make and Materials
The frames then go through cleaning and strict quality control, and many pairs of crafting hands to be hand-assembled and polished. After your frames have gone through the production process, they are individually examined and packed before making their way to you!Also known as cellulose acetate, these frames are traditionally hand-crafted by skilled craftsmen, with each frame passing through numerous stages of production and are hand-polished to ensure a glorious lustre.
## Warranty Information
### Warranty Information
### Warranty Information
Oscar Wylee provides a 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects. We will repair or replace faulty or defective frames or lenses free of charge for warranty claims made within 1 year of the delivery. We also offer repairs or replacement for problems experienced with vision during everyday use for claims made within 30 days of delivery. If the same product has been discontinued or is no longer available, then we may offer an exchange for a similar product or a refund.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Find a Store Location](https://www.oscarwylee.com.au/locations/full-store-list.html)