# Source: https://www.oscarwylee.com.au/sunglasses/collection/active-collection.html

# OW Active Collection
The active collection
features sports sunglasses frames designed with UV protection and
impact-resistant lenses for those who enjoy an active lifestyle and
the outdoors.
Sunglass frames from the active collection are engineered to take on
all your adventures, move with you and give you an optimal outdoor
experience. Experience active sports eyewear crafted to make you look
good and perform well. Built for performance, designed for
style.
body .oscar-first-description-top-banner__description {
max-height: 500px;
opacity: 1;
}
@media only screen and (max-width: 801px) {
.oscar-first-description-top-banner {
height: 570px !important;
}
}
H1 Placeholder 
Hit the ground running in the OW Active Collection! When you want to spice
up your sporty look or need the perfect companion for your adventures.
Buy 2 pairs from $199 or 3 pairs from $249*
*2 pairs from $199 and 3 pairs from $249 do not apply to Wes and Falcon.
Wes and Falcon are 1 pair from $199 and 2 pairs from $249.
## Built for performance, designed for style.
[](https://www.oscarwylee.com.au/wes-in-night-sky)
[Wes](https://www.oscarwylee.com.au/wes-in-night-sky)
$199
Night Sky
[](https://www.oscarwylee.com.au/nolan-sunglasses.html)
[Nolan](https://www.oscarwylee.com.au/nolan-sunglasses.html)
$169
Obsidian Black Matte
Genevieve
$169
Cioccolato

Todd
$129
Phoenix

Todd
$129
Obsidian Black

Falcon
$199
Beetle Glaze

[](https://www.oscarwylee.com.au/goups-in-beetle-glaze)
[Goups](https://www.oscarwylee.com.au/goups-in-beetle-glaze)
$129
Beetle Glaze
Todd
$129
Beetle Glaze

Lachie
$129
Neptune

[](https://www.oscarwylee.com.au/genevieve-sunglasses.html)
[Genevieve](https://www.oscarwylee.com.au/genevieve-sunglasses.html)
$169
Toasted Coconut
James
$129
Obsidian Black Matte

James
$129
Neptune

Yannis
$129
Paco Blue

Lachie
$129
Burnt Amber

[](https://www.oscarwylee.com.au/owen-in-bolt-blue)
[Owen](https://www.oscarwylee.com.au/owen-in-bolt-blue)
$129
Bolt Blue
Show All
## What Makes Oscar Wylee Active Sunglasses Ideal for Running?
Oscar Wylee active sunglasses can be ideal for running, as they
provide sun protection, durability, comfort and style. The
factors that make Oscar Wylee’s
[sport sunglasses](https://www.oscarwylee.com.au/glasses/sport-sunglasses)
ideal for running are listed below.
* Sun Protection: Oscar Wylee’s active sports sunglasses
feature UV 400 protection, which is the highest level of
protection against the sun’s UV light rays. This is important,
especially for running, as long and frequent sun exposure can
increase the risk of developing cataracts, macular degeneration
and eye growths.
* Durability: Oscar Wylee’s sports eyewear can be ideal for
running due to their durability. The active collection is designed
specifically to take on potential mishaps and minor impacts that
can occur during activities, so you don’t have to worry about them
breaking easily.
* Comfort: Oscar Wylee’s active sunglasses can be ideal for
running as they’re made with high-quality materials that ensure
all-day comfort. They’re lightweight, ensuring optimal use
throughout the day or during your activities.
* Style: Oscar Wylee’s sunglasses can make ideal options for
running if you want not only to prioritise optimal performance but
also style. Sports glasses from Oscar Wylee were crafted with
elevated design and creativity at the forefront.
### Can you Get Prescription Running Glasses in the Oscar Wylee Active
Collection?
Yes, you can get prescription running glasses in the active
collection,
depending on the frame. Prescription lenses are only available to
add to our Nolan and Genevieve styles.
All other styles from the active collection cannot include
prescription lenses. It may be important to note that frames from
the active collection are not necessarily exclusive for specific
outdoor activities and can be optimal options for many different
types of outdoor activities.
### Why Choose Running Sunglasses with Prescription Lenses?
You may want to choose running sunglasses with prescription lenses
for
clear vision, especially if you are nearsighted. For individuals
who want to eliminate the need for another pair
may want to opt for prescription running sunglasses. Runners can
experience benefits such as visual clarity and convenience when
choosing sports sunglasses that can include
[prescription lenses.](https://www.oscarwylee.com.au/glasses/prescription)
### Are Oscar Wylee Sunglasses Good for Sports and Outdoor Activity?
Yes, Oscar Wylee sunglasses can be good for sports and outdoor
activities
as they are equipped with essential components that are optimal
for sun protection and movement.
Oscar Wylee sunglasses make ideal sports eyewear for outdoor
activities as they feature impact-resistant lenses, lightweight
material and anti-slip technology.
### Where Can You Try the Oscar Wylee Active Collection In-Store?
You can try the other Oscar Wylee active collection in-store
at any of our listed locations. We have many stores across the
country, which you can see on our locations page.
Alternatively, you can also use your smartphone to look up
“optometrist near me”. If you have locations enabled on your
smartphone,
[Oscar Wylee](https://www.oscarwylee.com.au/) stores
nearest to you should easily appear in your search results.
#### Are There Any Oscar Wylee Deals or Discounts Available?
Yes, there are Oscar Wylee deals and discounts available.
We have our 2 pairs from $199 deal, our 3 pairs from $249 deal
and free eye tests with any glasses purchased on the same day for
international students. You can check our
[special offers](https://www.oscarwylee.com.au/special_offers.html)
page for all current deals and offerings, and get more info on how
they work. Use our 2 pair or 3 pair deals to purchase your perfect
rotation of sports glasses.
## Due for an Eye Test?
Oscar Wylee offers bulk billed eye tests for valid Medicare
cardholders. Visit us in-store to get your eyes checked.
[Book an eye test](https://www.oscarwylee.com.au/booking)
## OW Active Collection In-Store
Designed for active individuals, hit your peak performance in Active.
Find a store near you to try on the new collection.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)