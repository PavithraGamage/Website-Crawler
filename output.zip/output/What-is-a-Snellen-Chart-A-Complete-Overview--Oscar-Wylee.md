# Source: https://www.oscarwylee.com.au/eye-care/eye-test/snellen-chart

# What is a Snellen Chart? A Complete Overview
Published on September 22nd, 2022
Updated on April 1st, 2025
Australia
[Australia](https://www.oscarwylee.com.au/update_au_path)
[Canada](https://oscarwylee.ca/eye-care/eye-test/snellen-chart)
Canadian French

If you have ever had a comprehensive eye exam with an optometrist, it’s
likely that you have been asked to read from
an eye examing chart, with lines of letters that decline in size.
This chart is called a Snellen Chart.
Keep reading for an overview of the Snellen Chart and how it can be used to
help test your eyesight.
Ready to have your eyes tested?
Book an appointment with an Oscar Wylee optometrist
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Definition](#definition) [History](#history)
[Snellen Chart vs LogMAR Chart](#snellen_vs_logmar)
[Using a Snellen Chart at Home](#snellen_at_home)
## What is a Snellen Chart?
A Snellen Chart is a type of vision chart that tests the clarity and
sharpness of your eyesight, also known as
[visual acuity](https://www.oscarwylee.com.au/glasses/eye/test/visual-acuity). A Snellen Chart may be used during a routine eye exam to determine
how well your eyes see the details of an object at a distance of 20
feet, or 6 metres, away. The results from the Snellen test can be
helpful in deciding if you need any corrective glasses.
## The history of the Snellen Chart
The Snellen Chart was first created in 1862 by Dutch ophthalmologist
Herman Snellen. Snellen is supposed to have created the chart at the
request of his associate Dr. Franciscus Donders, who used early versions
of a wall-mounted eye chart to identify vision problems.
## What do the lines and letters mean on a Snellen Chart?
You may have heard of 20/20 vision, which is commonly understood to
refer to clear vision or normal visual acuity. But did you know that
this ratio refers to the Snellen Chart? Each line of letters on a
Snellen Chart is given a ratio like this. It is an indication of how
clearly you can see.
The letters on a Snellen Chart are used to help test how well your eyes
can identify details in objects. You may notice that the Snellen Chart
does not use all letters of the alphabet. I, J, M, Q, W, X, and Y are
not often used as they have been shown to be too difficult to read at a
distance of 6 metres, regardless of how good your vision is.
## Snellen Chart vs LogMAR Chart
At Oscar Wylee, we use certain elements of the Snellen Chart when
testing your vision. However, we also use it in conjunction with another
chart that tests visual acuity, called a LogMAR chart. LogMAR charts may
look very similar to Snellen Charts, but they are not the same. They use
a different measurement for scoring visual acuity and are formatted
differently.
LogMAR charts will have the same number of letters per line regardless
of size, and the spacing between letters is usually equivalent to the
letter size. LogMAR scoring will usually involve a decimal. Snellen
Charts by comparison will have more letters as the sizing decreases.
They also have irregular spacing between letters and are scored as a
ratio.
At Oscar Wylee our eye examing charts, which are digitised, are called
ETDRS charts. ETDRS charts are a revised, modified version of a Snellen
Chart. Our ETDRS charts have 5 letters per line, in keeping with LogMAR,
and use the Bailey Lovie layout, which has a proportional spacing
between the letters.
Find a store near you
Contact or visit your nearest store for an eye exam
[Find a store](https://www.oscarwylee.com.au/booking)
## How is a Snellen Chart used during a visual acuity test?
A Snellen Chart usually consists of 11 lines of block letters. The first
row will often be one or two large letters, with each line after this
consisting of different letters declining in size. When using a Snellen
Chart, your optometrist will position you 20 feet, or 6 metres back from
the chart. They will then ask you to read out the letters from the
largest at the top, going down until you either reach the bottom or
cannot see the letters clearly.
The optometrist will then proceed to determine your prescription by
having you look at the chart using a set of lenses. You will test each
eye individually and then together. The test should take around 5
minutes and it should not cause any discomfort. This test will be
conducted by an optometrist as part of your routine eye exam, alongside
other testing such as a slit lamp test.
## How do you interpret the results of a visual acuity test?
After testing your visual acuity with the Snellen Chart, your results
will be recorded as a ratio. The first number of the ratio represents
the distance at which the letters are being read, 20 feet or 6 metres,
and the second number represents the line of letters you can read. If
you can see objects clearly from 20 feet away, this will be expressed as
20/20 meaning you have normal visual acuity.
If you want to find out how sharp and clear your vision is, you can book
an eye exam with an independent optometrist at Oscar Wylee on
[our online booking page.](https://www.oscarwylee.com.au/booking)
## Can you use a Snellen Chart at home?
It is possible to use a Snellen Chart at home. There are plenty of
printable tests to be found online. However, home eye exams are not
reliable and can provide inaccurate results. If you need an eye exam of
any kind, it is best to book an appointment with an optometrist. They
will perform a visual acuity test, which may include the use of a
Snellen Chart, LogMAR chart, or ETDRS chart, and interpret the results
correctly.
Read What is a Snellen Chart? A Complete Overview in other Oscar Wylee
regions and their languages.
Australia
[Australia](https://www.oscarwylee.com.au/eye-care/eye-test/snellen-chart)
[Canada](https://oscarwylee.ca/eye-care/eye-test/snellen-chart)
Canadian French

Find a store near you
Contact or visit your nearest store for a full quote.
[Find a store](https://www.oscarwylee.com.au/booking)
Need to have your eyes tested?
Book an appointment with our Oscar Wylee optometrists.
[Book an eye test](https://www.oscarwylee.com.au/booking)