# Source: https://www.oscarwylee.com.au/legal/privacy-policy.html

# Oscar Wylee Privacy Policy Australia
Your privacy is important to us. We respect your personal information and we are committed to maintaining the highest standards to protect your personal information.
In order to provide you with the best service we may ask you to provide us with personal information from time to time. This Privacy Policy explains how we collect, use, store, disclose and protect your personal information in Australia.
In this Privacy Policy, all references to “Oscar Wylee”, “we”, “our” and “us” means Oscar Wylee Pty Ltd (ACN 154 936 526) and their subsidiaries, their holding companies or subsidiaries of such holding companies and their franchisees.
This Privacy Policy also applies to all employees and contractors of Oscar Wylee in relation to the collection, storage, use and disclosure of personal information in the workplace.
Operation of our Policy in Australia
You will be made aware when any personal information is required that may allow Oscar Wylee to identify or contact you. Personal information will usually be requested when you place an order, register for a particular service or competition but may be obtained by Oscar Wylee at other times. By consenting, either expressly or implied, to Oscar Wylee processing your personal information, you will be deemed to have read and accepted the terms of this Privacy Policy. Oscar Wylee will not process your personal information, unless it has your actual or deemed consent. Your personal information will only be used in accordance with this Privacy Policy. You are free at any time to opt out of receiving information from Oscar Wylee at the end of each communication.
We comply with the law in Australia
Oscar Wylee is bound by the&nbsp;Privacy Act 1988&nbsp;(Cth) and the Australian Privacy Principles (APPs) in Australia. This Privacy Policy sets out our practices in relation to the collection, use, disclosure and handling of personal information in Australia. In Australia, the APPs do not apply to employee records.
Personal information and sensitive information in Australia
Personal information is information or an opinion about an identified or reasonably identifiable individual, whether or not the information or opinion is true and whether or not the information is recorded in a material form. Sensitive information is personal information that includes information about a person’s health (among other things).
Types of personal information we collect and hold in Australia
We collect and hold personal information about individuals for the provision of our products and services and purposes connected to those products and services. If you don’t provide us with personal information, we are unlikely to be able to provide you with our services.
Consistent with the provision of our products and services, the types of personal information we may collect and hold include:
1. Your identity and contact details&nbsp;- includes your name, date of birth, gender, email address, home postal address, shipping address (if different), and your contact phone numbers;
2. Your payment details&nbsp;- your bank details and payment card details.&nbsp; Please note payment transactions are encrypted by the acquiring bank or payment service provider. Oscar Wylee will not retain any payment card details submitted by you;
3. Your profile data&nbsp;- if you register a customer account, this includes the profile you create to identify yourself when connecting to our website (including your username and password), and other data about purchases and your personal preferences;
4. Other information&nbsp;– we may collect insurance information, Medicare information, text of communications gathered in the course of our interaction with you on social media and emails, and other information from your interactions with us online, including IP address, URL’s, search histories, and other associated information.
5. We may also collect and hold sensitive information from you.&nbsp; The types of sensitive information we might collect includes prescription information, retinal imagery, medical histories, appointment information, family health histories, and medicine regimes.
How we collect and hold personal information in Australia
We may collect personal information in the course of providing our products and services, from our website, via our clients who pass on your information or third-party agents, or directly from you.
Personal information is held securely, is subject to various security protections, and is held only for as long as the information remains relevant to the purpose for which it was collected.
We take reasonable steps to ensure the security and integrity of the personal information we collect in store, use and disclose including restricted server access, encryption and other industry standard security protocols like use of firewalls and complex password protection.
Purposes for which we hold, use and disclose information in Australia
We will not use or disclose personal information for any secondary purpose, unless that secondary purpose is related to the primary purpose for which we have collected that information, and you would reasonably expect the disclosure in the circumstances, or unless you consent to that use or disclosure.
The purposes for which we hold, use and disclose and process information include:
1. conducting our business which includes providing our services, or the services of a third party, to you;
2. maintaining the safety and security of our operations (e.g. electronic and other security monitoring, maintaining management records);
3. communicating information about our products and services that may be of interest to you;
4. for our internal administrative, research, planning, marketing and development purposes; and
5. for our regulatory and legal compliance, including without limitation compliance with our licensing obligations.
We may also disclose personal information to third party technology partners, including but not limited to Mailchimp, Amazon Web Services, Facebook, Google and other marketing service providers.&nbsp;&nbsp;As part of providing services, such third party technology contractors may be outside Australia and obtain access to personal information.&nbsp; Oscar Wylee believes that such third party contractors are bound to privacy regimes that are substantially equivalent to the privacy requirements in Australia.
Access and correction in Australia
We will take all reasonable steps to ensure any personal data we collect, use or disclose is up to date and accurate.&nbsp; If you believe personal information we hold about you is not up to date or accurate, you may ask us to correct it.
You may ask us to provide you with details of the personal information we hold about you, and copies of that information.&nbsp; We will respond to your request and attempt to provide you with the data within 30 days of receipt of your request.
If we provide you with copies of the information you have requested, we may charge you a reasonable fee to cover the administrative costs of providing you with that information.
Please direct all requests for access and correction to [[email&nbsp;protected]](https://www.oscarwylee.com.au/cdn-cgi/l/email-protection).
Some other rights in relation to your privacy in Australia
Some individuals also have a right, in certain circumstances, to have the information held about them erased. You can talk to us further about this at [[email&nbsp;protected]](https://www.oscarwylee.com.au/cdn-cgi/l/email-protection).
You can also request that we restrict or suspend the processing of your personal information. If you do so, note that we will then be most likely unable to provide the services to you.
Changes to this policy in Australia
We will review and update this Privacy Policy from time to time as needed without notice. Therefore, you should review the terms of this policy periodically to make sure that you are aware of how we collect, hold, store and use personal information.
All information which is held by Oscar Wylee is governed by the latest version of this Privacy Policy at all times.
Complaints in Australia
If you consider a breach of the&nbsp;Privacy Act 1988&nbsp;(Cth) has occurred, you may direct your query to our Privacy Officer and we will attempt to resolve your complaint.
You can contact the Oscar Wylee Compliance Officer by:
Telephone: (+61) 02 8355 4646
Email: [[email&nbsp;protected]](https://www.oscarwylee.com.au/cdn-cgi/l/email-protection)
For more information about privacy in general please contact the following:
In Australia&nbsp;Office of the Australian Information Commissioner (OAIC)www.oaic.gov.au.
If you do not consider our response satisfactory, you may contact the Australian Privacy Commissioner (Australia).
[14 Natural Home Treatments and Remedies for Sore Eyes](https://www.oscarwylee.com.au/glasses/eye/sore/remedies)
[How to Turn On and Off Blue Light On iPhone and Android](https://www.oscarwylee.com.au/glasses/blue-light/how-to-turn-off)
[Puffy Eyes: Definition, Causes, Symptoms, and Treatment](https://www.oscarwylee.com.au/glasses/eye/puffy-definition)
[Why Do My Eyes Hurt When I Wake Up? 8 Causes and Treatment](https://www.oscarwylee.com.au/glasses/eye/reasons-why-eye-hurts-when-waking-up)
[Eye Twitching: Types, Causes, Symptoms, and Treatments](https://www.oscarwylee.com.au/glasses/eye/twitching-definition)
[Chalazion: Symptoms, Causes, Diagnosis, and Treatments](https://www.oscarwylee.com.au/glasses/eye/chalazion)
[Understanding the Gunk in My Eyes: Causes, Types and Treatments](https://www.oscarwylee.com.au/glasses/eye/reason-of-eye-gunk)
[How to Read an Eyeglasses Prescription](https://www.oscarwylee.com.au/glasses/eye/reading-eyeglasses-prescription)
[Best Glasses for Different Face Shapes: How to Choose Glasses for Male and Female Face
Shapes](https://www.oscarwylee.com.au/glasses/face-shapes)
[Red or Bloodshot Eyes: Causes, Symptoms, Treatment, and Prevention](https://www.oscarwylee.com.au/glasses/eye/red-or-bloodshot)
[8 Different Types of Lenses for Glasses](https://www.oscarwylee.com.au/glasses/eye/types-of-lenses)
[7 Different Types of Eye Drops You Should Know](https://www.oscarwylee.com.au/glasses/eye/types-of-eye-drops)
[Eye Floaters: Definition, Causes, Symptoms, and Treatment](https://www.oscarwylee.com.au/glasses/eye/floaters-definition)
[Seeing Flashing Lights in the Corner of the Eye: What is it, Causes, and Treatment](https://www.oscarwylee.com.au/glasses/eye/seeing-flashing-lights-in-corner-of-eye)
[Blepharitis: Types, Causes, Symptoms, Diagnosis, and Treatments](https://www.oscarwylee.com.au/glasses/eye/eyelids-inflammation)
[Best Glasses for Round Face (Male and Female): Frames, Shapes and Types](https://www.oscarwylee.com.au/glasses/face-shapes/round)
[Eye Allergies: Types, Causes, Symptoms, and Treatments](https://www.oscarwylee.com.au/glasses/eye/allergies)
[Different Types of Glasses, Frames, and Lenses](https://www.oscarwylee.com.au/glasses/types)
[Pinguecula: Causes, Symptoms, Diagnosis, and Treatment](https://www.oscarwylee.com.au/glasses/eye/pinguecula)
[Cataracts: Definition, Types, Causes, Symptoms, Treatment, and Prevention](https://www.oscarwylee.com.au/glasses/eye/cataracts)
More Glasses and Eye Health Guides 