# Source: https://www.oscarwylee.com.au/glasses/wear-all-the-time

# Should I Wear My Glasses All the Time? Benefits and Myths
Published on December 18th, 2024
Updated on Month Date, 2025 
Australia
[Australia](https://www.oscarwylee.com.au/glasses/wear-all-the-time)
New Zealand

[Canada](https://oscarwylee.ca/glasses/wear-all-the-time)
Canadian French

There has been much discussion regarding the question ‘Should you wear
glasses all the time?’ Myths such as glasses potentially worsening vision
and that they can lead to lazy eyes are some of the few ones that are often
believed by hesitant wearers. However, the benefits of correctly wearing
glasses such as vision correction, improved safety and reduced eye strain
are true and better for overall wholebeing.
Read on to discover the benefits and myths of wearing glasses and how
often they should be worn.
Look After Your Eyes With Oscar Wylee
Oscar Wylee optometrists perform extensive eye tests, bulk billed for
eligible Medicare card holders.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Necessity of Wearing Glasses](#Necessity-of-Wearing-Glasses)
[Risks of Not Wearing Prescribed Glasses](#Risks-of-Not-Wearing-Prescribed-Glasses)
[Myths About Long Term Glasses Use](#Myths-About-Long-Term-Glasses-Use)
## When Is It Necessary to Wear Glasses All the Time?
It is
necessary to wear glasses all the time if an optometrist prescribes
them for constant, daily correction. This will be the case if the wearer suffers from refractive errors
such as myopia, hyperopia or astigmatism. Wearing glasses consistently
is crucial if the wearer struggles to do everyday tasks without them
such as driving and reading.
### Do I Need to Wear Glasses All the Time for Specific Conditions?
Yes,
certain conditions will require people to wear glasses all the
time. Those with myopia will need glasses to combat blurry long-distance
vision which can impact daily tasks such as driving. People with
hyperopia will need to wear glasses to avoid headaches and fatigue
that can come with viewing objects at a close distance.
[Astigmatism](https://www.oscarwylee.com.au/glasses/eye/astigmatism)
is mitigated by glasses as they correct the distorted and blurry
vision that comes with the condition.
### Can Wearing Glasses Constantly Improve My Vision Over Time?
Wearing glasses constantly will generally not improve vision over
time. Glasses do not reshape your eye structure or fix any underlying
issues. They also do not weaken your eyesight over time if they are
constantly worn. Rather wearing glasses corrects vision, making
everyday eyesight much clearer.
## What are the Benefits of Prescription Glasses?
The
benefits of prescription glasses include vision correction, reduced
eye strain and improved safety.
[Prescription glasses](https://www.oscarwylee.com.au/glasses/prescription)
are corrective lenses worn to correct vision problems. Some of the
benefits of prescription glasses are listed below.
* Vision correction:  Vision correction
is a prominent benefit of prescription glasses. A prescription lens
refracts light onto the retina using either a concave or convex lens
depending on the vision condition. This helps to direct light onto the
retina properly, and helps with the symptoms of refractive errors such
as blurry vision.
* Reduce eye strain:  Reduced eye strain
is a benefit of prescription glasses. Eye strain can be a symptom for
those who suffer from eye conditions such as hyperopia, as
short-distance sight can lead to eye strain and headaches.
* Improved safety:  Improved safety is a
benefit that can occur as a result of wearing prescription glasses for
better vision. Wearing prescription glasses for tasks such as driving
is absolutely crucial for the wearer and other’s safety if they suffer
from poor eyesight.
Visit an Oscar Wylee store near you
Our staff can help you with all your eyewear needs.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
## What Are the Risks of Not Wearing Glasses as Prescribed by My
Optometrist?
The
risks of not wearing glasses as prescribed by an optometrist include
increased difficulty with everyday tasks, eye strain and risks. The risks of not wearing glasses as prescribed by the optometrist are
listed below.
* Increased difficulty with everyday tasks:
An increased struggle with everyday tasks is a massive risk when not
wearing glasses as prescribed by your Optometrist. Your prescription
is given to accommodate your eyewear needs. Without wearing it, tasks
such as reading, driving and watching TV will become a larger
struggle.
* Eye strain:  Eye strain may occur if
you do not wear glasses as prescribed. Glasses assist with clear
vision, and without them your eyes may strain to see clearly, leading
to headaches and fatigue.
* Risk of accidents:  There may be a
risk of accidents when glasses are not worn when they should be.
Whether you are driving, or crossing the street, if you are not
wearing the correct prescribed glasses you could cause injuries to
yourself or those around you.
### How Can I Tell If I Need to Wear Glasses All the Time?
Some signs that you may need to wear glasses all the time include
blurry vision, excessive squinting and seeing halos. These
symptoms indicate you might need to wear glasses more frequently and
seek advice from an optometrist for a personalised eye assessment. The
signs that you may need to wear glasses all the time are listed below.
* Blurry vision:  Blurry vision can
indicate fatigue or dry eyes. However, if blurry vision persists it
could indicate conditions such as nearsightedness or astigmatism.
* Excessive squinting:  Excessive
squinting can occur when your eyes are having trouble focusing such
as when you are reading or working on a laptop. This can impact your
ability to do everyday tasks and potentially indicate hyperopia.
* Seeing halos:  Seeing halos around
various light objects such as bulbs, car headlights and street lamps
can indicate eye conditions such as cataracts and astigmatism. These
symptoms may be corrected with prescription glasses.
#### Is It Safe to Avoid Wearing Glasses Occasionally for Short Periods?
There are
certain situations wherein it is safe to avoid wearing glasses
occasionally for short periods. For example if you have hyperopia, you will need to wear glasses
for reading but not for driving. Ultimately, it is best to consult
an eye care professional regarding when you have to wear glasses and
when you don’t have to.
#### Should I Wear Glasses During Specific Activities?
Glasses
should be worn during specific activities, depending on the eye
condition you have. For example, those with myopia should wear glasses while driving
as it requires robust long-distance vision. Hyperopia sufferers will
need glasses for reading and computer usage, as the words are in
close proximity to the eyes. Ultimately your vision weaknesses and
the regular activities you undergo will determine which specific
activities you should wear glasses.
## What are the Myths About Wearing Eyeglasses for the Long-Term?
There are many myths pertaining to wearing eyeglasses for long-term
periods of time such as
that they can fix all vision problems permanently, they can lead to
lazy eyes and that children should only wear them when their eye
problems become too severe. The myths about wearing eyeglasses for the long term are listed
below.
* Eyeglasses can fix all vision problems permanently:
Eyeglasses cannot fix all vision problems permanently. According to
Optometry Australia,eyeglasses provide temporary correction for
conditions such as myopia and hyperopia. However, they cannot
permanently cure them.
* Wearing glasses can lead to lazy eyes:
The notion that wearing glasses can lead to lazy eyes is a myth. Lazy
eyes refer to when there is reduced vision in one eye. Glasses correct
vision, and do not cause eyes to become lazy. They help reduce eye
strain and promote clear vision, not worsen it.
* Children should only wear glasses when eyesight becomes severe:
Organisations such as The Australian College of Optometry emphasize
the importance of early intervention when there are signs of vision
problems in children. They have stated children should get their eyes
tested as soon as there is a change in their vision as they may need
glasses.
### How Do Different Eye Conditions Affect the Need for Full-Time Glasses
Usage?
Different
eye conditions and their severity will affect the need for
full-time glasses usage. Those with myopia often require glasses for activities such as
driving and going to the cinema. Those with hyperopia will mainly need
glasses for close-up activities such as reading and computer work.
Those with astigmatism will need glasses full-time to maintain visual
clarity at all distances. According to the Mayo Clinic, Presbyopia can
affect those in their mid-40s and up. Presbyopia is the gradual loss
of the eye’s ability to focus on nearby objects, which will require
the need for glasses when doing close up tasks. In each of these
[common eye conditions](https://www.oscarwylee.com.au/glasses/eye/common-problems), the severity will also factor in the need for full-time glasses
usage. Ask your optometrist to confirm whether you require glasses for
full-time use.
#### Can Lifestyle Changes or Eye Exercises Reduce My Dependence on
Glasses?
Certain lifestyle changes can lead to reduced dependence on
glasses. Many experts
suspect that the surge in screen time has increased
short-sightedness. According to Professor Isabella Jalbert, this increase is ‘too rapid to be explained by genetics alone… and it’s highly
likely that lots of screen time is a risk factor for at least some
development of short-sightedness in children.’ To combat this it is important to have screen time limits and if
this is not possible then do the 20-20-20 rule wherein every 20
minutes, you look at something 20 feet away for at least 20 seconds.
Eye exercises such as Figure Eight and Pencil Push Ups can also
potentially strengthen eye muscles and improve blood circulation
when done regularly.
#### Can Glasses Make Your Vision Worse?
Glasses do not make your vision worse. This is a common
misconception when it comes to eyewear. According to the
Optometrists Organisation, this misconception comes from the belief
that ‘forcing’ the eyes to concentrate without the assistance of
glasses helps strengthen the muscles around the eyeball and slow the
potential progression of refractive errors. Ultimately, this force
will lead to eye strain which can cause headaches and fatigue.
However, wearing the wrong prescription can affect the eyes
negatively. Consult an optometrist if you believe your prescription
is too strong or too weak.
#### Are Contact Lenses a Viable Alternative to Wearing Glasses
Full-Time?
Contact lenses can be a viable alternative to wearing glasses
full-time. Contact lenses are a type of thin lens that sits on the surface
of the eye and helps to correct vision issues caused by refractive
errors. Unlike glasses, they are safe for sport and other physical
activity and good-fitting lenses will not fall off the face like
glasses do. However, more care is required when contact lenses are
being used. Your hands must be clean when they are being handled and
the contact lenses must be stored in a clean environment. Many
people may take time to adjust to the feel of using contact lenses
as they sit on the eye. You may want to consult an optometrist to
gauge the suitability of wearing contact lenses.
It is important to note that Oscar Wylee does not sell contact
lenses.
#### Do Children Have Different Requirements for Full-Time Glasses Usage
Compared to Adults?
Children have different reasons as to why they may require
full-time glasses compared to adults. Many have to wear them full-time as classroom tasks will require
it. From reading the smartboard to taking down notes, tasks such as
these require clear eyesight. However, they may not need glasses for
activities such as sports, depending on their eyewear needs. It is
important to seek professional advice from an optometrist and get an
[eye exam for your child](https://www.oscarwylee.com.au/glasses/eye/kids-eye-health)
if there are changes within their vision.
Read Should I Wear My Glasses All the Time? Benefits and Myths in other Oscar Wylee regions and their
languages.
Australia
[Australia](https://www.oscarwylee.com.au/glasses/wear-all-the-time)
New Zealand

[Canada](https://oscarwylee.ca/glasses/wear-all-the-time)
Canadian French

Take Care of your Eye Health with Oscar Wylee
Receive high quality eye tests with our optometrists. Book your eye
test at Oscar Wylee today.
[Book an eye test](https://www.oscarwylee.com.au/booking)
Oscar Wylee Accepts Major Health Funds In-store
Visit Oscar Wylee in-store for eye care services. Your health fund may
be able to cover some of the cost.
[Explore health funds](https://www.oscarwylee.com.au/health-funds.html)