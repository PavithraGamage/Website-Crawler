# Source: https://www.oscarwylee.com.au/glasses/eye/acute-angle-closure-glaucoma

# Acute Angle Closure Glaucoma: Symptoms and Treatment
Published on July 10th, 2026
Acute angle closure glaucoma is a type of glaucoma where the iris is situated too close to the drainage angle of the eye, blocking the passage for aqueous fluid to pass through, according to Glaucoma Australia. This leads to a sudden attack that requires immediate medical attention. Symptoms that will occur instantaneously include blurred vision, severe eye pain, coloured rings around lights, and nausea. Read more about acute angle closure glaucoma below.
It is important to note that Oscar Wylee offers optometry services only; this article is for educational purposes only and is not a substitute for professional medical advice, diagnosis, or treatment. Please call emergency services if you are experiencing the symptoms listed in this article.
Prioritise Your Eye Health
Our team can help you stay up to date with regular eye tests to keep your eyes healthy!
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Definition](#definition) [Symptoms](#symptoms) [Severity](#severity)
## What is Acute Angle Closure Glaucoma?
Acute angle closure glaucoma is a type of glaucoma. In this type, the iris is positioned too close to the drainage angle of the eye, blocking fluid that naturally passes through. If the angle closes, intraocular pressure will rise rapidly and lead to acute angle closure glaucoma, according to Glaucoma Australia.
### How does Acute Angle Closure Glaucoma Develop?
Acute angle closure [glaucoma](https://www.oscarwylee.com.au/eye-care/eye-conditions/glaucoma) develops when the drainage angle between the iris and cornea suddenly narrows or becomes completely blocked. The iris will shift forward and block this avenue of drainage, according to ophthalmologist Dr Parth Shah. The fluid will continue to be produced, with nowhere to drain.
#### Is Acute Angle Closure Glaucoma a Medical Emergency?
Yes, acute angle closure glaucoma is a medical emergency requiring immediate medical attention.
### Who is Most at Risk for Acute Angle Closure Glaucoma?
The people who are most at risk for closed angle glaucoma are people with hyperopia (long-sighted vision), those of Asian descent, older people, and women, according to Glaucoma Australia.
#### Can Certain Medicines Trigger Acute Angle Closure Glaucoma?
Yes, in some cases certain medicines can trigger acute angle closure glaucoma. Certain over-the-counter cold medications can lead to pupil dilation and then acute angle closure glaucoma, according to the Glaucoma Research Foundation.
## What are the Symptoms of Acute Angle Closure Glaucoma?
The symptoms of acute angle closure glaucoma are severe eye pain, reduced acuity, halos around objects of light, and nausea, according to Eye and Ear Organisation Australia. Read more about these symptoms of acute angle closure glaucoma below.
* Severe eye pain: [Severe eye pain](https://www.oscarwylee.com.au/glasses/eye/pain-definition) that persists is a common symptom of acute angle closure glaucoma.
* Reduced visual acuity: Reduced visual acuity can occur as a symptom of acute angle closure glaucoma, leading to [blurry](https://www.oscarwylee.com.au/glasses/eye/blurred-vision) and unclear vision.
* Halos around objects of light: Halos around objects of light, which are bright circles, are often indicative of eye conditions such as acute angle closure glaucoma. They make sources of light, such as streetlights or flashlights, less clear.
* Nausea: Nausea experienced frequently for prolonged periods of time, and sometimes vomiting, are common amongst those with acute angle closure glaucoma.
### How do Early Symptoms Differ From a Severe Glaucoma Attack?
The early symptoms of acute angle closure glaucoma differ from other forms of glaucoma, as these symptoms have a rapid onset that requires immediate medical action, while other forms are often slower and progressive.
Visit us in-store!
See our team and optometrist in-store for any of your eyecare needs.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
## How is Acute Angle Closure Glaucoma Diagnosed?
Acute angle closure glaucoma is diagnosed through a series of eye tests such as a slit-lamp examination, a tonometry test, gonioscopy, optic nerve evaluation and a pupil reactivity test, according to ophthalmologist Dr Parth Shah.
### What Eye Tests Confirm Acute Angle Closure Glaucoma?
The [eye tests](https://www.oscarwylee.com.au/glasses/eye/test-glossary) that will confirm acute angle closure glaucoma include a slit-lamp examination, a tonometry test, gonioscopy, and fundus evaluation. Read more about how these eye tests confirm acute angle closure glaucoma below.
* Slit-lamp examination: A [slit-lamp](https://www.oscarwylee.com.au/glasses/eye/slit-lamp-exam) examination allows the optometrist to see all parts of the eye, such as the optic nerve. A damaged optic nerve can be a sign of glaucoma.
* Tonometry test: A tonometry test measures the intraocular pressure (IOP) to see if it is higher than usual, which is a telltale sign of glaucoma.
* Gonioscopy: A gonioscopy is undertaken to evaluate the internal drainage system of the eye, known as the anterior chamber angle. If this angle is "closed", then the patient may be at risk of glaucoma due to the increased pressure, according to the Glaucoma Research Foundation.
* Fundus evaluation: Fundus evaluation through fundus photography is used to assess retinal conditions such as glaucoma.
#### Is Fundoscopy Enough to Diagnose Acute Angle Closure Glaucoma?
No, fundoscopy is not enough to diagnose acute angle closure glaucoma.
## What is the Treatment for Acute Angle Closure Glaucoma?
Treatments for acute angle closure glaucoma include medications or a laser iridotomy. Medications include various types of eye drops or oral medications. A laser iridotomy is a procedure that makes a hole in your iris to allow fluid to flow through freely, according to the Cleveland Clinic.
### Which Medicines Help Lower Eye Pressure?
The medicines that help lower eye pressure include oral or topical carbonic anhydrase inhibitors, topical beta-blockers, and topical alpha-2 adrenergic agonists, according to Eye and Ear Organisation Australia. These lower Intraocular pressure by suppressing the production of aqueous humour, the fluid that requires regular drainage from the eye.
#### Is Laser Treatment Needed As Emergency Care?
Yes, laser treatment is needed as emergency care after an acute angle closure glaucoma diagnosis. A peripheral iridotomy will be performed with a laser, or a laser iridoplasty, if a peripheral iridotomy cannot be performed, according to Glaucoma Australia.
#### Can Glasses Treat Acute Angle Closure Glaucoma?
No, unfortunately, [glasses](https://www.oscarwylee.com.au/glasses/prescription) do not treat angle closure glaucoma. Medication and surgical procedures are the treatment options for acute angle closure glaucoma, as recommended by your eye health professional.
## How does Acute Angle Closure Glaucoma Compare With Open Angle Glaucoma?
Acute angle closure glaucoma compares with open angle glaucoma in terms of the speed at which symptoms present in individuals. Acute angle closure glaucoma is characterised by a sudden increase in intraocular pressure, while open angle glaucoma entails a gradual presentation of symptoms such as vision loss.
### What Makes Acute Angle Closure Glaucoma More Dangerous?
Acute angle closure glaucoma is more dangerous due to the rapid nature of the symptoms emerging. The word 'acute' is defined as something that comes about quickly with intense and severe symptoms, according to the Australian Institute of Health and Welfare. This makes acute angle closure glaucoma dangerous as it can cause rapid vision loss, meaning immediate medical attention is required, according to Mornington Peninsula Eye Clinic.
#### Can Open Angle Glaucoma Become Acute Angle Closure Glaucoma?
No, open angle glaucoma cannot become acute angle closure glaucoma. These are two separate forms of glaucoma.
#### Can Vision Recover After Acute Angle Closure Glaucoma Treatment?
Vision can recover after acute angle closure glaucoma treatment if the treatment is done promptly. Given the rapid onset of symptoms of acute angle closure glaucoma, quick treatment is essential to restore healthy eyes and vision.
### How Can Future Angle Closure Glaucoma Attacks be Prevented?
Yes and no. You cannot prevent the structural shape of your eye. However, preemptive measures such as a laser iridotomy can be done, ensuring you discuss this with your ophthalmologist.
#### Can Acute Angle Closure Glaucoma Be Cured?
Acute angle closure glaucoma cannot be cured completely in some cases. An acute closure means the drainage of fluids from the eye may not be able to work efficiently again, according to Glaucoma Australia. Eye drops may need to be administered as recommended by an eye health professional, and eye checks should be regular.
Experience High Quality Eyecare Services From Our Team
Book an appointment online with an Oscar Wylee optometrist today.
[Book an eye test](https://www.oscarwylee.com.au/booking)
Major Health Funds Accepted In-store
For the purchase of frames and lenses, use your private health fund to limit how much you pay from your own pocket.
[Health Funds](https://www.oscarwylee.com.au/health-funds.html)