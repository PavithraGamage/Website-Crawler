# Source: https://www.oscarwylee.com.au/locations/optometrist-mildura.html

# Optometrist Mildura
Mildura CentralShop G039, Corner Deakin Avenue and 15th StreetMildura VIC 3500
* Opposite JB Hi-Fi
Opening hours
Monday9:00am - 5:30pm
Tuesday9:00am - 5:30pm
Wednesday9:00am - 5:30pm
Thursday9:00am - 5:30pm
Friday9:00am - 9:00pm
Saturday9:00am - 5:00pm
SundayClosed
*Store hours reflect local standard trading hours and exclude public holidays
[Visit our Mildura Central Google Business page for directions, reviews, and updates.](https://g.page/r/CU53cGL4gh9GEBM)
Book Appointment
[Call us: (03) 5008 4249](tel:(03) 5008 4249)
[Leave a Review!](https://g.page/r/CU53cGL4gh9GEBM/review)
Our Reviews
Michael Englefield
5 days ago
Very helpful and very thorough examination for my new glasses
Geoff Macdonald
1 week ago
Very good service, and quick ????????????
Luche Preglo ONeil
3 weeks ago
⭐⭐⭐⭐⭐
I had my eye check-up at Oscar Wylee last Friday after deciding to get a second opinion becau...se the glasses I got from my previous clinic became uncomfortable and hurt the bridge of my nose over time.
The optometrist was very knowledgeable and took the time to explain my eye condition in a way that was easy to understand. I also learned something I had never been told before—the difference between lens options for distance and reading, and how the position of your vision through the lens matters, especially when looking down for reading. It made me realise how important it is to choose the right lenses for your lifestyle, not just the frame.
One thing I really appreciated was that the staff genuinely asked about what I needed my glasses for before making recommendations. In my past experience at larger optical chains, I often felt like staff would simply say every frame looked good without really understanding my needs. Here, the advice felt more personal and tailored.
As a bonus, my Mildura Health Fund cover meant I received two pairs of glasses for about half the usual price, which was great value.
Overall, a very informative and positive experience. Thank you to the knowledgeable and friendly team at Oscar Wylee Mildura!
P.S can't wait for my new glasses :)
See more
April E
1 month ago
Had an emergency appointment today
The two ladies working were incredible, so caring, understanding ...and kind.
The optometrist was amazing !! Highly recommend!!
Never crossed a better optometrist in my lifetime
Helped me out so much after struggling with my eyes for months!
We are so lucky to have a great team in mildura
I am beyond grateful and thankful
Thanks preshodin!! - April
See more
Ivy Senoc
1 month ago
Jackie Jason
1 month ago
Josh Bottams
1 month ago
Small team, but Big customer service.Super happy with my experience.
Josh 6
1 month ago
Naomi Forbes-Wilson
1 month ago
Great friendly service!
Miley Mcmahon
1 month ago
Natamon Uttaranakorn
1 month ago
⭐⭐⭐⭐⭐
I had a wonderful experience at Oscar Wylee Mildura. The staff were all so friendly and welcom...ing. The optometrist was incredibly patient, explained everything clearly, and never made me feel rushed or pressured throughout the eye test or while choosing my glasses. I felt comfortable and well looked after from start to finish. They gave great advice, and there were so many beautiful frames to choose from. I'm looking forward to picking up my new glasses. Highly recommend!
See more
Lynette MANUEL
2 months ago
I found Oscar Wylee very professional overall and helpful in regard to a more unusual eye concern. I... now have a monitoring plan going forward and am also looking forward to my new prescription specs. The lady at the shop front on the day was very good in explaining everything and assisting me with selecting some new non-prescripton sunglasses, which are really great.
See more
Catherine Wilkie
2 months ago
Staff and optometrist were very helpful and profesional
Mel Walden-Mills
2 months ago
Optometrist was lovely as was the young lady helping me choose my glasses
Macaila Britton
2 months ago
Amazing service and friendly team
Sue Liddell
2 months ago
My experience was very pleasant.
The optometrist was very  professional and also very friendly. I wa...s very happy with his patience whilst doing the test and very informative. The staff were extra helpful and honest when helping me pick out my frames. Very friendly and helpful.
Very happy.
See more
Rachael Vaughan
2 months ago
Positive experience. Staff helped to reassure my daughter who was quite nervous. Very helpful and in...formative.
See more
Adam Irving
3 months ago
Awesome ???? professional
Melinda Morton
3 months ago
Fantastic! Ran on time, thorough appointment and professional. Definitely recommend.
jobin mathew
3 months ago
Very friendly staff and highly professional. My little girl enjoyed the visit .
Clive Robins
3 months ago
Very good service
Compement optomertrist
Frendly staff.
Dennis Murray
3 months ago
Kine Haugland
3 months ago
Gaylene Marquick
3 months ago
Optometrist was excellent. The receptionist was not efficient, changed quote price, and needs to lea...rn not to call older adults darling every second sentence.
See more
bubble tea
4 months ago
Have a pleasant experience with Oscar Wylee. Helpful and amazing customer service from the staff, de...tails explanations from the optometrist and patiently answer all my queries. Gladly and surely will come back again. Thank you Oscar Wylee ❤️
See more
Alice Smythe
4 months ago
Absolutely fantastic experience! From the moment I walked in, the customer service was outstanding. ...I had a very professional young lady, Olivia, help me. Everything was explained clearly, and she took the time to answer all my questions without rushing me.
The whole process was smooth, efficient, and stress-free. It’s rare to find a place where you feel so well looked after! They also have the lowest prices in Mildura. Highly recommend choosing Oscar Wylee
See more
H f
4 months ago
The optometrist was very thorough in his assessment of my eyes, especially the left for which I book...ed an emergency consultation for.
Point of Sale staff were pleasant, helpful and empathetic towards my predicament.
Big thank you????
A fabulous selection of frames priced exceptionally well.
Highly recommend
See more
Cam Hardie
4 months ago
Great and easy experience, Olivia (staff) was a great help. Thank you very much
Waanjai
4 months ago
Excellent service and super helpful staff.
Maya Harper
4 months ago
syawal husin
4 months ago
Sherrie Wilkins
5 months ago
The optometrist was very friendly and professional. The staff at Mildura were and always are as help...ful as they can be. I have lots of faith in the team and will continue to trust them with my eye care
See more
Cody Maree
5 months ago
Sharon Burness
6 months ago
I find picking frames daunting and  overwhelming, Devin was so patient and very helpful.
Catherine o...ptometrist was also very helpful, she answered all my questions.
Looking forward to a new pair.
See more
Amy-Jean Louw
6 months ago
Yennieann94 Yennieann94
6 months ago
Rhonda Johnson
7 months ago
Bonnie Jobe
7 months ago
Excellent service from all of the team
Diane Gledhill
9 months ago
Fantastic service lovely staff and very helpful
Grace Gray
10 months ago
Excellent appointment, with great advice and practical strategies.  Very professional.  Many thanks.
Meagan Louise Photography
10 months ago
Sia Miki
10 months ago
Great service
Joanne Garsed
11 months ago
Excellent, the best contact I recall having, staff friendly, knowledgeable, range of products very g...ood, staff very helpful when selecting frames, premises also well presented. Attended after recommendations from family members.
See more
ana cenzon
11 months ago
Tegan Zanker
11 months ago
Lovely staff, thoroughly done and examined.
Easy to book a date and time.
Would highly recommend.
Juliana Oware
11 months ago
Great service.  Courtney was very knowledgeable.  Explained everything she was doing to me. Thats wa...s good
See more
Robyn Mills
1 year ago
I went in with a severe bruise in my eye. Staff were great, the optometrist explained everything.  F...riendly staff. Overall great experience
See more
Tracy Moffat
1 year ago
Carol Doyle
1 year ago
Great staff at centro, so happy with them and looking forward to receive my glasses, thank you so mu...ch.I'll be going there again for future eye tests.
See more
Rhonda Oktay
1 year ago
## Find an Optometrist in Mildura Central With Oscar Wylee
You can find our Oscar Wylee store in the Mildura Central Shopping Centre. Conveniently located opposite JB Hi-Fi, at the Woolworths end of the centre, our Oscar Wylee optometrists are equipped to provide Medicare bulk billed eye tests, which include vision testing and examinations to help detect possible eye diseases or conditions. To make your appointment with us, you can take one of the buses that service the centre approximately every 30 minutes. Once here, our friendly retail staff will help you shop our range of stylish and affordable frames. 
Once you’ve finished your appointment with us, why not explore the local area. Mildura is known as the edge of the outback so if you like the outdoors, you can enjoy the nearby parks, or take a river cruise and enjoy the natural beauty of the Murray or Darling Rivers. If you live close to the Broken Hill and Renmark areas and want to see a high-quality optometrist near you, visit Oscar Wylee Mildura today!        
Meet Our Team
* Store Manager
Our Services
* Bulk Billed Eye Examinations
* Professional Frame Styling
* Frame Adjustments and Repairs
Show All
## Find an Optometrist in Mildura, Victoria for an Eye Health Test
Find an Oscar Wylee optometrist in Mildura, Victoria for your regular eye health test. Located in the Mildura Central Shopping Centre, our team of eye care professionals is dedicated to providing customers with high-quality services such as eye tests to assess vision and detect eye disease, prescription updates, and new frames. Our retail staff and optical dispensers are in-store to help customers shop for new eyewear including prescription glasses, prescription sunglasses and non-prescription eyewear. Our Mildura optometrists can also refer patients to an eye doctor, known as an ophthalmologist in Australia, if additional eye care is needed.
At Oscar Wylee our eye tests are a part of Australia’s Medicare system, meaning they are available at a bulk billed price, with no out-of-pocket expenses for eligible cardholders. The average price range for an optometrist in Melbourne, Victoria can vary depending on factors such as the patient’s age, health and visual needs. If you are in need of an eye health test in Mildura, Victoria, visit our Oscar Wylee glasses store where our dedicated team will take care of you!
## How to Find an Optometrist in Mildura, Victoria?
To find an optometrist in Mildura, Victoria you can take certain steps that can help make it easier for you such as searching online, assessing the store’s opening hours and finding the directions to your chosen location. The steps on how to find an optometrist in Mildura, Victoria are listed below.
1. Search online using the phrase, optometrist near me in Mildura. This can also be done here on the website via our locations page.
2. Click on the Oscar Wylee link, which will take you directly to our Mildura optometrist store page.
3. See the store’s opening hours and where the store is located specifically.
4. Use the Mildura Google Business page link located under store hours to see the directions on how to get to the store.
You can also find an optometrist in Mildura, Victoria by searching the keywords optometrist near me. If you have locations enabled on your smartphone and you’re in the Mildura, Victoria area, our Mildura store page should appear easily for you to click on.
### Is it Hard to Get an Eye Appointment in Mildura, Victoria?
No, it is not hard to get an eye appointment in Mildura. You can easily book an appointment to see an Oscar Wylee optometrist in Mildura, Victoria right here on this page. At Oscar Wylee we have highly qualified optometrists available for bulk billed eye appointments, which can be booked online or in-store.
#### How to Compare Optometrists in Mildura, Victoria to Each Other?
To compare optometrists in Mildura, Victoria, you can use factors such as eye tests offered, health fund coverage, lens types and add-ons and eyewear offered. To take care of your vision and eye health, it is important to receive an eye test at least once every two years. There are different types of tests that can be performed in an eye test and not all optometrists may offer the same tests. Health funds can be used to help cover some of the cost of your frames and lenses. To find out if your health fund is accepted at an optometrist in Mildura, Victoria visit their website. In the case of Oscar Wylee, we accept all major health funds and provide on-the-spot claims in-store. There are many different lens options available for prescription glasses such as single-vision, multifocal and high-index lenses. Most optometrists in Mildura, Victoria will offer these lenses although it is good to make sure. There are also lens add-ons available to enhance your glasses such as anti-reflective and blue light filters. Finally, if you are looking to purchase a pair of glasses after your eye test, you can compare the different styles and colours you are interested in from the optometrists in Mildura, Victoria. Oscar Wylee offers a wide range of frames with vintage and modern inspirations in bold colours and subtle designs.
#### How to Find an Eyeglasses Shop in Mildura, Victoria?
To find a glasses store in Mildura, Victoria you can try to follow these simple steps including searching online, selecting a convenient location and looking at their health insurance policies.  The steps on how to find a glasses store in Mildura, Victoria are listed below.
1. Search online using the phrase, glasses store in Mildura, Victoria. This will provide you with various options for glasses stores in the whole Mildura, Victoria area.
2. Select a glasses store that is most convenient for you to travel to.
3. Click the link to find out more information such as opening hours, exact location and directions to the glasses store in Mildura.
4. Read their health insurance policies to ensure you know what health benefits you have access to.
Our Oscar Wylee glasses store in Mildura, Victoria offers primary eye care services such as comprehensive eye tests as well as other services performed by an optometrist and offers prescription and non-prescription eyewear.
##### Is it Possible to Purchase Prescribed Sunglasses in Mildura, Victoria Without Seeing an Optometrist?
Yes and no, it is possible to [purchase prescribed sunglasses](https://www.oscarwylee.com.au/sunglasses.html) in Mildura, Victoria without seeing an optometrist if you already have a prescription that has not expired. If your prescription is expired, you can book an eye test to receive an updated or new prescription which will require you to see an optometrist. This will ensure your prescription sunglasses are appropriate for your visual needs.
## Where is the Oscar Wylee Mildura, Victoria Optometrist Located?
The Oscar Wylee Mildura optometrist is located on the ground level of Mildura Shopping Centre. Mildura Shopping Centre can be found on the corner of Deakin Avenue and 15th Street in Mildura, Victoria.
### What is the Phone Number of Oscar Wylee Mildura, Victoria Optometrist Store?
The phone number for our Oscar Wylee Mildura, Victoria optometrist store is (03) 5008 4249. Our Oscar Wylee Mildura, Victoria store is open, and our staff are available to be contacted, between the hours of 9 am and 5.30 pm from Monday to Friday, 9 am to 5 pm on Saturdays and 10 am to 5 pm on Sundays.
### What are the Reviews for Oscar Wylee Mildura, Victoria Optometrist?
The customer reviews for our Oscar Wylee Mildura, Victoria optometrist, can be found here on the website and online when you search for Oscar Wylee Mildura optometrist. The reviews for our Oscar Wylee Mildura optometrist are listed below.
* Sarah Foster:  The young lady that saw me in the Mildura store was very kind, extremely informative and efficient. It was a lovely experience.
* Susan Scott:  Friendly staff. Professional setting and excellent choice of eyewear. Costings are simplified and well explained.
* Sharon Poha:  I thoroughly enjoyed the experience from the moment I walked into Oscar Wylee. The service was absolutely outstanding and so accommodating. Thank you ladies, I commend you for an awesome time!
#### What Treatments or Eye Care Processes are Done in the Oscar Wylee Mildura, Victoria Optometrist Location?
The treatments or eye care processes done in the Oscar Wylee Mildura, Victoria optometrist location include a tonometry test, a slit lamp exam and a refraction test. Additional tests that may also be performed can include a dilated fundus exam. The treatments or eye-care processes that are done in the Oscar Wylee Mildura optometrist location are listed below.
* A Tonometry Test: An optometrist or optical dispenser will conduct a tonometry test which involves the use of a machine that will release small puffs of air into your eyes. This will assist with measuring pressure in the eye.
* Slit Lamp Test: A slit lamp test can be used to evaluate your eye health, by examining your cornea and iris which are the anterior and posterior of the eye.
* Refraction Test: During a refraction test, an optometrist will have you view an image through different lenses and ask you to confirm which helps you see the image clearer.
* Dilated Fundus Exam: A dilated fundus exam can help an optometrist assess your health in more detail by getting a clear view of the retina. This test is typically carried out for patients with diabetes and those who may be at risk of developing retinal damage.
## How Many Optometrists Exist in Mildura, Victoria?
There are many optometrists that exist in Mildura, Victoria including Oscar Wylee. The amount of optometrists available in an area will typically depend on the population and the eye care needs of those in the area. At Oscar Wylee Mildura, Victoria, our team is passionate about providing our customers with high-quality, dedicated eye care services. Our optometrists are available to provide bulk billed eye tests with our dedicated optometrists, prescription updates and new frames. If you are looking for an optometrist in Mildura, Victoria, Oscar Wylee is available to provide all your eye care and eyewear needs.
### What are the Other Closest Optometrist Locations to Mildura, Victoria in Australia?
There are no other Oscar Wylee optometrist locations close to Mildura, Victoria. However, we have many stores in Melbourne and wider Victoria, as well as New South Wales, Queensland and Western Australia. If you are looking for an optometrist near you, you can find the locations of our many stores on our [full store locations page.](https://www.oscarwylee.com.au/locations.html)
### Bulk Billed Eye Tests at Mildura Central
At Oscar Wylee Mildura Central, our in-store optometrists are available to provide customers with a range of eye care processes including eye health tests. Our quick and efficient service means you can come in and have your prescription updated and shop for a new pair of eyeglasses on the same day! For some of the best optometrists in Mildura, Australia, come and visit Oscar Wylee in Mildura Central.
### Oscar Wylee Mildura Central Accepts Leading Health Funds
Oscar Wylee in Mildura Central accepts leading health funds in-store. Bring your valid health fund card to our eyeglasses shop in Mildura Centra and our Oscar Wylee team can help process your claim and answers any questions about your eligibility.
### Fashion-Forward Glasses at Oscar Wylee Mildura Central
Oscar Wylee Mildura Central offers a range of prescription glasses, non-prescription glasses and prescription sunglasses in a variety of shapes, sizes and styles. Whether you want out-there glasses like an electric blue oversized frame or something more subtle like dainty black frames, there’s something to suit everyone’s taste at Oscar Wylee Mildura Central.
Book Appointment
[Call us: (03) 5008 4249](tel:(03) 5008 4249)
[Leave a Review!](https://g.page/r/CU53cGL4gh9GEBM/review)
[](tel:0350084249)