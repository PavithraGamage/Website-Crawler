# Source: https://www.oscarwylee.com.au/locations/optometrist-robina.html

# Optometrist Robina
Ground Floor, East Mall, Shop 4053Robina Town Centre DrRobina QLD 4230
* Opposite Boost Juice
Opening hours
Monday9:00am - 5:30pm
Tuesday9:00am - 5:30pm
Wednesday9:00am - 5:30pm
Thursday9:00am - 9:00pm
Friday9:00am - 5:30pm
Saturday9:00am - 5:30pm
Sunday10:00am - 4:00pm
*Store hours reflect local standard trading hours and exclude public holidays
[Visit our Robina Town Centre Google Business page for directions, reviews, and updates.](https://g.page/r/CYguZT-sIg0CEBM)
Book Appointment
[Call us: (07) 3519 6124](tel:(07) 3519 6124)
[Leave a Review!](https://g.page/r/CYguZT-sIg0CEBM/review)
Our Reviews
Zo Zo
6 days ago
Really good communication from staff. Polite and positive. Eye test went smoothly and the tech expla...ined everything clearly.
See more
Gina Gospel
1 week ago
Easy and methodical. Attention to detail.  Happy with process.
Pam Gallagher
1 week ago
Fast and efficient recommend OW. Also more affordable than previous provider I have used. Big differ...ence. Recommend comparing you won’t regret it.
See more
Cath Bellchambers
2 weeks ago
Fantastic Service and such beautiful frames to chose from .. Oscar Wylee has been my favourite glass... provider now for over 6 years and I adore their products and services
See more
susan watt
3 weeks ago
I have always found the staff at Robina extremely friendly and helpful. It is always a pleasure to c...ome into your store.
See more
Brodie kelly
4 weeks ago
I had such a great experience at Oscar Wylee Robina. The lovely lady optometrist who performed my ey...e test made me feel so comfortable, even though I usually don’t enjoy having my eyes checked.
The young lady at the front desk was also incredibly kind and welcoming, and both of them took the time to help me choose my new glasses.
The Robina team provided exceptional customer service from start to finish. I couldn’t recommend them more highly!
See more
Kaye Lam
1 month ago
Such a great environment. Everyone was happy and smiling. The testing was extremely efficient. Huge ...range to choose from. Would not hesitate to recommend to anyone
See more
Michael Espitia Martínez
1 month ago
Excellent attention and customer service from all staff.
Merrilyn Brunton-Wild
1 month ago
Friendly,efficient, professional
Nikki Morris
1 month ago
The Oscar Wylee staff were very warm and welcoming they are very helpful in finding the right pair o...f glasses for you.
See more
Siarne Howell-Forsyth
2 months ago
I had an amazing experience, the two ladies working (I didn’t catch their names)  working on Monday ...were so kind, helpful and friendly. They really seemed to care about me and didn’t just see me as a sale. Thank you ladies, sorry I didn’t grab your name.
See more
Chantelle Lloyd
2 months ago
Great experience ,optometrist and sales staff are lovely to deal with
Benji
2 months ago
Very friendly and professional team!
I went in to get my eyes tested for the first time since I was ...a kid, so I was a little unsure of what to do or expect. The team at Robina were awesome, the optometrist was great at explaining each step of testing, and was very patient with me. The team were lovely and helped pick out glasses that suit my face structure and tailored them to my style, placing the order for the correct ones all in one appointment. Overall lovely experience, the optometrist I had was amazing and the ladies behind the desk are very sweet.
See more
Amanda Mccallum
2 months ago
Wendy was amazing have already recommended her to my family ! The $100 for coating on glasses was ve...ry expensive as a business owner I know it’s the upsell so have no problem them asking but cost as much as a pair of glasses ! Service was great
See more
Jennifer Grech
2 months ago
Teresa Lakey
2 months ago
Great service, efficient friendly honest and reasonable prices
Alan Roughead
2 months ago
⭐⭐⭐⭐⭐
I had a fantastic experience at Oscar Wylee. The staff were friendly, welcoming, and very kno...wledgeable from the moment I walked in. The optometrist was thorough, explained everything clearly, and made me feel comfortable throughout the eye test.
There was a great range of frames to choose from, and the team took the time to help me find a pair that suited me perfectly. The whole process was easy, efficient, and stress-free.
I highly recommend Oscar Wylee to anyone looking for excellent customer service, professional eye care, and stylish, affordable glasses. Thank you to the team for such a positive experience!
See more
Katie Porter
2 months ago
Ting Li
2 months ago
So good, very detailed check
T S
2 months ago
I felt really comfortable having my eye test, the staff were extremely friendly and professional. Th...ere was a new girl on her second or third day and she was just wonderful as well. I chose a couple of really lovely pairs of glasses at a very affordable price, couldn’t be happy with the Service which made me feel extremely comfortable.
See more
Jason Littlewood
2 months ago
Very Professional…  service was very good!
Sandra Sarah Rachel
3 months ago
Katrina Owens
3 months ago
I have had very sore and itchy eyes for over a week. I made an apt and saw Yashee the optometrist at... the Robina store. She examined my eyes and fully explained the reason for the problem and discussed eye drops I was already using. She suggested changing one of the drops and advised it could take some time to heal. The other staff members Mai and Em assisted in making my apt and altered it when I called and left a message asking for an earlier apt. The testing prior to my apt was also dealt with such care. I was very impressed by all 3 staff members and received expectational service. Kat
See more
Tracy Ricketts
3 months ago
I was extremely happy with the lovely optometrist and the gorgeous girl who served me at the counter....  Both made me feel very welcome and were very friendly ????????
See more
Anne Brecht
3 months ago
Very friendly and professional service
Tracy Laverack
3 months ago
Test was great .. lady who did test was great she was very friendly and efficient
Deborah Amsler
3 months ago
Love going here - so thorough and helpful and excellent advice always
Julia Weyler
4 months ago
Wendy, optometrist was informative through professional  and helpful during my eye examination.
Than...k you ????
See more
Louise Ninnes
4 months ago
The team a OW Robina were incredible. I came in with an eye injury and they did their best to accomm...odate me with their already busy appointment list. I am incredibly grateful for the care and compassion provided by the staff at OW Robina. Highly recommend!
See more
Velvet
4 months ago
Had a wonderful experience with my optometrist. She was gentle and put me at my ease, feel as though... she has a super power in that the test where the puff of air into the eye, she got it first time!
See more
Donatella Zatta
4 months ago
Great experience - both front staff and optometrist have knowledge and experience. Highly recommende...d!
See more
Ginger Jiang
4 months ago
The Optometrist Wendy is the best I ever met,she explained clearly ,made me feel comfortable.Highly ...recommend.
See more
Shannon Jackson
4 months ago
Optometrist was extremely knowledgeable and helpful. Great experience!
Donna Laverick
4 months ago
I was there for a health check and they were so thorough and took their time. I love that they have ...access to the records from another store as well. I will keep going to Oscar Wylee
See more
Jenni Kerr
4 months ago
CLAUDE Phillips
5 months ago
The optometric was very informative,  gentle  and  thorough
Thanks
Laura Mackay
5 months ago
I like that the staff just leave you to try on your glasses and not pester you or pressure you.
Danielle Audrey
5 months ago
Amazing customer service, Vickie was super helpful and lovely whilst assisting me. Best GC store!
Rachelle Dean
5 months ago
Excellent!
Highly professional, great service.
Laura Spender
5 months ago
The team at Oscar Wylee Robina are incredible. Always seamless and the best optometrist’s who give h...onest advice and don’t push you into purchasing. 100% trust for my children and I
See more
Margaret Hunt
5 months ago
Another eye test this week, the staff, as ever, were delightful, helpful and very efficient. Yet to
...Pick up my new glasses but they have a great range of frames that fit my needs.
See more
star wars is good
5 months ago
Took my young son here for an eye test yesterday. The team were so warm and friendly.
We went straig...ht in, no long waiting times. The optometrist was so patient and thorough. She took her time to make sure each test was done just right. There was no upselling of unnecessary products (unlike another well known eyewear company). Just a lovely honest report of great eye health at the end. This will be our family optometrist from now on. Thanks ????????
See more
Amanda Patullo
5 months ago
What fantastic customer service at this store, Julia who works here was absolutely fantastic she was... such a delightful and happy person to deal with, the moment i walked in she greated me and my daughter straight away, I instantly felt comfortable and she has such a great vibe about her which made me instantly want to get glasses from this place, I ended up going back to this store to purchase glasses, Julia and Em who was also very helpful, both helped me in choosing glasses, I couldn't be happier with there customer service, good job girls!
See more
L
5 months ago
Optometrist was really lovely, very thorough and explained everything I needed to know. Looking forw...ard to getting my new glasses.Thanks kindly AAA+
See more
Riya
5 months ago
I have wonderful experience with the doctor and the staff. They have been great help with my eye che...ck-up and glasses. Thank you so much.
See more
kylee henseleit
5 months ago
S P
6 months ago
I’d like to give a big shout out to Yashi, optometrist and Em, optical dispenser for their friendly ...professionalism. Yashi took the time to clearly explain my eye care needs in a way that was easy to understand, which I really appreciated. Em was incredibly helpful and patient in helping me choose a snazzy new pair of frames. Thank you both for such a positive and enjoyable experience. Highly recommend.
See more
jaimi h
6 months ago
Tallulah Draper
6 months ago
The team was so lovely &amp; professional ❤️
Kshish Rana
6 months ago
I broke my glasses this morning and came in urgently needing a replacement. Vicki was fantastic—I to...ld her I would not be able to see without my glasses and asked if my order could be expedited. Instead, she provided me with a temporary pair to use free of charge while my new glasses are being made. I really appreciate her going above and beyond to help me out. Thank you, Vicki—you’re exceptional at your role.
See more
## Find an Optometrist in Robina With Oscar Wylee
Revolutionise your eyesight at Oscar Wylee Robina located in Robina Town Centre, close to Varsity Lakes and Mudgeeraba and a pleasant 15-minute walk from Robina Train Station. At Oscar Wylee Robina, we offer prescription glasses and prescription sunglasses, inspired by modern and vintage styles, as well as Medicare, bulk billed comprehensive eye tests in-store, so you can update and shop your prescription on the same day! 
Located just off the M1, the Robina Town Centre is the ultimate shopping, entertainment and dining destination on the Gold Coast. After your Oscar Wylee appointment, you can browse over 400 specialty and fashion stores. Only 10 minutes from Bond University and a 5-minute walk from the train station, you can go to the cinemas and go bowling, all located in the centre. For those who live in the area, Oscar Wylee optometrists nearest to you include Oscar Wylee Pacific Fair. Visit Oscar Wylee today and experience some of the best optometrist services in Robina, Australia.        
Meet Our Team
* Store Manager
* Optometrist
B.Optom
TPA Endorsed
Our Services
* Bulk Billed Eye Examinations
* Professional Frame Styling
* Frame Adjustments and Repairs
* Visual Fields Testing
* Digital Retinal Scanning
Show All
## Find an Optometrist in Robina, Gold Coast for an Eye Health Test
If you live in Robina, Gold Coast and are in need of an eye test, visit Oscar Wylee Robina for excellent eye care services. The Oscar Wylee Robina store, located in the Robina Town Centre, offers bulk billed eye tests for eligible Medicare cardholders. With an optometrist and optical dispenser in-store there is no need for an eye doctor if you need an eye health test in Robina.
At the Oscar Wylee Robina glasses store, you can browse a great range of stylish frames available in optical glasses, prescription sunglasses and non-prescription glasses. The average price range for an optometrist in Robina, Gold Coast can vary depending on factors such as the patient’s overall health and visual needs. For vision assessment and eye disease detection, visit Oscar Wylee Robina for an eye test.
## How to Find an Optometrist in Robina, Gold Coast?
To find an optometrist in Robina, you can take certain steps that can help make it easier for you such as searching online, assessing the store’s opening hours and finding the directions to your chosen location. The steps on how to find an optometrist in Robina are listed below.
1. Search online using the phrase, Robina optometrist near me. This can also be done here on the website via our locations page.
2. Click on the Oscar Wylee link, which will take you directly to our Robina optometrist store page.
3. See the store’s opening hours and where the store is located specifically.
4. Use the Robina Google Business page link located under store hours to see the directions on how to get to the store.
You can also find an optometrist in Robina, Gold Coast by searching the keywords optometrist near me. If you have locations enabled on your smartphone and you’re in the Robina area, our Oscar Wylee Robina store page should appear easily for you to click on.
### Is it Hard to Get an Eye Appointment in Robina, Gold Coast?
No, it is not hard to get an eye appointment in Robina. You can easily book an appointment to see an Oscar Wylee optometrist in Robina right here on this page. At Oscar Wylee we have highly qualified optometrists available for bulk billed eye appointments, which can be booked online, over the phone, or in-store.
#### How to Compare Optometrists in Robina to Each Other?
To compare optometrists in Robina, you can use factors such as eye tests offered, health fund coverage, lens types and add-ons and eyewear offered. To take care of your vision and eye health, it is important to receive an eye test at least once every two years. There are different types of tests that can be performed in an eye test and not all optometrists may offer the same tests. Health funds can be used to help cover some of the cost of your frames and lenses. To find out if your health fund is accepted at a Robina optometrist in the Gold Coast, visit their website. In the case of Oscar Wylee, we accept all major health funds and provide on-the-spot claims in-store. There are many different lens options available for prescription glasses such as single vision, multifocal and high index lenses. Most optometrists in Robina will offer these lenses although it is good to make sure. There are also lens add-ons available to enhance your glasses such as anti-reflective and blue light filters. Finally, if you are looking to purchase a pair of glasses after your eye test, you can compare the different styles and colours you are interested in from the optometrists in Robina, Gold Coast. Oscar Wylee offers a wide range of frames with vintage and modern inspirations in bold colours and subtle designs.
#### How to Find an Eyeglasses Shop in Robina, Gold Coast?
To find a glasses store in Robina, you can try to follow these simple steps including searching online, selecting a convenient location and looking at their health insurance policies. The steps on how to find a glasses store in Robina, Gold Coast are listed below.
1. Search online using the phrase, glasses store in Robina. This will provide you with various options for glasses stores in the whole Robina, Gold Coast area.
2. Select a glasses store that is most convenient for you to travel to.
3. Click the link to find out more information such as opening hours, exact location and directions to the glasses store in Robina.
4. Read their health insurance policies to ensure you know what health benefits you can access.
Our Oscar Wylee glasses store in Robina, Gold Coast offers primary eye care services such as comprehensive eye tests as well as other services performed by an optometrist and offers prescription and non-prescription eyewear.
##### Is it Possible to Purchase Prescribed Sunglasses in Robina, Gold Coast Without Seeing an Optometrist?
Yes and no, it is possible to [purchase prescribed sunglasses](https://www.oscarwylee.com.au/sunglasses.html) in Robina, Gold Coast without seeing an optometrist if you already have a prescription that has not expired. If your prescription is expired, you can book an eye test to receive an updated or new prescription which will require you to see an optometrist. This will ensure your prescription sunglasses are appropriate for your visual needs.
## Where is the Oscar Wylee Robina Optometrist Located in Gold Coast?
The Oscar Wylee Robina optometrist is located in Robina Town Centre opposite Boost Juice. The suburb of Robina is in the Gold Coast, Queensland, close to Mudgeeraba and Varsity Lakes. Visit an Oscar Wylee Robina optometrist for an eye health test.
### What is the Phone Number of Oscar Wylee Robina Optometrist Store?
The Oscar Wylee Robina optometrist store phone number is [(07) 3519 6124](tel:(07) 3519 6124). You can contact the Oscar Wylee Robina store between the hours of 9 am and 5:30 pm from Monday to Wednesday, 9 am and 9 pm on Thursdays, 9 am and 5:30 pm on Fridays and Saturdays and 10 am and 4 pm on Sundays.
### What are the Reviews for Oscar Wylee Robina Optometrist in Gold Coast?
The many reviews for Oscar Wylee Robina optometrist in Gold Coast, left by our various customers can be found here on the website as well as online when you search for Oscar Wylee Robina optometrist. The reviews for Oscar Wylee Robina optometrist are listed below.
* Lee Pollack:  The staff were friendly and helpful. My eye test was done by Wendy and the whole experience was comfortable and I was well informed during the process. I will certainly be returning with the great service they provide.
* Sagie 180:  The team were very professional, thorough and patient while waiting for me to pick my glasses. Wide range of products. Thanks team Robina.
* Kim Reily:  My experience with the guys at Robina was fantastic. Knowledgeable, courteous &amp; very helpful. Thank you.
* Imogene M:  Had a great experience, optometrist was lovely and patient, and very thorough. Would recommend!
#### What Treatments or Eye Care Processes are Done in the Oscar Wylee Robina Optometrist Location?
The treatments or eye care processes done in the Oscar Wylee Robina optometrist Gold Coast location include a tonometry test, a digital photograph, a slit lamp exam and a refraction test. Additional tests that may also be performed can include a visual field test and a dilated fundus exam. The treatments or eye-care processes that are done in the Oscar Wylee Robina optometrist Gold Coast location are listed below.
* A Tonometry Test: An optometrist or optical dispenser will conduct a tonometry test which involves the use of a machine that will release small puffs of air into your eyes. This will assist with measuring pressure in the eye.
* A Digital Photograph: An optometrist or optical dispenser may take a digital photograph of your eye which can be kept on record to use in future appointments to evaluate any changes to your eye.
* Slit Lamp Test: A slit lamp test can be used to evaluate your eye health, by examining your cornea and iris which are the anterior and posterior of the eye.
* Refraction Test: During a refraction test, an optometrist will have you view an image through different lenses and ask you to confirm which helps you see the image clearer.
* Visual Field Test: A visual field test can assist with assessing your peripheral vision, which may be beneficial for identifying any signs of glaucoma.
* Dilated Fundus Exam: A dilated fundus exam can help an optometrist assess your health in more detail by getting a clear view of the retina. This test is typically carried out for patients with diabetes and those who may be at risk of developing retinal damage.
## How Many Optometrists Exist in Robina, Gold Coast?
There are many optometrists that exist in Robina, Gold Coast to provide eye tests and glasses, including Oscar Wylee. The amount of optometrists available in an area will typically depend on the population. At Oscar Wylee Robina, we offer excellent optometry services including eye tests performed by skilled optometrists using high-quality equipment. We also have a wide range of fashion-forward frames that customers can browse in a large selection of sizes and colours. If you’re looking for an optometrist in Robina, choose Oscar Wylee and we will take care of your optometry and eyewear needs.
### What are the Other Closest Optometrist Locations to Robina, Gold Coast in Australia?
The other closest Oscar Wylee optometrist locations to Robina in Australia are Pacific Fair, Southport - Australia Fair and Tweed City. The locations and their distance from Robina are listed below.
* Pacific Fair:  Pacific Fair is close to Robina, around 8-9 km. The [Oscar Wylee Pacific Fair](https://www.oscarwylee.com.au/locations/optometrist-pacific-fair.html) store is located in the Pacific Fair Shopping Centre, opposite OPSM in Broadbeach, Queensland. Oscar Wylee Pacific Fair is dedicated to providing excellent optometry services.
* Southport - Australia Fair:  Southport - Australia Fair is close to Robina, around 14-15 km. The [Oscar Wylee Southport - Australia Fair](https://www.oscarwylee.com.au/locations/optometrist-southport.html) store is located in the Australia Fair Shopping Centre across from Goldmark. Visit Southport Oscar Wylee for all your eye care and eyewear needs.
* Tweed City:  Tweed City is close to Robina, around 27-29 km. The [Oscar Wylee Tweed City](https://www.oscarwylee.com.au/locations/optometrist-tweed-city.html) store is located in the Tweed City Shopping Centre in Tweed Heads, near Kmart. Our Tweed City store offers excellent optometry and eyewear services to satisfy all your eye care needs.
### Optometrist-Led Eye Tests at Oscar Wylee Robina
At Robina Oscar Wylee, you can expect bulk billed eye health tests for eligible Medicare cardholders, performed by skilled optometrists. Have your regular eye health check-up and shop for your new prescription at Oscar Wylee Robina. We take care of your eyesight and treat and examine eye diseases, both with regular eye tests and with affordable frames. Plan a trip today to visit our trusted Oscar Wylee optometrists in Robina Town Centre.
### Claim at Oscar Wylee With Your Health Fund
Our in-store experts at Oscar Wylee Robina will help you navigate the ins and outs of your health fund. We can process your health fund claim in-store with a valid health fund card, so remember to have yours handy at your next appointment. Here at Oscar Wylee, we want to make sure you get the best prescription glasses and sunglasses you need at affordable, competitive prices.
### Stylish Frames at Oscar Wylee Robina
Choose Oscar Wylee Robina for prescription glasses and prescription sunglasses that are both affordable and stylish. Visit our Oscar Wylee Robina eyeglasses shop today and chat with any one of our experts to find the perfect frames for your face shape and prescription requirements. Be styled for less with our prescription glasses frames at 2 pairs from $199 and 3 pairs from $249. At Oscar Wylee, you’ll find styles for every mood and every occasion.
Book Appointment
[Call us: (07) 3519 6124](tel:(07) 3519 6124)
[Leave a Review!](https://g.page/r/CYguZT-sIg0CEBM/review)