# Source: https://www.oscarwylee.com.au/glasses/eye/warning-signs-symptoms-eye-problems

# 21 Warning Signs and Symptoms of Eye Problems
Published on November 17th, 2023
Updated on Month Date, 2025 
Australia
[Australia](https://www.oscarwylee.com.au/glasses/eye/warning-signs-symptoms-eye-problems)
New Zealand

[Canada](https://oscarwylee.ca/glasses/eye/warning-signs-symptoms-eye-problems)
Canadian French

There are many warning signs and symptoms of eye problems that may include red eyes, crossed eyes, trouble focusing on close or distant
objects, cloudy vision,&nbsp; difficulty adjusting to darkness and more. Warning signs and symptoms of eye diseases and vision problems may
present different symptoms ranging from mild to severe,&nbsp; which are
often similar across different eye conditions. Therefore it is important
to not only have your eyes regularly tested but to also see an optometrist
right away when you notice changes to your vision. Early detection can
help the optometrist determine the most suitable treatment in a timely
manner. Continue reading to learn more about the warning signs of
unhealthy eyes and potential eye conditions.
Prioritise Your Eye Health at Oscar Wylee
If you have been noticing changes to your vision, make an appointment with
us today for a full eye examination.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[21 Warning Signs](#signs)
[Most Common Eye Probems](#eyeproblems)
[Prevention](#preventions)
The 21 warning signs and symptoms of eye problems are all common across
many different eye conditions and eye diseases. It is important to note
that these many signs and symptoms can differ between individuals with
some occurring and others not developing at all. The 21 signs and symptoms
of eye problems are listed below.
* Red Eyes: Red eyes are a common sign or
symptom of eye problems and normally occur when the eyes are either
infected, inflamed, irritated or injured.
* Crossed Eyes: Crossed eyes in babies may be a sign of strabismus and depending on the
direction the eyes are turned can determine which form of
strabismus.
* Trouble Focusing on Close or Distant Objects: Trouble focusing
on close or distant objects may be a sign of refractive errors such as
near-sightedness and far-sightedness.
* Cloudy Vision: Cloudy vision may be a sign or symptom of serious
eye conditions such as cataracts, age-related macular degeneration,
Fuchs dystrophy, diabetic retinopathy and floaters.
* Difficulty Adjusting to Darkness: Difficulty adjusting to
darkness may be a sign or symptom of myopia, glaucoma, cataracts,
vitamin A deficiency and retinitis pigmentosa.
* Double Vision: Double vision may be a sign of cataracts,
astigmatism, incorrect fitting glasses, misaligned eyes, cranial nerve
issues, strokes and brain aneurysms.
* Central Dark Spot in Eyesight: A central dark spot in eyesight
may be referred to as a scotoma which can be associated with serious eye
conditions such as glaucoma and cataracts or can be a sign of retinal
tear or detachment.
* Loss of Peripheral Vision: Loss of peripheral vision may be an
indication of eye conditions such as detached retina, glaucoma or
cataracts.
* Glare or Halos (Coloured Circles Around Lights): Glare or halos
(coloured circles around lights) may occur as a sign of an abnormally
shaped cornea, cloudy lens or corneal thinning or swelling.
* Excessive Tearing: Excessive tearing may be a sign of common eye
conditions such as an injury, infection or irritants.
* Swelling: Swelling may arise due to inflammation from
infections, injuries or fluid retention.
* Straight Lines Appear Wavy: Straight lines appearing wavy also
known as metamorphopsia may be a symptom of many macular diseases and
other conditions.
* Itching, Stinging, Dry Eyes: Itching, stinging and dry eyes can
be an indication of an allergy or issue with tear production.
* Headache: A headache can be associated with many different eye
problems such as eye strain and uncorrected nearsightedness and
farsightedness.
* Change in Iris Color: A change in iris colour may be caused by
different conditions such as iris nevi, iris freckles, lisch nodules and
fuchs heterochromic iridocyclitis.
* Veil Obstructing Vision: A veil obstructing vision can be
described as seeing a curtain-like image over your vision.
* Flashes or Floaters: Flashes or floaters may appear due to
possible issues with the vitreous gel of the eye.
* Sudden Loss of Vision: Sudden loss of vision can occur as a
result of serious eye conditions that cause clouding of the eye, and
retinal and nerve abnormalities.
* Inability to Close an Eyelid: The inability to close an eyelid
may be a sign of a condition referred to as lagophthalmos and can stem
from eyelid and nerve damage.
* Light Sensitivity: Light sensitivity is a common symptom of many
different eye problems that can impair the eye’s ability to process
light.
* Hazy or Blurred Vision: Hazy or blurred vision can commonly
occur as a result of varying eye problems with refractive errors being
one of the most common causes.
## 1. Red Eyes
Red eyes are a common symptom that can occur when experiencing many
different eye conditions.
Red eyes can likely develop as a sign of irritation, inflammation or
injury due to the small blood vessels that increase in size, causing them to appear red on the surface of the eye. Redness is
considered a typical response to allergens, dirt or debris entering the
eye and may be alleviated through the use of eye drops that specifically
target the cause, such as antihistamines for allergies. However, it is
important that you seek medical attention as your first option before
starting any treatments. Red eyes may likely last until the underlying
condition is addressed and is considered a very common sign of mild to
severe eye conditions.
## 2. Crossed Eyes
Crossed eyes can be a sign of an eye problem known as strabismus and depending on the direction the eyes
are turned can indicate which form of strabismus. Crossed eyes in babies can be a common sign of misaligned eyes which
have four different types including esotropia, exotropia, hypertropia and
hypotropia. However, this can go away as they turn 4-6 months, if it
persists past 4-6 months old, it could be a case of crossed eyes. Crossed
eyes may last from birth to around 4 months which may resolve, however, it
is possible for crossed eyes to remain past this age. In this case,
further examination by an eye care professional should be sought.
## 3. Trouble Focusing on Close or Distant Objects
Trouble focusing on close or distant objects can be a sign of refractive errors such as short-sightedness (myopia),
far-sightedness (hyperopia) or astigmatism.
Trouble focusing on objects in the distance may indicate there is an issue
with how your eye focuses light onto the retina and instead, light is
focused in front of the retina causing objects in the distance to appear
blurry. As a result, you may only have clear vision when looking at
objects up close. Experiencing trouble with focusing on objects up close
may be an issue of far-sightedness (hyperopia). This and astigmatism may
occur due to the abnormal length of the eye from the front to the back or
the unusual curvature of the cornea according to the National Eye
Institute.
## 4. Cloudy Vision
Cloudy vision can be a potential symptom of serious eye conditions such as cataracts,
age-related macular degeneration, Fuchs dystrophy, floaters and diabetic
retinopathy.
Cloudy vision may be a result of the protein in the lens of the eye
deteriorating and clumping together due to cataracts. Cloudy vision can
also develop as a symptom of Fuchs dystrophy as a result of corneal
swelling caused by the loss of endothelial cells. The endothelial cells
are responsible for maintaining a healthy amount of fluid in the cornea.
Floaters may also lead to cloudy vision due to the larger-sized floaters
moving across the eye. Diabetic retinopathy may be associated with cloudy
vision as a consequence of swollen retina tissue. This can occur when
diabetes is not treated or managed. It is important to see an optometrist
promptly if you have cloudy vision as this can be a sign of a more serious
condition.
## 5. Difficulty Adjusting to Darkness
Difficulty adjusting to darkness also known as night blindness may be a symptom of eye conditions such as cataracts, myopia, glaucoma
and vitamin A deficiency. Experiencing difficulty adjusting to darkness can develop due to
factors such as changes to how the eyes process light, which can be a
consequence of cataracts. [Night blindness](https://www.oscarwylee.com.au/glasses/eye/night-blindness)
may also stem from a build-up of pressure in the eye, which is what can
lead to glaucoma. Experiencing difficulty seeing in the dark could also
indicate a vitamin A deficiency as this vitamin assists with producing
certain pigments for a full functioning retina. Difficulty adjusting to
darkness may be corrected with prescription glasses or an updated
prescription or surgery if the condition does not improve with
glasses.
## 6. Double Vision
Double vision also known as diplopia may be a symptom of eye conditions such as cataracts, astigmatism,
incorrect-fitting glasses, misaligned eyes, cranial nerve issues, strokes
and brain aneurysms.
Double vision can indicate issues and diseases in the eyes as well as the
body and is defined as seeing two of the same image. The different types
of double vision are monocular and binocular, horizontal and vertical.
Monocular diplopia develops when double vision occurs in just one eye with
the second image appearing as a shadow. Binocular diplopia refers to when
double vision affects both eyes and may alleviate when one eye is covered.
When binocular diplopia occurs, double vision may appear horizontally or
vertically, however, these forms may arise depending on the cause of
double vision. Treatment or management of double vision will depend on how
severe the condition is but could involve hindering vision in one to
mitigate symptoms or using an eye patch. If you experience any sudden
double vision, it is recommended you seek urgent medical attention.
## 7. Central Dark Spot in Eyesight
A central dark spot in eyesight may be a sign or symptom of serious eye conditions such as retinal tear or
detachment or scotoma and other conditions. Seeing a central dark spot as a result of retinal tear may be
associated with age-related ocular problems, eye injuries, nearsightedness
and eye surgery. It is important to note that a retinal tear or detachment
is an eye emergency, therefore, urgent medical attention should be sought
right away. The development of a dark spot in your central vision may be
the visual field abnormality called scotoma according to the Cleveland
Clinic. A scotoma can be characterised as a blind spot and usually occurs
in one eye but can also occur in both eyes. According to the Cleveland
Clinic, these dark spots can develop in an area of the retina where the
nerves are not functioning and fail to transmit signals to the brain. The
types of scotomas differ according to where the blind spot occurs and can
stem from issues in the eye such as glaucoma and age-related macular
degeneration.
## 8. Loss of Peripheral Vision
Loss of peripheral vision may occur as a consequence of different ocular diseases such as a
detached retina, glaucoma, cataracts and retinitis pigmentosa.
Peripheral vision refers to your side vision or vision that is out of your
direct line of eyesight and allows you to see all around you without the
need to turn your head. Losing peripheral vision should be addressed with
a medical professional as soon as possible as it may likely be an
indication of a serious eye condition. Impaired peripheral vision can
occur as a consequence of different conditions which may include when
cataracts develop, when too much ocular pressure builds up or due to
retinal damage. The duration of this symptom may depend on which condition
is causing loss of peripheral vision and the breadth of damage
caused.
## 9. Glare or Halos (Coloured Circles Around Lights)
Glare or halos (coloured circles around lights) may indicate an issue with certain regions of the eye. Glare or halos may
signify different eye problems such as an abnormally shaped cornea,
cataracts, keratoconus, Fuchs Dystrophy, closed-angle glaucoma,
photokeratitis and other conditions.
The appearance of glare or halos may be noticeable during the night around
headlights and streetlights and can be accompanied by other symptoms. Some
possible occurrences that may lead to the development of glare or halos
may include a cloudy lens or abnormally shaped cornea bending light in an
unusual way. Other reasons may include corneal thinning or swelling and
refractive errors. Many of these circumstances may stem from eye
conditions that will require prompt medical attention. Therefore, it is
important to see an optometrist or your local doctor when experiencing the
symptoms of glare or halos. Managing glare or halos will depend on the
underlying condition which may be determined based on additional symptoms
that occur.
## 10. Excessive Tearing
Excessive tearing may develop when the eyes are irritated, infected or injured. Excessive tearing
typically occurs in order to eliminate what may be causing the irritation,
infection or injury.
The most common eye problems associated with excessive tearing include
conjunctivitis, blepharitis, dry eye, irritant exposure and corneal
damage. Increased tear production can typically take a few days to
alleviate depending on the condition and may likely occur along with other
symptoms.
## 11. Swelling
Swelling may be a common
sign or symptom of eye problems such as an injury, allergies or fluid
retention. Swelling can occur in and around the eye and is part of the
body’s natural response to allergens, infections and trauma to the eye.
In serious cases, damage to blood vessels and blockage in the eye’s
internal drainage system may also lead to swelling in the eye. Swelling
can induce discomfort, pain, the sensation of something in the eye,
itching and irritation according to UCLA Health. Eye swelling can take
between 24-48 hours to go down and will require prescribed medication
according to the underlying condition.
## 12. Straight Lines Appear Wavy
Straight lines appearing wavy may be a possible symptom known as metamorphopsia which is a vision
dysfunction often associated with age-related macular degeneration (AMD),
retinal haemorrhage, and other conditions.
Straight lines appearing wavy can ensue due to issues in the macula or the
brain according to All About Vision. The macula controls our central
vision and is located in the back region of the retina. This symptom may
be noticed by patients when looking at objects such as buildings or doors
and will likely require complex treatment from an ophthalmologist
depending on the type of condition. According to the National Library of
Medicine, metamorphopsia is a common symptom that can occur from different
macular diseases. For patients with age-related macular degeneration, the
most common occurrence was found to be a distortion of words on computer
displays, newspapers and books according to Xu K, Gupta V, Bae S et al.
(2018). Additionally, patients with wet AMD reported higher rates of
metamorphopsia than those with dry AMD.
## 13. Itching, Stinging, Dry Eyes
Itching, stinging and dry eyes may be
common signs and symptoms of eye problems such as allergies or an issue
with tear production. Itching, stinging and dry eyes can typically occur when allergens or
irritants get in the eye or from decreased tear production. These symptoms
may be alleviated from antihistamine eye drops or artificial tear eye
drops prescribed by an optometrist. It also may be helpful to see an
optometrist to ensure there are no underlying conditions. The duration of
these symptoms can vary between individuals and can depend on which
condition you have.
## 14. Headache
A headache may be a sign of eyestrain, eye injuries, dry eye, uncorrected
farsightedness nearsightedness and infections
according to NVision Centres. The different types of headaches can include
tension headaches, cluster headaches and migraines. Eye Strain may be the
most common cause of headaches due to overexertion of your eye muscles
when focusing on certain tasks that involve computers, reading, dim-light
conditions and bright-light conditions. Treatment may depend on the
factors causing the headache. It may be helpful to take regular breaks
during tasks to rest your eyes and prevent the chance of developing
eyestrain and headaches. It is also recommended to see your optometrist
for assistance with headaches associated with vision as they can check
whether your prescription may need updating or if you require prescription
glasses.
## 15. Change in Iris Colour
A change in iris colour may be associated with complex eye diseases, due to genetics and certain
medications. Changes to your iris colour can either be harmless or require treatment
and can include many causes such as iris nevi, iris freckles, Lisch
nodules and Fuchs heterochromic iridocyclitis. The causes that can lead to
a change in your iris colour can differ according to which eye condition
you have and may likely experience other symptoms as well. It is best to
see your optometrist who can then refer you to an ophthalmologist for
further examination and suitable treatment.
## 16. Veil Obstructing Vision
Veil obstructing vision may be an indication of serious eye conditions. Veil obstructing vision is
defined as seeing what resembles a curtain over your eyes and it requires
urgent medical attention.
Seeing a veil in your eyesight can be linked to the onset of a stroke,
retinal infection, blocked blood vessels in the eye or a detached and torn
retina. A symptom such as this will require further examination and a
professional diagnosis, therefore, it may be difficult to provide accurate
information on the duration and management. The prevalence however may be
common in patients who have pre-existing eye conditions.
## 17. Flashes or Floaters
flashes or floaters may be a
sign of changes to the vitreous gel of the eye due to age-related changes
or retinal detachment. Floaters can be described as greyish or dark squiggly lines or spots
that float across the eye and flashes are flashes of light that appear in
your vision. They can develop when segments of the vitreous gel clump
together, creating the appearance of shadows according to the National Eye
Institute. flashes or [floaters](https://www.oscarwylee.com.au/glasses/eye/floaters-definition)
may not always be a cause for concern, however, it is still advised to
have your eyes examined by an eye care professional to ensure there are no
problems with any structures of the eye. If there are no underlying
conditions found during the examination, the appearance of floaters or
flashes may gradually reduce and become less noticeable.
## 18. Sudden Loss of Vision
Sudden loss of vision can be a sign of many different eye problems with some being acute glaucoma,
trauma to the eye or retinal artery occlusion. Sudden loss of vision may occur when issues with the brain, nerves and
eyes develop and is considered an eye emergency, therefore, urgent medical
care should be sought. Loss of vision is considered sudden when it takes
place within seconds, minutes or days according to Christopher C. Muth in
his paper on Sudden Loss of Vision (2017). Diagnosing sudden loss of
vision may involve a neurological assessment and eye examination.
Treatment will depend on the cause which may involve surgery, eye drops or
medication.
## 19. Inability to Close an Eyelid
The inability to close an eyelid may be a sign of an eye condition known as lagophthalmos, which can be caused
mainly by nerve damage or eyelid damage from facial nerve paralysis,&nbsp;
eye surgery or eye trauma. The inability to close an eyelid can develop as a result of according
to the Cleveland Clinic. The different types of lagophthalmos are
nocturnal lagophthalmos, paralytic lagophthalmos and mechanical
lagophthalmos. Nocturnal lagophthalmos occurs when the eyes cannot close
when sleeping, paralytic lagophthalmos as a result of facial nerve
paralysis and mechanical lagophthalmos develops when the nerves in the
muscle do not operate correctly. Management will involve getting treatment
for the underlying cause, which could be nonsurgical methods such as eye
drops, moisturising ointment or tape to keep eyelids closed according to
the Cleveland Clinic. Surgical processes could include partially or
completely sewing the eyelid shut or implanting weights in the upper
eyelids. Other surgeries may include eyelid surgeries, lower eyelid
surgeries and facial surgeries. It may also be helpful to focus on
maintaining moisture in the eyes as the lack of blinking can leave the
eyes dry, leading to irritation and other potential complications.
## 20. Light Sensitivity
Light sensitivity can arise as a common symptom of several different eye problems that can leave the
eyes extra sensitive.
[Light sensitivity](https://www.oscarwylee.com.au/glasses/eye/sudden-light-sensitivity)
may be induced by common conditions such as corneal abrasions, dry eye,
conjunctivitis and uveitis. The eyes can develop sensitivity when certain eye conditions impair the
eye’s ability to process light. This symptom may last from weeks to months
depending on the cause and may be managed through limiting screen time,
wearing sunglasses during bright conditions and treating the underlying
condition.
## 21. Hazy or Blurred Vision
Hazy or blurred vision can develop during multiple types of eye problems such as refractive
errors. Hazy or blurred vision can be characterised as sight that is unclear,
out of focus and lacks sharpness. Blurry or hazy vision may be treated
when the underlying condition is addressed by an eye health professional.
Refractive errors such as nearsightedness and farsightedness may likely
require correction through prescription glasses. Blurry or hazy vision
from dry eyes may only require prescribed artificial tear eye drops to
restore or increase moisture. Blurry or hazy vision is a very common
symptom, however, it cannot be said how long it lasts as it depends on
which condition you have.
Are You Looking For a Local Optometrist?
We have highly qualified teams at multiple locations dedicated to
helping with your eye care needs.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
## Why is it Important to Know the Warning Signs of Eye Problems?
It is important to know the warning signs of eye problems as it can help patients know when to see an optometrist or medical
professional. It is helpful to familiarise yourself with different eye
disease symptoms to also know what to report to your optometrist
during your appointment. This can assist the optometrist in their
diagnosis of your condition. Different eye diseases often have similar
symptoms therefore, it is important to be mindful of any changes to your
eyes and vision. This will help ensure early detection of any eye problems
before further complications can develop.
### What is the Most Severe Symptom of Eye Problems?
The most severe symptoms of eye problems are sudden changes to your vision and include severe eye pain, loss of
vision in one eye and double vision.
However, many other symptoms may be considered severe when they occur in
an unexpected nature.
### What is a Less Severe Symptom of an Eye Problem?
A less severe symptom of an eye problem may be itchiness and watery eyes as it may likely be a consequence of
allergies or an eye infection. Less severe symptoms such as itchiness
and watery eyes can easily be relieved and treated
with antihistamine tablets eye drops or artificial tear eye drops.
However, it is still advisable to see an optometrist to get a
professional diagnosis of symptoms and to rule out serious eye
problems.
### What Eye Problem Signs Need Immediate Attention?
Eye problem signs that need immediate attention may be flashes of light, floaters, sudden hazy or blurred vision, eye injury
or pain and red eye.
These signs can occur unexpectedly, therefore, even if you have already
had a recent eye exam done, it is paramount that you seek assistance
from an optometrist or your local doctor.
### What is the Most Painful Eye Problem Symptom?
The most painful eye problem symptom may be severe pain in the eye caused by a foreign body scratching or
penetrating the eye. The cornea is considered to be very receptive to pain therefore, any
slight injuries in the eye can trigger significant pain to the eye. Many
other eye problems can also bring on the symptoms of pain such as
infections, glaucoma and other conditions.
## What are the Most Common Eye Problems?
The most common eye problems are refractive errors, age-related macular degeneration (AMD), diabetic
retinopathy, cataracts, glaucoma and strabismus. These eye problems can affect a range of age groups between children to
senior patients. The most [common eye problems](https://www.oscarwylee.com.au/glasses/eye/common-problems) are listed below.
* Refractive Errors: Refractive errors are a
common eye problem that affects vision and occurs when the shape of your
eyes hinders light from properly focusing light onto your retina. The
different types of refractive errors include myopia (nearsightedness),
hyperopia (farsightedness) and astigmatism. This form of eye problem can
affect patients from children to seniors.
* Age-Related Macular Degeneration: Age-related macular degeneration is characterised as disease that
occurs in the macula, affecting your central vision. The two types of
age-related macular degeneration are dry, which is the most common form
and takes place when the macula thins out as you get older. The other
type is wet (AMD),&nbsp; which develops when the macula is damaged by
abnormally grown blood vessels in the back of the eye. It is considered
less common and can lead to faster loss of vision.
* Diabetic Retinopathy: Diabetic retinopathy is an eye condition
that can result in vision loss or blindness in patients with diabetes.
Diabetes can lead to diabetic retinopathy when the blood vessels in the
retina swell up and bleed.
* Cataracts: Cataracts are when the lens of the eye becomes cloudy
as a result of proteins in the eye breaking down and sticking together,
which can hinder vision. This normally occurs in older patients as there
are natural changes to the lens of the due to increased age and exposure
to ultraviolet light.
* Glaucoma: Glaucoma is another common eye problem that can lead
to vision loss.&nbsp; Glaucoma may be caused by increased ocular
pressure, genetics, diabetes, increased age, migraines, high-blood
pressure and many other conditions. The types of glaucoma include
open-angle, and closed-angle and within these types are different forms
including primary glaucomas and secondary glaucomas. Acute angle-closure
glaucoma is a medical emergency which requires urgent medical
attention.
* Strabismus: Strabismus also known as misaligned eyes is an eye
condition where the eyes are not lined properly and cannot
simultaneously look at the same place. It normally occurs in children
but also develops in adults. The different types of strabismus are
inward (esotropia), outward (exotropia), up (hypertropia) and down
(hypotropia). It can arise as a result of problems in the eye
muscles.
### How are Eye Problem Symptoms Diagnosed?
Eye problem symptoms are diagnosed
through a comprehensive eye exam. Diagnosing eye problems usually
involve a series of different tests to assess the different regions of
the eye
and typically takes 20-30 minutes. The optometrist may ask you about
your medical history and your family’s medical history to determine if
you are at risk of certain eye conditions. Then they may proceed with
several tests to evaluate the exterior of the eye such as the cornea,
eyelids, iris and conjunctiva. They will then go on to look more closely
at the structures deeper in the eye which includes the retina, macula
and optic nerve.
#### What Eye Symptoms Indicate Blindness?
Eye symptoms that indicate blindness may be different depending on
which eye condition you have. Symptoms of blindness as a result of
cataracts, for example, may include a cloudy lens and blurry vision
according to Health Direct. If blindness is caused by diabetic
retinopathy, poor night vision, blurred or distorted vision can occur
as symptoms. However, every patient may have a different experience,
therefore, it is important to get a diagnosis from an eye care
professional.
## How to Prevent Eye Diseases?
To prevent eye diseases can involve different steps which may be able to increase eye and overall
bodily health, which may reduce the risk of developing eye diseases. It is important to have your eyes regularly checked through a
comprehensive eye exam to maintain [eye health](https://www.oscarwylee.com.au/glasses/eye/health-tips-keeping-eyesight-healthy), consuming sugary foods in moderation, and familiarising yourself with
your family’s eye health history. It may also be helpful to maintain a
healthy weight, always wear sunglasses when appropriate, quit smoking, use
protective eyewear, and rest your eyes from long periods of device use.
Finally, cleaning your hands and contact lenses correctly and eating
healthy.
## How Can Glasses Prevent Eyesight Issues?
Glasses can prevent eyesight issues such as short-sightedness, farsightedness and astigmatism. Glasses can help with clear vision by bending the light correctly onto
the retina, which is the tissue in the back region of the eye that is
light-sensitive. While glasses can correct these different errors when
wearing them, it does not alter the eyes.
Read 21 Warning Signs and Symptoms of Eye Problems in other Oscar Wylee
regions and their languages.
Australia
[Australia](https://www.oscarwylee.com.au/glasses/eye/warning-signs-symptoms-eye-problems)
New Zealand

[Canada](https://oscarwylee.ca/glasses/eye/warning-signs-symptoms-eye-problems)
Canadian French

Oscar Wylee Accepts Leading Health Funds In-store
Visit Oscar Wylee for your optometry needs, and your health fund may
help cover some of the cost. Bring a valid health fund card to your
local store for a full quote.
[Health Fund](https://www.oscarwylee.com.au/health-funds.html)
Have You Had Your Eyes Tested Recently?
Book an appointment with one of our optometrists today to stay on top of
your eye health.
[Book an eye test](https://www.oscarwylee.com.au/booking)