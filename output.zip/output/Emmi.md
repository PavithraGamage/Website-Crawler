# Source: https://www.oscarwylee.com.au/emmi-sunglasses.html

# Emmi
1
## Frame Design of Emmi Sunglasses
The frame design of Oscar Wylee’s Emmi sunglasses is characterised by their geometric shape, low nose bridge fit, and acetate frame. Emmi is a wearable unisex glasses frame that will complement any outfit or event, day to night.
$169    
In stock
Only %1 left
2 pairs from $199
Discount auto-applied at checkout
3 pairs from $249
Discount auto-applied at checkout
* 2 &amp; 3 Pair pricing applies to non-prescription sunglasses only. Prescription sunglasses incur additional charges.    
[Non-Prescription](https://www.oscarwylee.com.au/emmi-sunglasses.html#)
Qty
Prescription
Book an eye test
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
excluding prescription lenses
## About Emmi Sunglasses
A fun and quirky frame in a bold geometric shape. Show off your unique style in Emmi.
| Frame fit | Measurements |
| --- | --- |
| MEDIUM | 51 - 24 - 152 |
These measurements mean lens width, bridge, and temple length in millimetres (mm). They can be found on the inside of the temple arm. If you already have a pair that you like, you can compare it to these measurements.
### Made from Acetate
Oscar Wylee’s Emmi frame is a unisex geometric sunglasses frame that is perfect for those with round and oval face shapes. The Emmi frame is a striking and versatile frame that can be worn every day. The main specs of Oscar Wylee’s Emmi glasses frame, including dimensions, shape, materials, lenses, nose fit, and hinges are listed below.
Filter category 2 (Tobacco only) - General purpose sunglasses. Good protection against sunglare. Good UV Protection.Not suitable for driving in twilight, at night or under dull conditionsThis frame comes with polarised lenses. An additional $100 will be added to your order total for prescription orders.
| Emmi Frame Features | Emmi Frame Description | Dimensions | Shape | Materials | Lenses | Nose Fit | Hinges |
| --- | --- | --- | --- | --- | --- | --- | --- |
| The dimensions of the Emmi frame are measured in millimetres (mm) and are 51 - 24 - 152, meaning the lens width is 51 mm, the bridge is 24 mm, and the temple length is 152 mm. |
| Emmi is a geometric shape, well-suited to medium faces. |
| Emmi is made from acetate. |
| The lenses that can be used in the Emmi frame are sunglass lenses, which provide UV protection. Prescription lenses are also available to purchase for the Emmi sunglass frame, both online and in-store. |
| The nose fit for Emmi is a low nose bridge fit. |
| The hinges in Emmi are spring hinges, which are more flexible than other types of hinges and can extend past 90 degrees. |
Show All
### What Inspired the Frame Design of Oscar Wylee's Emmi Glasses?
The Oscar Wylee Emmi frame design was inspired by current fashion trends, as geometric shapes are often in fashion. A geometric glasses shape is timeless; it remains popular throughout the decades while other trends come and go.
## What to Know About Oscar Wylee's Emmi Sunglasses?
There are many aspects of the Oscar Wylee Emmi frames that customers should know to decide whether this is the right frame for them. The Emmi frame is a unisex, geometric sunglasses frame. Oscar Wylee’s Emmi frame is suitable for many face shapes, but particularly compatible with round and oval face shapes. The Emmi frame’s simple design makes them fashionable all year round. Emmi features the standard [parts of glasses](https://www.oscarwylee.com.au/glasses/eye/part-of-glasses), such as a rim, temples, lenses, spring hinges, and a low nose bridge.
### What are the Types of Temple Tips or Earpieces Included with Oscar Wylee's Emmi Glasses?
The type of temple tips or earpieces included in Oscar Wylee’s Emmi Glasses are made from acetate.
### What Type of Nose Bridge do Oscar Wylee's Emmi Glasses Have?
The type of nose bridge included in Oscar Wylee’s Emmi frame is a low nose bridge fit.
### What Type of Nose Pads are Included with Oscar Wylee's Emmi Glasses?
Oscar Wylee’s Emmi frame does not include adjustable silicone nose pads.
### What Type of Lenses do Oscar Wylee's Emmi Sunglasses Have?
The lenses that can be used in the Emmi frame are sunglass lenses, which provide UV protection. UV protection lenses block harmful ultraviolet rays, safeguarding eyes from damage. The Emmi frame comes in Filter Category 2. These are general purpose sunglasses. Good protection against sunglare. Good UV Protection. Not suitable for driving in twilight, at night or under dull conditions. Prescription lenses are also available for the Emmi frame, both online and in-store.
### What Material is Used for the Rim of Oscar Wylee's Emmi Glasses?
The material used for the rim of Oscar Wylee’s Emmi glasses frames is acetate. The rim refers to the part of a glasses frame that holds the lenses.
### What Type of Hinges are Included with Oscar Wylee's Emmi Glasses?
The type of hinges included with Oscar Wylee’s Emmi frames are spring hinges. A spring hinge in a glasses frame refers to hinges that are more flexible than normal hinges and can go slightly beyond 90 degrees. Spring hinges can provide a closer fit to the face.
## What Face Types are Most Suitable for Oscar Wylee's Emmi Glasses?
The face types most suitable for Oscar Wylee’s Emmi frame are round and oval face types. The Emmi frame is a geometric shape, meaning it complements the structure of round and oval faces particularly well. The geometric Emmi frames help balance the features of a [round face shape](https://www.oscarwylee.com.au/glasses/face-shapes/round) and [oval face shape](https://www.oscarwylee.com.au/glasses/face-shapes/oval), bringing the eyes and brows forward in a flattering way. Although there are many different [glasses for face shapes](https://www.oscarwylee.com.au/glasses/face-shapes) that may be considered more aesthetically suitable, it is important that people also choose frames that make them feel most comfortable and represent their personal style.
## What Size Options are Available for Oscar Wylee's Emmi Glasses?
The size option available for Oscar Wylee’s Emmi frame is a medium-frame fit.
## What Materials are Used to Create Oscar Wylee's Emmi Glasses?
The material used to create the Oscar Wylee Emmi frame is acetate. Acetate, also known as cellulose acetate, is a bioplastic made from cotton fibres or wood pulp. At Oscar Wylee, acetate glasses are made by adding a dye to cellulose acetate, which is rolled into a sheet. The shape of the glasses is then cut from this sheet.
## What’s Included
## What's Included
Each pair of glasses comes with a stylish frame case and lens cloth. We offer free shipping across Australia and 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects.
* Free Shipping for Australian Orders
* 1 Year Warranty on frames and lenses
* Scratch resistance lens coating on all prescriptions
* UV-proof coating on all prescriptions
* Stylish case and cloth
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
## Make and Materials
The frames then go through cleaning and strict quality control, and many pairs of crafting hands to be hand-assembled and polished. After your frames have gone through the production process, they are individually examined and&nbsp;packed before making their way to you!Also known as cellulose acetate, these frames are traditionally hand-crafted by skilled craftsmen, with each frame passing through numerous stages of production and are hand-polished to ensure a glorious lustre.
## Warranty Information
### Warranty Information
### Warranty Information
Oscar Wylee provides a 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects. We will repair or replace faulty or defective frames or lenses free of charge for warranty claims made within 1 year of the delivery. We also offer repairs or replacement for problems experienced with vision during everyday use for claims made within 30 days of delivery. If the same product has been discontinued or is no longer available, then we may offer an exchange for a similar product or a refund.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Find a Store Location](https://www.oscarwylee.com.au/locations/full-store-list.html)