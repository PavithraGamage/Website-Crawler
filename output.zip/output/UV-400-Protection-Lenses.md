# Source: https://www.oscarwylee.com.au/glasses/eye/uv-400-lenses

# UV 400 Protection Lenses
Published on August 20th, 2024
Updated on March 21st, 2024 
UV 400 on lenses effectively blocks 100% of the sun’s ultraviolet rays from
reaching the eyes, preventing long-term damage to your vision. Here at Oscar
Wylee, UV 400 protection is featured on all our lenses for both optical
glasses and sunglasses, ensuring the highest level of protection for your
eyes.
## What is UV Light?
UV consists of UVA which measures around 315-400 nanometres (nm), UVB
measures at 280-315 nm and UVC rays which are measured at 100-280 nm.
UVA rays have longer wavelengths that penetrate the deeper layer of the
skin causing wrinkles and sun spots to develop and affect all structures
of the eye. UVB rays are a medium wavelength that does not penetrate
past the superficial layers of the skin and is what contributes to
burning and delayed tanning. UVC falls in the short-wavelength range and
is the most harmful form of UV radiation, however, it does not reach the
earth’s surface as it is filtered by the atmosphere, according to the
World Health Organisation. This is why UV 400 is especially important
for effective protection during sun exposure as it ensures prevention of
up to 400 nm of UV radiation, which includes UVA and UVB rays.
Do You Have Any Eye Health Concerns?
See one of our highly skilled and knowledgeable optometrists in-store.
[Book an eye test](https://www.oscarwylee.com.au/booking)
## What is UV 400 Protection?
UV 400 protection on lenses is designed to prevent up to 400 nm of UV
light rays from penetrating your eyes by either blocking, absorbing or
reflecting the UV light. Glasses that feature UV 400 have special lenses
that are either coated with UV protection on the lens or have UV
protection built into them.
## How Does UV 400 on Lenses Work?
The UV coating on the glasses has a thin layer of chemicals that help to
either block, absorb or reflect UV radiation. The UV coating typically
involves a metal oxide, which is a key element in filtering out UV
radiation.
## Why are UV 400 Protection Glasses Important for Eye Health?
UV protection glasses are essential for eye and vision health as they
can prevent the risk of developing certain eye diseases and eye cancer.
UV 400 ensures that your eyes are protected from up to 400 nm of those
harmful light rays. The sun’s UV rays can cause damage to the surface
tissues of the eye as well as the cornea and lens, according to the
Centre for Eye Research Australia. Therefore, UV 400 protection glasses
are essential in ensuring all UV light rays are hindered from reaching
the eye, lowering the risk of accumulating damage to your eyes and the
skin around them.
### What are the Different Sunglass Categories?
The different sunglass categories include category 0, category 1,
category 2, category 3 and category 4, which refers to the level
of tint on sunglass lenses. Category 0 allows 80-100% of visible
light to pass through the lens, category 1 allows 43-80% of
visible light to pass through,&nbsp; category 2 allows 18-43% of
visible light to pass through the lens, category 3 allows 8-18% of
visible light to pass through the lens and category 4 allows 3-8%
of visible light to pass through the lens. Therefore, it is
generally recommended to opt for category 2 or 3 sunglasses when
you are out in direct sunlight. It is important to note that the
lens shade of sunglass lenses does not necessarily equate to UV
protection as darker shade lenses primarily aid with protection
from the sun’s brightness and glare. Therefore, it is important to
ensure that your sunglasses specifically state UV 400 for optimal
protection against UV light rays.
### What are the Different Types of Lenses that Provide UV 400
Protection?
Oscar Wylee offers UV 400 protection on all our lenses but also
provides a wide range of different lens types that serve both
functional purposes and UV 400 protection. For example, if you
frequently require more than one prescription, you may opt for our
multifocal lenses option, which can meet your visual needs and still
ensure 100% UV protection.
#### Choosing UV Protection Glasses
When choosing the best UV protection glasses or sunglasses, you
should consider the lenses, frames and overall purpose.
Lenses
You should ensure that the lenses feature UV 400 as many
lenses typically provide protection for only up to 300-380 nm.
It is also important to note that darker lenses do not
inherently mean they provide UV protection.
Sunglasses Frames
Frames can be chosen for many reasons based on style,
functionality and eye protection. If you require more
protection from UV light, you may want to choose wraparound
frames, which sit close to the face and shield the eyes by
blocking the sun from the sides.
Purpose
There are different types of sunglasses lenses that are
equipped with UV 400 and can serve a specific purpose for your
lifestyle or prescription needs. Photochromic lenses are a
great option for people who need vision correction as the
lenses go from clear to dark in response to sunlight. Meaning
indoors, the glasses will be clear but once you are in the sun
they will become tinted to protect the eyes from the sun and
up to 400 nm of its UV light. Polarised lenses are another
type of sunglasses that provide UV 400 protection and are
especially good for those regularly engaging in outdoor
activities, especially in circumstances that involve being out
on the water.
Book Your Next Eye Test at Oscar Wylee
Our team is highly trained and committed to providing excellent eye
care.
[Book an eye test](https://www.oscarwylee.com.au/booking)
Find an Oscar Wylee Store Near You
Our knowledgeable and friendly team can help you find a pair of
stylish and affordable frames.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)