# Source: https://www.oscarwylee.com.au/fenn-optical.html

# Fenn
1
## Frame Design of Fenn Glasses
The frame design of Oscar Wylee’s Fenn glasses is characterised by their classic shape, adjustable nose pads, and TR90 and stainless steel frame. Fenn is a charming women's glasses frame that will complement any outfit, day to night.
$169    
In stock
Only %1 left
2 pairs from $199
Discount auto-applied at checkout
3 pairs from $249
Discount auto-applied at checkout
Qty
Add to cart
Book an eye test
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
excluding prescription lenses
## About Fenn Glasses
Meet Fenn. A versatile frame that knows how to make a statement, but can just as easily fly under the radar. With flexible qualities - Fenn is easy to adjust and has ultra comfortable nose pads.
| Frame fit | Measurements |
| --- | --- |
| MEDIUM | 50 - 25 - 140 |
These measurements mean lens width, bridge, and temple length in millimetres (mm). They can be found on the inside of the temple arm. If you already have a pair that you like, you can compare it to these measurements.
### Made from TR90 and Stainless Steel
Oscar Wylee’s Fenn frame is a women's classic glasses frame that is perfect for those with square, oval, and pear face shapes. The Fenn frame is a chic, versatile frame that can be worn every day. The main specs of Oscar Wylee’s Fenn glasses frame, including dimensions, shape, materials, lenses, nose fit and hinges are listed below.
| Fenn Frame Features | Fenn Frame Description | Dimensions | Shape | Materials | Lenses | Nose Fit | Hinges |
| --- | --- | --- | --- | --- | --- | --- | --- |
| The dimensions of the Fenn frame are measured in millimetres (mm) and are 50 - 25 - 140, meaning the lens width is 50 mm, the bridge is 25 mm, and the temple length is 140 mm. |
| Fenn is a classic shape, well-suited to medium faces. |
| Fenn is made from TR90 and stainless steel, with cellulose propionate temple tips. |
| The lenses that can be used in the Fenn frame include optical lenses, such as single-vision and multifocal, and non-prescription lenses, which are plain and can have a filter, such as a blue-light filter applied. Fenn also comes as sunglasses. |
| The nose fit for Fenn is characterised by adjustable nose pads. |
| The hinges in Fenn are normal hinges, also known as standard or barrel hinges. |
Show All
### What Inspired the Frame Design of Oscar Wylee’s Fenn Glasses?
The Oscar Wylee Fenn frame design was inspired by current fashion trends, as classic shapes are often in fashion. A classic glasses shape is timeless; it remains popular throughout the decades while other trends come and go.
## What to Know About Oscar Wylee’s Fenn Glasses?
There are many aspects of the Oscar Wylee Fenn frames that customers should know about to decide whether this is the right frame for them. The Fenn frame is a women's classic-shaped frame. Oscar Wylee’s Fenn frame is suitable for many face shapes, but particularly compatible with square, oval, and pear face shapes. The Fenn frame’s simple design makes them fashionable all year round. Fenn features the standard [parts of glasses](https://www.oscarwylee.com.au/glasses/eye/part-of-glasses), such as a rim, temples, lenses, hinges, and an adjustable nose pad fit.
### What are the Types of Temple Tips or Earpieces Included with Oscar Wylee’s Fenn Glasses?
The type of temple tips or earpieces included in Oscar Wylee’s Fenn Glasses are made from cellulose propionate.
### What Type of Nose Bridge do Oscar Wylee’s Fenn Glasses Have?
The type of nose bridge included in Oscar Wylee’s Fenn frame is characterised by adjustable nose pads.
### What Type of Nose Pads are Included with Oscar Wylee’s Fenn Glasses?
Oscar Wylee’s Fenn frame includes adjustable silicone nose pads.
### What Type of Lenses do Oscar Wylee’s Fenn Glasses Have?
The type of lenses that typically come with the Oscar Wylee Fenn [glasses frame](https://www.oscarwylee.com.au/glasses.html) are optical lenses. Optical lenses are glasses lenses that have a prescription within the lens to help correct vision issues such as myopia, hyperopia, and astigmatism. Fenn frames also come as sunglasses, and with non-prescription lenses and add-ons such as a blue-light filter.
### What Material is Used for the Rim of Oscar Wylee’s Fenn Glasses?
The material used for the rim of Oscar Wylee’s Fenn glasses frames are TR90 and stainless steel. The rim refers to the part of a glasses frame that holds the lenses.
### What Type of Hinges are Included with Oscar Wylee’s Fenn Glasses?
The type of hinges included with Oscar Wylee’s Fenn frames are normal hinges. These provide strength and smooth movement connecting the frame’s arms and lenses.
## What Face Types are Most Suitable for Oscar Wylee’s Fenn Glasses?
The face types that are most suitable for Oscar Wylee’s Fenn frame are square, oval, and pear face types. The Fenn frame is a classic shape, meaning that it complements the structure of square, oval, and pear faces particularly well. The classic Fenn frames help balance the features of a [square face shape](https://www.oscarwylee.com.au/glasses/face-shapes/square), an [oval face shape](https://www.oscarwylee.com.au/glasses/face-shapes/oval), and a [pear face shape](https://www.oscarwylee.com.au/glasses/face-shapes/pear), bringing the eyes and brows forward in a flattering way. Although there are many [glasses for face shapes](https://www.oscarwylee.com.au/glasses/face-shapes) that may be considered more aesthetically suitable, it is important that people also choose frames that make them feel most comfortable and represent their personal style.
## What Size Options are Available for Oscar Wylee’s Fenn Glasses?
The size options available for Oscar Wylee’s Fenn frame are a medium-fit frame across all colours.
## What Materials are Used to Create Oscar Wylee’s Fenn Glasses?
The materials used to create the Oscar Wylee Fenn frame are TR90, stainless steel, and cellulose propionate. TR90 is a form of thermoplastic material, perfect for making flexible, durable, and lightweight glasses. Stainless steel is a durable iron-based alloy, and cellulose propionate is a lightweight, flexible nylon-based plastic.
## What’s Included
## What's Included
Each pair of glasses comes with a stylish frame case and lens cloth. We offer free shipping across Australia and 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects.
* Free Shipping for Australian Orders
* 1 Year Warranty on frames and lenses
* Scratch resistance lens coating on all prescriptions
* UV-proof coating on all prescriptions
* Stylish case and cloth
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
## Make and Materials
The frames then go through cleaning and strict quality control, and many pairs of crafting hands to be hand-assembled and polished. After your frames have gone through the production process, they are individually examined and packed before making their way to you!Our frames go through numerous stages of production and are hand-polished to ensure a glorious lustre. Featuring a mix of high-quality acetate and polished metal, these mixed materials frames are sure to enhance your eyewear collection.
## Warranty Information
### Warranty Information
### Warranty Information
Oscar Wylee provides a 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects. 
We will repair or replace faulty or defective frames or lenses free of charge for warranty claims made within 1 year of the delivery.
We also offer repairs or replacement for problems experienced with vision during everyday use for claims made within 30 days of delivery. If the same product has been discontinued or is no longer available, then we may offer an exchange for a similar product or a refund.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Find a Store Location](https://www.oscarwylee.com.au/locations/full-store-list.html)
Recommended
1. [](https://www.oscarwylee.com.au/aries-optical.html)
[Aries](https://www.oscarwylee.com.au/aries-optical.html)
Champagne
2. [](https://www.oscarwylee.com.au/peggy-optical.html)
[Peggy](https://www.oscarwylee.com.au/peggy-optical.html)
Blush Pink
3. [](https://www.oscarwylee.com.au/serge-optical.html)
[Serge](https://www.oscarwylee.com.au/serge-optical.html)
Blue Lagoon