# Source: https://www.oscarwylee.com.au/locations/optometrist-townsville.html

# Optometrist Townsville
Shop 247, Main Centre310-330 Ross River RdAitkenvale QLD 4814
* Next to Hype DC
Opening hours
Monday9:00am - 5:30pm
Tuesday9:00am - 5:30pm
Wednesday9:00am - 5:30pm
Thursday9:00am - 7:00pm
Friday9:00am - 5:30pm
Saturday9:00am - 4:00pm
Sunday10:00am - 3:00pm
*Store hours reflect local standard trading hours and exclude public holidays
[Visit our Stockland Townsville Google Business page for directions, reviews, and updates.](https://g.page/r/CQKMZiw-gwckEAE)
Book Appointment
[Call us: (07) 4700 0229](tel:(07) 4700 0229)
[Leave a Review!](https://g.page/r/CQKMZiw-gwckEAE/review)
Our Reviews
Annaleise Germon
5 days ago
Amy at the Townsville store went absolutely ABOVE and beyond and I’m so incredibly thankful for her ...wonderful service!!!
See more
Lorraine Dunseath
2 weeks ago
Julie Trajcevska
2 weeks ago
Brilliant service from all the staff. All girls were so helpful with me in picking out my frames. Sh...aron the optometrist was so great with explaining to me about my eyes and ways to help. Girls at front were lovely. All 3 frames with lenses were at a wonderful price and saved my nearly $1000 compared to other places I've been before
See more
Alex L
3 weeks ago
Very friendly staff and overall a great experience
Ersilia Brus
3 weeks ago
Both staff members were friendly and helpful.
Went straight through, no waiting time.
Sue Young
1 month ago
Lecia Goodwin
1 month ago
Was a beaut experience from the moment I walked in - until I had finalised my selections - thank you... so much ????
See more
Kyle Trajcevski
1 month ago
Customer service was spot on and nice
Appointment was easy and seamless
Optometrist explained ever...ything and was nice
See more
Alec Hunt
2 months ago
Very Professional, on time straight in and out with everything taken care of,thankyou
Brenda Flannery
2 months ago
Sharon the Optometrist was excellent and answered all my queries. A good selection of eyewear which ...made it easy to choose.
See more
Elissa Morrow
2 months ago
I wanted to say thank you to the lady that worked in the Townsville store on Monday. I ordered 3 pai...rs of clears and 2 pairs of sunglasses and she was awesome, the best experience I’ve had trying to choose frames. I wish I got her name, and was hoping it would be listed on the receipt but it’s not. So to the lady who was working alone at the Townsville store Monday 01/06/2026, thank you ☺️
See more
Emma O'Brien
3 months ago
I had a lovely experience with the staff, very helpful and kind!
Lily Belcher
3 months ago
Sally Needham
3 months ago
Paris Delroy
3 months ago
Kyung Eun Lee
3 months ago
Leanne Cattana
4 months ago
Elizabeth Hughes
4 months ago
Thankyou Sharon for your patience and assistance.
Matteo Adornetto
4 months ago
J AFfA
6 months ago
Very satisfied with my visit to Oscar Wylee.
Very pleasant reception staff and excellent informed tr...eatment from the Optometrist.
Highly recommend after my experience.
See more
Ashley Palmer
6 months ago
emma Luxford
7 months ago
Brilliant experience this morning. The lovely Marcus explained the process to me and had great custo...mer service helping me select the glasses for me.
See more
Leigh Ryan
8 months ago
Joaquin Flores
8 months ago
The team was amazing and super friendly and made picking new frames so easy. They know their stuff
Tarif Ullah
8 months ago
great service, very friendly staff, price for prescription glasses are way cheaper than anywhere els...e in the market.
See more
Dakka
8 months ago
Had an eye test done at Oscar Wylee Stocklands T'ville staff were kind, smiley an helpful well done ...thanks guys ????????
See more
Isna Groenewald
9 months ago
Thank you so much for the help with my dehydrated eyes.... I appreciate it. Thanks to everyone!
Autumn Stephens
9 months ago
Timothy O'Donnell
10 months ago
Very professional staff and quality equipment. Got my in and out for my eye test with no fuss and in... no time.
See more
Tahnee Kirkman
10 months ago
The ladies were a great help, very quick and efficient service
Joy Kern
11 months ago
Customer service was on point. Friendly and helpful. Store was Neat &amp; Tidy. The optometrist was help...ful, professional and informative.
See more
airlie hughes
11 months ago
Got an eye test and ordered my glasses on the same day both staff were lovely and helpful
Evan Pritchard
11 months ago
anish kuriakose
1 year ago
Emmanuel Patrick (Emmanuel Patrick)
1 year ago
Nice experience and customer satisfaction
jess cook
1 year ago
Susan Andrea
1 year ago
Great service, advice and price. Very efficient and didn't have to wait.
Arnav Rampal
1 year ago
I had a fantastic experience at Oscar Wylee thanks to Raymond. From the moment I walked in, he was f...riendly, professional, and genuinely interested in helping me find the right pair of glasses. He took the time to understand what I was looking for, explained the different lens and frame options clearly, and gave honest, thoughtful advice that made the decision so much easier. I never felt rushed or pressured, and his attention to detail meant I ended up with a pair that not only suits my face perfectly but feels great to wear. Raymond’s customer service really stood out as it’s rare to find someone so patient and knowledgeable. Highly recommend seeing him if you’re after a smooth and stress-free experience choosing glasses.
See more
Heidi Jenkins
1 year ago
I had a fantastic experience at my recent eye test. The staff were welcoming, professional, and made... me feel comfortable from the moment I walked in. The optometrist was thorough and explained everything clearly, answering all my questions with patience and care. The test itself was quick, but detailed, and I left feeling confident about my eye health. I really appreciated how efficient and friendly the whole team was. Highly recommend to anyone needing an eye check-up!
See more
Stephen Tasselli Marriage Celebrant Townsville
1 year ago
Firstly, the Staff were super friendly and helpful, and they knew exactly what they were doing and u...nderstanding of the products made it easier for me to decide on some new glasses to purchase
See more
Katie Walters
1 year ago
The staff are phenomenal and the pricing is perfect. Thank you!!!
B P
1 year ago
The Townsville team are exceptional! Can’t recommend enough to everyone!
Carys Morgans
1 year ago
Helpful and friendly staff
Melinda Dawson
1 year ago
Really great experience at Oscar Wylee. Great support, informative and helpful.
Chloe Haldane
1 year ago
Bree Schipper
1 year ago
I had a great experience again at Oscar Wylee. The crew always run on time for eye checks, very thor...ough examination. The process is always explained. The store is clean and beautifully presented. I picked my glasses up today and it was a pleasant and quick process.
See more
Ygggh Tdtf
1 year ago
All good  thanks
Jaimme-lee Dishington
1 year ago
The girls last Saturday were so helpful, great customer service could reccomend the girls more ????✨...
See more
Ayub Iskandar Indraguna
1 year ago
Amy Wilson
1 year ago
The quality of service is second to none. Highly recommend Oscar Wylee for all your eye wear needs. ...Staff are so friendly and attentive. There is a great selection of fashionable, functional and affordable eye wear and the store is easy to navigate. Thank you for a great experience!
See more
## Find an Optometrist in Townsville With Oscar Wylee
Discover an Oscar Wylee in Stockland Townsville Shopping Centre, next door to Michael Hill Jeweller and close to Woolworths. Our Oscar Wylee Townsville optometrist can be found in-store, ready to offer you a Medicare bulk billed eye test for eligible cardholders. Speak to our friendly staff to find prescription glasses inspired by modern and vintage styles just for you! Stockland Townsville Shopping Centre has over 3000 parking spaces and is accessible by bus and the Translink Townsville Network. There is also a taxi rank by the entrance. 
When you’re done getting your prescriptions renewed at Oscar Wylee Townsville, why not explore Townsville's largest shopping centre? Explore the mall and its 205 stores, or take a nice long stroll over the Nathan Street bridge to look at the Ross River. Or leave the mall and visit the Botanical Garden, Castle Hill and The Strand to find a picturesque beachfront with a view of Townsville's Magnetic Island. Book an eye test with Oscar Wylee as we think we have some of the best optometrists in Townsville, Australia.        
Meet Our Team
* Store Manager
Our Services
* Bulk Billed Eye Examinations
* Professional Frame Styling
* Frame Adjustments and Repairs
* Visual Fields Testing
* Digital Retinal Scanning
Show All
## Find an Optometrist in Townsville, Queensland for an Eye Health Test
For great eye care services including eye tests and prescription updates, you can find many optometrists in Townsville, Queensland. Oscar Wylee Townsville offers bulk billed eye tests for eligible Medicare cardholders which involve vision assessment and detection of eye diseases. Our store in Townsville also has a wide range of trendy frames available as optical glasses and prescription sunglasses.
For a comprehensive eye test, there’s no need to see an eye doctor, as our Oscar Wylee optical dispensers and optometrists are trained and qualified so you can expect all the necessities of an eye health test in Townsville. The average price range for an optometrist in Townsville, Queensland can vary depending on factors such as the patient’s visual needs and age. Visit Oscar Wylee Townsville for all your optometry needs.
## How to Find an Optometrist in Townsville, Queensland?
To find an optometrist in Townsville, you can take certain steps that can help make it easier for you such as searching online, assessing the store’s opening hours and finding the directions to your chosen location. The steps on how to find an optometrist in Townsville are listed below.
1. Search online using the phrase, Townsville optometrist near me. This can also be done here on the website via our locations page.
2. Click on the Oscar Wylee link, which will take you directly to our Townsville optometrist store page.
3. See the store’s opening hours and where the store is located specifically.
4. Use the Townsville Google Business page link located under store hours to see the directions on how to get to the store.
You can also find an optometrist in Townsville, Queensland by searching the keywords optometrist near me. If you have locations enabled on your smartphone and you’re in the Townsville area, our Oscar Wylee Townsville store page should appear easily for you to click on.
### Is it Hard to Get an Eye Appointment in Townsville, Queensland?
No, it is not hard to get an eye appointment in Townsville. You can easily book an appointment to see an Oscar Wylee optometrist in Townsville right here on this page. At Oscar Wylee we have highly qualified optometrists available for bulk billed eye appointments, which can be booked online, over the phone, or in-store.
#### How to Compare Optometrists in Townsville to Each Other?
To compare optometrists in Townsville, you can use factors such as eye tests offered, health fund coverage, lens types and add-ons and eyewear offered. To take care of your vision and eye health, it is important to receive an eye test at least once every two years. There are different types of tests that can be performed in an eye test and not all optometrists may offer the same tests. Health funds can be used to help cover some of the cost of your frames and lenses. To find out if your health fund is accepted at a Townsville optometrist in Queensland, visit their website. In the case of Oscar Wylee, we accept all major health funds and provide on-the-spot claims in-store. There are many different lens options available for prescription glasses such as single vision, multifocal and high index lenses. Most optometrists in Townsville will offer these lenses although it is good to make sure. There are also lens add-ons available to enhance your glasses such as anti-reflective and blue light filters. Finally, if you are looking to purchase a pair of glasses after your eye test, you can compare the different styles and colours you are interested in from the optometrists in Townsville, Queensland. Oscar Wylee offers a wide range of frames with vintage and modern inspirations in bold colours and subtle designs.
#### How to Find an Eyeglasses Shop in Townsville, Queensland?
To find a glasses store in Townsville, you can try to follow these simple steps including searching online, selecting a convenient location and looking at their health insurance policies. The steps on how to find a glasses store in Townsville, Queensland are listed below.
1. Search online using the phrase, glasses store in Townsville. This will provide you with various options for glasses stores in the whole Townsville, Queensland area.
2. Select a glasses store that is most convenient for you to travel to.
3. Click the link to find out more information such as opening hours, exact location and directions to the glasses store in Townsville.
4. Read their health insurance policies to ensure you know what health benefits you can access.
Our Oscar Wylee glasses store in Townsville, Queensland offers primary eye care services such as comprehensive eye tests as well as other services performed by an optometrist and offers prescription and non-prescription eyewear.
##### Is it Possible to Purchase Prescribed Sunglasses in Townsville, Queensland Without Seeing an Optometrist?
Yes and no, it is possible to [purchase prescribed sunglasses](https://www.oscarwylee.com.au/sunglasses.html) in Townsville, Queensland without seeing an optometrist if you already have a prescription that has not expired. If your prescription is expired, you can book an eye test to receive an updated or new prescription which will require you to see an optometrist. This will ensure your prescription sunglasses are appropriate for your visual needs.
## Where is the Oscar Wylee Townsville Optometrist Located in Queensland?
The Oscar Wylee Townsville optometrist is located in Stockland Townsville Shopping Centre in Atikenvale next to Hype DC. Atikenvale is a suburb in the urban area of Townsville in Queensland.
### What is the Phone Number of Oscar Wylee Townsville Optometrist Store?
The Oscar Wylee Townsville optometrist store phone number is (07) 4700 0229. You can contact the Oscar Wylee Townsville store between the hours of 9 am and 5:30 pm on Mondays, 8:30 am and 5:30 pm on Tuesdays and Wednesdays, 8:30 am and 7 pm on Thursdays, 8:30 am and 5 pm on Fridays, 8 am and 4 pm on Saturdays and 10 am and 3 pm on Sundays.
### What are the Reviews for Oscar Wylee Townsville Optometrist in Queensland?
The many reviews for Oscar Wylee Townsville optometrist in Queensland, left by our various customers can be found here on the website as well as online when you search for Oscar Wylee Townsville optometrist. The reviews for Oscar Wylee Townsville optometrist are listed below.
* Chris Johnston:  Very professional and helpful staff. A delight to deal with.
* Walter Hall:  Very professional and helpful service from the young ladies in the Stockland shopping centre branch. Highly recommended.
* Jessica Collins:  Team were very helpful and quick at Stocklands on Saturday. Thanks guys!
* Dr Dereck Chong:  As always, Oscar Wylee provides professional service to the community. You don’t feel that they are upselling useless products. They provide a service tailored to your individual needs. Highly recommend Oscar Wylee, especially the Townsville team. They are the best out there.
#### What Treatments or Eye Care Processes are Done in the Oscar Wylee Townsville Optometrist Location?
The treatments or eye care processes done in the Oscar Wylee Townsville optometrist Queensland location include a tonometry test, a digital photograph, a slit lamp exam and a refraction test. Additional tests that may also be performed can include a visual field test and a dilated fundus exam. The treatments or eye-care processes that are done in the Oscar Wylee Townsville optometrist Queensland location are listed below.
* A Tonometry Test: An optometrist or optical dispenser will conduct a tonometry test which involves the use of a machine that will release small puffs of air into your eyes. This will assist with measuring pressure in the eye.
* A Digital Photograph: An optometrist or optical dispenser may take a digital photograph of your eye which can be kept on record to use in future appointments to evaluate any changes to your eye.
* Slit Lamp Test: A slit lamp test can be used to evaluate your eye health, by examining your cornea and iris which are the anterior and posterior of the eye.
* Refraction Test: During a refraction test, an optometrist will have you view an image through different lenses and ask you to confirm which helps you see the image clearer.
* Visual Field Test: A visual field test can assist with assessing your peripheral vision, which may be beneficial for identifying any signs of glaucoma.
* Dilated Fundus Exam: A dilated fundus exam can help an optometrist assess your health in more detail by getting a clear view of the retina. This test is typically carried out for patients with diabetes and those who may be at risk of developing retinal damage.
## How Many Optometrists Exist in Townsville, Queensland?
There are many optometrists that exist in Townsville, Queensland to provide eye tests and glasses, including Oscar Wylee. The amount of optometrists available in an area will typically depend on the population. At Oscar Wylee Townsville, we offer excellent optometry services including eye tests performed by skilled optometrists using high-quality equipment. We also have a wide range of fashion-forward frames that customers can browse in a large selection of sizes and colours. If you’re looking for an optometrist in Townsville, choose Oscar Wylee and we will take care of your optometry and eyewear needs.
### What are the Other Closest Optometrist Locations to Townsville, Queensland in Australia?
There are no other Oscar Wylee optometrist locations close to Townsville in Australia, however, we have many stores in New South Wales, Queensland, Western Australia and Victoria. If you are looking for an optometrist near you, you can find the locations of our many stores on our full [store locations page](https://www.oscarwylee.com.au/locations.html).
### Optometrist-Led Eye Tests at Oscar Wylee Townsville
Oscar Wylee Townsville offers bulk billed eye health tests for valid Medicare cardholders performed by our trusted optometrists. Book your yearly eye health check-up and shop for your new prescription on the same day. Here at Townsville Oscar Wylee, you can take care of your eyesight, and treat and examine eye diseases, both with regular eye tests and with affordable frames.
### Major health Funds Accepted at Oscar Wylee
With in-store experts at Oscar Wylee Townsville, you won’t have to navigate the ins and outs of your health fund alone. The friendly team can process your health fund claim in-store with a valid health fund card, so remember to bring your card to your next appointment. Here at Oscar Wylee Townsville, we want to make sure you get the best prescription glasses and sunglasses you need at an affordable, competitive price.
### Stylish Frames at Oscar Wylee Townsville
Find a wide range of stylish and affordable glasses and prescription sunglasses at Oscar Wylee Townsville. Visit our Oscar Wylee Townsville eyeglasses shop today and chat with any one of our experts to discover the perfect frames for your personal style. Plus, we have a range of great deals including our prescription glasses at 2 pairs from $199 and 3 pairs from $249.
Book Appointment
[Call us: (07) 4700 0229](tel:(07) 4700 0229)
[Leave a Review!](https://g.page/r/CQKMZiw-gwckEAE/review)