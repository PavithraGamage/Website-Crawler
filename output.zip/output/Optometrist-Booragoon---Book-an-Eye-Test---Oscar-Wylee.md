# Source: https://www.oscarwylee.com.au/locations/optometrist-booragoon.html

# Optometrist Booragoon
Westfield T17, 125 Riseley StBooragoon WA 6154
* Near The Body Shop
Opening hours
Monday9:00am - 5:30pm
Tuesday9:00am - 5:30pm
Wednesday9:00am - 5:30pm
Thursday9:00am - 8:00pm
Friday9:00am - 5:30pm
Saturday9:00am - 5:00pm
Sunday11:00am - 5:00pm
*Store hours reflect local standard trading hours and exclude public holidays
[Visit our Booragoon Google Business page for directions, reviews, and updates.](https://g.page/r/CRNzlq-QS5cSEBM)
Book Appointment
[Call us: (08) 6249 7150](tel:(08) 6249 7150)
[Leave a Review!](https://g.page/r/CRNzlq-QS5cSEBM/review)
Our Reviews
Bruce Teague
4 days ago
Great. Very thorough and helpful
Elephant 19
4 days ago
Wonderful service answered all my questions and staff were helpful
Leonie Bovell
1 week ago
I am always happy with my appointments at Oscar Wylee, Booragoon. The only thing I think should chan...ge is that the optometrist should be named, even in your text reminders. (ie "a reminder that you have an appointment with ?????" at Booragoon) I have been to this person several times but I still don't know his name! Good service regarding frames.
See more
jordyn
1 week ago
I would recommend Oscar Wylee to anyone! The two girls in reception who helped me with pricing and p...icking glasses were so lovely, and the optometrist was also great. Nice range of cute glasses as well :)
See more
Kayla Vecchio
1 week ago
Harley Meunier
2 weeks ago
Experience friendly staff. Save hundreds recommend to anyone ????
beverley warrington
2 weeks ago
was very happy with my experience.All the staff were very helpful understanding of my situation at t...he time.This was my first visit but i feel now not my last
See more
Angelina Wright
2 weeks ago
Michael Aleknavicius
2 weeks ago
Emma Pointon
3 weeks ago
I had such a lovely experience at Oscar Wylee Booragoon from start to finish. The team were welcomin...g, friendly and genuinely took the time to help me find the right pair of glasses without making me feel rushed.
See more
Richard Kinnane
4 weeks ago
Friendly professional service
Robynne McTaggart
1 month ago
Awesome - very efficient and on time with the appointment
Pardeep Ghai
1 month ago
I’m delighted to share my great
experience today at: Oscar Wylee
Optometrist,Booragoon.
The staff at... the counter welcomed
all their customers with an honest
and sweet smile on their face.They
are very friendly and made your
experience easy and comfortable.
Aamir-the optometrist is very nice
and professional.He explained me
everything clearly and answer my
all questions properly.
No hesitation to refer/revisit again-
Oscar Wylee Optometrist, in future
as and when I need the services of
Optometrist!????????
See more
Sue Garrod-Raynor
1 month ago
They were absolutely lovely recommend anyone to go there ver professional and made me.feel at ease
Ash cranberry
1 month ago
The staff were really lovely and helpful and the optometrist was kind and patient, I really apprecia...te how he explained things clearly to me in a way that was easy to understand and provided me with upfront and realistic advice.
The lovely lady who helped me to decide on some frames was also very patient and I appreciated how she broke down &amp; explained the pricing options as well as gave me some style recommendations when I didn’t know where to begin.
Thank you for making my first eye test such a good &amp; comfortable experience ????
See more
James Gilmour
1 month ago
Ozzie Trent
1 month ago
Amazing service !!
Annie Chester
1 month ago
India Kelsall-Foreman
2 months ago
svetlanie -
2 months ago
Amanda Spencer
2 months ago
Kreshan Nunkoo
2 months ago
Had fun!
Wess Von Hooton
2 months ago
I instantly felt at ease by the warm nature of the assistant, who was very warm, friendly and attent...ive. The optometrist was just as friendly and I felt completely comfortable in his presence and by his knowledge and advice.
See more
Lakbay ni Drew
2 months ago
Sharon Gordon
2 months ago
I had the most incredible, professional experience when Renae answered and solved my query. She was ...efficient, extremely polite and provided a quick fix.
Thank you Renae.
See more
Anne Champion
2 months ago
The Oscar Wyler team in Garden City were exceptional! Very quick and efficient with the eye test and... then the added bonus of assisting with “girlfriend advice” on the selection of frames. Thank you team!!!!
See more
Vicky Piromalli
2 months ago
Amazing service. Thank you ????
Crystal Cao
3 months ago
Srinivasa Krishna Ponasanapalli
3 months ago
As always friendly staff and efficient service, with great range of options to choose!
John Diilio
3 months ago
Very professional and thorough people
Lana Ge
3 months ago
Excellent experience at the Oscar Wylee store in Booragoon.
The doctor was incredibly attentive and ...explained everything so clearly that even a child would understand the procedures and concerns. I was really impressed. He explained everything in such a calm, tactful, and careful way, which made me feel reassured and comfortable. He was also very patient with all of my endless questions, and I truly appreciate that. Thank you so much!
I wish more people worked like this.
See more
Thanika Jeyaramn
3 months ago
Oscar Wylee was able to accommodate my urgent request and provided an excellent service
Caterine Harianja
3 months ago
Natalie Gaul
3 months ago
Helpful staff, and great service. I will be back.
Sharon Keesing
3 months ago
John Renouf
3 months ago
Quick, professional, and frames cost less.
Tracey Larke
3 months ago
Very professional and helpful.
Grace Holden
3 months ago
Lou was an absolute pleasure to deal with, along with the rest of the team.
Could not recommend enou...gh!
See more
Carmen Chin
3 months ago
Friendly and professional staff who made the whole experience easy and comfortable. The optometrist ...explained everything clearly and took the time to answer questions properly. Great selection of glasses with lots of styles to choose from. Really happy with the service and would definitely recommend !
See more
Cosimo Cutri
3 months ago
Amazing such A great experience and very professional
Joe Dinh
3 months ago
Excellent service. Fast and professional. The Optometrist Robert was friendly and provided good advi...ce.
See more
Shari Norrish
3 months ago
Very lovely and helpful Optometry assistants, helped me with my choice.  Optometrist was very thorou...gh and told me some things I'd never been told before about my eyes and eyesight.
See more
Jessica Burton
3 months ago
Outstanding service and attention to detail. Incredibly thorough, quick and real. Highly recommended....
See more
Mia Turner
3 months ago
Fantastic team and lovely service. I was really looked after! Can’t wait to get my new glasses ☺️...
See more
Thomas Rushton
4 months ago
I would like to thank Oscar Wylee staff at Booragoon for keeping a regular check on me. In particula...r I'd like to commend Rob for testing and arranging further quick medical guidance. Thanks guys.
Tom
See more
Jill Russell
4 months ago
Efficient and professional.  A wide range of frames to choose from.  Great service
Anastasia Lili
4 months ago
First time at Oscar Wylee Booragoon,  amazing experience,  very details on eye test and explaining, ...excellent customer service.
See more
Nena Sorensen
4 months ago
The staff were very helpful and definitely considered my question ls about what frames suited me.
T...he optometrist was sensational and super energetic. He made the testing fund and was really informative and very thorough. Highly recommend.
Thank you team. I look forward to picking up my glasses and being able to read my graphic novels again.
See more
Kim Pearson
4 months ago
FANTASTIC ????
LOVE YOUR FRAMES
GREAT QUICK SERVICE ????
KIM ????
Bhavna Soni
4 months ago
Experience was great, everyone was quite friendly and helpful.
## Find an Optometrist in Booragoon With Oscar Wylee
Our Oscar Wylee store located in Booragoon Westfield is close to areas such as Ardross and Mount Pleasant. At Oscar Wylee Booragoon, our dedicated optometrists offer Medicare bulk billed eye health tests for same-day prescriptions. Oscar Wylee Booragoon has a variety of different frames to suit your style and vision needs, from vintage classics to bold, trendy styles.
Booragoon Westfield is a short walk from the Swan River. You can discover its natural beauty as it creates a spectacular contrast against the skyline of the city's high rises. Booragoon Westfield is a premium shopping centre located 15 minutes south of Perth CBD. It’s your one-stop shopping hub for fun and relaxation. After your appointment, you can explore fashion, entertainment and dining or catch a movie at HOYTS.        
Meet Our Team
* Optometrist
Doctor of Optometry
* Retail Partner
Our Services
* Bulk Billed Eye Examinations
* Professional Frame Styling
* Frame Adjustments and Repairs
* Visual Fields Testing
* Digital Retinal Scanning
Show All
## Find an Optometrist in Booragoon, Perth for an Eye Health Test
If you require high-quality eye care services such as eye health tests in Booragoon, Perth, come and visit our Oscar Wylee optometrists. Located in Booragoon Westfield, our dedicated optometrists are available to provide eye health tests that include vision testing and help in detecting and managing eye diseases. Our optometrists can also update prescriptions and refer patients with complex eye conditions to an eye doctor, known in Australia as an ophthalmologist, for specialised treatment. The average cost for an optometrist, ophthalmologist or other eye care services in Booragoon will be dependent on an individual’s eye care needs and age as well as underlying health conditions. At Oscar Wylee, our eye tests are conducted at a bulk billed price under Australia’s Medicare system.
At our Oscar Wylee glasses shop in Booragoon, Perth, our retail staff, including our optical dispensers, are available in-store to help customers find the eyewear that works best for their vision needs. Choose from our stylish range of frames including prescription glasses, prescription sunglasses or non-prescription glasses and our staff will make sure you leave with the perfect glasses fit.
## How to Find an Optometrist in Booragoon, Perth?
To find an optometrist in Booragoon, Perth you can take certain steps that can help make it easier for you such as searching online, assessing the store’s opening hours and finding the directions to your chosen location. The steps on how to find an optometrist in Booragoon, Perth are listed below.
1. Search online using the phrase, optometrist near me in Booragoon. This can also be done here on the website via our locations page.
2. Click on the Oscar Wylee link, which will take you directly to our Booragoon optometrist store page.
3. See the store’s opening hours and where the store is located specifically.
4. Use the Booragoon Google Business page link located under store hours to see the directions on how to get to the store.
You can also find an optometrist in Booragoon, Perth by searching the keywords optometrist near me. If you have locations enabled on your smartphone and you’re in the Booragoon, Perth area, our Booragoon store page should appear easily for you to click on.
### Is it Hard to Get an Eye Appointment in Booragoon, Perth?
No, it is not hard to get an eye appointment in Booragoon. You can easily book an appointment to see an Oscar Wylee optometrist in Booragoon, Perth right here on this page. At Oscar Wylee we have highly qualified optometrists available for bulk billed eye appointments, which can be booked online or in-store.
#### How to Compare Optometrists in Booragoon, Perth to Each Other?
To compare optometrists in Booragoon, Perth, you can use factors such as eye tests offered, health fund coverage, lens types and add-ons and eyewear offered. To take care of your vision and eye health, it is important to receive an eye test at least once every two years. There are different types of tests that can be performed in an eye test and not all optometrists may offer the same tests. Health funds can be used to help cover some of the cost of your frames and lenses. To find out if your health fund is accepted at an optometrist in Booragoon, Perth visit their website. In the case of Oscar Wylee, we accept all major health funds and provide on-the-spot claims in-store. There are many different lens options available for prescription glasses such as single-vision, multifocal and high-index lenses. Most optometrists in Booragoon, Perth will offer these lenses although it is good to make sure. There are also lens add-ons available to enhance your glasses such as anti-reflective and blue light filters. Finally, if you are looking to purchase a pair of glasses after your eye test, you can compare the different styles and colours you are interested in from the optometrists in Booragoon, Perth. Oscar Wylee offers a wide range of frames with vintage and modern inspirations in bold colours and subtle designs.
#### How to Find an Eyeglasses Shop in Booragoon, Perth?
To find a glasses store in Booragoon, Perth you can try to follow these simple steps including searching online, selecting a convenient location and looking at their health insurance policies. The steps on how to find a glasses store in Booragoon, Perth are listed below.
1. Search online using the phrase, glasses store in Booragoon, Perth. This will provide you with various options for glasses stores in the whole Booragoon, Perth area.
2. Select a glasses store that is most convenient for you to travel to.
3. Click the link to find out more information such as opening hours, exact location and directions to the glasses store in Booragoon.
4. Read their health insurance policies to ensure you know what health benefits you have access to.
Our Oscar Wylee glasses store in Booragoon, Perth offers primary eye care services such as comprehensive eye tests as well as other services performed by an optometrist and offers prescription and non-prescription eyewear.
##### Is it Possible to Purchase Prescribed Sunglasses in Booragoon, Perth Without Seeing an Optometrist?
Yes and no, it is possible to [purchase prescribed sunglasses](https://www.oscarwylee.com.au/sunglasses.html) in Booragoon, Perth without seeing an optometrist if you already have a prescription that has not expired. If your prescription is expired, you can book an eye test to receive an updated or new prescription which will require you to see an optometrist. This will ensure your prescription sunglasses are appropriate for your visual needs.
## Where is the Oscar Wylee Booragoon, Perth Optometrist Located?
The Oscar Wylee Booragoon optometrist is located in the Booragoon Westfield Shopping Centre. The Westfield Booragoon Shopping Centre is located at 125 Riseley Street, Booragoon, Perth.
### What is the Phone Number of Oscar Wylee Booragoon, Perth Optometrist Store?
The phone number for our Oscar Wylee Booragoon, Perth optometrist store is (08) 6249 7150. Our Oscar Wylee Booragoon, Perth store is open, and our staff are available to be contacted between 9 am and 5.30 pm from Monday to Wednesday, 9 am to 8 pm on Thursdays, 9 am to 5.30 pm on Fridays, 9 am to 5 pm on Saturdays and 11 am to 5 pm on Sundays.
### What are the Reviews for Oscar Wylee Booragoon, Perth Optometrist?
The customer reviews for our Oscar Wylee Booragoon, Perth optometrist, can be found here on the website and online when you search for Oscar Wylee Booragoon optometrist. The reviews for our Oscar Wylee Booragoon optometrist are listed below.
* Matt Porter:  My experience at Oscar Wylee in Booragoon WA, was very good. I found the staff happy, helpful and professional. The range of frames were well priced with a wide variety of styles.
* Natalie Phillips:  Very kind staff. The optometrist here is dedicated to ensuring your prescription is right. Thank you.
* David Loye:  First time buying glasses from Oscar Wylee and it was a pleasant and fun experience. Lots of frames to choose from and the staff were great at customer service. Our eye test was the best we have ever experienced, the optometrist was patient and very thorough and explained every step and answered all our questions in an easy-to-understand way. We are very happy customers.
#### What Treatments or Eye Care Processes Are Done in the Oscar Wylee Booragoon, Perth Optometrist Location?
The treatments or eye care processes done in the Oscar Wylee Booragoon, Perth optometrist location include a tonometry test, a digital photograph, a slit lamp exam and a refraction test. Additional tests that may also be performed can include a visual field test and a dilated fundus exam. The treatments or eye-care processes that are done in the Oscar Wylee Booragoon optometrist location are listed below.
* A Tonometry Test: An optometrist or optical dispenser will conduct a tonometry test which involves the use of a machine that will release small puffs of air into your eyes. This will assist with measuring pressure in the eye.
* A Digital Photograph: An optometrist or optical dispenser may take a digital photograph of your eye which can be kept on record to use in future appointments to evaluate any changes to your eye.
* Slit Lamp Test: A slit lamp test can be used to evaluate your eye health, by examining your cornea and iris which are the anterior and posterior of the eye.
* Refraction Test: During a refraction test, an optometrist will have you view an image through different lenses and ask you to confirm which helps you see the image clearer.
* Visual Field Test: A visual field test can assist with assessing your peripheral vision, which may be beneficial for identifying any signs of glaucoma.
* Dilated Fundus Exam: A dilated fundus exam can help an optometrist assess your health in more detail by getting a clear view of the retina. This test is typically carried out for patients with diabetes and those who may be at risk of developing retinal damage.
## How Many Optometrists Exist in Booragoon, Perth?
Many optometrists exist in Booragoon, Perth including Oscar Wylee. The amount of optometrists available in an area will typically depend on the population and the eye care needs of those in the area. At Oscar Wylee Booragoon, Perth, our team is passionate about providing our customers with high-quality, dedicated eye care services. Our optometrists are available to provide bulk billed eye tests with our dedicated optometrists, prescription updates and new frames. If you are looking for an optometrist in Booragoon, Perth, Oscar Wylee is available to provide all your eye care and eyewear needs.
### What are the Other Closest Optometrist Locations to Booragoon, Perth in Australia?
The closest Oscar Wylee Optometrist locations to Booragoon, Perth are Carousel Westfield, Fremantle and Claremont. The closest Oscar Wylee optometrist locations to Booragoon, Perth are listed below.
* Carousel Westfield:  Carousel Westfield is a shopping centre located in Cannington, Perth, approximately 14 km away from Booragoon, where you can find an Oscar Wylee optometrist. Our [Oscar Wylee Carousel](https://www.oscarwylee.com.au/locations/optometrist-carousel.html) optometrists are available to provide Medicare bulk billed eye tests for eligible cardholders.
* Fremantle:  Fremantle is a suburb located approximately 10 km away from Booragoon where you can find an Oscar Wylee optometrist for your eye care services. Our [Oscar Wylee Fremantle](https://www.oscarwylee.com.au/locations/optometrist-fremantle.html) store is located in the Manning Buildings. Here our team can provide eye tests, prescription updates and new frames.
* Claremont:  Claremont is a suburb approximately 17 km away from Booragoon where our Oscar Wylee optometrists are available for eye tests. [Oscar Wylee Claremont](https://www.oscarwylee.com.au/locations/optometrist-claremont.html) is located in the Claremont Quarter Shopping Centre on Bay View Terrace.
### Oscar Wylee Optometrist Eye Tests in Booragoon
For some of the best optometrists in Booragoon, Australia, come and visit Oscar Wylee Booragoon Westfield. Our Oscar Wylee optometrists are highly trained and equipped with some of the best optometry equipment to provide excellent eye care processes for our customers, including Medicare bulk billed eye tests to assess vision and examine the eyes for possible eye diseases or conditions.
### Health Funds Accepted at Oscar Wylee Booragoon
At our Oscar Wylee eyeglasses shop at Booragoon, we accept major health funds to help cover some of the cost of selected services. Bring your valid health fund card to Oscar Wylee Booragoon and our team can help process your claim in-store as well as assist with any questions about eligibility.
### Expert Advice in Oscar Wylee Optometrist Booragoon
Our friendly staff at Oscar Wylee Booragoon will help you find the perfect pair of glasses every time. No matter if you’re buying a pair of prescription glasses, prescription sunglasses or non-prescription glasses we’ve got you covered, with a range of styles, sizes and colours available. Get fitted for frames, choose from our different lens options and add-ons and get the most out of your frames at Oscar Wylee Booragoon!
Book Appointment
[Call us: (08) 6249 7150](tel:(08) 6249 7150)
[Leave a Review!](https://g.page/r/CRNzlq-QS5cSEBM/review)