# Source: https://www.oscarwylee.com.au/apo-optical.html

Out of stock        
# Apo
## About the Frames
Apo has a two-toned pattern with charming animal cartoons on the arms. This kid-proof frame has a flexible hinge and comes with a removable neck band and ear grips, making it perfect for running around the playground or having fun with friends. The frame and its removable accessories are made out of latex free and hypoallergenic materials.
### Made from TR90
Frame fitX-Small
Measurements47 - 15 - 134
These measurements mean lens width, bridge, and temple length. They can be found on the inside of the temple arm. If you already have a pair that you like, you can compare it to these measurements.
## What’s Included
## What's Included
Each pair of glasses comes with a stylish frame case and lens cloth. We offer free shipping across Australia and 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects.
* Free Shipping for Australian Orders
* 1 Year Warranty on frames and lenses
* Scratch resistance lens coating on all prescriptions
* UV-proof coating on all prescriptions
* Stylish case and cloth
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
## Warranty Information
### Warranty Information
### Warranty Information
Oscar Wylee provides a 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects. We will repair or replace faulty or defective frames or lenses free of charge for warranty claims made within 1 year of the delivery. We also offer repairs or replacement for problems experienced with vision during everyday use for claims made within 30 days of delivery. If the same product has been discontinued or is no longer available, then we may offer an exchange for a similar product or a refund.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Find a Store Location](https://www.oscarwylee.com.au/locations/full-store-list.html)