# Source: https://www.oscarwylee.com.au/eye-health/common-eye-conditions.html

# Common Eye Conditions
Here are a list of common eye conditions that can affect anyone.Your eyes can tell a lot about your general health, such as showing symptoms of diabetes or high blood pressure. These symptoms are not always obvious, that’s why a regular eye test is important to maintain your health. If you think you need help or due for a check up, please contact your local Oscar Wylee optometrist.
* [](https://www.oscarwylee.com.au/faq-popular.html)
### Glossary Of Common Eye Conditions
Astigmatism
You may have heard of people having astigmatism, but what does it mean? It’s actually a very common condition that is experienced by many people, and causes the following symptoms:
* Blurry vision
* Eye strain
* Headaches
* Increased glare, especially at night.
Causes of astigmatism
Eye astigmatism occurs when images in the eye are not focused to one point, due to the irregular shape of the cornea, lens or retina. Instead of being perfectly round (spherical), they are more oval shaped (cylindrical).
Managing astigmatism
The good news is that optometrists will test for astigmatism during your eye examination, and it can be corrected by wearing glasses to give you clear and comfortable vision.
Blepharitis
If you’ve been experiencing irritated, gritty, watery, red eyes, swollen and sticky eyelids, or even flaky skin around the eyes, chances are, you may be suffering from a type of blepharitis.
* Anterior blepharitis affects the eyelashes at the outer front portion of the eyelid.
* Posterior blepharitis affects the oil glands which are closer to the inner back surface of the eyelid that touches the eyeball.
Causes of blepharitis
To treat the blepharitis, your optometrist may ask some questions about what could be triggering your condition, such as:
* Dry eyes
* Bacterial infections: including Staphylococcus
* Seborrheic dermatitis: dandruff from the eyebrows and scalp
* Allergies: environmental allergies or reactions to skin care products, cosmetics, eyelash glue, contact lens solution, eye drops or medication
* Rosacea: a skin condition causing a red rash across the face
* Mites and lice (these are less common)
Treating blepharitis
Your optometrist may make one or more of the following recommendations:
* Stopping contact lens wear temporarily
* Antibiotic drops or cream
* Lubricating eye drops
* Eyelid scrubs: cleaning the dandruff and crusting from the eyelashes
* Warm compresses: carefully applying heat to the eyelids and gently massaging the oil glands
* Blephasteam
* IPL treatment
Cataracts
It’s estimated that by the age of 65, over 90% of people will have developed a form of cataract – meaning most of us will experience them as we get older. So, why does this happen? Cataracts form in the eye lens as a result of the clumping of protein, leading to a decline in clear vision. This process happens naturally with advancing age, which is why they are so common.
Sometimes, there are other causes of cataracts, including:
* Being born with congenital cataracts
* Trauma to the eye
* Medication (such as corticosteroids)
* Diabetes: cataracts are more common in diabetics
Of course, there’s no need to worry if you have regular eye checks, because your optometrist can let you know how your cataracts are progressing.
Here are the 3 main types of age-related cataracts that your optometrist with look out for:
* Nuclear
* Cortical
* Posterior subcapsular
Make sure you let your optometrist know if you are experiencing any of the following symptoms of cataracts:
* Cloudy or foggy vision
* Poor night vision
* Double vision in one eye
* Increased sensitivity to glare, especially with night driving
* Colours appearing less vivid or bright than they used to
* Frequent changes to your glasses prescription
Cataract treatment and prevention:
* Early cataracts: a change to your prescription and increasing lighting may be enough
* Advanced cataracts: require removal through surgery
* Wearing sunglasses outside to protect your eyes may help to delay the onset of early cataracts
Chalazion
If you’ve ever looked in the mirror to find that your eyelid feels heavy and droopy or lumpy, you may have a chalazion.
How to tell if it’s a chalazion on your eye
Also known as an internal hordeolum, a chalazion is a sign of a blocked oil gland, usually underneath your upper eyelid, resulting in swelling of the affected area. It may feel tender to touch. After a period of time, a harder red lump will start to form.
Causes of a chalazion
* Posterior blepharitis
* Rosacea
* Seborrheic dermatitis
* Tuberculosis
* Viral infection
How to treat a chalazion
They usually disappear by themselves after a few weeks to a month, but if they are affecting your vision or not improving, have a chat with your optometrist.In most cases, you’ll want to keep the eye as comfortable as possible while treating the posterior blepharitis (see section on Blepharitis).
* Avoid contact lens wear and makeup
* Avoid squeezing, rubbing or touching the chalazion
* Try warm compresses with a gentle massage to unclog the blocked oil gland
* Your optometrist may prescribe antibiotics or steroid medication to help with the swelling
Cloudy vision
We’ve all experienced times when our vision seems to go hazy all of a sudden, but then it usually clears after we rub our eyes or blink a few times. But what if it keeps happening? Here’s what it could be.
Is it cloudy or blurry?
* Cloudy vision is often described as looking through a fog, even when you squint
* Blurry vision comes into better focus and improves if you squint
Most common causes of cloudy vision
* Cataracts
* Dry eyes: irritation, grittiness, watering
* Migraine: headaches
* Corneal scar resulting from an injury
* Foreign body in the eye
Less common causes
* Fuch’s dystrophy
* Glaucoma
* Age-related macular degeneration (AMD)
* Diabetic retinopathy
* Optic neuritis
* Retinal vein occlusion
* Stroke
Cloudy eye conditions
If you notice that the cornea, the front surface of your eye, appears cloudy around the pupil, this is what could be causing it:
* High cholesterol
* Scarring from an eye injury
* Corneal diseases such as keratoconus or band keratopathy
Cloudy pupil
If you notice that your child’s pupil is white/cloudy, this could be a congenital cataract, or retinoblastoma, a rare form of eye cancer. Contact your doctor immediately as urgent treatment is required.
Still unsure? Find out what’s really going on
By making an appointment with one of our fully qualified optometrists for a comprehensive eye test to discuss your concerns.
[Book an eye test](https://www.oscarwylee.com.au/booking/)
Computer eye strain
If you’re sitting in front of your computer reading this right now, you may already be familiar with computer eye strain.
Increased screen time causes eye strain
According to the American Optometric Association, you are at the greatest risk of computer-related eye strain if you spend more than 2 hours a day in front of a screen. This includes digital devices such as laptops, computers, mobile phones, tablets and e-readers.
Other symptoms you may experience
* Blurry vision
* Double vision
* Headaches
* Sore eyes
* Dry eyes
* You may also suffer from neck and shoulder pain
Causes of computer eye strain
* Uncorrected vision problem
* Poor eye coordination
* Not taking enough breaks
* Inadequate lighting
* Glare reflecting off the screen
* Improper viewing distance
* Poor sitting posture
Managing computer eye strain
Our fully qualified optometrists are here to support you with options to make work and study easier for you:
* Prescription glasses to ease eye strain
* Lenses designed for use in front of a computer
* Eye exercises
* Anti-glare computer glasses: to reduce the discomfort from screen brightness
* Blue light glasses
Conjunctivitis (Pink Eye)
It’s quite likely that most of us have experienced conjunctivitis at some point, but what is it exactly? And what is pink eye?Conjunctivitis is an inflammation of the conjunctiva, a lining covering the white part of the eye and underneath your eyelids. The small blood vessels within the conjunctiva will dilate and cause the eye to take on a pinkish-red colour (that’s where “pink eye” comes from).
Here are the most common causes of conjunctivitis:
* Allergies
* Bacterial infections
* Viral infections
* Contact lens wear
Besides pink eye, there are other associated conjunctivitis symptoms:
* Itchy, irritated, sore, gritty feeling in the eyes
* Crusting in the corners of the eyes
* Watery eye
* White, yellow or stringy discharge
Worried that you may have pink eye?
There are several pink eye and conjunctivitis treatments and different types of eye drops for conjunctivitis in Australia. Before you head to the pharmacy, we recommend seeing your optometrist first for specific advice. This may include:
* Stopping contact lens wear temporarily, and adjusting your wearing habits
* Allergy eye drops
* Hayfever tablets
* Antibiotic drops or cream
* Lubricating eye drops
* Steroid eye drops
* Treat any underlying dry eye
Corneal ulcer
Having an eye ulcer is just as painful as it sounds, and requires urgent treatment so it doesn’t get worse and damage your eyesight. If you’ve been diagnosed with a corneal ulcer, it means that you have an open sore on your cornea.
Symptoms of corneal ulcers:
* Pain
* Watery eyes
* Discharge
* Red eyes
* Blurry vision
* Sensitivity to bright light
* You may notice a white spot on your cornea
Symptoms of corneal ulcers:
Contact lens related infections
* Bacteria
* Fungal
* Parasitic (especially Acanthamoeba from freshwater and soil)
Non contact lens related infections
* Virus: such as cold sores, shingles, chicken pox. Can be triggered by stress, sunlight or a compromised immune system
* Injury (chemical burns or abrasions)
* Severe dry eye
* Eyelid conditions which affect the ability to blink, leading to prolonged eye surface exposure and dryness (such as Bell’s Palsy)
See your optometrist or ophthalmologist urgently. Corneal ulcers can spread quickly, cause significant scarring on the eye and damage your vision if they are left untreated for too long.Rest assured though, that there are plenty of corneal ulcer treatments available, for both minor and serious infections, including:
* Eye drops and oral medication: anti-bacterial, anti-fungal and anti-viral
* Steroid eye drops and oral medication
Diabetic retinopathy
Diabetes is one of the fastest growing cardiovascular diseases in Australia, but did you know that it can affect the eyes as well?Diabetic retinopathy (DR) is a complication of diabetes where the small blood vessels in the back of the eye are damaged.
It is classified into different categories:
* Non-proliferative DR: this is an early stage where blood vessels leak blood and fluid into the retina. Vision is usually minimally affected
* Proliferative DR: is an advanced stage where new blood vessels are formed to replace those that are no longer working. These new vessels are prone to leaking, and can cause sudden vision loss
* Cystoid macular oedema: fluid leakage underneath the macula, causing blurry vision
How to prevent vision loss/blindness from diabetic retinopathy
If you have been diagnosed with background diabetic retinopathy, it doesn’t mean you will go blind. Through early detection and treatment, it’s possible to maintain a reasonable level of vision.
* Have good control of your blood sugar levels
* See your general practitioner for blood tests to assess your blood sugar levels
* Yearly diabetic eye examinations with your optometrist can be bulk billed to Medicare
* See your ophthalmologist regularly to have any diabetic retinopathy closely monitored
Treatments available from your ophthalmologist
* Laser treatment
* Injections
* Surgery
Double vision (diplopia)
If you’re finding yourself seeing double vision all of a sudden, it could be a sign of something serious. So what is double vision, what causes it and how can it be fixed?
What is double vision?
When looking at 1 object, you will see 2 images. Sometimes the images overlap, other times they are completely separate. You may constantly be blinking to refocus. It can lead to fatigue, headaches, eye strain and difficulty concentrating.What causes double vision?
Double vision in 1 eye
* Cataract
* Corneal scars from injury or infection
* Keratoconus
* Severe dry eye
Double vision with 2 eyes open is more serious
* Lazy eye/strabismus (poor control by the eye muscle causing misalignment)
* Nerve issues: Myasthenia Gravis, Graves Disease, Multiple sclerosis, Guillain-Barre syndrome, diabetes
* Brain: stroke, aneurysm, elevated intracranial pressure from injury, bleeding, infection, tumour, migraines
Treatment options for double vision from your optometrist
Your optometrist can assist with some muscle misalignment issues:
* By referring to an ophthalmologist for eye muscle surgery
* By working with your ophthalmologist to help improve your diplopia
* By prescribing vision therapy exercises
* By prescribing prism glasses
Double vision that needs urgent medical attention
If you notice any of the following signs along with your double vision, you must see your doctor ASAP:
* Headaches
* Nausea
* Droopy eyelids
* Pain with eye movement/around the eye
* Muscle weakness
* Dizziness
* Balance issues
Dry eye syndrome
Many of us have experienced the feeling of dry eyes at some point, and it is thought to be more common in women. Understanding more about it can help us to manage it better.
What is dry eye?
Dry eye syndrome is caused by either:
* The tears in our eyes evaporating too quickly, or
* The eyes are not producing enough tears
Symptoms of dry eye
* Sore, burning, irritated, red, watery or gritty eyes
* Watery eyes
* Blurry vision
* Glare sensitivity
* Eyelids sticking together
* Crusting at the corners of the eyes upon waking
* Difficulty keeping the eyes open
* Reduced tolerance to contact lenses
Causes of dry eye
* Older age
* Increased screen time: we tend to blink less to refresh our tears when concentrating
* Contact lens wear
* Exposure to hot, dry, smoky, windy or dusty environments
* Some medications
* Autoimmune conditions such as Sjogrens syndrome and rheumatoid arthritis
* Health conditions such as Bell’s Palsy and shingles
* Vitamin A deficiency
* Blepharitis
* Previous eye injury or surgery
* Laser eye surgery
* Eyelid conditions causing incomplete blink
See your optometrist to discuss management options, including:
* Tear supplement eye drops for dry eyes
* Treat the blepharitis: eyelid scrubs and warm compresses
* Steroid drops
* IPL treatment
* Blephasteam
* Changing contact lens wearing habits
* Punctal plugs
* Surgery to treat incomplete blink/eyelid dysfunction
* Vitamin A supplements
* Omega 3 supplements
Floaters
This is a very common condition that usually occurs naturally with age.
How eye floaters appear
They are dark or translucent looking, and will move together with your eye. If you try to look at them directly, they will eventually disappear off to the side. Floaters tend to be more noticeable against bright lights or white wall, and take on different shapes, such as:
* Black spots
* Cobwebs
* Flies or mosquitoes
* Squiggly lines
What is a floater
The inside of the eye is normally filled with a jelly-like substance known as the vitreous humour. Normal age-related changes can cause the proteins within the vitreous humour to clump together, which we see as floaters.
Causes of floaters
* Posterior vitreous detachment (PVD)
* Retinal holes or tears: can arise from a PVD, trauma or peripheral retinal thinning in those with high myopia
* Retinal detachment
* Posterior uveitis
* Retinal bleeding
* Trauma: such as a blow to the head, whiplash
Treatments for floaters
Floaters that have been noticeable for more than 6 weeks
Can be monitored by yourself and your optometrist at routine intervals, if there aren’t any other associated symptoms.If you notice a black spot that seems fixed in your vision for any period of time, you should see your optometrist promptly.
Floaters that have been noticeable for less than 6 weeks
You must see your optometrist or ophthalmologist urgently due to the possibility of a retinal detachment, particularly if you notice the following associated symptoms as well:
* New floaters
* More floaters than usual
* Flashing lights
* Black curtains/shadows in your vision
Glaucoma
According to Glaucoma Australia, 2 in 100 Australians will develop glaucoma in their lifetime. Glaucoma causes a loss of peripheral vision (visual field loss) through damage to the optic nerve, resulting from issues with the eye’s intraocular fluid drainage system.
Symptoms of glaucoma
* In most cases, there are usually no symptoms at all
* In advanced, severe glaucoma, tunnel vision results in misjudging or missing objects off to the side as well as mobility issues
* In acute angle closure glaucoma, symptoms include pain, red eyes, headaches, blurry vision, halos around lights, nausea
Types of glaucoma
* Open angle glaucoma: is most commonly seen and makes up 90% of cases. It is usually slowly progressive, caused by a blockage in the eye’s intraocular fluid drainage system resulting in elevated eye pressure
* Acute angle closure glaucoma: a sudden narrowing of the eye’s intraocular fluid drainage system causes a build-up of eye pressure. It needs urgent treatment as there is a high risk of vision loss
* Normal tension glaucoma: eye pressure is normal, but optic nerve damage is still observed
* Congenital glaucoma: is rare, present at birth and early childhood, and due to the incomplete development of eye’s intraocular fluid drainage system. It is often associated with other medical conditions
* Traumatic glaucoma
* Secondary glaucoma
* Pseudoexfoliative
* Pigmentary
* Irido-corneal endothelial syndrome
* Uveitic glaucoma
Risk factors
* Older age
* Family history of glaucoma, especially siblings
* Thin corneas
* Corticosteroid medication
* Ethnicity
* Diabetes
Have regular eye tests
It’s thought that 50% of people with glaucoma don’t know that they have it, so having regular eye examinations is important for early detection. Your optometrist can perform these following tests to assess for glaucoma:
* Eye pressure test
* Eye health check, including an assessment of your optic nerve
* Visual field test
If your optometrist suspects that you have glaucoma, you will be referred to an ophthalmologist for treatment
Treatment options for glaucoma
* Anti-glaucoma medication
* Laser treatment
* Surgery
Hay fever
Allergies are becoming increasingly common, and 1/5 people will experience hay fever at some point.It’s no surprise that it usually peaks in spring, triggered by the large amount of pollen released in the air. Hay fever normally causes nasal issues such as a runny nose, coughing or sneezing, but can affect your eyes as well.
Hay fever allergy symptoms in the eyes:
* Itchy/irritated/gritty eyes
* Red eyes
* Watery eyes
* Stringy discharge
* Blurry vision
Signs of hay fever:
Your optometrist can check underneath your eyelids for hay fever by looking for bumps called papillae.
Hay fever treatment for your eyes:
* Avoiding the trigger as much as possible, wearing sunglasses, eye protection or goggles outside
* Hay fever eye drops
* Hay fever tablets
* Steroid eye drops
Hyperopia (long sight)
When you have hyperopia, objects far away at distance are clear, but you have to focus harder to see clearly at near.
* Images entering the eye are focused behind the retina rather than on it
* Not to be confused with presbyopia, which is an age related change in your near vision
Causes of hyperopia
* Can be hereditary
* Many infants are born with it, but it self-corrects in early childhood so that they don’t end up with vision problems
Managing hyperopia
If you suspect that you, or your child has hyperopia, see your optometrist to discuss the most suitable option to correct it, including:
* Glasses
* Contact lenses
* Laser eye surgery
In some children, uncorrected hyperopia can lead to learning difficulties, and may not be detected at a school vision screening, so it’s a good idea to have your child’s eyes checked before they start school.
Macular degeneration (AMD)
Age-related macular degeneration (AMD) is the leading cause of severe vision impairment in people over 40 years old in Australia.It causes a painless loss of central vision affecting the macula, which is the part of the eye that we use when we look straight ahead to focus on something.
There are 2 types:
* Dry AMD: this is the more common variant, where there is a loss of retinal cells at the macula due to damage in the underlying layer. It tends to progress slowly
* Wet AMD: Dry AMD can become Wet AMD all of a sudden, leading to significant vision loss. It occurs due to the leakage of fluid in new blood vessels growing in the underlying layer.
Symptoms of AMD
* Gradual blurring of vision
* Difficulty seeing things centrally
* Distortion of straight lines
* Difficulty reading, writing and looking at detailed objects
* Trouble recognising faces
* Fading of colours
* Difficulty judging distances
* Hallucinations in late stage, advanced AMD due to significant vision loss
Risk factors
* Older age
* Smoking
* Family history of AMD
* Obesity
Prevention
* Eating a healthy, well balanced diet containing fruits and vegetable of all different colours, especially leafy greens and omega 3 fats
* Wearing sunglasses
* Avoiding smoking
* Regular exercise
Managing AMD
See your optometrist for regular follow ups to check for any changes or new symptoms.
* Eating a healthy, well balanced diet containing fruits and vegetable of all different colours, especially leafy greens and omega 3 fats
* Dry AMD: there is currently no treatment for this. Antioxidant supplements can help support certain variants of dry AMD.
* Amsler grid: This is a macular degeneration test, used to monitor for progression to wet AMD that you can take home and self-administer
* Wet AMD: urgent injections are needed to slow the vision loss
* For those with significant vision loss with either form of AMD, low vision aids and the use of good lighting are helpful
Myopia (short sight)
It’s estimated that by 2050, 50% of the world’s population will have myopia. Since so many people are developing myopia, there is currently a lot of ongoing research to help us understand it better.
What is myopia?
* Images entering the eye are focused in front of the retina, rather than on the retina
* Objects far away are blurry, near vision is clear
Myopia treatment
See your optometrist to discuss the following management options:
* Prescription glasses
* Contact lenses
* Laser eye surgery
Health conditions associated with myopia
* There is a higher risk of cataract, glaucoma and macular degeneration in people with high myopia
* Uncontrolled diabetes and cataracts can cause myopic shifts in your prescription
Myopia in children
Research has shown that there is a greater likelihood of developing of myopia in children who:
* Spend long periods of time working on computers, reading, or doing intense close work
* Lack exposure to natural sunlight
* Do not spend much time outdoors
* Have relatives with myopia
Treatment options to slow the progression of myopia in children include using orthokeratology (wearing hard contact lenses to sleep) and atropine eye drops. Have a chat with your optometrist about these options.
Ocular hypertension
People with ocular hypertension have eye pressure that is higher than normal (&gt;21mmHg), but do not show any other signs of glaucoma, such as visual field loss or optic nerve damage. They would be considered as having a higher risk of developing glaucoma in the future, and are monitored regularly.
Ocular hypertension symptoms
There are no symptoms, so having an eye pressure test when you see your optometrist is the only way to find out. The normal range of eye pressure is 10-21mmHg.
Risk factors for ocular hypertension
* Older age
* Family history of glaucoma
* Ethnicity
* Myopia
* Steroid medication
* Diabetes
Treatment
In most cases, no treatment is required. Regular monitoring of your eye pressure and optic nerve appearance, as well as visual field testing, is adequate.If your ocular hypertension is assessed as being of high risk into developing glaucoma, your ophthalmologist may prescribe anti-glaucoma treatment as a preventative measure. This includes eye drops or laser treatment.
Ocular migraine
Did you know that some migraines can affect the eyes only, and don’t cause headaches?Ocular migraines begin with changes to vision, and may or may not cause a headache afterwards. They normally last for up to 20 minutes.They’re also known as:
* Visual migraine
* Optical migraine
* Eye migraine
Symptoms you will see during an ocular migraine episode
* Patterns in your vision
* Flashing lights
* Zig zag lines
* Stars in the eyes
* Blind spots
Ocular migraine causes
* Some people have triggers – eye strain can be one of them
* Hormone changes
* Dietary issues
.....and many more, so it’s best to see your GP.
Treatment
* Usually no treatment is required as it is painless, and resolves by itself after 20 minutes. It’s best to stop what you’re doing and rest somewhere dark until it has passed.
* If you have a headache afterwards, you may need painkillers or medication, but it’s best to discuss this first with your GP.
* See if there are any eye-related triggers by having an eye test with your optometrist
Presbyopia
Are you finding that reading up close is getting more difficult? You’re holding things further away to read, making the text size larger on your phone and computer screen, squinting and straining to see small print, getting headaches or tired eyes? These are some of the most common symptoms that we hear from people who have presbyopia.
What is presbyopia?
* It’s a really common condition, and usually begins over the age of 40.
* As part of ageing process, the lens inside the eye becomes more rigid, so becomes less able to focus clearly at near.
How can it be corrected?
Speak to your optometrist to see which of the following options are most suitable for you:
* Wearing prescription reading, multifocal or bifocal glasses
* For some people, contact lenses or laser eye surgery can also help
Red eye
We’ve all experienced red eyes before, and tried to figure out how they came about. Red eyes occur when the tiny blood vessels on the white part of the eye dilate, making the eye look more red than usual.
There are many causes of red eyes, and we’ve listed them here for you.
* Dry eyes
* Eye injury/scratch
* Corneal ulcer
* Eye surgery complications
* Contact lens related red eye: infection or inflammation
* Exposure to triggers such as perfume, cigarette smoke, dust, pet fur, makeup, chemicals such as chlorine, hayfever
* Inflammatory conditions: keratitis, iritis/uveitis, episcleritis, scleritis
Acute angle closure glaucoma
A sudden buildup of eye pressure within the eye can cause painful, red eyes that require urgent treatment by an ophthalmologist (see section on Glaucoma).
Subconjunctival haemorrhage
This causes a painless bloodshot eye, caused by bleeding from a burst blood vessel, which usually resolves by itself within 1-2 weeks. Often there is no obvious cause, but it can happen due to eye rubbing, intense vomiting, coughing, sneezing and weight lifting.
Treatment for red eyes
It’s best to see your optometrist to diagnose the cause of the red eye, and they will also recommend the best way to manage it. This may include:
* Eye drops: lubricating, antibiotic, antiviral, steroid, allergy
* Avoiding allergy triggers
* Adjusting contact lens wearing habits
* Dry eye treatment
* Seeing an ophthalmologist about eye surgery complications
Retinal detachment
This is a serious condition that optometrists consider as an emergency due to the high risk of vision loss. It requires immediate assessment and treatment by a retinal surgeon. Retinal detachment treatment involves surgery. The sooner it is treated, the better the chance of recovery.
What is a retinal detachment?
The retina is a light sensitive layer attached to the back surface of the eye. We rely on the retina in our eyes to see. In some people, it pulls away, or detaches, from the back surface.
Causes of a retinal detachment
* Retinal tear
* Retinal holes
* Eye trauma
* Fluid buildup behind the retina
Risk factors
* Older age
* High myopia
* Previous eye surgery
* Previous history of retinal disease
* Family history of retinal detachment
Retinal detachment symptoms
If you see any of the following symptoms, please notify your optometrist or ophthalmologist immediately:
* Painless
* Floaters: the sudden appearance of many black spots in your vision
* Flashing lights
* Black curtain/shadows in your vision
* Blurry side vision/peripheral vision
* Blurry or distorted vision
Is it a retinal or posterior vitreous detachment (PVD)?
A posterior vitreous detachment presents with similar symptoms to a retinal detachment, however, it usually does not require treatment, just monitoring.
* Posterior vitreous detachment is a common condition that is part of the ageing process, more likely in people over 50 years old.
* The vitreous humour, a jelly-like substance that fills the inside of the eye, shrinks and pulls away from the retina.
* In most cases it pulls away without disturbing the retina, but sometimes it can cause a retinal tear or detachment, so it is best to have your eyes tested immediately just in case.
Stye (external hordeolum)
We’ll refer to an external hordeolum as a stye in this section.
There are 2 types of eye styes:
* Internal hordeolum (chalazion): see section on Chalazion
* External hordeolum (stye): occur due to an infection of the eyelash follicle on the outside of the eyelid and eventually appears resemble a pimple when it develops a white tip
A stye on the eye is a painful red lump that appears on the upper or lower eyelids – otherwise known as a pimple on the eyelid.
What causes a stye on the eye?
An infection by Staphylococcus Aureus bacteria causes anterior blepharitis, which then leads to the formation of an external hordeolum.
Avoid squeezing a stye
Although this is very tempting, especially after the white tip appears, it could lead to an infection of the entire eyelid – a serious condition called preseptal cellulitis.
Stye treatment
An external hordeolum usually resolves by itself, not long after the white tip appears on the lump. It may take approximately 1 month. They normally don’t require any treatment, but if they are affecting vision or not improving, your optometrist or doctor may recommend:
* Antibiotic ointment
* Steroid cream
* Surgery
How to prevent a stye
* Wash your hands before touching your eyes
* Wash your face regularly, including the eye area
* Eyelid scrubs
* Ensure that your skincare products and cosmetics aren’t making it worse
Watering eyes
Wondering why your eyes are watery? Are you finding yourself blotting at constantly watering eyes, which give you a glassy look and blurry vision?There are plenty of options to manage watery eyes, so it’s best to book in for an appointment with your optometrist to discuss the best steps to take.
What are the causes of watery eyes?
* Excessive tear production from having dry eyes (to compensate for dryness), a foreign body, inflammation of the eye surface, ingrown eyelashes (trichiasis), allergies, conjunctivitis or inadequate blinking
* Poor tear drainage rom blocked, narrow or poorly positioned tear ducts
* Poorly positioned tear ducts due to injury or a loose lower eyelid
* Blocked tear ducts are commonly seen in infants and young children
What are the causes of watery eyes?
* Excessive tear production - Try tear supplement eye drops, eyelid scrubs, warm compresses with a gentle massage to unclog the blocked oil gland, antibiotics, steroid drops, allergy eye drops, allergy tablets, IPL treatment or Blephasteam
* Poor tear drainage - Many cases can be managed with a lacrimal lavage, which is a procedure to unclog the tear duct
* Surgery - May be necessary for any poorly positioned eyelids or tear ducts, as well as blocked tear ducts.
Author: Jessica Foong (Optometrist)
Due for an eye test? Book now:
[Eye test near me](https://www.oscarwylee.com.au/booking)
We recommend that everyone should have an eye test with an optometrist at least once every 2 years.
Oscar Wylee offers bulk billed eye test, so there are no out-of-pocket expenses for eligible Medicare card holders.