# Source: https://www.oscarwylee.com.au/glasses/silhouette/rectangle.html

37 Products        
Showing 15 of 37
1. [](https://www.oscarwylee.com.au/logan-optical.html)
[Logan](https://www.oscarwylee.com.au/logan-optical.html)
$199    
[2 pairs from $249](https://www.oscarwylee.com.au/logan-optical.html)
2. [](https://www.oscarwylee.com.au/miles-optical.html)
[Miles](https://www.oscarwylee.com.au/miles-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/miles-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/miles-optical.html)
3. [](https://www.oscarwylee.com.au/hugh-optical.html)
[Hugh](https://www.oscarwylee.com.au/hugh-optical.html)
$199    
[2 pairs from $249](https://www.oscarwylee.com.au/hugh-optical.html)
4. [](https://www.oscarwylee.com.au/toby-optical.html)
[Toby](https://www.oscarwylee.com.au/toby-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/toby-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/toby-optical.html)
5. [](https://www.oscarwylee.com.au/windsor-optical.html)
[Windsor](https://www.oscarwylee.com.au/windsor-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/windsor-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/windsor-optical.html)
6. [](https://www.oscarwylee.com.au/francis-optical.html)
[Francis](https://www.oscarwylee.com.au/francis-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/francis-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/francis-optical.html)
7. [](https://www.oscarwylee.com.au/crane-optical.html)
[Crane](https://www.oscarwylee.com.au/crane-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/crane-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/crane-optical.html)
8. [](https://www.oscarwylee.com.au/brosque-optical.html)
[Brosque](https://www.oscarwylee.com.au/brosque-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/brosque-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/brosque-optical.html)
9. [](https://www.oscarwylee.com.au/cape-optical.html)
[Cape](https://www.oscarwylee.com.au/cape-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/cape-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/cape-optical.html)
10. [](https://www.oscarwylee.com.au/cliff-optical.html)
[Cliff](https://www.oscarwylee.com.au/cliff-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/cliff-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/cliff-optical.html)
11. [](https://www.oscarwylee.com.au/gibbs-optical.html)
[Gibbs](https://www.oscarwylee.com.au/gibbs-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/gibbs-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/gibbs-optical.html)
12. [](https://www.oscarwylee.com.au/wilder-optical.html)
[Wilder](https://www.oscarwylee.com.au/wilder-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/wilder-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/wilder-optical.html)
13. [](https://www.oscarwylee.com.au/andrew-optical.html)
[Andrew](https://www.oscarwylee.com.au/andrew-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/andrew-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/andrew-optical.html)
14. [](https://www.oscarwylee.com.au/bishop-optical.html)
[Bishop](https://www.oscarwylee.com.au/bishop-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/bishop-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/bishop-optical.html)
15. [](https://www.oscarwylee.com.au/julie-optical.html)
[Julie](https://www.oscarwylee.com.au/julie-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/julie-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/julie-optical.html)
37 Products        
Showing 15 of 37
Choosing Rectangle Glasses Suitability FAQs Pricing and Shipping 
## How to Choose the Best Rectangle Glasses for Women?
The way to choose the best rectangle glasses for women involves considering your face shape, assessing frame size, and thinking about personal style. The [best glasses for women](https://www.oscarwylee.com.au/glasses/best-women) will include frames that align with one’s individual preferences, usual style and visual needs. The ways to choose the best rectangle glasses for women are listed below.
* Consider face shape: Considering face shape is the first step in choosing the best rectangle glasses for women. There are certain face shapes that will work best with rectangle glasses. Faces that are more curved, such as round, oval and pear, will work best for rectangle glasses, as they help to bring angles and structure to the face.
* Assess frame size: Assessing frame size is an important step in choosing the best rectangle glasses for women. If a person chooses a frame that is too big or too small for their face, it may end up looking disproportionate on the face.
* Consider personal style: Consider personal style when choosing the best rectangle glasses for women. Colour, size and frame materials can all impact the styling of a frame and should be considered.


## How to Choose the Best Rectangle Glasses for Men?
The way to choose the best rectangle glasses for men involves considering your face shape, assessing frame size, and thinking about personal style. The [best glasses for men](https://www.oscarwylee.com.au/glasses/best-men-eyeglasses-for-every-face-shape) will vary between individuals; however, they will ultimately depend on personal preference, lifestyle and vision requirements. The ways to choose the best rectangle glasses for men are listed below.
* Consider face shape: Considering face shape first is important when choosing the best rectangle glasses for men. It is important to opt for frames that complement your facial features. Those with round faces may find rectangle or square glasses visually pleasing due to the contrast of the frame’s sharper and stronger angles paired with the softer features of a round face. Some frame shapes are more suited to certain face shapes than others; however, a helpful key is creating a visual contrast.
* Assess frame size: Assessing frame size can be helpful when choosing an ideal pair of rectangle glasses for men. To ensure a proper fit, check that your frames don’t extend too much past the widest portion of your face or feel like they’re tight around your head or like they’re pinching your nose.
* Consider personal style: Consider personal style when choosing your rectangle glasses by opting for the colours or colour palettes that either match or complement your usual outfits.


### How to Choose Rectangle Glasses According to Skin Tone?
To choose rectangle glasses according to skin tone, determine your skin undertone, and finally choose your frames to align with this. Determine your undertone by checking the colour of the veins on your inner wrist/forearm. If they look blue or purple, you may have cool undertones and fair skin; if they look green, you may have warm undertones and darker skin. However, if you have a mix of blue and green, you may be considered neutral-toned. Choose rectangle glasses that are complementary to your skin tone. For those with warm undertones, opt for similarly warm colours such as gold and bronze. Those with cool undertones may want to go for blues, silver or green rectangle glasses. Neutral-toned skin can opt for a variety of colours due to the balance of cool and warm skin tone.
### How to Choose Rectangle Glasses According to Face Shape?
To choose the best rectangle glasses according to face shape, it can be helpful to first assess your facial features and proportions to identify your face shape. Face shapes typically include round face shapes, pear face shapes, oval face shapes, heart face shapes and square face shapes. While there are often general recommendations for the [best glasses for different face shapes](https://www.oscarwylee.com.au/glasses/face-shapes), it will ultimately come down to what glasses make you feel your best. The ways to choose the best rectangle glasses according to face shape are listed below.
* Round face shapes: Round face shapes are characterised by their circular shape and typically harmonious dimensions. Square, rectangle and geometric glasses are suitable for [round face shapes](https://www.oscarwylee.com.au/glasses/face-shapes/round) as they help balance out the softer features and add stronger angles.
* Pear face shapes: Pear face shapes generally feature a narrower forehead along with a wider and rounded jawline, and fuller cheeks. Rectangle, cat eye and oval glasses are suitable for [pear shape faces](https://www.oscarwylee.com.au/glasses/face-shapes/pear) as they can help balance out the narrow forehead and wider jawline.
* Oval face shapes: Oval face shapes are characterised by a longer length face and overall well-balanced or equal facial features with a soft and/or rounded chin and jawline. Round, rectangle, square, aviator and cat eye glasses are suitable for [oval face shapes](https://www.oscarwylee.com.au/glasses/face-shapes/oval) as they have a harmonious facial structure.
* Heart face shapes: [Heart face shapes](https://www.oscarwylee.com.au/glasses/face-shapes/heart) are described as having a wider forehead and a smaller chin. Cat eye, round and square glasses help to balance out a wider forehead.
* Square face shapes: Square face shapes are defined by their prominent jawline, which is often equal in width to their forehead. Browline, round, square, aviator and cat eye glasses are suitable for square faces to help create a visual contrast between the angular features of a [square face](https://www.oscarwylee.com.au/glasses/face-shapes/square#Glasses) shape and the soft curves of these frames.
#### Are Rectangle Glasses Good for Prescription Use?
Yes, rectangle glasses are good for prescription use. Prescription rectangle glasses can help provide wearers with a stylish and classic accessory that provides clear vision. Here at Oscar Wylee, you can shop our wide range of rectangle glasses for prescription frames online or in-store.
#### Are Rectangle Glasses Suitable for Seniors?
Yes, rectangle glasses can be suitable for seniors. Rectangle glasses are a classic go-to frame for many, as they can easily be paired with a range of outfit styles and aesthetics. Rectangle glasses offer sleek lines and a timeless appeal.
## How to Choose Rectangle Glasses According to Bridge Width?
The way to buy rectangle glasses according to bridge width is to try on different frames and assess the [types of nose bridge](https://www.oscarwylee.com.au/glasses/nose-bridge-types) widths that will suit you. Exact width and fit will vary between different optical retailers, but generally, glasses widths are narrow, medium and wide. The ways to buy rectangular glasses according to bridge width are below.
* Narrow Glasses: Narrow glasses are well-suited to those with thinner or more petite faces. Kids and teenagers may also be well suited for more narrow rectangular sunglasses.
* Medium Glasses: Medium glasses are a good choice for those with more average-sized faces.
* Wide Glasses: Wide glasses are made to suit those with larger or more wide faces.
### Which Frame Colour Pattern Looks Best on Rectangle Glasses?
The frame colour pattern that may look best on rectangle glasses includes matte, solid, striped, tortoise, transparent and two-tone. The frame colour patterns that may look best on rectangle glasses are listed below.
* Matte Rectangle Glasses: A matte colour pattern for rectangle glasses refers to a low-gloss, flat-looking finish for a sleek, good-looking frame.
* Solid Rectangle Glasses:  A solid colour pattern for rectangle glasses provides wearers with a monochromatic look that’s easy to incorporate with their personal style.
* Tortoise Rectangle Glasses: Tortoise patterns offer a blend of often warm tones and are an effortlessly stylish accessory perfect for the classic sunglass.
* Transparent Rectangle Glasses:  Transparent or clear rectangle glasses offer a modern, trendy twist on a classic frame shape.
### Who Looks Best in Small Rectangle Glasses
Those with round, oval or pear shaped faces may look best in small rectangle glasses due to the straight lines of the frame adding more structure and visual balance. However, other individuals may find small rectangle glasses appealing, depending on personal preferences. You can try on small rectangle glasses on in-store at Oscar Wylee to see whether you like them or not. Opting for complimentary colours and the right size can influence the overall look. The small size of small rectangle frames may vary between different optical retailers, so you may find a pair well suited to your personal features and proportions.
#### Are Oversized Rectangle Glasses Suitable for Everyday Wear?
Oversized rectangle glasses are suitable for everyday wear. Oversized rectangle glasses help provide more cover over your face, which can help increase protection from the sun’s UV light. They are stylish, comfortable and can enhance any outfit, making them an ideal frame to wear every day. You can shop our wide selection of [oversized glasses](https://www.oscarwylee.com.au/glasses/silhouette/oversized.html)online or in-store
#### Are Classic Prescription Sunglasses a Good Option for Teenagers?
Yes, classic prescription sunglasses can be a good option for teenagers as they can help provide both clear vision and sun protection. Prescription sunglasses can be a popular choice among teenagers as they are more likely to spend longer and more frequent hours outdoors, in the sun. At Oscar Wylee, we have a wide range of sunglasses that you can add your prescription to for an additional price on top of your standard sunglass frames.
### Why are Rectangle Glasses Popular for Everyday Wear?
Rectangle glasses can be popular for everyday wear with their classic and timeless frame design. Rectangle glasses are an optimal option to pair with different outfit styles to either complete your look or stand as a statement piece. Rectangle glasses at Oscar Wylee are designed for all-day comfort and elevated style.
### Why are Rectangle Glasses a Top Pick for Modern Professionals?
Rectangle glasses may be a top pick for modern professionals because they are a perfect blend of clean design and a sharp, structured look. Rectangle glasses are a suitable style for [professional glasses](https://www.oscarwylee.com.au/glasses/professional-eyewear) as they complement work attire easily.
### What Factors Affect the Price of Rectangle Glasses?
The price of rectangle glasses will vary depending on the retailer and is generally affected by factors such as add-ons and lens type. At Oscar Wylee, one pair of rectangle glasses in our core range starts from $169, 2 pairs from $199 and 3 pairs from $249, excluding add-ons or high index lenses. Read our full [price guide](https://www.oscarwylee.com.au/price-guide/) for more information
### How to Adjust Rectangle Glasses for a Comfortable Fit?
You can adjust rectangle glasses for a comfortable fit by bringing them to the optometrist  to have them handled professionally. It is always recommended to have any repairs or adjustments done at your optical retailer, as attempting alterations yourself may result in further damage.
#### Are Transition Lenses Available in the Rectangle Glasses Collection?
Yes, transition lenses are available in rectangle glasses. Opt for either Adaptive Lenses, Oscar Wylee’s own brand, or Transitions® GEN S™ lenses to add onto your rectangle glasses for an additional price on top of your chosen glasses. Photochromic lenses are also known as transition lenses due to their function, as they “transition” from clear to dark and are suitable for those who need both the vision correction of prescription glasses and the UV protection of sunglasses without needing to change frames.
#### Are Classic Black Glasses Ideal for All Seasons?
Yes, classic black glasses can be ideal for seasons. Classic black glasses, such as black rencntagle glasses are an easy way to elevate one’s style as they can complement and complete any outfit. Whether you're layering up for colder months or staying casual and minimal for warmer months, classic black glasses are a great go-to frame as they are suitable for all skin tones depending on your preferences and personal taste.
#### Are Narrow Rectangle Glasses Better for Reading or Distance?
Yes, narrow rectangle glasses  can be better for reading than distance and if you don’t require a wider field of vision. Narrow rectangle glasses can provide clear vision for tasks that require close vision, such as reading, however, they may cut off your distance vision. You can check with your optometrist to check if narrow rectangle glasses will be suitable for your vision requirements.
#### Are Rectangle Frame Glasses Suitable for High Prescriptions?
Yes, rectangle frame glasses can be suitable for high prescriptions, however, you will need to consult with your optometrist to get a professional recommendation on the best frames. Generally, rectangle frame glasses are suitable for any type of prescription and may just depend on your preferences and what makes you feel comfortable.
#### Do Rectangle Eyeglasses Make Your Face Look Slimmer?
No, rectangle eyeglasses may not make your face look slimmer. However, this can potentially depend on your face shape and the width of your frame. In some cases, wearing a wider frame can make your face appear more narrow but this varies between individuals and frame styles.
## What Lens Types Work Best for Rectangle Glasses?
The lens types that can work best for rectangle glasses will come down to your personal vision requirements and your particular preferences for eyewear. It may be best to speak to an optometrist to get professional advice on which lens type will be more suitable for your rectangle glasses and your personal needs for vision, preferences and lifestyle.
### What Outfits Work Best with Stylish Rectangle Glasses?
The outfits that work best with stylish rectangle glasses can include a wide range, such as casual, formal, work and for special occasions. Rectangle glasses are a classic and timeless style of frames that can be easily worn with your regular t-shirt, jeans and sneakers, or a button shirt paired with tailored pants. Wear them to the office or on nights out, rectangle glasses are a great way to complete your look.
### How Long Does It Take to Get Prescription Rectangle Glasses?
It can take within 7-10 business days from the date of purchase when collecting in-store to get prescription rectangle glasses. A team member will contact you once your glasses have passed through all the quality control checks and are ready for collection. If your rectangle glasses are being shipped to your home, it may take up to 2 weeks to arrive. This includes the production time of 7-10 business days and additional time for shipping.
### What is the Return or Refund Policy for Rectangle Glasses?
The return or refund policy for rectangle glasses will depend on whether they are prescription or non-prescription and/or the type of prescription. Since each pair of glasses is customised based on your prescription, Oscar Wylee does not offer any exchange or refund for change of mind on prescription items. For non-prescription over the counter items, we can offer exchanges within 14 days from receiving grants if they are still in satisfactory condition. Oscar Wylee offers a 1 year warranty from the date of delivery covering manufacturing faults or defects in frames and lenses, with free repair or replacement during this period. We also provide repair or replacement for vision-related issues experienced during everyday use within 30 days of delivery. If a product has been discontinued, an exchange for a similar item or a refund may be offered. This warranty operates in addition to your rights under Australian Consumer Law.
### How are High-Quality Rectangle Glasses Manufactured?
Our high quality rectangle frames are manufactured through a careful blend of quality materials, precision engineering, and skilled assembly. Acetate frames start with bio-based cellulose acetate derived from natural fibres, cut to create both solid and uniquely patterned designs. The front of each acetate frame is then milled from a single block and shaped, polished, and refined through multiple hand-finished steps. Metal frames start as fine wire that’s formed, welded, and assembled piece by piece for strength and durability. After shaping, all frames undergo extensive polishing and tumbling for a smooth, comfortable finish. Hinges, rivets, and temples are fitted by hand, lenses are individually cut to match each frame, and every pair is thoroughly inspected to ensure it meets our quality standards before it reaches you.
What Factors Affect the Price of New Arrival Glasses?
The factors that affect the price of new arrival glasses at
Oscar Wylee can differ based on elements such as the glasses
range, add-ons and lens types.
One pair of glasses starts from our range price of $169, 2
pairs from $199 and 3 pairs from $249. It should be noted that prescription lens thickness and other
add-ons will affect overall pricing. See our full
price guide
for more
How Long Does It Take to Get New Arrival Prescription Glasses?
New arrival prescription glasses
may take 7–10 business days to arrive at your chosen Oscar
Wylee store for pick-up.
For home deliveries, please allow up to 2 weeks. You’ll
receive a confirmation email with your order details and a
tracking link once your order has been placed.

[Prescription Glasses](https://www.oscarwylee.com.au/glasses.html)
[Women’s Glasses](https://www.oscarwylee.com.au/glasses/collection/womens-glasses.html)
[Men’s Glasses](https://www.oscarwylee.com.au/glasses/collection/mens-glasses.html)
[Senior Glasses](https://www.oscarwylee.com.au/glasses/collection/seniors.html)
[Glasses for Kids](https://www.oscarwylee.com.au/glasses/collection/kids-collection.html)