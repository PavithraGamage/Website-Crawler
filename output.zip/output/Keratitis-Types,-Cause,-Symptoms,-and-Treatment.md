# Source: https://www.oscarwylee.com.au/glasses/eye/keratitis

# Keratitis: Types, Cause, Symptoms, and Treatment
Published on December 3rd, 2024
Updated on February 21st, 2024 
Australia
[Australia](https://www.oscarwylee.com.au/glasses/eye/keratitis)
[Canada](https://oscarwylee.ca/glasses/eye/keratitis)
[Canadian French](https://oscarwylee.ca/fr/glasses/eye/keratitis)
Keratitis also known as a corneal infection or corneal inflammation is
defined as inflammation in the cornea caused by an infection by bacteria
or viruses or injury to the eye. Keratitis symptoms can include pain,
redness, excessive tears, blurry vision and light sensitivity and can
either be infectious or non-infectious. Treatment may involve prescribed
artificial tear eye drops that may be used for minor non-infectious cases
while severe cases may require anti-inflammatory eye drops as prescribed
by an optometrist. Mild cases of infectious keratitis may be treated with
antibacterial, antifungal or antiviral eye drops prescribed by the
optometrist depending on the cause of symptoms. Severe cases may require
the intervention of oral medication according to the American Optometric
Association.
Prioritise Your Eye Health at Oscar Wylee
Let us help you with your eye health by booking an eye test with our team.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Definition](#Definition) [Types](#Types)
[Symptoms](#Symptoms) [Causes](#Causes)
## What is Keratitis?
Keratitis also referred to as a corneal infection or corneal inflammation is caused by an infection or an
injury to the eye and can involve ciliary congestion, swelling in the
cornea and the entrance of inflammatory cells. Infectious keratitis can be caused by fungal keratitis, bacterial
keratitis, parasitic keratitis and viral keratitis. Causes of
non-infectious keratitis can include injuries to the eye, ill-fitting
contact lenses, and having a foreign body stuck in the eye.
### What Part of the Eye Does Keratitis Affect?
The part of the eye that keratitis affects is the cornea, which is located at the front of the eye. The cornea is a clear, dome-shaped outer layer of the eye and is
located in front of the iris and pupil. Keratitis refers to the
inflammation and irritation of the cornea.
#### Does Keratitis Affect Both Eyes?
Yes and no, keratitis can affect both eyes in some cases,
however, keratitis normally affects just one eye.
#### Are Keratitis and Corneal Ulcers the Same?
No, keratitis and corneal ulcers are not the same, however, they may be closely linked.
Keratitis refers to corneal inflammation that can either be infectious
or non-infectious. A corneal ulcer is defined as an open sore on the
outer layer of the cornea that can stem from an infection.&nbsp;
However, keratitis can occur without leading to corneal ulcers
according to the American Academy of Ophthalmology.
## What are the Types of Keratitis?
The types of keratitis are infectious keratitis and noninfectious keratitis. The most common form of infectious keratitis may be microbial keratitis
which is usually caused by bacteria, viruses, fungi or parasites. The most
common form of noninfectious keratitis is typically caused by injuries
from cuts and abrasions to the eye. The symptoms for both infectious
keratitis and noninfectious keratitis can be similar, therefore, it is
important to see an optometrist or your local doctor if you are
experiencing pain, redness, excessive tears, light sensitivity, sensation
of foreign body in the eye, blurred or reduced vision. The types of
keratitis are listed below.
### Infectious Keratitis
Infectious keratitis refers to the infection of the cornea as a result of bacteria or a virus
contaminating the eye. Causes of infectious keratitis may include extended use or improper
care of contact lenses, eye injuries, eye diseases and a poor immune
system. According to Prevent Blindness, bacterial keratitis is the most
common type and can typically occur in people who use contact lenses.
Improper storage or not cleaning contact lenses or contact lens cases
can increase the risk of bacteria growing on their surfaces. Treating
infectious keratitis may require antibiotic eye drops or antiviral eye
drops as prescribed by an optometrist. Infectious keratitis may lead to
complications when left untreated including vision impairment and
corneal blindness according to the American Academy of Ophthalmology.
Therefore, it is important to have your eyes examined by an optometrist
for an accurate diagnosis and suitable treatment plan.
### Noninfectious Keratitis
Noninfectious keratitis is
inflammation in the cornea which can be caused by injuries in the eye,
dry eyes, foreign bodies in the eye and extended use of contact
lenses. Noninfectious keratitis can stem from scratches or scrapes to the
cornea from rubbing your eyes and chemical or thermal burns. Dry eyes
are another common cause that can lead to noninfectious keratitis due to
the lack of moisture protecting the eyes. Corneal inflammation may
develop as the Inflammatory cells proceed to the eyes to help the body
to eliminate the cause of irritation or injury. Noninfectious keratitis
may also progress to bacterial keratitis when corneal injuries are
prolonged without treatment. Therefore, you should seek medical
assistance right away to prevent further complications.
## What are the Symptoms of Keratitis?
The symptoms of keratitis are red eye, eye pain, watery eyes, blurry vision, poor or decreased vision,
photophobia and sensation of something in the eye. The symptoms of keratitis are listed below.
* Red Eye: Red eye can occur as a symptom of
keratitis when an infection or inflammation occurs due to the swollen
vessels beneath the surface of the sclera.
* Eye pain: Eye pain may develop during keratitis as one of the many accompanying
symptoms of inflammation.
* Watery Eyes: Watery eyes can occur as part of the body’s way to
eliminate the cause of injury or infection.
* Blurry Vision: Blurry vision can develop as a symptom of
keratitis and can be described as sight that is not sharp or is out of
focus.
* Poor or Decreased Vision: Poor or decreased vision may occur in
severe cases of keratitis or when the condition is left untreated.
* Photophobia or Sensitivity to Light: Photophobia may be induced
by keratitis as the infection or inflammation may result in a more
sensitive eye.
* Sensation of Something in the Eye: Sensation of something in the
eye can arise during keratitis due to inflammation.
### 1. Red Eye
Red eyes can develop as a symptom of keratitis due to the small blood vessels on the surface of
the eye enlarging when experiencing irritation. A [red eye](https://www.oscarwylee.com.au/glasses/eye/red-or-bloodshot)
is a common occurrence when the eye is infected or inflamed and may
alleviate when the underlying cause is addressed. The first line of
treatment typically includes artificial tear eye drops, antibacterial
eye drops, antiviral eye drops or anti-inflammatory eye drops prescribed
by an optometrist.
### 2. Eye pain
Eye pain may be
experienced when contracting keratitis due to the swelling and
infection. Swelling is a result of fluid building up in the affected tissues which
may lead to the compression of nerves in the affected region causing
pain. In certain cases, pain from keratitis may reach an extent to which
it may even feel difficult to open your eyelids. [Eye pain](https://www.oscarwylee.com.au/glasses/eye/pain-definition)
from keratitis may be helped with eye drops, depending on the cause of
symptoms, however, you should have your eyes checked by an optometrist
to receive a professional diagnosis.
### 3. Watery Eyes
Watery eyes as a result of keratitis can develop as part of the body’s natural protective
response.
Keratitis can bring on the symptom of watery eyes as a way to remove the
cause of infection or inflammation from the eye by producing more tears.
This helps to wash and flush the eyes, removing debris and irritants and
maintaining an adequate amount of moisture. The optometrist may
prescribe eye drops according to the cause of these symptoms and the
severity of your condition.
### 4. Blurry Vision
Blurry vision may occur as a result of keratitis and can be defined as sight that is not clear or is out of focus. Blurry vision is a common symptom of many other eye conditions,
therefore, it is important to see an optometrist when experiencing any
changes to your vision such as blurry vision. If keratitis is left
untreated or the infection is severe, the risk of visual impairment or
loss of vision may increase. However, timely treatment is usually
effective for mild to moderate cases of keratitis.
### 5. Poor or Decreased Vision
Poor or decreased vision can develop when experiencing complications of keratitis such as
corneal scarring from major eye injuries or corneal ulcers from
infections.
Poor or decreased vision may occur depending on the severity of your
condition, however, this may only occur when cases are left untreated.
It is important to note that keratitis does not always lead to impaired
vision or loss of vision.
### 6. Photophobia or Sensitivity to light
Photophobia or sensitivity to light may be a common symptom of keratitis and other certain eye conditions.
The cornea is considered to be a significantly sensitive tissue
and is highly receptive to pain according to the Centre For Sight.
Therefore, when the cornea is inflamed or infected, it may lead to [photophobia or sensitivity to light](https://www.oscarwylee.com.au/glasses/eye/light-sensitivity).
### 7. Sensation of Something in the Eye
The sensation of something in the eye can occur during the occurrence of keratitis as the lining of the
cornea’s sensory fibres may be compromised. The sensation of something in the eye can be a common symptom of eye
conditions that affect the cornea due to its sensitivity when infected
or inflamed. This symptom can be relieved with artificial tear eye
drops, which can increase the moisture of the eye, providing relief and
more comfort.
## What are the Causes of Keratitis?
The causes of keratitis can include
viruses, eye injury, fungal infections, contaminated water, bacterial
infections and parasitic infections. In cases of infectious keratitis, the main causes are often viruses or
bacteria. The main causes of non-infectious keratitis are generally an
injury to the eye, dry eyes, or the extended use or misuse of contact
lenses. The causes of keratitis are listed below.
* Viruses: Viruses may be a possible cause
of keratitis and can include the herpes simplex virus, varicella-zoster
virus and adenoviruses.
* Eye Injury: An eye injury may lead to the development of corneal inflammation
as a response to injury and can also allow for bacteria or viruses
to enter, leading to an infection.
* Fungal infections: Fungal infections are considered uncommon and can come from fungi
found in plants, water and soil.
* Bacterial Infections: Bacterial infections are the most common type of infectious
keratitis and may be caused by improper care of contact lenses or by
an injury.
* Parasitic Infections: Parasitic infections such as amebic keratitis and microsporidia
keratitis are rare forms of keratitis and can come from contaminated
bodies of water.
### 1. Viruses
Viruses are a possible risk factor for developing keratitis and can involve viruses such as
the herpes simplex virus, varicella-zoster virus and adenoviruses. Virus-related keratitis may likely develop from the herpes simplex
virus. You may be more vulnerable to contracting herpes simplex
keratitis if you have poor health, are immunocompromised or take
systemic or topical steroids according to the College of Optometrists.
It is important to wash your hands regularly and avoid touching your
face and rubbing your eyes. This may help minimise the risk of
potentially transferring any viruses from surfaces to your eyes.
Treating viral keratitis may involve antiviral medication in the topical
or oral form, however, this can depend on whether the patient’s
condition is mild or severe.
### 2. Eye Injury
An eye injury can lead to noninfectious keratitis and can be caused by prolonged wear of contact lenses, rubbing your eyes,
or debris and dirt getting into the eye. [Eye injuries](https://www.oscarwylee.com.au/glasses/eye/injuries)
can be characterised as scratches or scrapes on the surface of the
cornea
and can cause the cornea to swell as part of the body’s healing
mechanism in response to injuries. Injuries to the cornea can cause a
significant amount of pain due to the many sensory nerves. It is
important to seek medical attention right away if you start to
experience pain, blurry vision, light sensitivity and a headache after
an eye injury to ensure there are no major injuries.
### 3. Fungal infections
Fungal infections from Fusarium, aspergillus and Candida
may lead to keratitis and can be a consequence of trauma to the eye,
contact lens usage and the use of corticosteroids. Fungal keratitis is more commonly caused by Fusarium. However, the
particular fungi that leads to fungal keratitis can also depend on
climate, urbanisation and temperature according to the National Library
of Medicine. Keratitis caused by fungal infections may be treated using
antifungal medication prescribed by an eye care professional.
### 4. Bacterial Infections
Bacterial infections may contribute to keratitis as they can lead to inflammation in the
cornea. Bacterial infections may involve bacteria such as Pseudomonas
aeruginosa or Staphylococcus aureus according to the Centre for Disease
and Control Prevention. Bacterial keratitis may develop in individuals
who use contact lenses and do not practise proper care and storage.
Bacteria can easily grow and accumulate on the surface of your contact
lenses and contact lens case as well as in old contact lens solutions.
Therefore, to prevent the risk of developing bacterial keratitis, it is
important to follow the specific cleaning, disinfecting and storage
procedures. Bacterial keratitis may be treated with prescribed
anti-bacterial eye drops depending on the severity of your
condition.
### 5. Parasitic Infections
Parasitic infections are another rare form of keratitis and can come from acanthamoeba, a single-cell
organism that can be found in bodies of water. Parasitic infections can result in amebic keratitis due to factors such
as improper care of contact lenses, swimming, using a hot tub or contact
with contaminated water. According to the Centre for Disease and Control
Prevention, diagnosing this type of parasitic infection may require
taking a sample of the affected cornea tissue and using a microscope for
examination. Treating parasitic infections may involve prescribing
antibiotics and certain types of eye drops according to MSD
Manual.
### Who is at Risk of Developing Keratitis?
People who use contact lenses may be more at risk of developing
keratitis. Keratitis may likely develop in those who wear contact lenses overnight
or use extended-wear contact lenses.
Bacteria can accumulate on the surface of contact lenses and contact
lens cases, which is why there is a specific procedure for cleaning,
disinfecting and storing contact lenses. The solution that comes with
your contact lenses should be used before and after each use and kept in
a fresh pour of the solution for overnight storage.
#### Does Proper Hygiene Help Lower the Risk of Keratitis?
Yes, proper hygiene does help lower the risk of keratitis, as regularly washing hands and cleaning and disinfecting your contact
lenses can assist with eliminating germs. It may also be helpful to carry sanitiser that contains at least
60% alcohol with you when leaving the house for regular and convenient
removal of germs.
### How Prevalent is Keratitis?
Keratitis can be quite prevalent depending on the form of keratitis and geographical
location. In Australia, the estimated amount of infectious keratitis
from all causes is 1,200 per year according to Optometry Australia (2020). The incidence rate of
infectious keratitis is higher in under-resourced countries and is found
to affect people across all age groups according to the Scientific
Journal of the Royal College of Ophthalmologists.
#### Is Keratitis a Common Corneal Disease?
Yes and no, keratitis can be a common corneal disease depending on the type. Bacterial and
viral keratitis may be the most common form of keratitis according to the Cleveland Clinic. It may be difficult to provide an
accurate estimate on whether keratitis is a [common corneal disease](https://www.oscarwylee.com.au/glasses/eye/corneal-diseases)
due to insufficient case reporting in developing countries according
to Medscape.
Find an Oscar Wylee Store Near You
We offer bulk billed eye tests at all of our stores.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
## How is Keratitis Diagnosed?
Keratitis is diagnosed by an optometrist through different tests including a comprehensive eye exam, a swab of eye
discharge and a fluorescein stain test according to the Cleveland Clinic. The optometrist will also likely
ask you about your medical history and evaluate your condition based on
the symptoms you present.
### What are the Eye Tests Done to Diagnose Keratitis?
The eye tests that are done to diagnose keratitis are a visual acuity test, an examination of the cornea, a swab of eye
discharge and a fluorescein stain test. The tests that are done to diagnose keratitis are listed below.
* Visual Acuity Test: A visual acuity test
may be performed to diagnose keratitis and involves assessing the
affected eye as well as the unaffected eye. This will assist with
evaluating whether the patient’s vision is affected.
* An Examination of the Cornea: An examination of the cornea may be necessary and may involve the use
of light and a magnification tool.
* A Swab of Eye Discharge: A swab of eye discharge may also be
required to be sent to a lab for examination.
* Fluorescein Stain Test: A fluorescein stain test may be
performed to assess any damage caused to the cornea as well as any
foreign bodies in the eye.
### Which Eye Doctor Diagnoses Keratitis?
Both an optometrist and an ophthalmologist can diagnose keratitis. It
is important to note that In Australia, an optometrist is not considered an eye doctor, however, they are
qualified and trained to diagnose eye diseases and conditions such as
keratitis. In Australia, an eye doctor is an ophthalmologist. An ophthalmologist
is required to complete a medical degree and additional training in eye
care. A patient may be referred to an ophthalmologist should they
require more complex treatment or surgery.
### How Serious is Keratitis?
Keratitis can be serious depending on the severity of symptoms, as it is one of the most common
causes of corneal blindness. Keratitis caused by infections may last between 24 - 48 hours, but
this can vary between individuals and depends on the form of keratitis
and its severity. However, when detected early, keratitis can be
effectively treated without loss of vision or vision impairment.
#### What are the Complications of Keratitis?
The complications of keratitis can include corneal scarring and corneal blindness. Keratitis when left untreated or in severe cases may result in
corneal scarring if injuries are deep enough. Corneal blindness can
develop as a complication of keratitis due to the change of corneal
transparency according to the National Library of Medicine.
##### How Often Does Keratitis Lead to Blindness?
Blindness caused by keratitis can occur quite often as a result of contact lens wear in developed
countries or poor hygiene and environmental factors in developing
countries. &nbsp;According to Darren Shu Jeng Ting, Charlotte Shan Ho and
Rashmi Deshmukh et al. (2021), infectious keratitis is the leading cause of corneal blindness in
developing and developed countries. It is important to note that it may be difficult to provide
accurate figures for how often keratitis leads to blindness due to
insufficient surveillance and records of cases in certain countries.
##### Is Keratitis Classed as a Disability?
No, keratitis itself may not be classed as a disability, however, loss of vision or blindness that may occur as a result of keratitis
can be classed as a disability. Vision impairment to a degree such as less than 6/60 is
considered a disability in Australia as it affects daily living and
capabilities.
##### Is Keratitis Contagious?
Yes and no, keratitis can be contagious if it is the infectious form of keratitis, such
as herpes simplex virus-related keratitis. The infections that
result in keratitis may be transmitted
through contact with contaminated surfaces or droplet
transmission.
## How is Keratitis Treated?
Keratitis may be treated through the use of antibacterial eye drops, antiviral eye drops, antifungal eye drops and
anti-inflammatory eye drops, however, this can depend on the severity of the patient’s condition. An
examination from an optometrist or GP is strongly advised as they will
know how to treat keratitis and ensure there are no further complications.
The treatments for keratitis are listed below.
* Antibacterial Eye Drops: Antibacterial eye drops prescribed by an optometrist may be required to
treat keratitis caused by a bacterial infection.
* Antiviral Eye Drops: Antiviral eye drops may assist with the
treatment of viral keratitis.
* Antifungal Eye Drops: Antifungal eye drops may be prescribed to
a patient with keratitis that is caused by fungi infection.
* Anti-Inflammatory Eye Drops: Anti-inflammatory eye drops may be
a helpful treatment for inflammation symptoms that occur from keratitis
such as swelling, redness, and pain.
### Can Eyeglasses Help Protect Eyes from Further Keratitis Damage?
Yes and no, eyeglasses may help protect the eyes from further keratitis
damage as they may be capable of limiting more dirt and debris from
entering the eye. However, glasses may not delay or reduce symptoms such
as redness, swelling, excessive tears or pain as medication is required to
treat such symptoms.
## What are Ways to Prevent Keratitis?
The ways to prevent keratitis may include correct care of contact lenses, proper storage of contact lenses,
maintaining regular hygiene and regular eye tests. It is important to note that keratitis can still occur even if the steps
for how to prevent keratitis are followed. This is due to causes such as
viruses, dirt and debris that can easily affect the eye and cannot be
controlled. The ways to help prevent keratitis are listed below.
* Correct Care of Contact Lenses: Correct
care of contact lenses for individuals who require them may help with the
prevention of keratitis. Using multipurpose contact lens solutions to
clean, disinfect and store contact lenses can help reduce the growth of
bacteria.
* Proper Storage of Contact Lenses: Proper storage of contact lenses involves pouring a fresh batch of
contact lens solution into the contact lens case for when you are not
using them. This will help ensure your contact lenses are kept in a safe
and clean place, it is also important to clean and disinfect contact
lens cases with the recommended solution to prevent the accumulation of
germs.
* Regular Eye Tests: Maintaining regular eye tests can assist with
the early detection of eye problems such as keratitis before they
worsen. Regular eye tests may be able to detect early signs of
inflammation or infection caused by keratitis.
## When to Call a Doctor For Keratitis?
It may be recommended to call a doctor or optometrist for keratitis
if you start to experience symptoms such as pain, redness, excessive
tears, light sensitivity and blurry vision. Keratitis may be mild at first, therefore, it is recommended to get
help from a medical professional before more symptoms occur or worsen.
Keratitis can be an emergency if you are experiencing severe pain and/or
blurry vision.
### How Can Oscar Wylee Help with Your Keratitis Problem?
At Oscar Wylee, our optometrists can help patients with keratitis, which
refers to corneal inflammation or infection, by examining the eyes and
treating the condition if detected. Oscar Wylee optometrists are highly trained eye care professionals
who can detect and treat a range of eye conditions including keratitis.
If a person believes they may have keratitis, they can book an
appointment with an Oscar Wylee optometrist to have their eyes examined
for the condition, which may include a fluorescein stain test, an
examination of the cornea, and a swab of eye discharge. If keratitis is
detected, our optometrists can help treat the condition. Treatment for
keratitis can involve eye drops, or oral medication in severe
cases.
Read Keratitis: Types, Cause, Symptoms, and Treatment in other Oscar Wylee
regions and their languages.
Australia
[Australia](https://www.oscarwylee.com.au/glasses/eye/keratitis)
[Canada](https://oscarwylee.ca/glasses/eye/keratitis)
[Canadian French](https://oscarwylee.ca/fr/glasses/eye/keratitis)
Oscar Wylee Accepts Major Health Funds In-store
Visit Oscar Wylee in-store and our team can help you with your health
fund claims.
[Health Fund](https://www.oscarwylee.com.au/health-funds.html)
Need to Have Your Eyesight Checked?
At Oscar Wylee we offer bulk-billed eye tests for all eligible medicare
card holders.
[Book an eye test](https://www.oscarwylee.com.au/booking)