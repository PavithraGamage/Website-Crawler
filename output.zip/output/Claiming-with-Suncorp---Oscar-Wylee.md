# Source: https://www.oscarwylee.com.au/health-funds/suncorp.html

# Suncorp at Oscar Wylee

As a member of Suncorp, you can claim on optical extras using your
health fund’s coverage for optical services, such as prescription
frames, lenses or glasses. Suncorp benefits reset every calendar year,
claim your glasses before time runs out! Any extras you don’t use
will be lost.
With Oscar Wylee, you can have up to 75% coverage on select
optical purchases when you shop with us. Look at the table below to see
your Suncorp policy’s name and the amount of coverage that policy gives
when you shop at Oscar Wylee. Your coverage might change or
not apply to extras such as add-ons, coatings or tinting.
## Are you seeing double?
Taking care of your eyes can be done in only 30 minutes with Oscar
Wylee.
[Book an eye test](https://www.oscarwylee.com.au/booking)
#### Waiting Period
6 months
#### Benefit Limits Reset
1st of January
#### Claimable Benefits %
75% for Top Extras, 60% for all others
To learn whether your plan includes single vision lenses, bifocal lenses
and/or multifocal lenses, talk to your health insurance provider.
| Your Extras Package Annual Limit:* | Starter Extras | Everyday Extras | Mid Extras | Top Extras | SINGLES COVER | 1 Standard OW Pair
from $169^ | 2 Standard OW Pairs
from $199^ | 3 Standard OW Pairs
from $249^ |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| $150 | $200 | $250 | $300 |
| Partial Cover | Partial Cover | Partial Cover | Partial Cover |
| Partial Cover | Partial Cover | Partial Cover | Partial Cover |
| Partial Cover | Partial Cover | Partial Cover | Partial Cover |
^Excludes add-ons. Standard frames and lenses only. Oscar Wylee’s
standard product inclusions are calculated based on the optical
allowances under each health fund package and may vary. If unsure,
please confirm with your provider. Our two pair and three pair deals are
only available per person and cannot be split between two people. Only
one prescription can be used per offer. If you have a distance and a
reading prescription, this is included in the offer as this is
considered to be one prescription. Any prescriptions must have the full
name of the person claiming and a valid expiry date to be able to order.
If you have two different prescribed prescriptions, you will need to
visit a store to be eligible for our two pair and three pair deals.
| FAMILY COVER | 1 Standard OW Pair
from $169^ | 2 Standard OW Pairs
from $199^ | 3 Standard OW Pairs
from $249^ |
| --- | --- | --- | --- |
| $150 per person | $200 per person | $250 per person | $300 per person |
| Partial Cover | Partial Cover | Partial Cover | Partial Cover |
| Partial Cover | Partial Cover | Partial Cover | Partial Cover |
| Partial Cover | Partial Cover | Partial Cover | Partial Cover |
^Excludes add-ons. Standard frames and lenses only. Oscar Wylee’s
standard product inclusions are calculated based on the optical
allowances under each health fund package and may vary. If unsure,
please confirm with your provider. Our two pair and three pair deals are
only available per person and cannot be split between two people. Only
one prescription can be used per offer. If you have a distance and a
reading prescription, this is included in the offer as this is
considered to be one prescription. Any prescriptions must have the full
name of the person claiming and a valid expiry date to be able to order.
If you have two different prescribed prescriptions, you will need to
visit a store to be eligible for our two pair and three pair deals.
## Due for an eye test?
We recommend that everyone should have an eye test with an
optometrist at least once every 2 years.
[Book an eye test](https://www.oscarwylee.com.au/booking)
*Based on Suncorp’s
[Cover Guide](https://www.suncorp.com.au/insurance/health/compare-extras-cover.html)
and product factsheet as presented to the Commonwealth Ombudsman
[1](https://www.suncorp.com.au/content/dam/suncorp/insurance/suncorp-insurance/documents/health/suncorp-starter-extras.pdf)
[2](https://www.suncorp.com.au/content/dam/suncorp/insurance/suncorp-insurance/documents/health/suncorp-everyday-extras.pdf)
[3](https://www.suncorp.com.au/content/dam/suncorp/insurance/suncorp-insurance/documents/health/suncorp-health-insurance-mid-extras.pdf)
[4](https://www.suncorp.com.au/content/dam/suncorp/insurance/suncorp-insurance/documents/health/suncorp-health-insurance-top-extras.pdf). With Suncorp couples and Families policies, the annual limit is
applied per person. Dependents and couples are given the same cover
limit as the primary member, the amount is not shared between all
parties.
Information correct as of November 2024.
## Your eye test explained
Routine eye test appointments are quick and painless. Find out
what to expect during an eye exam and how to understand your eye
test results.
[Find out more](https://www.oscarwylee.com.au/eye-health/your-eye-test-explained.html)
## Bulk Billing
Find out what bulk billing is and whether you're eligible to
receive an eye test free of charge.
[Find out more](https://www.oscarwylee.com.au/eye-health/eye-test-info/bulk-billing.html)
## What is Pupillary Distance? (PD)
Do you know your PD? It's something you'll need to know when
ordering glasses online. Find out what Pupillary Distance is and
how you can measure your own.
[Read more](https://www.oscarwylee.com.au/eye-care/eye-test/what-is-pupillary-distance.html)
## Book an eye test
Oscar Wylee eye tests are bulk billed through Medicare. This
means there will be no out-of-pocket expense for eligible
Medicare cardholders.
[Book online](https://www.oscarwylee.com.au/booking/)
## Find a store near you
Contact or visit your nearest store for a full quote.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)