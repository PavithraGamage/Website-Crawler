# Source: https://www.oscarwylee.com.au/glasses/nose-bridge-types/saddle

# Saddle Nose Bridge Glasses and Sunglasses
Published on August 18th, 2025
Updated on July 14th, 2025 
A saddle nose bridge for glasses and sunglasses refers to a glasses nose bridge that sits high up on the nose and distributes weight evenly on either side. A saddle nose bridge is shaped like an upside-down U. Saddle nose bridges are common in glasses, and at Oscar Wylee, we have several glasses with a saddle nose bridge, including Serge, Victor, Orville, Ezra, and Ramon. Keep reading to learn more about the saddle nose bridge design feature.
Ready to book an eye test
At Oscar Wylee, we offer bulk billed eye tests for all eligible medicare card holders.
[Eye test near me](https://www.oscarwylee.com.au/booking)
[How to Choose](#Choose) [Material](#Material) [Definition](#Definition) [Price Factors](#Price)
## How to Choose the Best Saddle Bridge Glasses?
The way to choose the best saddle bridge glasses is much the same as for many other types of glasses. You should consider face shape, frame size, colour of the frames, consider your hairstyle, and accentuate your personality when picking the saddle bridge frame that is right for you.. The ways to choose the best saddle bridge glasses are listed below.
* Consider face shape: Consider face shape when choosing the best saddle bridge glasses. Certain frames pair well with certain face shapes. For example, a pair of rectangle glasses may complement a round face well, as it is able to provide structure and angles to the round face.
* Frame size: Consider frame size when choosing the best saddle bridge glasses. Saddle bridge glasses can be any size, small, medium or large. It is important to pick a size that sits well at your temples and across the nose.
* The colour of your frames: Consider the colour of your frames when picking the best saddle bridge glasses. You may want to consider what colours will go best with your everyday attire, or what occasions the frames will be worn for, such as work or a fun day out.
* Consider your hairstyle: Consider your hairstyle when choosing the best saddle bridge frames, as some hairstyles may complement certain frame shapes better. Hair that is shorter and textured will draw attention to the centre of the face, and make your eyewear a focal point. In this case, you may prefer a thinner frame, which will not overpower the face. Medium length hair is versatile when it comes to compatible frames, so you might want to consider thickness and style when it comes to glasses frames.
* Accentuate your personality: Accentuating your personality is an important step in picking the best saddle nose bridge glasses. Pick a shape, colour, size or pattern that best suits and represents your personality and style.
### How to Choose the Best Saddle Bridge Glasses According to Face Shape?
To choose the best saddle bridge glasses according to [face shape](https://www.oscarwylee.com.au/glasses/face-shapes) you should determine your face shape, and choose a glasses shape that fits it well. The most common face shapes are square, oval, pear and round face shapes. The types of face shapes and what saddle nose bridge glasses would suit them are listed below.
* Square Faces: Square faces are characterised by an angular forehead and chin, and a face that is mostly in proportion. Round or oval saddle nose bridge glasses are good for square faces, as they soften the naturally sharp angles.
* Oval Faces: Oval faces are rounded and longer than they are wide. Angular or square saddle nose bridge frames are good for oval faces; however, this face shape is considered versatile and may work with other shapes too.
* Pear Faces: Pear faces are characterised by a narrow forehead and wider jawline. Saddle nose bridge rames that complement pear shapes are round and oval shapes.
* Round Faces: Round faces are circular in appearance with few angles. Round faces will benefit from rectangular or square saddle nose bridge frames as they provide contrast and angles for the soft curves of this face shape.
### How to Choose Saddle Nose Bridge Glasses According to Eye Colour?
Eye colour does not typically play a major factor in choosing the saddle nose bridge glasses. If a person wants guidance on what frames may look the best on them, it is best to consider other, more prominent features such as skin tone, hair colour, face and nose shape. If a person does want to consider eye colour, however, blue or grey eyes will be complemented by silver, grey, or navy frames. Brown or hazel eyes may work with tortoiseshell, gold or dark brown glasses to match the eyes.
## Which Material is Best for Saddle Nose Bridge Glasses?
There is no best material for saddle bridge glasses. The material best for each individual will depend on factors such as comfortability, material aesthetic preference and personal style. The common materials that are best for saddle nose bridge glasses are titanium, acetate, ultem, and bio-acetate. The materials that are best for saddle nose bridge glasses are listed below.
* Titanium: Titanium is a type of metal known for its lightweight qualities, a good choice for saddle nose bridges.
* Acetate: Acetate is a flexible cellulose material with a variety of colourways that can be used to create frames with saddle nose bridges.
* Stainless steel: Stainless steel is a metal that is a great material for saddle bridge glasses.
* Ultem: Ultem is a type of plastic known for its lightweight and durability.
* Bio-acetate: Bio-acetate is mainly made from plant-based matter such as wood pulp and cotton fibres for a more eco-conscious material.
### 1. Titanium Saddle Bridge Glasses
[Titanium](https://www.oscarwylee.com.au/glasses/titanium) saddle bridge glasses are characterised by a metal appearance, their strength and lightweight quality. The metal’s durability and sleek profile make it an effortlessly cool eyewear choice.
[](https://www.oscarwylee.com.au/franklin-optical.html)
[Franklin](https://www.oscarwylee.com.au/franklin-optical.html)
$169    
Add to Cart
[Shop Franklin](https://www.oscarwylee.com.au/franklin-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/franklin-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/franklin-optical.html)
### 2. Acetate Saddle Bridge Glasses
Acetate saddle bridge glasses refer to glasses made from a flexible and hypoallergenic cellulose material. [Acetate](https://www.oscarwylee.com.au/glasses/acetate-frame) is a popular material choice for saddle bridge glasses as it can come in a variety of colours, with an often thick frame for a bold piece.
[](https://www.oscarwylee.com.au/serge-optical.html)
[Serge](https://www.oscarwylee.com.au/serge-optical.html)
$169    
Add to Cart
[Shop Serge](https://www.oscarwylee.com.au/serge-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/serge-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/serge-optical.html)
[](https://www.oscarwylee.com.au/mesa-optical.html)
[Mesa](https://www.oscarwylee.com.au/mesa-optical.html)
$169    
Add to Cart
[Shop Mesa](https://www.oscarwylee.com.au/mesa-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/mesa-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/mesa-optical.html)
[](https://www.oscarwylee.com.au/frieda-optical.html)
[Frieda](https://www.oscarwylee.com.au/frieda-optical.html)
$169    
Add to Cart
[Shop Frieda](https://www.oscarwylee.com.au/frieda-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/frieda-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/frieda-optical.html)
### 3. Stainless Saddle Bridge Glasses
[Stainless steel](https://www.oscarwylee.com.au/glasses/materials/stainless-steel.html) is a metal that is a great material for saddle bridge glasses. Stainless steel provides a sleek look with often metallic colours for sharp good looks.
[](https://www.oscarwylee.com.au/thomas-optical.html)
[Thomas](https://www.oscarwylee.com.au/thomas-optical.html)
$169    
Add to Cart
[Shop Thomas](https://www.oscarwylee.com.au/thomas-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/thomas-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/thomas-optical.html)
[](https://www.oscarwylee.com.au/ava-optical.html)
[Ava](https://www.oscarwylee.com.au/ava-optical.html)
$169    
Add to Cart
[Shop Ava](https://www.oscarwylee.com.au/ava-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/ava-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/ava-optical.html)
[](https://www.oscarwylee.com.au/betty-optical.html)
[Betty](https://www.oscarwylee.com.au/betty-optical.html)
$169    
Add to Cart
[Shop Betty](https://www.oscarwylee.com.au/betty-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/betty-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/betty-optical.html)
### 4. Ultem Saddle Bridge Glasses
Ultem saddle bridge glasses refer to glasses made from a type of strong, durable thermoplastic.
[](https://www.oscarwylee.com.au/allan-optical.html)
[Allan](https://www.oscarwylee.com.au/allan-optical.html)
$169    
Add to Cart
[Shop Allan](https://www.oscarwylee.com.au/allan-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/allan-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/allan-optical.html)
[](https://www.oscarwylee.com.au/leigh-l-optical.html)
[Leigh Large](https://www.oscarwylee.com.au/leigh-l-optical.html)
$169    
Add to Cart
[Shop Leigh Large](https://www.oscarwylee.com.au/leigh-l-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/leigh-l-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/leigh-l-optical.html)
### 5. Bio-acetate Saddle Bridge Glasses
Bio-acetate saddle bridge glasses are made from mainly plant based matter.[Bio-acetate](https://www.oscarwylee.com.au/glasses/bio-acetate) frames are an eco-friendly eye wear choice.
[](https://www.oscarwylee.com.au/julie-optical.html)
[Julie](https://www.oscarwylee.com.au/julie-optical.html)
$169    
Add to Cart
[Shop Julie](https://www.oscarwylee.com.au/julie-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/julie-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/julie-optical.html)
### What is a Saddle Nose Bridge in Glasses?
A saddle bridge in glasses refers to the piece of frame, shaped like an upside down U, that sits directly above the nose and holds the glasses to the face. A saddle bridge will sit high up on the nose, and distributes weight evenly on either side. Other common bridge fits are the [double bridge glasses](https://www.oscarwylee.com.au/glasses/nose-bridge-types/double-nose-bridge) and [high nose bridge fit glasses and sunglasses.](https://www.oscarwylee.com.au/glasses/nose-bridge-types/high-nose)
### Why does the Nose Bridge Matter in Choosing Saddle Bridge Glasses?
The type of nose bridge a person has does not matter too much in choosing saddle bridge glasses. Generally, saddle bridge glasses suit a wide range of nose shapes and nose bridges.
## How to Buy Saddle Bridge Glasses According to Width?
At Oscar Wylee, we have several saddle bridge glasses in differing widths to accommodate a range of face sizes. These width sizes include X-Small, Narrow, Medium or Wide. Read on for the various saddle bridge glasses widths to consider before purchasing.
* X-Small: X-small is well suited to adults with smaller, narrow faces, or kids, and is the smallest size we sell at Oscar Wylee. We have saddle nose bridge glasses that come in small sizes, including Serge in Small.
* Narrow: Narrow width saddle bridge frames are available at Oscar Wylee, and good for petite and narrow faces.
* Medium: Medium frames are available at Oscar Wylee in a range of colours and shapes. Medium frames are well suited to those with average, or medium sized faces. Oscar Wylee medium width saddle bridge frames include Serge and Victor.
* Wide: Wide frames are available at Oscar Wylee. Wide frames are good for those with wider, larger faces and include Serge Large.
### Which Colour Pattern is Best for Saddle Bridge Glasses Frames?
There are various colour patterns a person can choose from when it comes to choosing the best for saddle bridge glasses. Some saddle nose bridge colour patterns include solid, tortoise and two-toned. Read on for the various colour patterns that could be best for an eye-catching saddle bridge glasses frame.
* Solid: Solid colour frames can be a good eyewear choice for saddle bridge frames. Solid patterns are good for those wanting one strong colour.
* Tortoise: Tortoiseshell patterns offer a blend of often warm tones for saddle bridge glasses.
* Two-toned: Two-toned glasses create an eye-catching contrast and visual interest for those who want a bold pop of colour in their saddle bridge glasses.
### How Do Saddle Bridge Glasses Compare to Adjustable Nose Pads?
Saddle bridge glasses and adjustable nose pads are not comparable as one, saddle bridge, is a design and adjustable nose pads are a functional feature.&nbsp; A saddle nose bridge is a [nose bridge type for glasses and sunglasses](https://www.oscarwylee.com.au/glasses/nose-types) that looks like an upside-down U and sits across the nose. [Nose pads for glasses](https://www.oscarwylee.com.au/glasses/nose-pad) are small, sometimes silicone pads, that touch either side of the nose and help hold the glasses to the face.
### Which Colour is Best for Saddle Bridge Glasses?
The best colour for saddle bridge glasses is a personal preference. At Oscar Wylee we have a variety of colours such as black, brown, blue, green, red, and pink. Read on for the various colours that are best for saddle bridge glasses frames.
* Black: Black is a classic, neutral colour perfect for saddle bridge glasses. Black glasses will suit a variety of people, as well as match many outfits.
* Brown: Brown is a classic, stylish colour that will
* Blue: Blue for saddle bridge glasses adds some stylish colour, whether a baby blue or rich navy, for a visually appealing aesthetic.
* Green: Green, depending on the shade, can be a rich, regal colour for saddle bridge frames, or a bright, fun pop of colour.
* Red: Red saddle bridge glasses are a bold statement. Red is one of the colours of the season, and will give the wearer a hugely stylish look.
* Pink: Pink coloured frames can be a fun, feminine option for saddle bridge glasses.
Find Your Local Oscar Wylee Store
Use our store locator page to find your near Oscar Wylee store and come see the team for all your eyewear and eyecare needs.
[Optometrist near me](https://www.oscarwylee.com.au/locations/)
## What Types of Nose Shapes Work Best with Saddle Bridge Glasses?
Nose shape type does not generally play a role in how well saddle bridge glasses will work for people. Saddle bridge glasses will generally suit a wide range of nose shapes and sizes. For more on saddle bridges and other eyewear components, read the [Parts of Glasses: A Guide to the Anatomy of Glasses](https://www.oscarwylee.com.au/glasses/eye/part-of-glasses).
### Are Saddle Bridge Glasses Better for Persons with Small Noses?
Saddle bridge glasses are not necessarily better for people with small noses, as they come in many sizes that can fit a variety of nose sizes.
### What is the Difference Between a Saddle Bridge and a Low Nose Bridge?
The difference between a saddle bridge and a low nose bridge is that a saddle bridge is a design feature of a pair of glasses, whereas a low nose bridge is a physical feature on a person. A low nose bridge is generally in line, or sits below, the pupils.
#### Do Retro-Style Glasses Commonly Feature Saddle Bridges?
Yes, retro-style glasses commonly feature saddle bridges. Saddle bridges are a classic design feature of glasses, and have been a staple of many glasses designs for years.
#### Are Saddle Bridge Glasses Suitable for Sports and Active Use?
Saddle bridge glasses can be suitable for sports and active use, if they are part of a strong, durable sports sunglasses frame. At Oscar Wylee, our [active sunglasses](https://www.oscarwylee.com.au/sunglasses/collection/active-collection.html), part of the OW Active Collection, have several sports sunglasses with a nose bridge resembling a saddle bridge.
#### Are Saddle Bridge Glasses Comfortable for Long-Term Wear?
Yes, saddle bridge glasses should generally be comfortable for long term wear. The shape and design of saddle nose bridges allow the weight of the frames to be distributed evenly on either side of the nose.
#### Who Should Wear Saddle Bridge Glasses?
Saddle bridge glasses can generally be worn by most people. Saddle bridge glasses are versatile and can work with a variety of nose shapes, sizes and types.
## What are the Price Factors for Saddle Bridge Glasses?
The price factors for saddle bridge glasses, like all glasses at Oscar Wylee, will vary depending on elements such as glasses material, add-ons and lens types. One pair of glasses from our core range starts from $169, 2 pairs from $199 and 3 pairs from $249. It should be noted that lens thickness and other add-ons will affect overall pricing. For a full price guide, read [here](https://www.oscarwylee.com.au/price-guide/).
### What is the Duration of Shipment for Saddle Bridge Glasses?
Oscar Wylee offers domestic shipping for all glasses, including saddle bridge glasses, ordered on the website. Typically, deliveries will usually be dispatched within 7-10 business days. An email will be sent to you confirming the order alongside an order tracking link. Deliveries to the home may take up to 3 weeks.
Are You Due for an Eye Test?
Regular eye tests are an important step in keeping eyes healthy. Book now and an Oscar Wylee optometrist can provide a Medicare bulk billed eye test.
[Eye test near me](https://www.oscarwylee.com.au/booking)
Major Health Funds Accepted In-store
For the purchase of frames and lenses, use your private health fund insurance to limit how much you pay from your own pocket.
[Explore Health Funds](https://www.oscarwylee.com.au/health-funds.html)