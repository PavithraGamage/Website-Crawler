# Source: https://www.oscarwylee.com.au/shipping.html

Oscar Wylee offers free domestic shipping on all orders placed on our website within Australia! Once our laboratory has cut the lenses to fit your specifications, we'll try as hard as we can to get your glasses to you as fast as possible.
### Frequently asked questions about shipping:
* How much do you charge for shipping?Oscar Wylee offers free domestic shipping on all orders placed on our website within Australia!Once our laboratory has cut the lenses to fit your specifications, we'll try as hard as we can to get your glasses to you as fast as possible.
* How long will it take before I receive my glasses?Deliveries on purchase orders will usually be dispatched within 7-10 business days.Delivery on Australian orders is FREE and your order will be sent out via Australia Post.An email will be sent to you once your glasses have been dispatched with an order tracking link.If you are not around to take delivery, you will be left a calling card telling you how you can pick up your package. Unfortunately we cannot ship orders on public holidays. In this instance please expect your delivery to be delayed by one business day.
### Still have more questions?
Please check out our [Help/FAQ](https://www.oscarwylee.com.au/faq-popular.html) page or [Contact us](https://www.oscarwylee.com.au/contact/)!