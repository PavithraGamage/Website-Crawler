# Source: https://www.oscarwylee.com.au/glasses/eye/what-happens-if-you-rub-your-eyes-too-much

# What Happens if You Rub Your Eyes Too Much?
Published on May 21st, 2026
Australia
Australia
New Zealand
Canada
Canadian French

Eye rubbing is a reflexive action many of us do, whether to relieve eye
strain, irritation, or itchiness.
However, rubbing your eyes too harshly or frequently can have
complications on your eye health, such as redness, corneal damage, puffy
eyes, and exacerbating eye conditions you already have.
Read more about these complications that come from rubbing your eyes, and
ways to properly treat irritated eyes.
It should be noted that this information is general in nature and does
not replace professional medical advice.
Schedule your next appointment with our team for great eyecare!
Our optometrists and teams are dedicated to your healthy vision.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Dry Eyes](#dry-eyes)
[Keratoconus](#keratoconus)
[How It Affects Eyes](#affects)
[How to Stop](#stop)
## 1. Eye Irritation
[Eye irritation](https://www.oscarwylee.com.au/glasses/eye/irritation-causes)
can occur from rubbing your eyes too much. While
rubbing your eyes may be an instinctual response to irritated
eyes, the action is known to exacerbate the irritation.
## 2. Redness
[Redness](https://www.oscarwylee.com.au/glasses/eye/red-or-bloodshot)
can emerge as a result of rubbing your eyes. This is because it can
cause tiny blood vessels to break, leading to bloodshot
eyes, according to the Vision Eye Institute.
## 3. Increased Itching
Increased itching may happen if you rub your eyes.
Rubbing your eyes is a temporary solution to itchy
eyes, and can make them feel even itchier.
## 4. Blurry Vision
[Blurry vision](https://www.oscarwylee.com.au/glasses/eye/blurred-vision), either short-term or long-term, can be a result of
rubbing your eyes. This is particularly true for those with pre-existing
vision conditions.
## 5. Light Sensitivity
[Light sensitivity](https://www.oscarwylee.com.au/glasses/eye/light-sensitivity)
may be noticeable soon after rubbing your eyes vigorously. After rubbing
your eyes harshly,
you may see flashes of light and spots in your vision before it
reverts to normal.
## 6. Dry Eyes
Dry eyes are a common reason you may rub their eyes frequently. However,
it is not an effective solution and can
sometimes make your
[dry eyes](https://www.oscarwylee.com.au/glasses/eye/dry-eyes)
even worse.
[Eye drops](https://www.oscarwylee.com.au/glasses/eye/types-of-eye-drops)
are a more effective treatment for dry eyes.
## 7. Eye Strain
[Eye strain](https://www.oscarwylee.com.au/glasses/eye/fatigue-definition)
can be a reason why you may rub your eyes frequently.
However, this can often lead to them feeling even more strained. It is
important to manage eye strain by implementing measures such as pacing
screen time and using appropriate
[prescription glasses](https://www.oscarwylee.com.au/glasses.html)
recommended by your optometrist.
Experience passionate eyecare and a memorable in-store experience!
Visit your local OW store for any of your concerns or browse our wide
selection of stylish frames!
[Find a store](https://www.oscarwylee.com.au/locations)
## 8. Scratching of Cornea
Corneal scratch is a possibility if you scratch your eyes too frequently
or harshly. This abrasion and
scratching can lead to redness, pain and watery eyes.
## 9. Keratoconus
Frequent and vigorous eye rubbing is strongly linked to the development
and progression of keratoconus. This is because eye rubbing can break
down the fibres of the cornea and make it thinner, leading to
progressive
[keratoconus](https://www.oscarwylee.com.au/glasses/eye/keratoconus).
## 10. Dark Circles Around the Eyes
Dark circles can
emerge around the eyes as a result of rubbing them,
according to the Vision Eye Institute. These dark circles are often
accompanied by bloodshot eyes.
## 11. Wrinkles Around the Eyes
Wrinkles around the eyes can develop if you rub the
skin around the eyes harshly and vigorously.
## 12. Eye Infections
Eye infections are a potential complication of rubbing your eyes too
much. If you rub your eye, the transference of germs from your hands can
result in infections like
[conjunctivitis](https://www.oscarwylee.com.au/glasses/eye/conjunctivitis),
according to the Vision Eye Institute.
## 13. Increased Inflammation
Increased inflammation is common among those who rub their eyes.
Particularly
under the eyes and on the eyelids themselves, which can
become swollen and inflamed.
## 14. Temporary Vision Problems
Temporary vision problems can occur from rubbing your eyes. Most
notably, right after rubbing your eyes, your vision may
be blurred but return to normal quickly.
## 15. Permanent Vision Changes
Permanent vision changes
are a possibility if you rub your eyes too much.
Studies have shown that excessive eye rubbing can lead to the eye
condition keratoconus, which can cause permanent vision deterioration.
## 16. Watery Eyes
[Watery eyes](https://www.oscarwylee.com.au/glasses/eye/watery)
are not necessarily a result of rubbing your eyes too much. However, they are often a sign of allergies and irritation in the
eye, which can lead to an individual wanting to rub their eyes, further
worsening the condition.
## 17. Burning Sensation
A burning sensation in the eyes is
often a reaction to irritation or a lack of eye lubrication, according to the Cleveland Clinic. Irritation and dry eyes due to a
lack of eye lubrication are often reasons why people may rub their eyes,
potentially leading to a burning sensation.
## 18. Puffy Eyes
[Puffy eyes](https://www.oscarwylee.com.au/glasses/eye/puffy-definition)
are common amongst those who rub their eyes, as the
friction causes the eyelids and surrounding skin to become inflamed.
### Why do People Keep Rubbing Their Eyes?
People keep rubbing their eyes as a
natural instinct in response to itchiness, sore eyes,
tiredness, or the feeling of a foreign body inside the eye, such as
dust particles.
#### Is Rubbing Your Eyes Bad for You?
Yes, rubbing your eyes can be bad for you, particularly
if you do it frequently and harshly. Once-off and
infrequent eye rubbing should not generally affect your eyes.
However, it is a short-term solution and often leads to more eye
rubbing. Vigorous eye rubbing can lead to
[corneal abrasions](https://www.oscarwylee.com.au/glasses/eye/corneal-abrasion), tearing, eye redness, and potentially even impaired vision,
according to Eye Specialists Sydney.
##### Can Rubbing Your Eyes Change Your Vision?
Yes, rubbing your eyes may change your vision,
particularly if it is harsh and vigorous rubbing,
and if you have pre-existing vision conditions.
## How does Eye Rubbing Affect Eye Health?
Eye rubbing affects
[eye health](https://www.oscarwylee.com.au/glasses/eye/health-tips-keeping-eyesight-healthy)
as it can cause complications such as
transferring germs, cornea damage,
[bloodshot eyes](https://www.oscarwylee.com.au/glasses/eye/red-or-bloodshot)
and worsening existing conditions such as myopia, according to Vision
Eye Institute.
### How Does Rubbing Your Eyes Cause Damage to the Surface?
Rubbing your eyes causes damage to the eye surface, as
tiny broken blood vessels can develop, leading to bloodshot
eyes.
The cornea can also thin as a result of vigorous rubbing, referred to
as keratoconus, according to the Centre for Eye Research Australia.
#### Can Rubbing Your Eyes Damage Them Permanently?
Yes, rubbing your eyes, particularly if you do this frequently and
harshly, can damage them permanently.
##### Does Rubbing Eyes Cause Astigmatism?
There are mixed views on whether rubbing eyes
causes
[astigmatism](https://www.oscarwylee.com.au/glasses/eyewear-for-astigmatism). However, it could potentially exacerbate the condition if you
have it already.
##### Can You Go Blind From Rubbing Your Eyes Too Much?
Yes, in some extreme cases, continuous eye
rubbing can lead to vision loss, according to George Street Eye
Centre. However it should be noted this is only in rare cases as a
result of rigorous, prolonged rubbing.
## Why Does Rubbing Your Eyes Feel Good?
Rubbing your eyes feels good as it is an
easy, instantaneous action that lubricates the ocular surface, according to Defeat Keratoconus. It is an immediate relief for dry
eyes; however, it is not an effective solution.
### Why does It Feel Good to Rub Your Eyes When Tired?
It feels good to rub your eyes when tired, as it provides
temporary relief from the strain and fatigue you may
feel.
#### Is That Relief Only Temporary?
Yes, the relief that comes from rubbing your eyes
is only temporary and a short-term solution to irritation.
## How Can You Stop Rubbing Your Eyes?
To stop rubbing your eyes, use other methods to treat eye irritation and
make sure they are used frequently during periods when you have itchy,
irritated eyes. These alternatives can include
eye drops, cold compresses and allergy medication,
according to Vision Clinic Sydney. Read more about these alternatives
below.
* Eye Drops: Eye drops are a common
alternative to rubbing eyes. They can be purchased over the counter
and are beneficial for dryness, irritation, and flushing out any
foreign bodies that may be present.
* Cold Compresses: Cold compresses can
reduce swelling, irritation, and relieve stress in the eyes, and are
particularly useful for allergies.
* Allergy Medication: Allergy
medications will be useful for those who have irritated eyes as a
result of allergies. Make sure to consult your GP for the best
treatment of your allergies, which can reduce your irritated eyes.
Is It Better to Use Eye Drops Instead of Rubbing?Yes, it is better to use eye drops instead of rubbing. Eye drops
provide sufficient lubrication to the eye's surface, making the eyes
less dry and less prone to irritation. Rubbing the eyes is an instant
reflex; however, it does not address any of the underlying causes of
itchy eyes.
## Can Prescription Glasses Help Reduce Eye Rubbing?
Prescription glasses,
in some cases, may help reduce eye rubbing.
[Prescription glasses](https://www.oscarwylee.com.au/glasses.html)
allow for optimal visual clarity for those with vision issues. In turn,
prescription glasses can prevent eye strain and fatigue, which are
common reasons individuals may rub their eyes.
It should be noted that this information is general in nature and
does not replace professional medical advice.
Read What Happens if You Rub Your Eyes Too Much? in other Oscar Wylee
regions and their languages.
Australia
Australia
New Zealand
Canada
Canadian French

Experience Quality Eye Care!
We have knowledgeable optometrists at Oscar Wylee, who are available
in-store to perform high-quality eye tests.
[Book an eye test](https://www.oscarwylee.com.au/booking)
Oscar Wylee Accepts Major Health Funds In-store
Visit Oscar Wylee in-store for eye care and eye wear services, and
your health fund may help cover some of the cost.
[Explore health funds](https://www.oscarwylee.com.au/health-funds.html)