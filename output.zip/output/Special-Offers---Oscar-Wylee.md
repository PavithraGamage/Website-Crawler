# Source: https://www.oscarwylee.com.au/special_offers.html

[](https://www.oscarwylee.com.au/3-pairs-from-249)
###### 3 Pairs from $249 **
A frame for every occasion! Select 3 optical prescription glasses with
standard single vision lenses from $249.
[Find out more](https://www.oscarwylee.com.au/3-pairs-from-249)
[](https://www.oscarwylee.com.au/glasses.html)
###### 2 Pairs from $199 *
2 pairs are better than 1! Choose 2 optical prescription glasses with
standard single vision lenses from $199.
[Shop Glasses](https://www.oscarwylee.com.au/glasses.html)
[](https://www.oscarwylee.com.au/3-pairs-from-249)
###### 3 Pairs of non-prescription sunglasses from $249 **
Bring a statement pair wherever you go. Choose 3 standard
non-prescription sunglasses from $249.
[Find out more](https://www.oscarwylee.com.au/3-pairs-from-249)
[](https://www.oscarwylee.com.au/sunglasses.html)
###### 2 Pairs of non-prescription sunglasses from $199 *
One for brunch and one for the beach. Select 2 standard non-prescription
sunglasses from $199.
[Shop Sunglasses](https://www.oscarwylee.com.au/sunglasses.html)
[](https://www.oscarwylee.com.au/locations/full-store-list.html)
###### Limited Edition Tote Bags
Customers who purchase prescription glasses with any add-on in-store can
receive one of our vibrant, limited edition tote bags!
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
[](https://www.oscarwylee.com.au/eye-test-offer-for-international-students)
###### Free Eye Test for International Students
Receive a free eye test at Oscar Wylee with any glasses purchased on the
same day. Must show a valid international ID and student ID to qualify
for this offer.
[Learn more](https://www.oscarwylee.com.au/eye-test-offer-for-international-students)
[](https://www.oscarwylee.com.au/glasses/collection/kids-collection.html)
###### Kids Glasses: 2 Pairs from $199 *
Select 2 kids' frames from $199. Includes standard single vision lenses.
[Shop Kids Collection](https://www.oscarwylee.com.au/glasses/collection/kids-collection.html)
[](https://www.oscarwylee.com.au/multifocal-lenses.html)
###### Included Standard Multifocal Lens
Buy a single pair of glasses from our $169 range and get standard
multifocal lenses included. Standard frame and lens pricing applies.
[Find out more](https://www.oscarwylee.com.au/multifocal-lenses.html)
[](https://www.oscarwylee.com.au/retinal-scan.html)
###### Free Digital Retinal Scan ^
Digital Retinal Scans can help uncover problems with your vision that
may not show up during a regular eye test.
[Read more](https://www.oscarwylee.com.au/retinal-scan.html)
[](https://www.oscarwylee.com.au/visual_field.html)
###### Bulk billed Visual Field Test ^
A Visual Field Test can be used to diagnose vision loss and eye
problems, such as glaucoma.
[Read more](https://www.oscarwylee.com.au/visual_field.html)
* Our two pairs of glasses from $199 includes clear optical glasses with
standard single vision lenses only. Our standard single vision lenses are CR
39, 1.5 index lenses with scratch resistance. You can upgrade to
prescription sunglasses for an additional cost per pair. Our two pairs from
$199 is only available per person and cannot be split between two people.
Only one prescription can be used per offer. If you have a distance and a
reading prescription, this is included in the offer as this is considered to
be one prescription. Any prescriptions must have the full name of the person
claiming and a valid expiry date to be able to order. If you have two
different prescribed prescriptions, you will need to visit a store to be
eligible for our two pairs from $199.
** Our three pairs of glasses from $249 includes clear optical glasses with
standard single vision lenses only. Our standard single vision lenses are CR
39, 1.5 index lenses with scratch resistance. You can upgrade to
prescription sunglasses for an additional cost per pair. Our three pairs
from $249 is only available per person and cannot be split between two or
more people. Only one prescription can be used per offer. If you have a
distance and a reading prescription, this is included in the offer as this
is considered to be one prescription. Any prescriptions must have the full
name of the person claiming and a valid expiry date to be able to order. If
you have two different prescribed prescriptions, you will need to visit a
store to be eligible for our three pairs from $249.
^ Not available at all stores. Usage criteria is at the discretion of the
optometrist.
On the lookout for great value for glasses frames and excellent services?
At Oscar Wylee you can expect:
• Lifetime guarantee of adjustments or professional cleaning for your Oscar Wylee glasses.
• If within 1 year of purchase your glasses have any defects due to material or production faults, we will repair or replace them for you. Learn more about our [Oscar Wylee Warranty](https://www.oscarwylee.com.au/legal/oscar-wylee-warranty.html).
• Free Shipping for Australian Orders
• Scratch resistance lens coating on all prescriptions
• UV-proof coating on all prescriptions
• Protective case and microfibre lens cloth for your favourite new frames.
Due for an eye test? Book now:
[Eye test near me](https://www.oscarwylee.com.au/booking)
We recommend that everyone should have an eye test with an optometrist at least once every 2 years.
Oscar Wylee offers bulk billed eye test, so there are no out-of-pocket expenses for eligible Medicare card holders.