# Source: https://www.oscarwylee.com.au/lucia-sunglasses.html

# Lucia
1
## Frame Design of Lucia Sunglasses
The frame design of Oscar Wylee’s Lucia sunglasses is characterised by their oval and round shape, high nose bridge fit, and acetate and stainless steel frame. Lucia is a trendy women's glasses frame that will work for any occasion, whether the wearer wants to liven up their everyday style or complement a fun outfit for a day out.
$169    
In stock
Only %1 left
2 pairs from $199
Discount auto-applied at checkout
3 pairs from $249
Discount auto-applied at checkout
* 2 &amp; 3 Pair pricing applies to non-prescription sunglasses only. Prescription sunglasses incur additional charges.    
[Non-Prescription](https://www.oscarwylee.com.au/lucia-sunglasses.html#)
Qty
Prescription
Book an eye test
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
excluding prescription lenses
## About Lucia Sunglasses
With her diamond-like shape and thick temples, Lucia is utterly chic, and we’re not apologising for it.
| Frame fit | Measurements |
| --- | --- |
| MEDIUM | 52 - 16 - 142 |
These measurements mean lens width, bridge, and temple length in millimetres (mm). They can be found on the inside of the temple arm. If you already have a pair that you like, you can compare it to these measurements.
### Made from Acetate and Stainless Steel
Oscar Wylee's Lucia frame is a women's oval and round sunglasses frame that is perfect for those with square, oval, heart, pear, and diamond face shapes. The Lucia frame is a striking and versatile frame that blends well with your outfits while making the perfect statement. The main specs of Oscar Wylee's Lucia glasses frame, including dimensions, shape, materials, lenses, nose fit, and hinges, are listed below.
Filter category 3 - General purpose sunglasses. High protection against sunglare. Good UV Protection. Not suitable for driving in twilight, at night or under dull conditions
This frame comes with tinteded lenses. An additional $30 will be added to your order total for prescription orders.
| Lucia Frame Features | Lucia Frame Description | Dimensions | Shape | Materials | Lenses | Nose Fit | Hinges |
| --- | --- | --- | --- | --- | --- | --- | --- |
| The dimensions of the Lucia frame are measured in millimetres (mm) and are 52 - 16 - 142, meaning the lens width is 52 mm, the bridge is 16 mm, and the temple length is 142 mm. |
| The Lucia frame is an oval and round shape, well suited to medium faces. |
| Lucia is made from acetate and stainless steel. |
| The lenses that can be used in the Lucia frame are sunglass lenses, which provide UV protection. Prescription lenses are also available to purchase for the Lucia sunglass frame, both online and in-store. |
| The nose fit for the Lucia frame is a high nose bridge fit. |
| The hinges in Lucia glasses are normal hinges, also known as standard or barrel hinges. |
Show All
### What Inspired the Frame Design of Oscar Wylee's Lucia Glasses?
The Oscar Wylee Lucia frame design was inspired by current fashion trends, as oval and round shapes are often in fashion. An oval and round glasses shape is timeless; it remains popular throughout the decades while other trends come and go.
## What to Know About Oscar Wylee's Lucia Sunglasses?
There are many aspects of the Oscar Wylee Lucia frames that customers should know about, so they can decide whether this is the right frame for them. The Lucia frame is a women's oval and round sunglasses frame. Oscar Wylee's Lucia frame is suitable for many face shapes, but particularly compatible with square, oval, heart, pear, and diamond face shapes. The Lucia frame's simple design means that they are fashionable all year round. Lucia features the standard [parts of glasses](https://www.oscarwylee.com.au/glasses/eye/part-of-glasses), such as a rim, temples, lenses, hinges, and a high nose bridge.
### What are the Types of Temple Tips or Earpieces Included with Oscar Wylee's Lucia Glasses?
The type of temple tips or earpieces included in Oscar Wylee's Lucia Glasses are made from acetate.
### What Type of Nose Bridge do Oscar Wylee's Lucia Glasses Have?
The type of nose bridge included in Oscar Wylee's Lucia frame is a high nose bridge fit.
### What Type of Nose Pads are Included with Oscar Wylee's Lucia Glasses?
Oscar Wylee's Lucia frame does not include adjustable silicone nose pads.
### What Type of Lenses do Oscar Wylee's Lucia Sunglasses Have?
The lenses that can be used in the Lucia frame are sunglass lenses, which provide UV protection. UV protection lenses block harmful ultraviolet rays, safeguarding eyes from damage. The Lucia frame comes in Filter Category 3. These are general purpose sunglasses that provide high protection against sunglare and good UV protection. They are not suitable for driving in twilight, at night, or under dull conditions. Prescription lenses are also available for the Lucia frame, both online and in-store.
### What Material is Used for the Rim of Oscar Wylee's Lucia Glasses?
The material used for the rim of Oscar Wylee's Lucia glasses frames is acetate. The rim refers to the part of a glasses frame that holds the lenses.
### What Type of Hinges are Included with Oscar Wylee's Lucia Glasses?
The type of hinges included with Oscar Wylee's Lucia frames are normal hinges, also known as standard or barrel hinges. These provide strength and smooth movement connecting the frame's arms and lenses.
## What Face Types are Most Suitable for Oscar Wylee's Lucia Glasses?
The face types most suitable for Oscar Wylee's Lucia frame are square, oval, heart, pear, and diamond face types. The Lucia frame is an oval and round shape, meaning it complements the structure of square, oval, heart, pear, and diamond faces particularly well. The oval and round Lucia frames help to balance the features of a [square face shape](https://www.oscarwylee.com.au/glasses/face-shapes/square), an [oval face shape](https://www.oscarwylee.com.au/glasses/face-shapes/oval), a [heart face shape](https://www.oscarwylee.com.au/glasses/face-shapes/heart), a [pear face shape](https://www.oscarwylee.com.au/glasses/face-shapes/pear), and a [diamond face shape](https://www.oscarwylee.com.au/glasses/face-shapes/diamond), bringing the eyes and brows forward in a flattering way. Although there are many different [glasses for face shapes](https://www.oscarwylee.com.au/glasses/face-shapes) that may be considered more aesthetically suitable, it is important that people also choose frames that make them feel most comfortable and represent their personal style.
## What Size Options are Available for Oscar Wylee's Lucia Glasses?
The size option available for Oscar Wylee's Lucia frame is a medium-fit frame.
## What Materials are Used to Create Oscar Wylee's Lucia Glasses?
The materials used to create the Oscar Wylee Lucia frame are acetate and stainless steel. Acetate, also known as cellulose acetate, is a bioplastic made from cotton fibres or wood pulp. At Oscar Wylee, acetate glasses are made by adding a dye to cellulose acetate, which is rolled into a sheet. The shape of the glasses is then cut from this sheet. Stainless steel is a type of metal commonly used for glasses that is lightweight, durable and corrosion-resistant.
## What’s Included
## OW Case &amp; Cloth
Protective Case and Lens Cloth
Our high-quality glasses case and lens cloth are included with every purchase of an Oscar Wylee frame. The stylish, magnetic case is made from a hard shell. This sturdy and durable material keeps your glasses protected and safe, wherever you go. Ensure your lenses are clean and scratch-free with our OW microfibre cloth, specifically designed to ensure you have comfortable vision through your lenses.
Oscar Wylee offers:
* Free Shipping on all orders
* 1 Year Warranty on frames and lenses
* Scratch resistance lens coating on all prescriptions
* UV-proof coating on all prescriptions
Health fund rebate: Once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. Learn more about [health funds](https://www.oscarwylee.com.au/health-funds.html).
## Make and Materials
Our frames go through numerous stages of production and are hand-polished to ensure a glorious lustre. Featuring a mix of high-quality acetate and polished metal, these mixed materials frames are sure to enhance your eyewear collection.The frames then go through cleaning and strict quality control, and many pairs of crafting hands to be hand-assembled and polished. The frames then go through cleaning and strict quality control, and many pairs of crafting hands to be hand-assembled and polished.After your frames have gone through the production process, they are individually examined and packed before making their way to you!
## Warranty Information
### Warranty Information
### Warranty Information
Oscar Wylee provides a 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects. We will repair or replace faulty or defective frames or lenses free of charge for warranty claims made within 1 year of the delivery. We also offer repairs or replacement for problems experienced with vision during everyday use for claims made within 30 days of delivery. If the same product has been discontinued or is no longer available, then we may offer an exchange for a similar product or a refund.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Find a Store Location](https://www.oscarwylee.com.au/locations/full-store-list.html)