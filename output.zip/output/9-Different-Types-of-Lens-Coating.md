# Source: https://www.oscarwylee.com.au/glasses/lens-coating

# 9 Different Types of Lens Coating
Published on October 9th, 2024
Updated on Month Date, 2025 
Australia
[Australia](https://www.oscarwylee.com.au/glasses/lens-coating)
New Zealand

[Canada](https://oscarwylee.ca/glasses/lens-coating)
Canadian French

There are a variety of different lens coatings that a person can add to
their glasses or sunglasses lenses to help with their eye care and
lifestyle needs. Lens coatings are designed to enhance a person’s eyewear
and help them get the most from their frames. The
9 different types of lens coating include anti-reflective coating, blue
light coating, UV400 protection coating, scratch-resistant coating, mirror
coating, hydrophobic coating, oleophobic coating, photochromic coating and
polarised coating. The different types of lens coatings are listed below.
* Anti-reflective coating: Anti-reflective
coating refers to a coating that reduces lens reflection.
* Blue light coating: Blue light coating is a lens coating that cuts how much blue light
enters the eye.
* UV400 protective coating: UV400 protection coating is designed to protect the eyes from UV rays
up to 400 nanometres.
* Scratch-resistant coating:
Scratch-resistant coating is applied to lenses to help prevent
scratches.
* Mirror coating:
Mirror coating is a sunglasses lens that helps to reduce lens
reflection.
* Hydrophobic coating: Hydrophobic coating helps lenses to become more water resistant,
meaning water is less likely to stick to the lens.
* Oleophobic coating:
Oleophobic coating is a coating added to lenses to prevent oil from
sticking to the lens.
* Photochromic coating:
Photochromic coating is a type of lens coating that darkens from clear
to dark when exposed to UV rays.
* Polarised coating:
Polarised coating is a type of lens feature that helps minimise glare
from the sun by cutting light on the horizontal wavelength. Many
manufacturers will use a polarised sheet for this feature, as opposed to
a coating.
Are You Due for an Eye Test?
Book online and our Oscar Wylee optometrists will perform a Medicare bulk
billed eye test to keep your eye health on track.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Definition](#Definition) [Benefits](#Benefits)
[Factors to Consider](#Factors)
[Oscar Wylee Lens Coatings](#LensCoatings)
## 1. Anti-Reflective Coating
Anti-reflective coating is a type of coating that helps reduce the amount of light that reflects
off lenses. Anti-reflective coating is a thin layer applied to the lens that
removes reflections that you may usually see from your glasses.
Anti-reflective coating will help to get rid of halos or glare around
light sources at night time. At Oscar Wylee, basic anti-reflective
coating is included with a blue light filter. Premium anti-reflective
coating will be an additional cost.
## 2. Blue Light Coating
Blue light coating is a type of lens coating that helps to reduce the amount of blue light
that reaches the eye. Blue light is a type of visible light that can be natural and
emitted from the sun, or artificial, emitted from computer and phone
screens and LED light bulbs. The exact impact of long-term blue light
exposure on eye health is still under investigation, however it has
been theorised that blue light may cause digital eye strain, dry eye,
disruption to sleep patterns and has the potential to damage retinal
cells. According to UC Davis Health, frequent, long term exposure to
blue light may cause retinal cell damage that leads to eye conditions
such as macular degeneration. [Blue light coating](https://www.oscarwylee.com.au/glasses/eye/blue-light)
aims to reduce the amount of blue light that enters the eye and hits
the retina. According to a 2017 study titled ‘Blue-Light Filtering
Spectacle Lenses: Optical and Clinical Performances’, blue light
lenses may theoretically reduce the phototoxicity of blue light by
10.6 - 23.6% , with phototoxicity referring to irritation caused by UV
or blue light. At Oscar Wylee, our blue light filter is built into the
lens material, as oppose to a coating.
## 3. UV400 Protection Coating
UV400 protection coating refers to a lens coating that protects the eyes from UV rays up to
400 nanometres (nm). UV rays are a type of light emitted from the sun. UV light can be
harmful to the eyes if they are exposed to it for extended periods of
time. Extended exposure to UV can lead to eye issues such as growths
on the eye, cataracts and potentially eye cancer such as ocular
melanoma. [UV400 protection](https://www.oscarwylee.com.au/glasses/eye/uv-400-protection)
coating helps to prevent damage from UV exposure by providing a
barrier between the eyes and UV rays. At Oscar Wylee, all glasses come
with UV400 coating for no additional cost.
## 4. Scratch-Resistant Coating
Scratch-resistant coating refers to a lens coating that helps to prevent scratches on the lens
of glasses. Scratch-resistant coating works by making the glasses harder and
therefore less prone to scratches than a softer lens.
Scratch-resistant coatings do not guarantee that lenses will not be
scratched, but may help to prevent. At Oscar Wylee, all glasses come
with scratch-resistant coating.
## 5. Mirror Coating
Mirror coating is a
sunglasses lens coating that helps prevent light reflection on
lenses. Mirror coating is another type of anti-reflective coating, meaning
that its main purpose is to reflect light from a lens, helping to
reduce glare and make vision clearer. The difference between
anti-reflective and mirror coating is that anti-reflective coatings
are typically clear, whereas a mirror coating may look more solid from
others' perspectives. Mirror coatings can also be different colours.
For information on Oscar Wylee mirror coatings, see our team in store.
For more on lens colours, read
[Sunglasses Lens Colour Guide: Differences and How to Choose the
Right One](https://www.oscarwylee.com.au/glasses/sunglasses-lens-colour).
## 6. Hydrophobic Coating
Hydrophobic coating is a type of lens coating that helps to prevent water from sticking to a
lens.
Hydrophobic coatings make lenses water-resistant, meaning water will
not attach to a lens as easily. The hydrophobic coating makes it
easier to keep lenses clean and well taken care of. Hydrophobic
coating is included with Oscar Wylee anti-reflective lenses for an
additional cost.
## 7. Oleophobic Coating
Oleophobic coating refers to a lens coating, similar to hydrophobic coating, that helps to prevent
oils from sticking to a lens. Oleophobic makes lenses more resistant to oils, making it harder to
smudge or get fingerprints on a lens. Oscar Wylee does not sell
oleophobic coatings.
## 8. Photochromic Coating
Photochromic coating refers to a type of lens coating that turns from clear to dark when
exposed to UV rays from the sun. A photochromic lens is coated with a chemical that reacts with
sunlight, darkening a clear coating to dark sunglasses tint. When a
person goes back inside or under cover where UV light cannot right the
lenses, they will go back to clear. The purpose of the photochromic
coating is convenience. [Photochromic lenses](https://www.oscarwylee.com.au/glasses/eye/photochromic-lenses)
mean a person does not need to change between prescription glasses and
sunglasses, as they exist within the same pair of lenses. At Oscar
Wylee, our photochromic lenses are also referred to as adaptive
lenses.
## 9. Polarised Coating
Polarised coating refers to a lens feature that helps to minimise sun glare, also helps
to provide UV protection. [Polarised lenses](https://www.oscarwylee.com.au/glasses/eye/polarised-lenses)
are made from specific chemicals that help to stop horizontal light
from entering through the lens, thus lessening the effects of glare
from the sun. Polarisation can be a coating, but is often a sheet
applied to lenses. Polarisation is good for cutting glare from roads,
water and snow. At Oscar Wylee, we have polarisation available. See
our website or visit our store for more information.
## What is Lens Coating?
A lens coating refers to a coating that is applied to the top of a glasses or
sunglasses lens. [Lens coatings](https://www.oscarwylee.com.au/glasses.html)
can include a range of different coatings with different purposes,
including photochromic coating, blue light coating, UV400 protection
coatings and anti-reflective coating.
### What is the Importance of Lens Coating?
The importance of lens coating depends on individual eye care needs and the purpose of the coating
chosen. Blue light coating, for example, is not an essential coating for
eye health but can be important for those looking at screens for a
long time, as it can help protect the eyes from blue light. UV400
coating is an important lens coating for all people to have,
regardless of eye care needs, as it protects the eyes from UV rays.
Prolonged exposure to UV rays can have negative effects on the
eye.
### Can you have Multiple Lens Coating on Glasses?
Yes, you can have multiple lens coatings on glasses.
People can have multiple coatings on glasses to help cater for their
eye care needs. For example, a person may have a blue light coating
and anti-reflective coating, to help limit blue light entering the
eye and limit light reflection on glasses. Not all coatings will
work together however, such as photochromic and mirror
coatings.
Find an Oscar Wylee Store Near You
Come and visit your local Oscar Wylee store where our friendly team
will help you shop our range of stylish and affordable frames, and
assist with your eye care needs.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
## What are the Benefits of Lens Coating in Glasses
There are several common problems that different lens coatings can help to
address. Photochromic lens coating helps to address issues of convenience
for those who need prescriptions for both glasses and sunglasses. With
photochromic lens coatings, people don't need to change between
sunglasses and glasses as the lens do this for them. Blue light
coating can help to address digital eye strain and fatigue by limiting
the amount of blue light entering the eye.
## What are the Factors to Consider When Choosing Lens Coating for Glasses?
The
benefit of lens coatings in glasses is that they allow a person to
customise their glasses to meet their individual eye needs. A person with a prescription for all distances, who doesn't want to
switch between glasses and sunglasses, can use photochromic coating so
they can have both eyewear in one pair. Some coatings, like UV400
protection and anti-reflective, are beneficial for all regardless of
individual eye care needs. UV400 protection helps protects the eye
from UV rays and anti-reflective can limit glare and reflection on
glasses, helping a person see clearer.
* Individual eye care needs: It is
important to consider individual eye care needs when choosing lens
coatings. Those with a prescription should consult with an optometrist
or knowledgeable retail team member on what lens coatings can help
them get the most use from their optical glasses.
* Lifestyle needs:Lifestyle needs is an important thing to
consider when choosing glasses lenses as not all coating will be
suitable. People who don't have prescriptions or don't spend time in
front of the computer may have no need for blue light or
[transition lenses and photochromic glasses](https://www.oscarwylee.com.au/glasses/eye/photochromic-lenses). Those who spend lots of time outside may benefit from polarisation
coating.
* Costs: Cost is an important factor to consider when choosing lens coatings
as most lens coatings are typically an additional cost on top of the
prices of a frame. Be sure to check with your retailer regarding the
cost of coatings.
### How to Choose Lens Coating for Glasses from Oscar Wylee?
The best way to choose lens coatings for glasses from Oscar
Wylee
is to come into store to speak with our knowledgeable retail
team. Speak with our retail staff who can give you information on the
lens coatings we have and their cost. You can also read one of our
webpages on the
[8 different types of lenses for glasses](https://www.oscarwylee.com.au/glasses/eye/types-of-lenses). Oscar Wylee has several pages across our website dedicated to
informing people about the different types of coatings we provide,
including
[polarisation](https://www.oscarwylee.com.au/glasses/eye/polarised-lenses),
[UV400 protection](https://www.oscarwylee.com.au/glasses/eye/uv-400-protection)
and
[photochromic lenses](https://www.oscarwylee.com.au/glasses/eye/photochromic-lenses).
### How to Look After Coated Lenses?
The way to look after coating lenses is the same as any other type of lenses or glasses you have. The best way to look after your glasses and their lenses is to
keep your glasses clean, making sure there is no dust, dirt or
debris build up. It is also recommended that you keep your glasses
and their lenses safe by not leaving them on your head where they
could fall off, or leaving them face down where they may be
scratched. You should also not leave glasses in the car, hanging
from clothes, and should always handle them with two hands. These
measures will help to protect your glasses and their lenses from
scratches, smudges and breakages.
Read 9 Different Types of Lens Coating in other Oscar Wylee regions
and their languages.
Australia
[Australia](https://www.oscarwylee.com.au/glasses/lens-coating)
New Zealand

[Canada](https://oscarwylee.ca/glasses/lens-coating)
Canadian French

Oscar Wylee Accepts Major Health Funds In-store
Visit Oscar Wylee in-store for eye care services and your health fund
may help cover some of the cost.
[Explore Health Funds](https://www.oscarwylee.com.au/health-funds.html)
Book an Oscar Wylee Eye Test
We recommend that everyone should have an eye test with an optometrist
at least once every 2 years.
[Book an eye test](https://www.oscarwylee.com.au/booking)