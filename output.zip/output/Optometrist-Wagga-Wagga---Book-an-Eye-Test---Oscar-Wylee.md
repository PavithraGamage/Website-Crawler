# Source: https://www.oscarwylee.com.au/locations/optometrist-wagga-wagga.html

# Optometrist Wagga Wagga
You may have noticed our Oscar Wylee Orange store has closed, but
your eye care journey with us continues.
You can still visit another Oscar Wylee store for eye health services,
we have your details on file, or browse our latest frames online.
We apologise for any inconvenience and appreciate your continued
support.
Wagga Wagga Marketplace
Shop 49, 87 Baylis Street
Wagga Wagga
NSW 2650
Opposite Priceline
Opening hours
Monday9:00am - 5:30pm
Tuesday9:00am - 5:30pm
Wednesday9:00am - 5:30pm
Thursday9:00am - 7:00pm
Friday9:00am - 5:30pm
Saturday9:00am - 4:00pm
Sunday10:00am - 4:00pm
*Store hours reflect local standard trading hours and exclude public
holidays
Visit our Wagga Wagga Google Business page for directions,
reviews, and updates.

Book Appointment
Our Reviews
David Waldock
1 month ago
Great experience. Very friendly staff.
amy fulham
2 months ago
Lovely staff
Fiona Gregurke
3 months ago
Amanda Sutton
3 months ago
molly
3 months ago
Susan Colley
4 months ago
I had the best experience. Customer service was fantastic, eye test was timely and everything explai...ned beautifully.
Couldn’t recommend more highly!
Ended up with 2 pairs of glasses that I LOVE!!
See more
Sheridan Hughes
4 months ago
Very friendly staff and good quality products
R G
4 months ago
Really lovely store staffed by lovely people. They've gone above and beyond for me more than once!
Nathan
5 months ago
Max M
5 months ago
Lovely experience throughout the entire process. I was assisted in selecting the style to best suit ...me, encouraged to volley my opinions about frame options, and given great advice about the pros and cons of their range.
After a few minor tweaks and adjustments, the glasses felt superbly snug.
Kudos to Ree for guiding me through each step with her expertise and warm manner. Truly a phenomenal job, as I originally walked into the store with the intention of just browsing, but was won over by the service provided.
See more
Wendy Smith
6 months ago
Ray Vincent
6 months ago
The staff at the Waggga provided excellent setvice
Robyn Sweeney
8 months ago
Prompt attention for my Fitness to Drive test (my first).  Amani was terrific and answering my many ...questions as we went along (I have not long had cataract surgery and this has changed my vision quite a bit). I am still wearing my old progressive lens glasses which is a bit of a juggle with changed vision but we worked out the best temporary strategy.
I will be visiting Oscar Wylee again once my second eye has had surgery - for my new appropriate glasses.
See more
Glenda Clemson
9 months ago
Excellent service..professional caring optometrist
Reviews by ST
10 months ago
The appointment was on time, and the front desk staff were very helpful throughout. The optometrist ...was patient, clearly explaining everything as she went through the checks. To keep things budget-friendly, the store only carries its own brand, limiting the selection of frames and designs somewhat. But there’s still a decent variety to choose from. Plus, it’s conveniently located in the Wagga Marketplace, right across from Priceline.
See more
Sach T
10 months ago
The appointment was on time, and the front desk staff were very helpful throughout. The optometrist ...was patient, clearly explaining everything as she went through the checks. To keep things budget-friendly, the store only carries its own brand, limiting the selection of frames and designs somewhat. But there’s still a decent variety to choose from. Plus, it’s conveniently located in the Wagga Marketplace, right across from Priceline.
See more
Amity// Bell
10 months ago
Jacob Hooper
10 months ago
Glenn Fahey
10 months ago
Very friendly and helpful staff, very thorough in what they done,highly recommended.
Diane gavan
11 months ago
Janette Haddon
11 months ago
Very well conducted
Bridgett Barr
1 year ago
The girl who helped me (I think her name was Lily?) was absolutely amazing, very helpful &amp; kind and ...helped me get sorted. The optometrist explained things very clearly as well. Cannot fault the whole process.
See more
Pookie Reece
1 year ago
Great staff and service. Highly recommend.
Gloria Lowey
1 year ago
The staff are very friendly and exstremely helpful.  The optomotrist was very pleasant as well.  Tha...nk you to all.
See more
Lily Knight
1 year ago
Very thorough eye examination. Excellent explanations of all aspects of eye test.
kylie Mayor
1 year ago
Rebecca Naumoski
1 year ago
Great service, both ladies explained everything, were very helpful and a pleasure to deal with. Woul...d happily recommend this business.
See more
Julianne Halden
1 year ago
From the time I arrived for my appointment I felt very welcomed by the friendly front office staff m...ember (sorry, cannot remember her name). She was so welcoming and confident in her role.
All my paperwork was up to date and only had to add my Medicare card details. I was then ushered to the rear of the room to undergo a few simple tests conducted by the receptionist. I was asked then to take a look around at styles available until the Optometrist was ready for me. I had a quick look and then the Optometrist took me in for my eye test. This was completed promptly and it was established that I needed an upgrade in my glasses.
Very happy with the service and can't wait for my new glasses to arrive!
See more
Rebekah Barton
1 year ago
Fantastic!!! The doctor there spotted a hole in my eye and contacted emergency straight away. Can no...t thank them enough for literally saving my vision
See more
lyn cowan
1 year ago
Went to the Wagga Wagga store 2/05/25. The meet and greet was excellent and the optometrist was know...ledgeable and very thorough. The overall experience was excellent.
See more
Louise Wheaton
1 year ago
Awesome service .. made it so easy to pick frames .. awesome prices too!
Wayne Ambrose
1 year ago
Elizabeth Hope
1 year ago
I was very happy with the way I was treated, the staff were very friendly and helpful, way to go Osc...ar Wylee keep up the good work ????
See more
rebeka Lally
1 year ago
Kate Eaton
1 year ago
Super efficient &amp; friendly. Had an eye check &amp; got a few call prior to confirm times &amp; concerns ect.... Staff were very friendly &amp; well informed &amp; the Optometrist was lovely too. Very clear at communicating &amp; felt very at ease.
See more
Tammy Paton
1 year ago
Great optometrist and staff - unfortunately fell short due to having to be referred to another optom...etrist for a scan that they couldn't provide, this should have been disclosed to me as this would have allowed me to make the decision to use Oscar Wylee or somewhere else that had a one stop shop
See more
Millie McLeod
1 year ago
Amazing customer service!! Thank you! Very happy!
Not maree
1 year ago
Was great. Quick and simple no waiting around for ages after your appoitment time like specsavers. S...taff are great and friendly too
See more
Sheryl Ramlall
1 year ago
Exceptional customer service
Rebekka Lake
1 year ago
Marianne Firth
1 year ago
Good experience,  staff were very helpful and friendly. Excellent service.
Vital
1 year ago
Lindi from Oz
1 year ago
My experience was satisfactory, but was unable to be completed, and I have been asked to come back f...or a retinal scan in a fortnight.  See you then.
See more
Sarah Smith
2 years ago
My daughters eye test was a 10/10, the gentleman who tested her eyes was so friendly, patient and li...stened to all my concerns and answered all my questions.
Experience was a all round 10/10.
See more
Hansa Rathnayake
2 years ago
Marsh
2 years ago
Really great service from the team here
mirjam vd e
2 years ago
The staff is very knowledgeable and friendly. They’ve been a great help
Tracey O'Malley-Tuitavake
2 years ago
Very professional, great glasses, great prices
Vicki Kay
2 years ago
Awesome staff from the time of my eye test till I left the store they were so caring
Michaella Riley
2 years ago
Very patient and kind with my 3.5year old. Made him feel very comfortable and it was an enjoyable ex...perience for him.
See more
## Find an Optometrist in Wagga Wagga With Oscar Wylee
Oscar Wylee Wagga Wagga is located in the heart of the Riverina
Region with a strong outreach to other regional towns such as Junee, Griffith,
Temora and Young. Come visit us at our eyeglasses shop for eye health tests
and same-day prescriptions. Oscar Wylee Wagga Wagga has a wide selection of
optical frames and sunglasses available in unconventional shapes and colours
that are sure to make you stand out in a crowd. Our optometrists at Oscar
Wylee Wagga Wagga are capable of diagnosing eye conditions and eye diseases,
so you can be certain that we take eye care seriously. 
Be
sure to enjoy a relaxing afternoon at Botanical Gardens while you’re here with
its miniature railway and Zoo/Open Air Aviary or at Wagga Beach, nestled on
the edge of the Murrumbidgee River. Utilise the free 3-hour parking at the
Wagga Wagga Marketplace or any of the nearby parking facilities off Baylis
Street. If travelling by public transport, buses operated by Busabout Wagga
will drop you right at the Baylis Street entrance to the Wagga Wagga
Marketplace.        
Meet Our Team
Our Services
* Bulk Billed Eye Examinations
* Professional Frame Styling
* Frame Adjustments and Repairs
* Visual Fields Testing
* Glaucoma
* Macular
Degeneration and Cataract Assessments
Show All
## Find an Optometrist in Wagga Wagga, NSW for an Eye Health Test
An optometrist in Wagga Wagga, NSW is capable of providing
prescription sunglasses as well as prescription glasses. At
Oscar Wylee you can get an eye health test in Wagga Wagga at a
bulk billed price thanks to Australia’s Medicare system. When
you visit us in-store, you can see our optical dispenser for any
eyewear-related concerns or browse through our selection of
frames. If you need an eye doctor, our team will happily refer
you to one in the area.
Your vision health is important to us so let us help you stay up
to date with regular eye tests, which is important in the early
detection of eye diseases. The average price for an optometrist
in Wagga Wagga may depend on factors such as the number of other
optometrists in Wagga Wagga, the facility they operate in and
the required equipment.
## How to Find an Optometrist in Wagga Wagga, NSW?
To find an optometrist in Wagga Wagga, NSW you can take certain
steps that can help make it easier for you such as
searching online, assessing the store’s opening hours and
finding the directions to your chosen location. The steps on how to find an optometrist in Wagga Wagga are
listed below.
1. Search online using the phrase, Wagga Wagga optometrist near
me. This can also be done here on the website via our
locations page.
2. Click on the Oscar Wylee link, which will take you directly to
our Wagga Wagga optometrist store page.
3. See the store’s opening hours and where the store is located
specifically.
4. Use the Wagga Wagga Google Business page link located under
store hours to see the directions on how to get to the store
You can also find an optometrist in Wagga Wagga by searching the
keywords optometrist near me. If you have locations enabled on
your smartphone and you’re in the Wagga Wagga area, our Wagga
Wagga store page should appear easily for you to click on.
### Is it Hard to Get an Eye Appointment in Wagga Wagga, NSW?
No, it is not hard to get an eye appointment in Wagga Wagga. You
can easily book an appointment to see an Oscar Wylee optometrist
in Wagga Wagga right here on this page. At Oscar Wylee we have
highly qualified optometrists available for bulk billed eye
appointments, which can be booked online or in-store.
#### How to Compare Optometrists in Wagga Wagga to Each Other?
To compare optometrists in Wagga Wagga, you can use factors such
as eye
tests offered, health fund coverage, lens types and add-ons
and eyewear offered. To take care of your vision and eye health, it is important
to receive an eye test at least once every two years. There are
different types of tests that can be performed in an eye test
and not all optometrists may offer the same tests. Health funds
can be used to help cover some of the cost of your frames and
lenses. To find out if your health fund is accepted at Wagga
Wagga optometrist in NSW , visit their website. In the case of
Oscar Wylee, we accept all major health funds and provide
on-the-spot claims in-store. There are many different lens
options available for prescription glasses such as single
vision, multifocal and high index lenses. Most optometrists in
Wagga Wagga will offer these lenses although it is good to make
sure. There are also lens add-ons available to enhance your
glasses such as anti-reflective and blue light filters. Finally,
if you are looking to purchase a pair of glasses after your eye
test, you can compare the different styles and colours you are
interested in from Wagga Wagga optometrists in NSW. Oscar Wylee
offers a wide range of frames with vintage and modern
inspirations in bold colours and subtle designs.
#### How to Find an Eyeglasses Shop in Wagga Wagga, NSW?
To find a glasses store in Wagga Wagga, you can try to follow
these simple steps including
searching online, selecting a convenient location and looking
at their health insurance policies. The steps on how to find a glasses store in Wagga Wagga, NSW
are listed below.
1. Search online using the phrase, glasses store in Wagga Wagga.
This will provide you with various options for glasses stores
in the whole area of Wagga Wagga.
2. Select a glasses store that is most convenient for you to
travel to.
3. Click the link to find out more information such as opening
hours, exact location and directions to the glasses store in
Wagga Wagga.
4. Read their health insurance policies to ensure you know what
health benefits you have access to.
Our Oscar Wylee glasses store in Wagga Wagga, NSW offers primary
eye care services such as comprehensive eye tests as well as
other services performed by an optometrist and offers
prescription and non-prescription eyewear.
##### Is it Possible to Purchase Prescribed Sunglasses in Wagga Wagga,
NSW Without Seeing an Optometrist?
Yes and no, it is possible to
[purchase prescribed sunglasses](https://www.oscarwylee.com.au/sunglasses.html)
in Wagga Wagga, NSW without seeing an optometrist if you already
have a prescription that has not expired. If your prescription
is expired, you can book an eye test to receive an updated or
new prescription which will require you to see an optometrist.
This will ensure your prescription sunglasses are appropriate
for your visual needs.
## Where is the Oscar Wylee Wagga Wagga Optometrist in NSW Located?
The Oscar Wylee Wagga Wagga optometrist is located at the
Marketplace Shopping Centre which can be found at 87 Baylis
Street. The Oscar Wylee Wagga Wagga store is positioned opposite
Priceline.
What is the Phone Number of Oscar Wylee Wagga Wagga Optometrist
Store?
The Oscar Wylee Wagga Wagga optometrist store phone number is
(02) 6900 2314. You can contact
the Oscar Wylee Wagga Wagga store between the hours of 9:30 am
and 5:30 pm on Monday, Tuesday, Wednesday and Friday, on
Thursdays between 9 am and 7 pm, on Saturdays between 9 am and 4
pm and on Sundays between 10 am and 4 pm.

### What are the Reviews for Oscar Wylee Wagga Wagga Optometrist in
NSW?
The many reviews for Oscar Wylee Wagga Wagga optometrist in NSW,
left by our various customers can be found here on the website
and online when you search for Oscar Wylee Wagga Wagga
optometrist. The reviews for Oscar Wylee Wagga Wagga optometrist
are listed below.
* Catarina Catherine Smith:  Very comfortable and the
staff were nice and polite and explained it all and what was
going to happen, thank you.
* Kerry Connors:  Very happy.
* Abby Jayne:  Went in for a chat about potentially
getting glasses and the casual Monique who greeted me was
amazing. Very thorough and kind, knows her stuff really well.
Would absolutely go back when I need frames.
* Kelly Garlick:  Friendly service and minimal wait time.
Eye assessment seemed thorough.
#### What Treatments or Eye Care Processes are Done in the Oscar Wylee
Wagga Wagga Optometrist Location?
The treatments or eye care processes done in the Oscar Wylee
Wagga Wagga optometrist NSW location include
a tonometry test, a slit lamp exam and a refraction test.
Additional tests that may also be performed can include
visual field tests and a dilated fundus exam. The
treatments or eye-care processes that are done in the Oscar
Wylee Wagga Wagga optometrist NSW location are listed below.
* A Tonometry Test: An optometrist or optical dispenser
will conduct a tonometry test which involves the use of a
machine that will release small puffs of air into your eyes.
This will assist with measuring pressure in the eye.
* Slit Lamp Test: A slit lamp test can be used to
evaluate your eye health, by examining your cornea and iris
which are the anterior and posterior of the eye.
* Refraction Test: During a refraction test, an
optometrist will have you view an image through different
lenses and ask you to confirm which helps you see the image
clearer.
* Visual Field Test: A visual field test can assist with
assessing your peripheral vision, which may be beneficial for
identifying any signs of glaucoma.
* Dilated Fundus Exam: A dilated fundus exam can help an
optometrist assess your health in more detail by getting a
clear view of the retina. This test is typically carried out
for patients with diabetes and those who may be at risk of
developing retinal damage.
## How Many Optometrists Exist in Wagga Wagga, NSW?
Many Oscar Wylee optometrists exist in Wagga Wagga, NSW to
provide eye tests and glasses, including Oscar Wylee. The number
of optometrists in Wagga Wagga may be due to the number of
residents in the area and the geographical size of the suburb.
If you need essential eye services such as a comprehensive eye
test, a wide selection of prescription eyewear and more, then
choose Oscar Wylee as your first choice for optometry services.
### What are the Other Closest Optometrist Locations to Wagga Wagga,
NSW in Australia?
There are no other Oscar Wylee optometrist locations close to
Wagga Wagga in Australia, however, we have many stores in New
South Wales, Queensland, Western Australia and Victoria. If you
are looking for an optometrist near you, you can find the
locations of our many stores on our
[full store locations page](https://www.oscarwylee.com.au/locations/full-store-list.html).
### Bulk Billed Eye Tests at Oscar Wylee
We have experienced optometrists performing quality eye tests for
health and vision at our Oscar Wylee Wagga Wagga store. Make an
in-store visit and have your prescription updated and shop for a new
pair of eyeglasses on the same day. Our optometrists at Oscar Wylee
Wagga Wagga want to prioritise your eye health. With the
recommendation of having your eyes tested at least once every two
years, we will work to help you keep up to date!
### Health Funds Accepted at Oscar Wylee Wagga Wagga
Here at Oscar Wylee Wagga Wagga, major health funds are accepted. Our
experts at Oscar Wylee Wagga Wagga can process your claim at our
eyeglasses shop with a valid health fund card. We can also help you
through the ins and outs of your insurance to make certain that you’re
getting the best price every single time for all of your prescription
glasses needs.
### Fashion-Forward Glasses at Wagga Wagga
Here at our Oscar Wylee Wagga Wagga store, you can count on us to
provide modern and vintage-style frames that are affordable. You might
want to customise your glasses with add-ons such as an anti-reflective
coating, a blue light filter, and more from our range. Our Oscar Wylee
Wagga Wagga store experts will help you select what’s best for you,
and you’ll walk out of our store with a pair of prescription glasses
or prescription sunglasses that will perfectly align with you and your
vision needs.
Book Appointment