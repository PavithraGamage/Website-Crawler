# Source: https://www.oscarwylee.com.au/bishop-optical.html

# Bishop
1
## Frame Design of Bishop Glasses
The frame design of Oscar Wylee’s Bishop glasses is characterised by their rectangle shape, nose pads and a stainless steel and acetate frame. The Bishop frame is a men’s, classic glasses frame that will work for any occasion, whether the wearer wants to liven up their work style or complement a fun outfit for a night out.
$169    
In stock
Only %1 left
2 pairs from $199
Discount auto-applied at checkout
3 pairs from $249
Discount auto-applied at checkout
Qty
Add to cart
Book an eye test
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
excluding prescription lenses
## About Bishop Frames
Bishop’s sleek and sharp lines make a bold statement. The understated metals allow the unique design to truly shine. Spring hinges, adjustable nose pieces and acetate tips provide comfort to this unique frame.
| Frame fit | Measurements |
| --- | --- |
| MEDIUM | 53 - 21 - 145 |
These measurements mean lens width, bridge, and temple length in millimetres (mm). They can be found on the inside of the temple arm. If you already have a pair that you like, you can compare it to these measurements.
### Made from Stainless Steel
Oscar Wylee’s Bishop frame is a men’s, rectangle glasses frame that is perfect for those with round and oval face shapes. The Bishop frame is a stylish, widely wearable frame that can be worn every day. The main specs of Oscar Wylee’s Bishop glasses frame including dimensions, shape, materials, lenses, nose fit and hinges are listed below.
| Bishop Frame Features | Bishop Frame Description | Dimensions | Shape | Materials | Lenses | Nose Fit | Hinges |
| --- | --- | --- | --- | --- | --- | --- | --- |
| The dimensions of the Bishop frame are measured in millimetres (mm) and are 53 - 21 - 145, meaning the lens width is 53 mm, the bridge is 21 mm and the temple length is 145 mm. |
| The Bishop frame is a rectangular shape, well suited to medium faces. |
| Bishop glasses are made from stainless steel and acetate. |
| The lenses that can be used in the Bishop frame are optical lenses, which include single vision and multifocal lenses and non-prescription lenses, which are plain and can have a filter like a blue light filter applied. |
| The Bishop frame is fitted with adjustable nose pads. |
| The hinges in Bishop glasses are spring hinges, which are more flexible than other types of hinges and can extend past 90 degrees. |
Show All
### What Inspired the Frame Design of Oscar Wylee’s Bishop Glasses?
The Oscar Wylee Bishop frame design was inspired by current fashion trends as rectangle glasses shapes are often in fashion.
## What to Know About Oscar Wylee’s Bishop Glasses?
There are many aspects of the Oscar Wylee Bishop frames that customers should know about, so they can decide whether this is the right frame for them. The Bishop frame is a men's rectangular glasses frame. Oscar Wylee’s Bishop frame is suitable for many face shapes but particularly compatible with round and oval face shapes. The Bishop frame’s simple design means that they are fashionable all year round. Bishop glasses feature the standard [parts of glasses](https://www.oscarwylee.com.au/glasses/eye/part-of-glasses) such as a rim, temples, lenses, spring hinges and nose pads.
### What are the Types of Temple Tips or Earpieces Included with Oscar Wylee’s Bishop Glasses?
The type of temple tips or earpieces included in Oscar Wylee’s Bishop Glasses are made from acetate.
### What Type of Nose Bridge do Oscar Wylee’s Bishop Glasses Have?
The type of nose bridge included in Oscar Wylee’s Bishop frame is nose pads.
### What Type of Nose Pads are Included with Oscar Wylee’s Bishop Glasses?
Oscar Wylee’s Bishop includes standard nose pads. Nose pads are great for comfort and can also be adjusted for the perfect fit.
### What Type of Lenses do Oscar Wylee’s Bishop Glasses Have?
The type of lenses that typically come with the Oscar Wylee Bishop [glasses frame](https://www.oscarwylee.com.au/glasses.html) are optical lenses. Optical lenses are glasses lenses that have a prescription within the lens to help correct vision issues such as myopia, hyperopia and astigmatism. Bishop glasses can also come with non-prescription lenses, with add-ons such as a blue light filter. Bishop frames are currently unavailable as sunglasses online, however, customers can customise in-store and add on tint or polarisation.
### What Material is Used for the Rim of Oscar Wylee’s Bishop Glasses?
The material used for the rim of Oscar Wylee’s Bishop glasses frames is stainless steel. The rim refers to the part of a glasses frame that holds the lenses.
### What Type of Hinges are Included with Oscar Wylee’s Bishop Glasses?
The type of hinges included with Oscar Wylee’s Bishop frames are spring hinges. A spring hinge in a glasses frame refers to hinges that are more flexible than normal hinges and can go slightly beyond 90 degrees. Spring hinges can provide a closer fit to the face.
## What Face Types are Most Suitable for Oscar Wylee’s Bishop Glasses?
The face types that are most suitable for Oscar Wylee’s Bishop frame are round and oval face shapes. The Bishop frame is a rectangle shape, meaning that it complements the structure of round and oval faces particularly well. The rectangle Bishop frames help to balance the features of a [round face shape](https://www.oscarwylee.com.au/glasses/face-shapes/round) or an [oval face shape](https://www.oscarwylee.com.au/glasses/face-shapes/oval). Rectangle frames help to add sharper angles and lines to the softer and rounded features of a round and oval face type, highlighting without overemphasising them. Although there are many [glasses for face shapes](https://www.oscarwylee.com.au/glasses/face-shapes) that may be considered more aesthetically suitable, it is important that people also choose the frames that make them feel most comfortable, and represent their personal style.
## What Size Options are Available for Oscar Wylee’s Bishop Glasses?
The size options available for Oscar Wylee’s Bishop frame are a medium -fit frame across all colours.
## What Materials are Used to Create Oscar Wylee’s Bishop Glasses?
The primary materials used to create the Oscar Wylee Bishop frame are stainless steel and acetate. Acetate, also known as cellulose acetate, is a bioplastic, made from cotton fibres or wood pulp. At Oscar Wylee, acetate glasses are made by adding a dye to cellulose acetate, which is rolled into a sheet. The shape of the glasses is then cut from this sheet.
## What’s Included
## What's Included
Each pair of glasses comes with a stylish frame case and lens cloth. We offer free shipping across Australia and 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects.
* Free Shipping for Australian Orders
* 1 Year Warranty on frames and lenses
* Scratch resistance lens coating on all prescriptions
* UV-proof coating on all prescriptions
* Stylish case and cloth
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
## Make and Materials
The frames then go through cleaning and strict quality control, and many pairs of crafting hands to be hand-assembled and polished. After your frames have gone through the production process, they are individually examined and&nbsp;packed before making their way to you!As part of our durable frame family, some of our most popular styles, are now in stainless steel. These frames are hypoallergenic, corrosion resistant, light weight, and not sensitive to temperature changes.
## Warranty Information
### Warranty Information
### Warranty Information
Oscar Wylee provides a 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects. 
We will repair or replace faulty or defective frames or lenses free of charge for warranty claims made within 1 year of the delivery.
We also offer repairs or replacement for problems experienced with vision during everyday use for claims made within 30 days of delivery. If the same product has been discontinued or is no longer available, then we may offer an exchange for a similar product or a refund.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Find a Store Location](https://www.oscarwylee.com.au/locations/full-store-list.html)
Recommended
1. [](https://www.oscarwylee.com.au/logan-optical.html)
[Logan](https://www.oscarwylee.com.au/logan-optical.html)
Primary Blue
2. [](https://www.oscarwylee.com.au/miles-optical.html)
[Miles](https://www.oscarwylee.com.au/miles-optical.html)
Hazelnut Tortoise
3. [](https://www.oscarwylee.com.au/aries-optical.html)
[Aries](https://www.oscarwylee.com.au/aries-optical.html)
Champagne