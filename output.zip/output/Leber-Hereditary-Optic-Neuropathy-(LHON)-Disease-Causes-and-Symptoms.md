# Source: https://www.oscarwylee.com.au/glasses/eye/leber-hereditary-optic-neuropathy-lhon-disease

# Leber Hereditary Optic Neuropathy (LHON) Disease: Causes and Symptoms
Published on March 9th, 2026
Updated on March 21st, 2025 
Australia
Australia
New Zealand
Canada
Canadian French

Leber Hereditary Optic Neuropathy (LHON) is
a genetic disease that can cause sudden vision loss. Leber
Hereditary Neuropathy Disease is caused by genetic mutations in the
mitochondrial DNA, according to the Centre for Eye Research Australia.
Symptoms of Leber Hereditary Optic Neuropathy start with sudden blurring of
vision, usually beginning in one eye. Leber Hereditary Optic Neuropathy
affects daily visual function, as central vision is needed for everyday
tasks such as reading, driving, and recognising people. There is no
definitive cure for Leber Hereditary Optic Neuropathy, and management
focuses on helping people with their vision loss. Glasses don’t usually
help, improve, or stop vision loss, according to the Mito Foundation.
Different kinds of glasses, such as specialised lenses, tints, and low
vision aids, can significantly improve visual comfort and function for those
with Leber Hereditary Optic Neuropathy by enhancing contrast, reducing
glare, and maximising remaining peripheral vision.
Prioritise Your Eye Health
Our team can help you stay up to date with regular eye tests to keep your
eyes healthy!
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Definition](#definition)
[Causes](#causes)
[Symptoms](#symptoms)
[Treatments](#treatments)
## What is Leber Hereditary Optic Neuropathy (LHON) Disease?
Leber Hereditary Optic Neuropathy Disease is
a rare genetic mitochondrial disease that can cause sudden central
vision loss.
Mitochondria are the powerhouse of the cell, and when they are not
working properly, reduced energy production can lead to the death of
retinal ganglion cells, which convey visual information to the brain,
according to Retina Australia. Mutations in the MT-ND1, MT-ND4, or
MT-ND6 genes can cause Leber Hereditary Optic Neuropathy. Leber
Hereditary Optic Neuropathy directly affects the
[optic nerve](https://www.oscarwylee.com.au/glasses/eye/anatomy/optic-nerve)
and causes it to degenerate, leading to rapid, often permanent, loss of
central vision. The disease can affect anyone, but it often appears in
young adults, primarily young males, and progresses quickly, according
to Dr A. Shemesh’s research article titled ‘Leber Hereditary Optic
Neuropathy (LHON)’ in 2024. Potential risk factors include smoking,
alcohol use, and exposure to environmental toxins.
### How does LHON Affect the Optic Nerve and Central Vision?
Leber Hereditary Optic Neuropathy
directly affects the optic nerve fibres, which are responsible for
central vision
by carrying visual information from the eye to the brain. The optic
nerve is composed of the axons of the retinal ganglion cells, which
transmit visual signals from the eye to the brain. This signal is
damaged in the swollen optic nerve, where retinal ganglion cells are
harmed and, as some of these cells die, the optic nerve atrophies,
according to the United Mitochondrial Disease Foundation. The
atrophied optic nerve reduces the amount of information sent from the
brain to the eye and leads to blurred or blind central vision. Most of
the time, a person with Leber Hereditary Optic Neuropathy does not go
completely blind but will retain their peripheral or ‘side’ vision,
according to the Centre for Eye Research Australia.
#### Is Leber Hereditary Optic Neuropathy Considered a Type of Optic
Neuropathy?
Yes, Leber Hereditary Optic Neuropathy is a
type of hereditary optic neuropathy. Leber
Hereditary Optic Neuropathy is a rare, genetic disease that damages
the optic nerve and often leads to selective destruction of the
retinal ganglion cells and permanent central vision loss. The
condition is a mitochondrial disorder caused by mitochondrial
dysfunction. When the retinal ganglion cells die, the optic nerve
deteriorates, and information sent from the eye to the brain is
diminished, leading to blurred vision or potentially blindness.
##### Can LHON Cause Colour Vision Deficiency?
Yes, Leber Hereditary Optic Neuropathy
commonly causes colour vision deficiency. People
with Leber Hereditary Optic Neuropathy often struggle to
distinguish red and green early on, and those with a severe case
may experience a blue-yellow deficit, according to ophthalmologist
Dr. Peter A. Quiros’s study titled ‘Colour vision defects in
asymptomatic carriers of the Leber’s hereditary optic neuropathy
(LHON) mtDNa 11778 mutation from a large Brazilian LHON pedigree:
a case-control study’ in 2006 with over 200 participants.
Disruption of colour discrimination is a primary symptom of Leber
Hereditary Optic Neuropathy, caused by damage to retinal ganglion
cells and their axons, which control central vision pathways.
## What Causes Leber Hereditary Optic Neuropathy?
Leber Hereditary Optic Neuropathy is
caused by inherited gene mutations in mitochondrial DNA, according to Dr A. Shemesh (2024). Mutations in the MT-ND1, MT-ND4,
or MT-ND6 genes can cause Leber Hereditary Optic Neuropathy. Mutations
in mitochondrial DNA disrupt cellular energy production and primarily
affect the high-energy-dependent optic nerve. Retinal ganglion cells in
the optic nerve have a significantly high metabolic activity, being both
‘extremely energy-demanding and fragile neurons’, making them vulnerable
to this energy decrease, according to Dr P. Layrolle’s research article
titled ‘The Optic Nerve at Stake: Update on Environmental Factors
Modulating Expression of Leber’s Hereditary Optic Neuropathy (2024). The
death of retinal ganglion cells leads to optic nerve atrophy and,
therefore, central vision impairment.
### How do Mitochondrial DNA Mutations Lead to Vision Loss in LHON?
Leber Hereditary Optic Neuropathy causes vision loss
due to mutations in optic nerve cells, which reduces adenosine
triphosphate (ATP) production.
ATP is the main molecule for storing and transferring energy in cells.
Reduced ATP production leads to the degeneration of retinal ganglion
cells and their axons, according to Dr U.S. Kim’s research article
titled ‘Leber Hereditary Optic Neuropathy–Light at the End of the
Tunnel?’ (2018). Retinal ganglion cell death directly affects optic
nerve fibres, leading to central vision impairment.
#### Is LHON Inherited Through the Maternal Line?
Yes, Leber Hereditary Optic Neuropathy is
only inherited through the maternal line. Leber
Hereditary Optic Neuropathy is a mitochondrial DNA (mtDNA) disorder,
and mitochondria are only passed to children through the maternal
line. A female with a primary LHON-causing mtDNA variant will
transmit the variant to all of her offspring, according to Dr P.
Yu-Wai-Man’s research article titled ‘Leber Hereditary Optic
Neuropathy’ (1993). Both male and female children can inherit the
disease, but males are significantly more likely to develop
symptoms. Males are four to five times more likely to be affected
than females, according to Dr P. Yu-Wai-Man.
## What are the Symptoms of Leber Hereditary Optic Neuropathy?
Leber Hereditary Optic Neuropathy primarily affects central vision.
Symptoms of Leber Hereditary Optic Neuropathy usually start with a
blurring of central vision in one eye, and affect both eyes within weeks
or months. The symptoms of Leber Hereditary Optic Neuropathy include
a sudden onset of
[blurred central vision](https://www.oscarwylee.com.au/glasses/eye/blurred-vision)
(usually beginning in one eye), a growing central blind spot (central
scotoma), colour vision loss, contrast sensitivity loss, and optic
atrophy.
The symptoms of Leber Hereditary Optic Neuropathy are listed below.
* Blurred central vision: Blurred
central vision often appears suddenly, and vision deteriorates
rapidly, leading to central vision loss. Blurred central vision
usually appears in one eye first, with the second eye declining after
a few weeks or months.
* Central scotoma: Central scotoma is a
growing central blind spot in the visual field.
* Colour vision loss: Colour vision loss
involves difficulty discriminating red and green colours early on.
People with severe cases of Leber Hereditary Optic Neuropathy may
experience a blue-yellow deficit later on.
* Contrast sensitivity loss: Contrast
sensitivity loss refers to difficulty distinguishing an object and its
details from the background.
* Atrophic phase: The atrophic phase
refers to permanent damage to the optic nerve, also known as optic
atrophy.
### How does Vision Typically Change During the Early Stages of LHON?
The early stages of Leber Hereditary Optic Neuropathy involve
central vision blurring in one eye, which progresses to the second
eye within weeks or months, leading to visual impairment, colour
vision deficits, and central scotomas, according to Dr A. Shemesh (2024). Central vision blurring is the
first symptom of Leber Hereditary Optic Neuropathy, and involves
rapid, cloudy or blurred vision affecting the central vision field,
usually in one eye, then the other, according to Dr A.
Stramkauskaite’s research article titled ‘Clinical Overview of Leber
Hereditary Optic Neuropathy’ in 2022. Progression to the second eye
can occur within a few months to a year, although it can sometimes
start in both eyes. Both eyes are affected simultaneously in
approximately 25% of cases, according to Dr A. Stramkauskaite.
#### Does LHON Cause Painless Central Vision Loss?
Yes, acute, painless loss of central vision is a
main characteristic of Leber Hereditary Optic Neuropathy, according
to Dr A. Stramkauskaite (2022). Loss of vision is painless, a key
factor in distinguishing the disease from other eye diseases such as
[optic neuritis](https://www.oscarwylee.ca/glasses/eye/optic-neuritis), which usually causes
[eye pain](https://oscarwylee.ca/glasses/eye/pain-definition). Patients usually do not experience eye pain or inflammatory signs
commonly seen in conditions like optic neuritis, because Leber
Hereditary Optic Neuropathy is a neurodegenerative disease.
## How does LHON Affect Daily Visual Function?
Leber Hereditary Optic Neuropathy causes a sudden loss of central
vision,
severely affecting daily activities that require clear eyesight, such
as reading and writing, facial recognition, and driving.
The development of central scotoma causes a blurry or blind spot in the
centre of the vision field, making it particularly hard to see details
straight ahead. Reading small print in books or on screens also becomes
close to impossible, and patients who become legally blind will not be
able to drive. General daily tasks such as recognising faces and
navigating busy areas become very difficult for people with Leber
Hereditary Optic Neuropathy. People with Leber Hereditary Optic
Neuropathy often retain their peripheral or ‘side vision’, and this can
allow them to navigate their environment independently.
### How does LHON Impact Daily Activities Like Reading and Face
Recognition?
Leber Hereditary Optic Neuropathy significantly affects daily
activities such as reading and facial recognition due to loss of
central vision.
Reading can become very challenging or impossible due to loss of
fine detail perception, and recognising others is affected as ‘face
perception is strongly impaired’
in patients with Leber Hereditary Optic Neuropathy, according to Dr R.
Francomme’s research titled ‘Visual Functions in Patients With Leber
Hereditary Optic Neuropathy’ in 2024 with 12 participants. Central
vision loss means that magnification and high-contrast visual aids
become essential for affected individuals to regain their
independence, according to Dr P. Yu-Wai-Man (1993).
#### Can LHON Lead to Legal Blindness?
Yes, Leber Hereditary Optic Neuropathy can
commonly lead to legal
[blindness](https://www.oscarwylee.com.au/glasses/eye/visual-impairment).
Vision in people with Leber Hereditary Optic Neuropathy varies from
person to person, but usually,
[visual acuity](https://www.oscarwylee.com.au/eye-care/eye-test/visual-acuity.html)
is around 6/60 or worse. Visual acuity refers to someone’s clarity
of vision, and is often measured at a distance of 6 metres and
expressed as a ratio, for example, 6/6 vision. People with Leber
Hereditary Optic Neuropathy are often considered legally blind,
according to the Mito Foundation. Many individuals retain their
peripheral vision despite being legally blind.
## Who is Most at Risk for Developing LHON Disease?
Young adult males who carry mitochondrial mutations inherited from
their mother are the most at risk
for developing Leber Hereditary Optic Neuropathy. Leber Hereditary Optic
Neuropathy has a ‘strong male preponderance (80% to 90%), and the usual
age at onset is between 15 and 35 years’, according to Dr A. Shemesh
(2024). Environmental triggers such as smoking, alcohol use, and
exposure to environmental toxins may also influence symptom onset.
### Why are Young Adult Males More Commonly Affected by LHON Disease?
Young males are more commonly affected by Leber Hereditary Optic
Neuropathy due to hormonal and genetic factors. Leber
Hereditary Optic Neuropathy is passed through the maternal line, and
both sexes may inherit the mutation, although males develop symptoms
significantly more often. Female carriers of Leber Hereditary Optic
Neuropathy are thought to be protected by estrogen and experience
lower penetrance of symptoms than their male counterparts. There is
also a hypothesis that there is a modifier gene on the X chromosome
that works together with the mitochondrial DNA mutation, and as males
only have one X chromosome, they are more likely to develop the
disease.
#### Are Males More Likely Than Females to Develop LHON Symptoms?
Yes,
males are significantly more likely to develop symptoms of Leber
Hereditary Optic Neuropathy than females.
Leber Hereditary Optic Neuropathy affects predominantly males in
80-90% of cases, according to Dr C. Meyerson’s research article
titled ‘Leber hereditary optic neuropathy: current perspectives’ in
2015. Female carriers can carry the disease without symptoms. The
exact biological reason remains under study, but current research
points to the protective effects of estrogen and the X-linked
susceptibility gene as two main factors for the disease manifesting
significantly more in men.
## How is Leber Hereditary Optic Neuropathy Diagnosed?
Leber Hereditary Optic Neuropathy is
diagnosed through clinical eye tests and, most importantly, genetic
testing to identify mitochondrial DNA mutations.
An eye healthcare provider will perform specialised eye tests to
determine your eye health and vision. They will often ask questions
regarding your general health and family history of eye problems. If
Leber Hereditary Optic Neuropathy is suspected, genetic testing will be
needed to identify mutations in mitochondrial DNA, which involves a
sample of blood or saliva being sent to a laboratory to confirm a
diagnosis, according to the Centre for Eye Research Australia. There are
3 primary mtDNA mutations that testing looks for, which are responsible
for the majority of cases.
### What Eye Tests Detect Genetic Vision Loss Like LHON?
Several
[eye tests](https://www.oscarwylee.com.au/glasses/eye/check-up)
performed by eye healthcare providers can confirm Leber Hereditary
Optic Neuropathy, including a combination of
specialised eye tests, imaging, and genetic testing.
An MRI (Magnetic Resonance Imaging) may be required to exclude other
ocular causes that have similar symptoms, and an
[Optical Coherence Tomography](https://www.oscarwylee.com.au/glasses/eye/oct-fundus-test)
(OCT) may be performed, which measures the thickness of the retinal
nerve fibre layers and optic nerve, helping to detect swelling. A
[visual field test](https://www.oscarwylee.com.au/visual_field.html)
may also be performed, which measures peripheral and central vision to
detect central scotoma, as well as a visual acuity test, which
measures the severity of central vision loss. Colour vision testing is
often performed, which assesses for defects in red-green and
blue-yellow colour perception. These tests can suggest Leber
Hereditary Optic Neuropathy, but as it is caused by mutations in
mitochondrial DNA, a definitive diagnosis can only be confirmed
through genetic testing.
#### Is Genetic Testing Required to Confirm LHON?
Yes, genetic testing is required to confirm Leber
Hereditary Optic Neuropathy. Genetic testing identifies
mitochondrial DNA mutations, which account for the majority of Leber
Hereditary Optic Neuropathy cases. An eye healthcare provider may
suspect Leber Hereditary Optic Neuropathy based on clinical signs,
but these alone are not definitive, and genetic confirmation is
essential.
## What Triggers Can Worsen LHON Symptoms?
The triggers that can worsen Leber Hereditary Optic Neuropathy symptoms
can include
smoking, alcohol use, and exposure to environmental toxins.
The triggers that can worsen LHON symptoms are listed below.
* Smoking: ‘Cigarette smoking is
associated with either the onset or progression of Leber Hereditary
Optic Neuropathy, and heavy smokers are more susceptible to the
disease’, according to Dr A. Stramkauskaite (2022).
* Alcohol use: Heavy drinking often
leads to an increased risk of vision loss, although its association
with disease progression is not as strong as with smoking.
* Exposure to environmental toxins: Exposure to chemical solvents and industrial toxins can trigger the
development of symptoms.
### How Do Smoking and Alcohol Influence Disease Progression in LHON?
Smoking and alcohol influence disease progression in Leber Hereditary
Optic Neuropathy through
increased oxidative stress in the mitochondria.
Retinal ganglion cells in the optic nerve are particularly vulnerable
to mitochondrial dysfunction, which smoking and alcohol accelerate.
Studies on gene-environment interactions in Leber Hereditary Optic
Neuropathy, such as an Oxford Academic research article by M. A.
Kirkman titled ‘Gene-environment interactions in Leber hereditary
optic neuropathy’ in 2009, indicate that smoking and heavy alcohol
consumption significantly increase the risk of vision loss in
individuals carrying DNA mutations, particularly smokers.
#### Can Lifestyle Factors Increase the Risk of Vision Loss in LHON
Carriers?
Yes,
unhealthy lifestyle factors can significantly increase the risk
of vision loss
in carriers of Leber Hereditary Optic Neuropathy. The risk of vision
loss is exacerbated by smoking, heavy alcohol consumption and poor
nutrition. Healthy habits such as quitting smoking, moderate to no
alcohol consumption, a balanced diet, avoiding environmental toxins,
and monitoring eye health may help lower the risk of the disease
progressing.
Find Your Nearest OW Store!
We’ve got knowledgeable teams who are passionate about delivering
high-quality care.
[Find a store](https://www.oscarwylee.com.au/locations)
## What Are the Treatments for LHON?
The treatments for Leber Hereditary Optic Neuropathy centre around
preserving remaining vision, and no conclusive cure exists. Treatments
include
low vision aids, idebenone, lifestyle changes, antioxidants and
supplements, and gene therapy.
The treatments for Leber Hereditary Optic Neuropathy are explained
below.
* Low vision aids: Low vision aids are a
traditional treatment method for patients with severe vision loss,
particularly young adults with preserved peripheral vision, according
to Dr A. Theodorou-Kanakari’s research article titled ‘Current and
Emerging Treatment Modalities for Leber’s Hereditary Optic Neuropathy:
A Review of the Literature’ in 2018.
* Idebenone: Idebenone is a therapy
sometimes used in the management of Leber Hereditary Optic Neuropathy.
Idebenone contains antioxidant properties and acts as a ‘mitochondrial
electron carrier’, which may help support cellular energy (ATP)
production. Some studies suggest it may support visual function in
certain patients, although outcomes can vary and treatment is
typically guided by a medical specialist.
* Lifestyle changes: Lifestyle changes,
including avoiding tobacco use, heavy alcohol consumption, and
exposure to environmental toxins, can limit risk factors for
developing Leber Hereditary Optic Neuropathy.
* Vitamins and supplements: Vitamins
such as B2, B3, B12, C, and E, as well as folic acid, and other
supplements such as alpha-lipoic acid, carnitine, and creatine, have
been used to treat mitochondrial disorders such as Leber Hereditary
Optic Neuropathy. The evidence for the benefits of vitamin and
supplement use for the disease remains limited.
* Gene therapy: Gene therapy is an
emerging treatment approach being studied for Leber Hereditary Optic
Neuropathy. It involves the defective gene being replaced by the
‘normal wild-type gene so that the normal gene is expressed’,
according to Dr A. Theodorou-Kanakari. Research into gene testing for
Leber Hereditary Optic Neuropathy is ongoing, and early studies have
shown favourable results in some patients, although availability and
outcomes may vary.
### What Low Vision Aids Are Available for LHON Patients?
Low vision aids available for Leber Hereditary Optic Neuropathy can
include
electronic video magnifiers, handheld/mounted magnifiers (CCTV),
telescopic glasses, and smartphone apps.
The low vision aid options for patients are listed below.
* Electronic video magnifiers: Electronic video magnifiers allow people to read using their
remaining peripheral vision. Some examples are ZoomText and
SuperNova.
* Handheld/mounted magnifiers (CCTV): Handheld/mounted magnifiers or CCTV (closed-circuit television)
magnifiers are devices that magnify printed materials to display a
larger image on an HD monitor.
* Telescopic glasses: Telescopic
glasses act as small binoculars mounted on lenses, improving central
vision.
* Smartphone apps: Smartphone apps can
help improve peripheral vision and magnify text. Useful apps include
Be My Eyes, Smart Magnifier, and AI apps like Seeing AI.
#### Can Glasses Help Manage LHON Symptoms?
Yes,
[glasses](https://www.oscarwylee.com.au/)
may help manage Leber Hereditary Optic Neuropathy
symptoms by supporting remaining vision. Glasses can help correct
refractive errors and improve clarity for patients experiencing
Leber Hereditary Optic Neuropathy. Glasses are supportive, but they
do not restore damaged optic nerve fibres or reverse the disease.
##### Can Prescription Glasses Improve Reading for LHON Patients?
Yes,
[prescription glasses](https://www.oscarwylee.com.au/glasses.html)
can improve reading for patients with Leber
Hereditary Optic Neuropathy if magnification or refractive
correction is needed. Strong reading prescription glasses may
enlarge print for patients. Additional low vision aids are highly
effective and often required for Leber Hereditary Optic Neuropathy
patients.
### What Lenses Can Reduce Eye Strain for People with Vision Loss?
Specialised
[lenses](https://www.oscarwylee.com.au/glasses/eye/types-of-lenses)
may reduce eye strain for patients with Leber Hereditary Optic
Neuropathy. Specialised lenses include
FL-41 tinted lenses, precision coloured lenses,
[polarised lenses](https://www.oscarwylee.com.au/glasses/eye/polarised-lenses), and
[blue light lenses](https://www.oscarwylee.com.au/glasses/eye/blue-light).
The details of these lenses are explained below.
* FL-41 tinted lenses: FL-41 tinted
lenses are rose-coloured lenses that filter out blue and green
light, decreasing pain and discomfort for patients.
* Precision coloured lenses: Precision
coloured lenses are specialised tints that can improve contrast and
comfort.
* Polarised lenses: Polarised lenses
reduce glare, which is ideal for Leber Hereditary Optic Neuropathy
patients as they often experience extreme
[light sensitivity](https://www.oscarwylee.com.au/glasses/eye/light-sensitivity).
* Blue light lenses: Blue light lenses
are designed to block blue light emitted by digital screens.
#### Can Progressive Lenses Help People with Central Vision Loss?
Progressive lenses generally
do not help, improve, or stop central vision loss
caused by Leber Hereditary Optic Neuropathy, according to the Mito
Foundation. Leber Hereditary Optic Neuropathy is a genetic condition
that damages the optic nerve, not a refractive error of the eye.
[Progressive lenses](https://www.oscarwylee.com.au/glasses/eye/progressive-lenses)
are designed to fix how the eye bends light, and they cannot correct
the central blur of the eye or blindness caused by a damaged optic
nerve.
### What Types of Sunglasses Protect Sensitive Eyes in LHON?
Different types of sunglasses can protect individuals with sensitive
eyes from Leber Hereditary Optic Neuropathy, including
[UV protection lenses](https://www.oscarwylee.com.au/glasses/best-uv-sunglasses-for-eye-protection), polarised lenses, and wraparound frames.
Protective sunglasses are essential and reduce light discomfort, which
is often worsened by sunlight. The types of sunglasses that may help
protect sensitive eyes in LHON are listed below.
* UV-protection lenses: UV-protection
lenses that provide maximum UV400 protection are essential as they
block harmful UVA and UVB rays.
* Polarised lenses: Polarised lenses
reduce glare, which can cause eye pain and headaches. Neutral grey,
brown, and copper tints help improve visual comfort. Category 3 or 4
Lenses provide higher reduction of sunglare and are recommended for
sensitive eyes.
* Wraparound frames: Wraparound frames
limit light entering the eye from the top, bottom, or sides.
### How can Anti-Glare Glasses Improve Vision Comfort for LHON?
Anti-glare glasses coatings may improve vision comfort for patients
with Leber Hereditary Optic Neuropathy by
reducing light sensitivity, reducing
[eye fatigue](https://www.oscarwylee.com.au/glasses/eye/fatigue-definition), and enhancing visual clarity.
People with Leber Hereditary Optic Neuropathy often experience light
sensitivity, and anti-glare coatings reduce bright light intensity.
[Anti-glare glasses](https://www.oscarwylee.com.au/guides/lenses/anti-glare)
can reduce eye fatigue and headaches as the eyes do not have to work
as hard to see in a glary environment. Anti-glare glasses can also
enhance contrast and clarity, making it easier to see in darker
conditions.
#### Can Photochromic Lenses Help with Light Sensitivity in LHON?
Yes,
[photochromic lenses](https://www.oscarwylee.com.au/glasses/eye/photochromic-lenses)
may help with light sensitivity
experienced by Leber Hereditary Optic Neuropathy patients.
Photochromic lenses automatically darken outdoors and remain clear
indoors, which helps with glare and discomfort. Optic nerve damage
cannot be treated or reversed by photochromic lenses, but they can
be a helpful aid to manage symptoms and improve comfort for people
with Leber Hereditary Optic Neuropathy, according to the Mito
Foundation.
Read Leber Hereditary Optic Neuropathy (LHON) Disease: Causes and
Symptom in other Oscar Wylee regions and their languages.
Australia
Australia
New Zealand
Canada
Canadian French

Major Health Funds Accepted
In-store
For the purchase of frames and lenses, use your private health fund to
limit how much you pay from your own pocket.
[Health Funds](https://www.oscarwylee.com.au/health-funds.html)
Experience High Quality Eyecare Services From Our Team
Book an appointment online with an Oscar Wylee optometrist today.
[Book an eye test](https://www.oscarwylee.com.au/booking)