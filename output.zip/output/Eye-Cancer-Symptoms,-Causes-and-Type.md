# Source: https://www.oscarwylee.com.au/glasses/eye/cancer

# Eye Cancer: Symptoms, Causes and Types
Published on April 2nd, 2026
Australia
Australia
New Zealand
Canada
Canadian French
 
Eye cancer is the development of abnormal cells in and around your eye in an uncontrolled way, according to Health Direct. The causes of eye cancer are not fully understood; however, there may be certain factors that can increase the risk, such as increased age, family history, and lifestyle habits. There are many different types of eye cancers, such as intraocular melanoma (Uveal Melanoma), retinoblastoma, ocular lymphoma, conjunctival melanoma, eyelid cancer, orbital cancer, and secondary (metastatic) eye cancer. The contents of this article are for informational purposes only and should not be used to participate in any self-diagnosis. If you are concerned, it is important to see your optometrist for a comprehensive examination.
Stay on top of your eye health!
It is recommended to get an eye test at least once every 1-2 years unless advised otherwise by an optometrist.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Definition](#definition) [Symptoms](#symptoms) [Types](#types) [Diagnosis](#diagnosis)
## What is Eye Cancer?
Eye cancer develops in the cells in your eyes and neighbouring structures, such as the tear ducts and eyelids. There are many different types of eye cancer that can impact the eye, with ocular melanoma being the most common, according to the Cancer Council.
### How Does Eye Cancer Develop in Different Parts of the Eye?
Eye cancer can develop in different parts of the eye due to the growth of abnormal cells in the eye in an uncontrolled way.
#### Is Eye Cancer a Rare Condition?
Yes, eye cancer is considered a rare condition. Different types may have varying incidence rates with uveal melanoma, for example, having an incidence of 7.6 per million adults in Australia, according to Edith Cowan University.
## What are the Symptoms of Eye Cancer?
The symptoms of eye cancer can include blurred vision, flashes of light, partial or complete loss of vision, floaters, brown or dark spots on the sclera, a bulging eye and eye pain. If you experience any of these symptoms, it is recommended you see a health professional. The symptoms of eye cancer are listed below.
* Blurred Vision: Blurred vision is a common symptom of many conditions, on a rare occasion this can be a symptom of eye cancer and is described as vision that lacks sharpness and detail. [Blurry vision](https://www.oscarwylee.com.au/glasses/eye/blurred-vision) from eye cancer may be due to different reasons depending on the type of cancer. For example, a tumour's growth may hinder normal eye function by physically obstructing light, damaging cells, or compressing internal structures.
* Flashes of Light: Flashes of light may contribute as a symptom of eye cancer, depending on the type. Cases such as ocular melanoma or metastatic tumours may potentially cause stress on, detach from or pull on the retina.
* Partial or Complete Loss of Vision: Partial or complete loss of vision can occur as a symptom of eye cancer, depending on the severity and type.
* Floaters: Floaters may be a symptom of eye cancer and are characterised as small specks, wavy lines or shadows in your vision.
* Brown or Dark Spot on the Sclera: A brown or dark spot on the sclera may indicate certain types of eye cancers, such as ocular melanoma. Melanomas develop from melanocytes, which are cells that produce pigment.
* Bulging Eye: A bulging eye may be a symptom of eye cancers, depending on the type of cancer. The bulging may be caused by a growth of a tumour in cases such as ocular melanoma or lymphoma.
* Eye Pain: Eye pain can ensue as a symptom of eye cancer as a result of certain complications, such as increased eye pressure, growth of tumours or inflammation.
#### Can Eye Cancer Cause Vision Changes Early?
Yes, eye cancer may potentially cause vision changes early. Early vision changes, such as blurry or poor vision, can ensue during as a result of eye cancer, according to the Cancer Council.
## What Causes Eye Cancer?
The causes of eye cancer are not completely known by medical professionals. However, there may be certain factors that can increase the likelihood of developing the disease, such as DNA mutations, inherited gene defects, random cell errors, UV light exposure, having light-coloured eyes, fair skin, increasing age and a family history of eye cancer.
### What Factors Increase the Risk of Eye Cancer, including UV Exposure and Photokeratitis?
The factors that may increase the risk of eye cancer, including UV exposure and photokeratitis, may be the harm of excessive exposure to sunlight without protection and the significant UV damage. Other related factors can include having light coloured eyes, fair skin and increased age. The factors that may increase the risk of eye cancer, including UV exposure and photokeratitis, are listed below.
* Excessive Exposure to Sunlight: Excessive exposure to sunlight without protection may increase the risk of eye cancers such as ocular melanoma, skin cancer on the eyelids and around the eyes.
* UV Damage: UV damage may contribute as a risk factor for eye cancers such as conjunctival squamous cell carcinoma and ocular melanoma. This may be due to UV light damage to the cells in the eye and numerous other factors.
* Light Coloured Eyes: Light coloured eyes are often considered a risk factor for eye cancer, potentially due to having less melanin (pigment) in the iris for protection against UV radiation.
* Fair Skin: Fair skin, similarly, can contribute as a risk factor for eye cancer due to having less melanin in the skin, so less protection from UV light.
* Increased Age: Increased age can also be a risk factor for developing eye cancer, with patients over the age of 50 being the most common age range affected.
#### Can UV Exposure Contribute to Eye Cancer?
Yes, UV exposure may contribute to eye cancer. According to the Centre for Eye Research Australia, excessive exposure to the sun can produce long-term effects, such as cataracts and eye cancers, such as pterygium, skin cancer on the eyelids and around the eyes and cancer of the conjunctiva. Short-term effects can include eye irritation, excessive blinking and sensitivity to light.
Visit us in-store!
See our team and optometrist in-store for any of your eyecare needs.
[Find a store](https://www.oscarwylee.com.au/locations)
## What are the Types of Eye Cancer?
The types of eye cancer may include intraocular melanoma (uveal melanoma), retinoblastoma, ocular lymphoma, conjunctival melanoma, eyelid cancer and orbital cancer. The types of eye cancers and their definitions are listed below.
* Intraocular melanoma (uveal melanoma): Intraocular melanoma (uveal melanoma) is a type of rare eye cancer that primarily affects the middle layer of the eye, the uvea.
* Retinoblastoma: Retinoblastoma is an eye cancer that initiates in the retina and may occur more commonly in children.
* Conjunctival Melanoma: Conjunctival melanoma is classified as a rare and aggressive form of eye cancer that affects the surface of the eye.
* Eyelid Cancer: Eyelid cancers, such as basal cell carcinoma, which may be the most common type that can potentially arise from excessive sun exposure, along with other factors.
* Orbital Cancer: Orbital cancer can be characterised as malignant tumours that form in the socket of the eye, known as the orbit.
* Ocular Lymphoma: Ocular melanoma is a form of eye cancer that develops in the white blood cells and is considered rare.
## 1. Intraocular Melanoma (Uveal Melanoma)
Intraocular melanoma (uveal melanoma) is a type of rare eye cancer that impacts the uvea, which is the middle layer of the eye. This condition ensues in the cells that are responsible for producing pigment in the eye and are called melanocytes. It does not typically cause any early symptoms and is detected through a routine eye exam, according to the National Cancer Institute.
## 2. Retinoblastoma
Retinoblastoma is considered a rare and aggressive type of eye cancer that mainly occurs in children. This condition may stem from the retina and may include symptoms such as the pupil appearing white in colour instead of red when a light is shone into it, eye redness or pain, an eye that is larger than usual and cloudiness in the iris and pupil.
## 3. Ocular Lymphoma
Ocular lymphoma is considered a rare type of cancer that develops in the white blood cells of the immune system. Unlike other lymphomas, which usually start in the lymph nodes, ocular lymphoma ensues inside the eye or in neighbouring structures.
## 4. Conjunctival Melanoma
Conjunctival melanoma is characterised as a rare and aggressive cancer that involves the surface of the eye. According to Butt et al., (2024), conjunctival melanoma was recorded to have a global incidence rate of 1 in a million and is increasing to 1.4; however, this is more prevalent among 65-year-olds.
## 5. Eyelid Cancer
Eyelid cancer may refer to any form of cancer that develops on the eyelid or in the eyelid. Symptoms of eyelid cancer can include inflammation that persists for a long period, discolouration in the skin of the eyelid and a growth on the eyelid, which may bleed or itch. There are many different types of eyelid cancers, with basal cell carcinoma, sebaceous carcinoma and squamous cell carcinoma being some of the most common forms.
## 6. Orbital Cancer
Orbital cancer refers to orbital tumours that form within the eye socket (orbit). They may initiate in any of the tissues in the socket, including the blood vessels, nerves, bones and connective tissue. A possible indication of this condition includes a bulging eyeball and accompanying symptoms such as eye pain, swelling, double vision and blurry vision.
## How is Eye Cancer Diagnosed?
Eye cancer can be diagnosed through a routine eye test. Optometrists are trained to diagnose a range of eye conditions, including eye cancer, according to Cancer Council Australia. They can direct you to a suitable ophthalmologist for further assessment and treatment. If you are concerned, see your optometrist for comprehensive examination.
### How Do Eye Tests Help Detect Eye Cancer?
Eye tests can help detect eye cancer through the different tools used by an eye care professional. According to Health Direct, a specialist can use a special microscope or capture high-resolution images of the back of your eye with a specialised camera. An eye care professional can use additional [eye tests](https://www.oscarwylee.com.au/eye-care/eye-test) for further examination.
## How Does Eye Cancer Affect the Retina and Vision Function?
Eye cancer can affect the retina and vision function in different ways depending on the type. However, eye cancers may produce tumours, for example, that can impair how light enters the eye or the eye's ability to process light that enters. The [retina](https://www.oscarwylee.com.au/glasses/eye/anatomy/retina) is responsible for detecting light and converting it into signals for the brain.
#### Can Damage to the Retina Affect Light Sensitivity and Vision?
Yes, damage to the retina can affect light sensitivity and vision. Damage to the retina can affect one's [light sensitivity](https://www.oscarwylee.com.au/glasses/eye/light-sensitivity) and vision, as the retina is the layer responsible for transmitting light into signals for the brain to process as images.
## How can Eye Cancer Be Misdiagnosed as Other Eye Problems?
Eye cancer may be misdiagnosed as other problems due to the symptoms that tumours can bring about which can be closely similar to the symptoms of other eye conditions. Additional testing methods by a trained healthcare professional such as imaging technology, ultrasound and high resolution biomicroscopy or fluorescein angiography can assist with completing the right diagnosis of eye cancers instead of other [eye problems.](https://www.oscarwylee.com.au/glasses/eye/common-problems)
### How do the Symptoms of Eye Cancer Differ from Those of a Corneal Abrasion?
The symptoms of eye cancer may differ from those of a [corneal abrasion](https://www.oscarwylee.com.au/glasses/eye/corneal-abrasion) mainly in their initial levels of pain and effect on vision. A corneal abrasion may be characterised as a more immediate and intense pain or a feeling that something is stuck in your eye and usually follows trauma to the eye. Eye cancer may progress more gradually in stages and is typically painless in the early stages.
## How Can You Protect Your Eyes from Eye Cancer Risks?
You may be able to help protect your eyes from cancer risks by taking more preventative measures. It can be helpful to wear UV protection sunglasses when spending time outdoors in the sun and limiting how much time you spend out in the sun to minimise excessive exposure. However, it is important to note that you may not be able to definitively prevent eye cancer risks, as it is dependent on numerous factors.
### How does Wearing Sunglasses in Winter and UV Protection Help?
Wearing [sunglasses](https://www.oscarwylee.com.au/glasses/eye/sunglasses) in winter and UV protection helps your eyes by reducing excessive exposure to the sun's UV light rays. According to Cancer Council NSW, exposure to UV can lead to significant or permanent damage to the structures of the eye. Behar-Cohen et al., (2013) note that UV protection for children's eyes is especially important as the transmittance of UV is higher at younger ages.
#### Can Protective Eyewear Reduce Eye Damage Risks?
Yes, protective eyewear can help reduce eye damage risks, especially if you spend a lot of time or work in environments or with materials that can get into your eyes. Protective eyewear such as safety goggles or polycarbonate glasses is often required for those at risk, such as workers who work with mechanical equipment, chemicals and sources of radiation, mainly ultraviolet radiation from welding and infra-red radiation from furnaces, according to the National Occupational Health and Safety Commission. It is important to note that Oscar Wylee does not offer safety goggles or eyewear that you can wear in such environments or for working with the mentioned materials.
##### Can Wearing UV Sunglasses Help Protect Your Eyes from Eye Cancer Risks?
Yes, wearing [UV sunglasses](https://www.oscarwylee.com.au/glasses/best-uv-sunglasses-for-eye-protection) can help protect your eyes from eye cancer risks, but they may not necessarily prevent eye cancer from developing. According to the Cancer Council NSW, wearing close-fitting wraparound sunglasses and a hat can offer optimal protection from UV radiation, which has been established as a decisive risk factor for developing cancer.
Read Eye Cancer: Symptoms, Causes and Types in other Oscar Wylee
regions and their languages.
Australia
Australia
New Zealand
Canada
Canadian French
 
Experience Quality Eye Care!
We have knowledgeable optometrists at Oscar Wylee, who are available in-store to perform high-quality eye tests.
[Explore health funds](https://www.oscarwylee.com.au/health-funds.html)
Oscar Wylee Accepts Major Health Funds In-store
Visit Oscar Wylee in-store for eye care and eye wear services, and your health fund may help cover some of the cost.
[Book an eye test](https://www.oscarwylee.com.au/booking)