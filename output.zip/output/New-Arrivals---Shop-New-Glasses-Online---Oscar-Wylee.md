# Source: https://www.oscarwylee.com.au/glasses/collection/new-arrivals.html

129 Products        
Showing 15 of 129
1. [](https://www.oscarwylee.com.au/solene-optical.html)
[Solene](https://www.oscarwylee.com.au/solene-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/solene-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/solene-optical.html)
2. [](https://www.oscarwylee.com.au/vivian-optical.html)
[Vivian](https://www.oscarwylee.com.au/vivian-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/vivian-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/vivian-optical.html)
3. [](https://www.oscarwylee.com.au/jorja-optical.html)
[Jorja](https://www.oscarwylee.com.au/jorja-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/jorja-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/jorja-optical.html)
4. [](https://www.oscarwylee.com.au/vista-optical.html)
[Vista](https://www.oscarwylee.com.au/vista-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/vista-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/vista-optical.html)
5. [](https://www.oscarwylee.com.au/emma-optical.html)
[Emma](https://www.oscarwylee.com.au/emma-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/emma-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/emma-optical.html)
6. [](https://www.oscarwylee.com.au/yumi-optical.html)
[Yumi](https://www.oscarwylee.com.au/yumi-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/yumi-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/yumi-optical.html)
7. [](https://www.oscarwylee.com.au/drew-optical.html)
[Drew](https://www.oscarwylee.com.au/drew-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/drew-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/drew-optical.html)
8. [](https://www.oscarwylee.com.au/mumford-optical.html)
[Mumford](https://www.oscarwylee.com.au/mumford-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/mumford-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/mumford-optical.html)
9. [](https://www.oscarwylee.com.au/remmi-optical.html)
[Remmi](https://www.oscarwylee.com.au/remmi-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/remmi-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/remmi-optical.html)
10. [](https://www.oscarwylee.com.au/humphrey-optical.html)
[Humphrey](https://www.oscarwylee.com.au/humphrey-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/humphrey-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/humphrey-optical.html)
11. [](https://www.oscarwylee.com.au/lori-optical.html)
[Lori](https://www.oscarwylee.com.au/lori-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/lori-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/lori-optical.html)
12. [](https://www.oscarwylee.com.au/gina-optical.html)
[Gina](https://www.oscarwylee.com.au/gina-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/gina-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/gina-optical.html)
13. [](https://www.oscarwylee.com.au/yvonne-optical.html)
[Yvonne](https://www.oscarwylee.com.au/yvonne-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/yvonne-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/yvonne-optical.html)
14. [](https://www.oscarwylee.com.au/francis-optical.html)
[Francis](https://www.oscarwylee.com.au/francis-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/francis-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/francis-optical.html)
15. [](https://www.oscarwylee.com.au/kaycee-optical.html)
[Kaycee](https://www.oscarwylee.com.au/kaycee-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/kaycee-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/kaycee-optical.html)
129 Products        
Showing 15 of 129
Choosing the Best Glasses Suitability Functionality Pricing and Shipping
## How to Choose the Best New Arrival Glasses for Women?
When choosing the best new arrival glasses for women, consider factors such as face shape, selecting a suitable style and ensuring comfort. [The best women’s glasses](https://www.oscarwylee.com.au/glasses/face-shapes) to choose are frames that fit comfortably, enhance your natural features and can be incorporated into your wardrobe. The ways to choose the best new arrival glasses for women are listed below.
* Consider face shape: Consider face shape when choosing the best new arrival glasses for women to complement your natural features and overall look. Square frames are a suitable option for those with round faces as the strong lines and angles contrast the curved lines of round faces, creating balance.
* Select a suitable style: Select a suitable style for the best new arrivals glasses for women by trying on a variety of options. Try experimenting with different width frames, colours and material combinations to see what glasses best suit you.
* Ensure comfort: Ensure comfort when choosing new arrival glasses by putting your frames on and assessing how they fit. See if they slip down your nose bridge or feel like they’re pinching your nose bridge or if they feel tight around the head.
[](https://www.oscarwylee.com.au/gigi-optical.html)
[Gigi](https://www.oscarwylee.com.au/gigi-optical.html)
$169    
Add to Cart
[Shop Gigi](https://www.oscarwylee.com.au/gigi-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/gigi-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/gigi-optical.html)
[](https://www.oscarwylee.com.au/sabrina-optical.html)
[Sabrina](https://www.oscarwylee.com.au/sabrina-optical.html)
$169    
Add to Cart
[Shop Sabrina](https://www.oscarwylee.com.au/sabrina-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/sabrina-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/sabrina-optical.html)
## How to Choose the Best New Arrival Glasses for Men?
When choosing the best new arrival glasses for men, consider factors such as face shape, selecting a suitable style and ensuring comfort. [The best men’s glasses](https://www.oscarwylee.com.au/glasses/best-men-eyeglasses-for-every-face-shape) to choose are frames that fit comfortably, enhance your natural features and can be incorporated into your wardrobe. The ways to choose the best new arrival glasses for men are listed below.
[](https://www.oscarwylee.com.au/jacob-optical.html)
[Jacob](https://www.oscarwylee.com.au/jacob-optical.html)
$169    
Add to Cart
[Shop Jacob](https://www.oscarwylee.com.au/jacob-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/jacob-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/jacob-optical.html)
### How to Choose New Arrival Glasses According to Skin Tone?
To choose the best new arrival glasses according to skin tone involves knowing what your skin tone/undertone is and finding complementary frame colours. A person’s skin tone can often be determined by observing the veins on the inside of their wrist. If the veins are blue or purple, this usually suggests a cool undertone. Veins that look blue and green may indicate you have a neutral undertone, while veins that appear green or yellow and green often point to a warm undertone. For cooler skin tones, colours such as blue, grey, and purple tend to be the most flattering. Those with warmer undertones may look best in frames with warm, earthy shades like browns and gold.
### How to Choose New Arrival Glasses According to Face Shape?
To choose the best new arrival glasses according to your face shape, it can be helpful to first examine your facial features and proportions to identify your face shape. Common face shapes include round, pear, oval, heart, and square. While there are general recommendations for the [best glasses for different face shapes](https://www.oscarwylee.com.au/glasses/face-shapes), the ultimate choice should be the pair that makes you feel your best. The ways to choose the best new arrival glasses according to face shape are listed below.
* Round face shapes: Round face shapes are characterised by their circular shape and typically harmonious dimensions. Square, rectangular and geometric glasses are suitable for [round face shapes](https://www.oscarwylee.com.au/glasses/face-shapes/round) as they help balance out the softer features and add stronger angles.
* Pear face shapes: Pear face shapes generally feature a narrower forehead along with a wider and rounded jawline, and fuller cheeks. Rectangle, cat eye and oval glasses are suitable for [pear shape faces](https://www.oscarwylee.com.au/glasses/face-shapes/pear) as they can help balance out the narrow forehead and wider jawline.
* Oval face shapes: Oval face shapes are characterised by a longer length face and overall well-balanced or equal facial features with a soft and/or rounded chin and jawline. Round, rectangle, square, aviator and cat eye glasses are suitable for [oval face shapes](https://www.oscarwylee.com.au/glasses/face-shapes/oval) as they have a harmonious facial structure.
* Heart face shapes: Heart face shapes are described as having a wider forehead and a smaller chin. Cat eye, round and square glasses help to balance out a wider forehead, typically featured on a [heart face shape](https://www.oscarwylee.com.au/glasses/face-shapes/heart).
* Square face shapes: Square face shapes are defined by their prominent jawline, which is often equal in width to their forehead. Browline, round, square, aviator and cat eye glasses are suitable for square faces to help create a visual contrast between the angular features of a [square face](https://www.oscarwylee.com.au/glasses/face-shapes/square#Glasses) shape and the soft curves of these frames.
## How to Choose New Arrival Glasses According to Bridge Width?
You can choose new arrival glasses according to width by trying on different frame sizes to determine which width will suit you best. We have glasses to cater to all face sizes, including narrow, medium and wide. The ways to buy new arrival glasses according to width are listed below.
* Narrow frames: Narrow-width frames generally feature smaller lenses and a narrower bridge and are suitable for petite and narrow faces.
* Medium frames: Medium frames are available in a wide selection of shapes and styles. Medium frames are well-suited to those with average or medium-sized faces.
* Wide frames: Wide frames are good for those with wider, larger faces and should not extend beyond the widest portion of your face.
#### Are New Arrival Glasses Suitable for Seniors?
Yes, new arrival glasses are suitable for seniors. Many new arrival glasses at Oscar Wylee feature styles and shapes that can complement seniors and meet their vision requirements. [Senior glasses](https://www.oscarwylee.com.au/glasses/collection/seniors.html) can include bold, minimal, bright and classic styles. The most suitable glasses from our new arrivals will depend on your personal preferences and style.
### What Makes New Arrival Eyeglass Frames Different from Regular Frames?
New arrival eyeglass frames are not different from regular frames. New arrival glasses are simply new releases of glasses products as part of Oscar Wylee’s new eyewear collections.
### Which Colour Pattern Looks Best on New Arrival Glasses?
The best colour pattern that looks best on new arrival glasses include matte, solid, tortoise, transparent and two-toned. However, it is important to note that the best colour pattern for new arrival glasses will depend on personal aesthetic preferences. The best colour patterns that may look best on new arrival glasses are listed below.
* Matte: A Matte colour pattern can be a popular option in our new arrival glasses, providing a refined, understated style that highlights the shape and details of the frame.
* Solid: A Solid colour pattern is a staple choice included in new arrival glasses, as they can easily be paired with any outfit style and different kinds of occasions.
* Tortoise: A Tortoise colour pattern is a versatile way to step up your day-to-day glasses rotation. Many people can opt for this colour pattern option as it is considered widely flattering to many different skin tones.
* Transparent: A Transparent frame is often a classic popular option in new arrival glasses as they bring a subtle and minimalist elevation.
* Two-toned: Two-toned colour pattern glasses are an elevated take on a classic frame design, perfect for those who love different colours.
### How to Adjust New Arrival Glasses for a Comfortable Fit?
You can adjust new arrival glasses for a comfortable fit by bringing your frames to the optical retailer you purchased them from to have them adjusted professionally. If you bought new arrival glasses from Oscar Wylee, you can take them to your nearest store to have them adjusted.
#### Are Transition Lenses Available For New Arrival Glasses?
Yes, transition lenses are available for new arrival glasses. You can choose from Oscar Wylee’s own brand, known as adaptive lenses or the brand Transitions® GEN S™ to add onto your new arrival glasses for an additional price on top of your chosen glasses. Photochromic lenses are also known as [transition lenses](https://www.oscarwylee.com.au/glasses/eye/photochromic-lenses) due to their function, as they “transition” from clear to dark and are suitable for those who need both the vision correction of prescription glasses and the UV protection of sunglasses without needing to change frames.
#### Are Rimless or Wire Frame Glasses Included in the Latest New Arrivals?
Yes and no, there are [wire frame glasses](https://www.oscarwylee.com.au/glasses/wire-frame) included in the latest new arrivals; however, there are no rimless frame glasses in the latest new arrivals. We have a wide selection of wire frame glasses or also known as metal glasses, available in gold, silver, black and rose gold colours.
## What Lens Types Work Best for New Arrival Glasses?
Many different lens types can work best with new arrival glasses; however, you should consult with your optometrist on which lens type may be the most suitable for your glasses. They will be able to provide their professional opinion on the most appropriate frame for your vision requirements and personal preferences.
#### Do New Arrival Frames Make Your Face Look Smaller?
New arrival glasses can make a person’s face appear smaller, but only depending on the frames and their face shape. Wider frames may make it seem as if your face appears smaller due to the broader design contrasting with facial proportions. However, this effect can vary between individuals based on their unique features.
### What Factors Affect the Price of New Arrival Glasses?
The factors that affect the price of new arrival glasses at Oscar Wylee can differ based on elements such as the glasses range, add-ons and lens types. One pair of glasses starts from our range price of $169, 2 pairs from $199 and 3 pairs from $249. It should be noted that prescription lens thickness and other add-ons will affect overall pricing. See our full [price guide](https://www.oscarwylee.com.au/price-guide/) for more
### How Long Does It Take to Get New Arrival Prescription Glasses?
New arrival prescription glasses may take 7–10 business days to arrive at your chosen Oscar Wylee store for pick-up. For home deliveries, please allow up to 2 weeks. You’ll receive a confirmation email with your order details and a tracking link once your order has been placed.
[Prescription Glasses](https://www.oscarwylee.com.au/glasses.html)
[Women’s Glasses](https://www.oscarwylee.com.au/glasses/collection/womens-glasses.html)
[Men’s Glasses](https://www.oscarwylee.com.au/glasses/collection/mens-glasses.html)
[Senior Glasses](https://www.oscarwylee.com.au/glasses/collection/seniors.html)
[Glasses for Kids](https://www.oscarwylee.com.au/glasses/collection/kids-collection.html)