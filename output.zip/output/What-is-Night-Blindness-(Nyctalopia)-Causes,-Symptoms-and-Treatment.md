# Source: https://www.oscarwylee.com.au/glasses/eye/night-blindness

# What is Night Blindness (Nyctalopia): Causes, Symptoms and Treatment
Published on August 28th, 2023
Updated on February 13th, 2025
Night blindness, scientifically known as nyctalopia, is an eye condition
that causes the eyes to struggle to see in dim light and experience poor
night vision. According to an article published in the National Library of
Medicine, nyctalopia is defined as the inability of a person’s eyes to
adapt quickly from lightness to darkness. Night blindness can affect a
person’s daily life as it can make driving at night difficult. The main
causes of night blindness include cataracts, glaucoma, myopia and
diabetes. The main symptom of nyctalopia is not being able to see well at
night or in low-light conditions. Treatments for night blindness
(nyctalopia) depend on the underlying cause of this vision issue. For
example, if it is caused by vitamin A deficiency, it may be treated by
consuming more of this vitamin. Keep reading to learn more about night
blindness and its causes and symptoms.
Due for an Eye Test?
It is important to book regular eye tests. Book online today with Oscar
Wylee.
[Book an eye test](https://www.oscarwylee.com.au/booking)
## What are the Causes of Night Blindness?
Night blindness is caused due to either an issue with the rod cells,
which are photoreceptor cells in the eye, or the pupils. If there are
issues with these two functions, then it may cause a person to have
trouble seeing in dim light or at night. The main causes of night
blindness include cataracts, glaucoma, myopia and diabetes. These causes and their definitions are listed below.
* Cataracts: Cataracts are an age-related
eye condition that affects a person’s lens. Due to a disruption to the
lens, it limits the amount of light that can enter the eye, causing night
blindness.
* Glaucoma: Glaucoma is a term for a group
of eye conditions that causes damage to the optic nerve, resulting in
vision loss. According to Glaucoma Australia, people with glaucoma can
experience impaired dark adaptation which can affect a person’s ability to
drive safely.
* Myopia: Myopia is a refractive error that
causes a person’s distance vision to be blurry. This eye condition may
cause a person’s night vision to be blurry as if their vision is affected
in daylight, it is likely to worsen in low light.
* Diabetes: Diabetes is characterised by
uncontrolled blood sugar levels and can lead to the eye condition diabetic
retinopathy which may cause symptoms such as poor night vision.
Other causes of night blindness may include retinitis pigmentosa, which
is a group of rare eye diseases that affect the retina, and ocular
albinism which is a genetic condition that reduces the pigment of a
person’s iris.
### How Do Cataracts Cause Night Blindness?
Cataracts are an age-related eye condition that limits the amount of light that can
enter the eye, causing night blindness. A
[cataract](https://www.oscarwylee.com.au/glasses/eye/cataracts)
is a clumping of protein in the eye’s lens which causes the lens to
become cloudy instead of clear, which is called opacification. According
to Medical News Today, cataracts interfere with a person’s vision via
the lens which can lead to night blindness. Cataracts are most commonly
treated through cataract surgery which in turn can treat night blindness
as it corrects the issues with the lens. Cataract surgery involves
removing and replacing the lens with an artificial one called an
intraocular lens.
### How Does Glaucoma Cause Night Blindness?
Glaucoma is a term for a group of eye conditions that causes damage to
the optic nerve, resulting in vision loss. According to Glaucoma
Australia, people with glaucoma can experience impaired dark adaptation which can
affect a person’s ability to drive safely. [Glaucoma](https://www.oscarwylee.com.au/glasses/eye/glaucoma)
has also been recognised by the National Transport Commission and
Austroads as an eye condition that affects a person’s capacity to drive
safely. A common glaucoma symptom is a loss of peripheral vision which
can make it difficult to rapidly adapt to changes in lighting, causing
issues with driving at night as it impedes a person’s ability to manage
glare and also judge the distance of other cars on the road.
### How Does Myopia Cause Night Blindness?
Myopia is a refractive error that causes a person’s distance vision to
be blurry. This eye condition may cause a person’s night vision to be blurry as if their vision is
affected in daylight, it will worsen in low light. According to the Cleveland Clinic, people who have myopia commonly
experience poor night vision due to optical issues.
[Myopia](https://www.oscarwylee.com.au/glasses/eye/nearsightedness)
can be treated through prescription glasses which can also be helpful
for night blindness caused by this refractive error. People with night
myopia may also benefit from a stronger prescription to help them see
better in low-light conditions.
### How Does Diabetes Cause Night Blindness?
Diabetes is characterised by uncontrolled blood sugar levels and can lead to the eye condition diabetic retinopathy which in its early
stages can cause symptoms such as poor night vision.
According to Optometrists.org, diabetes may lead to diabetic retinopathy
as the condition changes the shape of the lens, leading to damaged blood
vessels in the eye. Other symptoms besides poor night vision in diabetic
retinopathy include seeing floaters in your vision, blurry vision and
empty and dark spots in your vision.
## How Do Eyes With Night Blindness Differ in Function?
A person who has eyes with night blindness will function differently than
those without this vision issue. According to the National Library of
Medicine, night blindness, scientifically known as nyctalopia, either affects the
functionality of the rod cells or the pupils. The rod cells in [eye anatomy](https://www.oscarwylee.com.au/glasses/eye/anatomy)
are photoreceptors that are sensitive to low levels of light which help
people see at nighttime. If the rod cells are damaged, it can result in
night blindness, light sensitivity and diminished peripheral vision. The
pupils are responsible for letting light into the eye and they adjust
depending on the amount of light present. This is called the pupillary
light reflex and if it is impaired, it can result in night
blindness.
### What is the Research Available About Night Blindness?
There is noteworthy research available regarding night blindness,
scientifically known as nyctalopia. Some of the research and learnings
about night blindness are found in the American Academy of Ophthalmology and the National Library of
Medicine which are listed below.
* According to an article published by the American Academy of
Ophthalmology titled Shedding Light on Night Blindness published by
Kierstan Boyd in 2016, night blindness is not the inability to see at
night, rather it means your vision is worse when it is dark.
* An article that was updated in 2022 in the National Library of Medicine
titled, Physiology, Night Vision, by Divy Mehra and Patrick H. Le,
discusses night blindness on a cellular level and also explains the
development, mechanism and clinical significance, among other areas of
night blindness.
Visit a store near you
Come in and see our friendly staff where you can browse through our
wide range of stylish and on-trend glasses.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
## What are the Symptoms of Night Blindness?
Night blindness symptoms mainly stem from a person’s difficulty seeing when
it is dark.The symptoms of night blindness include poor night
vision, blurry vision at night and sensitivity to light. These symptoms and
their definitions are listed below.
| Symptoms of night blindness | Definition | Commonality |
| --- | --- | --- |
| Poor night vision | Night blindness is characterised by having poor vision at night and
can make certain activities difficult such as driving in the dark. | Poor night vision is the main symptom of night blindness. |
| Blurry vision at night | A person who has myopia will have blurry distance vision in the
daytime which will most likely worsen at night. | Blurry vision at night is common for people who have myopia. |
| Sensitivity to light | A person may develop a sensitivity to light if there is damage to
the rod cells in their eyes. | Sensitivity to light is a less common symptom of night blindness. |
According to an article titled Physiology, Night Vision
published in the National Library of Medicine, the main symptom of night
blindness is difficulty seeing in dim light or at nighttime.
## What are the Treatments for Night Blindness?
There are various treatments available for night blindness that are prescribed
depending on the underlying cause of this eye problem.
For example, if night blindness is caused by a cataract in the eye,
cataract surgery may be required to treat this eye condition. If myopia is
contributing to poor night vision, your optometrist will prescribe
prescription glasses and if you already wear glasses, then a stronger
prescription may be advised. According to the Cleveland Clinic, treatment
for night blindness that is caused by a retinal disease will need
additional investigation, performed by a retina specialist.
### How to Protect Eyes from Night Blindness with Dietary Changes?
To protect the eyes from night blindness, a person can implement
certain dietary changes by consuming Vitamin A and zinc. Vitamin A and zinc have been shown to play a role in the normal
function of a person’s eyesight, therefore, it is beneficial to ensure you do not have a Vitamin A or
zinc deficiency. The vitamins and minerals that can help protect the
eyes from night blindness are listed below.
* Vitamin A: Vitamin A is a fat-soluble
vitamin that is important for normal eyesight function. According to the
World Health Organisation, night blindness is one of the first signs of
vitamin A deficiency. Foods containing vitamin A include carrots,
pumpkin, sweet potato, eggs and fortified milk.
* Zinc: Zinc is a mineral that supports
many functions of the body including the immune system and thyroid
function. According to an article published in the National Library of
Medicine, a person with a zinc deficiency may develop night blindness.
There are many foods that contain zinc including fish, poultry, meat and
dairy.
### How to Diagnose Night Blindness?
Night blindness can be diagnosed in the same way as many other eye
conditions or issues which is through a comprehensive eye test. The
steps in a comprehensive eye test may include pre-testing, a slit lamp test, a visual acuity test and a visual field
test.
These tests and their definitions are listed below.
1. Pre-testing: Pre-testing occurs before
the main testing with an optometrist and is typically performed by an
optical dispenser or a trained staff member. This test will involve an
eye pressure test, also known as a tonometry test, which will assess
intraocular eye pressure. A digital photograph may also be taken of your
eye to assess any changes in the eye.
2. Slit lamp test: A slit lamp test will
assess your eye health and examine the anterior and posterior of the eye
which includes your cornea and iris.
3. Visual acuity test: A visual acuity test
measures the clarity and sharpness of a person's vision using a letter
chart. The results for this test will be denoted using a fraction such
as 20/20 which is the measurement of normal vision.
4. Visual field test: A visual field test
assesses your peripheral vision and it is particularly useful for
detecting glaucoma, which is a condition that can cause vision loss.
An eye test is very important for assessing the health of a person’s
eyes and their vision. Regular eye tests can help detect and treat any
eye conditions you may have. If you are in need of an eye test, find an
Oscar Wylee [Optometrist Australia](https://www.oscarwylee.com.au/locations/full-store-list.html) near you.
## How Do Optometrists Perform Night Blindness Tests?
An optometrist performs multiple tests throughout an [eye test](https://www.oscarwylee.com.au/booking), many of which may be helpful in diagnosing night blindness. According
to Optometrist.org, an optometrist may perform a test using the Pelli-Robson contrast
sensitivity chart which can help detect signs of night blindness. It is similar to a visual acuity test in that it uses a letter chart but
in this case, the letters are in different shades of grey.
### Does Oscar Wylee Help for Night Blindness?
Yes, [Oscar Wylee](https://www.oscarwylee.com.au/)
can help with night blindness by adding our Premium Anti-Reflective
coating to any pair of prescription and non-prescription glasses
which is an additional $45 on top of the price of a standard pair of
glasses. Anti-reflective glasses have many benefits such as enhancing
the clarity of your lenses, reducing glare from computer screens,
eliminating reflections in your glasses and improving your night vision.
Visit an Oscar Wylee store to browse our wide range of frames to suit
your needs where you can add an anti-reflective coating among other
add-ons and lens types.
## How to Drive During Night Blindness?
If you have night blindness, driving in the dark can be difficult but
according to Welia Health, there are certain ways you can improve your
night blindness when driving. These instructions include slowing down to allow a bigger reaction time, cleaning your windshield to
improve visibility, wearing prescription glasses, driving during the day
where possible and finally, wearing glasses with an anti-reflective
coating.
At Oscar Wylee, we offer a Premium Anti-Reflective lens coating for an
additional $45 on top of a pair of standard glasses which can be worn as [night driving glasses](https://www.oscarwylee.com.au/glasses/night-driving). This coating reduces reflections, providing the wearer with clear
vision and it is also scratch and smudge resistant as well as anti-static.
According to Glaucoma Australia, people who have glaucoma that affects
their vision may be issued a conditional licence which may prohibit them
from driving at night.
### How Does Night Blindness Differ From Normal Vision?
Night blindness differs from normal vision as it is characterised by not being able to see well at night. While a person’s nighttime vision is affected, their daytime vision
will be unimpaired. When it is dark, a person’s pupils with normal
vision will expand to see better at night or in dim lighting. A person
who has night blindness will have a different experience when in the
dark as conditions such as glaucoma or cataracts affect how the eyes
work. In the case of glaucoma, some of its medications can constrict a
person’s pupil, making it difficult to see at night. If you struggle to
see at night or in dim lighting, book an appointment with an eye care
professional as it may be a symptom or a more serious condition.
#### Is Night Blindness a Caused By Common Eye Problems?
Yes, night blindness (nyctalopia) may be caused by
[common eye problems](https://www.oscarwylee.com.au/glasses/eye/common-problems)
such as cataracts, glaucoma and myopia. Cataracts cause night
blindness as it limits the amount of light that can enter the eye. Night
blindness can be caused by glaucoma as it damages the optic nerve
resulting in vision loss. Finally, myopia may cause night blindness as
if a person’s distance vision is blurry in daylight, it is likely to be
worse in low light.
### What is the Difference Between Night Blindness and Colour Blindness?
The difference between night blindness and colour blindness is
how they affect a person’s vision. Night blindness is an eye
condition that causes the eyes to struggle to see in dim light and
experience poor night vision.
[Colour blindness](https://www.oscarwylee.com.au/glasses/eye/colour-blindness-types), more accurately called colour vision deficiency, is an eye condition in
which the eyes have difficulty seeing colours in a normal way.
Claim Glasses Through Your Health Fund
Oscar Wylee accepts all leading health funds.Visit us
today to claim.
[Discover health funds](https://www.oscarwylee.com.au/health-funds.html)
Your Eyes Need Care Too!
Stay on top of your eye health by booking an eye test with our friendly
optometrists.
[Book an eye test](https://www.oscarwylee.com.au/booking)