# Source: https://www.oscarwylee.com.au/glasses/collection/together.html

# TOGETHER EYEWEAR COLLECTION
A BLOOM OF COZY AND NATURAL COLOURS 
[](#layer-product-list)
The Together Collection brings you eyewear that is crafted to fit you and
all that makes you unique. Revolving around the theme of self-expression,
this collection of glasses embodies individuality, featuring distinctive
patterns and colourways, paired with a range of frame shapes and styles.
Stand out or blend in, the choice is yours.
14 Products        
Showing 14
1. [](https://www.oscarwylee.com.au/humphrey-optical.html)
[Humphrey](https://www.oscarwylee.com.au/humphrey-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/humphrey-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/humphrey-optical.html)
2. [](https://www.oscarwylee.com.au/serge-optical.html)
[Serge](https://www.oscarwylee.com.au/serge-optical.html)
$169.00    
[2 pairs from $199](https://www.oscarwylee.com.au/serge-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/serge-optical.html)
3. [](https://www.oscarwylee.com.au/serge-2-optical.html)
[Serge 2](https://www.oscarwylee.com.au/serge-2-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/serge-2-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/serge-2-optical.html)
4. [](https://www.oscarwylee.com.au/bowery-optical.html)
[Bowery](https://www.oscarwylee.com.au/bowery-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/bowery-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/bowery-optical.html)
5. [](https://www.oscarwylee.com.au/mesa-optical.html)
[Mesa](https://www.oscarwylee.com.au/mesa-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/mesa-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/mesa-optical.html)
6. [](https://www.oscarwylee.com.au/zola-optical.html)
[Zola](https://www.oscarwylee.com.au/zola-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/zola-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/zola-optical.html)
7. [](https://www.oscarwylee.com.au/peyton-optical.html)
[Peyton](https://www.oscarwylee.com.au/peyton-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/peyton-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/peyton-optical.html)
8. [](https://www.oscarwylee.com.au/frieda-optical.html)
[Frieda](https://www.oscarwylee.com.au/frieda-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/frieda-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/frieda-optical.html)
9. [](https://www.oscarwylee.com.au/parker-l-optical.html)
[Parker Large](https://www.oscarwylee.com.au/parker-l-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/parker-l-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/parker-l-optical.html)
10. [](https://www.oscarwylee.com.au/thomas-optical.html)
[Thomas](https://www.oscarwylee.com.au/thomas-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/thomas-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/thomas-optical.html)
11. [](https://www.oscarwylee.com.au/kyle-optical.html)
[Kyle](https://www.oscarwylee.com.au/kyle-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/kyle-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/kyle-optical.html)
12. [](https://www.oscarwylee.com.au/parker-optical.html)
[Parker](https://www.oscarwylee.com.au/parker-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/parker-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/parker-optical.html)
13. [](https://www.oscarwylee.com.au/kristof-optical.html)
[Kristof](https://www.oscarwylee.com.au/kristof-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/kristof-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/kristof-optical.html)
14. [](https://www.oscarwylee.com.au/elodie-optical.html)
[Elodie](https://www.oscarwylee.com.au/elodie-optical.html)
$199    
[2 pairs from $249](https://www.oscarwylee.com.au/elodie-optical.html)
14 Products        
Showing 14
Show All
## What is the Together Eyewear Collection?
The Together Eyewear Collection features
glasses varied in colour, shape and design, aiming to celebrate
individual expression and style. Anyone can find a frame from the collection that resonates with
their fashion sense. From bold and striking colours to subdued,
minimal tones, there is a frame perfect for any face.
## What Materials are Used to Make Together Eyewear?
The materials used to make the eyewear found in the Together
Collection include
acetate, acetate &amp; metal, metal and titanium. Read on for
more on these materials listed below.
* Acetate: Acetate glasses are a strong, flexible and
hypoallergenic material.
[Acetate frames](https://www.oscarwylee.com.au/glasses/acetate-frame)
come in a variety of colours and patterns, with an often thicker
frame.
* Acetate &amp; Metal: Acetate &amp; metal glasses provide strength
and striking, contrasting aesthetics between the two materials.
* Metal:
[Metal glasses](https://www.oscarwylee.com.au/glasses/metal)
provide a thinner, minimal aesthetic for those who prefer more
subtle eyewear.
* Titanium:
[Titanium](https://www.oscarwylee.com.au/glasses/titanium)
eyewear is renowned for its lightweightness for comfortable wear
and a minimal look.
## Which Frame Styles are Included in the Together Eyewear Collection?
The frame styles that are included in the Together Eyewear
Collection are
Humphrey, Serge, Serge 2, Bowery, Mesa, Zola, Peyton, Frieda,
Parker Large, Thomas, Kyle, Parker, Kristof and Elodie. These frames are diverse in appearance and able to cater to
[different face shapes](https://www.oscarwylee.com.au/glasses/face-shapes). The frame options from Oscar Wylee's Together collection are
listed below.
* Humphrey: Acetate and metal come together to create
Humphrey - a lightweight and classic frame. Humphrey is perfect
for those who prefer a more subdued palette.
* Serge: The iconic Serge is for the bold and adventurous,
now in three striking colourways.
* Serge 2: Serge 2 has its original's wide fit and square
shape but with silicone nose pads and 5-barrel hinges for
adjustability and comfort. This is the perfect frame to
accommodate those who want added comfort during wear.
* Bowery: Bowery, with its geometric shape, now comes in
black for intriguing, novel charm.
* Mesa: Mesa's square frame is a classic choice, in three
new vibrant colours: Cherry, Spearmint and Blue Lagoon.
* Zola: This simple and feminine Zola now comes in two new
colours in this collection: Milthril and Marshmallow.
* Peyton: Playful Peyton, a cute pair launched in two
colours in the Together collection: Opal Tortoise and Autumn
Petal.
* Frieda: With subtle dramatic flair, Frieda brings a
feminine energy in two colours: Orchid Fade and Cherry.
* Parker Large: The classic Parker stands out in two
exciting colourways: Jade and Speckled Bluebird.
* Thomas: Thomas in its Blueberry Tortoise colour, is a
unique frame, perfect for any occasion with a classic frame.
* Kyle: Exude true individuality with the Kyle frame,
created to reflect who you are with a classic frame and unique
colourways.
* Parker: Parker is a classic and sleek frame. Parker is
for those who want to look sharp every day of the week.
* Kristof: Kristof draws from cinematic inspiration with
its pronounced classic shape for those who have an eye for the
dramatic.
* Elodie: Elodie boasts a titanium frame for a lightweight
profile, for the unique and carefree.
## How does Together Eyewear Deliver Superior Quality?
The Together Eyewear Collection
delivers superior quality through high-quality materials and
unique colourways.
Like other Oscar Wylee collections, the frames are made from
materials such as acetate and various metals, which are notably
good materials for the creation of eyewear. The Together
Collection is about celebrating the beauty of individuality, with
intriguing colourways ranging from neutrals to bold shades. This
aims to appeal to any person's sense of style and individuality.
## Is Together Eyewear Environmentally Friendly?
The Together eyewear collection
can be considered environmentally friendly in relation to the
frames in the collection that are made from bioacetate. Bioacetate is a material made mainly from renewable plant
matter such as wood pulp and cotton fibres. There is a lesser
amount of non-biodegradable plasticisers present compared to
regular acetate. Bioacetate reduces certain non-renewable
components compared to traditional acetate, but is not fully
biodegradable. The Together Collection frames that are made from
bio-acetate are listed below.
* Kristof: Kristoff has a pronounced classic
shape.
* Kyle: Kyle is a classic shape in unique
colourways.
## What Makes the Together Eyewear Collection Different from Eyewear?
The Together Eyewear Collection is
different from other eyewear collections through its theme,
centred on individuality and self-expression. The collection features an array of shapes and designs, from
bold, square frames to neutral-toned circular frames. This variety
is to reflect the aesthetics of a range of demographics and the
beauty present in this diversity.
## Why are Together Eyewear Popular for Everyday Wear?
The Together Eyewear collection is popular for everyday wear as
they are both practical and stylish.
The Together Collection boasts a range of frames in bold, bright
and neutral colours. Whether bright blue or subdued pink, these
frames aim to showcase your style and sense of individuality,
making them popular for everyday wear alongside your favourite
outfits.
## What Lens Protection and Features Does Together Eyewear Provide?
The lens protection and features provided by the Together
Eyewear collection are the same as the other frames available at
Oscar Wylee. Like all other Oscar Wylee eyewear, glasses from the together
collection feature UV 400 protection which is the highest level of
protection against the sun's UV light rays, blocking 99–100
percent of UV light. You can purchase add-ons to your Together
eyewear frame that can make the lenses more personalised to you.
For example, the Premium Anti-Reflective filter reduces
reflection, is scratch and smudge resistant and anti-static. There
is also the
[BLULite filter](https://www.oscarwylee.com.au/blue-light-glasses.html)
which reduces the amount of harmful blue light rays that emit from
digital screens.
## Due for an Eye Test?
Oscar Wylee offers bulk billed eye tests for valid Medicare
cardholders. Visit us in-store to get your eyes checked.
[Book an eye test](https://www.oscarwylee.com.au/booking)
## OW Together Collection In-Store
Find a store near you to try on the new collection.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)