# Source: https://www.oscarwylee.com.au/glasses/eye/neovascular-glaucoma

# Neovascular Glaucoma: Meaning and Treatment
Published on March 26th, 2026
Australia
Australia
New Zealand
Canada
Canadian French

Neovascular glaucoma is
a severe case of secondary glaucoma that stems from the growth of new
blood vessels on the angle of the anterior chamber.
Neovascular glaucoma
can lead to significant vision loss and is considered difficult to
manage. The causes of neovascular glaucoma may include retinal vein occlusion,
advanced diabetic eye disease and ocular ischaemic syndrome, according to
Glaucoma Australia. Patients with neovascular glaucoma may experience
symptoms such as increased intraocular pressure, eye pain, and more
potential harm to vision. Treating this condition may require focusing on
controlling the increased pressure and identifying the underlying cause.
See an optometrist for expert eye care services
We have dedicated teams and optometrists at every store ready to assist
you!
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Definition](#definition)
[Causes](#causes)
[Symptoms](#symptoms)
[Treatment](#treatment)
## What is Neovascular Glaucoma (NVG)?
Neovascular glaucoma is
characterised by the formation of new blood vessels within the
anterior chamber angle of the eye, disrupting the eye's drainage
system, leading to a severe form of glaucoma.
Neovascular glaucoma is typically caused by a reduced supply of oxygen
in the retina, signalling the choroid to grow new blood vessels as a
response. The new vessels can cause a blockage, causing fluid to build
up and increase ocular pressure, ultimately causing neovascular
glaucoma. This condition is commonly associated with conditions such as
central retinal vein occlusion, diabetic retinopathy, or ocular ischemic
syndrome, according to Eye Wiki.
#### Is Neovascular Glaucoma Caused by Abnormal New Blood Vessel Growth in
the Eye?
Yes, neovascular glaucoma
may be caused by abnormal blood vessel growth over the drainage
pathways in the eye.
Neovascular glaucoma is often linked to eye conditions that disrupt
proper blood flow to the retina, which causes a growth factor known as
vascular endothelial growth factor or VEGF. This is what helps the
formation of new blood vessels that are weak and vulnerable, leading
to bleeding and inflammation.
## What Causes Neovascular Glaucoma to Develop?
What causes neovascular glaucoma to develop can include
proliferative diabetic retinopathy, retinal vein occlusion,
and ocular ischemic syndrome. The potential causes of
neovascular glaucoma are listed below.
* Proliferative Diabetic Retinopathy: Proliferative diabetic retinopathy may be a cause of neovascular
glaucoma if diabetes is severe and untreated.
* Retinal Vein Occlusion: Retinal vein
occlusion can contribute as a cause in developing neovascular glaucoma
and can occur when one of the veins in the retina becomes blocked.
* Ocular Ischemic Syndrome: Ocular
ischemic syndrome is defined as a severe condition that can arise from
reduced blood flow to the eye and can lead to the increased risk of
developing neovascular glaucoma.
### Which Retinal Diseases Commonly Trigger Neovascular Glaucoma?
The retinal diseases that can commonly trigger neovascular glaucoma
may include
proliferative diabetic retinopathy, retinal vein occlusion and
ocular ischemic syndrome.
The retinal diseases that may commonly trigger neovascular glaucoma
are listed below.
* Proliferative Diabetic Retinopathy: Proliferative diabetic retinopathy is considered the most advanced
stage of diabetic eye disease, especially when poorly controlled,
can trigger the abnormal growth of blood vessels, leading to the
development of neovascular glaucoma.
* Retinal Vein Occlusion: Retinal vein
occlusion refers to a blockage in one of the retinal veins that can
disrupt normal blood flow, which may contribute to the development
of neovascular glaucoma.
* Ocular Ischemic Syndrome: Ocular
ischemic syndrome is considered a serious condition that can result
from reduced ocular blood supply and can be associated with the
increased risk of developing neovascular glaucoma.
## Proliferative Diabetic Retinopathy
Proliferative diabetic retinopathy is the most advanced stage of
diabetic eye disease, potentially caused by the growth of new blood
vessels in the retina.
Proliferative
[diabetic retinopathy](https://www.oscarwylee.com.au/glasses/eye/diabetic-retinopathy)
may be a likely cause of neovascular glaucoma as it can damage the
retinal blood vessels,
which can then lead to the development of new blood vessels along the
iris and drainage angle. This can block the eye's drainage system and
cause a build-up of fluid, which can result in increased pressure,
according to Tang et al., (2023).
## Retinal Vein Occlusion
Retinal vein occlusion
can be a likely cause of neovascular glaucoma due to the
consequential ischemia
in the retina from causes such as a vein blockage. Neovascular glaucoma
occurs as a result of retinal vein occlusion due to the blockage of the
vein, causing a severe lack of oxygen, triggering the growth of new
blood vessels. These new blood vessels can block the eye's drainage
system, leading to a marked increase in intraocular pressure and, hence,
neovascular glaucoma.
## Ocular Ischemic Syndrome
Ocular ischemic syndrome is
characterised as a severe vascular condition that can arise when the
retina does not receive optimal nutrients and oxygen. This can then lead to the development of new blood vessels,
obstructing the eye's drainage system, initiating neovascular glaucoma.
#### Can Diabetic Retinopathy Cause Neovascular Glaucoma?
Yes, diabetic retinopathy can cause neovascular glaucoma
due to its consequential oxygen and blood deprivation, triggering
the growth of abnormal vessels.
The new vessels that grow in response are leaky and weak and the new
vessels that grow in response are leaky and weak and can form a
network across the eye's drain angle, reducing outflow and increasing
intraocular pressure, causing neovascular glaucoma.
## Why is Neovascular Glaucoma Sometimes Called 100 Day Glaucoma?
Neovascular glaucoma may sometimes be called 100-day glaucoma
due to its onset typically occurring around 90-100 days after central
retinal vein occlusion,
according to Havens and Gulati (2017). However, while neovascular
glaucoma has been referred to as 90 or 100-day glaucoma historically, it
can ensue anywhere between 2 weeks and 2 years after initial retinal
vein occlusion.
### How does Retinal Ischemia Lead to Rapid NVG Development?
Retinal ischemia may lead to rapid NVG development
as it can cause a state of oxygen starvation that can trigger the
release of VEGF. This protein causes abnormal blood vessels to develop across the
eye's drainage angle, physically blocking the eye's fluid from flowing
out, causing a rapid increase in ocular pressure, according to
Urbonavičiūtė et al., (2022).
### How does Neovascular Glaucoma Affect Eye Pressure?
Neovascular glaucoma can affect
[eye pressure](https://www.oscarwylee.com.au/glasses/eye/pressure-behind-eye)
by growing new blood vessels, blocking the eye's natural fluid
drainage pathways.
The
blockage then causes a buildup of fluid, leading to increased
intraocular pressure,
which can damage structures within the eye, affecting vision.
### What Happens to the Eye's Drainage Angle When New Blood Vessels Form?
The eye's drainage angle
can become blocked when new blood vessels form as they develop
along the drainage angle.
The drainage angle of the eye, also known as the 'angle' of the eye,
is the section between the iris and cornea and helps maintain eye
pressure through the trabecular meshwork, where the fluid flows out.
The new vessels that form are weak and leaky, which results in
scarring and due to their location of growth, over the drainage
channels, the eye fluid cannot drain properly, according to
Radhakrishnan, MD from the Glaucoma Research Foundation.
## Does Neovascularisation Block Aqueous Humour Outflow?
Yes, neovascularisation can block aqueous humour outflow
as the new vessels physically hinder the fluid from draining out of
the eye. Neovascularisation refers to the growth of new blood vessels along
the drainage angle as a survival response to the lack of blood or oxygen
in the eye. The vessels that grow, however, are weak and leaky and can
result in scar tissue forming, obstructing the drainage angle and
causing eye pressure to build up.
Visit us in-store!
See our team and optometrist in-store for any of your eyecare needs.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
## What Symptoms Can Indicate Neovascular Glaucoma?
The symptoms that may indicate neovascular glaucoma can include
eye pain, red eye, blurred vision and loss of vision.
The symptoms that can indicate neovascular glaucoma are listed below.
* Eye Pain: Eye pain can be a symptom of
neovascular glaucoma due to the increased pressure inside the eye,
which itself can cause discomfort and press on the structures in the
eye.
* Red Eye: Red eyes may ensue as a
result of neovascular glaucoma, potentially from the abnormal growth
of new blood vessels along the drainage angle.
* Blurred Vision: Blurry vision can
arise during neovascular glaucoma from the initial development of
diabetic retinopathy, being the most common cause of neovascular
glaucoma.
* Loss of vision: Loss of vision can be
a symptom of neovascular glaucoma, as the increased pressure in the
eye can cause damage to important structures.
## Eye Pain
Eye pain can occur as a symptom of neovascular glaucoma mainly
due to the significant increase in intraocular pressure. The growth of new vessels blocking the eye's drainage pathways and
hindering optimal fluid outflow leads to the pressure build-up and
consequential
[eye pain](https://www.oscarwylee.com.au/glasses/eye/pain-definition).
## Red Eye
Red eyes can come about when experiencing neovascular glaucoma
as a result of the new blood vessels that are fragile and grow along
the drainage angle.
The newly grown blood vessels on the iris may be more visible, and the
high intraocular pressure may also contribute to the inflamed and,
therefore, red hue. The new blood vessels, being fragile, can cause
bleeding inside the eye, also contributing to the appearance of
[red eyes](https://www.oscarwylee.com.au/glasses/eye/red-or-bloodshot).
## Blurred Vision
Blurred vision can ensue during neovascular glaucoma,
similarly to the increased pressure in the eye. The blockage of the
fluid properly draining from the eye can cause damage to the optic
nerve, causing impaired or blurred vision, as well as from the retinal ischemia.
## Loss of Vision
Loss of vision from neovascular glaucoma
may occur as the increased pressure can potentially damage the optic
nerve, which can contribute to loss of vision. The increased pressure is caused by the blocked drainage angle in the
eye and can push on the internal structures of the eye.
### How do Vision Changes Develop as Neovascular Glaucoma Progresses?
Vision changes may worsen as neovascular glaucoma progresses; however,
this may likely depend on the patient's condition and other health
factors.
Neovascular glaucoma can lead to vision loss and blindness in
severe cases, as the increased pressure can damage the optic nerve,
which is what helps the eye to carry transmitted signals from the
retina to the brain.
#### Can Neovascular Glaucoma Cause Blurred Vision?
Yes, neovascular glaucoma can cause blurred vision
due to the increased pressure in the eye. Due to
the blockage of fluid, increasing intraocular pressure can cause
swelling, which can contribute to
[blurry vision](https://www.oscarwylee.com.au/glasses/eye/blurred-vision). If the ocular pressure remains, it can also physically compress
the optic nerve and blur vision.
## What Causes Eye Pain and Redness in Neovascular Glaucoma?
The causes of eye pain and redness in neovascular glaucoma
can be from the increased pressure in the eye, inflammation and
corneal edema.
High intraocular pressure may trigger eye pain and redness as the rapid
pressure rise may affect the cornea, iris and ciliary body. The abnormal
vessels that are triggered by retinal ischemia are usually fragile and
can leak, leading to inflammation, which can also cause eye pain and
redness. Swelling due to the high eye pressure can also contribute to
eye pain and redness in neovascular glaucoma.
### Why do Patients Experience Severe Ocular Discomfort in NVG?
Patients may experience severe ocular discomfort
due to NVG as a result of the high pressure in the eye.
Oxygen or blood starvation in the eye can trigger the abnormal growth
of new blood vessels as compensation, leading to the blockage of the
eye's drainage system. This then leads to the high pressure in the
eye, and therefore, what contributes to the ocular discomfort during
NVG.
#### Can Neovascular Glaucoma Cause Red or Bloodshot Eyes?
Yes, neovascular glaucoma can cause red or bloodshot eyes
due to the accompanying complications. The abnormal
growth of new blood vessels on the iris and drainage angle, the
increased pressure in the eye itself and the abnormal vessels that
can bleed leading to inflammation, are all possible causes for red
or bloodshot eyes.
## How do Eye Doctors Diagnose Neovascular Glaucoma?
Eye doctors can diagnose neovascular glaucoma through a
slit-lamp examination, fluorescein angiography, gonioscopy, tonometry
and fundus exam.
A slit-lamp examination and fluorescein angiography can assist with
checking the eye for any newly grown vessels on the iris. A gonioscopy
can aid in identifying new vessels in the anterior chamber angle prior
to their appearance on the iris' surface. Tonometry can help with
assessing ocular pressure and a fundus exam can help with detecting
underlying causes often linked to neovascular glaucoma, such as retinal
vein occlusion and diabetic retinopathy. While optometrists will be able
to diagnose neovascular glaucoma, they will then refer you to an
[eye doctor](https://www.oscarwylee.com.au/glasses/eye/doctors)
or also known as an ophthalmologist for further evaluation and
treatment.
#### Can a Comprehensive Eye Test Detect Early Signs of NVG?
Yes, a comprehensive eye test can detect early signs of NVG.
A comprehensive
[eye test](https://www.oscarwylee.com.au/glasses/eye/test-glossary)
initially conducted by an optometrist will be able to identify the
early signs of neovascular glaucoma and can then refer you to an
ophthalmologist.
It is important to get your eyes tested if you experience any changes
to your vision to ensure early detection.
## What Treatments are Available for Neovascular Glaucoma?
The treatments that are available for neovascular glaucoma can include
eye drops, oral agents and intravitreal injections. The
primary goals of treating neovascular glaucoma revolve around first
addressing the intraocular pressure and identifying and treating the
underlying cause, according to Glaucoma Australia. The list of
treatments available for neovascular glaucoma is listed below.
* Eye Drops: Eye drops may be used as
treatment for neovascular glaucoma in order to reduce the production
of aqueous fluid, ultimately to decrease ocular pressure.
* Oral Agents: An oral agent, such as
acetazolamide, may be additionally required to aid in controlling
intraocular pressure.
* Intravitreal Injections: Intravitreal
injections may be available to help treat neovascular glaucoma, to
stop stress response chemicals, or growth factors. The injection is
inserted into the eye to rapidly disrupt the neovascular process, but
is not considered a complete treatment on its own.
### How do Doctors Lower Eye Pressure in Neovascular Glaucoma?
Doctors may lower eye pressure in neovascular glaucoma
by using certain eye drops or medications. Doctors may first use
eye drops and medications such as beta blockers or alpha-2
agonists
to reduce eye pressure, address inflammation or resort to stronger
oral medications, according to Rodrigues et al., (2016).
#### Can Medications Help Reduce Intraocular Pressure in NVG?
Yes, medications
may help reduce intraocular pressure in NVG and include eye drops
and oral medications.
Eye doctors may likely opt for eye drops and medications as a first
choice of treatment when controlling high intraocular pressure in
NVG.
## How is Neovascular Glaucoma Different from Other Types of Glaucoma?
Neovascular glaucoma
is different from other types of glaucoma as it stems from the growth
of new blood vessels in the eye, which blocks the eye's drainage
system. It is often linked to other eye diseases, such as diabetic
retinopathy or central retinal vein occlusion and may be more
complicated to treat
as it revolves around eye pressure reduction and addressing the
underlying cause. Other types of
[glaucoma](https://www.oscarwylee.com.au/glasses/eye/glaucoma)
may progress more slowly, while neovascular glaucoma is considered
secondary and more aggressive.
### What Makes NVG More Aggressive Than Primary Glaucoma?
What makes NVG more aggressive than primary glaucoma may be
due to its more rapid progression of vision loss. The consequences
of severe ischemia and growth of new blood vessels, which cause
obstruction where the eye's fluids flow out,
are also what might make NVG more aggressive than glaucoma.
### Is Neovascular Glaucoma Considered a Secondary Glaucoma?
Yes, neovascular glaucoma is considered a secondary glaucoma.
According to Mishra and Meyer (2022),
neovascular glaucoma is defined as a secondary glaucoma
characterised by the growth of new blood vessels on the iris and angle
of the anterior chamber.
## What Complications Can Occur if Neovascular Glaucoma Is Not Treated?
The complications that can occur if neovascular glaucoma is not treated
can potentially lead to severe visual impairment.
According to Rakusiewicz-Krasnodębska et at., (2025), the management of
NVG requires a complex approach of including both management of
intraocular pressure and treatment of the underlying retinal ischemia.
### How does Untreated NVG Affect Vision Over Time?
Untreated NVG may worsen vision over time,
potentially leading to blindness. According to
Urbonavičiūtė et al., (2022), untreated neovascular glaucoma may
progress from secondary open-angle glaucoma to angle-closure glaucoma,
resulting in irreversible blindness. Due to the risk of blindness, NVG
is considered an ophthalmic emergency.
#### Can Untreated Neovascular Glaucoma Cause Permanent Vision Loss?
Yes, untreated neovascular glaucoma
can cause permanent vision loss. The resulting vision loss from
neovascular glaucoma when untreated will, however, depend on the
severity of the condition
and the individual. According to Drinkwater et al., (2018),
neovascular glaucoma usually results in vision loss and carries a
poor prognosis.
Read Neovascular Glaucoma: Meaning and Treatment in other Oscar Wylee
regions and their languages.
Australia
Australia
New Zealand
Canada
Canadian French

Experience Quality Eye Care!
We have knowledgeable optometrists at Oscar Wylee, who are available
in-store to perform high-quality eye tests.
[Book an eye test](https://www.oscarwylee.com.au/booking)
Oscar Wylee Accepts Major Health Funds In-store
Visit Oscar Wylee in-store for eye care and eye wear services, and
your health fund may help cover some of the cost.
[Explore health funds](https://www.oscarwylee.com.au/health-funds.html)