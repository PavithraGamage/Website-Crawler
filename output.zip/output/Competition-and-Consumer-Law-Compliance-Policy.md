# Source: https://www.oscarwylee.com.au/legal/compliance-policy.html

# Oscar Wylee Competition and Consumer Law Compliance Policy
## Purpose
This policy is designed to facilitate Oscar Wylee’s compliance with its obligations under the Competition and Consumer Act 2010 (CCA) including the Australian Consumer Law (ACL), which is part of the CCA and to promote a culture of compliance with the CCA.
## Scope
This policy applies to all Oscar Wylee Board members, directors, officers, employees, agents and contractors who perform duties for or on behalf of Oscar Wylee.
## Our Commitment
Oscar Wylee is committed to the observance of all laws and the highest ethical standards. Compliance with the CCA is a critical element of this commitment.Oscar Wylee strives to be an organisation where:
* our people demonstrate commitment to compliance;
* we have useful systems and procedures to support and assist us to comply with the CCA;
* we provide interesting, effective and ongoing training on our responsibilities and obligations arising under the CCA;
* our personnel are held accountable for their performance and their conduct.
## The Australian Consumer Law
The ACL is Australia’s national, state and territory law that aims to protect consumers and ensure fair trading in Australia. It applies to all our business activities such as advertising, selling, supplying, sourcing, pricing and dealing with consumers in any capacity.Some key provisions of the ACL mean that we must:
* not engage in misleading or deceptive conduct;
* not make false or misleading representations about goods or services;
* not supply goods that do not comply with mandatory standards or are unsafe;
* provide an appropriate remedy if a consumer’s rights under the consumer guarantee provisions of the ACL are not met.
## Consequences
Companies and individuals that engage in conduct in contravention of the CCA even if those contraventions are innocent or unintentional, may be exposing themselves to penalties and fines, damages, Court orders and other serious consequences.
Oscar Wylee will take action internally against any persons who are knowingly or recklessly concerned in a contravention of the CCA and will not indemnify them in the event of any liability to pay a pecuniary penalty or legal costs incurred in defending or resisting court proceedings in which the person is found to have such a liability in respect of that contravention. Deliberate non-compliance with the CCA will not be tolerated and may result in dismissal.
## Our strategy for ensuring compliance
Oscar Wylee’s commitment to ensuring it meets its obligations under the CCA includes the development, implementation and maintenance of a Consumer Law Compliance Program (Compliance Program) designed to:
* prevent, identify and rectify any potential contraventions of the ACL;
* ensure awareness of our responsibilities and obligations in relation to relevant provisions of the ACL;
* assist Oscar Wylee to continue to be a good corporate citizen.
Some key elements of Oscar Wylee’s Compliance Program include:
* this Compliance Policy;
* a Compliance Officer who has overall responsibility for ensuring our Compliance Program is effectively designed, implemented and maintained;
* a Compliance Advisor to assist Oscar Wylee to strengthen its Compliance Program;
* awareness of consumer law compliance issues for relevant persons as part of their induction;
* regular training for relevant persons on their duties and obligations under the ACL;
* a Complaints Handling System capable of identifying, classifying, storing and responding to competition and consumer law complaints;
* Whistleblower Protection Mechanisms to protect those coming forward with consumer law complaints;
* documented compliance processes to assist Oscar Wylee to meet our obligations;
* regular reporting on the continuing effectiveness of our Compliance Program.
## Responsibilities
Oscar Wylee is committed to giving our staff appropriate resources by way of systems, training, and support to enable them to meet their obligations and avoid liability and loss to themselves and the business.
Oscar Wylee representatives are required to:
* familiarise themselves with this Compliance Policy;
* comply with all aspects of Oscar Wylee’s Compliance Program and make proper use of the systems, training, and support provided by the business;
* complete all required compliance training in a timely manner when required to do so;
* observe the spirit and the letter of the law and exercise high standards of ethical conduct when performing any duties for Oscar Wylee;
* seek guidance and assistance as required to ensure you comply with your obligations;
* report any Compliance Program related issues or CCA compliance concerns to Oscar Wylee’s Compliance Officer as soon as you become aware of such a matter.
## Reporting Concerns or Wrongdoing
You can contact the Compliance Officer by:
* Telephone: [(+61) 02 8355 4646](tel:+6183554646)
* Email: [[email&nbsp;protected]](/cdn-cgi/l/email-protection#a4c7cbc9d4c8cdc5cac7c1e4cbd7c7c5d6d3ddc8c1c18ac7cbc9)
Oscar Wylee will not act to the detriment of any employee as a consequence of them raising with management in good faith any breach of law or any violation of Oscar Wylee’s principles or values or any other legal or ethical concerns. Oscar Wylee guarantees that whistleblowers with CCA compliance concerns will not be prosecuted or disadvantaged in any way and that their reports will be kept confidential and secure.