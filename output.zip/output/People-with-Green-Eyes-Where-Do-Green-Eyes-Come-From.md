# Source: https://www.oscarwylee.com.au/glasses/eye/green

# People with Green Eyes: Where Do Green Eyes Come From?
Published on February 28th, 2025
Updated on Month Date, 2025  
Australia   
[Australia](https://www.oscarwylee.com.au/glasses/eye/green)
[New Zealand](https://www.oscarwylee.co.nz/glasses/eye/green)
[Canada](https://oscarwylee.ca/glasses/eye/green)
Canadian French

Green eyes may be considered rare, with just around 2% of the world’s population having green eyes, according to the American Academy of Ophthalmology. OCA2 is a gene responsible for creating melanin, which is a substance that affects the pigmentation of your hair, eyes and skin. The different types of green eyes can include light green eyes, dark green eyes and hazel green eyes. While there are no physiological benefits of having green eyes, they may be perceived as a unique eye colour due to their rarity. Continue reading to explore green eyes more.
[Definition](#Definition) [Prevalence](#Prevalence) [Types](#Types) [Recommended Glasses Frames](#Recommended)
Do You Have Any Eye Health Concerns?
See one of our highly skilled and knowledgeable optometrists in-store.
[Book an eye test](https://www.oscarwylee.com.au/booking)
## Different Types of Eye Colours
There are several different types of eye colours including green, brown, amber, hazel, blue, and grey.
## What is Green Eye Colour?
Green eye colours are the rarest occurring eye colour and may stem from an amalgamation of eumelanin and a small portion of pheomelanin. Different types of green eyes may include light green, dark green and hazel green. To inherit green eyes, two copies of the allele are required. Eumelanin is one of the two types of melanin and is black-brown in colour,, while pheomelanin is the other type of melanin and is yellow-red in colour, according to ScienceDirect. [Different eye colours](https://www.oscarwylee.com.au/glasses/eye/colour) are associated with the amount of melanin that is present in the front portions of the iris according to MedlinePlus.
### How Rare are Green Eyes?
Green eyes may be considered very rare with only 2% of people in the world possessing this eye colour according to the American Academy of Ophthalmology. In comparison, blue eyes are suggested to be more common with around 8-10% of people in the world having blue eyes according to World Population Review. Around 70-80% of the world's population has brown eyes and 5% have hazel eyes according to Medical News Today.
## Where do Green Eyes Come From?
Green eyes come from a combination of black-brown and a small amount of yellow-red. They have low levels of melanin, resulting in the scattering of light in the stroma and making them appear green. The light scattering in green eyes may be known as Rayleigh scattering, which can only occur when there is little melanin in the eyes.
## What are the Different Types of Green Eyes?
The different types of green eyes include light green eyes, hazel-green eyes, and dark green. The different types of eye colours are listed below.
* Light Green Eyes: Light green eyes may refer to green eyes that have more yellow hues giving them a lighter appearance. Light green eyes may look like they slightly change in colour depending on different lighting.
* Hazel-Green Eyes: Hazel-green eyes are typically described as having a unique mix of brown and sometimes amber hues. Hazel green eyes can often be mistaken for brown eyes due to their mix and how the light is scattered.
* Dark Green Eyes: Dark green eyes may refer to green eyes that are not as vibrant as light green eyes and are one solid colour. However, there are cases where dark green eyes also have some brown in them enabling a darker appearance.
### 1. Light Green Eyes
Light green eyes can be described as green eyes that include more yellow hues, which is what may give them a lighter appearance. Light green eyes can often look like they’re slightly changing in colour in different lighting conditions due to their lesser amount of melanin.
### 2. Hazel-Green Eyes
Hazel green eyes are unique due to their combination of green and brown and sometimes amber hues. Hazel green eyes are often perceived as brown eyes due to the nature of their colour mix, which can also be seen as a small brown ring around the pupils of their eyes. Hazel green eyes can sometimes change slightly in colour under different lighting conditions due to their various colours.
### 3. Dark Green Eyes
Dark green eyes differ from light green eyes as they may not be as bright or vibrant but still give off a green colour. Dark green eyes usually have one solid colour, however, there are dark green eyes that feature some brown in them. Dark green eyes with hints of brown may be the cause of what gives them their darker shade appearance.
### What Countries Have Green Eyes?
The countries that have green eyes may be Ireland and Scotland, with over 75% of people who inherit green eyes found in these two countries. Generally, the countries located in Northern, Western and Central Europe have more people with green eyes according to World Population Review. While there may be higher rates of individuals born with green eyes located in European countries, there are other countries that also have people with green eyes. No ethnicity or country only has green eyes.
See Our Dedicated Team at One of Our Stores Today!
Visit your local Oscar Wylee team for your eye care needs, quality eye tests and new frames.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
## What are the Benefits of Having Green Eyes?
There are no significant benefits of having green eyes as they do not affect vision or any other physiological aspects. However, green eyes may be perceived as a unique eye colour due to how rare they are.
### How do Green Eyes Compare to Blue Eyes?
Green eyes compared to blue eyes can be similar in the fact that they both have less melanin present, which is what gives them their green and blue colour appearances. Green and blue eyes do not have any pigment in the iris, causing more light scattering according to Kugler Vision.
## What are the Downsides of Having Green Eyes?
There are no downsides to having green eyes as eye colour does not necessarily affect vision function or any major physiological aspects. However, it is often said that those with lighter eye colours may be more susceptible to light sensitivity due to having less pigment for protection. However, this may be largely attributed to how much sun exposure you allow yourself and can still affect those with darker eye colours. It is recommended that those with lighter eye colours use sunglasses when in direct sunlight to prevent discomfort, however, this also applies to every individual to prevent [UV light](https://www.oscarwylee.com.au/glasses/eye/uv-light) damage.
### Are Green Eyes Associated with Eye Deficiencies?
Yes, green eyes may be more associated with light sensitivity due to possessing less melanin pigment and therefore less protection. Melanin is a type of pigment that is present in the eye and helps to protect the eyes as it can function as a defence mechanism according to the American Cancer Society. Darker coloured eyes contain more pigment, enabling their apparent presence of colour in the iris. Lighter coloured eyes such as green eyes contain less melanin, causing more light scattering in the iris enabling the appearance of a green colour. It is important to note that while lighter colour eyes can be more at risk of light sensitivity, all eye colours are still vulnerable to damage from the sunlight. Therefore, it is important to get regular eye tests and wear sunglasses for sun protection, which are essential ways to care for your [eye health](https://www.oscarwylee.com.au/glasses/eye/health-tips-keeping-eyesight-healthy).
### Can Green Eyes Be Covered with Contact Lenses?
Yes, green eyes can be covered with contact lenses. Anyone with any eye colour and refractive errors such as farsightedness, nearsightedness or astigmatism can wear [contact lenses](https://www.oscarwylee.com.au/glasses/eye/contact-lenses) to have clear vision. It is important to note that Oscar Wylee does not sell contact lenses.
### What Glasses Frames Best Complement Green Eye Colour?
The glasses frames that complement green eye colours best may include earthy tones such as neutrals, tortoiseshell frames, certain green shades, clear frames, black frames and metal frames. At Oscar Wylee, we have these colours available in a wide range of shapes and styles which you can browse online or in-store.
Read People with Green Eyes: Where Do Green Eyes Come From? in other Oscar Wylee regions and their languages.
Read People with Green Eyes: Where Do Green Eyes Come From? in other Oscar Wylee regions and their languages.
Australia   
[Australia](https://www.oscarwylee.com.au/glasses/eye/green)
[New Zealand](https://www.oscarwylee.co.nz/glasses/eye/green)
[Canada](https://oscarwylee.ca/glasses/eye/green)
Canadian French

Eye Tests Available at Oscar Wylee
Get your eyes tested and your prescription updated at Oscar Wylee! Our dedicated optometrists are available to provide Medicare bulk billed eye tests.
[Book an eye test](https://www.oscarwylee.com.au/booking)
Claim Your Health Fund Benefits at Oscar Wylee
Bring your valid health fund card to Oscar Wylee and our in-store team will be able to help you make a claim.
[Health funds](https://www.oscarwylee.com.au/health-funds.html)