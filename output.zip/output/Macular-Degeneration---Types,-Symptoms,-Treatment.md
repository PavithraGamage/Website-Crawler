# Source: https://www.oscarwylee.com.au/eye-care/eye-conditions/macular-degeneration

# Macular Degeneration - Types, Symptoms, Treatment
Age-related macular degeneration (AMD) is an eye condition in which a person loses their central vision. Age-related macular degeneration is caused by damage to the macula, which is part of the retina, found at the back of the eye. There are two types of macular degeneration; dry macular degeneration and wet macular degeneration. The most common symptom of macular degeneration is blurring of the central vision. The treatment options for this eye condition will depend on the type a person has. Keep reading to find out more about macular degeneration, how it's treated and how you can help prevent it.
Get a Medicare bulk billed eye test
Book an appointment with an Oscar Wylee optometrist, bulk billed for eligible Medicare card holders.
[Book an eye test](https://www.oscarwylee.com.au/booking)
## What is macular degeneration?
Age related macular degeneration (AMD) is an eye condition that affects central vision. As a person ages, a part of their retina called the macula can be damaged. This causes a decline in central vision, the area of your sight that recognises fine detail. If you have AMD, you may have blurry central vision and find it hard to recognise faces. Age-related macular degeneration is one of the most common eye conditions for people over 50 years of age in Australia. According to a 2019 study by the Australian Department of Health, there are approximately 1.3 million people with age-related macular degeneration in Australia, affecting approximately 1 in 7 people in this older demographic.
Source: ‘A better view - National Strategic Action Plan for Macular Disease’, Australian Government, Department of Health.
There are two types of macular degeneration: dry macular degeneration and wet macular degeneration.
## What is dry macular degeneration?
Dry macular degeneration is the most common type of macular degeneration, occurring when the macula thins and loses light-sensitive cells. Dry macular degeneration can also be caused by drusens, which refers to the build up of yellow waste deposits under the retina. Dry macular degeneration causes gradual vision loss and can develop over several years.
What is dry macular degeneration?
Dry macular degeneration is the most common type of macular degeneration, occurring
when the macula thins and loses light-sensitive cells. Dry macular degeneration can also be caused by
drusens, which refers to the build up of yellow waste deposits under the retina. Dry macular
degeneration causes gradual vision loss and can develop over several years. 
A feeling of burning, itchy or scratching eyes
Eyes become sensitive to light
Reddening around the eyes
Eyes are unexplainably watery
Vision is becoming blurry
A constant feeling that something is in your eye
Other symptoms like exhausted or strained eyes are also possible.
 

## What is wet macular degeneration?
Wet macular degeneration occurs when new blood vessels grow under the retina and macula, which may leak blood or other fluids into the eye. Wet macular degeneration will typically begin as dry macular degeneration. Wet macular degeneration is not as common as dry macular degeneration, however it is more serious and may develop quicker. The vision loss associated with wet macular degeneration, may progress faster than the vision loss associated with dry macular degeneration.
## Macular degeneration symptoms
The most common symptom of age-related macular degeneration (AMD) is a blurring of the central vision. Both types of macular degeneration are generally painless. Dry macular degeneration will usually develop slowly, whereas wet macular degeneration can come on quickly, with more dramatic vision loss . Many people may not know they have macular degeneration until their vision becomes blurry. Getting regular eye tests can help your optometrist detect macular degeneration, and other vision issues such as [hyperopia](https://www.oscarwylee.com.au/eye-care/eye-conditions/hyperopia). If you need an eye test, you can [book online](https://www.oscarwylee.com.au/booking) with our dedicated optometrists.
The possible symptoms of age-related macular degeneration are listed below.
* Blurry central vision
* Central vision loss
* Trouble seeing faces clearly
* Difficulty reading
* Dark areas in your vision
* Poor colour vision
* Distorted vision with straight lines appearing wavy
* Requiring a bright light to complete close up work
Curious about other eye conditions? Read about the symptoms and causes of [dry eyes](https://oscarwylee.com.au/eye-care/eye-conditions/dry-eyes).
### What does the eye see when it has macular degeneration?
When a person has age-related macular degeneration (AMD), what they will see depends on which type of macular degeneration they have and what stage it is at. People with early stage dry macular degeneration may not see anything out of the ordinary. As the condition progresses, a person may notice their vision getting blurry. The eye may struggle to see fine detail. You may also see blank spots in your central vision, or colours may become dull. Straight lines may also appear wavy.
## What causes macular degeneration?
The development of age-related macular degeneration (AMD) is caused by a combination of ageing, genetics and environmental factors, which damage the macula. There are two types of macular degeneration; dry and wet. Dry macular degeneration is caused by a loss of light-sensitive cells and a thinning of the macula as the eye ages. Dry macular degeneration can also be caused by drusens. Drusens refers to yellow deposits, made up of fatty proteins such as lipids, that build up under the retina. The cause of wet macular degeneration is the growth of blood vessels under the macula, which may leak fluid into the eye.
### Macular degeneration risk factors
There are several risk factors that may make a person more likely to develop macular degeneration (AMD). The risk factors are listed below.
1. Age: Being over 50 years old is one of the major risk factors for developing macular degeneration. The older you get, the more likely you are to develop this condition.
2. Family history: Those who have a close family member with AMD are more likely to develop the condition.
3. Smoking: Smoking cigarettes greatly increases the likelihood of developing macular degeneration.
4. Overweight: Being overweight may also increase your risk of developing macular degeneration.
5. Cardiovascular conditions: Having heart or blood vessel related health conditions, may increase the likelihood of developing macular degeneration.
## How is macular degeneration diagnosed?
Age-related macular degeneration (AMD) will be diagnosed during an eye test with an optometrist. During an eye test, your optometrist will assess your vision and see if there are any areas of concern. To detect AMD, your optometrist may conduct a dilated pupil exam. During this exam, a patient is given eye drops to dilate the pupil, allowing the optometrist to see the structures of your retina more clearly. An Optical Coherence Tomography (OCT) may also be recommended. An OCT is a machine that can take detailed images of the structure of the eye.
Find an Oscar Wylee store near you
Contact or visit your nearest store for an eye test
[Find a Store](https://www.oscarwylee.com.au/locations/full-store-list.html)
## Macular degeneration treatment
There is currently no cure for age-related macular degeneration (AMD). However, there are certain treatment options that may slow the progression of the condition in its early stages. The exact type of treatment will depend on the type of AMD and the severity of the symptoms. There are no treatment options for dry macular degeneration, however, eating a healthy and balanced diet may help to slow its progression. Recommended foods for dry macular degeneration are listed below.
* Dark-green, leafy vegetables.
* Fresh fruit daily.
* Fish two to three times a week.
* A handful of nuts a week.
* Choosing low GI carbohydrates.
* Limiting consumption of oils and fats.
Regularly exercising and avoiding tobacco products may also help to slow the progression of dry macular degeneration. There has also been research conducted that shows certain vitamin supplements may be beneficial in slowing dry AMD progression.
Source: American Academy of Ophthalmology
Unlike dry AMD, there are treatment options for wet macular degeneration. The aim of these treatment methods is to combat the growth of abnormal blood vessels and remove any leaking of blood and other fluids, in the eye. The treatment options for wet AMD are listed below.
* Injections: Eye injections, such as Anti-VEGF injections, may be recommended to help to combat the growth of abnormal blood vessels that cause wet AMD.
* Laser treatment: Laser treatment for wet macular degeneration aims to remove abnormal blood vessels which leak into the eye.
## Preventing macular degeneration
There is no certain way to prevent macular degeneration from developing. However, there are steps you can take to delay the onset of macular degeneration and possibly slow the progression of symptoms. The ways that may help delay the onset of macular degeneration are listed below.
* Eye Tests: It is important to keep up your eye tests with your optometrist, so they can monitor the progression of symptoms.
* Amsler Grid: An Amsler Grid is a type of eye chart, displaying a grid with a dot in the centre. The chart is designed to detect issues in your central vision. You may be able to use this chart to self-monitor changes to your vision.
* Wear sunglasses: If you are going outside, it is a good idea to wear sunglasses to help protect your eyes from damaging UV rays and help to maintain good eye health.
* Eating healthy: Eating a balanced and healthy diet high in fruits, dark green leafy vegetables and omega-3 fats, can help prevent the onset of macular degeneration.
* Quit smoking: As smoking cigarettes can increase the risk of developing AMD, it is best to avoid any tobacco products.
* Exercise: Exercising regularly will also help to maintain your overall health and possibly slow the onset of macular degeneration.
## Macular degeneration complications
Most age-related macular degeneration complications centre around a person’s quality of life. Macular degeneration may not always cause total blindness, however, the loss of central vision can affect lifestyle. It may be harder to recognise faces, perform daily activities like driving, and can lead to anxiety and depression.
## How do I know if I have macular degeneration?
If you think you may have macular degeneration, it is important to book an appointment with your optometrist as soon as possible so they can diagnose, manage and treat this condition.
## Find your nearest Oscar Wylee store
Visit us in-store and our team can assist you with your eye care needs.
[Find a store near you](https://www.oscarwylee.com.au/locations/full-store-list.html)
## Get a Medicare bulk billed eye test
Book an appointment with an Oscar Wylee optometrist.
[Book an eye test](https://www.oscarwylee.com.au/booking)