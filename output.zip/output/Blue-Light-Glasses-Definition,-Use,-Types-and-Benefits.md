# Source: https://www.oscarwylee.com.au/glasses/eye/blue-light

# Blue Light Glasses: Definition, Use, Types and Benefits
Published on June 22nd, 2023
Updated on Month Date, 2025 
Australia
[Australia](https://www.oscarwylee.com.au/glasses/eye/blue-light)
[New Zealand](https://www.oscarwylee.co.nz/glasses/eye/blue-light)
[Canada](https://oscarwylee.ca/glasses/eye/blue-light)
Canadian French

Blue light glasses have lenses
designed to block or reduce the blue light emitted from digital
screens
according to the Cleveland Clinic. The use of blue light lenses, also
referred to as screen glasses is intended for protection against the
potentially harmful effects that prolonged exposure to blue light is
believed to have. The benefits of blue light glasses, according to Everyday
Health and Harvard Business Review, are better sleep quality and quantity as
well as better work performance. There are different types of blue light
glasses, such as red, orange and yellow tinted lenses. The debate of, do
blue light glasses really work or if it is beneficial to use blue light
glasses for the computer, is still ongoing. However, as evidence shows,
results are often too inconsistent to reach a conclusion according to the
National Library of Medicine.
Take care of your eye health
Book a bulk billed eye test with one of our optometrists today.
Book an eye test
[Definition](#definition) [Benefits](#benefits)
[Limitations](#limitations) [Devices](#devices)
## What are Blue Light Glasses?
Blue light glasses have
lenses that are made to help block or reduce the blue light that digital
screens emit. The blue light from digital screens is believed to have effects that may
be harmful to the eyes. These harmful effects may include eye strain, dry
eyes, blurry vision and headaches. However, these are likely symptoms of
digital eye strain and dry eye according to Amy Sheppard and James Wolffsohn
in a paper published in the National Library of Medicine. The question of
what are blue light glasses is common, especially in regard to whether it is
necessary during screen time. According to Optometry Australia’s 2022 Vision
Index, increased screen time as a result of hybrid working has seen a
progression in eye problems in Australians.
### How Do Blue Light Glasses Work?
Blue light glasses work
by lessening the amount of blue light that enters the eye. The lenses of blue light glasses are coated with a filter or built with
special material in the lens. The answers to what is a blue light filter
and what do blue light glasses do are essentially connected.
The special lens coating on blue light glasses acts as the blue light
filter and as a result, either absorbs or reflects the blue
light. Blue light has a short wavelength in the visible spectrum, according to
Zhi-Chun Zhao, Ying Zhou, Gang Tan and Juan Li in their paper published in
the International Journal of Ophthalmology. The short wavelength of blue
light means a higher amount of energy and as a result, is often perceived
to be harmful passing through the cornea of the eye.
## What is the Use of Blue Light Glasses?
The use of blue light glasses, also known as screen glasses,
can be used when working from a digital device as well as
during recreational screen time. Blue light can come from laptops,
computers, smartphones, tablets, gaming consoles, and LED screens.
Individuals may be interested in using blue light glasses
when watching television, streaming videos on a tablet/laptop or browsing
the internet.
### Who Uses Blue Light Glasses?
Individuals who work with digital devices or those who may be experiencing
discomfort in their eyes may choose to use blue light glasses. Eye
problems such as digital eye strain and dry eyes are common when using
digital devices for long periods. People with digital eye strain or dry
eyes may associate their symptoms with their exposure to blue light.
Individuals who spend their spare time on digital devices may also want
to use blue light glasses for protection. Although there is not enough evidence to conclude whether blue light is
harmful, it has been common for people to be more wary of the possible
effects of blue light on their eyes, according to Zhi-Chun Zhao, Ying
Zhou, Gang Tan and Juan Li in their paper published in the International
Journal of Ophthalmology. It is a widely available option for people with
prescription glasses and those who do not require prescription glasses.
With the increased time spent on digital devices for work and
entertainment, it is common for people to resort to blue glasses for the
computer.
## What Are the Benefits of Blue Light Glasses?
The benefits of blue light glasses are
improved sleep quality and quantity as well as work performance
as suggested by evidence from a number of studies. Blue light glasses’
benefits may differ between individuals or may not occur at all. It is
important to note that there is not enough evidence to support whether blue
light is harmful. Therefore, blue light glasses are not recommended by the
American Academy of Ophthalmology. The benefits of blue light glasses are
listed below.
1. Improved sleep quality and quantity:
Improved sleep quality and quantity may be achieved using blue light
glasses as studies have shown. Blue light from digital screens during the
evening can cause disruptions to our melatonin production. Melatonin is a
natural hormone produced by the body to help us feel sleepy when it is
dark at night. Blue light glasses can minimise how much blue light we are
taking in during evening screen time. Blue light assists us with feeling
alert during the day with the sun contributing as the biggest source of
blue light. Consequently, experiencing blue light from digital devices
near sleeping hours can cause excessive stimulation to the brain and
hinder the secretion of melatonin.
2. Improved Work Performance: Improved work
performance has been a suggested outcome through the use of blue light
glasses in a study done by Guarana, C. L., Barnes, C. and Ong, W. on the
effects of blue light filtration on sleep and work outcomes. The result of
improved sleep quality has an overall positive influence on work
performance, task engagement and work behaviour.
### What are the Limitations of Blue Light Glasses?
The limitations of blue light glasses are their
efficacy in preventing symptoms of digital eye strain, dry eyes,
long-term damage from blue light and the effects of blue light. While there are few studies that exhibit the effectiveness of blue
light glasses on sleep and work improvement, the limitations also extend
to whether blue light is conclusively harmful to the eyes. The limitations
of blue light glasses are listed below.
1. Preventing digital eye strain and dry eye symptoms:
Blue light glasses have no effect in preventing symptoms such as eye
strain, headaches, blurry vision or dry eyes. According to the American
Academy of Ophthalmology, the damaging effects of blue light are still
under investigation. Therefore, symptoms that occur during excessive use
of digital devices are likely caused by eye problems such as digital eye
strain and dry eyes. These eye problems can develop from extended screen
time and reduced blinking as opposed to the blue light.
2. Preventing long-term damage: Blue light
glasses may not be useful in altering any long-term negative effects of
prolonged screen time. It is strongly advised to take regular breaks
while working with digital devices, use artificial tears to ensure your
eyes are hydrated and actively remember to blink more.
3. Harmful effects of blue light: The
effects of blue light have not been confirmed to be damaging to the
eyes. The duration of our screen time may likely be the cause of
discomfort according to the Cleveland Clinic.
Find an Oscar Wylee store near you
You can find an Oscar Wylee team near you on our locations page.
Find a store
## What Are the Types of Blue Light Glasses?
The types of blue light glasses are
red, orange and yellow tinted. Blue light glasses with red
or orange-tinted lenses are designed to block more blue light according to
the Sleep Foundation. They may change the colour of your digital device
screen. Yellow-tinted glasses are intended to block a narrow spectrum of
blue light, this may be a suitable option for daytime use. Oscar Wylee
offers the option to add a blue light filter to your prescription glasses.
You can read more information in our article about
[different types of glasses](https://www.oscarwylee.com.au/glasses/types). Blue light glasses for the elderly and for those with diagnosed eye
conditions will only differ depending on their prescriptions.
Oscar Wylee does not offer red, orange or yellow-tinted blue light
glasses. The different types of blue light glasses include
kids blue light blocking glasses, night-time blue light blocking glasses,
day time blue light blocking glasses and fitover clip-on blue light
blocking glasses. The types of blue light blocking glasses are listed below.
1. Kids blue light blocking glasses: Kids
blue light blocking glasses are normal, adult blue light blocking glasses,
reduced in size to fit kids.
2. Night-time blue light blocking glasses:
Night-time blue light blocking glasses are blue light glasses designed to
be used when using digital devices at night time when it’s dark and
minimal natural light is present.
3. Day time blue light filter glasses: Day
time blue light blocking glasses refers to blue light glasses that are
designed to be worn during the day.
4. Fitover clip-on glasses: Fitover clip-on
glasses refer to glasses that have lenses separate from the actual glasses
frame. The lenses of fitover clip-on glasses can be fitted over the
glasses frame, then removed when not needed.
### 1. Kids Blue Light Blocking Glasses
Kids blue light blocking glasses refer to
standard blue light glasses that have been made to fit kids. Kids blue light blocking glasses aim to help block some of the blue
light that emits from digital devices including television, computers and
laptops, phones and video game devices. According to the Australian
Institute of Family Studies, many Australian children are spending more
than the recommended two hours on digital devices, including computers,
television and video games. Kids blue light blocking glasses work in the
same way as adult blue light glasses, aiming to block some of the light
emitting from digital devices.
### 2. Night-time Blue Blocking Glasses
Night-time blue blocking glasses are a
type of blue light glasses that are suitable for wearing during
night. When using digital devices near sleeping hours, it may be helpful to
wear blue light blocking glasses to prevent the blue light from disrupting
melatonin production and circadian rhythms.
### 3. Day Time Blue Light Filter Glasses
Day time blue light filter glasses refer to
blue light blocking glasses that can be worn during the day. Day time blue light filter glasses may have an anti-reflective or
anti-glare coating to protect the eyes from glare from the sun.
### 4. Fitover Clip-on Glasses
Fitover clip on glasses refers to a
type of blue light glasses in which the blue light lenses are attached
to a separate apparatus. This apparatus can then be attached over the
person’s frames as needed. The purpose of fitover clip-on glasses is that people can use their
normal glasses with their normal lenses, and clip the blue light lenses on
when needed. Oscar Wylee does not sell fitover clip-on blue light glasses.
#### Do Display Devices Have Blue Light Feature?
Yes, some display devices have blue light features which
may reduce the blue light that is emitted from the screens. For example, Apple has a function on their iPhones called Night Shift
which automatically changes the colours on the display to a warmer hue
which can help the owner get a better night’s sleep. Android phones have
a similar function known as an Eye Comfort Shield which adjusts the
screen’s colours based on the time of day. This can also be done
manually so you can choose when to turn on the blue light features. You
can read a detailed article on
[how to turn off blue light on my device](https://www.oscarwylee.com.au/glasses/blue-light/how-to-turn-off). Many modern computers and displays will also have blue light features
as it is a much talked about topic in the eye care industry.
#### Do Blue Light Glasses Work?
It is difficult to give an answer to do blue light glasses work as the
research is still in its early stages. While a blue
light lens is effective at blocking blue light, there is no definitive
evidence that these types of glasses will protect the eyes from damage.
While the effects of blue light are still being discovered, there is
evidence that suggests blue light has a negative effect on sleep.
According to a study published in The Proceedings of the National
Academy of Sciences, blue light may cause people to release less
melatonin which is the chemical that aids in sleep. A blue light filter
has also been suggested to help with the eye condition called digital
eye strain which is caused by prolonged use of digital screens.
Therefore, wearing blue light glasses for computer use can be
beneficial.
#### Can Blue Light Glasses Help with Eye Strain?
As discussed, blue light glasses can be used to
potentially help with eye strain, specifically digital eye
strain. Digital eye strain, also known as computer vision syndrome, is a term
used to encompass a wide range of vision and eye symptoms experienced as
a result of prolonged use of digital screens such as computers, phones
and tablets. Digital eye strain can cause the eyes to feel fatigued,
cause blurry vision and also dry eyes. A blue light lens is among the
possible treatments for digital eye strain alongside taking frequent
breaks from computer use, using lubricating eye drops, wearing
prescription glasses and adjusting the brightness of the screen. If you
suffer from eye strain caused by looking at a digital screen, you may
benefit from wearing blue light glasses for computer use. You can find
more helpful advice in our article on the
[10 tips for computer eye strain relief](https://www.oscarwylee.com.au/glasses/eye/tips-for-computer-eye-strain-relief).
Read Blue Light Glasses: Definition, Use, Types and Benefits in other
Oscar Wylee regions and their languages.
Australia
[Australia](https://www.oscarwylee.com.au/glasses/eye/blue-light)
[New Zealand](https://www.oscarwylee.co.nz/glasses/eye/blue-light)
[Canada](https://oscarwylee.ca/glasses/eye/blue-light)
Canadian French

Major Health funds accepted at Oscar Wylee
Come in-store and our team will happily assist you in using your health
fund to cover some of the cost of new frames or an eye test.
[Health Funds](https://www.oscarwylee.com.au/health-funds.html)
Are you due for an eye test?
Book an eye test online and come and visit our dedicated team in-store.
[Book an eye test](https://www.oscarwylee.com.au/booking)