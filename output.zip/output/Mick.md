# Source: https://www.oscarwylee.com.au/mick-sunglasses.html

# Mick
1
## Frame Design of Mick Sunglasses
The frame design of Oscar Wylee’s Mick sunglasses is characterised by a classic rectangle shape, a high nose bridge fit, and an acetate frame. Mick sunglasses are a men's everyday frame that will work for any occasion, whether the wearer wants to liven up their work style or complement an outfit for a night out.
$169    
In stock
Only %1 left
2 pairs from $199
Discount auto-applied at checkout
3 pairs from $249
Discount auto-applied at checkout
* 2 &amp; 3 Pair pricing applies to non-prescription sunglasses only. Prescription sunglasses incur additional charges.    
[Non-Prescription](https://www.oscarwylee.com.au/mick-sunglasses.html#)
Qty
Prescription
Book an eye test
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
excluding prescription lenses
## About Mick Sunglasses
Mick is a versatile frame designed for all-day comfort. This sports sunglass is the perfect combination of functionality and style.
| Frame fit | Measurements |
| --- | --- |
| WIDE | 58 - 17 - 145 |
These measurements mean lens width, bridge, and temple length in millimetres (mm). They can be found on the inside of the temple arm. If you already have a pair that you like, you can compare it to these measurements.
### Made from Acetate
Oscar Wylee’s Mick frame is a men's rectangle sunglasses frame that is perfect for those with round or oval face shapes. The Mick frame is a sleek, widely wearable frame that can be worn every day. The main specs of Oscar Wylee’s Mick glasses frame, including dimensions, shape, materials, lenses, nose fit and hinges, are listed below.
Filter category 3 - General purpose sunglasses. High protection against sunglare. Good UV Protection.Not suitable for driving in twilight, at night or under dull conditions
This frame comes with tinted lenses. An additional $30 will be added to your order total for prescription orders.
| Mick Frame Features | Mick Frame Description | Dimensions | Shape | Materials | Lenses | Nose Fit | Hinges |
| --- | --- | --- | --- | --- | --- | --- | --- |
| The dimensions of the Mick frame are measured in millimetres (mm) and are 58 - 17 - 145, meaning the lens width is 58 mm, the bridge is 17 mm, and the temple length is 145 mm. |
| The Mick frame is a rectangle shape, well-suited to wide faces. |
| Mick glasses are made from acetate. |
| The lenses that can be used in the Mick frame are sunglass lenses, which provide UV protection. Prescription lenses are also available for the Mick sunglass frame, both online and in-store. |
| The nose fit of Mick frames is a high nose bridge fit. |
| The hinges in the Mick sunglasses are normal hinges, also known as standard or barrel hinges. |
Show All
### What Inspired the Frame Design of Oscar Wylee's Mick Glasses?
The Oscar Wylee Mick frame design was inspired by current fashion trends,  as rectangle shapes are often in fashion. A rectangle glasses shape is timeless, meaning it remains popular throughout the decades while other trends pass.
## What to Know About Oscar Wylee's Mick Sunglasses?
There are many aspects of the Oscar Wylee Mick frames that customers should know about, so they can decide whether this is the right frame for them. The Mick frame is a men's rectangle-shaped frame. Oscar Wylee's Mick frame is suitable for many face shapes, but particularly compatible with with round or oval face shapes. The Mick frame's simple design means that they are fashionable all year round. The Mick glasses feature the standard [parts of glasses](https://www.oscarwylee.com.au/glasses/eye/part-of-glasses), such as a rim, temples, lenses, normal hinges and a high nose bridge fit.
### What are the Types of Temple Tips or Earpieces Included with Oscar Wylee's Mick Glasses?
The type of temple tips or earpieces included in Oscar Wylee’s Mick Glasses are made from acetate.
### What Type of Nose Bridge do Oscar Wylee's Mick Glasses Have?
The type of nose bridge included in Oscar Wylee's Mick frame is a high nose bridge fit.
### What Type of Nose Pads are Included with Oscar Wylee's Mick Glasses?
Oscar Wylee's Mick frame does not include adjustable silicone nose pads.
### What Type of Lenses do Oscar Wylee's Mick Sunglasses Have?
The lenses that can be used in the Mick frame are sunglass lenses, which provide UV protection. UV protection lenses block harmful ultraviolet rays, safeguarding eyes from damage. The Mick Frame comes in Filter Category 3. These are general-purpose sunglasses and provide good protection against sunglare. However, they are not suitable for driving in twilight, at night or under dull conditions. Prescription lenses are also available for the Mick sunglass frame, both online and in-store.
### What Material is Used for the Rim of Oscar Wylee's Mick Glasses?
The material used for the rim of Oscar Wylee’s Mick glasses frames is acetate. The rim refers to the part of a glasses frame that holds the lenses.
### What Type of Hinges are Included with Oscar Wylee's Mick Glasses?
The type of hinges included with Oscar Wylee’s Mick frames are normal hinges. These provide strength and smooth movement connecting the frame's arms and lenses.
## What Face Types are Most Suitable for Oscar Wylee's Mick Glasses?
The face types that are most suitable for Oscar Wylee’s Mick frame are round or oval faces. The Mick frame is a rectangle shape, meaning that it complements the structure of round and oval faces particularly well. The Mick frames help to balance the features of a [round face shape](https://www.oscarwylee.com.au/glasses/face-shapes/round) or an [oval face shape](https://www.oscarwylee.com.au/glasses/face-shapes/oval), bringing the eyes and brows forward in a flattering way. Although there are many [glasses for face shapes](https://www.oscarwylee.com.au/glasses/face-shapes) that may be considered more aesthetically suitable, it is important that people also choose the frames that make them feel most comfortable and represent their personal style.
## What Size Options are Available for Oscar Wylee's Mick Glasses?
The size option available for Oscar Wylee's Mick frame is a wide frame fit.
## What Materials are Used to Create Oscar Wylee's Mick Glasses?
The primary material used to create the Oscar Wylee Mick frame is acetate. Acetate, also known as cellulose acetate, is a bioplastic made from cotton fibres or wood pulp. At Oscar Wylee, acetate glasses are made by adding a dye to cellulose acetate, which is rolled into a sheet. The shape of the glasses is then cut from this sheet.
## What’s Included
## What's Included
Each pair of glasses comes with a stylish frame case and lens cloth. We offer free shipping across Australia and 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects.
* Free Shipping for Australian Orders
* 1 Year Warranty on frames and lenses
* Scratch resistance lens coating on all prescriptions
* UV-proof coating on all prescriptions
* Stylish case and cloth
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
## Make and Materials
The frames then go through cleaning and strict quality control, and many pairs of crafting hands to be hand-assembled and polished. After your frames have gone through the production process, they are individually examined and packed before making their way to you!Also known as cellulose acetate, these frames are traditionally hand-crafted by skilled craftsmen, with each frame passing through numerous stages of production and are hand-polished to ensure a glorious lustre.
## Warranty Information
### Warranty Information
### Warranty Information
Oscar Wylee provides a 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects. We will repair or replace faulty or defective frames or lenses free of charge for warranty claims made within 1 year of the delivery. We also offer repairs or replacement for problems experienced with vision during everyday use for claims made within 30 days of delivery. If the same product has been discontinued or is no longer available, then we may offer an exchange for a similar product or a refund.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Find a Store Location](https://www.oscarwylee.com.au/locations/full-store-list.html)