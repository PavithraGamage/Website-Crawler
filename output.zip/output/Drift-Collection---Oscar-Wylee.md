# Source: https://www.oscarwylee.com.au/glasses/collection/drift-collection.html

Introducing the Drift Collection, inspired by the Australian wilderness at its best.
The frames embody our rugged coastline, from its natural shapes to rough rocks melting into the blue
depths.

Introducing the Drift Collection, inspired by the Australian wilderness at its best.
The frames embody our rugged coastline, from its natural shapes to rough rocks melting into the blue depths.
Introducing the Drift
Collection, inspired
by the Australian wilderness at its
best. 
The frames embody our rugged coastline, from its natural shapes to rough
rocks melting into
the blue depths. 

Introducing the Drift Collection, inspired by the Australian wilderness at its best.
The frames embody our rugged coastline, from its natural shapes to rough rocks melting into the blue depths.
[](/glasses/collection/drift-collection.html#layer-product-list) Flexible hinges 
The frames come in unique colours that mimic rugged grey cliffs, turquoise seas, crashing emerald waves and ochre sands.
[](/glasses/collection/drift-collection.html#layer-product-list) Shatter-resistant lenses 
The Drift frames range from classic to contemporary shapes to complement a natural look to a more bold style.
[](/glasses/collection/drift-collection.html#layer-product-list) Shatter-resistant lenses 
The glasses capture the beauty of neutral shapes, colours and designs, so they can be worn by anyone, regardless of gender.
4 Products        
Showing 4
1. [](https://www.oscarwylee.com.au/zeke-optical.html)
[Zeke](https://www.oscarwylee.com.au/zeke-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/zeke-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/zeke-optical.html)
2. [](https://www.oscarwylee.com.au/andrew-optical.html)
[Andrew](https://www.oscarwylee.com.au/andrew-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/andrew-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/andrew-optical.html)
3. [](https://www.oscarwylee.com.au/prue-optical.html)
[Prue](https://www.oscarwylee.com.au/prue-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/prue-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/prue-optical.html)
4. [](https://www.oscarwylee.com.au/victor-optical.html)
[Victor](https://www.oscarwylee.com.au/victor-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/victor-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/victor-optical.html)
4 Products        
Showing 4