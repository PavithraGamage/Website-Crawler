# Source: https://www.oscarwylee.com.au/locations/optometrist-blacktown.html

# Optometrist Blacktown
Level 3, Shop 305417 Patrick StreetBlacktown NSW 2148
* (Near YD and Typo)
Opening hours
Monday9:00am - 5:30pm
Tuesday9:00am - 5:30pm
Wednesday9:00am - 5:30pm
Thursday9:00am - 7:00pm
Friday9:00am - 5:30pm
Saturday9:00am - 5:00pm
Sunday10:00am - 5:00pm
*Store hours reflect local standard trading hours and exclude public holidays
[Visit our Blacktown Google Business page for directions, reviews, and updates.](https://g.page/r/Ccpf6vFNdQ8yEBM)
Book Appointment
[Call us: (02) 8809 5869](tel:(02) 8809 5869)
[Leave a Review!](https://g.page/r/Ccpf6vFNdQ8yEBM/review)
Our Reviews
Glen Montgomery
6 days ago
Very happy
divya kotha
1 week ago
Azamy Mohammad Sabir
2 weeks ago
Nishant Midha
2 weeks ago
The receptionist was polite and helpful. The ophthalmologist tested keenly and explained the results... very well. The machine for air pressure test behaved funny though took long time to focus. You can get appointment on sunday too. Not crowded.
See more
maua sanileva
3 weeks ago
Calizar Maureen Faye M
4 weeks ago
Maryann Hearn
4 weeks ago
Vasantha Selvaratnam
4 weeks ago
I am very happy my eye testing.
Paulette Renouf
1 month ago
Very nice customer service. The girls were very thorough from eye testing to purchasing my new two p...airs of glasses. I would highly recommend Oscar Wylee, Blacktown, my place of Choice.
See more
Vasanth Kumar
1 month ago
Very attention to detail. The way I was explained I felt like I was the doctor myself. I never felt ...I was just another customer....
See more
Krissy Madriaga
1 month ago
Jimmy Guion
1 month ago
Mirna was exceptionally thorough with my eye tests and spend significant time explaining her finding...s and further options for me. What a great job and a pleasant experience. 100% recommended. Thank you so much.
See more
Celia N
1 month ago
The 3 ladies at OWO in Blacktown are all very professional, friendly &amp; so helpful. I would definitel...y recommend them to my family &amp; friends. My first time with OW &amp; they have a great selection of glasses / frames to choose from.  Thank you Ladies!
See more
Ashley Oquendo
1 month ago
H K
1 month ago
Great service , Vivian was very helpful .
Maria Paludi
1 month ago
Tiju Mathews
2 months ago
R Lyons
2 months ago
Myrna was very professional and gave very good instructions. She answered all my questions from a so...lid background of knowledge and empathy.
See more
clarenaomi
2 months ago
Optometrist is so good and thorough always come away feeling well
Looked after
Steve K
2 months ago
Turned up and appointment time was kept on time. The staff helped to fill in all paperwork for a fir...st time customer. Optometrist was very throughout in measuring up for lenses. Worth going there from that experience.
Picked up the 2 pairs of glasses today. Quick service good to have new glasses again.
See more
Vanessa Delos Santos
3 months ago
Sandee Cee Bee
3 months ago
Oscar Wiley Blacktown is sensational.
Noel Villarosa
3 months ago
Staff of this store are very accomodating,over all Awesome.
mannat multani
3 months ago
Khin Maung Htun
4 months ago
C Ormazabal
4 months ago
Excellent service and doctor
Nadereh Hasani
4 months ago
Thank you very much, it was very accurate and excellent.
Babylen Belleza
4 months ago
Staff are very helpful and accomodating. Optometrist is very nice, soft spoken, patient and efficien...t. Thank you for a great experience.
See more
jaswinder singh
5 months ago
I got new reading glasses,the previous one had thin glasses but these one have very thick glasses wh...ich looks like we have gone back in time.it would be better if you explain the whole thind bedire hand
See more
forsocialmedia purpose
5 months ago
I have been a loyal customer of Oscar Wylee for the past three years, which is why this experience h...as been especially disappointing.
I recently left my glasses in store to have my lenses transferred into new frames, as I was told this would be covered by my insurance. I was advised verbally and asked to leave my glasses with them so the process could begin.
It has now been a month, and I have not received any updates regarding the status of my glasses. I understand that delays can happen, but the lack of communication has been frustrating — especially as someone who has continued to support this brand for years.
I have always had positive experiences before, I hope the store can improve communication and follow-up processes, as loyal customers value transparency and reliability.
See more
Grace Capati
5 months ago
Joumana Sawaya
6 months ago
Staff were very friendly and helpful
Repeka Molimoli
6 months ago
Excellent service during my eye test.I truly appreciate your professionalism and care.
Laurie Doolan
6 months ago
Geraldine Magallanes
7 months ago
Ashley Clifford
7 months ago
Great experience, optometrist was efficient and genuinely interested in my eye health. Didn’t feel l...ike I was just another free eye test
See more
Maryanne [[email&nbsp;protected]](https://www.oscarwylee.com.au/cdn-cgi/l/email-protection)
7 months ago
Ben Gundes
8 months ago
The Service and Professionalism of the Optometrist was second to none, She was very thorough and exp...lained everything without any issues...
See more
Vina Lejano
8 months ago
This was my 2nd time doing eye test in 2 years and my eye test was kind off a rush. I hope the optom...etrist did it a bit slow.
See more
James Philipsz
9 months ago
good
Louise Wheeler
9 months ago
The staff are really helpful and the optometrist explains everything. It's  nice to see the same per...son  each year. She was very friendly and helpful
See more
Allen Alag
9 months ago
My optometrist was named Vivian. Her customer Service sets a benchmark for all her peers. I came in ...for a “Fitness  to Drive” eye test. Vivian’s focus was on the thorough completion of the test  to retain my Drivers Licence. Not only did she complete the task but even advised me that my current reading glasses are still perfect for me. Unlike other optometrist that hard sells their glasses even when you don’t need it. Highly recommended. Thank you Vivian.
See more
Rosarita Villon
9 months ago
Staff was very professional, friendly and helpful.my.whole family goes to this optometrist  yearly.
HereGoesMitch (Mitch Bergin)
9 months ago
Vivian was exceptionally thorough, professional, and empathetic. She took the time to listen and ens...ure I received the right care.
See more
Marjorie May
9 months ago
I was attended to by Optometrist Vivian who quickly and efficiently made sure each eye was checked f...or the best outcome, and further assisted by Rhianna who explained about different lenses, costs and helped me choose frames to suit me. I had a great experience with both ladies, they were good humoured and they listened to what I needed. They were very professional, personable and knowledgeable. Excellent customer service, Thank You ladies. Can't wait to try my new glasses.
See more
rajesh prabhakaran
10 months ago
Excellent service. Tanny and optometrist Lenny make sure that you are comfortable and makes the proc...ess so smooth. They are very kind and polite people. Will surely come back for future eye tests
See more
deep khaira
10 months ago
Had a very good experience at Oscar Wylee Blacktown. Great service, friendly staff and nice glasses ...variety:)
See more
isabella shim
10 months ago
They are professional and very kind. Explained details.
Christine
10 months ago
Very lovely service from the staff. The optometrist was really professional explained and listen to ...me. Overall service 10/10. Loved how i wasnt cross sold or pressured into anything i didnt need will be back. Honesty is the best service with no pressure good work.
See more
Chacha Del Corro
11 months ago
Beyond what I expected by way of the eye test. Checked more than what I needed for an updated prescr...iption for my glasses.
See more
## Find an Optometrist in Blacktown with Oscar Wylee
Welcome to Oscar Wylee Blacktown, located a minute's walk from Blacktown station and just a 10-minute drive from Seven Hills or Doonside. Our Oscar Wylee Optometrist Westpoint store carries out bulk billed eye exams for those with a valid Medicare card. With an optometrist onsite so you can get your vision tested, you can update or get a new prescription and order your new pair of glasses on the same day! Oscar Wylee Blacktown offers modern and vintage-inspired prescription glasses and prescription sunglasses. 
Located on level 3 of Westpoint Shopping Centre and across from Typo and Famous Footwear, Oscar Wylee Blacktown offers optical glasses, as well as non-prescription and prescription sunglasses. We also have late-night appointments on Thursday nights until 7pm for busy patients, as well as weekend trades. Oscar Wylee Blacktown is offering some of the best optometrist services in Western Sydney and is easily accessible by public transport, train and bus, and Westpoint offers free 3-hour parking.        
Meet Our Team
* Optometrist
B.Optom (Hons)
B.Sc (Vision)
Therapeutically Endorsed
Show All
## Find an Optometrist in Blacktown Sydney for an Eye Health Test
An optometrist in Blacktown can provide locals with comprehensive eye exams and a range of prescription sunglasses and eyeglasses. You won’t require an eye doctor to take care of your eye health as our optometrists and optical dispenser can cover any issues or enquiries you may have. Come visit the Oscar Wylee glasses store for your next eye health test in Blacktown. Here you will be taken through different tests to make sure all the parts of the eye are healthy. A comprehensive eye test is vital for catching early signs of any eye diseases or minor eye problems and is available at a bulk billed price if you’re registered in Australia’s Medicare system.
The average price range for an optometrist in Blacktown can vary, therefore, it may be too difficult to provide an accurate price range for Blacktown optometrists. Visit an optometrist in Oscar Wylee Blacktown for excellent eye care services.
## How to Find an Optometrist in Blacktown Sydney?
To find an optometrist in Blacktown, Sydney, you can take certain steps that can help make it easier for you such as searching online, assessing the store’s opening hours and finding the directions to your chosen location. The steps on how to find an optometrist in Blacktown are listed below.
1. Search online using the phrase, Blacktown optometrist near me. This can also be done here on the website via our locations page.
2. Click on the Oscar Wylee link, which will take you directly to our Blacktown optometrist store page.
3. See the store’s opening hours and where the store is located specifically.
4. Use the Blacktown Google Business page link located under store hours to see the directions on how to get to the store.
You can also find an optometrist in Blacktown by searching the keywords optometrist near me. If you have locations enabled on your smartphone and you’re in the area of Blacktown, our Blacktown store page should appear easily for you to click on.
### Is it Hard to Get an Eye Appointment in Blacktown Sydney?
No, it is not hard to get an eye appointment in Blacktown. You can easily book an appointment to see an Oscar Wylee optometrist in Blacktown right here on this page. At Oscar Wylee we have highly qualified optometrists available for bulk billed eye appointments, which can be booked online or in-store.
#### How to Compare Optometrists in Blacktown to Each Other?
To compare optometrists in Blacktown, you can use factors such as eye tests offered, health fund coverage, lens types and add-ons and eyewear offered. To take care of your vision and eye health, it is important to receive an eye test at least once every two years. There are different types of tests that can be performed in an eye test and not all optometrists may offer the same tests. Health funds can be used to help cover some of the cost of your frames and lenses. To find out if your health fund is accepted at Blacktown optometrist in Sydney, visit their website. In the case of Oscar Wylee, we accept all major health funds and provide on-the-spot claims in-store. There are many different lens options available for prescription glasses such as single vision, multifocal and high index lenses. Most optometrists in Blacktown will offer these lenses although it is good to make sure. There are also lens add-ons available to enhance your glasses such as anti-reflective and blue light filters. Finally, if you are looking to purchase a pair of glasses after your eye test, you can compare the different styles and colours you are interested in from Blacktown optometrists in Sydney. Oscar Wylee offers a wide range of frames with vintage and modern inspirations in bold colours and subtle designs.
#### How to Find an Eyeglasses Shop in Blacktown, Sydney?
To find a glasses store in Blacktown, you can try to follow these simple steps including searching online, selecting a convenient location and looking at their health insurance policies. The steps on how to find a glasses store in Blacktown Sydney are listed below.
1. Search online using the phrase, glasses store in Blacktown. This will provide you with various options for glasses stores in the whole Blacktown Sydney area.
2. Select a glasses store that is most convenient for you to travel to.
3. Click the link to find out more information such as opening hours, exact location and directions to the glasses store in Blacktown.
4. Read their health insurance policies to ensure you know what health benefits you have access to.
Our Oscar Wylee glasses store in Blacktown, Sydney offers primary eye care services such as comprehensive eye tests as well as other services performed by an optometrist and offers prescription and non-prescription eyewear.
##### Is it Possible to Purchase Prescribed Sunglasses in Blacktown, Sydney Without Seeing an Optometrist?
Yes and no, it is possible to [purchase prescribed sunglasses](https://www.oscarwylee.com.au/sunglasses.html) in Blacktown, Sydney without seeing an optometrist if you already have a prescription that has not expired. If your prescription is expired, you can book an eye test to receive an updated or new prescription which will require you to see an optometrist. This will ensure your prescription sunglasses are appropriate for your visual needs.
## Where is the Oscar Wylee Blacktown Optometrist in Sydney Located?
The Oscar Wylee Blacktown optometrist is located on level 3 of the Westpoint Shopping Centre across from Typo and Famous Footwear. You can find the Westpoint Shopping Centre along Patrick Street in Blacktown.
### What is the Phone Number of Oscar Wylee Blacktown Optometrist Store?
The Oscar Wylee Blacktown optometrist store phone number is (02) 8809 5869. You can contact the store on Monday, Tuesday, Wednesday and Friday between 9 am and 5:30 pm, on Thursday between 9 am and 7 pm, on Saturday between 9 am and 5 pm and on Sunday between 10 am and 5 pm.
### What are the Reviews for Oscar Wylee Blacktown Optometrist in Sydney?
The many reviews for Oscar Wylee Blacktown optometrist in Sydney, which are written by our various customers, can be found here on the website and online when you search for Oscar Wylee Blacktown optometrist. The reviews for Oscar Wylee Blacktown optometrist are listed below.
* Emily Dewsbury -  The experience was great and I loved the environment.
* Katie-Lee Bilbija -  The team was great, I was late to my appointment unfortunately and originally they advised that they were unable to fit me in, only to then make it possible! They were also very helpful and supportive whilst trying to find suitable glasses.
* Jake De Los Reyes -  Very efficient and so friendly.
* Digitally Better -  5/5 the optometrist took a lot of time, and care with my eye test.
#### What Treatments or Eye Care Processes are Done in the Oscar Wylee Blacktown Optometrist Location?
The treatments or eye care processes done in the Oscar Wylee Blacktown optometrist Sydney location include a tonometry test, a digital photograph, a slit lamp exam and a refraction test. Additional tests that may also be performed can include a visual field test and a dilated fundus exam. The treatments or eye-care processes that are done in the Oscar Wylee Blacktown optometrist Sydney location are listed below.
* A Tonometry Test: An optometrist or optical dispenser will conduct a tonometry test which involves the use of a machine that will release small puffs of air into your eyes. This will assist with measuring pressure in the eye.
* A Digital Photograph: An optometrist or optical dispenser may take a digital photograph of your eye which can be kept on record to use in future appointments to evaluate any changes to your eye.
* Slit Lamp Test: A slit lamp test can be used to evaluate your eye health, by examining your cornea and iris which are the anterior and posterior of the eye.
* Refraction Test: During a refraction test, an optometrist will have you view an image through different lenses and ask you to confirm which helps you see the image clearer.
* Visual Field Test: A visual field test can assist with assessing your peripheral vision, which may be beneficial for identifying any signs of glaucoma.
* Dilated Fundus Exam: A dilated fundus exam can help an optometrist assess your health in more detail by getting a clear view of the retina. This test is typically carried out for patients with diabetes and those who may be at risk of developing retinal damage.
## How Many Optometrists Exist in Blacktown Sydney?
There are several optometrists that exist in Blacktown Sydney including Oscar Wylee. The number of optometrists in Blacktown potentially depends on the resident population and the demand, however, there is no definitive number of optometrists in Blacktown and other locations. Make Oscar Wylee Blacktown your first choice for outstanding optometry services which include comprehensive eye tests and a wide range of fashionable frames.
### What are the Other Closest Optometrist Locations to Blacktown, Sydney in Australia?
The other closest Oscar Wylee optometrist locations to Blacktown in Australia are Winston Hills, Mt Druitt, Castle Towers and Rouse Hill. The other closest optometrist locations to Blacktown, Sydney are listed below.
* Winston Hills: Winston Hills is close to Blacktown with 7-10 km in between stores. At [Oscar Wylee Winston Hills](https://www.oscarwylee.com.au/locations/optometrist-winston-hills.html), you can expect high-quality services which include eye health tests and assistance with prescription and non-prescription eyewear. Oscar Wylee Winston Hills can be found at the Winston Hills Mall next to Terry White Pharmacy.
* Mt Druitt: Mt Druitt is close to Blacktown, 10-13 km in distance away and is located on Cnr Carlisle Avenue &amp; Luxford Road, next to Prouds. The [Oscar Wylee Mt Druitt](https://www.oscarwylee.com.au/locations/optometrist-mt-druitt.html) store is where you have access to primary eye care services performed by a team who are passionate about your eye health.
* Rouse Hill: Rouse Hill is close to Blacktown with 11-14 km in between stores which you can visit at Rouse Hill Town Centre which is the go-to shopping centre for Rouse Hill residents. The [Oscar Wylee Rouse Hill](https://www.oscarwylee.com.au/locations/optometrist-rouse-hill.html) store is situated near JB HI-FI and offers many helpful services for those who require prescription and non-prescription eyewear.
* Castle Hill: Castle Hill is close to Blacktown with 13-15 km in between and can be found near David Jones, on level 2 of the Castle Towers Shopping Centre. The [Oscar Wylee Castle Hill](https://www.oscarwylee.com.au/locations/optometrist-castle-towers.html) store is where you can get your eyes tested at a bulk billed price and professional assistance with selecting the perfect pair of frames.
### Oscar Wylee Blacktown optometrists perform bulk billed eye tests
With Oscar Wylee, you can prioritise your eye health and take care of your vision. Just stop by our Oscar Wylee eyeglasses shop in Blacktown Sydney where the eye care processes available include prescription updates, eye health tests to assess vision and detect certain eye diseases, and frame shopping. At Oscar Wylee Blacktown, eye tests are bulk billed, meaning there are no out-of-pocket expenses for eligible Medicare card holders. Eye tests are carried out by our fully trained Oscar Wylee optometrists, using high-quality equipment.
### Oscar Wylee Blacktown accepts major health funds
At Oscar Wylee Blacktown, we accept all major health funds. Our staff can process your health fund claim in-store with a valid health fund card and are able to help answer any questions you may have about what you’re eligible for with your health fund. We ensure you don’t have to navigate the hardest parts of health insurance alone. Oscar Wylee Blacktown is dedicated to making sure you get what you need at an affordable, competitive price.
### Fashion-forward styles at affordable prices
Our optometrists at Oscar Wylee Blacktown are here to help provide prescription lenses to fit customer needs - from multifocal lenses to blue light filters or a polarised lens for your prescription sunglasses. Our team at Oscar Wylee Blacktown is committed to helping you find your perfect pair of frames, offering modern and vintage-style glasses frames at an affordable cost.
Book Appointment
[Call us: (02) 8809 5869](tel:(02) 8809 5869)
[Leave a Review!](https://g.page/r/Ccpf6vFNdQ8yEBM/review)