# Source: https://www.oscarwylee.com.au/cliff-optical.html

# Cliff
1
## Frame Design of Cliff Glasses
The frame design of Oscar Wylee’s Cliff glasses is characterised by a rectangle shape, high nose bridge and an acetate frame. Cliff glasses are a men’s, statement frame that will work for any occasion, whether the wearer wants to liven up their work style or complement a fun outfit for a night out.
$169    
In stock
Only %1 left
2 pairs from $199
Discount auto-applied at checkout
3 pairs from $249
Discount auto-applied at checkout
Qty
Add to cart
Book an eye test
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
excluding prescription lenses
## About Cliff Frames
Cliff is a classic square frame, that is large and in charge!
Spring hinges make for an extremely comfortable fit.
| Frame fit | Measurements |
| --- | --- |
| WIDE | 55 - 18 - 145 |
These measurements mean lens width, bridge, and temple length in
millimetres (mm). They can be found on the inside of the temple
arm. If you already have a pair that you like, you can compare it
to these measurements.
### Made from Acetate
Oscar Wylee’s Cliff frame is a men’s, rectangle glasses frame that
is perfect for wide faces and those with round and oval face
shapes. The Cliff frame is a stylish, widely wearable frame suited
to many personal styles. The main specs of Oscar Wylee’s Cliff
glasses frame including
dimensions, shape, materials, lenses, nose fit and hinges
are listed below.
| Cliff Frame Features | Cliff Frame Description | Dimensions | Shape | Materials | Lenses | Nose Fit | Hinges |
| --- | --- | --- | --- | --- | --- | --- | --- |
| The dimensions of the Cliff frame are measured in millimetres
(mm) and are 55 - 18 - 145, meaning the lens width is 55 mm,
the bridge is 18 mm and the temple length is 145 mm. |
| The Cliff frame is a rectangular shape, well suited to wide
faces. |
| Cliff glasses are made from a material called acetate. |
| The lenses that can be used in the Cliff frame are optical
lenses, which include single vision and multifocal lenses and
non-prescription lenses, which are plain and can have a filter
like a blue light filter applied. |
| The nose fit of Cliff frames is a high nose bridge. |
| The hinges in Cliff glasses are spring hinges, which are more
flexible than other types of hinges and can extend past 90
degrees. |
Show All
### What Inspired the Frame Design of Oscar Wylee’s
Cliff Glasses?
The Oscar Wylee Cliff frame design was inspired by current
fashion trends as rectangle glasses shapes are often in
fashion.
## What to Know
About Oscar Wylee’s Cliff Glasses?
There are many aspects of the Oscar Wylee Cliff frames that
customers should know about, so they can decide whether this
is the right frame for them. The Cliff frame is a men’s
rectangle-shaped frame. Oscar Wylee’s Cliff frame is suitable
for many face shapes but is particularly compatible with round
and oval face shapes. The Cliff frame’s simple design means
that they are fashionable all year round. Cliff glasses
feature the standard
[parts of glasses](https://www.oscarwylee.com.au/glasses/eye/part-of-glasses)
such as a rim, temples, lenses, spring hinges and a high nose
bridge.
### What are the
Types of Temple Tips or Earpieces Included with
Oscar Wylee’s Cliff Glasses?
The type of temple tips or earpieces included in Oscar Wylee’s
Cliff Glasses are made from acetate.
### What Type of Nose Bridge do Oscar Wylee’s Serge
Small Glasses Have?
The type of nose bridge included in Oscar Wylee’s Cliff frame
is a high nose bridge.
### What Type of Nose Pads are Included with Oscar
Wylee’s Cliff Glasses?
Oscar Wylee’s Cliff frame does not include any type of nose
pads.
### What Type of Lenses do Oscar Wylee’s Cliff Glasses
Have?
The type of lenses that typically come with the Oscar Wylee
Cliff
[glasses frame](https://www.oscarwylee.com.au/glasses.html)
are optical lenses. Optical lenses are glasses lenses that
have a prescription within the lens to help correct vision
issues such as myopia, hyperopia and astigmatism. Cliff
glasses can also come with non-prescription lenses, with
add-ons such as a blue light filter. Cliff frames are
currently unavailable as sunglasses online, however, customers
can customise in-store and add on tint or polarisation.
### What Material is Used for the Rim of Oscar Wylee’s
Cliff Glasses?
The material used for the rim of Oscar Wylee’s Cliff glasses
frames is acetate. The rim refers to the part of a glasses
frame that holds the lenses.
### What Type of Hinges are Included with Oscar Wylee’s
Cliff Glasses?
The type of hinges included with Oscar Wylee’s Cliff frames
are spring hinges. A spring hinge in a glasses frame refers to
hinges that are more flexible than normal hinges and can go
slightly beyond 90 degrees. Spring hinges can provide a closer
fit to the face.
## What Face Types are Most Suitable for Oscar Wylee’s
Cliff Glasses?
Glasses? The face types that are most suitable for Oscar
Wylee’s Cliff frame are round and oval face shapes. The Cliff
frame is a rectangle shape, meaning that it complements the
structure of round and oval faces particularly well. The
rectangle Cliff frame helps to balance the features of an
[oval face shape](https://www.oscarwylee.com.au/glasses/face-shapes/oval)
or a
[round face shape](https://www.oscarwylee.com.au/glasses/face-shapes/round), bringing the eyes and brows forward in a flattering way. A
rectangle shape can also bring balance to the face by
providing some structure. Although there are many
[glasses for face shapes](https://www.oscarwylee.com.au/glasses/face-shapes)
that may be considered more aesthetically suitable than those
mentioned above, it is important that people also choose the
frames that make them feel most comfortable, and represent
their style.
## What Size Options are Available for Oscar Wylee’s
Cliff Glasses?
The size options available for Oscar Wylee’s Cliff frame are a
wide-fit frame across all colours.
## What Materials are Used to Create Oscar Wylee’s
Cliff Glasses?
The primary material used to create the Oscar Wylee Cliff
frame is acetate. Acetate, also known as cellulose acetate, is
a bioplastic, made from cotton fibres or wood pulp. At Oscar
Wylee, acetate glasses are made by adding a dye to cellulose
acetate, which is rolled into a sheet. The shape of the
glasses is then cut from this sheet.
## What’s Included
## What's Included
Each pair of glasses comes with a stylish frame case and lens cloth. We offer free shipping across Australia and 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects.
* Free Shipping for Australian Orders
* 1 Year Warranty on frames and lenses
* Scratch resistance lens coating on all prescriptions
* UV-proof coating on all prescriptions
* Stylish case and cloth
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
## Make and Materials
The frames then go through cleaning and strict quality control, and many pairs of crafting hands to be hand-assembled and polished. After your frames have gone through the production process, they are individually examined and packed before making their way to you!Also known as cellulose acetate, these frames are traditionally hand-crafted by skilled craftsmen, with each frame passing through numerous stages of production and are hand-polished to ensure a glorious lustre.
## Warranty Information
### Warranty Information
### Warranty Information
Oscar Wylee provides a 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects. 
We will repair or replace faulty or defective frames or lenses free of charge for warranty claims made within 1 year of the delivery.
We also offer repairs or replacement for problems experienced with vision during everyday use for claims made within 30 days of delivery. If the same product has been discontinued or is no longer available, then we may offer an exchange for a similar product or a refund.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Find a Store Location](https://www.oscarwylee.com.au/locations/full-store-list.html)
Recommended
1. [](https://www.oscarwylee.com.au/windsor-optical.html)
[Windsor](https://www.oscarwylee.com.au/windsor-optical.html)
Citrus