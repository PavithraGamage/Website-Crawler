# Source: https://www.oscarwylee.com.au/glasses/eye/types-of-glaucoma

# Types of Glaucoma
Published on July 16th, 2026
Australia
Australia
New Zealand
Canada
Canadian French

There are many types of glaucoma, with most divided into two categories:
open-angle glaucoma and closed-angle glaucoma, with primary and secondary
glaucoma as their different variants. Open-angle glaucoma is characterised by an open drainage system, while
closed-angle glaucoma is where the drainage system may be partially or
completely obstructed. According to Glaucoma Australia, a rough estimate of
400,000 Australians have glaucoma, with about 50% undiagnosed.
Due for an eye test?
With an optometrist in every store, you can receive a bulk billed eye test
to assess your vision and the health of your eyes for eligible medicare
card holders.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Types](#types)
[Primary vs Secondary](#primary-vs-secondary)
[Treatment](#treatment)
[Risk Factors](#risk-factors)
The types of glaucoma may include
primary open angle glaucoma, primary angle closure glaucoma, normal
tension glaucoma, congenital glaucoma and secondary glaucoma.
Some of the different types of glaucoma are listed below.
* Primary Open Angle Glaucoma: Primary
open angle glaucoma can develop gradually without any noticeable
symptoms as a result of the eye's drainage system slowly growing
inefficient over time.
* Primary Angle Closure Glaucoma: Primary angle closure glaucoma can occur when the drainage angle
located between the iris and cornea becomes narrow and blocks fluid
drainage.
* Normal Tension Glaucoma: Normal
tension glaucoma occurs when a patient has normal intraocular
pressure, but there is still damage to the optic nerve.
* Congenital Glaucoma: Congenital
glaucoma is a rare form that is present at birth and early childhood,
due to the incomplete development of the eye's intraocular fluid
drainage system.
* Secondary Glaucoma: Secondary glaucoma
is a category of different types of glaucoma that occurs as a result
of another eye problem or disorder.
## 1. Primary Open Angle Glaucoma
Primary Open Angle Glaucoma is not caused by another medical condition.
According to Glaucoma Australia, open-angle glaucoma
is typically caused by high intraocular pressure inside the eye that
damages the optic nerve. The high pressure is typically due to an
imbalance in the flow of fluid in the eye.
There are typically no symptoms for primary open-angle glaucoma, as most
patients will not notice any vision changes and will not experience
pain. It is considered the most common form of glaucoma in Australia and
is typically treated with eye drops that help reduce increased
intraocular pressure.
## 2. Primary Angle Closure Glaucoma
Primary Angle Closure Glaucoma
can occur when the iris is physically pushed or moved forward,
blocking the drainage angle completely.
This hinders the healthy outflow of aqueous humour, according to
Glaucoma Australia. Treating the increased ocular pressure may depend on
the extent of damage to the trabecular meshwork and angle closure.
## 3. Normal Tension Glaucoma
Normal-tension Glaucoma is
characterised by normal intraocular pressure, but there is still
damage to the optic nerve.
According to Glaucoma Australia, it is believed that
normal-tension glaucoma can stem from a lack of ocular blood flow to
the optic nerve, which makes a person more susceptible to developing
this type of glaucoma. As with many other types of glaucoma, patients may not typically
experience any symptoms, which is why early detection can be very
difficult. Normal-tension glaucoma may be treated with eye drops that
will lower eye pressure, and surgery or laser treatment may be suggested
to slow its progression in an attempt to preserve eyesight.
## 4. Congenital Glaucoma
Congenital Glaucoma is
a rare type of glaucoma that develops at birth and early childhood,
due to the improper development of the eye's intraocular fluid
drainage system, which causes high eye pressure.
According to the National Eye Institute, the symptoms of congenital
glaucoma in children include cloudy eyes, sensitivity to light, eyes
that are larger than normal and excessive tear production.
## 5. Secondary Glaucoma
Secondary Glaucoma is
a category of different types of glaucoma that is caused by another
eye problem or disorder. According to Glaucoma Australia, types of secondary glaucoma include
pigmentary glaucoma, related to the iris; neovascular glaucoma, which
can develop when the eye does not receive enough blood and oxygen;
traumatic glaucoma, caused by a direct injury to the eye; uveitic
glaucoma, the result of the eye condition uveitis; and steroid-induced
glaucoma, caused by steroid medications. Symptoms are not usually
experienced in the early stages, which is why it is recommended to have
an eye test at least once every two years so an optometrist can assess
for eye diseases and conditions, including glaucoma.
## How do Different Types of Glaucoma Compare?
There are many different types of glaucoma, which can affect individuals
differently.
When comparing some of the different types of glaucoma, the most
common form, according to Glaucoma Australia, is open-angle
glaucoma.
This type is slow-growing and normally detected during a routine
standard eye test with an optometrist and can include risk factors such
as being over the age of 50, having a family history of glaucoma, and
short-sightedness. The type that may urgently require treatment is
[acute angle-closure glaucoma](https://www.oscarwylee.com.au/glasses/eye/acute-angle-closure-glaucoma)
due to the rapid increase of intraocular pressure.
### What is the Difference Between Primary and Secondary Glaucoma?
The difference between primary and secondary glaucoma is their cause.
Primary glaucoma can occur without an individual already having an
underlying condition, while secondary glaucoma is the consequence of
specific triggers
that can be identified, such as inflammation, an injury to the eye or
tumours.
#### Do All Types of Glaucoma Require the Same Treatment?
No, all types of glaucoma may not require the same treatment.
While most cases may be managed effectively through the use of
eye drops, laser treatment or surgery, treatment can differ
between patients.
It may be important to note that while treatment can help prevent
vision loss, it cannot restore sight that is already impaired from
glaucoma.
Find Your Nearest OW Store!
We've got knowledgeable teams who are passionate about delivering
high-quality care.
[Find a store](https://www.oscarwylee.com.au/locations)
## Which Type of Glaucoma is the Most Serious?
The type of glaucoma that may be most serious
is acute angle-closure glaucoma. Acute angle-closure
[glaucoma](https://www.oscarwylee.com.au/eye-care/eye-conditions/glaucoma)
may be less common but can be a medical emergency and require urgent
care.
It causes a rapid increase in eye pressure, which can result in vision
loss in a shorter span of time, unlike other types, which are slowly
progressing.
### Which Glaucoma Type Has the Highest Risk of Vision Loss?
The glaucoma type that may have the highest risk of vision loss
is acute angle-closure glaucoma, as it can cause a sudden spike in
intraocular pressure
and lead to vision loss in a matter of hours. Other forms of glaucoma,
such as primary open-angle glaucoma, are considered more common and
may take longer to progress.
#### Can Early Diagnosis Help Prevent Blindness From Any Type of
Glaucoma?
Yes, early diagnosis may help prevent blindness from any type of
glaucoma.
However, it is important to note that
[vision impairment](https://www.oscarwylee.com.au/glasses/eye/visual-impairment)
that is already present cannot be restored. Having regular eye tests
can help with early detection and allow treatments to effectively
delay progression and reduce eye pressure.
## How do Eye Doctors Diagnose Different Types of Glaucoma?
Eye doctors can diagnose different types of glaucoma
through an eye test. An optometrist or ophthalmologist can identify
each form by assessing the optic nerve, other structures in the eye,
and pressure levels.
There are several steps as part of a routine eye test that can help eye
care professionals examine all important regions of the eye. In
Australia, ophthalmologists are the only eye care professionals who are
considered
[eye doctors](https://www.oscarwylee.com.au/eye-care/optometry/eye-doctors.html); however, optometrists are qualified and trained to diagnose eye
conditions including glaucoma.
### What Eye Tests Help Identify the Type?
The eye tests that can help identify the type of glaucoma can include
tonometry, gonioscopy, visual field test, optical coherence
tomography
and ophthalmoscopy. The
[eye tests](https://www.oscarwylee.com.au/eye-care/eye-test)
that can help identify the type are listed below.
* Tonometry: A tonometry test can help
with diagnosing glaucoma as it measures the pressure in your eyes,
known as intraocular pressure.
* Gonioscopy: A gonioscopy is a test
that examines how well the drainage system in the eye works.
* Visual Field Test: A visual field
test assesses the condition and quality of one's peripheral vision.
As peripheral vision is the area of sight affected by glaucoma, a
visual field test is important in helping to diagnose glaucoma.
* Optical Coherence Tomography: Optical coherence works by using near-infrared light to illuminate
and assess how much light is subsequently reflected off the retina
and optic nerve.
* Ophthalmoscopy: Ophthalmoscopy helps
eye care professionals to examine the interior structures of the eye
such as the optic nerve and retina.
## How is Each Type of Glaucoma Treated?
Each type of glaucoma may be treated with
eye drops, laser therapy and
surgery. The different treatment options for each type
of glaucoma are listed below.
* Eye Drops: [Eye drops](https://www.oscarwylee.com.au/glasses/eye/types-of-eye-drops)
are typically the first line of treatment for glaucoma and work by
reducing intraocular pressure by either reducing the amount of fluid
your eye produces or improving fluid drainage.
* Laser Therapy: Laser therapy for each
glaucoma type can help aqueous humour flow better and also help this
fluid drain more effectively within the eye. This treatment is
performed by an ophthalmologist.
* Surgery: Surgery is used to treat each
glaucoma type when the condition is unable to be helped by other forms
of treatment such as medication, eye drops and laser treatment. Common
eye surgeries for glaucoma include Trabeculectomy and Glaucoma
Drainage Devices.
### Which Treatments Work Best for Different Types?
The treatments that can work best for different types
will typically include the usual options, such as eye drops, laser
therapy and surgery.
The exact treatment that will work best for the different types will
depend on the severity and stage of the patient's condition. It is
important to note that it may be difficult to state which particular
treatment is the most suitable for every form, as treatment varies
between individuals.
#### Do All Types of Glaucoma Require Surgery?
No, all types of glaucoma do not require surgery.
Certain types or cases of glaucoma may only need surgery when eye
drops and laser therapy are not effective on the
condition.
### What Risk Factors Increase the Chance of Developing Glaucoma?
The risk factors that may increase the chance of developing glaucoma
include
having a family history of glaucoma, being over the age of 50,
having diabetes, being short- or long-sighted, on long-term use of
steroid medication, having had an eye operation or eye injury and
having high blood pressure.
#### Can Family History Increase Your Risk?
Yes, having a family history of glaucoma can increase your risk of
developing glaucoma. According to Glaucoma Australia,
first-degree relatives, which include parents, siblings and
children, have a higher risk of developing glaucoma.
This is why it is important to let your optometrist know and ensure
you get regular eye tests to help with early detection and timely
treatment.
Read Types of Glaucoma in other Oscar Wylee regions and their
languages.
Australia
Australia
New Zealand
Canada
Canadian French

Experience High Quality Eyecare Services From Our Team
Book an appointment online with an Oscar Wylee optometrist today.
[Book an eye test](https://www.oscarwylee.com.au/booking)
Major Health Funds Accepted
In-store
For the purchase of frames and lenses, use your private health fund to
limit how much you pay from your own pocket.
[Health Funds](https://www.oscarwylee.com.au/health-funds.html)