# Source: https://www.oscarwylee.com.au/leo-optical.html

# Leo
1
## Frame Design of Leo Glasses
The frame design of Oscar Wylee’s Leo glasses is characterised by their oval and round shape, high nose bridge, and an acetate frame. Leo is a unisex, statement glasses frame that will complement any outfit, day to night.
$169    
In stock
Only %1 left
2 pairs from $199
Discount auto-applied at checkout
3 pairs from $249
Discount auto-applied at checkout
Qty
Add to cart
Book an eye test
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
excluding prescription lenses
## About Leo Frames
Presenting the frame that people talk about; Leo. Known for versatility and class. Easy to wear with gorgeous acetate material, Leo is truly a cult classic.
| Frame fit | Measurements |
| --- | --- |
| NARROW | 45 - 22 - 145 |
These measurements mean lens width, bridge, and temple length in millimetres (mm). They can be found on the inside of the temple arm. If you already have a pair that you like, you can compare it to these measurements.
### Made from Acetate
Oscar Wylee’s Leo frame is a unisex oval and round glasses frame that is perfect for those with square, oval and heart face shapes. The Leo frame is a stylish, widely wearable frame that can be worn every day. The main specs of Oscar Wylee’s Leo glasses frame, including dimensions, shape, materials, lenses, nose fit, and hinges are listed below.
| Leo Frame Features | Leo Frame Description | Dimensions | Shape | Materials | Lenses | Nose Fit | Hinges |
| --- | --- | --- | --- | --- | --- | --- | --- |
| The dimensions of the Leo frame are measured in millimetres (mm) and are 45 - 22 - 145, meaning the lens width is 45 mm, the bridge is 22 mm, and the temple length is 145 mm. |
| Leo is an oval and round shape, well-suited to narrow faces. |
| Leo is made from acetate. |
| The lenses that can be used in the Leo frame include optical lenses, such as single-vision and multifocal, and non-prescription lenses, which are plain and can have a filter, such as a blue light filter applied. |
| The nose fit for Leo is characterised by a high nose bridge. |
| The hinges in Leo are normal hinges, also known as standard or barrel hinges. |
Show All
### What Inspired the Frame Design of Oscar Wylee’s Leo Glasses?
The Oscar Wylee Leo frame design was inspired by current fashion trends, as oval and round glasses are a timeless style.
## What to Know About Oscar Wylee’s Leo Glasses?
There are many aspects of the Oscar Wylee Leo frames that customers should know about to decide whether this is the right frame for them. The Leo frame is a unisex oval and round shaped frame. Oscar Wylee’s Leo frame is suitable for many face shapes, but particularly compatible with square, oval and heart face shapes. The Leo frame’s simple design makes them fashionable all year round. Leo features the standard [parts of glasses](https://www.oscarwylee.com.au/glasses/eye/part-of-glasses), such as a rim, temples, lenses, hinges, and a high nose bridge.
### What are the Types of Temple Tips or Earpieces Included with Oscar Wylee’s Leo Glasses?
The type of temple tips or earpieces included in Oscar Wylee’s Leo Glasses are made from acetate.
### What Type of Nose Bridge do Oscar Wylee’s Leo Glasses Have?
The type of nose bridge included in Oscar Wylee’s Leo frame is characterised by a high nose bridge.
### What Type of Nose Pads are Included with Oscar Wylee’s Leo Glasses?
Oscar Wylee’s Leo frame does not have adjustable nose pads.
### What Type of Lenses do Oscar Wylee’s Leo Glasses Have?
The type of lenses that typically come with the Oscar Wylee Leo [glasses frame](https://www.oscarwylee.com.au/glasses.html) are optical lenses. Optical lenses are glasses lenses that have a prescription within the lens to help correct vision issues such as myopia, hyperopia, and astigmatism. Leo frames can also come as sunglasses and with non-prescription lenses and add-ons such as a blue light filter.
### What Material is Used for the Rim of Oscar Wylee’s Leo Glasses?
The material used for the rim of Oscar Wylee’s Leo glasses frames is acetate. The rim refers to the part of a glasses frame that holds the lenses.
### What Type of Hinges are Included with Oscar Wylee’s Leo Glasses?
The type of hinges included with Oscar Wylee’s Leo frames are normal hinges. Normal hinges, also known as barrel hinges or standard hinges have many interlocking loops that are stabilised with a small screw.
## What Face Types are Most Suitable for Oscar Wylee’s Leo Glasses?
The face types that are most suitable for Oscar Wylee’s Leo frame are square, oval and heart face types. The Leo frame is an oval and round shape, meaning that it complements the structure of square, oval and heart faces particularly well. The oval &amp; round Leo frames help balance the features of [square face shapes](https://www.oscarwylee.com.au/glasses/face-shapes/square), [oval face shapes](https://www.oscarwylee.com.au/glasses/face-shapes/oval) and [heart face shapes](https://www.oscarwylee.com.au/glasses/face-shapes/heart), bringing the eyes and brows forward in a flattering way. Although there are many [glasses for face shapes](https://www.oscarwylee.com.au/glasses/face-shapes) that may be considered more aesthetically suitable, it is important that people also choose frames that make them feel most comfortable and represent their personal style.
## What Size Options are Available for Oscar Wylee’s Leo Glasses?
The size options available for Oscar Wylee’s Leo frame are a narrow-frame fit frame across all colours.
## What Materials are Used to Create Oscar Wylee’s Leo Glasses?
The primary material used to create the Oscar Wylee Leo frame is acetate. Acetate is used for the rim, nose bridge, and temples and temple tips.
## What’s Included
## What's Included
Each pair of glasses comes with a stylish frame case and lens cloth. We offer free shipping across Australia and 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects.
* Free Shipping for Australian Orders
* 1 Year Warranty on frames and lenses
* Scratch resistance lens coating on all prescriptions
* UV-proof coating on all prescriptions
* Stylish case and cloth
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
## Make and Materials
The frames then go through cleaning and strict quality control, and many pairs of crafting hands to be hand-assembled and polished. After your frames have gone through the production process, they are individually examined and packed before making their way to you!Also known as cellulose acetate, these frames are traditionally hand-crafted by skilled craftsmen, with each frame passing through numerous stages of production and are hand-polished to ensure a glorious lustre.
## Warranty Information
### Warranty Information
### Warranty Information
Oscar Wylee provides a 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects. 
We will repair or replace faulty or defective frames or lenses free of charge for warranty claims made within 1 year of the delivery.
We also offer repairs or replacement for problems experienced with vision during everyday use for claims made within 30 days of delivery. If the same product has been discontinued or is no longer available, then we may offer an exchange for a similar product or a refund.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Find a Store Location](https://www.oscarwylee.com.au/locations/full-store-list.html)