# Source: https://www.oscarwylee.com.au/glasses/eye/vitreous-humour

# Vitreous Humour: Anatomy, Function, and Related Eye Problems
Updated on April 23rd, 2025
Published on April 12th, 2024
Australia
[Australia](https://www.oscarwylee.com.au/glasses/eye/vitreous-humour)
[Canada](https://oscarwylee.ca/glasses/eye/vitreous-humour)
[Canadian French](https://oscarwylee.ca/fr/glasses/eye/vitreous-humour)
The vitreous humour, also known as vitreous fluid, is a clear, gel
substance that fills most of the space of the eye, from the lens down to
the retina. The vitreous humour is the largest part of the eyeball and its
functions include maintaining the shape of the eye, maintaining oxygen
gradient, shock absorption and vision clarity. Eye conditions related to
the vitreous humour include&nbsp;eye floaters, vitreous degeneration and posterior vitreous detachment.&nbsp;Ways to take care of the vitreous humour include booking regular
eye tests, eating a healthy diet, exercising regularly and stopping
smoking. Keep reading to learn more about the structure of the vitreous
humour and its functions.
Due for an Eye Test?
Our Oscar Wylee optometrists offer bulk billed eye tests for valid
Medicare cardholders. Come in to have your vision and eye health assessed.
[Book your eye test](https://www.oscarwylee.com.au/booking)
[Definition](#Definition) [Function](#Function)
[Related Problems](#Problems) [Care](#Care)
## What is the Vitreous Humour of the Eye?
The vitreous humour of the eye is a&nbsp;gel-like substance that fills the inside of the eyeball, according to the National Cancer Institute. The vitreous humour is
a clear substance comprising mostly water; the rest is made up of
salts, sugars, collagen and proteins. According to an article
published in the National Library of Medicine titled,&nbsp;Vitreous function and intervention of it with vitrectomy and other
modalities, the vitreous humour is the largest intraocular component and plays
an important role in the eye’s development and oxygen
metabolism.
### Are the Vitreous Body and the Vitreous Humour the Same?
Yes,&nbsp;the vitreous body and the vitreous humour are the same thing, they are simply different terms for this part of the eye’s
anatomy.
## What is the Structure of the Vitreous Humour?
The vitreous humour&nbsp;provides the shape of the eyeball and is made of mostly water with
other substances such as collagen and glucose.&nbsp;Collagen provides the vitreous humour with strength and also
maintains its gel state. According to the National Library of
Medicine, the vitreous humour makes up 80% of the intraocular
volume.
### What is the Vitreous Humour Made of?
The vitreous humour is&nbsp;made of approximately 98-99% water, according to an article published in Science Direct. The rest is
comprised of trace amounts of collagen, ions, hyaluronic acid,
glucose, anions and cations.
### What Colour is the Vitreous Humour?
The vitreous humour is&nbsp;transparent or clear and, therefore, is colourless.&nbsp;The&nbsp;vitreous humour is clear&nbsp;as it is made up almost completely of water and does not
contain any substances that would give it colour.
### Where is the Vitreous Humour Located?
The vitreous humour is&nbsp;located between a person’s lens and retina, in
the vitreous cavity,&nbsp;according to the Cleveland Clinic. In the vitreous cavity,
the vitreous humour is located in a protective layer called the
vitreous membrane. According to an article published in the National
Library of Medicine, the vitreous humour is adjacent to the ciliary
body, retina and lens.
## What is the Function of the Vitreous Humour in the Eye?
There are four main functions of the vitreous humour according to
Medical News Today, which are&nbsp;maintaining the shape of the eye, maintaining oxygen gradient, shock
absorption and vision clarity.&nbsp;The vitreous humour maintains the shape of the eye, making up
80% of the eye’s volume and holding the retina and lens in place.
According to Medical News Today, the vitreous humour ensures that the
eye maintains proper oxygen balance so that there is a lower oxygen
concentration near the lens and a higher concentration near the
retina. Vitreous humour helps with shock absorption to prevent
injuries as it is a viscous and soft fluid. Finally, vision clarity is
a function of the vitreous humour due to its clear nature, allowing
light to travel unobstructed to the retina.
### How Does the Vitreous Humour Help the Human Eye See?
The vitreous humour helps the human eye see&nbsp;by helping with vision clarity as it lets light in to hit the
retina.&nbsp;As the vitreous humour is a clear substance, it does not
provide any obstruction when light enters the eye. The&nbsp;[aqueous humour](https://www.oscarwylee.com.au/glasses/eye/aqueous-humour)&nbsp;on the other hand, helps the eye maintain optimal inflation
and its shape by providing nutrients.
#### Is the Vitreous Humour Sensitive to Light?
No,&nbsp;the vitreous humour is not sensitive to light,
the retina is the light-sensitive layer in the eye.&nbsp;The retina is located at the back of the eye and converts light
that enters the eye into electrical impulses which the optic nerve
then sends to the brain.
There’s More In-Store!
Visit our friendly team at a store near you where you can try on our
latest styles.
[Find a store](https://www.oscarwylee.com.au/locations/)
## What are the Vitreous Humour-related Eye Problems?
The vitreous humour-related eye problems include&nbsp;eye floaters, posterior vitreous detachment, vitreous hemorrhage,
vitreous degeneration and persistent hyperplastic primary
vitreous.&nbsp;These eye conditions and their definitions are listed below.
* Eye floaters: Eye floaters are an eye
problem where a person sees spots or lines in their vision caused by
changes to the vitreous inside the eye.
* Posterior vitreous detachment:&nbsp;Posterior vitreous detachment is an eye condition that is
characterised by the vitreous humour separating from the retina
often due to the natural ageing process.
* Vitreous hemorrhage:&nbsp;A vitreous hemorrhage occurs when there is blood in the vitreous
cavity. The causes of bleeding in the vitreous are abnormal vessels,
normal vessels and extension of blood from an adjacent source.
* Vitreous degeneration:&nbsp;Vitreous
degeneration occurs when the vitreous begins to shrink and liquefy,
most commonly due to age.
* Persistent hyperplastic primary vitreous:&nbsp;Persistent hyperplastic primary vitreous (PHPV)
causes a failure of the embryological, primary vitreous and hyaloid
vasculature to regress.
### 1. Eye Floaters
Eye floaters are an eye problem where&nbsp;a person sees spots or lines in their vision caused by changes to
the vitreous inside the eye.&nbsp;Eye floaters can look like lines, strings, cobwebs,
threadlike stands and black or grey dots. The causes of&nbsp;[eye floaters](https://www.oscarwylee.com.au/glasses/eye/floaters-definition)&nbsp;include diabetic retinopathy, ageing, eye injuries, migraines
and retinal detachment. Eye floaters can be treated through eye
surgery and laser therapy, or simply waiting out the symptoms in
some cases, as symptoms may lessen over time and become tolerable.
Your optometrist will advise which treatment is best.
### 2. Posterior Vitreous Detachment
Posterior vitreous detachment is an eye condition that
is&nbsp;characterised by the vitreous humour separating from the retina
often due to the natural ageing process.&nbsp;Symptoms of posterior vitreous detachment include eye
floaters and flashes of light, according to the Cleveland Clinic.
Posterior vitreous detachment is unlikely to cause vision loss and
should not cause any pain. As&nbsp;[posterior vitreous detachment](https://www.oscarwylee.com.au/glasses/eye/posterior-vitreous-detachment)&nbsp;is non-sight threatening, treatment is not always necessary,
however, treatment may be advised if there are complications such as
a retinal tear, retinal detachment, macular pucker and macular
hole.
### 3. Vitreous Hemorrhage
A vitreous hemorrhage&nbsp;occurs when there is blood in the vitreous cavity.&nbsp;The three causes of bleeding in the vitreous are abnormal
vessels which are prone to bleeding, normal vessels which rupture
due to stress and extension of blood from an adjacent source such as
tumours, according to the American Academy of Ophthalmology. The
symptoms of a vitreous hemorrhage include eye floaters and more
severe cases may cause issues with a person’s visual acuity and
visual field. Treatment for a vitreous hemorrhage is determined by
treating the underlying cause.
### 4. Vitreous Degeneration
Vitreous degeneration occurs when&nbsp;the vitreous begins to shrink and liquefy, most commonly due to
age, according to the Kellogg Eye Centre. Vitreous degeneration causes
symptoms such as eye floaters and posterior vitreous detachment as
the vitreous separates from the retina. While the most common cause
of vitreous degeneration is age, this condition can be accelerated
due to previous cataract surgery, eye trauma and myopia
(nearsightedness). Treatment is not typically necessary for vitreous
degeneration as most instances will not affect a person’s vision
other than eye floaters which people can get used to over
time.
### 5. Persistent Hyperplastic Primary Vitreous
Persistent hyperplastic primary vitreous (PHPV), more commonly
known as persistent fetal vasculature, is a&nbsp;congenital condition present at birth that causes a failure of the
embryological, primary vitreous and hyaloid vasculature to
regress, according to an article published in the National Library of
Medicine by M Silbert and AS Gurwood. There are three presentations
of PHPV which are a purely anterior presentation, a purely posterior
presentation and, the most common clinical presentation, which is a
combination of anterior and posterior presentations.
## What are the Different Ways to Take Care of the Vitreous Humour?
The different ways to take care of the vitreous humour according to
the Cleveland Clinic include&nbsp;booking regular eye tests, eating a healthy diet, exercising
regularly and stopping smoking.&nbsp;These ways to take care of the vitreous humour are listed
below.
* Book regular eye exams: Booking
regular eye exams is very important in taking care of your overall eye
health, including the health of your vitreous humour. Eye exams allow
optometrists to monitor the health of your eyes and detect eye
problems.
* Eat a healthy diet:&nbsp;A healthy and balanced diet is beneficial for
overall eye health including for the vitreous humour. By eating
well, you give your body the fuel it needs which helps to boost
immunity and health.
* Exercise regularly:&nbsp;Regular exercise is
beneficial for eye health as it lowers the chance of developing
conditions that may affect a person’s eyes such as diabetes or high
blood pressure.
* Stop smoking:&nbsp;Smoking is very detrimental
to a person’s eye health as it has been shown to cause damage to the
macula and the retina. Smoking is also linked to an increased risk
of age-related macular degeneration.
### What is the Importance of a Regular Eye Exam for the Vitreous Humour?
A regular eye test is very important as it&nbsp;can detect issues with the vitreous humour such
as a posterior vitreous detachment and vitreous degeneration.&nbsp;We recommend everyone has an eye test at least once every two
years or, if you are over the age of 65, then a year review is
advised. If you are experiencing any noticeable changes in your
vision, you also should contact an optometrist so they can assess
your vision and eye health.
### How can Oscar Wylee Help Take Care of Your Eyes?
Oscar Wylee can help you take care of your eyes by&nbsp;providing high-quality eye tests performed by skilled
optometrists.&nbsp;Our Oscar Wylee optometrists use modern equipment to assess
your eye health and vision to detect any signs of eye disease and
provide treatment, or refer patients where necessary. After your eye
test, you can browse our wide range of frames and order your new
glasses on the same day.
Read Vitreous Humour: Anatomy, Function, and Related Eye Problems in
other Oscar Wylee regions and their languages.
Australia
[Australia](https://www.oscarwylee.com.au/glasses/eye/vitreous-humour)
[Canada](https://oscarwylee.ca/glasses/eye/vitreous-humour)
[Canadian French](https://oscarwylee.ca/fr/glasses/eye/vitreous-humour)
Take Care of Your Vision
Regular eye tests allow your optometrist to monitor your vision and
eye health for any changes.
[Book your eye test](https://www.oscarwylee.com.au/booking)
Get a Full Quote in Storee
Get fitted for your glasses at Oscar Wylee by visiting us in-store and
you can talk to our friendly staff for a complete quote.
[Explore Health Funds](https://www.oscarwylee.com.au/health-funds.html)