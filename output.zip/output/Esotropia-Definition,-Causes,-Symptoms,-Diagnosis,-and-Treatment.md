# Source: https://www.oscarwylee.com.au/glasses/eye/esotropia

# Esotropia: Definition, Causes, Symptoms, Diagnosis, and Treatment
Published on July 8th, 2025
Updated on March 21st, 2025  
Australia   
[Australia](https://www.oscarwylee.com.au/glasses/eye/esotropia)
[Canada](https://oscarwylee.ca/glasses/eye/esotropia)
[Canadian French](https://oscarwylee.ca/fr/lunettes/oeil/esotropie)
Esotropia is defined as a form of strabismus, also known as misaligned eyes and can be characterised as the inward turning of the eye or both eyes. The types of esotropia can include congenital, acquired, constant, intermittent, accommodative, nonaccommodative and pseudoesotropia. This eye condition can develop when your eye muscles are failing to coordinate as they are meant to work together to achieve binocular vision, according to the Cleveland Clinic. Other possible factors that may cause esotropia are family history, high hyperopia, premature birth, a brain issue, eye conditions or a neurological condition. Esotropia may present symptoms such as the inability of the eyes to move in synchronisation, having to turn your head to improve vision, squinting and blinking. It can also include depth perception issues and poor vision in one eye (amblyopia). This type of strabismus can be diagnosed through a refraction test, visual acuity test and a dilated eye exam.
Our Oscar Wylee Optometrists Care About Your Eye Health
Make an appointment with us today for excellent optometry services.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Definition](#definition) [Types](#types) [Causes](#causes) [Symptoms](#symptoms)
## What is Esotropia?
Esotropia is defined as an eye condition and form of strabismus, that causes misalignment of the eye or eyes, in which they are pointed towards the nose. It is essential for both eyes to coordinate when moving; this is known as binocular vision. Binocular vision is the ability to visually focus on an object with both eyes. There are different types of esotropia, which include intermittent, constant, congenital, acquired, accommodative, non-accommodative and pseudoesotropia.
### What Does Esotropia Look Like?
Esotropia may look like the inward-turning of the eyes and may initially occur intermittently. When esotropia occurs, a distinctive sign can be one or both eyes crossing, pointed towards the nose and struggling to move together.
### How Common is Esotropia?
Esotropia may be common, according to the Lions Eye Institute strabismus is one of the most common eye conditions that occurs in children. However, there is still insufficient data on the estimate of people specifically with esotropia.
#### Is Esotropia Hereditary?
Yes, esotropia can be inherited, as it has more associations with heritable factors than exotropia, which is known as another form of strabismus. A 2014 study of 1462 twins concluded that esotropia exhibited more evidence of genetic links with 64% of esotropia deviation according to the National Library of Medicine.
### How Does Esotropia Differ From Other Types of Strabismus?
Esotropia differs from other types of [strabismus](https://www.oscarwylee.com.au/glasses/eye/crossed-definition) as each form causes the eyes to turn in different directions. While esotropia can prompt the eyes to turn inward, exotropia causes outward turning, hypotropia causes downward turning and hypertropia can cause upward turning. It may be common to mistake comparing esotropia and strabismus, however, like the other forms mentioned, esotropia is one of the four types of strabismus.
## What are the Different Types of Esotropia?
The different types of esotropia are intermittent, constant, congenital or infantile, nonaccommodative, accommodative, and pseudoesotropia. The different types of esotropia and their definitions are listed below.
* Intermittent Esotropia: Intermittent esotropia is a form of strabismus that can occur and stop at irregular intervals.
* Constant Esotropia: Constant esotropia is when the misalignment of the eyes is present all the time.
* Congenital or Infantile Esotropia: Congenital esotropia also known as infantile esotropia is when esotropia develops at birth or at around six months of age.
* Nonaccommodative Esotropia: Nonaccommodative esotropia can be defined as a form of strabismus that cannot be treated with glasses and may require surgery.
* Accommodative Esotropia: Accommodative esotropia is described as a type of strabismus that develops in children as a result of attempting to focus.
* Pseudoesotropia: Pseudoesotropia is a condition in which a child's eyes appear to be misaligned but are not. They may look this way due to a wide, broad or flat nose bridge or pronounced folds in the upper lid of the eye.
### 1. Intermittent Esotropia
Intermittent esotropia is characterised as a form of strabismus that causes misalignment of the eyes in fluctuation. According to the Optometrists Network, intermittent esotropia can be managed, however, may be triggered by stress or extended periods of performing activities that rely on near-vision. Treatment for intermittent esotropia can include prescription glasses, vision therapy, and surgery depending on the severity of the condition. According to the American Optometric Association, intermittent esotropia may present symptoms such as double vision as the brain is interpreting two images, depth perception issues and impeded vision in one eye. Untreated intermittent esotropia could potentially lead to constant esotropia, therefore, it is important to see an optometrist if you are experiencing such changes.
### 2. Constant Esotropia
Constant esotropia occurs when the misalignment of the eyes is always present. Intermittent esotropia differs from constant esotropia as the misalignment of the eyes or eye may be brought on by stressful situations or prolonged concentration, whereas the latter presents its implications all the time. Constant esotropia could develop if intermittent esotropia is left untreated in some cases, however, other cases can still remain intermittent according to Science Direct. This type of esotropia is considered more serious and can affect how some individuals may position their heads in order to maintain normal alignment of the eyes according to the National Library of Medicine.
### 3. Congenital or Infantile Esotropia
Congenital or infantile esotropia is the form of strabismus that occurs either at birth or around six months and is the most common type of esotropia. Patients with congenital or infantile esotropia typically have normal visual acuity. However, amblyopia could develop in the potential case of one eye turning more than the other during congenital esotropia. The factors that may contribute to the occurrence of congenital esotropia can include premature birth, family history of strabismus, seizure disorders, developmental delay and cerebral palsy according to the American Association for Pediatric Ophthalmology. Eye muscle surgery is the main form of treatment for this case of strabismus and should be performed before the patient turns 2. This has been found to produce better results for vision, however, there may be a likely chance of the patient exhibiting a deficiency in depth-perception when older.
### 4. Nonaccommodative Esotropia
Nonaccommodative esotropia is defined as a type of strabismus that does not improve with the use of prescription glasses. While it may be too difficult to determine the main cause for the development of nonaccommodative esotropia, there may be certain risk factors associated with this condition. These risks can include the occurrence of esotropia before the age of 2 and oblique dysfunction according to the American Academy of Ophthalmology. Strabismus surgery may be recommended to aid misalignment as prescription glasses are not able to resolve this form of strabismus.
### 5. Accommodative Esotropia
Accommodative esotropia occurs when the eye or both eyes turn towards the nose when trying to concentrate and can be treated with prescription glasses. This form of esotropia is found more in children with farsightedness, and those with poor near-vision. Accommodative esotropia may typically develop in children from the ages of 18 to 36 months and may be more likely for those with a family history of strabismus. It is important to note, that farsightedness does not always result in developing esotropia, however, children may be more susceptible to crossing their eyes when trying to focus to see objects up close clearly. Accommodative esotropia can be treated with prescription glasses.
### 6. Pseudoesotropia
Pseudoesotropia is a condition in which the eyes are not crossed but appear to be misaligned. Due to a flat or broad nose bridge or a pronounced fold of the upper eyelid, the eyes or eye may appear misaligned. An optometrist will be capable of fully assessing whether the patient does have esotropia by examining how one eye moves while the other eye is covered.
## What are the Causes of Esotropia
The causes of esotropia are thyroid-related eye disorders, brain disorders, poor vision, glaucoma and premature birth. Other possible causes can include conditions like diabetes or hyperthyroidism, vascular issues, childhood cataracts, amblyopia and hyperopia. These esotropia causes may not directly produce esotropia. The esotropia causes and their definitions are listed below.
* Thyroid-related eye disorders: Thyroid-related eye disorders may be a factor in developing esotropia due to the occurrence of fibrosis in the extraocular muscles.
* Brain disorders: Brain disorders may contribute to esotropia due to their impact on nerves in the brain that are responsible for eye movement and position.
* Poor vision: Poor vision may be a risk factor for esotropia as one or both eyes may overcompensate in order to maintain clear vision.
* Glaucoma: Glaucoma may occur along with esotropia or as a result of glaucoma surgery.
* Premature birth: Premature birth may pose a risk of developing esotropia as a result of weak eye nerves or eye muscles.
* Conditions like diabetes or hyperthyroidism: Conditions like diabetes or hyperthyroidism may lead to esotropia as they can affect certain parts of the eye.
* Vascular issues, including strokes: Vascular issues, including strokes, may cause esotropia as interrupted blood circulation may lead to serious medical problems including esotropia.
* Childhood Cataract: Childhood cataracts may lead to esotropia due to impaired vision.
* Amblyopia: Amblyopia may occur when vision fails to develop properly from a young age.
* Hyperopia: Hyperopia may be a strong factor in developing esotropia due to poor vision in one eye.
### 1. Thyroid-Related Eye Disorders
Thyroid-related eye disorders may be a factor in the development of esotropia as it can affect the muscles in the orbit of the eye. Thyroid-related eye disorder, also referred to as thyroid eye disease, causes inflammation in the eye and its surrounding tissues as a result of an autoimmune reaction. As a result of swelling of the extraocular muscles, eye movement may be limited and lead to misalignment according to the American Academy of Ophthalmology. According to a 2020 paper published in the Journal of Current Ophthalmology, esotropia may develop in 15% of all patients with thyroid eye disease.
### 2. Brain Disorders
Brain disorders such as cerebral palsy, hydrocephalus and brain tumours may be present when strabismus occurs. According to the American Orthoptic Journal, it is common to find patients with cerebral palsy to also have esotropia. Cerebral palsy is a group of disorders that can affect how the body moves and the ability to control balance and posture. Hydrocephalus is a neurological disorder that causes an unusual buildup of fluid in the brain. This may induce esotropia as the nerves that are responsible for eye position and movement can be damaged, prompting misalignment of the eyes.
### 3. Poor Vision
Poor vision may lead to esotropia due to prolonged eye focus on objects in order to have clear vision. Poor vision such as farsightedness may trigger esotropia as the eye muscles may have to exert more effort in order to maintain clear vision of objects up close, leading to the inward turn of one or both eyes. Farsightedness is characterised as a refractive error that results in having poor near vision.
### 4. Glaucoma
Glaucoma may also be present when some esotropia cases occur or glaucoma surgery may lead to the development of esotropia. In paediatric cases, patients who also have glaucoma in addition to esotropia may be easier to treat compared to adults who also have these conditions. According to a 2017 paper on Strabismus Associated with Glaucoma and Glaucoma Surgery, in these cases of strabismus, esotropia is the most common form to occur. It is typically sensory and a consequence of amblyopia, sensory esotropia can occur due to poor vision in one eye. [Glaucoma](https://www.oscarwylee.com.au/glasses/eye/glaucoma) is defined as an eye disease that can lead to vision loss due to optic nerve damage.
### 5. Premature Birth
Premature birth may pose a higher risk of developing eye diseases that can lead to visual impairing and non-visual impairing conditions including esotropia. Premature birth is when a baby is born before the completion of 37 weeks of pregnancy. In a 2015 study of 966 infants, 141 of them had strabismus at the age of 2 and 80% of those cases had esotropia. Premature birth may increase the risk of esotropia due to poor growth of eye nerves or eye muscles. Children with either esotropia or exotropia were found to be at an increased risk of having impaired fixation ability, visual field deficit, cerebral palsy, impaired ability to walk, low mental development index and a low physical development index when compared to their peers without strabismus.
### 6. Conditions Like Diabetes or Hyperthyroidism
Conditions like diabetes or hyperthyroidism may lead to esotropia due to their implications in the eye. Diabetes and hyperthyroidism may be considered as endocrine or hormone problems according to the Diabetes Journals. Endocrine problems may manifest symptoms in the eye and tissues in the orbital area according to a 2021 paper on Ocular Manifestations of Endocrine Disorders. Diabetes particularly may factor in the development of esotropia as it can be common for patients to experience a lack of circulation, leading to paralytic strabismus according to Riverside Health System. Esotropia can also be a consequence of nerve damage caused by diabetes according to the Cleveland Clinic.
### 7. Vascular Issues, Including Strokes
Vascular issues including strokes may cause esotropia among other optic issues in adults. According to Stanford Medicine, adults may be susceptible to esotropia as a result of eye or blood vessel damage. Vascular issues are defined as a condition that can affect the circulation of blood to parts of the body excluding the brain and heart. In a study of 519 patients who experienced the onset of a stroke, 19% of them were found to have strabismus after a full orthoptic assessment according to the Nature Journal. A stroke is a medical emergency that occurs when the brain's blood supply is impeded and can cause further medical complications including eye problems.
### 8. Childhood Cataracts
Childhood cataracts may be a strong factor in the occurrence of esotropia especially after surgery for cataracts. Childhood cataracts occur when the lens of the eye becomes cloudy and occurs at a young age. According to the National Library of Medicine, [childhood cataracts](https://www.oscarwylee.com.au/glasses/eye/childhood-cataracts) have an increased association with strabismus and more so post surgery. An evaluation of paediatric patients' medical reports from 2000 to 2011 found that children who acquired strabismus underwent cataract surgery when they were younger compared to children who did not have strabismus.
### 9. Amblyopia
Amblyopia may occur along with esotropia as poor vision in one eye may cause the weaker eye to turn inward. Esotropia may occur as a result of amblyopia due to the poor development of proper eye alignment during childhood. Esotropia and [amblyopia](https://www.oscarwylee.com.au/glasses/eye/lazy-definition) are commonly associated with each other, however, esotropia differs as it is an issue with eye alignment and amblyopia is characterised as a vision problem in one eye.
### 10. Hyperopia
Hyperopia may potentially lead to esotropia due to excessive eye focusing required to maintain clear vision. [Hyperopia](https://www.oscarwylee.com.au/glasses/eye/hyperopia) is also known as farsightedness, which may lead to esotropia if left untreated. Accommodative esotropia in particular can increasingly occur in farsighted patients during childhood according to the Web MD. Hyperopia occurs when you can only see objects in the far distance but have difficulty seeing objects up-close.
Find an Oscar Wylee Store Near You
Our team is dedicated to eye care and providing excellent services to our customers!
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
## What are the Symptoms of Esotropia?
The symptoms of esotropia are squinting, blurry vision, diplopia, unsynchronised eyes and depth-perception issues. It is important to note that some esotropia symptoms are the same across other eye conditions. Therefore, it is important to have your eyes checked by an optometrist to get a proper diagnosis. The possible esotropia symptoms and their definitions are listed below.
* Squinting: Squinting is a possible symptom of esotropia and can occur as a result of misaligned eyes.
* Blurry Vision: Blurry vision may occur as a consequence of esotropia due to excessive eye focusing.
* Diplopia: Diplopia can occur as the brain receives two visual images from misaligned eyes.
* Unsynchronised Eyes: Unsynchronised eyes can refer to the inability of the eyes to move together.
* Depth Perception Issues: Depth perception issues can be a common symptom of esotropia due to the eyes' inability to look at the same image with both eyes.
### 1. Squinting
Squinting is a potential symptom of esotropia that can occur due to misaligned eyes and may develop in order for the individual to see better. Squinting is the act of partially closing one's eyes in order to see more clearly.
### 2. Blurry Vision
Blurry vision may arise in adult esotropia cases as the eyes may be required to exert more eye-focusing effort to be able to see better. Blurry vision can be described as images that are not sharp or clear.
### 3. Diplopia
Diplopia can develop as esotropia can cause the eyes to see two images due to the misalignment of the eyes. [Diplopia](https://www.oscarwylee.com.au/glasses/eye/double-vision) may likely occur during esotropia as both eyes require innervation of every eye muscle in order to maintain proper alignment according to the American Academy of Ophthalmology. Diplopia is characterised as seeing two images of the same object and has two classifications known as monocular and binocular diplopia.
### 4. Unsynchronised Eyes
Unsynchronised eyes can refer to the eyes' inability to see and move together when looking at objects. It is a common and distinctive symptom of esotropia and may need to be further examined by an eye care professional.
### 5. Depth-Perception Issues
Depth-perception issues may be brought on as a consequence of esotropia since the eyes are turned inward and are not coordinated. Depth perception is defined as the ability to see in three dimensions; length, width and depth and the capability to discern the distance of an object.
## How Do Eye Doctors Diagnose Esotropia?
[Eye doctors](https://www.oscarwylee.com.au/glasses/eye/doctors) may diagnose esotropia by first asking what you and your family's medical history is like and then carrying out different physical tests. It is important to note that in Australia, optometrists are not considered eye doctors, as eye doctors are those with medical degrees and a specialisation in eye care. However, they are fully capable of diagnosing eye conditions including esotropia. The series of tests that follow includes asking what you and your family's medical history is and carrying out different physical tests such as a visual acuity test, refraction, dilated pupil exam and an alignment and focus assessment. A visual acuity test will involve reading letters from a chart on a wall. A refraction will involve examining the eyes with different corrective lenses to check how light is focused and the dilation exam will enable the optometrist to further assess the health of the eye's internal components. This all may take up to half an hour or an hour as it is a comprehensive eye test and is intended to ensure there are no problems with your vision.
##### What is the Difference Between Esotropia and Exotropia?
The difference between esotropia and exotropia is the direction the eyes turn. Esotropia causes the inward turning of the eyes, while exotropia is the outward deviation of the eyes. Both [esotropia](https://www.oscarwylee.com.au/glasses/eye/intermittent-exotropia) and [exotropia](https://www.oscarwylee.com.au/glasses/eye/intermittent-exotropia) share similar causes, including eye muscle weakness, genetics, conditions like a stroke and poor vision. Additionally, both can be treated with the same methods of prescription glasses and eye surgery.
## FAQs About Esotropia
Show All
### How Serious is Esotropia?
Esotropia may be serious if it is constantly present, however, misalignment may stop on its own if it occurs intermittently. It is strongly recommended to see an optometrist if you or your child suddenly experiences misalignment of the eyes.
#### Is Esotropia Contagious?
No, esotropia is not contagious, as it is an eye condition and not a viral or bacterial disease that is transmissible simply by contact. It does have genetic links and, therefore, may be inherited.
#### Is Esotropia Permanent?
Yes and no, esotropia can be permanent if in the constant form, left untreated and may progress as amblyopia as the brain may gradually disregard relying on the weaker eye. However, if the esotropia is intermittent, it may resolve on its own or respond well to treatment.
## How is Esotropia Treated?
Esotropia may be treated by prescribing glasses, prism glasses or surgery, depending on the severity of the condition. Prescription glasses may likely be the most suitable and effective treatment for accommodative esotropia. For constant or non-accommodative esotropia, surgery or botulinum toxin injection may be recommended.
### How Long Does it Take to Treat Esotropia?
Esotropia may take three to six months to treat, depending on how early it is detected. According to the Mayo Clinic, children with this condition should be treated before the age of 9 to prevent permanent vision loss.
#### Does Esotropia Require Eye Surgery?
Yes and no, esotropia may require surgery if it occurs in infants; however, adults can also have surgery performed and if it is not affected by prescription glasses. Cases of congenital esotropia among infants less than five months old may not require any treatment at all, according to the Cleveland Clinic.
#### Can Eyeglasses Fix Esotropia?
Yes, eyeglasses may fix esotropia, for accommodative, congenital/infantile, constant and intermittent cases, eyeglasses may likely be the first line of treatment unless advised otherwise by your optometrist.
#### Does an Eye Patch Help Treat Esotropia?
Yes, an eye patch may help treat esotropia as a non-invasive alternative to surgery, particularly for younger patients. It may aid vision, however, it may not correct misalignment. Your optometrist will be able to determine the most suitable treatment for your condition type, therefore it is important to seek assistance from them first.
#### Can Strabismus Eye Exercises Cure Esotropia?
Yes and no, [strabismus eye exercises](https://www.oscarwylee.com.au/glasses/eye/strabismus-and-eye-exercises) may be able to help treat esotropia, depending on the severity of your condition and type. This is also referred to as vision therapy and may include ocular workouts in an attempt to have both eyes look at the same object. However, it may not be able to completely cure esotropia.
#### Does Esotropia Require Eye Surgery?
Esotropia may only require eye surgery depending on the severity of your condition. If prescription glasses aren't effective, then surgical intervention may be recommended according to the American Association for Paediatric Ophthalmology and Strabismus.
Read Esotropia: Definition, Causes, Symptoms, Diagnosis, and Treatment in other Oscar Wylee regions and their languages.
Australia   
[Australia](https://www.oscarwylee.com.au/glasses/eye/esotropia)
[Canada](https://oscarwylee.ca/glasses/eye/esotropia)
[Canadian French](https://oscarwylee.ca/fr/lunettes/oeil/esotropie)
We Accept Major Health Funds at Oscar Wylee
Come in-store and our team will happily assist you in using your health fund to cover some of the cost of new frames.
[Health Fund](https://www.oscarwylee.com.au/health-funds.html)
Let Us Help You Stay Up To Date With Your Eye Tests!
Book your next optometry appointment online or with us in-store.
[Book an eye test](https://www.oscarwylee.com.au/booking)