# Source: https://www.oscarwylee.com.au/brody-optical.html

# Brody
1
## Frame Design of Brody Glasses
The frame design of Oscar Wylee’s Brody glasses is characterised by a rectangle shape, adjustable nose pads and an acetate and metal frame. Brody glasses are a men’s, essential frame that will work for any occasion.
$169    
In stock
Only %1 left
2 pairs from $199
Discount auto-applied at checkout
3 pairs from $249
Discount auto-applied at checkout
Qty
Add to cart
Book an eye test
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
excluding prescription lenses
## About Brody Frames
These classic, rectangular eyeglasses feature a full-rim silver metal
design. Accented with Oscar Wylee’s signature acetate tortoiseshell
arms. Brody is a great addition to our mens glasses range.
| Frame fit | Measurements |
| --- | --- |
| WIDE | 56 - 17 - 140 |
These measurements mean lens width, bridge, and temple length in
millimetres (mm). They can be found on the inside of the temple arm.
If you already have a pair that you like, you can compare it to these
measurements.
### Made from Acetate &amp; Metal
Oscar Wylee’s Brody frame is a men’s, rectangle glasses frame that is
perfect for wide faces and those with round and oval face shapes. The
Brody frame is a stylish, widely wearable frame that can be worn every
day. The main specs of Oscar Wylee’s Brody glasses frame including
dimensions, shape, materials, lenses, nose fit and hinges are
listed below.
| Brody Frame Features | Brody Frame Description | Dimensions | Shape | Materials | Lenses | Nose Fit | Hinges |
| --- | --- | --- | --- | --- | --- | --- | --- |
| The dimensions of the Brody frame are measured in millimetres (mm)
and are 56 - 17 - 140, meaning the lens width is 56 mm, the bridge
is 17 mm and the temple length is 140 mm. |
| The Brody frame is a rectangular frame shape, well suited to round
and oval faces. |
| Brody glasses are made from acetate and metal. |
| The lenses that can be used in the Brody frame are optical lenses,
which include single vision and multifocal lenses and
non-prescription lenses, which are plain and can have a filter
like a blue light filter applied. |
| Brody glasses are fitted with adjustable nose pads. |
| The hinges in Brody frames are spring hinges, which are more
flexible than other types of hinges and can extend past 90
degrees. |
Show All
### What Inspired the Frame Design of Oscar Wylee’s Brody
Glasses?
The Oscar Wylee Brody frame design was inspired by current fashion
trends as rectangle shapes are a must-have for those who are
looking for a timeless glasses frame.
## What to Know About Oscar Wylee’s Brody Glasses?
There are many aspects of the Oscar Wylee Brody frames that
customers should know about, so they can decide whether this is
the right frame for them. The Brody frame is a
[men’s glasses frame at Oscar Wylee](https://www.oscarwylee.com.au/glasses/collection/mens-glasses.html)
that is rectangle-shaped. Oscar Wylee’s Brody frame is
suitable for many face shapes but particularly compatible with
round and oval face shapes. The Brody frame’s classic design
means that they are fashionable all year round. Brody glasses
feature the standard
[parts of glasses](https://www.oscarwylee.com.au/glasses/eye/part-of-glasses)
such as a rim, temples, lenses, spring hinge and nose pads.
[Women’s glasses](https://www.oscarwylee.com.au/glasses/collection/womens-glasses.html)are also available at Oscar Wylee.
### What are the Types of Temple Tips or Earpieces Included
with Oscar Wylee’s Brody Glasses?
The type of temple tips or earpieces included in Oscar Wylee’s
Brody Glasses are made from acetate and the temples are made from
cupronickel.
### What Type of Nose Bridge do Oscar Wylee’s Brody Glasses
Have?
The type of nose bridge included in Oscar Wylee’s Brody frame is
nose pads.
### What Type of Nose Pads are Included with Oscar Wylee’s
Brody Glasses?
Oscar Wylee’s Brody frame includes standard nose pads. Nose pads
are great for comfort and can also be adjusted for the perfect
fit.
### What Type of Lenses do Oscar Wylee’s Brody Glasses
Have?
The type of lenses that typically come with the Oscar Wylee Brody
[glasses frame are optical lenses. Optical lenses are
glasses lenses that have a prescription within the lens to help
correct vision issues such as myopia, hyperopia and astigmatism.
Brody glasses can also come with non-prescription lenses, with
add-ons such as a blue light filter. Brody frames are currently
unavailable as sunglasses online, however, customers can
customise in-store and add on tint or polarisation.](https://www.oscarwylee.com.au/glasses.html)
### What Material is Used for the Rim of Oscar Wylee’s
Brody Glasses?
The material used for the rim of Oscar Wylee’s Brody glasses
frames is stainless steel. The rim refers to the part of a glasses
frame that holds the lenses.
### What Type of Hinges are Included with Oscar Wylee’s
Brody Glasses?
The type of hinges included with Oscar Wylee’s Brody frames are
spring hinges, A spring hinge in a glasses frame refers to hinges
that are more flexible than normal hinges and can go slightly
beyond 90 degrees. Spring hinges can provide a closer fit to the
face.
## What Face Types are Most Suitable for Oscar Wylee’s
Brody Glasses?
The face types most suitable for Oscar Wylee’s Brody frame
are round and oval face shapes. The Brody frame is a rectangle
shape, meaning that it complements the structure of round and oval
shapes particularly well. The rectangle Brody frames help to
balance the features of a
[round face shape](https://www.oscarwylee.com.au/glasses/face-shapes/round)
and an
[oval face shape](https://www.oscarwylee.com.au/glasses/face-shapes/oval), bringing the eyes and brows forward in a flattering way.
[Rectangle glasses at Oscar Wylee](https://www.oscarwylee.com.au/glasses/silhouette/rectangle.html)
help to flatter round and oval face types creating a pleasing
visual contrast between sharp angles and rounded features
highlighting without overemphasising them. Although there are many
[glasses for face shapes](https://www.oscarwylee.com.au/glasses/face-shapes)
that may be considered more aesthetically suitable, it is
important that people also choose the frames that make them feel
most comfortable, and represent their personal style. There are
also[rectangle sunglasses available at Oscar Wylee](https://www.oscarwylee.com.au/sunglasses/silhouette/rectangle.html).
## What Size Options are Available for Oscar Wylee’s Brody
Glasses?
The size options available for Oscar Wylee’s Brody frame are a
wide-frame fit across all colours.
## What Materials are Used to Create Oscar Wylee’s Brody
Glasses?
The primary materials used to create the Oscar Wylee Brody frame
are acetate and metal. The material used for the nose bridge and
temples is cupronickel. Acetate, also known as cellulose acetate,
is a bioplastic, made from cotton fibres or wood pulp. At Oscar
Wylee, acetate glasses are made by adding a dye to cellulose
acetate, which is rolled into a sheet. The shape of the glasses is
then cut from this sheet.
## What’s Included
## What's Included
Each pair of glasses comes with a stylish frame case and lens cloth. We offer free shipping across Australia and 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects.
* Free Shipping for Australian Orders
* 1 Year Warranty on frames and lenses
* Scratch resistance lens coating on all prescriptions
* UV-proof coating on all prescriptions
* Stylish case and cloth
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
## Make and Materials
The frames then go through cleaning and strict quality control, and many pairs of crafting hands to be hand-assembled and polished. After your frames have gone through the production process, they are individually examined and&nbsp;packed before making their way to you!Our frames go through numerous stages of production and are hand-polished to ensure a glorious lustre. Featuring a mix of high-quality acetate and polished metal, these mixed materials frames are sure to enhance your eyewear collection.
## Warranty Information
### Warranty Information
### Warranty Information
Oscar Wylee provides a 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects. We will repair or replace faulty or defective frames or lenses free of charge for warranty claims made within 1 year of the delivery. We also offer repairs or replacement for problems experienced with vision during everyday use for claims made within 30 days of delivery. If the same product has been discontinued or is no longer available, then we may offer an exchange for a similar product or a refund.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Find a Store Location](https://www.oscarwylee.com.au/locations/full-store-list.html)
Recommended
1. [](https://www.oscarwylee.com.au/crane-optical.html)
[Crane](https://www.oscarwylee.com.au/crane-optical.html)
Satin Orion Grey
2. [](https://www.oscarwylee.com.au/aerin-optical.html)
[Aerin](https://www.oscarwylee.com.au/aerin-optical.html)
Gold