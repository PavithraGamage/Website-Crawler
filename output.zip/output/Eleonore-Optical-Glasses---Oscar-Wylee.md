# Source: https://www.oscarwylee.com.au/eleonore-optical.html

# Eleonore
1
## Frame Design of Eleonore Glasses
The frame design of Oscar Wylee’s Eleonore glasses is characterised by their oval and round shape, low nose bridge fit and TR90 frame. Eleonore is a kid’s staple glasses frame that will complement any outfit, day to night.
$169    
In stock
Only %1 left
2 pairs from $199
Discount auto-applied at checkout
3 pairs from $249
Discount auto-applied at checkout
Qty
Add to cart
Book an eye test
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
excluding prescription lenses
## About Eleonore Glasses
Meet Eleonore, your new best friend that you can take with you everywhere! Perfect for your little ones, the frame has no metal parts, latex free and hypoallergenic materials, ear grips, neck band and a completely flexible hinge, making it the most kid-proof frame we sell.
| Frame fit | Measurements |
| --- | --- |
| X-SMALL | 43 - 16 - 130 |
These measurements mean lens width, bridge, and temple length in millimetres (mm). They can be found on the inside of the temple arm. If you already have a pair that you like, you can compare it to these measurements.
### Made from TR90
Oscar Wylee’s Eleonore frame is a kid's oval and round glasses frame that is perfect for those with square, oval, heart, pear and diamond shapes. The Eleonore frame is a timeless frame that can be worn every day. The main specs of Oscar Wylee’s Eleonore glasses frame, including dimensions, shape, materials, lenses, nose fit, and hinges, are listed below.
| Eleonore Frame Features | Eleonore Frame Description | Dimensions | Shape | Materials | Lenses | Nose Fit | Hinges |
| --- | --- | --- | --- | --- | --- | --- | --- |
| The dimensions of the Eleonore frame are measured in millimetres (mm) and are 43 - 16 - 130, meaning the lens width is 43 mm, the bridge is 16 mm, and the temple length is 130 mm. |
| Eleonore is an oval and round shape, well-suited to extra small faces. |
| Eleonore is made from TR90. |
| The lenses that can be used in the Eleonore frame include optical lenses, such as single-vision and multifocal, and non-prescription lenses, which are plain and can have a filter, such as a blue light filter, applied. |
| The nose fit for Eleonore is characterised by a low nose bridge. |
| The hinges in Eleonore are flexi hinges, which are more flexible than regular hinges for accident-prone children. |
Show All
### What Inspired the Frame Design of Oscar Wylee’s Eleonore Glasses?
The Oscar Wylee Eleonore frame design was inspired by current fashion trends, as oval and round glasses are a timeless style.
## What to Know About Oscar Wylee’s Eleonore Glasses?
There are many aspects of the Oscar Wylee Eleonore frames that customers should know about to decide whether this is the right frame for them. The Eleonore frame is a kid’s, oval and round -shaped frame. Oscar Wylee’s Eleonore frame is suitable for many face shapes, but particularly compatible with square, oval, heart, pear and diamond face shapes. The Eleonore frame’s simple design makes them fashionable all year round. Eleonore features the standard [parts of glasses](https://www.oscarwylee.com.au/glasses/eye/part-of-glasses), such as a rim, temples, lenses and flexi hinges.
### What are the Types of Temple Tips or Earpieces Included with Oscar Wylee’s Eleonore Glasses?
The type of temple tips or earpieces included in Oscar Wylee’s Eleonore Glasses are made from TR90.
### What Type of Nose Bridge do Oscar Wylee’s Eleonore Glasses Have?
The type of nose bridge included in Oscar Wylee’s Eleonore frame is characterised by a low nose bridge fit.
### What Type of Nose Pads are Included with Oscar Wylee’s Eleonore Glasses?
Oscar Wylee’s Eleonore frame does not include adjustable silicone nose pads.
### What Type of Lenses do Oscar Wylee’s Eleonore Glasses Have?
The type of lenses that typically come with the Oscar Wylee Eleonore [glasses frame](https://www.oscarwylee.com.au/glasses.html) are optical lenses. Optical lenses are glasses lenses that have a prescription within the lens to help correct vision issues such as myopia, hyperopia, and astigmatism. Eleonore frames also come as sunglasses, and with non-prescription lenses and add-ons such as a blue-light filter. Eleonore frames can be customised into sunglasses in-store or online with add-on tints or polarisation.
### What Material is Used for the Rim of Oscar Wylee’s Eleonore Glasses?
The material used for the rim of Oscar Wylee’s Eleonore glasses frames is TR90. The rim refers to the part of a glasses frame that holds the lenses.
### What Type of Hinges are Included with Oscar Wylee’s Eleonore Glasses?
The type of hinges included with Oscar Wylee’s Eleonore frames are flexi hinges. The hinges in Eleonore are flexi hinges, which are more flexible than regular hinges for accident-prone children.
## What Face Types are Most Suitable for Oscar Wylee’s Eleonore Glasses?
The face types that are most suitable for Oscar Wylee’s Eleonore frame are square, oval, heart, pear and diamond face shapes. The Eleonore frame is a classic shape, meaning that they complement the structure of square, oval, and pear face shapes particularly well. The classic Eleonore frames help balance the features of [square face shapes](https://www.oscarwylee.com.au/glasses/face-shapes/square), [oval face shapes](https://www.oscarwylee.com.au/glasses/face-shapes/oval), [heart face shapes](https://www.oscarwylee.com.au/glasses/face-shapes/heart), [pear face shapes,](https://www.oscarwylee.com.au/glasses/face-shapes/pear) and [diamond face shapes](https://www.oscarwylee.com.au/glasses/face-shapes/diamond), bringing the eyes and brows forward in a flattering way. Although there are many [glasses for face shapes](https://www.oscarwylee.com.au/glasses/face-shapes) that may be considered more aesthetically suitable, it is important that people also choose frames that make them feel most comfortable and represent their personal style.
## What Size Options are Available for Oscar Wylee’s Eleonore Glasses?
The size options available for Oscar Wylee’s Eleonore frame are an X-small frame fit across all colours.
## What Materials are Used to Create Oscar Wylee’s Eleonore Glasses?
The primary material used to create the Oscar Wylee is TR90. TR90 is a thermoplastic material noted for its durability, flexibility, and lightweight nature.
## What’s Included
## What's Included
Each pair of glasses comes with a stylish frame case and lens cloth. We offer free shipping across Australia and 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects.
* Free Shipping for Australian Orders
* 1 Year Warranty on frames and lenses
* Scratch resistance lens coating on all prescriptions
* UV-proof coating on all prescriptions
* Stylish case and cloth
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
## Warranty Information
### Warranty Information
### Warranty Information
Oscar Wylee provides a 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects. We will repair or replace faulty or defective frames or lenses free of charge for warranty claims made within 1 year of the delivery. We also offer repairs or replacement for problems experienced with vision during everyday use for claims made within 30 days of delivery. If the same product has been discontinued or is no longer available, then we may offer an exchange for a similar product or a refund.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Find a Store Location](https://www.oscarwylee.com.au/locations/full-store-list.html)