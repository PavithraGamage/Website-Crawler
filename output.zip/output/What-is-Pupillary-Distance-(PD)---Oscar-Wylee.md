# Source: https://www.oscarwylee.com.au/eye-care/eye-test/what-is-pupillary-distance.html

# What Is Pupillary Distance?
At Oscar Wylee, we are dedicated to giving you the best eye care and products. When it comes to getting your glasses made, we need to know your pupillary distance (PD) so that the lens sits correctly over your eyes, giving you clear and comfortable vision.
## What is pupillary distance (PD)?
Pupillary Distance (PD) is the measurement in millimetres of the distance between the centre of each of your pupils. It is used to ensure that your lenses are positioned correctly to give you the best possible vision. PD measurements are important for people who wear glasses and will always be taken before you buy prescription eyewear. If you’re unsure about your PD measurement, visit an Oscar Wylee [store near you](https://www.oscarwylee.com.au/locations/full-store-list.html) and our friendly team can assist you.
## Binocular vs monocular pupillary distance
There are two kinds of pupillary distance measurements. One which measures the total distance between your pupils and the other is the two measurements between the centre of each pupil to the bridge of your nose.
### Binocular PD
Binocular PD is the total measurement between the pupils, as explained above.
### Monocular PD
Not all eyes are equally proportioned and one pupil could be a couple of millimetres further away from the nose bridge than the other. Monocular PDs are the two measurements between the centre of each pupil to the bridge of your nose. It is usually written with Right Eye first and Left Eye second: 30/31.
## What is the average pupillary distance (PD)?
While not everyone's pupillary distance is the same, there is usually a common range which they fall into.
* Male average: 64mm
* Female average: 62mm
* Adult average: 63mm
* Child average: 56mm
## Why does PD matter?
In order to make your eyeglasses custom to your face, we need to know the distance between your pupils. By knowing this difference we can make sure the optical centre of the eyeglass lens, which holds the clearest vision, sits directly in front of your pupil. Also, when ordering a new pair of prescription glasses or prescription sunglasses online, your PD value is required to place an order.
## How do I find my PD for glasses?
We do recommend getting your PD measured in-store by our optical dispenser. This can be done when you are being fitted for your new glasses using a pupillometer or PD metre.If that is not an option, you can also measure your pupillary distance at home using the guides provided below.
### How to measure your pupillary distance at home
Measuring your PD at home really comes in handy when you want to order prescription glasses online and already have your prescription but don’t know your PD. You can measure your own PD using a millimetre ruler and a mirror.
1. You will need a ruler, a mirror and torch (your phone will suffice).
2. At a distance of about 20cm away, look front on into the mirror.
3. Hold the ruler directly above your eyes and place it against your brows, making sure you keep your face front on to the mirror. Place your phone below your left eye, shining the light towards the mirror.
4. Close your right eye and align the ruler from zero to the centre of the light reflection in the left pupil.
5. Without moving your head or the ruler, open your right eye,close your left eye and move the light below your right eye. Read the millimetre line that lines up with the centre of the light reflection in your right pupil. This number represents your PD in millimetres.
6. Repeat the entire process a few times to get a consistent measurement.
### How to measure pupillary distance using old glasses
You can also measure your pupillary distance at home if you have an old pair of glasses, a non-permanent marker and torch as above.
1. Stand roughly 20 centimetres away from a mirror wearing your glasses.
2. Close one of your eyes and place the torch below the other.
3. With the other eye open, put a dot with the marker directly over the light reflection seen in the pupil of the open eye on the lens.
4. Without moving your head, repeat the previous step on your other eye so that you have two dots over each of your pupils.
5. Measure in millimetres the distance between these two dots on the lenses to get your pupillary distance.
### How to measure someone else’s pupillary distance
If measuring your own PD using a ruler or an old pair of glasses does not work for you, you can also get a friend to measure it for you.This can be done with both the ruler or the glasses method and simply following the same steps. The only difference is you can keep both eyes open in the measuring process, whilst your friend closes one eye at a time as per above.Make sure you are not looking at the friend’s open eye whilst measuring otherwise this will change the results of your PD.
### How to measure pupillary distance for reading glasses
If you need your PD measurement for prescription reading glasses, then you will need to know your Near PD which is calculated as 3-4 mm less than your Distance PD. For example:Distance PD: 62mm, Near PD: 62 - 3= 59mm
## Useful tips for measuring your PD
* If you are unable to get an accurate measurement yourself, have someone help you!
* Try to keep your face still and look straight ahead
* If you’re still unsure or want an accurate measurement of your PD, visit an Oscar Wylee store near you.
## What happens if my pupillary distance is off?
Getting the correct measurement for your PD is crucial - an incorrect PD can affect the lenses so that it can feel like you’re wearing someone else's glasses.An inaccurate PD can cause eye strain, headaches and blurry vision. That is why it is recommended that you come in person to get your PD measured by a professional. And for those who are only able to do it at home, it is important to measure multiple times to get the most accurate results possible.
## Does my PD change over time?
Your pupillary distance changes as you grow from a young child into an adult as the skull shape changes and gets bigger. But once you reach adulthood, it is very unlikely that your PD will change.
## Is my PD listed on my prescription?
No. In most cases, your PD will be measured after your [eye test](https://www.oscarwylee.com.au/eye-health/eye-test-info.html), when you have picked out your glasses and in the process of placing the order. The dispenser will measure your PD with a pupillometer. Your eye exam will include a test of your [visual acuity](https://www.oscarwylee.com.au/eye-care/eye-test/what-is-20-20-vision.html) to measure the sharpness and clarity of your eyesight.This pupillary distance measurement is then added to your order which will be available to reference the next time you buy a pair of glasses. Learn more about [understanding your prescription](https://www.oscarwylee.com.au/eye-test/how-to-read-your-eye-prescription).
## I’ve got my PD. What happens next?
Once you have your PD measurement, you can move on to buying your prescription glasses. If you also have your prescription, you can buy your glasses online. In-store at Oscar Wylee, we’ve got eyewear for every side of you. Come in and browse our [exclusive range of glasses](https://www.oscarwylee.com.au/glasses.html) and have fun trying on different styles and colours. When buying online, Oscar Wylee has a [face shape guide](https://www.oscarwylee.com.au/face-shape-guide.html) to help you pick your perfect pair.
## Do You Need Your PD Measured?
Visit us in store and our friendly staff can assist you.
All major health funds accepted in store.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
## Due for an eye test?
We recommend everyone has a complete eye examination at least once every two years.
Book yours today with Oscar Wylee.
[Book an eye test](https://www.oscarwylee.com.au/booking)