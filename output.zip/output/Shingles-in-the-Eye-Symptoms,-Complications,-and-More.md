# Source: https://www.oscarwylee.com.au/glasses/eye/shingles

# Shingles in the Eye: Definition, Symptoms, Complication, and Treatment
Published September 22nd, 2023
Updated on June 19th, 2024
Australia
[Australia](https://oscarwylee.com.au/glasses/eye/shingles)
[Canada](https://oscarwylee.ca/glasses/eye/shingles)
[Canadian French](https://oscarwylee.ca/fr/glasses/eye/shingles)
Shingles in the eye is a disease that can lead to the development of a
burning, painful and itchy rash and is typically caused by the
varicella-zoster virus, which is the same virus that leads to chicken pox.
Shingles of the eye can present symptoms such as a rash and blisters,
swelling in the eyelid, redness, burning, itching, light sensitivity and
blurry vision. Complications that may occur as a result of eye shingles
can include keratitis, conjunctivitis, and inflammation inside the eye,
leading to impaired vision and an increased risk of glaucoma. Treating
shingles in the eye may involve prescribing antiviral medication or
anti-inflammatory eye drops.
How is Your Vision?
If you are worried about the quality of your vision, book a bulk-billed
eye test with Oscar Wylee today.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Definition](#definition) [Symptoms](#symptoms)
[Complications](#complications)
[Treatment](#treatment)
## What are Shingles in the Eye?
Shingles in the eye are defined as a&nbsp;viral infection that can cause swelling of the eye and rashes around
the eye, body, sides of the face, nose and forehead. Shingles may appear as red or pink blotches and may be caused by
the varicella zoster virus according to Health Direct. Shingles may
initially feel like a burning or tingling sensation around the body as
the first most noticeable symptom. Other common early signs of
shingles can include a low fever, flu-like symptoms, headache and a
fever.
### What is the Other Term for Shingles in the Eye?
The other term for shingles in the eye is&nbsp;herpes zoster ophthalmicus or ophthalmic zoster&nbsp;according to the National Institute of Health.
## What Causes Shingles in the Eye?
The causes of shingles or herpes zoster in the eye&nbsp;can be due to the preexisting latent varicella-zoster virus in people
who previously experienced chicken pox&nbsp;according to the National Library of Medicine. However, it is
important to note that not every person with the inactive virus will
develop shingles. The reactivation of the virus can occur as a result
of the body’s declining cellular ability to decimate infected cells,
which can take place due to increased age and other factors.
### Does Wearing Contact Lenses Cause the Shingles in the Eye?
No, wearing contact lenses&nbsp;may not cause shingles in the eye as herpes
zoster ophthalmicus develops from the virus that is present in
people who have previously contracted chicken pox&nbsp;and other circumstantial factors. Proper daily care of your contact
lenses can help prevent the development of any eye infections.
### Are Age and Gender a Factor that May Cause Shingles in the Eye?
Yes, age and gender may be factors that cause shingles in the
eye&nbsp;due to the body’s declining ability to protect
itself against infections.&nbsp;Shingles were found to be present in those aged 65 years and
older according to a 2012 analysis of 134 herpes zoster ophthalmicus
cases within the Kaiser Permanente Hawaii health plan.&nbsp;The incidence rate of shingles in the eye between men and women
exhibited that it&nbsp;occurred more in men than in women. However, it occurred more in
women who were older&nbsp;according to a 2021 study in the National Library of
Medicine.
### What Part of the Eye Does Shingles in the Eye Occur?
Shingles in the eye may occur in&nbsp;the eyelid and surrounding areas.&nbsp;Shingles may occur in front of the eye&nbsp;leading to keratitis which is a common complication of
shingles according to Harvard Health Publishing. In rare cases,
shingles may also develop in the back of the eye in relation to the
optic nerve and the retina. However, this type of shingles in the
eye is referred to as viral retinitis and does not manifest as a
skin rash but instead may cause inflammation and an infection in the
retina. Other regions where shingles in the eye can occur include
the forehead, scalp and nose.
### What are the Risk Factors of Shingles in the Eye?
The risk factors of shingles in the eye can include&nbsp;advanced age,&nbsp;previously contracted chicken pox and a poor immune system. The risk factors of shingles in the eye are listed below.
* Advanced Age:&nbsp;Advanced age may be a risk factor for shingles
in the eye as the immune system’s cellular response to infections
grows weaker with increased age.
* Previously Contracted Chicken Pox:&nbsp;Previously having chicken pox can lead to the development of
shingles in the eye due to the varicella-zoster virus going
dormant and remaining in the nerve tissues.
* Poor Immune System:&nbsp;A poor immune system can contribute as a risk factor for shingles
in the eye as the dormant virus can reactivate.
## What are the Early Signs That Someone Might be Developing Shingles in
the Eye?
The early signs that someone might be developing shingles in the eye
are&nbsp;burning, tingling and pain, sensitivity to touch,
fever, and a red rash. These early stages of shingles in the eye are the most common. If
you experience any of these symptoms, it is important to seek medical
attention right away. Other early signs of how to tell if you have
shingles in your eye can include aching muscles, tiredness, headaches,
nausea and general unwellness according to Healthline. The early signs
that someone might be developing shingles in the eye are listed
below.
* Burning, Tingling and Pain: Burning, tingling and pain may commonly occur in the region where
the rash may likely develop. This can take place 1-2 days before the
rash develops and has often been characterized by an electrical
sensation or feeling, according to the American Academy of
Dermatology Association.
* Sensitivity to Touch:&nbsp;Sensitivity to touch can be described as the occurrence of pain,
sharpness or stinging when touched. This may occur during the early
stages of shingles in the eye before the rash appears.
* Fever:&nbsp;A fever might occur in the early stages of developing shingles in
the eye due to the herpes zoster virus reactivating in the body. A
fever is how the body responds in an attempt to fight off the
infection.
* Red Rash:&nbsp;A red rash can start to develop soon after the burning, tingling
and painful sensations occur. The rash can then progress into a rash
of painful blisters and scabbing.
### What are the Signs and Symptoms of Shingles in the Eye?
The signs and symptoms of shingles in the eye can include&nbsp;blurry vision, eye redness, irritation or
tearing, skin redness or rash around the eye. It can also include&nbsp;blisters around the upper eyelid and forehead on one side, burning,
throbbing, or itching around the eye and extreme skin
sensitivity.&nbsp;The signs and symptoms of shingles in the eye are listed
below.
* Blurry Vision:&nbsp;Blurry vision can occur as a symptom of shingles in the eye as it
may also implicate some nerves of the head, which can cause the
infection to spread to the eyelid, the surface of the eye and
inner structures of the eye according to Harvard Health
Publishing.
* Eye Redness, Irritation or Tearing:&nbsp;Eye redness, irritation or tearing may develop as symptoms of
shingles in the eye when the infection reaches regions of the
eye.
* Skin Redness or Rash Around the Eye:&nbsp;Skin redness or a rash around the eye can
develop as a symptom before the progression of blisters.
* Blisters Around the Upper eyelid and One Side of the
Forehead:&nbsp;Blisters around the upper eyelid and one side of the forehead can
develop shortly after the initial pain,&nbsp; burning and tingling
sensation during the early stages of shingles in the eye.
* Burning, Throbbing, or Itching Around the&nbsp;Eye:&nbsp;Burning, throbbing or itching around the eye
can occur as a symptom of shingles in the eye as onset symptoms
before skin redness, rashes and blisters occur.
* Extreme Skin Sensitivity:&nbsp;Extreme skin sensitivity can take place as a result of the
shingles infection and can be defined as pain or stinging when
affected areas of the skin are touched.
#### 1. Blurry Vision
Blurry vision may occur as&nbsp;a symptom of shingles in the eye due to affected nerves in the
head, causing the infection to reach the regions of the
eye.&nbsp;[Blurry vision](https://www.oscarwylee.com.au/glasses/eye/blurred-vision)&nbsp;can be defined as unclear vision that lacks details and
defined shapes.
#### 2. Eye Redness, Irritation or Tearing
Eye redness, irritation or tearing are&nbsp;common symptoms of shingles in the eye and can
develop when the infection reaches the regions of the eye.&nbsp;Eye redness can occur from the infection due to the eye’s
surface vessels enlarging. The eyes may experience&nbsp;[eye irritation](https://www.oscarwylee.com.au/glasses/eye/irritation-causes)due to the redness which leads to tearing.
#### 3. Skin Redness or a Rash Around the Eye
Skin redness or a rash around the eye is a&nbsp;common symptom of shingles in the eye and can develop after the
initial burning and pain&nbsp;that typically occurs in the early stages. Redness or a
rash around the eye is a common response due to inflammation from
the virus infection.
#### 4. Blisters Around the Upper Eyelid and One Side of the Forehead
Blisters around the upper eyelid and one side of the
forehead&nbsp;can develop from skin redness and a rash
around the eye.&nbsp;The blisters can appear as red or pink blotches of raised
bumps filled with fluid, this stage typically takes place after
redness and rashes start appearing on the skin.
#### 5. Burning, Throbbing, or Itching Around the Eye
Burning, throbbing or itching around the eye can often arise as early signs of shingles in the eye before the
appearance of redness and a rash
on the skin. Burning, throbbing or itching occurs where the rash
and blisters can likely develop. The symptom of burning can feel
like a sharp and hot sensation on the skin. Throbbing can be
characterized as a pulsing sensation on the skin.
#### 6. Extreme Skin Sensitivity
Extreme skin sensitivity&nbsp;may occur with shingles in the eye due to the varicella-zoster
infection causing an inflammatory response in the body.&nbsp;Extreme skin sensitivity may be described as pain or
stinging in the skin when touched.
##### How Often Does an Adult Experience Shingles?
An adult may only experience shingles&nbsp;once, however, it is possible for it to
reoccur. Shingles may typically occur around the age of 50 or older,
however, it is possible to contract shingles at any age
according to Health Direct.
## How are Shingles in the Eye Diagnosed?
Shingles in the eye may be diagnosed&nbsp;by looking at the rash around your eye, eyelid, scalp and body&nbsp;by a doctor or optometrist. They may also ask if you have
previously had chicken pox and will discuss your symptoms.
### What are the Eye Exams Needed to Diagnose Shingles in the Eye?
The eye exams needed to diagnose shingles in the eye may
be&nbsp;a slit lamp and ophthalmoscope.&nbsp;A slit lamp allows the optometrist to examine the inner
structures of the eye and the front of the eye. An ophthalmoscope,
also known as a fundoscopy, is a hand-held instrument that shines a
light through the pupil. This allows the optometrist to evaluate the
health of the back region of the eye.
### How Do Shingles Get into Your Eyes?
Shingles can get into your eyes&nbsp;if the varicella-zoster virus is triggered in the trigeminal nerve,
affecting the ophthalmic branch. The trigeminal nerve belongs to one set of cranial nerves and is
responsible for bringing sensation to the face. The three branches
of the trigeminal nerve are the ophthalmic, the maxillary and the
mandibular.
### What are the Potential Complications Associated with Shingles in the
Eye?
The potential complications associated with shingles in the eye
can&nbsp;include keratitis, cornea and retina swelling as
well as increased pressure in the eye.&nbsp;Keratitis symptoms can present as redness in the eye, tears or
discharge, pain and irritation and blurry vision. Swelling in the
cornea can bring on the sensation of having something in your eye
and cause pain and discomfort. Swelling in the retina may cause
distorted or blurry vision according to the National Eye
Institute.
#### Can Shingles in the Eye Lead to Permanent Vision Loss?
Yes, shingles can lead to permanent vision loss&nbsp;due to corneal scarring and damage to the retina. According to the National Library of Medicine, 1 in 10
individuals can experience moderate to severe vision loss,
however, this may be a result of corneal scarring.
#### Are There Any Long-term Effects of Shingles on Eye Health?
Yes, long-term effects of shingles can
include vision loss, scarring, the development of corneal blood
vessels, uveitis, corneal ulceration and perforation.&nbsp; It is important to seek treatment for shingles in the eye
to prevent long-term effects.
If you are experiencing any of these symptoms, it is strongly
advisable to seek urgent medical attention. The development of blood vessels in the cornea can occur due to
inflammation caused by an infection. Uveitis is characterized as
inflammation in the eye and can commonly develop due to an
autoimmune condition. Symptoms of uveitis may include floaters in
the eye, blurry vision, eye pain, vision loss and red eyes.
Corneal ulceration and perforation is the thinning of the cornea
caused by infection, which can lead to a rupture or a hole in the
cornea. Other causes of corneal ulceration and perforation include
keratitis, eye injuries, ocular surface diseases and autoimmune
abnormalities. Symptoms can include vision loss, pain and
excessive tears.
Qualified Optometrists at Every Store!
Our team of experts can assist you with any eye care advice you may
need.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
## What are the Treatments for Shingles in the Eye?
The treatments for shingles in the eye include&nbsp;antiviral medication, eye drops, pain medication and a cool
compress. The treatments for shingles in the eye are listed below.
* Antiviral Medication:&nbsp;Antiviral medication can be taken as a tablet or
in liquid form. It can help prevent the spread of the virus, reduce
the rash and mitigate pain from the rash.
* Eye Drops:&nbsp;Eye drops may be prescribed to help control inflammation, prevent
further complications in the eye and maintain moisture.
* Pain Medication:&nbsp;Pain medication may also be recommended to alleviate any symptoms
of pain.
* Cold Compress:&nbsp;Cold compress may be effective in easing itchiness, pain and
discomfort. You can apply a cold compress by using a cold damp hand
towel or a plastic bag with ice.
### How Treatable are Shingles in the Eye?
Shingles in the eye is&nbsp;effectively treated by using antiviral medication as it can aid
with delaying the further development of the virus and reduce
symptoms.&nbsp;However, it is important to begin treatment as soon as
possible.
### What is the New Treatment For Shingles in the Eye?
There is currently&nbsp;no new treatment for shingles in the eye. However, NYU Langone Health Medical Centre is currently
investigating new treatment processes for shingles in the eye
through clinical trials.
#### Can Eye Drops be Used in Treating Shingles in the Eye?
Yes, eye drops can be used in treating shingles in the eye
depending on the specific type and purpose.&nbsp;[Eye Drops](https://www.oscarwylee.com.au/glasses/eye/types-of-eye-drops#:~:text=Among%20the%20different%20types%20of,and%20anti%2Dredness%20eye%20drops.)&nbsp;that specifically target viruses may prove
effective in reducing symptoms of shingles in the eye&nbsp;and preventing the virus from progressing according to NVision
Centres.
## What are Ways to Prevent Shingles in the Eye?
A way to prevent shingles in the eye
may be to opt for the shingles vaccine as recommended by the Centers
for Disease Control and Prevention (CDC). The shingles vaccine may increase the chances of preventing the
development of shingles in the eye as it contains a weak form of the
varicella-zoster virus. Recombinant Zoster Vaccine, RZV is currently
the only vaccine authorized for use in Canada.
### Is the Shingles Vaccine Effective in Preventing Shingles in the Eye?
Yes, the shingles vaccine is&nbsp;considered highly effective in preventing shingles in the eye for
people aged 50 years and older. According to Medical News Today and the American Academy of
Ophthalmology, the Shingrix vaccine has been proven effective by
90%.
### Can Wearing Eye Glasses Help Prevent Shingles in the Eye?
No, wearing glasses may&nbsp;not help prevent shingles in the eye as it is
caused by the reactivation of the varicella-zoster virus. If you previously had chickenpox, the virus will be dormant and
present in the spinal nerve according to the Centers for Disease
Control and Prevention (CDC).
### Are Shingles in the Eye Contagious to Others?
No, shingles in the eye are&nbsp;not contagious to others, however, you may spread it to someone who
has never had chickenpox before. Therefore it is important to practise good hygiene habits and
avoid scratching or touching your rash.
Read Shingles in the Eye: Definition, Symptoms, Complication, and
Treatment in other Oscar Wylee regions and their languages.
Australia
[Australia](https://oscarwylee.com.au/glasses/eye/shingles)
[Canada](https://oscarwylee.ca/glasses/eye/shingles)
[Canadian French](https://oscarwylee.ca/fr/glasses/eye/shingles)
Oscar Wylee Accepts Major Health Funds
Contact or visit your nearest store for a full quote.
[Find a store](https://www.oscarwylee.com.au/health-funds.html)
Due For an Eye Test?
Oscar Wylee offers bulk billed eye tests, so there are no
out-of-pocket expenses for eligible Medicare cardholders.
[Book an eye test](https://www.oscarwylee.com.au/booking)