# Source: https://www.oscarwylee.com.au/guides/lenses/bifocal.html

# Bifocal Lenses: How It Works, Types and Alternatives
Published on August 19th, 2022
Updated on February 3rd, 2025
Australia
[Australia](https://www.oscarwylee.com.au/guides/lenses/bifocal.html)
New Zealand

[Canada](https://oscarwylee.ca/guides/lenses/bifocal.html)
[Canadian French](https://oscarwylee.ca/fr/guides/lenses/bifocal.html)
Bifocal lenses are glasses lenses which have two prescriptions in one lens correcting distance and near vision.
Bifocals can help those with hyperopia, astigmatism and myopia.
Bifocals glasses are designed to enable people to see both close-up and
far away without the need to swap between multiple glasses. They have
lenses that split into two segments containing two prescriptions. The
benefits of bifocals include convenience, versatility and
cost-effectiveness. The different types of bifocals are distinguished by
how the prescriptions sit within the lens and can include ribbon, round,
executive and flat top. Keep reading to learn more about bifocals.
Take Care of Your Eyes at Oscar Wylee
At Oscar Wylee we offer bulk billed eye tests for all eligible medicare
card holders.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Definition](#Definition) [Benefits](#Benefits)
[Types](#Types) [Vision Problems](#Problems)
## What are Bifocal Lenses?
Bifocal lenses are a type of glasses lens with two prescriptions in one lens, which
help to correct both near and far vision issues caused by refractive
errors. Bifocal glasses, often called bifocals, look like regular glasses
but have a line separating the two prescriptions in the lens. The
larger top area of the lens will contain the distance prescription
which can help you see far-away objects such as street signs and your
TV. The smaller area at the bottom will hold the near/reading
prescription, helping you do up-close activities such as reading and
knitting. Bifocals may not always have a hard line between two
prescriptions, sometimes the separation between the two is more
blurred. Bifocals can also have certain add-ons, such as an
anti-reflective or anti-glare coating, applied to the lenses.
### How do Bifocals Work?
Bifocals work by combining a prescription for near vision correction and a
prescription for distance vision correction, within one lens. A person uses bifocals by moving your eyes behind the lenses
according to the distance you wish to see. For example, if you are
reading a book, you look through the bottom part of the lenses to
see the words clearly. This minimises the need for a separate pair
of reading glasses as you can see up close and far away all in one
pair. Learn more about Oscar Wylee’s lens options and their prices
in our
[price guide](https://www.oscarwylee.com.au/price-guide/).
## What Are the Benefits of Bifocal Lenses?
The benefits of bifocal lenses include convenience, versatility and cost-effectiveness. The benefits of bifocals lenses are listed below.
* Convenience: Bifocals allow for
optimal convenience as it eliminates the need to carry multiple pairs
of glasses when out and about. This also allows for less clutter in
your handbags.
* Versatility: The versatility of bifocal lenses allows for easy transition
between near and far-sighted vision. This makes it the perfect
versatile accessory for a busy day out, requiring clear vision in
differing situations.
* Cost-effective: Bifocal lenses are cost-effective as the wearer does not have to
pay for two pairs of prescription glasses, and instead just pay for
one with bifocal lenses.
### What Is the Purpose of Bifocal Glasses?
The purpose of bifocal lenses is to correct vision for those who require both near and far
prescriptions. The two distinct lenses for distance and close-up vision are
particularly valuable for correction of conditions such as
presbyopia which affects near vision with age.
### How Are Bifocal Lenses Different From Single-Vision Lenses?
Bifocal lenses are different from [single-vision lenses](https://www.oscarwylee.com.au/glasses/eye/single-vision-lenses) as these contain one singular prescription on the lenses. Bifocal lenses on the other hand have two distinct prescriptions:
one for near distance and another for long distance. Bifocal lenses
will be more valuable for people who struggle with both near and
long-distance vision and find themselves in situations where both
are as important.
## What Are the Types of Bifocal Lenses?
The different types of bifocal lenses are distinguished by how the
two prescriptions sit within the lens. Some of the different types of
bifocal lenses include ribbon, round, flat top and executive. Some of the types of bifocal lenses are listed below.
* Ribbon: Ribbon bifocal lenses refer to
bifocals with the close-up prescription a long, thin, rectangular
shape at the bottom of the lens.
* Round:
Round bifocal lenses refer to bifocals in which the close-up
prescription is a circular shape at the bottom of the lens.
* Flat top: Flat top bifocals refer to bifocals in which the close-up
prescription is a D-shape, upside down, at the bottom of the lens.
At Oscar Wylee, the prescription in our bifocals are flat top
shaped.
* Executive: Executive bifocals will have the close-up prescription fill the
entirety of the bottom of the lens.
### Do All Bifocal Lenses Have a Line?
Not all bifocal lenses have a line.
Those without a line are called progressive or multifocal lenses and
instead have a progression of differing lens power from the top to
the bottom. This contrasts with line bifocals which are more common
as these have a visible line separating the two lenses.
Find an Oscar Wylee Store Near You
Come and visit your local Oscar Wylee store and our friendly staff can
assist you with your eye care needs.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
## How Do You Use Bifocal Glasses Correctly?
To use bifocal glasses correctly, position your eyes behind the part of the lenses according to the
distance you wish to see. Bifocal lenses have both a distance and near prescription divided
by a line across a centre. This will inform how to move your eyes to
see the clearest given the situation. For example, if you are reading
a computer screen you will want to look through the bottom part of the
lenses for near vision clarity.
### When Are Bifocal Lenses Prescribed?
When bifocals are prescribed will be up to an optometrist and their
patient's individual eye care needs. According to the Optometrists
Organisation, Bifocal lenses will typically be prescribed for adults with
presbyopia. However, they can also be prescribed to strengthen eye teaming, a
visual efficiency skill that allows both eyes to be coordinated and
reduces potential eye strain whilst reading.
#### Are Bifocal Lenses Still Used Today?
Yes, bifocal lenses are still used today. They are invaluable to
those who need visual clarity for both short and long distances,
making them still relevant and useful to wearers today. The
creation of progressive lenses has seen the ability for wearers to
have more than one glasses lens without the presence of a visible
line separating the lenses. The prescription of progressive lenses
is instead blended for a seamless transition between the two for
the wearer.
### What Are the Alternatives to Bifocal Lenses?
The alternatives to bifocal lenses can include glasses with a single prescription or progressive
lenses. Bifocals can correct myopia, hyperopia and astigmatism, by having
two prescriptions in the same lenses. An alternative to the two
prescriptions in one lens is to have single vision lenses, which
have one prescription within one lens, meaning a person would have
two separate pairs of glasses. Another alternative to bifocal lenses
is [progressive lenses](https://www.oscarwylee.com.au/glasses/eye/progressive-lenses), which are bifocals or trifocals in which the prescriptions within
the lenses are blended, as opposed to separated by a straight
line.
#### Can Bifocal Lenses Be Removed From Glasses?
Bifocal lenses can be removed from glasses if the whole lens is removed.
A person cannot remove the prescription from lenses. If a new
prescription is required, a person will typically need to get new
lenses.
### What Is the Difference Between Lined and No-Line Bifocals?
The differences between lined and no-line bifocals are both aesthetic and functional.
Aesthetically lined bifocals have a visible horizontal line
separating the two prescriptions whereas no-line bifocals do not.
This also differentiates their functionality slightly. Those wearing
lined bifocals will have to position their eyes above or below the
line to utilise either lens. Whereas no-line bifocals feature a
gradual progression into two lenses so you will have to adjust your
eyes to find the ideal lens without the line as a guide.
### Who Invented Bifocal Lenses?
Benjamin Franklin is credited for the invention of bifocal
glasses. According to History.com in a letter dated May 23rd, 1785 he
wrote of the invention: ‘I have only to move my eyes up or down, as
I want to see distinctly far or near, the proper glasses being
always ready.’
#### When Were Bifocal Lenses Invented?
Bifocal lenses were first invented by Benjamin Franklin in 1784. The most notable evolution in bifocal lenses would come in 1959
as engineer Bernhard Maietnaz patented the first commercially
successful progressive lens called ‘Varilux.’
### What Vision Problems Do Bifocal Lenses Correct?
The vision problems bifocals can help correct are myopia (nearsightedness), hyperopia
(farsightedness), presbyopia and astigmatism.
Myopia refers to a refractive error in which distance vision can be
blurry. Hyperopia is a refractive error generally affecting near
vision. Presbyopia is an age-related eye condition in which near
vision is blurry. Presbyopia is caused by the lens's natural ageing,
which makes it harder and less flexible. Astigmatism refers to a
refractive error that cancause blurry vision both up close and far
away. Bifocals correct these vision issues by having two
prescriptions in the one lens.
#### Are Bifocals and Reading Glasses the Same?
Both bifocals and reading glasses can help a person see close-up objects clearer, but they are not
the same eyewear. Bifocals are glasses with two prescriptions in one lens to
correct myopia and hyperopia.
[Reading glasses](https://www.oscarwylee.com.au/reading_glasses.html)
refer to glasses that are designed to help with close-up
activities like reading or writing. Reading glasses, like
bifocals, can have a prescription in them to help see up close
objects clearly. However, unlike bifocals, reading glasses just
have a singular prescription or purpose and will not also help
with distance vision.
Read Bifocal Lenses: How It Works, Types and Alternatives in other
Oscar Wylee regions and their languages.
Australia
[Australia](https://www.oscarwylee.com.au/guides/lenses/bifocal.html)
New Zealand

[Canada](https://oscarwylee.ca/guides/lenses/bifocal.html)
[Canadian French](https://oscarwylee.ca/fr/guides/lenses/bifocal.html)
Are You Due for an Eye Test?
We recommend that everyone has an eye test at least once every two
years or as recommended by an optometrist.
[Book an eye test](https://www.oscarwylee.com.au/booking)
Major Health Funds Accepted In-store
For the purchase of frames and lenses, use your private health fund
insurance to limit how much you pay from your own pocket.
[Explore Health Funds](https://www.oscarwylee.com.au/health-funds.html)