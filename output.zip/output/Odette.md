# Source: https://www.oscarwylee.com.au/odette-sunglass.html

[Skip to the end of the images gallery](#gallery-next-area)
[Skip to the beginning of the images gallery](#gallery-prev-area)
# Odette
1
Prescription
Choose your lenses
What do you use your glasses for?
Distance
For being able to see far away objects clearly. Distance glasses are ideal for activities such as driving and watching TV.                
Reading
For magnifying nearby objects. These are ideal for close-up activities such as reading books and working on the computer.                
Multifocal Lenses
For clarity in both distance and reading vision. Multifocal lenses are helpful for those who require a certain prescription strength for reading and a different prescription strength for distance.                    
We currently do not offer multifocal lenses for purchase online, as they require an in-store fitting. To complete an order with multifocal lenses, visit us at your nearest Oscar Wylee store.
[Find a location](https://www.oscarwylee.com.au/locations/full-store-list.html/)
Please note that we cannot accept expired prescriptions. If your prescription has expired, [book an eye test](https://www.oscarwylee.com.au/booking/) with us.        
Add your prescription
back
I’m an existing customer                        We'll use your prescription we have on file, or contact you if more info is needed.
We'll use your prescription we have on file, or contact you if more info is needed.                    
Upload a photo of it                        This is the quickest option!
Please upload an image (in jpg, png or pdf) of your prescription.                    
images over 800px high or wide, will be resized before saving
Send it to us later                        Email us your prescription after checkout.
You can send us your prescription by:
|
|
| Email:[[email&nbsp;protected]](/cdn-cgi/l/email-protection#026b6c646d426d71616370757b6e67672c616d6f) |
Don't forget to include your prescription and the email address that you will be entering during checkout step.
Have us call your optometrist                        We will get your prescription from your optometrist.
Have us call your optometrist
Enter in your optometrist’s information, and we’ll reach out to obtain your prescription information.
Patient’s full name
Patient’s date of birth
Optometrist’s business name
Optometrist’s phone number
Choose another method to add prescription
Lens Options
Your Lenses
Pupillary Distance (PD)                            
[What is Pupillary Distance?](https://dj3im2gm3txew.cloudfront.net/pub/media/catalog/PD_measurement_tool.pdf)
I have 2 PD values
Select your PD (Right)25.025.526.026.527.027.528.028.529.029.530.030.531.031.532.032.533.033.534.034.535.035.536.036.537.037.538.0                                    
Select your PD (Left)25.025.526.026.527.027.528.028.529.029.530.030.531.031.532.032.533.033.534.034.535.035.536.036.537.037.538.0                                    
Select your PD505152535455565758596061626364656667686970717273747576                                
I confirm that this information is correct.
Pupillary Distance (PD)                            
[What's Pupillary Distance?](https://dj3im2gm3txew.cloudfront.net/pub/media/catalog/PD_measurement_tool.pdf)
I have 2 PD values
Select your PD (Right)25.025.526.026.527.027.528.028.529.029.530.030.531.031.532.032.533.033.534.034.535.035.536.036.537.037.538.0                                    
Select your PD (Left)25.025.526.026.527.027.528.028.529.029.530.030.531.031.532.032.533.033.534.034.535.035.536.036.537.037.538.0                                    
Select your PD505152535455565758596061626364656667686970717273747576                                
I confirm that this information is correct.
### Lens Thickness
Standard                            1.5 index lens
Recommended for prescriptions for power +/- 3.00
INCLUDED                            
Extra Thin                            1.61 index lens
Recommended for prescriptions for power +/- 3.00 to +/- 4.00
+$110                    
Super Thin                            1.67 index lens
Recommended for prescriptions for power +/- 4.00 to +/- 5.00
+$160                    
Ultimate Thin                            1.74 index lens
Recommended for strong prescriptions, power higher than +/- 5.00
+$260                    
Sun Protection
800px 
Tinted Lenses
Tinted lenses for style and comfort
+$30
Grey
Category 3
Brown
Category 3
Green
Category 3
800px 
Gradient Tint Lenses
Lenses that are darker on top and lighter below
+$30
Grey
Category 2
Brown
Category 2
Green
Category 2
800px 
Polarised Lenses
Polarised lenses for enhanced clarity
+$100
Grey
Category 3
Brown
Category 3
Green
Category 3
800px 
Photochromic and Transitions® Lenses
Lenses that darken in sunlight
from
$100
Adaptive Lenses
Changes from clear to darker opacity to adapt to light conditions.                                    
+$100
Grey
Category 3
Transitions® Gen S™
Transitions® branded photochromic lenses, quickly change from clear to a darker opacity to adapt to light conditions.                                    
+$160
Grey
Category 3
Brown
Category 3
Ruby
Category 3
Sapphire
Category 3
Graphite Green
Category 3
Amethyst
Category 3
Emerald
Category 3
Amber
Category 3
ⓘ
What are Lens Categories?
* Filter category 2:
General purpose sunglasses. Good protection against sun-glare. Good UV protection. Not suitable for driving in twilight or at night or under dull conditions.
* Filter category 3:
General purpose sunglasses. High protection against sun-glare. Good UV protection. Not suitable for driving in twilight or at night or under dull conditions.
Lens Add Ons
None
Anti-Reflective*
Reduces annoying reflection
Improves cosmetic appearance
Scratch resistant hard coating
INCLUDED
Premium Anti-Reflective*
Highly recommended
Reduces annoying reflections for clearer vision
Scratch and smudge resistant, anti-static
Improves cosmetic appearance
Can reduce eye strain due to glare
+$10
*on the back of sunglasses lenses only            
Review Your Selections
Free domestic shipping with every order
Edit Selections
Discounts will be calculated at checkout
$169    
In stock
Only %1 left
2 pairs from $199
Discount auto-applied at checkout
3 pairs from $249
Discount auto-applied at checkout
* 2 &amp; 3 Pair pricing applies to non-prescription sunglasses only. Prescription sunglasses incur additional charges.    
[Non-Prescription](https://www.oscarwylee.com.au/odette-sunglass.html#)
Qty
Prescription
Book an eye test
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
excluding prescription lenses
## About the Frames
A soft rounded eye frame lends Odette a charmingly coveted look. Finished with custom cellulose acetate material. Flexible yet strong, and oh so loveable.
### Made from Acetate
Frame fitMedium
Measurements51 - 21 - 145
These measurements mean lens width, bridge, and temple length in millimetres (mm). They can be found on the inside of the temple arm. If you already have a pair that you like, you can compare it to these measurements.
Filter category 2 - General purpose sunglasses. Good protection against sunglare. Good UV Protection.Not suitable for driving in twilight, at night or under dull conditions
This frame comes with polarised lenses. An additional $100 will be added to your order total for prescription orders. 
## What’s Included
## What's Included
Each pair of glasses comes with a stylish frame case and lens cloth. We offer free shipping across Australia and 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects.
* Free Shipping for Australian Orders
* 1 Year Warranty on frames and lenses
* Scratch resistance lens coating on all prescriptions
* UV-proof coating on all prescriptions
* Stylish case and cloth
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
## Make and Materials
The frames then go through cleaning and strict quality control, and many pairs of crafting hands to be hand-assembled and polished. After your frames have gone through the production process, they are individually examined and packed before making their way to you!Also known as cellulose acetate, these frames are traditionally hand-crafted by skilled craftsmen, with each frame passing through numerous stages of production and are hand-polished to ensure a glorious lustre.
## Warranty Information
### Warranty Information
### Warranty Information
Oscar Wylee provides a 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects. 
We will repair or replace faulty or defective frames or lenses free of charge for warranty claims made within 1 year of the delivery.
We also offer repairs or replacement for problems experienced with vision during everyday use for claims made within 30 days of delivery. If the same product has been discontinued or is no longer available, then we may offer an exchange for a similar product or a refund.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Find a Store Location](https://www.oscarwylee.com.au/locations/full-store-list.html)
Recommended
1. [](https://www.oscarwylee.com.au/chamberlain-sunglasses.html)
[Chamberlain](https://www.oscarwylee.com.au/chamberlain-sunglasses.html)
Striped Buckeye