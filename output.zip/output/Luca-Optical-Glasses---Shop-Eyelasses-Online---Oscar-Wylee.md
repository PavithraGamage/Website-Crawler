# Source: https://www.oscarwylee.com.au/luca-optical.html

# Luca
1
## Frame Design of Luca Glasses
The frame design of Oscar Wylee’s Luca glasses is characterised by its oval/round shape and acetate frame. Luca glasses are a unisex, stylish frame that will work for any occasion, whether the wearer wants to liven up their everyday style or complement a fun outfit for a day out.
$169    
In stock
Only %1 left
2 pairs from $199
Discount auto-applied at checkout
3 pairs from $249
Discount auto-applied at checkout
Qty
Add to cart
Book an eye test
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
excluding prescription lenses
## About Luca Frames
This intriguing oval frame boasts spring hinges and a distinctive keyhole nose bridge. The perfect combo of comfort and style.
| Frame fit | Measurements |
| --- | --- |
| Medium | 51 - 20 - 145 |
These measurements mean lens width, bridge, and temple length in millimetres (mm). They can be found on the inside of the temple arm. If you already have a pair that you like, you can compare it to these measurements.
### Made from Acetate
Oscar Wylee’s Luca frame is a women’s oval and round glasses frame that is perfect for medium faces and those with square, oval or heart face shapes. The Luca frame is a stylish, widely wearable frame that blends well with your outfits or makes the perfect statement. The main specs of Oscar Wylee’s Luca glasses frame including dimensions, shape, materials, lenses, nose fit and hinges are listed below.
| Luca Frame Features | Luca Frame Description | Dimensions | Shape | Materials | Lenses | Nose Fit | Hinges |
| --- | --- | --- | --- | --- | --- | --- | --- |
| The dimensions of the Luca frame are measured in millimetres (mm) and are 51 - 20 - 145, meaning the lens width is 51 mm, the bridge is 20 mm and the temple length is 145 mm. |
| The Luca frame is a round shape, well suited to medium faces. |
| Luca glasses are made from a material called acetate. |
| The lenses that can be used in the Luca frame are optical lenses, which include single vision and multifocal lenses and non-prescription lenses, which are plain and can have a filter like a blue light filter applied. |
| The nose fit of Luca frames is a high nose bridge fit. |
| The hinges in Luca glasses are spring hinges, which are more flexible than other types of hinges and can extend past 90 degrees. |
Show All
### What Inspired the Frame Design of Oscar Wylee’s Luca Glasses?
The Oscar Wylee Luca frame design was inspired by current trends as oval and round shapes are often in fashion.
## What to Know About Oscar Wylee’s Luca Glasses?
There are many aspects of the Oscar Wylee Luca frames that customers should know about, so they can decide whether this is the right frame for them. The Luca frame is a unisex oval/round frame. Oscar Wylee’s Luca frame is suitable for many face shapes but particularly compatible with square, oval and heart face shapes. The Luca frame’s classic design means that they are fashionable all year round. Luca glasses feature the standard [parts of glasses](https://www.oscarwylee.com.au/glasses/eye/part-of-glasses) such as a rim, temples, lenses, spring hinge and a high nose bridge fit.
### What are the Types of Temple Tips or Earpieces Included with Oscar Wylee’s Luca Glasses?
The type of temple tips or earpieces included in Oscar Wylee’s Luca Glasses are made from acetate.
### What Type of Nose Bridge do Oscar Wylee’s Luca Glasses Have?
The type of nose bridge included in Oscar Wylee’s Luca frame is a high nose bridge.
### What Type of Nose Pads are Included with Oscar Wylee’s Luca Glasses?
Oscar Wylee’s Luca frame does not include adjustable silicone nose pads.
### What Type of Lenses do Oscar Wylee’s Luca Glasses Have?
The type of lenses that typically come with the Oscar Wylee Luca [glasses frame](https://www.oscarwylee.com.au/glasses.html) are optical lenses. Optical lenses are glasses lenses that have a prescription within the lens to help correct vision issues such as myopia, hyperopia and astigmatism. Luca glasses can also come with non-prescription lenses, with add-ons such as a blue light filter. Luca frames are currently unavailable as sunglasses online, however, customers can customise in-store and add on tint or polarisation.
### What Material is Used for the Rim of Oscar Wylee’s Luca Glasses?
The material used for the rim of Oscar Wylee’s Luca glasses frames is acetate. The rim refers to the part of a glasses frame that holds the lenses.
### What Type of Hinges are Included with Oscar Wylee’s Luca Glasses?
The type of hinges included with Oscar Wylee’s Luca frames are spring hinges. A spring hinge in a glasses frame refers to hinges that are more flexible than normal hinges and can go slightly beyond 90 degrees. Spring hinges can provide a closer fit to the face.
## What Face Types are Most Suitable for Oscar Wylee’s Luca Glasses?
The face types that are most suitable for Oscar Wylee’s Luca frame are square, oval and heart face types. The Luca frame is an oval and round shape, meaning that it complements the structure of square, oval and heart faces particularly well. The Luca frames help to balance the features of a [square face shape](https://www.oscarwylee.com.au/glasses/face-shapes/square), an [oval face shape](https://www.oscarwylee.com.au/glasses/face-shapes/oval) or a heart face shape, bringing the eyes and brows forward in a flattering way. Although there are many [glasses for face shapes](https://www.oscarwylee.com.au/glasses/face-shapes) that may be considered more aesthetically suitable, it is important that people also choose the frames that make them feel most comfortable and represent their personal style.
## What Size Options are Available for Oscar Wylee’s Luca Glasses?
The size options available for Oscar Wylee’s Luca frame are a medium-frame fit across all colours. The frame is also available in a Luca Small frame in the colours Clear Crystal and Marshmallow.
## What Materials are Used to Create Oscar Wylee’s Luca Glasses?
The material used to create the Oscar Wylee Luca frame is acetate. Acetate, also known as cellulose acetate, is a bioplastic, made from cotton fibres or wood pulp. At Oscar Wylee, acetate glasses are made by adding a dye to cellulose acetate, which is rolled into a sheet. The shape of the glasses is then cut from this sheet.
## What’s Included
## OW Case &amp;a Cloth
Protective Case and Lens Cloth
Our high-quality glasses case and lens cloth are included with every purchase of an Oscar Wylee frame. The stylish, magnetic case is made from a hard shell. This sturdy and durable material keeps your glasses protected and safe, wherever you go. Ensure your lenses are clean and scratch-free with our OW microfibre cloth, specifically designed to ensure you have comfortable vision through your lenses.
Oscar Wylee offers:
* Free Shipping for Australian Orders
* 1 Year Warranty on frames and lenses
* Scratch resistance lens coating on all prescriptions
* UV-proof coating on all prescriptions
Health fund rebate: Once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. Learn more about [health funds](https://www.oscarwylee.com.au/health-funds.html).
## Make and Materials
The frames then go through cleaning and strict quality control, and many pairs of crafting hands to be hand-assembled and polished. After your frames have gone through the production process, they are individually examined and packed before making their way to you!Also known as cellulose acetate, these frames are traditionally hand-crafted by skilled craftsmen, with each frame passing through numerous stages of production and are hand-polished to ensure a glorious lustre.
## Warranty Information
### Warranty Information
### Warranty Information
Oscar Wylee provides a 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects. 
We will repair or replace faulty or defective frames or lenses free of charge for warranty claims made within 1 year of the delivery.
We also offer repairs or replacement for problems experienced with vision during everyday use for claims made within 30 days of delivery. If the same product has been discontinued or is no longer available, then we may offer an exchange for a similar product or a refund.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Find a Store Location](https://www.oscarwylee.com.au/locations/full-store-list.html)
Recommended
1. [](https://www.oscarwylee.com.au/louie-optical.html)
[Louie](https://www.oscarwylee.com.au/louie-optical.html)
Apple Blush
2. [](https://www.oscarwylee.com.au/kent-optical.html)
[Kent](https://www.oscarwylee.com.au/kent-optical.html)
Clear Crystal