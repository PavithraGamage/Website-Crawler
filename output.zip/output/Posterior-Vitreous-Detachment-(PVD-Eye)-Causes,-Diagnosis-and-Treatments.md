# Source: https://www.oscarwylee.com.au/glasses/eye/posterior-vitreous-detachment

# Posterior Vitreous Detachment (PVD): Causes, Diagnosis and Treatments
Published on April 5, 2024
Updated on January 16th, 2025
Posterior vitreous detachment (PVD)
is a condition in which the vitreous, the transparent, gel-like substance
that fills the middle of the eye, detaches from the retina.
Symptoms of posterior vitreous detachment commonly include an increase in
eye floaters, flashes and in some cases blurry vision. Posterior vitreous
detachment is typically non-sight threatening, unless complications occur.
Complications can include macular holes, retinal tears and vitreous
haemorrhages. Signs that a complication has occurred can include distorted
or decreased vision. It is important that a person sees an optometrist as
soon as possible if symptoms of posterior vitreous detachment or any
complications are present. There is generally no treatment needed for
posterior vitreous detachment unless complications have occurred. The brain
will generally get used to floaters and flashes and learn to ignore them. An
optometrist will typically diagnose posterior vitreous detachment during an
eye test and will be able to provide advice on how to proceed if the
condition is present.
Want to see more articles from us? Make Oscar Wylee your preferred source on
Google by clicking the button below.
[Make OW A Preferred Source](https://www.google.com/preferences/source)
Are You Due for an Eye test?
Book online and our Oscar Wylee optometrists will perform a Medicare bulk
billed eye test to keep your eye health on track.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Definition](#definition) [Causes](#causes)
[Symptoms](#symptoms) [Treatment](#treatment)
## What is Posterior Vitreous Detachment?
Posterior vitreous detachment (PVD)
refers to a condition in which the vitreous detaches from the
retina. The vitreous, also known as the vitreous humour, is the transparent,
gel-like substance that fills the middle of the eye, between the lens
and the retina. Posterior vitreous detachment refers to the vitreous
detaching from the retina, which often occurs due to changes in the eye
as a person ages. Posterior vitreous detachment is a
[common eye problem](https://www.oscarwylee.com.au/glasses/eye/common-problems)
and not sight-threatening unless a retinal tear or other complications
have occurred. Symptoms of posterior vitreous detachment can include eye
floaters, but the condition may also occur without symptoms. It is
important to see an optometrist if a person notices a sudden increase of
eye floaters, blurry vision and flashes of light as this may indicate a
retinal tear, which needs immediate medical attention. Posterior
vitreous detachment is generally an age-related condition, with the
likelihood of a person experiencing this increasing with age. Posterior
vitreous detachment may be abbreviated to PVD.
### What Causes Posterior Vitreous Detachment?
Posterior vitreous detachment is typically
caused by changes in the eye as a person ages. According to the
American Academy of Ophthalmology, the vitreous changes with age,
becoming less solid and more like a liquid. As the vitreous undergoes
this change, it can shrink and pull away from the retina.
#### Can Posterior Vitreous Detachment (PVD) Cause Distorted Vision?
Posterior vitreous detachment
may cause distorted vision in some cases.
[Distorted vision](https://www.oscarwylee.com.au/glasses/eye/distorted-vision)
refers to objects appearing wavy or bent, according to the American
Academy of Ophthalmology. Distorted vision is not a common symptom
of posterior vitreous detachment and may occur if the vitreous
detachment has caused complications, such as a retinal tear, macular
hole, or vitreous haemorrhage, according to The American Society of
Retina Specialists.
#### Is Posterior Vitreous Detachment Harmful?
Posterior vitreous detachment
is not generally harmful or vision-threatening, however, it can
sometimes cause more serious vision issues that can affect sight
if complications have occurred. Complications that can arise from posterior vitreous detachment
include retinal tears, macular holes and retinal detachment. These
are serious eye conditions that can be sight-threatening and may
require immediate medical attention. Symptoms of posterior vitreous
detachment are typically painless and include a sudden increase of
eye floaters and flashes, as well as blurred vision. If
complications have occurred, symptoms may also include distorted
vision. It is important to see an optometrist or medical
professional if you have any symptoms of posterior vitreous
detachment so an optometrist can assess your eyes and identify any
potential complications.
## What Are the Posterior Vitreous Detachment Symptoms?
The symptoms of posterior vitreous detachment can include
floaters, flashes, blurry vision, and in more serious cases where
complications have occurred, distorted vision. Posterior vitreous detachment symptoms are generally painless, and
non-vision threatening unless complications like a macular hole, have
occurred. It is important to see an optometrist if you believe you have
symptoms of posterior vitreous detachment, so an assessment and
diagnosis can be made and any complication identified. The symptoms of
posterior vitreous detachment are listed below.
* Floaters:  Floaters refer to specks or
cobweb-like strands that move across a person’s vision. According to
the National Eye Institute, floaters occur when the vitreous detaches
and strands of the vitreous cast shadows on the retina, which appear
as floaters.
* Flashes:  Flashes refer to occurrences
of flashing lights in the eyes. According to Kahawita, Simon and
Gilhotra in an article for the Australia Family Practioner, flashes
may occur as a symptom of posterior vitreous detachment if the
vitreous tugs, causing mechanical stimulation of the retina.
* Blurry vision:  Blurry vision refers
to vision appearing out of focus, with objects not looking sharp or
clear. Blurry vision may occur as a symptom of posterior vitreous
detachment if larger floaters are obscuring the visual field, presence
of a Weiss ring in the vitreous body or, in more serious cases,
vitreous haemorrhage, according to Ramovecchi, Salati and Zeppieri in
the paper
Spontaneous posterior vitreous detachment: A glance at the current
literature.
* Distorted vision: 
[Distorted vision](https://www.oscarwylee.com.au/glasses/eye/distorted-vision)
refers to objects appearing wavy, bent or out of shape. According to
The American Society of Retina Specialists, distorted vision may occur
if vitreous detachment has caused complications such as retinal tears
or macular holes.
### How is Posterior Vitreous Detachment (PVD) Diagnosed?
Posterior vitreous detachment (PVD) will be
diagnosed by an optometrist during an eye test. An optometrist
will use a range of tests during an
[eye checkup](https://www.oscarwylee.com.au/glasses/eye/test-glossary)
to assess the eye for signs of posterior vitreous detachment,
including a dilated eye exam. A dilated eye exam involves an
optometrist using dilating eye drops to widen the pupil, so a more
in-depth examination of the eye’s structures can be performed. An
optometrist will use a slit lamp, which is a type of microscope, to
assess the vitreous. Other tests that may be used by an optometrist to
diagnose posterior vitreous detachment include an Ultrasonography and
an Optical Coherence Tomography (OCT). At Oscar Wylee you can get a
bulk billed eye test with one of our optometrists, which can assist in
the diagnosis of posterior vitreous detachment. Bulk billing does not
mean that there are
[free eye tests at Oscar Wylee](https://www.oscarwylee.com.au/free-eye-test)
as Medicare, Australia’s universal healthcare system, is billed.
However, there will be no out-of-pocket costs for customers.
## What are the Effects of Posterior Vitreous Detachment (PVD) on a
Person’s Vision?
The
effects that posterior vitreous detachment (PVD) will have on a
person and their vision are generally minor. However, if complications have occurred as a result of vitreous
detachment, the effects may be more severe and impact vision. Generally,
the symptoms of posterior vitreous detachment include eye floaters,
flashes and blurry vision. According to the Royal National Institute of
Blind People, the symptoms of posterior vitreous detachment may calm
down as the brain learns to ignore them. If complications have occurred
such as a macular hole or retinal detachment, as a result of vitreous
detachment, symptoms may be more severe, such as distorted or decreased
vision. It is important to see an optometrist if you believe you have
symptoms of posterior vitreous detachment.
### What is the Timeline for Posterior Vitreous Detachment?
The time in which posterior vitreous detachment occurs
varies from person to person and happens in stages. There are 4
stages of posterior vitreous detachment according to Koller, Kraker
and Hwang in the paper
Progression of Partial Posterior Vitreous Detachment Over Time.
Stage 1 in which there is no detachment, stage 2 in which the vitreous
partially separated from the fovea but not the foveola, stage 3 where
the vitreous is separated from the macula but is still attached to the
optic nerve and stage 4 in which the vitreous is separated from both
the macula and the optic nerve. According to the same study, the rate
at which a person progresses from stage to stage of posterior vitreous
detachment happens over decades.
## What is the Treatment for Posterior Vitreous Detachment?
There is
generally no treatment needed for posterior vitreous detachment
unless damage to the retina has occurred during the detachment. According to The Royal Victorian Eye and Ear Hospital, symptoms of
posterior vitreous detachment will settle over time, with flashes
lessening and floaters becoming less noticeable. According to the Royal
National Institute of Blind People, the brain learns to ignore symptoms
of posterior vitreous detachment over time, making them less noticeable.
If a complication such as a retinal tear has occurred during detachment,
an ophthalmologist may treat this by sealing the retina to the wall of
the eye using a freezing treatment like a laser, according to the
American Academy of Ophthalmology.
Visit a Store Near You
Our team in-store can help you with any questions you have about eye
tests or glasses.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
### What is the Consequence of Untreated Posterior Vitreous Detachment?
Posterior vitreous detachment
can usually go untreated without consequence, as the condition is
non-sight threatening and symptoms may become less noticeable as the
brain gets used to them.
However, if a complication like a retinal tear has occurred, this will
need prompt treatment by an eye care professional as this condition
can cause vision loss.
#### Can Glasses Posterior Vitreous Detachment Treat (PVD)?
No, glasses will not treat posterior vitreous detachment.
Glasses can refer to prescription glasses that help correct
refractive errors such as myopia. Other
[types of glasses](https://www.oscarwylee.com.au/glasses/types)
include sunglasses or non-prescription glasses. Glasses will not
treat posterior vitreous detachment as this is an issue with the
internal structure of the eye, not a refractive error.
How is Your Vision?
If you have concerns about how clear your vision is, book a bulk
billed eye test with Oscar Wylee today.
[Book an eye test](https://www.oscarwylee.com.au/booking)
Oscar Wylee Accepts Major Health Funds In-store
Visit Oscar Wylee in-store for eye care services and your health fund
may help cover some of the cost.
[Explore health funds](https://www.oscarwylee.com.au/health-funds.html)