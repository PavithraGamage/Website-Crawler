# Source: https://www.oscarwylee.com.au/privacy-policy-cookie-restriction-mode.html
# Privacy and Cookie Policy

This privacy policy sets out how the website (hereafter "the Store") uses and protects any information that you give Oscar Wylee while using this website. Oscar Wylee is committed to ensuring that your privacy is protected. Should we ask you to provide certain information by which you can be identified when using this website, then you can be assured that it will only be used in accordance with this privacy statement. The Store may change this policy from time to time by updating this page. You should check this page from time to time to ensure that you are happy with any changes Oscar Wylee may implement.
## What we collect
We may collect the following information:
* name
* contact information including email address
* demographic information such as postcode, preferences and interests
* other information relevant to customer surveys and/or offers
For the exhaustive list of cookies we collect see the [List of cookies we collect](#list) section.
## What we do with the information we gather
Oscar Wylee requires require this information to understand your needs and provide you with a better service, and in particular for the following reasons:
* Internal record keeping.
* We may use the information to improve our products and services.
* We may periodically send promotional emails about new products, special offers or other information which we think you may find interesting using the email address which you have provided.
* From time to time, Oscar Wylee may also use your information to contact you for market research purposes. We may contact you by email, phone, fax or mail. We may use the information to customise the website according to your interests.
## Security
At Oscar Wylee, we are committed to ensuring that your information is secure. In order to prevent unauthorised access or disclosure, we have put in place suitable physical, electronic and managerial procedures to safeguard and secure the information we collect online.
## How we use cookies
Cookies allow web applications to respond to you as an individual. The web application can tailor its operations to your needs, likes and dislikes by gathering and remembering information about your preferences.
Oscar Wylee use traffic log cookies to identify which pages are being used. This helps us at Oscar Wylee analyse data about web page traffic and improve our website in order to tailor it to customer needs. We only use this information for statistical analysis purposes and then the data is removed from the system.
Overall, cookies help Oscar Wylee provide you with a better website, by enabling us to monitor which pages you find useful and which you do not. A cookie in no way gives us access to your computer or any information about you, other than the data you choose to share with us. You can choose to accept or decline cookies. Most web browsers automatically accept cookies, but you can usually modify your browser setting to decline cookies if you prefer. This may prevent you from taking full advantage of the website of what our website has to offer.
## Links to other websites
Our Oscar Wylee website may contain links to other websites of interest. However, once you have used these links to leave our site, you should note that we do not have any control over that other website. Therefore, we cannot be responsible for the protection and privacy of any information which you provide whilst visiting such sites and such sites are not governed by this privacy statement. You should exercise caution and look at the privacy statement applicable to the website in question.
## Controlling your personal information
You may choose to restrict the collection or use of your personal information in the following ways:
* whenever you are asked to fill in a form on our website, look for the box that you can click to indicate that you do not want the information to be used by anybody for direct marketing purposes
* if you have previously agreed to us using your personal information for direct marketing purposes, you may change your mind at any time by letting us know using our Contact Us information
Oscar Wylee will not sell, distribute or lease your personal information to third parties unless we have your permission or are required by law to do so. We may use your personal information to send you promotional information about third parties which we think you may find interesting if you tell us that you wish this to happen.
Oscar Wylee may collect, store, use and disclose personal information about you, which you can request to access under the Privacy Act 1988 (Privacy Act) and the Australian Privacy Principles (APPs) contained in Schedule 1 of the Privacy Act. A small fee will be payable. If you would like a copy of the information held on you please email us this request using our Contact Us information, and one of our friendly customer representatives will get back to you.
If you believe that any information we are holding on you is incorrect or incomplete, please write to or email us as soon as possible, at the above address. Our team will promptly correct any information found to be incorrect.
## Cookies
Our website uses cookies and similar technologies to provide website functionality, improve your browsing experience, analyse website traffic, and support our marketing activities at Oscar Wylee.
The types of cookies we use include:
* Necessary Cookies:&nbsp;These cookies are required for the operation of our website and enable core functionality such as security, shopping cart functionality, page navigation and access to secure areas of the website.
* Functional Cookies:&nbsp;These cookies allow the website to remember choices you make, such as your preferences and recently viewed products, to provide enhanced functionality and a more personalised experience.
* Analytics Cookies :These cookies help us understand how visitors interact with our website by collecting information about website usage and performance. This information helps us improve our website and services we offer here at Oscar Wylee.
* Advertising and Marketing Cookies:&nbsp;These cookies are used to measure the effectiveness of our advertising campaigns, deliver relevant advertisements and understand how visitors engage with our marketing across different platforms we have at Oscar Wylee.&nbsp;&nbsp;
We may use third-party providers including Google, Meta (Facebook), Microsoft, TikTok, Snapchat, X (formerly Twitter) and other advertising and analytics partners to assist with these activities.
Most web browsers allow you to manage or disable cookies through your browser settings. Please note that disabling certain cookies may affect the functionality of our website.