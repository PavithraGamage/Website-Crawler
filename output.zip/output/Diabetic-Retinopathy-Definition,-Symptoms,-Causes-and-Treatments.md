# Source: https://www.oscarwylee.com.au/glasses/eye/diabetic-retinopathy

# Diabetic Retinopathy: Definition, Symptoms, Causes and Treatments
Published on May 3rd, 2024
Diabetic retinopathy is a complication of diabetes that affects the blood vessels in the retina. Damage to these blood vessels causes vision loss and can eventually lead to blindness if untreated. There are no symptoms in early-stage diabetic retinopathy but later-stage symptoms include fluctuating vision, increased sensitivity to light and glare and eye floaters. Treatments for diabetic retinopathy include medication, laser treatment and eye surgery. Keep reading to learn more about diabetic retinopathy diagnosis and the other eye conditions caused by diabetes.
Due for an Eye Test?
Book online with an Oscar Wylee Optometrist to receive a bulk billed eye test.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Definition](#definition) [DIabetic Eye Diseases](#diseases) [Stages](#stages) [Treatments](#treatments)
## What is Diabetes?
Diabetes is a chronic disease that occurs when a person’s blood sugar (blood glucose), is too high. Diabetes is caused by either the pancreas not producing enough insulin, or the body not being able to effectively use the insulin it produces. According to the National Institute of Diabetes and Digestive and Kidney Diseases, diabetes increases a person’s risk for damage to their kidneys, nerves, heart and eyes. The most common types of diabetes are type 1, type 2 and gestational diabetes. The scientific name for this disease is diabetes mellitus.
## What is Retinopathy?
Retinopathy is a disease that affects the retina. Types of retinopathy aside from diabetic retinopathy include hypertensive retinopathy which is a complication of high blood pressure, central serous retinopathy which occurs when fluid builds up under the retina and retinopathy of prematurity which occurs in premature babies.
## What is Diabetic Retinopathy?
Diabetic retinopathy (DR) is a complication of diabetes where the small blood vessels in the retina located at the back of the eye are damaged. Diabetic retinopathy can be classified into different categories which are non-proliferative DR, proliferative DR and cystoid macular oedema. According to Healthdirect Australia, the symptoms a person may experience with diabetic retinopathy are blurred vision, pain in the eyes, eye floaters, sensitivity to glare and trouble seeing at night. This eye condition may be diagnosed through an eye test and the patient may be referred to an ophthalmologist if necessary.
### What is Proliferative Diabetic Retinopathy?
Proliferative diabetic retinopathy is an advanced stage of diabetic retinopathy where new blood vessels are formed to replace those that are no longer working. These new vessels are prone to leaking and can cause sudden vision loss. According to the Mayo Clinic, vision loss occurs due to scar tissue formed from the growth of new blood vessels which can cause the retina to detach from the back of the eye.
### How Common is Diabetic Retinopathy in People with Diabetes?
According to the National Eye Institute, more than half of people who have diabetes will develop diabetic retinopathy. The risk of developing diabetic retinopathy increases the longer a person has diabetes.
#### What are Other Eye Conditions Related to Diabetes?
Diabetes can affect the eye in many ways causing eye conditions other than diabetic retinopathy, which is known as diabetic eye disease. Other types of diabetic eye diseases include glaucoma, cataracts and macular edema. These related [eye conditions](https://www.oscarwylee.com.au/glasses/eye/common-problems) and their definitions are listed below.
* Glaucoma: Neovascular glaucoma can be caused by diabetes as high sugar levels damage the retina’s blood vessels resulting in the creation of abnormal blood vessels, according to Johns Hopkins Medicine.
* Cataracts: People with diabetes are at a high risk of developing cataracts as high blood sugar can lead to changes in the lens which can speed up the formation of a cataract.
* Macular edema: Diabetic macular edema occurs due to swelling in the part of the retina called the macular. This swelling is caused by microaneurysms forming in the blood vessels that leak fluid into the retina.
### What are the Early Signs of Diabetic Retinopathy?
There are no early symptoms of diabetic retinopathy as symptoms are most commonly experienced in the later stages of this eye condition. Later symptoms of diabetic retinopathy include blurry vision, eye floaters and vision loss.
## What are the Diabetic Retinopathy Symptoms?
In the early stages of diabetic retinopathy, many people do not experience symptoms.
Symptoms in the later stages that may occur, according to Vision Australia, include fluctuating vision, patchy field loss, increased sensitivity to light and glare and eye floaters. These symptoms and their definitions are listed below.
* Fluctuating vision: Fluctuating vision is described as blurred vision that comes and goes. Fluctuating vision may occur due to irregular blood sugar levels.
* Patchy field loss: Patchy field loss is due to scars caused by damaged blood vessels. This type of vision loss cannot be corrected by prescription glasses.
* Increased sensitivity to light and glare: A person with diabetic retinopathy can develop increased sensitivity to light and glare. Light sensitivity is discomfort or pain that occurs when the eyes are exposed to light.
* Eye floaters: Eye floaters are black dots or strings that appear in a person's vision. Eye floaters are a symptom of diabetic retinopathy as the growth of scar tissue can pull the retina away from the back of the eye.
### What are the Stages of Diabetic Retinopathy?
The three stages of diabetic retinopathy, as defined by the NHS (National Health Service), are background retinopathy, pre-proliferative retinopathy and proliferative retinopathy. These stages and their definitions are listed below.
* Stage 1: Background retinopathy-In the first stage of diabetic retinopathy, microaneurysms appear in the blood vessels of the retina. Eyesight is not yet affected at this stage and a person does not require treatment.
* Stage 2: Pre-proliferative retinopathy-In the second stage, more severe changes are occurring in the retina such as bleeding. At this stage, there is a high risk that a person’s vision will be eventually affected.
* Stage 3: Proliferative retinopathy-In stage three, new scar tissue and blood vessels have formed on the retina, causing bleeding which can lead to retinal detachment. There is a very high risk of vision loss at this stage and treatment is necessary.
Find an Oscar Wylee Store Near You
Our capable team can help you with any concerns about your vision health and eyewear needs.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
## What is the Main Cause of Diabetic Retinopathy?
The main and only cause of diabetic retinopathy is high blood sugar due to diabetes. Diabetic retinopathy is a complication of diabetes. If there is too much sugar in a person’s blood, it can cause a blockage of blood vessels that provide nourishment to the retina, cutting off the retina’s blood supply, according to the Mayo Clinic.
### How Can Diabetes Affect the Blood Vessels of the Retina?
Diabetes affects the eyes as high blood sugar damages the blood vessels in the [retina](https://www.oscarwylee.com.au/glasses/eye/anatomy/retina), causing them to swell and leak which can cause blurry vision, according to the Centers for Disease Control and Prevention. In some cases, new blood vessels can grow but are abnormal, leading to further vision issues.
#### Does Diabetic Retinopathy Cause Bleeding in the Eye?
Yes, in the later stages of diabetic retinopathy, blood vessels located in the retina may begin to bleed into the vitreous humour, which is the gel-like substance that fills the eyeball. If this occurs, it can cause the symptoms of eye floaters and a person may see small specks or spots in their vision.
## How to Diagnose Diabetic Retinopathy?
Diagnosis of diabetic retinopathy is achieved through an eye test performed by an eye care professional. The eye test performed to diagnose diabetic retinopathy is a dilated eye exam which involves the patient’s pupils being dilated using eye drops. The optometrist will then check the eyes for signs of diabetic retinopathy. It is extremely important to have regular [eye tests](https://www.oscarwylee.com.au/glasses/eye/check-up) if you have diabetes as more than half of people with diabetes develop diabetic retinopathy and early detection and treatment can prevent blindness.
## Can You Prevent Diabetic Retinopathy?
There is no definitive way of preventing diabetic retinopathy, however, a person’s risk of developing this eye condition can increase due to having diabetes for a long time, high blood pressure, tobacco use, poor control of blood glucose levels, high cholesterol and pregnancy.
### What is the Prevention for Diabetic Retinopathy?
While complete prevention of diabetic retinopathy is not possible, there are ways a person can attempt to prevent vision loss and/or blindness from diabetic retinopathy. A person should have good control of their blood sugar levels, should see their general practitioner for blood tests to assess their blood sugar levels, have a yearly diabetic eye test with their optometrist and see their ophthalmologist regularly to have any diabetic retinopathy closely monitored.
## What are Diabetic Retinopathy Treatments?
The type of treatment for diabetic retinopathy commonly depends on the type of diabetic retinopathy a person has and its severity. Three types of treatments for diabetic retinopathy according to the National Eye Institute, include medication, laser treatment and eye surgery. These treatments and their definitions are listed below.
* Medication: Certain medications can be used to treat diabetic retinopathy to reverse or slow down its effects. The medications used to treat this eye condition are called anti-VEGF drugs and corticosteroids.
* Laser treatment: Laser treatment for diabetic retinopathy is performed to reduce swelling in a person’s retina. This treatment is performed using lasers to make the blood vessels shrink and stop leaking, according to the National Eye Institute.
* Eye surgery: Eye surgery can be used to treat diabetic retinopathy. The type of eye surgery is called a vitrectomy which involves an eye doctor removing the vitreous and replacing it with another solution.
### Can Diabetic Retinopathy Lead to Blindness if Left Untreated?
Yes, diabetic retinopathy can lead to blindness if it is left untreated or is poorly managed. According to the NHS (National Health Service), it can typically take several years for diabetic retinopathy to become severe enough to cause blindness. Diagnosis and treatment for this eye condition is extremely important which means having regular eye tests and seeing an optometrist if you have any vision or eye problems.
Take Care of Your Eyes Today
Oscar Wylee offers no-gap bulk billed eye tests for valid Medicare cardholders performed by dedicated optometrists.
[Book an Eye Test](https://www.oscarwylee.com.au/booking)
Major Health Funds Accepted
Looking for information about your private health fund provider? We’ve collected all the details you’ll need!
[Explore Health Funds](https://www.oscarwylee.com.au/health-funds.html)