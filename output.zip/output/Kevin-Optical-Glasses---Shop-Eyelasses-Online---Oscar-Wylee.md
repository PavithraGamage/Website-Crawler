# Source: https://www.oscarwylee.com.au/kevin-optical.html

# Kevin
1
## Frame Design of Kevin Glasses
The frame design of Oscar Wylee’s Kevin glasses is characterised by a rectangular shape with a high-bridge nose fit and an acetate frame. The Kevin frame is a men's, statement pair of glasses that will work for any occasion, whether the wearer wants to liven up their work style or complement a fun outfit for a night out.
$169    
In stock
Only %1 left
2 pairs from $199
Discount auto-applied at checkout
3 pairs from $249
Discount auto-applied at checkout
Qty
Add to cart
Book an eye test
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
excluding prescription lenses
## About Kevin Frames
Kevin is an easy, laid-back frame with a rectangular shape that
creates flattering angles on the face. Find the joy in simplicity
with this effortless frame.
| Frame fit | Measurements |
| --- | --- |
| MEDIUM | 52 - 19 - 145 |
These measurements mean lens width, bridge, and temple length in
millimetres (mm). They can be found on the inside of the temple
arm. If you already have a pair that you like, you can compare it
to these measurements.
### Made from Acetate
Oscar Wylee’s Kevin glasses frame is a rectangular, acetate frame
that suits oval or round face shapes. The Kevin frame is a
stylish, widely wearable frame that can be worn everyday day. The
main specs of Oscar Wylee’s Kevin glasses frame including
dimensions, shape, materials, lenses, nose fit and hinges
are listed below.
| Kevin Frame Features | Kevin Frame Description | Dimensions | Shape | Materials | Lenses | Nose Fit | Hinges |
| --- | --- | --- | --- | --- | --- | --- | --- |
| The dimensions of the Kevin frame are measured in millimetres
(mm) and are 52 - 19 - 145, meaning the lens width is 52 mm,
the bridge is 19 mm and the temple length is 145 mm. |
| The Kevin frame is a rectangular shape, well suited to medium
faces. |
| Kevin glasses are made from a material called acetate. |
| The lenses that can be used in the Kevin frame are optical
lenses, which include single vision and multifocal lenses and
non-prescription lenses, which are plain and can have a filter
like a blue light filter applied. |
| The nose fit of Kevin frames is a high nose bridge fit. |
| The hinges in Kevin glasses are spring hinges, which are more
flexible than other types of hinges and can extend past 90
degrees. |
Show All
### What Inspired the Frame Design of Oscar Wylee’s
Kevin Glasses?
The Oscar Wylee Kevin frame was inspired by current fashion
trends as rectangle shapes are often in fashion. Their clean
and sharp angles and lines make for a timeless glasses frame.
## What to Know About Oscar Wylee’s Kevin Glasses?
There are many aspects of the Oscar Wylee Kevin frames that
customers should know about so they know whether this is a
suitable frame for them. The Kevin frame is a men’s
rectangle-shaped frame. Oscar Wylee’s Kevin frame is suitable
for many face shapes but is particularly compatible with oval
and round face shapes. The Kevin frame’s classic design means
that they are fashionable all year round. Kevin glasses
feature the standard
[parts of glasses](https://www.oscarwylee.com.au/glasses/eye/part-of-glasses)
such as a rim, temples, lenses, spring hinge and a high nose
bridge.
### What are the
Types of Temple Tips or Earpieces Included with
Oscar Wylee’s Kevin Glasses?
The temples and temple tips of Oscar Wylee’s Kevin Glasses are
made from acetate.
### What Type of Nose Bridge do Oscar Wylee’s Kevin
Glasses Have?
Oscar Wylee’s Kevin frame has a high nose bridge.
### What Type of Nose Pads are Included with Oscar
Wylee’s Kevin Glasses?
Oscar Wylee’s Kevin frame does not have nose pads.
### What Type of Lenses do Oscar Wylee’s Kevin Glasses
Have?
The Oscar Wylee Kevin frame typically comes with optical
lenses. Optical lenses are glasses lenses that have a
prescription within the lens to help correct vision issues
such as myopia, hyperopia and astigmatism. Kevin glasses can
also come with non-prescription lenses, with add-ons such as a
blue light filter. Kevin
[glasses frame](https://www.oscarwylee.com.au/glasses.html)
are currently not available as sunglasses online, however,
customers can customise in-store and add on tint or
polarisation.
### What Material is Used for the Rim of Oscar Wylee’s
Kevin Glasses?
The rim of Oscar Wylee’s Kevin glasses frames are made from
acetate. The rim refers to the part of a glasses frame that
holds the lenses.
### What Type of Hinges are Included with Oscar Wylee’s
Kevin Glasses?
The type of hinges featured on Oscar Wylee’s Kevin frames are
spring hinges. A spring hinge in a glasses frame refers to
hinges that are more flexible than normal hinges and can go
slightly beyond 90 degrees. Spring hinges can provide a closer
fit to the face.
## What Face Types are Most Suitable for Oscar Wylee’s
Kevin Glasses?
The Oscar Wylee Kevin frame is most suitable for round and
oval face types. The Kevin frame is a rectangular frame shape
that complements the structure of round and oval faces
particularly well. The rectangle Kevin frames helps to balance
the features of an
[oval face shape](https://www.oscarwylee.com.au/glasses/face-shapes/oval)
or a
[round face shape](https://www.oscarwylee.com.au/glasses/face-shapes/round). The Kevin frame helps to bring forward the soft and fuller
features of oval and round face types, highlighting without
overemphasising them. Although there are many
[glasses for face shapes](https://www.oscarwylee.com.au/glasses/face-shapes)
that may be considered more aesthetically suitable, it is
important that people also choose the frames that make them
feel most comfortable, and represent their personal style.
## What Size Options are Available for Oscar Wylee’s
Kevin Glasses?
The size options available for Oscar Wylee’s Kevin frame are a
medium-frame fit across all colours.
## What Materials are Used to Create Oscar Wylee’s
Kevin Glasses?
The primary material used to create the Oscar Wylee Kevin
frame is acetate. Acetate, also known as cellulose acetate, is
a bioplastic, made from cotton fibres or wood pulp. At Oscar
Wylee, acetate glasses are made by adding a dye to cellulose
acetate, which is rolled into a sheet. The shape of the
glasses is then cut from this sheet.
## What’s Included
## OW Case &amp; Cloth
Protective Case and Lens Cloth
Our high-quality glasses case and lens cloth are included with every purchase of an Oscar Wylee frame. The stylish, magnetic case is made from a hard shell. This sturdy and durable material keeps your glasses protected and safe, wherever you go. Ensure your lenses are clean and scratch-free with our OW microfibre cloth, specifically designed to ensure you have comfortable vision through your lenses.
Oscar Wylee offers:
* Free Shipping for Australian Orders
* 1 Year Warranty on frames and lenses
* Scratch resistance lens coating on all prescriptions
* UV-proof coating on all prescriptions
Health fund rebate: Once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. Learn more about [health funds](https://www.oscarwylee.com.au/health-funds.html).
## Make and Materials
The frames then go through cleaning and strict quality control, and many pairs of crafting hands to be hand-assembled and polished. After your frames have gone through the production process, they are individually examined and packed before making their way to you!Also known as cellulose acetate, these frames are traditionally hand-crafted by skilled craftsmen, with each frame passing through numerous stages of production and are hand-polished to ensure a glorious lustre.
## Warranty Information
### Warranty Information
### Warranty Information
Oscar Wylee provides a 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects. We will repair or replace faulty or defective frames or lenses free of charge for warranty claims made within 1 year of the delivery. We also offer repairs or replacement for problems experienced with vision during everyday use for claims made within 30 days of delivery. If the same product has been discontinued or is no longer available, then we may offer an exchange for a similar product or a refund.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Find a Store Location](https://www.oscarwylee.com.au/locations/full-store-list.html)