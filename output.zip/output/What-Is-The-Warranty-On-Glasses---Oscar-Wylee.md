# Source: https://www.oscarwylee.com.au/faq-returns.html

* [POPULAR FAQS](https://www.oscarwylee.com.au/faq-popular.html)
* [ORDERING](https://www.oscarwylee.com.au/faq-ordering.html)
* [PRESCRIPTIONS](https://www.oscarwylee.com.au/faq-prescriptions.html)
* [SUNGLASSES](https://www.oscarwylee.com.au/faq-sunglasses.html)
* [RETURNS &amp; WARRANTIES](https://www.oscarwylee.com.au/faq-returns.html)
* [PAYMENT](https://www.oscarwylee.com.au/faq-payment.html)
* [HEALTH FUNDS](https://www.oscarwylee.com.au/faq-healthfund.html)
* [LENSES](https://www.oscarwylee.com.au/glasses/eye/types-of-lenses)
* [FRAMES](https://www.oscarwylee.com.au/faq-frames.html)
* [SHIPPING](https://www.oscarwylee.com.au/faq-shipping.html)
* [EYEWEAR STYLING TIPS](https://www.oscarwylee.com.au/faq-eyewear-styling-tips.html)
POPULAR
ORDERING
PRESCRIPTIONS
SUNGLASSES
RETURNS &amp; WARRANTIES
PAYMENT
HEALTH FUNDS
LENSES
FRAMES
SHIPPING
EYEWEAR STYLING TIPS
### RETURNS &amp; WARRANTIES
For more details please refer to [Oscar Wylee Warranty](https://www.oscarwylee.com.au/legal/oscar-wylee-warranty.html)
What is covered by Oscar Wylee Warranty?
Oscar Wylee provides a 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects. We will repair or replace faulty or defective frames or lenses free of charge for warranty claims made within 1 year of the delivery.
Oscar Wylee also offers a repair or replacement for problems experienced with vision during everyday use for claims made within 30 days of delivery.
If the same product has been discontinued or is no longer available, then we may offer an exchange for a similar product or a refund.
Our warranty policy is in addition to Australian consumer law which cannot be limited or excluded.
What is not covered?
Our warranty does not cover:
* wear and tear;
* any modifications or repairs not made by Oscar Wylee;
* damage caused by misuse, neglect or carelessness (e.g. scratches from dropping or crazing to lenses due to being left in high temperatures);
* damage caused by natural disaster;
* changes to designs and/or colour after purchase;
* purchases or deliveries outside Australia;
* accidental loss or damage;
* items that were not purchased from Oscar Wylee (e.g. if only lenses were purchased then the warranty does not cover any frame used for the lenses; if only frames were purchased then the warranty does not any lenses used in the frames);
* incorrect external prescriptions provided to Oscar Wylee.
* We do not cover chipped 1.5 index lenses in half-rim styles purchased. As such we recommend 1.6 index for greater durability.
Change of mind
You may exchange or refund non-prescription, over-the-counter sunglasses within 30 days of delivery if you change your mind. These should be in brand new, saleable condition and accompanied by the original packaging.
We do not offer exchanges or accept returns for a change of mind on any other product.
Gift cards
Gift cards are not refundable or redeemable for cash.
How to make a claim?
To make a warranty claim you must return your glasses to your nearest Oscar Wylee store at your own expense together with proof of purchase.
Your rights
The benefits provided by this warranty are in addition to other rights and remedies available under the law. Our goods come with guarantees that cannot be excluded under the Australian Consumer Law. You are entitled to a replacement or refund for a major failure and compensation for any other reasonably foreseeable loss or damage. You are also entitled to have the goods repaired or replaced if the goods fail to be of acceptable quality and the failure does not amount to a major failure.