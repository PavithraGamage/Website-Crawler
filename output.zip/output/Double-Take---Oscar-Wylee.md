# Source: https://www.oscarwylee.com.au/glasses/collection/double-take.html

# Double Take Collection
[](#layer-product-list)
9 Products        
Showing 9
1. [](https://www.oscarwylee.com.au/avery-optical.html)
[Avery](https://www.oscarwylee.com.au/avery-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/avery-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/avery-optical.html)
2. [](https://www.oscarwylee.com.au/bronwyn-optical.html)
[Bronwyn](https://www.oscarwylee.com.au/bronwyn-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/bronwyn-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/bronwyn-optical.html)
3. [](https://www.oscarwylee.com.au/opal-optical.html)
[Opal](https://www.oscarwylee.com.au/opal-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/opal-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/opal-optical.html)
4. [](https://www.oscarwylee.com.au/connor-optical.html)
[Connor](https://www.oscarwylee.com.au/connor-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/connor-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/connor-optical.html)
5. [](https://www.oscarwylee.com.au/damian-optical.html)
[Damian](https://www.oscarwylee.com.au/damian-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/damian-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/damian-optical.html)
6. [](https://www.oscarwylee.com.au/nolan.html)
[Nolan](https://www.oscarwylee.com.au/nolan.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/nolan.html)
[3 pairs from $249](https://www.oscarwylee.com.au/nolan.html)
7. [](https://www.oscarwylee.com.au/nolan-sunglasses.html)
[Nolan](https://www.oscarwylee.com.au/nolan-sunglasses.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/nolan-sunglasses.html)
[3 pairs from $249](https://www.oscarwylee.com.au/nolan-sunglasses.html)
8. [](https://www.oscarwylee.com.au/marco-sunglass.html)
[Marco](https://www.oscarwylee.com.au/marco-sunglass.html)
$169
9. [](https://www.oscarwylee.com.au/duckworth-sunglasses.html)
[Duckworth](https://www.oscarwylee.com.au/duckworth-sunglasses.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/duckworth-sunglasses.html)
[3 pairs from $249](https://www.oscarwylee.com.au/duckworth-sunglasses.html)
9 Products        
Showing 9