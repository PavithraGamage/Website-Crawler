# Source: https://www.oscarwylee.com.au/blue-light-glasses.html

Filters Blue Light
May Ease Eye Strain
Reduces Glare
Clear Lens
# Blue Light Glasses
Oscar Wylee’s BLULite Filter glasses aim to help block blue light rays emitted from digital screens. The potential benefits for those wearing blue light glasses include reduced eye strain, improved comfort while using devices and improved sleep quality. In an increasingly digital world, blue light glasses can be an asset for everyone!



## What are blue light glasses?
Blue light glasses are glasses which are designed to block or reduce the amount of blue light emitted from digital screens. They do this by applying a filter or coating to the lens. At Oscar Wylee our BLULite Filter helps block artificial blue light produced from digital devices.
## How does blue light impact you?
Prolonged exposure to artificial blue light emitted from devices such as a computer or phone screen may disrupt your natural sleep cycle by blocking melatonin production. Extended periods of screen time can also cause eye discomfort known as digital eye strain.
## Do you need blue light glasses?
With busy lifestyles, some of us may not be able to get away from our laptops and phones before bedtime. Extended periods of screen time can also cause eye discomfort known as digital eye strain. Glasses with an added blue light filter may help to reduce the blue light affecting you from your digital devices and ease any digital eye strain.
## Are you due for an eye test?
Book now with one of our trained optometrists. If you need prescription glasses you can add a blue light filter to your lenses.
[Book an eye test](https://www.oscarwylee.com.au/booking)
## Blue Light Filter
If your career or lifestyle relies heavily on using digital devices, we recommend using blue light glasses.
Add a Blue Light Filter to any optical prescription glasses up to 1.67 index, or to non-prescription glasses, for an additional $85. Includes free Basic Anti-Reflective Coating.

## Blue Light Filter Premium
Add a Blue Light Premium Filter to any optical prescription glasses up to 1.67 index, or to non-prescription glasses, for an additional $95. Includes a Premium Anti-Reflective coating, scratch and smudge resistance and anti-static protection.
If ordering your glasses online, when selecting your Lens Type, choose a Blue Light Filter add-on.
If you're in-store, let our team members know you want to add a blue light filter to your glasses.
[View Our Glasses Range](https://www.oscarwylee.com.au/glasses.html)
How to add a Blue Light Filter to your glasses
STEP 1
Choose your frame
Select your frame from our wide selection of exclusive colours and
styles.
Our friendly teams are eager to help you find your perfect pair!
STEP 2
Add a Blue Light Filter (+$80) 
or Blue Light Premium Filter (+$90)
You can add a blue light filter to your optical glasses for an
additional fee.
If ordering your glasses online, when selecting your
Lens Type, choose a Blue Light Filter add-on.
If you're in-store, let our team members know you want
to add a blue light filter to your glasses.
Blue light filter is available with prescription glasses up to
1.67 index or with non-prescription glasses.
  
## What is Blue Light?
Blue light is found in the electromagnetic energy spectrum and is emitted from the sun. This is known as natural blue light. Artificial blue light is produced by screens and LED light bulbs which can affect your sleep and cause eye strain.
Blue light occurs naturally from the sun and your body uses it to help regulate its sleep-wake cycle. It does so by producing a hormone called melatonin at night in the absence of naturally occurring light.
### The Wavelength of Blue Light
The blue light spectrum has short waves, between a 380 and 500-nanometre range. Longer waves include things like microwaves, radio waves and ultraviolet waves.
Source: National Library of Medicine
Is Blue Light Bad For Your Eyes?
You may have experienced digital eye strain if after looking at your
screens for a long time you experience. The symptoms of this digital eye
strain, according to the Mayo Clinic include:
Blurred/double vision
Increased sensitivity to light
Dry or watery eyes
Sore, burning or tired eyes
Headaches

## Benefits of blue light lenses
Blue Light glasses can be worn to block artificial blue light that is emitted from digital screens. They may provide benefits such as:
* Ease eyestrain
* Improve quantity and quality of sleep
* Reduce visual fatigue
[View Our Glasses Range](https://www.oscarwylee.com.au/glasses.html)
## Ready for your Blue Light Filter?
Head into a store near you and ask about our blue light filter.
[Find your nearest location](https://www.oscarwylee.com.au/locations/full-store-list.html)
Need to renew your prescription?
Book an eye test
 
Show All
### Do you need a prescription for blue light glasses?
No! At Oscar Wylee, you can add a blue light filter to any pair of optical glasses–prescription or non-prescription. We offer many different types of lenses including [multifocals](https://www.oscarwylee.com.au/multifocal-lenses.html).
### How much are blue light glasses?
At Oscar Wylee a Blue Light Filter can be added to a pair of optical glasses for an additional $85, or $95 to add the Blue Light Filter Premium which includes an Anti-Reflective coating, scratch and smudge resistance and anti-static protection.
### How do I clean blue light glasses?
You can get rid of pesky smudges and fingerprints by simply cleaning your blue light glasses with the Oscar Wylee lens cleaner.
To avoid scratches, you shouldn’t place your glasses down on the lens. Rather place them in a glasses case or on the arms so the lens does not touch any surfaces.
At Oscar Wylee, we have a lifetime adjustment policy, meaning that if your blue light glasses get loose or feel uncomfortable, you can bring them in-store for an adjustment where one of our friendly staff will assist you.
## Do blue light glasses work?
While blue light glasses are effective in blocking blue light emitted from screens, it is still early in the research to determine the effectiveness of these filters and whether they are protecting your eyes from damage.
There are also many related vision problems caused by lengthy screen time that can instead fall under a term called Computer Vision Syndrome.
What is the wavelength of blue light?
The blue light spectrum has short waves, between a 380 and
500-nanometre range. Longer waves include things like
microwaves, radio waves and ultraviolet waves.

## What are Additional Ways to Reduce or Prevent Eye Strain and Computer Vision Syndrome?
Blue light glasses are just one way to possibly prevent the discomfort and symptoms of Computer Vision Syndrome.
Other ways include:
* Taking frequent breaks from screens to rest your eyes
* Blinking often to moisten your eyes
* Limiting your screen time where possible
* Enlarging the text on your screen for easier reading
* Using eye drops to refresh your eyes
* Turning on the blue light filter on your iPhone or Android.
## What are the Different Types of Blue Light Glasses?
The different types of blue light glasses can include gaming glasses, computer glasses, clear blue light glasses and kids blue light glasses. At Oscar Wylee, a blue light filter can be added on top of other lens options to suit your lifestyle, turning a standard pair of glasses into a specific type such as gaming or computer.
* Gaming glasses: Gaming glasses are designed to help gamers' eyes and often have lenses with a blue light filter, anti-reflective coating and a small amount of magnification to prevent squinting.
* Computer glasses: Computer glasses are glasses that often include an intermediate prescription to help you see a computer screen more clearly .They often will have an anti-reflective coating applied to them as well as having a blue light filter to help further reduce potential eye strain induced by the blue light.
* Clear blue light glasses: Some blue light glasses can have an amber tint added to the lenses which offers an extra buffer against blue light. At Oscar Wylee we provide clear blue light glasses that have no colour tint, only the blue light filter.
* Kid’s blue light glasses: At Oscar Wylee we have a [Kids Collection](https://www.oscarwylee.com.au/glasses/collection/kids-collection.html) with small and extra small frames to fit children which can be fitted with lenses containing a blue light filter. With exposure to digital devices at younger ages, it is important that kids are protected from artificial blue light.