# Source: https://www.oscarwylee.com.au/vivian-optical.html

# Vivian
1
## Frame Design of Vivian Glasses
The frame design of Oscar Wylee’s Vivian glasses is characterised by its cat eye shape, low nose bridge fit, and acetate frame. Vivian glasses are a sophisticated women’s glasses frame that will work for any occasion, whether the wearer wants to liven up their everyday style or complement a fun outfit for a day out. Oscar Wylee’s range of [women's cat eye glasses can be shopped online](https://www.oscarwylee.com.au/glasses/silhouette/cat-eye-glasses.html).
$169    
In stock
Only %1 left
2 pairs from $199
Discount auto-applied at checkout
3 pairs from $249
Discount auto-applied at checkout
Qty
Add to cart
Book an eye test
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
excluding prescription lenses
## About Vivian Sunglasses
Our cat eye shaped Vivian combines sophistication with modern flair. Designed for effortless comfort, this classy frame makes a statement from the office to date night. You’re sure to receive a second look!
| Frame fit | Measurements |
| --- | --- |
| Medium | 52 - 17 - 145 |
These measurements mean lens width, bridge, and temple length in millimetres (mm). They can be found on the inside of the temple arm. If you already have a pair that you like, you can compare it to these measurements.
### Made from Acetate
Oscar Wylee’s Vivian frame is a women’s cat eye glasses frame that is perfect for those with heart, square, pear, or diamond face shapes. The Vivian frame is a stylish, refined frame that blends well with your outfits or makes the perfect statement. The main specs of Oscar Wylee’s Vivian glasses frame, including dimensions, shape, materials, lenses, nose fit and hinges, are listed below.
Filter category 2 - General purpose sunglasses. Good protection against sunglare. Good UV Protection. Not suitable for driving in twilight, at night or under dull conditions 
This frame comes with tinted lenses. An additional $30 will be added to your order total for prescription orders. 

| Vivian Frame Features | vivian Frame Description | Dimensions | Shape | Materials | Lenses | Nose Fit | Hinges |
| --- | --- | --- | --- | --- | --- | --- | --- |
| The dimensions of the Vivian frame are measured in millimetres (mm) and are 52 - 17 - 145, meaning the lens width is 52 mm, the bridge is 17 mm, and the temple length is 145 mm. |
| The Vivian frame is a cat eye shape, well-suited to medium faces. |
| Vivian glasses are made from acetate. |
| The lenses that can be used in the Vivian frame are optical lenses, which include single vision and multifocal lenses and non-prescription lenses, which are plain and can have a filter, such as a blue light filter, applied. |
| The nose fit for Vivian is characterised by a low nose bridge fit. |
| The hinges in Vivian are normal hinges, also known as standard or barrel hinges. |
Show All
### What Inspired the Frame Design of Oscar Wylee's Vivian Glasses?
The Oscar Wylee Vivian frame design was inspired by the contemporary trend of cat eye-shaped glasses for women. Cat eye-shaped glasses are characterised by their pointed upper corners and round square bodies. The design of cat eye-shaped glasses was originally born out of the need for more variety in women’s glasses during the 1930s, which is when American artist Altina Schinasi designed the Harlequin frame, now known as cat eye-shaped glasses.
## What to Know About Oscar Wylee's Vivian Sunglasses?
There are many aspects of the Oscar Wylee Vivian frames that customers should know about, so they can decide whether this is the right frame for them. The Vivian frame is a woman's cat eye frame. Oscar Wylee’s Vivian frame is suitable for many face shapes, but particularly compatible with heart, square, pear, and diamond face shapes. The Vivian frame’s trendy design means that they are fashionable all year round. The Vivian glasses feature the standard [parts of glasses](https://www.oscarwylee.com.au/glasses/eye/part-of-glasses), such as a rim, temples, lenses, hinges and a low nose bridge fit.
### What are the Types of Temple Tips or Earpieces Included with Oscar Wylee's Vivian Glasses?
The type of temple tips or earpieces included in Oscar Wylee’s Vivian Glasses are made from acetate.
### What Type of Nose Bridge do Oscar Wylee's Vivian Glasses Have?
The type of nose bridge included in Oscar Wylee’s Vivian frame is a low nose bridge fit.
### What Type of Nose Pads are Included with Oscar Wylee's Vivian Glasses?
Oscar Wylee’s Vivian glasses do not include adjustable nose pads.
### What Type of Lenses do Oscar Wylee's Vivian Sunglasses Have?
The type of lenses that typically come with the Oscar Wylee Vivian glasses frame are optical lenses. Optical lenses are glasses lenses that have a prescription within the lens to help correct vision issues such as myopia, hyperopia and astigmatism. Vivian glasses can also come with non-prescription lenses, with add-ons such as a blue light filter. Vivian frames can be customised into sunglasses in-store or online with add-on tints or polarisation.
### What Material is Used for the Rim of Oscar Wylee's Vivian Glasses?
The material used for the rim of Oscar Wylee’s Vivian glasses frames is acetate. The rim refers to the part of a glasses frame that holds the lenses.
### What Type of Hinges are Included with Oscar Wylee's Vivian Glasses?
The type of hinges included with Oscar Wylee’s Vivian frames are normal hinges. These provide strength and smooth movement, connecting the frame’s arms and lenses.
## What Face Types are Most Suitable for Oscar Wylee's Vivian Glasses?
The face types that are most suitable for Oscar Wylee’s Vivian frame are heart, square, pear, and diamond face shapes. The Vivian frame is a cat eye shape, meaning that it complements the structure of heart, square, pear, and diamond faces particularly well. The Vivian frames help to balance the features of a [heart face shape](https://www.oscarwylee.com.au/glasses/face-shapes/heart), [square face shape](https://www.oscarwylee.com.au/glasses/face-shapes/square), [pear face shape](https://www.oscarwylee.com.au/glasses/face-shapes/pear), or a [diamond face shape](https://www.oscarwylee.com.au/glasses/face-shapes/diamond), bringing the eyes and brows forward in a flattering way. Although there are many [glasses for face shapes](https://www.oscarwylee.com.au/glasses/face-shapes) that may be considered more aesthetically suitable, it is important that people also choose the frames that make them feel most comfortable and represent their personal style.
## What Size Options are Available for Oscar Wylee's Vivian Glasses?
The size option available for Oscar Wylee’s Vivian frame is a medium-frame fit.
## What Materials are Used to Create Oscar Wylee's Vivian Glasses?
The materials used to create the Oscar Wylee Vivian frame are acetate. Acetate, also known as cellulose acetate, is a bioplastic made from cotton fibres or wood pulp. At Oscar Wylee, acetate glasses are made by adding a dye to cellulose acetate, which is rolled into a sheet. The shape of the glasses is then cut from this sheet.
## What’s Included
## OW Case &amp; Cloth
Protective Case and Lens Cloth
Our high-quality glasses case and lens cloth are included with every purchase of an Oscar Wylee frame. The stylish, magnetic case is made from a hard shell. This sturdy and durable material keeps your glasses protected and safe, wherever you go. Ensure your lenses are clean and scratch-free with our OW microfibre cloth, specifically designed to ensure you have comfortable vision through your lenses.
Oscar Wylee offers:
* Free Shipping on all orders
* 1 Year Warranty on frames and lenses
* Scratch resistance lens coating on all prescriptions
* UV-proof coating on all prescriptions
Health fund rebate: Once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. Learn more about [health funds](https://www.oscarwylee.com.au/health-funds.html).
## Make and Materials
Also known as cellulose acetate, these frames are traditionally hand-crafted by skilled craftsmen, with each frame passing through numerous stages of production and are hand-polished to ensure a glorious lustre. The frames then go through cleaning and strict quality control, and many pairs of crafting hands to be hand-assembled and polished. After your frames have gone through the production process, they are individually examined and&nbsp;packed before making their way to you!
## Warranty Information
### Warranty Information
### Warranty Information
Oscar Wylee provides a 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects. We will repair or replace faulty or defective frames or lenses free of charge for warranty claims made within 1 year of the delivery. We also offer repairs or replacement for problems experienced with vision during everyday use for claims made within 30 days of delivery. If the same product has been discontinued or is no longer available, then we may offer an exchange for a similar product or a refund.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Find a Store Location](https://www.oscarwylee.com.au/locations/full-store-list.html)