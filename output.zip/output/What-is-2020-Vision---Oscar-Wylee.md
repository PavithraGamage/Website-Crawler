# Source: https://www.oscarwylee.com.au/eye-care/eye-test/what-is-20-20-vision.html

# What is 20/20 Vision?
20/20 vision is a phrase used to describe a person's ability to see clearly at a distance of 20 feet. You might have come across this term from your friends and family declaring they have perfect vision. But is this actually what perfect vision looks like?Keep reading to find out what 20/20 vision means and how to know if you have it.
## What does 20/20 vision mean?
20/20 vision is a term that represents your visual acuity and is based on letter charts you see at the optometrist. It is used as a way of quantifying normal vision.
### What is visual acuity?
Visual acuity refers to how sharp and clear your vision is. Many people will have had a visual acuity test as it occurs when you have an [eye test](https://www.oscarwylee.com.au/eye-health/eye-test-info.html). Normal visual acuity can be described as 20/20 vision.
### What is the difference between 6/6 vision and 20/20 vision?
Although the phrase 20/20 vision is most commonly used, you may have also heard the term 6/6 vision. While in Australia we are more familiar with the phrase 20/20 vision, because we use the metric system, 20/20 vision isn’t relevant as this measurement is in feet. Therefore 20 feet converted into the metric system is 6 metres and that’s how we get 6/6 vision.
## How to read your glasses prescription
20/20 vision is measured using an eye chart known as a [Snellen eye chart](https://www.oscarwylee.com.au/eye-care/eye-test/snellen-chart) and is performed by an optometrist or an ophthalmologist. In a visual acuity test, you will be asked to read rows of letters set at a distance of 6 metres starting from the top and moving down. The letters will begin large and get smaller as you progress. You will read the Snellen chart one eye at a time then with both eyes. This would help determine if you would need a different prescription for each eye which is relatively common. The further down the chart you can see, the better your visual acuity is. However far down you can read on the snellen chart will then be compared to where someone with 20/20 vision can see as this is considered normal vision. Whatever the lowest line you read is represented as a fraction describing how clear your eyesight is. For example, if you can see further down the line than someone with 20/20 vision, your eyesight could be described as 20/15. If the furthest you can see is above the 20/20 vision line, you could have 20/40 vision.
## Is 20/20 vision perfect vision?
20/20 vision doesn't actually mean you have perfect vision, it is simply an indicator of a person with normal vision based on practical scientific consensus and is used as a benchmark to compare and test eyesight. A [2020 study by Optometry Australia](https://goodvisionforlife.com.au/2021/02/22/can-you-have-better-than-20-20-vision/) found that 26 percent of Australians have never had an eye exam because they believe they have perfect vision. Regular eye tests are an important part of taking care of your eye health. There are other aspects of vision that can mean you have ‘good’ eyesight, other than sharpness and clarity. These include:
* Depth perception - The ability to judge how far one object is away in relation to another object, and also from the viewer, by viewing an object adequately with both eyes.
* Peripheral vision - The part of your sight that is outside your central visual field, e.g. the sides of your vision.
* Colour perception - Your ability to perceive different wavelengths of light waves to see different hues.
## How to restore your vision to 20/20
Refractive errors cannot be reversed but there are some ways you can correct your vision.You can restore your vision to 20/20 by wearing prescription eyewear such as glasses and contact lenses or through Laser-assisted in-situ keratomileusis (LASIK) eye surgery and PRK (Photorefractive keratectomy) eye surgery. This is a procedure performed by an ophthalmologist that corrects refractive errors such as nearsightedness and farsightedness by reshaping the cornea, improving your visual acuity. There are also lifestyle changes you can make that can protect your eye health and minimise your risk of low visual acuity.
* Attend regular eye exams
* Ask your family members if there is a history of eye disease
* Wear sunglasses
* Avoid smoking and use of tobacco products
* Maintain a healthy diet and exercise routine
* Rest your eyes regularly if you are staring at a screen for long periods of time
Learn more about the different eye conditions that can affect your vision in our [eye test glossary](https://www.oscarwylee.com.au/glasses/eye/test-glossary).
## How to read your glasses prescription
If you need glasses, a prescription will specify the exact strength which is needed to correct your vision. Higher values indicate a stronger prescription. The glasses prescription usually consists of 3 main numbers:
SPH (Sphere)Indicates the amount of long - sightedness (denoted with a “+” symbol), or short-sightedness (denoted with a “-” symbol).
CYL (Cylinder)Represents the amount of astigmatism (denoted with a “-” symbol).
AXISSpecifies the angle between 0-180 degrees which corrects the astigmatism.Your PD (Pupil Distance) could also be found on your prescription. This is a measurement in millimetres of the distance between the optical centres and is used to ensure that your lenses are positioned properly to give you clear vision.PD value is required when ordering a new pair of glasses. Find out more about your [PD and how to measure it at home.](https://www.oscarwylee.com.au/measure_your_pd.html)
## When should I see an eye doctor?
You should have a regular eye test once every 2 years or as directed by your optometrist to take care of your eye health. If you are over 65, it is recommended you have an eye exam annually. You should also see your eye doctor if you notice any changes in your vision. These could include:
* Blurry eyesight
* Any eye pain
* Swelling of and around the eyes
* Double vision
* Noticing flashes or floaters in your vision
## Frequently asked questions about 20/20 vision
### Why do some people have less than 20/20 vision?
There are a number of eye conditions that can cause your vision to be less than 20/20. These can include reflective error and eye conditions.
Some refractive errors include:
* Myopia - Nearsightedness
* Hyperopia - Farsightedness
* Astigmatism - Irregular curvature of the eye
* Presbyopia - An age-related eye condition caused by loss of elasticity of the lens
Eye disorders
* Cataracts - Clouding of the lens causing blurry vision
* Glaucoma - A group of eye diseases that occur when the optic nerve is damaged, most commonly affecting a person's peripheral field
* Diabetes - Can cause diabetic retinopathy which damages the blood vessels in the retina
### How do you know if you have 20/20 vision?
To determine if you have 20/20 vision, you will need to book an eye test. An optometrist will perform an eye exam where you can find out if you have better than 20/20 vision, worse, or if your vision is normal.We recommend that everyone should have an eye test with an optometrist at least once every 2 years.Oscar Wylee offers bulk billed eye tests, so there are no out-of-pocket expenses for eligible Medicare card holders. [Book an eye test](https://www.oscarwylee.com.au/booking) today and find a [location](https://www.oscarwylee.com.au/locations/full-store-list.html) near you.
### Can you have better than 20/20 vision?
Yes! 20/20 vision is a measure of normal eyesight, therefore, you can have better than 20/20 vision. For example, you could have 20/10 vision meaning you can see clearly at 20 feet what a person with normal vision would need to be 10 feet away to see.
### Do I need glasses if I have 20/20 vision?
Yes. It is possible to still need glasses if you have 20/20 vision. Depending on your situation and eye health, such as if you have astigmatism, if you need even better focus than 20/20 vision or you are experiencing eyestrain related to near work. You should regularly visit an optometrist so they can detect any issues with your vision that could need correcting. Browse our complete [range of glasses](https://www.oscarwylee.com.au/glasses.html) to find your perfect pair.
### What are the minimum vision requirements for driving in Australia?
According to the [Austroads Medical standards for licensing](https://austroads.com.au/publications/assessing-fitness-to-drive/ap-g56/vision-and-eye-disorders/medical-standards-for-licensing-11), a person is not fit to drive if they have a bilateral uncorrected visual acuity worse than 6/12 (20/40).
### What can I expect to happen to my vision as I get older?
As you get older, your vision will change and may get worse, even if you have had 20/20 vision. Many people experience presbyopia which means they will have to use reading glasses. Ageing can also affect your ability to tell colours apart and you may struggle to adjust to changes in light.
## Need a new pair of glasses?
Visit your nearest store to browse our wide range of styles and colours.
All major health funds accepted in store.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
## Do you need your eyes tested?
Book an appointment with an Oscar Wylee optometrist to find out if you have 20/20 vision.
[Book an eye test](https://www.oscarwylee.com.au/booking)