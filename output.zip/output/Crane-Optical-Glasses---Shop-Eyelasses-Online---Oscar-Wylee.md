# Source: https://www.oscarwylee.com.au/crane-optical.html

# Crane
1
## Frame Design of Crane Glasses
The frame design of Oscar Wylee’s Crane glasses is characterised by its rectangle shape, nose pads and a metal and acetate frame. Crane glasses are a men’s, stylish frame that will work for any occasion, whether the wearer wants to liven up their everyday style or complement a fun outfit for a day out.
$169    
In stock
Only %1 left
2 pairs from $199
Discount auto-applied at checkout
3 pairs from $249
Discount auto-applied at checkout
Qty
Add to cart
Book an eye test
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
excluding prescription lenses
## About Crane Frames
Crane is a classic rectangular frame providing a minimalist look, taken to the next level by its lustrous finish. (P.S. The nose pads are super comfy.)
| Frame fit | Measurements |
| --- | --- |
| MEDIUM | 53 - 16 - 140 |
These measurements mean lens width, bridge, and temple length in millimetres (mm). They can be found on the inside of the temple arm. If you already have a pair that you like, you can compare it to these measurements.
### Made from Metal
Oscar Wylee’s Crane frame is a unisex rectangle glasses frame that is perfect for medium-width faces and those with round and oval face shapes. The Crane frame is a stylish, widely wearable frame that blends well with your outfits or makes the perfect statement. The main specs of Oscar Wylee’s Crane glasses frame including dimensions, shape, materials, lenses, nose fit and hinges are listed below.
| Crane Frame Features | Crane Frame Description | Dimensions | Shape | Materials | Lenses | Nose Fit | Hinges |
| --- | --- | --- | --- | --- | --- | --- | --- |
| The dimensions of the Crane frame are measured in millimetres (mm) and are 53 - 16 - 140, meaning the lens width is 53 mm, the bridge is 16 mm and the temple length is 140 mm. |
| The Crane frame is a rectangle shape, well suited to medium faces. |
| Crane glasses are made from a mixture of acetate, stainless steel and cupronickel. |
| The lenses that can be used in the Crane frame are optical lenses, which include single vision and multifocal lenses and non-prescription lenses, which are plain and can have a filter like a blue light filter applied. |
| Crane frames are fitted with adjustable nose pads. |
| The hinges in Crane glasses are spring hinges, which are more flexible than other types of hinges and can extend past 90 degrees. |
Show All
### What Inspired the Frame Design of Oscar Wylee’s Crane Glasses?
The Oscar Wylee Crane frame design was inspired by contemporary trends as rectangle glasses are often in fashion.
## What to Know About Oscar Wylee’s Crane Glasses?
There are many aspects of the Oscar Wylee Crane frames that customers should know about, so they can decide whether this is the right frame for them. The Crane frame is a men's rectangle frame. Oscar Wylee’s Crane frame is suitable for many face shapes but particularly compatible with round and oval face shapes. The Crane frame’s simple but essential design means that they are fashionable all year round. Crane glasses feature the standard [parts of glasses such as a rim, temples, lenses, spring hinges and nose pads.](https://www.oscarwylee.com.au/glasses/eye/part-of-glasses)
### What are the Types of Temple Tips or Earpieces Included with Oscar Wylee’s Crane Glasses?
The type of temple tips or earpieces included in Oscar Wylee’s Crane Glasses are made from acetate and the temples are made from cupronickel.
### What Type of Nose Bridge do Oscar Wylee’s Crane Glasses Have?
The type of nose bridge included in Oscar Wylee’s Crane frame is nose pads.
### What Type of Nose Pads are Included with Oscar Wylee’s Crane Glasses?
Oscar Wylee’s Crane glasses include standard nose pads. Nose pads are great for comfort and can also be adjusted for the perfect fit.
### What Type of Lenses do Oscar Wylee’s Crane Glasses Have?
The type of lenses that typically come with the Oscar Wylee Crane [glasses frame are optical lenses. Optical lenses are glasses lenses that have a prescription within the lens to help correct vision issues such as myopia, hyperopia and astigmatism. Crane glasses can also come with non-prescription lenses, with add-ons such as a blue light filter. Crane frames are currently unavailable as sunglasses online, however, customers can customise in-store and add on tint or polarisation.](https://www.oscarwylee.com.au/glasses.html)
### What Material is Used for the Rim of Oscar Wylee’s Crane Glasses?
The material used for the rim of Oscar Wylee’s Crane glasses frames is stainless steel. The rim refers to the part of a glasses frame that holds the lenses.
### What Type of Hinges are Included with Oscar Wylee’s Crane Glasses?
The type of hinges included with Oscar Wylee’s Crane frames are spring hinges. A spring hinge in a glasses frame refers to hinges that are more flexible than normal hinges and can go slightly beyond 90 degrees. Spring hinges can provide a closer fit to the face.
## What Face Types are Most Suitable for Oscar Wylee’s Crane Glasses?
The face types that are most suitable for Oscar Wylee’s Crane frame are round and oval face types. The Crane frame is a rectangle shape, meaning that it complements the structure of round and oval faces particularly well. The Crane frames help to balance the curved features of a [round face shape or an](https://www.oscarwylee.com.au/glasses/face-shapes/round)[oval face shape bringing the eyes and brows forward in a flattering way. Although there are many](https://www.oscarwylee.com.au/glasses/face-shapes/oval)[glasses for face shapes that may be considered more aesthetically suitable, it is important that people also choose the frames that make them feel most comfortable and represent their personal style.](https://www.oscarwylee.com.au/glasses/face-shapes)
## What Size Options are Available for Oscar Wylee’s Crane Glasses?
The size options available for Oscar Wylee’s Crane frame are a medium-frame fit across all colours.
## What Materials are Used to Create Oscar Wylee’s Crane Glasses?
The materials used to create the Oscar Wylee Crane frame are acetate, stainless steel and cupronickel. The rim is made from stainless steel, the nose bridge and temples are made from cupronickel and the temple tips are made from acetate. Acetate, also known as cellulose acetate, is a bioplastic, made from cotton fibres or wood pulp.
## What’s Included
## What's Included
Each pair of glasses comes with a stylish frame case and lens cloth. We offer free shipping across Australia and 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects.
* Free Shipping for Australian Orders
* 1 Year Warranty on frames and lenses
* Scratch resistance lens coating on all prescriptions
* UV-proof coating on all prescriptions
* Stylish case and cloth
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
## Make and Materials
The frames then go through cleaning and strict quality control, and many pairs of crafting hands to be hand-assembled and polished. After your frames have gone through the production process, they are individually examined and packed before making their way to you!As part of our durable frame family, some of our most popular styles, are now in stainless steel. These frames are hypoallergenic, corrosion resistant, light weight, and not sensitive to temperature changes.
                            
## Warranty Information
### Warranty Information
### Warranty Information
Oscar Wylee provides a 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects. 
We will repair or replace faulty or defective frames or lenses free of charge for warranty claims made within 1 year of the delivery.
We also offer repairs or replacement for problems experienced with vision during everyday use for claims made within 30 days of delivery. If the same product has been discontinued or is no longer available, then we may offer an exchange for a similar product or a refund.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Find a Store Location](https://www.oscarwylee.com.au/locations/full-store-list.html)