# Source: https://www.oscarwylee.com.au/glasses/how-to-remove-scratches

# How to Remove Scratches from Glasses
Published on April 17th, 2025
Updated on August 11th, 2026
Australia   
[Australia](https://www.oscarwylee.com.au/glasses/how-to-remove-scratches)
New Zealand

[Canada](https://oscarwylee.ca/glasses/how-to-remove-scratches)
Removing scratches from glasses by yourself may not be possible and is not recommended, as it could lead to further damage. It is generally advised to take your glasses to your optometrist so they can assess whether your lenses need to be replaced. Whether it's from accidentally dropping them, wiping the lenses with the wrong cloth, or everyday wear and tear, scratches can happen to even the most careful eyeglass wearers. However, you can significantly reduce the risk of scratching your lenses by taking precautionary steps when using and storing them.
See our Team In-Store For Any Eyewear or Eye Care Concerns
Our optometrists and retail team are dedicated to providing excellent optometry services.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Causes of Scratches](#causes) [Polishing Scratched Glasses](#polishing) [Buffing Scratched Glasses](#buffing) [Wearing Scratched Glasses](#wearing-scratched-glasses)
## Why do My Glasses Scratch So Easily?
Your glasses may scratch easily, potentially due to less durable scratch-resistant coatings, improper storage, incorrect cleaning methods and general dirt and debris. Glasses with less durable scratch-resistant coatings may be more susceptible to scratching. Leaving them around after using them and not returning them to their original case may also contribute to your glasses developing scratches, as it helps provide optimal protection. Using a rough material or strong chemicals may also cause scratches. This is why it is important to use lens cleaner specifically designed for ophthalmic lenses, or get an appropriate cleaning kit from your optometrist. If dirt and debris regularly get on your glasses and accumulate, the particles can potentially rub against your lenses, leaving a small mark. Rinse off dust first, then wipe with a clean microfibre cloth before and after use to help prevent this.
### Can you Polish Scratches Out of Glasses?
No, you cannot polish scratches out of glasses. Polishing scratches out of glasses won’t work, as the surface of the lens may be permanently damaged. Modern spectacle lenses have multiple surface coatings, and once these coatings are scratched, they cannot be restored by polishing without damaging the optical lens quality. As a result, replacing the lens is usually the only effective solution. An optometrist or optician will be able to examine how deep the scratches are and decide if the lenses need to be replaced. Polishing your glasses can help them look clearer and cleaner; however, you may still be able to see the scratches.
### Can you Buff Scratches Out of Eyeglasses?
No, you cannot buff scratches out of eyeglasses. Buffing is not generally recommended for glasses as it is too abrasive and can cause more scratches and damage. You will need to take your glasses to your optometrist so they can assess how severe or deep the scratch is and let you know if they need to be replaced. Buffing scratches out may be more in reference to the surfaces of cars and can work on superficial scratches that cannot be felt with your fingernail and involve removing the thin layer of the car’s clear coat with a buffing pad.
We Offer Bulk Billed Eye Tests!
See our team in-store or book your next appointment online.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
### Is Wearing Scratched Glasses Bad?
Yes and no; wearing scratched glasses can be bad if they obstruct your view. However, if the damage does not hinder your clear view, it may not necessarily be bad to wear scratched glasses. Scratches may also increase glare, halos and reduced contrast sensitivity, especially when driving at night.
### What are the Precautions when Using DIY Methods for Scratch Removal?
The precautions when using DIY methods for scratch removal include avoiding abrasive materials, using a proper lens cleaning solution and using a microfibre cloth. However, it is important to note that we do not advise customers to try removing scratches from their glasses themselves. These points are to emphasise the risk of further damage. The precautions when using DIY methods for scratch removal on glasses are listed below.
* Avoiding Abrasive Material: Avoid using abrasive material, as this can cause more scratches to your glasses. Abrasive materials can include certain types of clothing, paper towels, tissues and certain cleaning solutions.
* Using a Proper Lens Cleaning Solution: Use a proper cleaning solution, as some cleaning solutions may be too harsh for eyeglasses. It is recommended to use an approved lens cleaner, or one that is bought from an optometrist.
* Use a Microfibre Cloth: Use a microfibre cloth when wiping and/or cleaning your glasses, as its non-abrasive nature and fine fibres effectively trap dirt and dust without scratching the lenses.
### When to Seek Professional Help for Scratched Glasses?
You should seek professional help for scratched glasses when the scratches obstruct your vision. If the scratches are near your line of vision and become a nuisance, it may also be advisable to take them to your optometrist.
### How to Prevent Your Eyeglasses from Scratches?
To prevent your eyeglasses from scratches, ensure correct storage, handle your eyeglasses with care, check where your eyeglasses are before you sit and avoid keeping eyeglasses alone in pockets or bags. The ways to prevent your eyeglasses from scratches are listed below.
* Use proper storage: Use proper storage after every use. It is best to keep your glasses in the case they originally came with when they are not in use to prevent them from getting scratched and minimise dirt and debris.
* Check where your eyeglasses are before you sit: Always check where your eyeglasses are before you sit down, as this can prevent them from getting scratched or bent.
* Avoid keeping eyeglasses alone in pockets or bags: Avoid putting your eyeglasses alone in pockets or bags to prevent them from rubbing against potentially harsh material.
#### Can Regular Cleaning Help Prevent Eyeglasses Scratches?
Yes, regular cleaning, when done correctly, can help prevent scratches on your eyeglasses, as it can help remove any buildup of dirt and debris. However, the most important precaution is preventing abrasive material from rubbing against your glasses. This is especially important when [cleaning your eyeglasses](https://www.oscarwylee.com.au/eye-care/guides/how-to-clean-glasses), as many people mistakenly use the wrong types of cloth material or cleaning solution.
Read How to Remove Scratches from Glasses in other Oscar Wylee regions and their languages.
Australia   
[Australia](https://www.oscarwylee.com.au/glasses/how-to-remove-scratches)
New Zealand

[Canada](https://oscarwylee.ca/glasses/how-to-remove-scratches)
Major Health Funds Accepted In-store
For the purchase of frames and lenses, use your private health fund insurance to cover some of the cost.
[Explore health funds](https://www.oscarwylee.com.au/health-funds.html)
When was your last eye test?
At Oscar Wylee we offer bulk billed eye tests for eligible Medicare card holders.
[Book an eye test](https://www.oscarwylee.com.au/booking)