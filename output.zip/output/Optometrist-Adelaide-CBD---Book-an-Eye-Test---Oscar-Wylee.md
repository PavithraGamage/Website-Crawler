# Source: https://www.oscarwylee.com.au/locations/optometrist-rundle-mall.html

# Optometrist Rundle Mall
156 Rundle MallAdelaide SA 5000
* Opposite Target
Opening hours
Monday9:30am - 6:00pm
Tuesday9:30am - 6:00pm
Wednesday9:30am - 6:00pm
Thursday9:30am - 6:00pm
Friday9:30am - 9:00pm
Saturday9:30am - 5:00pm
Sunday10:30am - 5:00pm
*Store hours reflect local standard trading hours and exclude public holidays
[Visit our Rundle Mall Google Business page for directions, reviews, and updates.](https://g.page/r/CcNWD9x20UXgEAE)
Book Appointment
[Call us: (08) 8123 9047](tel:(08) 8123 9047)
[Leave a Review!](https://g.page/r/CcNWD9x20UXgEBM/review)
Our Reviews
Cameron McDonald
4 days ago
I have been going to Oscar Wylee in Rundle Mall for a number of years and they have always been plea...sant, good service and no hassles fixing any issues with the glasses.
See more
Lynnette Williams
1 week ago
Very polite and great sevice especally on a Sunday, thankyou Alice.
Jennifer Williams
2 weeks ago
Very helpful and friendly. Great service.
Jen Wilder
2 weeks ago
Attentive, helpful, friendly professional staff each time I've visited the Rundle Mall office. I've ...had adjustments made to my old glasses on an earlier visit, and most recently, I had my eyes tested. Thank you!
See more
Anne Forde
4 weeks ago
Great staff very helpful and optometrist took the time explained everything clearly to me
John Fisher
1 month ago
Kate Clarke
1 month ago
All the staff were very helpful and knowledgeable.
Would recommend.
Mandy OGrady
1 month ago
Mary was fantastic and explained everything very thoroughly. Lucy is a superstar, patient, very frie...ndly and knowledgeable. Fantastic service!
See more
Scarlett Anne
1 month ago
Great friendly staff, optometrists are thorough and lovely. Store is nice and calm.
Monique Callery
1 month ago
Mary made my eye test easy. She was lovely. Friendly and i felt comfortable. No hard sales either wh...ich was great!
Good choice of frames.
See more
Isobel Carracher
1 month ago
All good look forward to to receiving my new glasses!!!
Mark Hilton
1 month ago
Very friendly and knowledgeable staff from eye exam to glasses selection ????
Emma abdulla
1 month ago
Honestly 10 stars for Trinity! She was absolutely amazing with her skills and communication around m...y eyes. Very honest woman who enjoys helping and I felt so welcomed as a customer in her hands. I was later helped by a blonde lady who was amazing with helping me look at frames
See more
Sherryll Tobeck
2 months ago
My experience was great. Such a lovely team of ladies. Everything was explained in detail. Very help...ful. I would recommend Oscar Wylee Optometrist to my friends.
Thank you for your care at the Rundall Mall shop.
See more
Steven Plane
2 months ago
Jenelle Thomson
2 months ago
I visited Rundle Mall In Adelaide I had to cancel my appt With minimal notice . Bec was non judgemen...tal and happy for me to reschedule . Trinity the Optometrist was just fabulous Extremely friendly Informative and efficient A great choice of glasses too. I highly recommend Rundle Mall store
See more
Jenny Nitschke
2 months ago
dr.kainat Nazir
2 months ago
I highly recommend everyone for eye test at Oscar Wylee Optometrist. Whole staff is really good and ...professional. I fond Mary (optometrist) highly professional, keen and devoted to her work. The way she did eye test, I am really impressed. Thanks.
See more
Susan
2 months ago
Just walked in and was seen immediately for an eye test and given excellent advise about my dry eyes... and then chose 3 new glasses from a huge array of classy options. Great service and they know what they are doing.
See more
Niyas Manzoor
3 months ago
Natalia Ganem
3 months ago
michelle goody
3 months ago
My first time getting eyes tested, wonder customer service and a fantastic optometrist.
Great select...ion of frames, I'm excited to get mine when they're ready.
See more
Netrix Cardozo
3 months ago
The staff were very patient and attentive. I asked for advice on which type of glasses would suit me... best, and they helped me choose. The eye exam was quick and very efficient. Excellent staff. Thumbs up
See more
Brian Knott
3 months ago
A pleasant and personal experience. Everyone at Oscar Wylee was friendly and able to help with very ...personal attention and information. I highly recommend Oscar Wylee to anyone needing or wanting eye health and vision checks. And for grat help with glasses frames
Brian
See more
Ash Abfalter
3 months ago
Super friendly, super efficient, super affordable.  Just great actually
Peter McCurrach
3 months ago
Tracy Nguyen
3 months ago
Very friendly and kind staff. Smooth and easy
Jelai Co
3 months ago
Bianca Warnock
3 months ago
*edit, I received an apology call the following day. I appreciate the response. I will leave the com...ment as it reflects my experience at the time.
I was ignored by two staff at the counter who after several minutes of backs turned, looked up at me, ignored me further and returned to the work they had begun. Another staff member came in, looked at me and waited to be told to act (one of the two original staff simply turned and directed their head at me like 'here figure out what she wants'). This third person then did a great job triaging me, processing my initial tests and then the Optometrist I saw was very good too. I was asked by one of the original two staffers if I wanted help choosing frames but was actually inept at being friendly, suggestive of types, and had zero customer service skills.
The good balances the bad, but shows how awful the two staffers were. I'm not likely to return in the future if I have subsequent issues with the new glasses I've ordered. First time custom may not mean repeat.
If cheap glasses are indicative of cheap staff, reassess the business model and train staff, teach empathy in customer service, and show staff value in pay...and if that fails, pick better staff.
See more
Judykwok870
3 months ago
Alice examined my eyes, she's professional and helpful, explained to me patiently my conditions, tha...t eased my mind. Thank you.
See more
Luisa Leo
3 months ago
West lakes 10/10 Dieu, Hannah and jhenna gave me excellent service , greeted with a friendly
Smile r...ight away upon entering tick arrived early for an appointment they seen me right away no wait time and made me feel comfortable and very welcome. If your looking for great service that’s
Friendly and good quality then I would recommend west lakes OSCAR WYLEE
See more
isil kardas
3 months ago
The optometrist provides great service and accurate result!
Sascha Z
4 months ago
Highly recommend!
From the optometrists to the store staff, they are friendly, helpful, thorough and... professional.
See more
Encieh Sadat
4 months ago
Very well, I went there as an emergency and the medicine they prescribed was really good.
Yuliya Klymenko
4 months ago
The staff is super friendly and professional, really enjoyed service
Sharon Harvey
4 months ago
Trinity is lovely she explained everything in the appointment and made the choice much easier.  Bec ...made the choice of frames a breeze.
See more
Elle Brown
4 months ago
Optician who did CB my test was amazing- took time to explain things
sue Carbone
4 months ago
Ladies were so lovely and helpful from the floor staff to the optometrist.
Such a huge range of fram...es to choose from too.
See more
Pippa Clacherty
4 months ago
They were lovely, helped me pick out new glasses I really like.
Purichaya Ajjamnong
4 months ago
They are professional and offer a wide variety of products at affordable prices.
Julia Lian
5 months ago
Good experience~
Desma Moshou
5 months ago
Fantastic customer service. A joy going in there. And my glasses Wow. Can’t wait till they’re ready....
See more
Nagi Guirguis
5 months ago
Was very easy to make an appointment online, the staff were very nice and very helpful and the lady ...optometrist was professional and very thorough, thank you very much
See more
Lucy Slattery
5 months ago
Beck is very good at her job. She's an asset to your company &amp; this is my 4th pair of glasses from O...scar Wylee.
Everything seems to be an "add-on" &amp; the range seems a little bit limited in its styles &amp; colours, with lots of pairs that look almost identical.
I'm never too sure if I'm getting value for money, it often feels a bit rushed; but it's clean, convenient &amp; friendly .
See more
Qing Ling
5 months ago
Melissa Bedoya Rojas
5 months ago
Excellent service
wathsala senevirathne
5 months ago
hafifah humaida
5 months ago
very helpful, came to did a bit of adjustment for my glasses pads, but got fully adjusted and rebala...nced instead!! Lovely!!!
See more
Roj Chu
5 months ago
Amelia Hale
5 months ago
## Find an Optometrist in Adelaide - Rundle Mall With Oscar Wylee
Our Adelaide Oscar Wylee store in the Adelaide CBD is located in the iconic outdoor Rundle Mall, along the pedestrian road off Pulteney Street. We are close to the University of Adelaide and central to surrounding areas such as Fitzroy, Unley and Norwood. Oscar Wylee’s optometrists in Rundle Mall offer in-store bulk billed eye tests for same-day prescriptions to eligible Medicare cardholders. Here you can shop our variety of stylish frames, and find the lenses to suit your eyesight needs. 
When you have finished your appointment with us in Oscar Wylee Adelaide, check out the vast retail options Rundle Mall has to offer for a great shopping experience. There is everything from EB Games to Dymocks and Myer. You could also settle down for a slow and shaded walk, looking at the mall’s iconic artwork, such as Bert Flugelman’s Spheres (Mall's Balls). Visit our eyeglasses shop today to experience some of the best optometry services in Adelaide, Australia.         
Meet Our Team
* Optometrist Partner
B. Medsc (VisSc)
MOpt
Therapeutically Endorsed
* Store Manager
Certificate IV in Optical Dispensing (Ongoing)
Our Services
* Bulk Billed Eye Examinations
* Professional Frame Styling
* Frame Adjustments and Repairs
* Visual Fields Testing
* Digital Retinal Scanning
Show All
## Find an Optometrist in Rundle Mall, Adelaide for an Eye Health Test
Find an optometrist in Rundle Mall, Adelaide, for your regular eye health test. An eye test at Oscar Wylee Rundle Mall is bulk billed for eligible Medicare cardholders, however, the average price range for an optometrist in Rundle Mall can vary depending on factors such as the patient’s overall health. An eye test will look at a patient’s vision and also assess for eye diseases. For patients with more complex eye issues, our optometrists can refer them to an eye doctor, known in Australia as an ophthalmologist.
In Oscar Wylee Rundle Mall in Adelaide, you can browse our wide range of frames in many different colours, styles and sizes, available in optical glasses and prescription sunglasses. Visit Oscar Wylee Rundle Mall where our great staff, including an optometrist and optical dispenser, can help with your eye care and eyewear needs.
## How to Find an Optometrist in Rundle Mall, Adelaide?
To find an optometrist in Rundle Mall, Adelaide, you can take certain steps that can help make it easier for you such as searching online, assessing the store’s opening hours and finding the directions to your chosen location. The steps on how to find an optometrist in Rundle Mall are listed below.
1. Search online using the phrase, Rundle Mall optometrist near me. This can also be done here on the website via our locations page.
2. Click on the Oscar Wylee link, which will take you directly to our Rundle Mall optometrist store page.
3. See the store’s opening hours and where the store is located specifically.
4. Use the Rundle Mall Google Business page link located under store hours to see the directions on how to get to the store.
You can also find an optometrist in Rundle Mall, Adelaide by searching the keywords optometrist near me. If you have locations enabled on your smartphone and you’re in the Rundle Mall area, our Oscar Wylee Rundle Mall store page should appear easily for you to click on.
### Is it Hard to Get an Eye Appointment in Rundle Mall, Adelaide?
No, it is not hard to get an eye appointment in Rundle Mall. You can easily book an appointment to see an Oscar Wylee optometrist in Rundle Mall right here on this page. At Oscar Wylee we have highly qualified optometrists available for bulk billed eye appointments, which can be booked online, over the phone, or in-store.
#### How to Compare Optometrists in Rundle Mall to Each Other?
To compare optometrists in Rundle Mall, you can use factors such as eye tests offered, health fund coverage, lens types and add-ons and eyewear offered. To take care of your vision and eye health, it is important to receive an eye test at least once every two years. There are different types of tests that can be performed in an eye test and not all optometrists may offer the same tests. Health funds can be used to help cover some of the cost of your frames and lenses. To find out if your health fund is accepted at a Rundle Mall optometrist in Adelaide, visit their website. In the case of Oscar Wylee, we accept all major health funds and provide on-the-spot claims in-store. There are many different lens options available for prescription glasses such as single vision, multifocal and high index lenses. Most optometrists in Rundle Mall will offer these lenses although it is good to make sure. There are also lens add-ons available to enhance your glasses such as anti-reflective and blue light filters. Finally, if you are looking to purchase a pair of glasses after your eye test, you can compare the different styles and colours you are interested in from the optometrists in Rundle Mall, Adelaide. Oscar Wylee offers a wide range of frames with vintage and modern inspirations in bold colours and subtle designs.
#### How to Find an Eyeglasses Shop in Rundle Mall, Adelaide?
To find a glasses store in Rundle Mall, you can try to follow these simple steps including searching online, selecting a convenient location and looking at their health insurance policies.  The steps on how to find a glasses store in Rundle Mall, Adelaide are listed below.
1. Search online using the phrase, glasses store in Rundle Mall. This will provide you with various options for glasses stores in the whole Rundle Mall, Adelaide area.
2. Select a glasses store that is most convenient for you to travel to.
3. Click the link to find out more information such as opening hours, exact location and directions to the glasses store in Rundle Mall.
4. Read their health insurance policies to ensure you know what health benefits you have access to.
Our Oscar Wylee glasses store in Rundle Mall, Adelaide offers primary eye care services such as comprehensive eye tests as well as other services performed by an optometrist and offers prescription and non-prescription eyewear.
##### Is it Possible to Purchase Prescribed Sunglasses in Rundle Mall, Adelaide Without Seeing an Optometrist?
Yes and no, it is possible to [purchase prescribed sunglasses](https://www.oscarwylee.com.au/sunglasses.html) in Rundle Mall, Adelaide without seeing an optometrist if you already have a prescription that has not expired. If your prescription is expired, you can book an eye test to receive an updated or new prescription which will require you to see an optometrist. This will ensure your prescription sunglasses are appropriate for your visual needs.
## Where is the Oscar Wylee Rundle Mall Optometrist Located in Adelaide?
The Oscar Wylee Rundle Mall optometrist is located in Adelaide in the iconic outdoor Rundle Mall. Adelaide is the coastal capital city of South Australia.
### What is the Phone Number of Oscar Wylee Rundle Mall Optometrist Store?
The Oscar Wylee Rundle Mall optometrist store phone number is (08) 8123 9047. You can contact the Oscar Wylee Rundle Mall store between the hours of 9 am and 6 pm from Monday to Thursday, 9:30 am and 9 pm on Fridays, 9:30 am and 5 pm on Saturdays and 10:30 am and 5 pm on Sundays.
### What are the Reviews for Oscar Wylee Rundle Mall Optometrist in Adelaide?
The many reviews for Oscar Wylee Rundle Mall optometrist in Adelaide, left by our various customers can be found here on the website and online when you search for Oscar Wylee Rundle Mall optometrist. The reviews for Oscar Wylee Rundle Mall optometrist are listed below.
* Yewoong Kim:  Best service from Millie and Hannah! They helped me fix my glasses which I bent from walking into a door!
* Dr Wendy Ella Wright:  The eye test was so thorough, respectful, gentle and bulk billed by Medicare! I am so happy and feel so well looked after. Thank you for your professionalism and smiles.
* Paul Miller:  Everyone involved was efficient and professional yet at the same time friendly and keen to keep it a comfortable experience.
* Peter Gill:  Excellent, very professional staff &amp; optometrist. Fully covered by my health fund so very affordable.
#### What Treatments or Eye Care Processes are Done in the Oscar Wylee Rundle Mall Optometrist Location?
The treatments or eye care processes done in the Oscar Wylee Rundle Mall optometrist Adelaide location include a tonometry test, a digital photograph, a slit lamp exam and a refraction test. Additional tests that may also be performed can include a visual field test and a dilated fundus exam. The treatments or eye-care processes that are done in the Oscar Wylee Rundle Mall optometrist Adelaide location are listed below.
* A Tonometry Test: An optometrist or optical dispenser will conduct a tonometry test which involves the use of a machine that will release small puffs of air into your eyes. This will assist with measuring pressure in the eye.
* A Digital Photograph: An optometrist or optical dispenser may take a digital photograph of your eye which can be kept on record to use in future appointments to evaluate any changes to your eye.
* Slit Lamp Test: A slit lamp test can be used to evaluate your eye health, by examining your cornea and iris which are the anterior and posterior of the eye.
* Refraction Test: During a refraction test, an optometrist will have you view an image through different lenses and ask you to confirm which helps you see the image clearer.
* Visual Field Test: A visual field test can assist with assessing your peripheral vision, which may be beneficial for identifying any signs of glaucoma.
* Dilated Fundus Exam: A dilated fundus exam can help an optometrist assess your health in more detail by getting a clear view of the retina. This test is typically carried out for patients with diabetes and those who may be at risk of developing retinal damage.
## How Many Optometrists Exist in Rundle Mall, Adelaide?
There are many optometrists that exist in Rundle Mall, Adelaide to provide eye tests and glasses, including Oscar Wylee. The number of optometrists available in an area will typically depend on the population. At Oscar Wylee Rundle Mall, we offer excellent optometry services including eye tests performed by skilled optometrists using high-quality equipment. We also have a wide range of fashion-forward frames that customers can browse in a large selection of sizes and colours. If you’re looking for an optometrist in Rundle Mall, choose Oscar Wylee and we will take care of your optometry and eyewear needs.
### What are the Other Closest Optometrist Locations to Rundle Mall, Adelaide in Australia?
The other closest Oscar Wylee optometrist locations to Rundle Mall in Australia are Marion, West Lakes and Tea Tree Plaza. The locations and their distance from Rundle Mall are listed below.
* Marion:  Marion is close to Rundle Mall, around 14-15 km. The [Oscar Wylee Marion](https://www.oscarwylee.com.au/locations/optometrist-marion.html) store is located in Westfield Marion, near Big W. Oscar Wylee Marion provides bulk billed eye tests, visual field testing and frame adjustments and repairs.
* West Lakes:  West Lakes is close to Rundle Mall, around 14-15 km. The [Oscar Wylee West Lakes](https://www.oscarwylee.com.au/locations/optometrist-west-lakes.html) store is located in Westfield West Lakes opposite the Universal Store. For fashion-forward frames and comprehensive eye tests, visit Oscar Wylee West Lakes.
* Tea Tree Plaza:  Tea Tree Plaza is close to Rundle Mall, around 15 km. The [Oscar Wylee Tea Tree Plaza](https://www.oscarwylee.com.au/locations/optometrist-tea-tree-plaza.html) store is located in Modbury, South Australia, near Bevilles Jeweller. Visit Oscar Wylee Tea Tree Plaza for visual fielding testing and digital retinal scanning.
### Oscar Wylee Offers Bulk Billed Eye Tests
Book your eye health test at our Oscar Wylee Adelaide eyeglasses store at Rundle Mall. We bulk bill our eye test to Medicare, so you can update your prescription with our trained Oscar Wylee optometrists. We'll make sure your eyesight and eye health needs are covered with our vision testing in approximately 30 minutes! Choose our Oscar Wylee Adelaide optometrist to provide essential eye care processes such as having your vision assessed and eye health checked for certain eye diseases and conditions.
### Leading Health Funds Accepted at Oscar Wylee
Oscar Wylee Adelaide in Rundle Mall accepts major health funds for our prescription glasses and prescription sunglasses including Medibank, Bupa and HBF. Rebates are offered for those with valid health funds. Our excellent staff in-store can help you process your claim and provide an on-the-spot quote. We’re here to help you save big on Oscar Wylee frames and lenses. Visit Oscar Wylee Adelaide and our team can help you navigate the ins and outs of your health fund.
### Expert Styling Advice in Adelaide
Our friendly staff at Oscar Wylee Adelaide in Rundle Mall provide expert styling advice to help you find the perfect pair of glasses or sunglasses, every time. In-store you can get fitted for frames and choose from our different lens options like multifocals or polarisation. You can also customise and optimise your new pair of glasses with Oscar Wylee’s different lens coatings such as anti-reflective coatings and blue light filters. No matter if you’re buying a pair of prescription glasses or prescription sunglasses, Oscar Wylee Adelaide has got you covered.
Book Appointment
[Call us: (08) 8123 9047](tel:(08) 8123 9047)
[Leave a Review!](https://g.page/r/CcNWD9x20UXgEBM/review)