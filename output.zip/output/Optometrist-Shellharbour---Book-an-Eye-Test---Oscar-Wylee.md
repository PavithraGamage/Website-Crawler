# Source: https://www.oscarwylee.com.au/locations/optometrist-shellharbour.html

# Optometrist Shellharbour
Stockland ShellharbourGround Level, Shop 1054211 Lake Entrance RoadShellharbour City Centre NSW 2529
* Near Vodafone
Opening hours
Monday9:00am - 5:00pm
Tuesday9:00am - 5:30pm
Wednesday9:00am - 5:30pm
Thursday9:00am - 9:00pm
Friday9:00am - 5:30pm
Saturday9:00am - 4:00pm
Sunday10:00am - 4:00pm
*Store hours reflect local standard trading hours and exclude public holidays
[Visit our Shellharbour Google Business page for directions, reviews, and updates.](https://g.page/r/CRl1d60gWgm7EAE)
Book Appointment
[Call us: (02) 4296 8987](tel:(02) 4296 8987)
[Leave a Review!](https://g.page/r/CRl1d60gWgm7EBM/review)
Our Reviews
clare craven
4 weeks ago
Really happy, so much more thorough and cheaper than specsavers. After many attempts from specsavers... and costly glasses I ended up coming here and these guys got my prescription right and found something on the wall of my eye that will need to be monitored.
See more
lloyd bushnell
1 month ago
Very friendly and professional staff.
Highly recommend.
Iisa Bazzano
1 month ago
Excellent service from a friendly and professional team who made the whole experience easy and comfo...rtable, I highly recommend this optometrist for their genuine care and attention to detail. And even a follow up phone call.. 5 star team!
See more
Leanne Bow
1 month ago
Fantastic! The staff were super helpful, kind and friendly. I would definitely recommend anyone to g...o Oscar Wylee at Shellharbour
See more
Robert and Josie Frencham
1 month ago
I had a very bad experience with another Optometrist and they went out of their way to make me feel ...heard and listen to my concerns. Both the Optometrist and staff went over and beyond in their help.
See more
Giovanna Boghi
1 month ago
Lydia Withers
1 month ago
I had such a fantastic experience at the Shellharbour Oscar Wylee, thanks to Isaac. From the moment ...I walked in, he was friendly, patient, and incredibly helpful. He took the time to help me choose the perfect pair of glasses, offering honest advice and making the whole process so easy and enjoyable.
Isaac truly went above and beyond with his customer service. He was knowledgeable, never made me feel rushed, and genuinely cared about making sure I was happy with my purchase. It’s rare to come across service like this these days, and it made all the difference.
Thank you, Isaac, for such an outstanding experience. I highly recommend asking for him if you’re looking for new glasses!
See more
Brooke Spiteri
2 months ago
I had such an enjoyable experience at Oscar Wylee. From the moment I walked in, the entire team was ...friendly, welcoming, and made me feel comfortable straight away.
The whole staff were fantastic, but Isaac was just beautiful. He was incredibly kind, honest, and genuine, and took the time to make sure I found the right option without ever making me feel pressured. His warm nature and exceptional customer service really stood out and made the experience even more enjoyable.
It's clear that customer care is a priority here. I left feeling well looked after and couldn't be happier with my experience. Highly recommend! ????✨
See more
Alex McDonald
2 months ago
Excellent - thanks for your help
Angela Naumovski
2 months ago
Every visit to this store has been exceptional, thanks to the friendly and incredibly helpful staff.... They always make me feel comfortable and valued. Recently, when I experienced an eye issue, they immediately booked me in with the optometrist. Furthermore, during a follow-up to check a new prescription, the optometrist went completely out of his way to ensure total accuracy. The entire team truly went above and beyond to reassure me, making it clear I can contact them anytime if further issues arise.
See more
Janice Hurley
2 months ago
I was able to book same day eye consultation. The staff were exceptionally helpful and knowledgeable... about their products. The eye examination was a stress-free experience and extremely informative. Thank you.
See more
Christine Bailey
2 months ago
Narelle Fitzpatrick
2 months ago
Janine Santry
2 months ago
Very professional, fabulous customer service and great frames to chose from for a great prices
Andrew Tolhurst
3 months ago
Montana Smith
3 months ago
David Sheaffe
3 months ago
Another great experience at the store. Makena was super helpful in assisting in frame selection and ...was a pleasure to deal with.
See more
Natalie Boland
3 months ago
Really great experience at Oscar Wylee Shellharbour. The gentleman and woman there were both so help...ful and friendly, and the eye specialist was very informative too. Such a lovely team.
See more
Caroline Dunlop
3 months ago
Isaac and the team at the Shellharbour branch provided an exceptionally memorable and wonderful expe...rience. Isaac's extensive product knowledge and detailed information greatly assisted me in selecting my new frames. Isaac possesses a warm spirit, is charismatic, and demonstrates a professional yet personalised approach, which was truly delightful. I highly recommend Isaac and the team at Shellharbour for your eyewear requirements.
See more
Tara Field
3 months ago
The staff were absolutely fantastic. I would highly recommend.
Allira Murphy
3 months ago
Staff and optometrist were incredibly friendly and helpful
Taisha Woods
4 months ago
The team at Oscar Wylee at Shellharbour are so amazing. Getting glasses can be a worrisome experienc...e but the team here make you feel so comfortable and welcome. They are extremely helpful nothing is too much trouble and they made my selection experience so fast and easy. I would recommend them to everyone getting new glasses. Thank you team Shellharbour
See more
Becky Guggisberg
4 months ago
Professional and caring. I love the team at Shellharbour - the examination is accurate &amp; well explai...ned, the staff are super kind when selecting glasses &amp; have a 'good eye' for what frames suit your face.
See more
Kajal Mehla
4 months ago
I recently visited Oscar Optometrist and was thoroughly impressed with the service I received. From ...the moment I walked in, the staff were welcoming and professional, making me feel at ease. The optometrist was knowledgeable and took the time to explain each step of the eye exam, ensuring I understood everything clearly. They used state-of-the-art equipment, which gave me confidence in the accuracy of the results.
What stood out most was the personalized attention I received. The optometrist listened carefully to my concerns and tailored the exam to address my specific needs.
Overall, I highly recommend Oscar Optometrist to anyone in need of eye care. Their commitment to providing excellent service, combined with their friendly and professional approach, makes them a top choice. I will definitely be returning for my future eye care needs.
See more
Alison Visser
5 months ago
The staff were really welcoming, helpful and professional, and not pushy. Thank you for a great expe...rience ????
See more
Sharon Wonnocott
5 months ago
Service was fantastic and also the range was extensive, very happy ????
Maddie White
5 months ago
The team here are so great! Makena especially was so lovely and helpful!!
Renad Al-asali
5 months ago
The staff are friendly and highly skilled at what they do. My kids get their eyes tested there every... year, and we always leave with big smiles on our faces. ????
See more
Shelby Moses
5 months ago
Super friendly and helpful staff!
Terry Selby
6 months ago
Easy visit.  Test done.  Check againt last year findings. Pick out frames. Process. Done. Wait for g...lasses to arrive. Thank you
See more
Belinda King
6 months ago
Friendly and helpful staff
Zoe Mcmahon
6 months ago
The pre test lady was fabulous…polite, pleasant, efficient and funny while being professional in her... tasks.
My eye test was performed efficiently and professionally, as usual, which is why I keep coming back. I didn’t buy my frames from you as I feel they are often  too heavy and big for my face and you don’t seem to have appetite range that suits my tastes. I have two frames from you however that still wear.
See more
Carlos rodrigues
6 months ago
JOSEPHINE SIMPSON
6 months ago
Went to the Oscar Wylee Shellharbour store .the customer service was excellent  I had after having a...n eye test ,need driving glasses and updated reading glasses the choice of style was fantastic. The price is great value, I would highly recommend them to everyone.
See more
Emma Ridley
6 months ago
Honestly one of the best experiences I’ve had getting glasses from any store.
I’d love to give Isaac... a massive shout out, his customer service is incredible and was genuinely helpful.
See more
Leeanne Caddick
6 months ago
Staff were lovey ,very helpful and professional . Great range of fashionable glasses.. I will defini...tely come back and recommend to others
See more
Chloe De Freitas
6 months ago
Janice Greening
7 months ago
⭐️⭐️⭐️⭐️⭐️ Amazing experience at Oscar Wylee Shellharbour!
My experience at Oscar Wylee Shellharbou...r was fantastic. From the moment I arrived, I was greeted by a warm, friendly, and highly professional team. The optometrist was thorough and took the time to explain everything during my eye test, making sure I felt at ease the entire time.
When it came to choosing frames, the staff were incredibly helpful, offering honest advice without any pressure. Their range of stylish glasses is beautiful, and I couldn’t be happier with my new pair.
The whole visit was smooth, relaxed, and genuinely enjoyable. I felt truly cared for and would highly recommend Oscar Wylee Shellharbour to anyone seeking exceptional eye care and outstanding service.
See more
John Healey
7 months ago
Wonderful service and attention by all staff
Diane McLauchlan
7 months ago
Very pleased with the test as I have very complicated eyesight. The optometrist &amp; Manager showed me ...a lot of help.
See more
MArk Helson
7 months ago
It was great &amp; easy no waiting &amp; good service.
Laurinda Kelly
7 months ago
Always have a fantastic experience at Oscar Wyler Shellharbour. So helpful, friendly &amp; experienced. ...The range of glasses is amazing &amp; vibrant too. Thank you.
See more
Monique Headington
7 months ago
Friendly, helpful and efficient! :)
Kristijan Krcoski
7 months ago
Amazing customer service!
I came in for a simple frame adjustment unaware that my glasses were beyo...nd repair and were discontinued - Sam went above and beyond and somehow found an exact replacement for the frames.
I really appreciate the effort Sam went to assist me - would highly recommend OW Shellharbour.
See more
John
7 months ago
Well done
Ruth Eton
7 months ago
Great staff very helpful and really thorough
And profession eye specialist. Excellent all round. And... great glasses!!!
See more
Donna Morgan
8 months ago
I received excellent service and care. I was served by Isaac who was very intentional about producin...g the best service. Sam was excellent with helping my select the right style for my face which is always a challenge. Highly recommend
See more
Daniel Barkeit
8 months ago
Very helpful and friendly service by shop manager and very good optometrist.
Annabelle Gibson
8 months ago
Really good experience. Professional, polite and helpful. The best optometrist at the Shellharbour s...quare.
See more
A Google User
8 months ago
## Find an Optometrist in Shellharbour With Oscar Wylee
Nestled between Wollongong and Kiama, our Oscar Wylee store can be found in the Shellharbour Stockland Shopping Centre. Located on the ground level, our Oscar Wylee Shellharbour optometrists are on hand to provide Medicare bulk billed eye tests, and our staff can help you shop our range of stylish and affordable frames- all in one day! You can use the centre’s free parking or take one of the buses that service the centre, to make your appointment with us. 
If you have time after your appointment, why not explore the range of beaches and picturesque coastal sites that surround the Shellharbour area. If you want some excitement, Kiama’s famous blowhole is just a 20-minute drive away from the centre! Our team and optometrists at Oscar Wylee Shellharbour would be more than happy to assist you with their eye health and vision services. If you live in the Oak Flats, Blackbutt or Barrack Heights areas, come in and see us at our Stockland Shellharbour store!        
Meet Our Team
* Optometrist
* Store Manager
Our Services
* Bulk Billed Eye Examinations
* Professional Frame Styling
* Frame Adjustments and Repairs
* Visual Fields Testing
* Digital Retinal Scanning
Show All
## Find an Optometrist in Shellharbour, NSW for an Eye Health Test
An optometrist in Shellharbour, NSW can offer prescription glasses to help correct refractive errors such as nearsightedness or farsightedness. If your condition requires further diagnosis, Oscar Wylee Shellharbour can refer you to an eye doctor. If you require minor repairs for your eyewear including prescription sunglasses, you can count on our qualified optical dispenser by visiting us in-store. If you have any vision concerns or just need to have your regular eye check-up, you can make an appointment here online for an eye health test in Shellharbour. As part of Australia’s Medicare system, you have access to our services at a bulk billed price. Early detection of eye diseases can help significantly, so it is recommended to have your eyes checked at least once every two years or once every year if you are 65 years or older.
During an eye test, you can expect to be taken through a few different tests using certain tools that help to examine different regions of the eye. Factors such as the number of available optometrists in the area, the equipment used and the status of your condition may determine the average price for an optometrist in Shellharbour.
## How to Find an Optometrist in Shellharbour, NSW?
To find an optometrist in Shellharbour, NSW you can take certain steps that can help make it easier for you such as searching online, assessing the store’s opening hours and finding the directions to your chosen location. The steps on how to find an optometrist in Shellharbour are listed below.
1. Search online using the phrase, Shellharbour optometrist near me. This can also be done here on the website via our locations page.
2. Click on the Oscar Wylee link, which will take you directly to our Shellharbour optometrist store page.
3. See the store’s opening hours and where the store is located specifically.
4. Use the Shellharbour Google Business page link located under store hours to see the directions on how to get to the store.
You can also find an optometrist in Shellharbour by searching the keywords optometrist near me. If you have locations enabled on your smartphone and you’re in the Shellharbour area, our Shellharbour store page should appear easily for you to click on.
### Is it Hard to Get an Eye Appointment in Shellharbour, NSW?
No, it is not hard to get an eye appointment in Shellharbour. You can easily book an appointment to see an Oscar Wylee optometrist in Shellharbour right here on this page. At Oscar Wylee we have highly qualified optometrists available for bulk billed eye appointments, which can be booked online or in-store.
#### How to Compare Optometrists in Shellharbour to Each Other?
To compare optometrists in Shellharbour, you can use factors such as eye tests offered, health fund coverage, lens types and add-ons and eyewear offered. To take care of your vision and eye health, it is important to receive an eye test at least once every two years. There are different types of tests that can be performed in an eye test and not all optometrists may offer the same tests. Health funds can be used to help cover some of the cost of your frames and lenses. To find out if your health fund is accepted at Shellharbour optometrist in NSW, visit their website. In the case of Oscar Wylee, we accept all major health funds and provide on-the-spot claims in-store. There are many different lens options available for prescription glasses such as single vision, multifocal and high index lenses. Most optometrists in Shellharbour will offer these lenses although it is good to make sure. There are also lens add-ons available to enhance your glasses such as anti-reflective and blue light filters. Finally, if you are looking to purchase a pair of glasses after your eye test, you can compare the different styles and colours you are interested in from Shellharbour optometrists in NSW. Oscar Wylee offers a wide range of frames with vintage and modern inspirations in bold colours and subtle designs.
#### How to Find an Eyeglasses Shop in Shellharbour, NSW?
To find a glasses store in Shellharbour, you can try to follow these simple steps including searching online, selecting a convenient location and looking at their health insurance policies. The steps on how to find a glasses store in Shellharbour, NSW are listed below.
1. Search online using the phrase, glasses store in Shellharbour. This will provide you with various options for glasses stores in the whole area of Shellharbour.
2. Select a glasses store that is most convenient for you to travel to.
3. Click the link to find out more information such as opening hours, exact location and directions to the glasses store in Shellharbour.
4. Read their health insurance policies to ensure you know what health benefits you have access to.
Our Oscar Wylee glasses store in Shellharbour, NSW offers primary eye care services such as comprehensive eye tests as well as other services performed by an optometrist and offers prescription and non-prescription eyewear.
##### Is it Possible to Purchase Prescribed Sunglasses in Shellharbour, NSW Without Seeing an Optometrist?
Yes and no, it is possible to [purchase prescribed sunglasses](https://www.oscarwylee.com.au/sunglasses.html) in Shellharbour, NSW without seeing an optometrist if you already have a prescription that has not expired. If your prescription is expired, you can book an eye test to receive an updated or new prescription which will require you to see an optometrist. This will ensure your prescription sunglasses are appropriate for your visual needs.
## Where is the Oscar Wylee Shellharbour Optometrist in NSW Located?
The Oscar Wylee Shellharbour optometrist is located at the Stockland Shellharbour Shopping Centre which is located at 211 Lake Entrance Rd. The Oscar Wylee Shellharbour store can be found on the ground level near Vodafone.
### What is the Phone Number of Oscar Wylee Shellharbour Optometrist Store?
The Oscar Wylee Shellharbour optometrist store phone number is [(02) 4296 8987](tel:(02) 4296 8987). You can contact the Oscar Wylee Shellharbour store between the hours of 9 am and 5:00 pm on Monday, Tuesday, Wednesday, and Friday, on Thursday between 9 am and 9 pm, on Saturday between 9 am and 4 pm and on Sunday between 10 am and 4 pm.
### What are the Reviews for Oscar Wylee Shellharbour Optometrist in NSW?
The many reviews for Oscar Wylee Shellharbour optometrist in NSW, left by our various customers can be found here on the website and online when you search for Oscar Wylee Shellharbour optometrist. The reviews for Oscar Wylee Shellharbour optometrist are listed below.
* D:  So glad to have had my eye examination conducted by Steve Anastovski. He is the best in the business! The whole team were lovely &amp; personable.
* Alan Pyper:  Great service from the staff at Shellharbour Oscar Wylee, efficient, professional and friendly. I received a very thorough eye test and had plenty of time to choose my frames from their extensive range. I would definitely recommend them.
* Lee Rosewarn:  Always friendly &amp; helpful staff.
* Adrienne Matthews:  I found the Optometrist and Staff were very professional and was impressed with their explanations regarding my eye test.
* Marea Beetson:  My husband and I had our eyes tested and found it to be a pleasant and stress free experience. The staff were efficient and very accommodating.
#### What Treatments or Eye Care Processes are Done in the Oscar Wylee Shellharbour Optometrist Location?
The treatments or eye care processes done in the Oscar Wylee Shellharbour optometrist NSW location include a tonometry test, a digital photograph, a slit lamp exam and a refraction test. Additional tests that may also be performed can include a visual field test and a dilated fundus exam. The treatments or eye-care processes that are done in the Oscar Wylee Shellharbour optometrist NSW location are listed below.
* A Tonometry Test: An optometrist or optical dispenser will conduct a tonometry test which involves the use of a machine that will release small puffs of air into your eyes. This will assist with measuring pressure in the eye.
* A Digital Photograph: An optometrist or optical dispenser may take a digital photograph of your eye which can be kept on record to use in future appointments to evaluate any changes to your eye.
* Slit Lamp Test: A slit lamp test can be used to evaluate your eye health, by examining your cornea and iris which are the anterior and posterior of the eye.
* Refraction Test: During a refraction test, an optometrist will have you view an image through different lenses and ask you to confirm which helps you see the image clearer.
* Visual Field Test: A visual field test can assist with assessing your peripheral vision, which may be beneficial for identifying any signs of glaucoma.
* Dilated Fundus Exam: A dilated fundus exam can help an optometrist assess your health in more detail by getting a clear view of the retina. This test is typically carried out for patients with diabetes and those who may be at risk of developing retinal damage.
## How Many Optometrists Exist in Shellharbour, NSW?
Many Oscar Wylee optometrists exist in Shellharbour, NSW to provide eye tests and glasses, including Oscar Wylee. The number of optometrists in Shellharbour may be due to the number of residents in the area and the geographical size of the suburb. If you need essential eye services such as a comprehensive eye test, a wide selection of prescription eyewear and more, then choose Oscar Wylee as your first choice for optometry services.
### What are the Other Closest Optometrist Locations to Shellharbour, NSW in Australia?
The other closest Oscar Wylee optometrist location to Shellharbour, NSW in Australia is Wollongong. Wollongong is close to Shellharbour, around 29 km in distance and is located at Wollongong Central Shopping Centre. The [Oscar Wylee Wollongong](https://www.oscarwylee.com.au/locations/optometrist-wollongong-central.html) store can be found at 200 Crown Street opposite City Beach. Here you can receive quality eye tests, professional eye care and assistance.
### Bulk Billed Eye Tests at Shellharbour
Make Oscar Wylee Shellharbour your go-to for excellent eye care services. When you come into our eyeglasses shop, you can have your prescription updated and shop for your new pair of eyeglasses on the same day. Our trained eye care professionals at Oscar Wylee Shellharbour can update your prescription or issue a new one, usually in under 20 minutes. With the recommended frequency of eye health tests and vision testing being at least once every two years, Oscar Wylee Optometrists at Shellharbour can keep you up to date on your eyesight and eye health needs.
### Health Funds Accepted at Oscar Wylee Shellharbour
Oscar Wylee Shellharbour accepts major health funds in Australia. Our team at Oscar Wylee Shellharbour will be able to process your claim at our eyeglasses shop with a valid health fund card. We understand how confusing insurance policies can be but you can be certain, here at Oscar Wylee Shellharbour, we will do our best to help you with every aspect of your health fund.
### Fashion-Forward Frames at Oscar Wylee
We offer prescription eyeglasses and prescription sunglasses in a variety of modern and vintage-inspired styles at our Oscar Wylee Shellharbour store. You may choose to customise your glasses with one of our lens options. Our experts in our eyeglasses shop are qualified to help determine what may work best for you and your lifestyle. We’ll help you leave our Oscar Wylee Shellharbour store with a pair of prescription glasses or prescription sunglasses that work for your style and prescription needs.
Book Appointment
[Call us: (02) 4296 8987](tel:(02) 4296 8987)
[Leave a Review!](https://g.page/r/CRl1d60gWgm7EBM/review)