# Source: https://www.oscarwylee.com.au/glasses/blue-light

# What is Blue Light from Digital Devices?
Published on February 2nd, 2023
Updated on October 17th, 2024
Australia    
[Australia](https://www.oscarwylee.com.au/glasses/blue-light)
[Canada](https://oscarwylee.ca/glasses/blue-light)
[Canadian French](https://oscarwylee.ca/fr/glasses/blue-light)
Blue light from digital devices refers to HEV (High-Energy Visible) light, similar to ultraviolet rays, that are found in digital screens such as tablets and smartphones. Blue light is also emitted from the sun. The blue light definition is a high energy light source that is measured in nanometres (nm). Blue light wavelengths measure between 380 to 500 nanometers, according to UC Davis Health.Blue ray light is unique because the eyes cannot filter it as effectively as other colours of light, meaning more blue light reaches the eyes than any other light on the spectrum. It has been theorised that blue light, especially from digital devices, may negatively affect the eyes by disrupting sleep cycles and causing eye fatigue, eye strain and ocular migraines. People may be able to limit the effects of extended blue light exposure by resting the eyes, wearing blue light glasses or by finding anti-blue light settings, products and apps for computers, phones and televisions.
Look after your eyes at Oscar Wylee
Book an eye test with one of Oscar Wylee optometrists, bulk billed for eligible Medicare cardholders.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Definition](#Definition) [Effects of Blue Light](#Effects-of-Blue-Light) [Common Concerns](#Common-Concerns) [Protection](#Protection)
## Where Does Blue Light Come From?
Blue light comes from natural sunlight and artificial sources such as smartphones, tablets, LED screens and computer screens. The natural sources of blue light are the sun, and its light. Sunlight is a constant in everyday life and causes the body to feel awake, energetic and functional. Blue light in smartphones and tablets has the same amount of wavelengths and comes from the LED lights used to make the screens.
### What are the High-Energy Blue Light Sources?
The high-energy blue light sources are the sun and technology such as smartphones, tablets, LED screens, computers, laptops and gaming systems. The sources of high-energy blue light are listed below.
* Smartphones: Smartphones are mobile phones that have many of the same functions as computers, such as internet browsing. Smartphones may have between 400 and 490 nm of blue light.
* Tablets: A tablet is a digital device that operates like a computer, only wireless. A tablet may have between 400 - 490 nm of blue light emitted.
* Computers: Computers are digital devices for internet browsing, data storage and processing. Computers are a big source of blue light for many people.
* Laptops: Laptops are portable computers that may emit between 400 and 490 nm of blue light.
* Gaming Consoles: Gaming consoles are screens that people use to play video games on. There may be between 400 - 490 nm of blue light in a gaming console.
* LED screens: Other LED screens, such as digital billboards and posters are a source of blue light.
### What are the Natural Sources of Blue Light?
The natural source of blue light is the sun. Any other natural source of blue light is a product or extension of the sun's blue light rays. This includes glares or reflections.
### What is the Difference Between High-energy and Natural Sources of Blue Light for the Human eye?
There is no major difference between high-energy and natural sources of blue light. Blue light tends to affect the eyes the same way, regardless of the source. The only minor difference between high-energy and natural sources of blue light is the time of day that the body is likely to experience them. Blue light from the sun is experienced during the day, when it has been shown to have positive effects on the body, such as an elevation in mood and greater work productivity. Artificial blue light can be experienced at any time of day, depending on when a person is on a digital device. Blue light can disrupt sleeping patterns if a person is on their phone or their computer later in the day or at night time, as blue light helps to regulate sleep.
## What is the Blue Light Wavelength?
The blue light wavelength is a high energy wavelength, ranging between 380 to 500 nanometres (nm). Light wavelengths are the microscopic but perceivable particles that make up colours and light, known as photons. The light spectrum reaches the maximum wavelength at 700 nm, the wavelength of red light. Blue light wavelength is similar to the ultraviolet rays the sun creates on a daily basis, in that it is a small wavelength that passes through surfaces but still emits a high amount of energy.
### How to Measure Wavelength of Blue Light?
To measure the wavelength of blue light, professionals use specialised devices. The blue light wavelength is measured in nanometres (nm). Blue light levels are measured using devices such as solarmeters or light-metres. Blue light is measured in these devices by separating the levels of each form of light within the device.Blue light may start to negatively affect the human eye at a wavelength of 400 nm and above, according to the National Institute of Medicine. Blue light levels of 400 nm and above have a chance of penetrating the retina and eye lens while still retaining high energy, causing damage to the eyes that may lead to conditions such as cataracts and dry eyes. Blue light passing through the cornea also leads to less melatonin being made in the body, affecting a person's ability to rest.
## What are the Benefits of Blue Light for Human Eye?
The benefits of blue light for human eyes are increased awareness, greater memory, an improvement in mood, improved emotional state and enhanced reflexes. Blue light also aids the body's circadian rhythm, creating better sleep. The benefits of blue light for the human eye are listed below.
* Awareness: Blue light locks the creation of melatonin, the hormone that causes the body to feel sleepy, leading to greater sense of awareness and alertness.
* Greater memory: Blue light helps memory as it heightens awareness and thought processing, including information received and the mind’s ability to retain it.
* Improved mood: The energy the body creates in response to seeing or feeling blue light also affects the mind, creating a better mood.
* Enhanced reflexes: Blue light creates a feeling of being awake, enhancing a person's ability to react to things at a greater speed.
* Better rest: Blue light can help the body regulate sleep. Exposure to blue light in the day indicates to the body that it needs to be awake. At night, the lack of blue light tells the body that it is time to sleep.
Get a Full Quote in Store
Get fitted for your glasses at Oscar Wylee by visiting us in store and talking to our friendly staff for a complete quote.All major health funds accepted in store.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
## What are the Effects of Blue Light on the Human Eye?
The effects of blue light on the human eye is increased awareness, eye fatigue and retinal damage. The effects of blue light on the human eyes are listed below.
* Increased awareness: Blue light increases awareness by stimulating the body in the same way natural sunlight does. The stimulation blue light causes makes the body feel awake and energised, creating greater awareness and alertness in the eyes.
* Eye fatigue: Blue light may cause eye fatigue as it is harder for the eye to perceive due to its low wavelength. To see blue light, the eyes increase the level of concentration for a long period at a time. This puts strain on the eyes, causing them to fatigue quickly, creating feelings of headaches, dry eyes and discomfort.
* Retinal damage:&nbsp;Blue light may cause retinal damage as it is not naturally blocked by the front of the eye, resulting in the high energy light passing through the eyes and into the retina. This may cause damage to the retina.
To learn more about the possible effects of blue light, book an [eye exam](https://www.oscarwylee.com.au/glasses/eye/test-glossary) with an eye health professional.
### What are the Concerns About Blue Light?
The concerns about blue light are that it affects circadian rhythm, that it may damage the retina and that blue light may cause age-related macular degeneration (AMD). The concerns regarding blue light are as listed below.
* Blue light disrupts the body's circadian rhythm: A person's natural sleep cycle or circadian rhythm, may be affected by blue light as this light simulates the effects of sunlight, which helps us to regulate sleep. This is of particular concern during times when the eyes and the brain should be resting, such as night time.
* Blue light may damage the retina: Blue light passes through the front of the eye and hits the retina, which may cause damage to the retina and accelerate vision problems.
* Blue light causes macular age-related degeneration (AMD): There are concerns that blue light may damage the retina when the eye is overexposed to it. Some theorise that this damage may weaken the retina in ways that are normally only caused by ageing, increasing risk of macular degeneration.
#### How Does Blue Light Affect Work Efficiency?
Blue light affects work efficiency by improving alertness, and reducing fatigue. Blue light affects work efficiency by preventing the body from creating melatonin, the hormone the body creates to put itself to sleep, according to Harvard Health. Blue light simulates sunlight and naturally wakes up the body when it comes into contact with the skin, making a person more awake and aware, increasing work efficiency.
#### How Does Blue Light Affect Psychology?
Blue light affects psychology by elevating moods and enabling the body to create more energy, which prevents depression and assists in sleep when blue light is received during daylight hours. According to a study performed by the American Academy of Neurology, blue light therapy was shown to improve a patient's level of depression.
#### How Does Blue Light Affect Sleep?
Blue light affects sleep by disrupting the body's circadian rhythm, simulating sunlight and keeping the body awake. Too much blue light exposure causes the system to believe it is still in sunlight, reducing the production of melatonin, the hormone that helps us to sleep.
#### What are the Long-term Effects of Blue Light?
The long term effects of blue light have not yet been scientifically proven. As digital blue light is a newer technology, few studies definitely state what the long term effects are. Possible effects may include age-related macular degeneration (AMD), cataracts, digital eye strain and a disrupted sleep cycle.
#### What are the Short-term Effects of Blue Light?
The short term effects of blue light may include increased awareness, dry eyes, eye fatigue and short headaches. Blue light is stimulating to look at, negatively affecting sleep cycles and preventing the eyes from blinking a healthy and consistent amount. This causes the eyes to dry quickly. Blue light causes increased awareness and focus, particularly on a specific object.Eyes become fatigued when focused for too long on a single point. Keeping attention on a blue light source for too long causes discomfort in the eyes and minor headaches. These headaches and retinal pains continue until the eyes have rested
## How Does Blue Light Affect Children?
Blue light affects children in the same way it affects adults. Blue light may affect a child’s natural sleep cycle, which may disrupt the child’s development and quality of life. A bad sleep cycle results in low energy throughout the day and a poor mental state until proper rest has been sought.Possible effects of blue light on children can be tested with an [eye exam for children](https://www.oscarwylee.com.au/glasses/eye/exam-for-children). Please be advised not all Oscar Wylee stores have children's vision testing available.
## How to Protect the Human Eye from Blue Light?
To protect the human eye from blue light, try wearing blue light glasses, rest the eyes from blue light sources and turn on blue light blocking functions on applicable devices. The best ways to protect the human eye from blue light are listed below.
* Wear Blue Light Glasses: [Blue light glasses](https://www.oscarwylee.com.au/glasses/blue-light/works) are effective in blocking blue light, reducing the phototoxicity of this light source by 10-20%, according to a 2017 study conducted by Tsz Wing Leung, Roger Wing-hong Li and Chea-su Kee.
* Rest from blue light sources: Limiting how much blue light the body is taking in reduces negative effects associated with prolonged blue light exposure. A common rule used to promote health and reduce issues with blue light energy is referred to as the 20-20-20 rule: After looking at an object 20 feet away for 20 minutes, look away for 20 seconds.
* Turn on blue light blocking: Blue light on devices such as tablets or smartphones can be reduced or blocked depending on the device. Blue light blockers are found through the device's setting or through a separate, downloadable app.
### What Emits Blue Light?
Blue light is emitted by the sun and from artificial sources such as smartphones, computers, and fluorescent lights. Blue light and ultraviolet rays from the sun are blocked to a degree by wearing a pair of sunglasses when outdoors. Blue light from digital sources such as computers are blocked to a degree by using blue light filters, such as the ones found in glasses or additional applications and settings in digital devices.
#### What are the Best Methods to Reduce Blue Light exposure?
The best methods to reduce blue light exposure are resting the eyes from sources of blue light or using blue light blocking products such as blue light filters on glasses or [blue light preventing apps and functions](https://www.oscarwylee.com.au/glasses/blue-light/how-to-turn-off). Blue light exposure refers to the amount of blue light that enters the eye.Blue light exposure can also be prevented by taking breaks from looking at a source of blue light for more than 20 minutes. Blue light blocking on phones and other devices are found in the item's settings. Look for ‘night shift’ or ‘blue light’ settings to turn off blue light exposure on the device.
## What is Blue Light Spectrum?
The blue light spectrum is the visible blue light the human eye sees on the colour spectrum. The visible light spectrum is all the wavelengths of colour the human eye sees and perceivably measures. Blue light’s measurement on the scale is 400-500 nm, with red being at the very end of the scale at 700 nm. Blue light filter glasses and light spectrum glasses do not disrupt the wearers ability to see blue light. Blue light glasses instead attempt to prevent the high energy that blue light wavelengths contain from passing through the eyes.
Read What is Blue Light from Digital Devices in other Oscar Wylee regions and their languages.
Australia    
[Australia](https://www.oscarwylee.com.au/glasses/blue-light)
[Canada](https://oscarwylee.ca/glasses/blue-light)
[Canadian French](https://oscarwylee.ca/fr/glasses/blue-light)
Find an Oscar Wylee store near you
Our knowledgeable and friendly team can help you find a pair of stylish and affordable frames.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
Book an eye test at Oscar Wylee
Come in and see our optometrists for an eye test. If you are an eligible Medicare Card holder, our eye tests will be bulk billed.
[Book an eye test](https://www.oscarwylee.com.au/booking)