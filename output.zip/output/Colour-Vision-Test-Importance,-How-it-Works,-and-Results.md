# Source: https://www.oscarwylee.com.au/glasses/eye/test/colour-vision-test

# Colour Vision Test: Importance, How it Works, and Results
Published on June 14th, 2024
Updated on Month Date, 2025  
Australia   
[Australia](https://www.oscarwylee.com.au/glasses/eye/test/colour-vision-test)
New Zealand

[Canada](https://oscarwylee.ca/glasses/eye/test/colour-vision-test)
[Canadian French](https://oscarwylee.ca/fr/lunettes/oeil/test/test-vision-couleurs)
A colour vision test examines a person’s ability to see colours to determine if they have any colour deficiencies, typically performed by an optometrist as part of an eye test. Types of colour vision tests include an Ishihara test (colour plate test) and a colour hue test ( colour arrangement test). The types of colour vision deficiency, colloquially known as colour blindness, a colour vision test can diagnose include red-green colour vision deficiency, blue-yellow colour vision deficiency and monochromatism. Colour vision deficiency is most often caused by genetics but can also be due to certain diseases, injuries, medications and chemicals. Keep reading to learn more about how colour vision tests work and what their results reveal about a person’s ability to see colour.
Due for an Eye Test?
Oscar Wylee offers Medicare bulk billed eye tests for valid Medicare cardholders.
[Eye test near me](https://www.oscarwylee.com.au/booking)
[Definition](#definition) [Types](#types) [Causes](#causes) [Risks](#risks)
## What is a Colour Vision Test?
A colour vision test is performed by an eye care professional to examine a person’s colour vision for any deficiencies. A colour vision test will involve a patient identifying or sorting colours to determine what colours they can see and those that they cannot. The most common type of colour vision test, according to the National Eye Institute, is an Ishihara test, also known as a colour plate test. An Ishihara test consists of circles or plates made up of dots of a certain colour in varying shades, with a number in the middle made out of the same dots but in a different colour. If a person is unable to see the number in the middle of an Ishihara test, then they may have [colour vision deficiency](https://www.oscarwylee.com.au/glasses/eye/colour-vision-deficiency) as their eyes have not differentiated between the two colours on the plate. Another type of colour vision test is a colour hue test. A colour hue test determines if a person has colour vision deficiency using blocks of varying colours. The aim of the test is for the patient to order the blocks, often in rainbow order. If the blocks are not in the specified order, it can indicate a type of colour vision deficiency.
### What is the Importance of a Colour Vision Test?
A colour vision test is very important as it can diagnose a person who has colour vision deficiency or colour blindness. Colour vision deficiency, colloquially known as colour blindness, is a condition where a person has difficulty seeing colours in a normal way. According to Health Direct, colour vision deficiency may make people confuse colours, or make some colours appear less bright. A colour vision test is most often performed as part of an [eye test](https://www.oscarwylee.com.au/glasses/eye/check-up) by an optometrist using a colour hue test or an Ishihara test.
## How Does a Colour Vision Test Work?
A colour vision test works by determining the colours a person can see using different tests. According to the National Eye Institute, a colour plate test, also known as an Ishihara test, is most commonly used and works by using different coloured dots in a circle typically with a number in the middle which the patient is asked to identify. For people who have deficits in their colour vision, the number may blend into the background colour and therefore they cannot see it. If the results of a colour plate test are inconclusive, the eye care professional may ask the patient to do a colour hue test. A colour hue test, also known as a colour arrangement test, requires a patient to arrange coloured blocks in rainbow order. A colour hue test may be used for people who need accurate colour vision for their jobs such as graphic designers, according to the National Eye Institute.
## What Does a Colour Vision Test Diagnose?
A colour vision test will diagnose colour vision deficiency, an eye condition in which the eyes have trouble seeing colour properly. There are three main types of colour vision deficiency which are red-green colour vision deficiency, blue-yellow colour vision deficiency and monochromatism. The types of colour vision deficiencies and their definitions are listed below.
* Red-green colour vision deficiency: Red-green colour vision deficiency has four categories which include protanomaly, deuteranomaly, protanopia and deuteranopia.
* Blue-yellow colour vision deficiency: Blue-yellow colour vision deficiency includes two categories which are tritanopia and tritanomaly.
* Monochromatism: Monochromatism, also known as complete colour blindness, occurs when a person cannot see any colour.
### 1. Red-green Colour Vision Deficiency
Red-green colour vision deficiency can be categorised into four types, protanomaly, deuteranomaly, protanopia and deuteranopia. Protanomaly is a mild form of red-green colour vision deficiency that can make the appearance of red colours look more green and darkened. Deuteranomaly is the most common type of red-green colour vision deficiency that results in green colours appearing red. Protanopia can occur as a result of absent L cones and can cause the inability of the eyes to see red colours. Deuteranopia can develop due to missing M cones and can hinder the eyes from seeing green colours.
### 2. Blue-yellow Colour Vision Deficiency
Blue-yellow colour vision deficiency, also known as anomalous trichromacy is categorised into two types, tritanopia and tritanomaly. Tritanopia is a rare type of blue-yellow colour vision deficiency that makes it difficult for a person to differentiate between blue and green, purple and red and yellow and pink. Tritanomaly is the other type of blue-yellow colour vision deficiency that occurs when the S cones of the eye are present but are not functioning properly. This may cause the inability to distinguish between red and yellow and between blue and green.
### 3. Monochromatism
Monochromatism is known as complete colour blindness and prevents the eyes from perceiving colours. Due to the lack of working cone photoreceptors, people with this type of colour deficiency may only be capable of seeing grey colours, according to the National Library of Medicine. People with monochromatism may also be susceptible to other vision problems such as low visual acuity and nystagmus. Monochromatism is considered the most rare and severe type of colour vision deficiency and cannot be treated. It is generally caused by genetic defects and can appear during infancy.
## What are the Causes of Poor Colour Vision?
The most common cause of poor colour vision, or colour vision deficiency, is genetics, meaning a person is born with the condition that has been passed down from their parents. Other causes of colour vision deficiency, according to the Mayo Clinic include diseases, injury, medications and chemicals. These causes of poor colour vision and their definitions are listed below.
* Genetics: Genetics is the most common cause of colour vision deficiency meaning the issue is passed down from parent to child. According to the National Eye Institute, this occurs through genes on chromosomes, which are made of DNA.
* Diseases: Certain diseases such as diabetes, Alzheimer’s disease, leukaemia, glaucoma, Parkinson’s disease, sickle cell anaemia and macular degeneration can cause colour deficits
* Injuries: Colour vision deficiency can be caused by injuries to the optic nerve, retina and even the brain. These injuries include retinal detachment and eye injuries caused by lasers.
* Medications: Some medications are known to alter a person’s colour vision. These medications include those used to treat heart problems, autoimmune diseases, infections and high blood pressure.
* Chemicals: If a person is exposed to specific chemicals, it may cause colour vision deficiency. According to the Mayo Clinic, these chemicals can include those found in certain workplaces such as fertilisers and carbon disulfide.
### Does Damage to the Optic Nerve Cause Poor Colour Vision?
Yes, damage to the optic nerve can cause poor colour vision. The optic nerve is involved in colour vision as, according to the American Optometric Association, pigments inside the light-sensitive cones in the eye register different colours and send this information through the optic nerve to the brain. Glaucoma is an eye condition that can cause damage to the [optic nerve](https://www.oscarwylee.com.au/glasses/eye/anatomy/optic-nerve) due to increased eye pressure. This pressure negatively affects the optic nerve and may lead to loss of colour recognition.
Find Your Local Oscar Wylee Store
Use our store locator page to find your nearest Oscar Wylee and come see the team for all your eyewear and eyecare needs.
[Optometrist near me](https://www.oscarwylee.com.au/locations/full-store-list.html)
## How to Prepare for a Colour Vision Test?
There is no preparation needed for a colour vision test.
### What Happens During a Colour Vision Test?
What happens during a colour vision test will be determined by the type of test being performed by the eye care professional. While each test will assess a person’s colour vision, they are different in their approaches as a colour hue test uses blocks whereas an Ishihara test uses colour plates.
### What Happens After a Colour Vision Test?
After a colour vision test, your optometrist will go through your results and determine if you have any colour vision deficiencies. If the results are inconclusive, they may perform other colour vision tests. According to the National Eye Institute, in many cases, a colour vision deficiency diagnosis is not very serious as most people with this condition do not experience problems with everyday activities.
### How Accurate is a Colour Vision Test?
A colour vision test is recognised as fairly accurate although it can depend on certain variables such as the accuracy of the patient’s answers. According to the National Eye Institute, it can be difficult to diagnose colour vision deficiency in children as they may try to hide it. Also, in the case of an Ishihara test, accuracy can be determined by how many colour plates a patient is tested on.
### Are There Risks in a Colour Vision Test?
There are no risks in a colour vision test. The two main types of colour vision tests, a colour hue test and an Ishihara test, are non-invasive. A colour hue test involves a patient arranging blocks of different colours and an Ishihara test uses plates made up of different coloured dots and requires the patient to identify numbers within the dots.
### What is the Relation of Colour Vision Test to Colour Blindness?
A colour vision test is a way to determine if a person has colour blindness, or more accurately, any type of colour vision deficiency. There are three types of colour vision deficiency, monochromatism, which is complete [colour blindness](https://www.oscarwylee.com.au/glasses/eye/colour-blindness-types), blue-yellow colour blindness and red-green colour blindness. The types of tests used to assess colour vision include an Ishihara colour test and a colour hue test.
### What is the Difference Between a Colour Vision Test and a Colour Blind Test?
There is no difference between a colour vision test and a colour blind test, they are simply different terms to refer to the same types of tests. A colour vision test is performed to measure a person’s colour vision against a standard of colour vision to determine if they have any deficiencies. Colour blindness is the colloquial term for colour vision deficiency and can be tested using an Ishihara colour blindness test or colour hue test.
## Who Performs a Colour Vision Test?
The eye care professional who performs a colour vision test is most commonly an optometrist. An optometrist is a healthcare professional who provides fundamental eye care services such as eye tests and prescriptions. An [optometrist](https://www.oscarwylee.com.au/eye-care/optometrist) can perform a colour vision test as part of an eye test appointment.
### Does Oscar Wylee Offer a Colour Vision Test?
Yes, Oscar Wylee offers a colour vision test for patients who require it. While it is not part of a standard eye test, if a patient is having issues or concerns with their colour vision, they should let the optometrist know and they will take the appropriate course to test their vision. You can book an [Oscar Wylee eye test](https://www.oscarwylee.com.au/booking) online or in-store.
#### What are the Eye Exam Locations Near Me?
There are many eye exam locations you can find if you need to have your colour vision tested or just for a regular eye test appointment with an optometrist. If you’re looking for an eye exam location near me, you can choose one of Oscar Wylee’s many stores across Australia. We have stores in the Australian Capital Territory, New South Wales, the Northern Territory, Queensland, South Australia, Tasmania, Victoria and Western Australia.
#### How Much Does a Colour Vision Test Cost?
The price of a colour vision test may vary depending on where the test is taking place and whether it can be covered by Medicare. According to UNSW Colour Vision Clinic, they charge a $200 fee for a colour vision assessment for adults and for children under 15, the cost is $150.
Read Colour Vision Test: Importance, How it Works, and Results in other Oscar Wylee regions and their languages.
Australia   
[Australia](https://www.oscarwylee.com.au/glasses/eye/test/colour-vision-test)
New Zealand

[Canada](https://oscarwylee.ca/glasses/eye/test/colour-vision-test)
[Canadian French](https://oscarwylee.ca/fr/lunettes/oeil/test/test-vision-couleurs)
Need Your Eyes Tested?
Our optometrists are knowledgeable and dedicated to providing excellent services and care.
[Eye test near me](https://www.oscarwylee.com.au/booking)
Major Health Funds Accepted In-store
For the purchase of frames and lenses, use your private health fund insurance to limit how much you pay from your own pocket.
[Discover Health Funds](https://www.oscarwylee.com.au/health-funds.html)