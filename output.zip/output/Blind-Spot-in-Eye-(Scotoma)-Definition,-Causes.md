# Source: https://www.oscarwylee.com.au/glasses/eye/blind-spot-in-eye-scotoma

# Blind Spot in Eye (Scotoma): Definition, Causes
Published on August 7th, 2026
A scotoma is the formal term for a blind spot in the vision, causing blackness or lack of visual sensation, according to Eastern Suburb Eye Specialists. Conditions such as age-related macular degeneration, glaucoma, diabetic retinopathy, retinal detachments and optic neuritis are noted to lead to a scotoma.
Prioritise Your Eye Health
Our team can help you stay up to date with regular eye tests to keep your eyes healthy!
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Definition](#definition) [Eye Conditions](#conditions) [Types](#types) [Diagnosis](#diagnosis)
## What is a Blind Spot in the Eye (Scotoma)?
A blind spot in the eye (scotoma) is an area or spot in the retina where there is a lack of light-sensitive cells, where visual stimuli is unable to be interpreted clearly, according to SydWest Eye Specialists.
### How is a Scotoma Different From the Eye's Natural Blind Spot?
A scotoma is different from the eye’s natural blind spot as it emerges as a result of an issue with the eye or condition.
#### Is Every Blind Spot a Sign of an Eye Disease?
Not every blind spot is a sign of eye disease. Some may emerge as a result of conditions such as migraines. However, if you experience a prolonged, sudden blind spot in your vision, you should consult a health professional immediately.
## What Causes a Blind Spot in Your Vision?
The cause of a blind spot in your vision is often when there is a spot on your retina where the nerves do not work and fail to send signals to your brain, leading to a lapse in a particular part of your vision, according to Cleveland Clinic. Blind spots can also happen as a symptom of an eye condition.
### Which Eye Conditions Can Lead to a Scotoma?
The eye conditions that can lead to a scotoma include age-related macular degeneration, glaucoma, diabetic retinopathy, retinal detachment, and optic neuritis. Read more about these eye conditions that may lead to a scotoma below.
#### 1. Age-Related Macular Degeneration
[Age-related macular degeneration](https://www.oscarwylee.com.au/glasses/eye/age-related-macular-degeneration) refers to a condition where there is a distortion or absence of the central field of vision as an individual ages, according to the Better Health Channel. This distortion or portion of lost vision is the scotoma that emerges as a result of the condition.
Find Your Nearest OW Store!
We've got knowledgeable teams who are passionate about delivering high-quality care.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
#### 2. Glaucoma
[Glaucoma](https://www.oscarwylee.com.au/glasses/eye/glaucoma) refers to a condition where there is an increase in intraocular pressure (IOP), which causes damage to the optic nerve, according to Glaucoma Australia. Symptoms include blurred vision, scotoma, watery eyes, and seeing halos.
#### 3. Diabetic Retinopathy
[Diabetic retinopathy](https://www.oscarwylee.com.au/glasses/eye/diabetic-retinopathy) is a complication of diabetes, wherein the tiny blood vessels in your retina gradually become damaged, according to Health Direct. Symptoms of this include blurry vision, light sensitivity and patchy spots in your vision (scotoma).
#### 4. Retinal Detachment
Retinal detachment is a condition where the retina, the layer of tissue at the back of the eye, pulls away from its normal position, according to Health Direct. [Retinal detachments](https://www.oscarwylee.com.au/glasses/retinal-detachment) can lead to flashes of light, an increase in floaters and flashes and a shadow or dark curtain appearing in the vision.
#### 5. Optic Neuritis
Optic Neuritis is a form of optic neuropathy and can lead to vision issues such as vision loss. The most common vision issue for children who have [optic neuritis](https://www.oscarwylee.com.au/glasses/eye/optic-neuritis) is a central scotoma, according to The Royal Australian College of General Practitioners.
## What are the Different Types of Scotoma?
The different types of scotoma are central scotoma, paracentral scotoma, scintillating scotoma and altitudinal scotoma. Read more about these different types of scotomas below.
### 1. Central Scotoma
A central scotoma will appear in the centre of your visual field, and your eyes will not be able to detect stationary objects as well as moving objects, according to Vision Eye Institute.
### 2. Paracentral Scotoma
A paracentral scotoma refers to one that presents slightly off to the side of your line of vision, according to the Cleveland Clinic. You can have more than one paracentral scotoma.
### 3. Scintillating Scotoma
This type of scotoma often appears to be jagged or wavy, going light to dark and back again. This kind of scotoma often happens if you have a migraine with aura.
### 4. Altitudinal Scotoma
An altitudinal scotoma, or defect, happens when you lose vision above or below a horizontal line in your sight, usually happening in one eye, according to Cleveland Clinic.
## What Does a Blind Spot in Vision Look Like?
A blind spot in vision can look like a few different things. These can appear as dark spots or even wavy and zig-zagged lines.
### What Symptoms Can Occur Along With a Scotoma?
The symptoms that can occur along with a scotoma are difficulty seeing colours, needing excess light to see and eye floaters, according to The Cleveland Clinic. Read more for these symptoms that can occur along with a scotoma.
* Difficulty seeing colours: Difficulty seeing colours clearly is a common symptom alongside scotomas due to their potential affect on the cone cells
* Needing excess light: Needing excess light to see clearly in certain situations may be a symptom alongside a scotoma.
* Eye floaters: Eye floaters may emerge more frequently as a result of a scotoma in your vision.
#### Can a Scotoma Affect Only One Eye?
Yes, scotomas usually affect only one eye, according to Health Direct. but can happen in both, according to the Cleveland Clinic.
## How is a Blind Spot in the Eye Diagnosed?
A blind spot in the eye is diagnosed through tests such as a dilated eye test, slit lamp exam and visual field test, according to SydWest Eye Specialists.
### Which Tests Are Used to Detect a Scotoma?
The tests that are used to detect a scotoma are a dilated eye test, slit lamp exam and visual field test. Read more about these tests and the role they play in detecting scotoma below.
* Dilated eye test: A dilated eye test is one that enlarges your pupils using eye drops to examine the retina.
* Slit lamp exam: A slit-lamp exam allows optometrists to examine all parts of the eye and further inside the eye.
* Visual field test: A visual field test uses spots of light to assess your central vision and your ability to visualise objects.
#### Can a Blind Spot Be Found During a Routine Eye Test?
Yes, a blind spot can be found during a routine eye test through tests such as a dilated eye test, slit lamp exam and visual field test.
## How is a Scotoma Treated?
There is  no singular treatment of a scotoma. Some go away on their own, such as ones caused by migraines. Ones caused by conditions such as glaucoma can only be managed by treatments specific to the condition.
### Is Every Scotoma Treatable?
Whether a scotoma is treatable will depend on the underlying cause of it. A scotoma as a result of a migraine will go away on its own. However, a scotoma as a result of more serious eye conditions such as diabetes may need ongoing treatment and will not go away completely.
## How can Glasses Help People With a Scotoma?
Glasses can help people with a scotoma as they help people without one They help correct refractive errors and allow for sharper, clearer vision. It should be noted that they will not reduce or eliminate a scotoma.
### What are the Advantages of Transition Lenses for People With a Scotoma?
Transition lenses will not allow for any specific advantages for those with a scotoma compared to those without a scotoma. They are not a cure or treatment for scotomas.
#### Can Polarised Sunglasses Reduce Glare for People With a Scotoma?
Yes, [polarised sunglasses](https://www.oscarwylee.com.au/glasses/eye/polarised-lenses) may reduce glare for people with a scotoma. However, they will not get rid of or reduce the scotoma.
## When Should You See an Eye Doctor for a Blind Spot?
You should see an eye doctor immediately if there is a blind spot in your vision that has emerged suddenly.
### How can you Protect Your Vision if You Have a Scotoma?
To protect your vision if you have a scotoma, you must go to an eye health professional to identify the underlying cause. They will be able to provide advice and treatment plans on how to treat the root cause. For example, scotomas are a common symptom of Glaucoma, which is treated through measures such as eye drops or laser surgery, according to Glaucoma Australia.
#### Can Early Treatment Help Prevent Vision Loss?
Yes, early treatment can help prevent vision loss. Scotomas can be indicative of a more serious eye condition, which is why early detection by an eye professional is important.
Experience High Quality Eyecare Services From Our Team
Book an appointment online with an Oscar Wylee optometrist today.
[Book an eye test](https://www.oscarwylee.com.au/booking)
Major Health Funds Accepted In-store
For the purchase of frames and lenses, use your private health fund to limit how much you pay from your own pocket.
[Health Funds](https://www.oscarwylee.com.au/health-funds.html)