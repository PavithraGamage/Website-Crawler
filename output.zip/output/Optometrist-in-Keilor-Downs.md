# Source: https://www.oscarwylee.com.au/locations/optometrist-keilor-downs.html

Optometrist Keilor Downs
Keilor Central
Ground Floor Shop 07, 80 Taylors Rd
Keilor
Downs VIC 3038
Near Coles

# Optometrist Keilor Downs
Permanently closed 
Opening hours
Monday9:00am - 5:30pm
Tuesday9:00am - 5:30pm
Wednesday9:00am - 5:30pm
Thursday9:00am - 9:00pm
Friday9:00am - 9:00pm
Saturday9:00am - 5:00pm
Sunday10:00am - 5:00pm
*Store hours reflect local standard trading hours and exclude public
holidays

Our Oscar Wylee Keilor Central store has closed, but this isn’t
the end of your eye care journey!
Visit another Oscar Wylee store to experience our high-quality eye
care services, such as eye tests and new frames, as we still have
your eye care details.
See your nearby stores below!
[Watergardens](https://www.oscarwylee.com.au/locations/optometrist-watergardens.html)
[Airport West](https://www.oscarwylee.com.au/locations/optometrist-airport-west.html)
[Highpoint](https://www.oscarwylee.com.au/locations/optometrist-highpoint.html)
[Broadmeadows](https://www.oscarwylee.com.au/locations/optometrist-broadmeadows.html)
Visit our Keilor Central Google Business page for directions,
reviews, and updates.

Book Appointment
[Call us: 1300 164 990](tel:1300 164 990)
Our Reviews
Michelle Barba
2 years ago
Really great service at Oscar Wylee Keilor Central! After experiencing terrible service at highpoint... in person and by watergardens on the phone, Kevin at Keilor Central was able to assist in refining a prescribed script for lenses and was able to provide extensive reasoning and solutions for my optical needs!
See more
Aleksandra Tasevska
2 years ago
Great service
Shaaban Baset
2 years ago
Hoang Pham
2 years ago
Caroline Zammit
2 years ago
The receptionist was very helpful, and approachable. The optometrist was very professional and expla...ined everything very thoroughly.
See more
Slwan Habash
2 years ago
Emily Culhane
2 years ago
The lady at reception is very welcoming. My children adore her. We see her now and again for little ...adjustments and she’s always happy and quick to assist.
The appointment with the optometrist went well. He was very thorough.
Highly recommend
Thank you ????
See more
maryanne tota
2 years ago
Great service, met all my requirements. Friendly staff
Uyen Ngoc Tran
2 years ago
Im really happy with professional and friendly service that Kevin and Vanessa gave me while im shopp...ing at Oscar Wylee in Keilor, very helpful recommendation given
Thanks to Kevin and Vanessa that helping me a lot throung my eyes test and choosing good frame for myself
Really appreciate it
See more
Rye shy
2 years ago
Optometrist explained everything simple and easy to understand. Excellent service and prompt.
joeseph kennedy
2 years ago
it was a great experience professional and fast in helping in checking my eye health and getting me ...my needed eye ware.
See more
Kate Veal
2 years ago
Helpful, friendly and supportive staff
Reynaldo Rodriguez
2 years ago
Excellent and experienced staff...
Christine Co
2 years ago
Great experience.
Kevin proved to be a knowledgeable optometrist who was quickly and efficiently abl...e to complete my eye test and Vanessa was fantastic sales assistant, she was friendly and able to guide me to the best suited glasses for my face.
First time customer, will return.
See more
Lua
2 years ago
hussain sameri
2 years ago
Mo Sassella
2 years ago
Fast,  easy awesome service aswell, ????
Joe Kam
2 years ago
Good Customer. Thanks to Anna and Kevin
Debby Hirst
2 years ago
Efficient and friendly team. Every aspect about my appointment was clearly explained. Cost was check...ed and double checked. Really appreciate this level of service.
See more
Wendy Clutterbuck
2 years ago
Good service,
Leanne Dalton
2 years ago
It was my first time visiting this store and I was very impressed. Kevin the optometrist was brillia...nt and knew what he was doing, also Anna was very helpful and honest in helping pick out some frames. I will now be a regular customer.
See more
J T (Phương Cake)
2 years ago
Not my first eye test but it was the first I personally made the decision to book myself and definit...ely the most intricate test. First test was a torture device randomly spritzing into your eyes multiple times while you try not to flinch like the first time. Then there were a a few more tests in the private room with the actual optometrist (he had the labcoat.)
Didn't buy glasses after the appointment. Didn't have the money for it. So I requested for the report emailed to me.
The online booking process was quick and simple for me, but might not be the same for others. There were  few branches and one nearby at my local shopping centre.
See more
Julio Corrales
2 years ago
Clean environment, Excellent attention to detail.
Mal Sadat
2 years ago
Great customer service and range of frames.
Helen Witton
3 years ago
The Optometrist was very through with my son and patient as he's only six. He said he'd send through... the referral in the morning and I had it by 8am. Very happy with the service every time I go here, plus good prices and styles.
See more
Jela M
3 years ago
Wonderful range and quick check. Great price given for my new glasses.
David Marcos
3 years ago
Kirti -
3 years ago
kathryn tobin
3 years ago
Great range of glasses at a reasonable price. Would definitely recommend them to family and friends.... All my questions regarding my eye health answered. Will definitely be going back again when needed.
See more
Anna-marie Munnik
3 years ago
Sonel Cr7
3 years ago
Trina Safai
3 years ago
Very friendly and professional team. Sebastian loved his eye test and felt comfortable and confident....
Thankyou for a great experience and your patience!
See more
Kat Elms
3 years ago
Great products,  great service, cheap and friendly staff ????????????????????
ED
3 years ago
Helpful selecting styles.
tala feltraemon
3 years ago
Lovely customer service very attentive !
Josie Solas
3 years ago
Optometrist Kevin is very professional
The lady at reception is also very helpful
Joyce
3 years ago
Great value and great service
Quan Dat Phan
3 years ago
Exceptional services and staff recognise the urgency of my situation
Hakan
3 years ago
Very friendly staff and help me very well
Aakif
3 years ago
Very supportive and caring.
Christine Tsiogas
3 years ago
Optomitrist was just amazing!
Very caring and helpful
Amy Barrotta
3 years ago
Had the best experience at this Oscar Wylee! Optom was knowledgable and friendly. The girls are so l...ovely and attentive. Would definitely go back!
See more
Amy Huynh
3 years ago
Very friendly and helpful staff that looked after me during my appointment. Optometrist Kevin was gr...eat to speak to and provided professional service!
See more
Katie Pell
3 years ago
I randomly dropped in without an appointment and the staff were in incredibly helpful and efficient.... The floor staff were very helpful when explaining the pricing and talking my facial measurements and the optometrist was friendly and efficient. I had a great in store experience and would recommend that store to others.
See more
pham bao ngoc
3 years ago
Greg Hatzistavrou
3 years ago
marcela nonea
3 years ago
Alex Bucman
3 years ago
I still waiting for my invoice to be emailed to me unprofessional
She said she go emailed same after...noon still not yet coming
See more
Fei Ng
3 years ago
The optometist was polite and patient. The ladies were friendly and gave me enough personal space to... try on different frames without trying to hurry me.
See more
Lucien Collard
3 years ago
I recently had an in-depth eye test done at Oscar Wylee's at the Keilor Central Shopping Centre. I w...as most impressed by the thoroughness, patience and professionalism of Kevin, the optometrist who saw me. I unreservedly recommend Oscar Wylee to anybody who needs to have their eyes tested or wants a new pair of glasses.
See more
## Find an Optometrist in Keilor Central With Oscar Wylee
If you live close to the St Albans or Kealba areas, then our
Oscar Wylee store at the Keilor Central Shopping Centre is your go-to for
optometry services. At Oscar Wylee Keilor Central, our skilled and experienced
optometrists can conduct Medicare bulk billed eye tests and our friendly staff
can help you shop our range of affordable and stylish frames including
prescription glasses, prescription sunglasses and non-prescription glasses.
To make your appointment with us, you can drive in and
use one of the centre’s 1100 car spaces, with disabled parking and Parents
with Prams parking available. The closest train station to the centre is
Keilor Central. From the station, you can take a bus directly to the shopping
centre. Why not make the most of your trip and explore the retail options at
the centre, or check out the Brimbank Aquatic and Wellness Centre, with
swimming pools and a gym. For some of the best optometry services in Keilor
Downs, Australia, come and visit Oscar Wylee at Keilor Central!        
Our Services
* Bulk
Billed Eye Examinations
* Professional Frame Styling
* Frame Adjustments and
Repairs
Show All
## Find an Optometrist in Keilor Central, Victoria for an Eye Health
Test
If you are in need of an eye health test in Keilor Central,
Victoria, you can find an Oscar Wylee optometrist in-store, on
the ground floor of the shopping centre. At Oscar Wylee Keilor
Central, our optometrists are fully equipped with the latest
optometry equipment to provide customers with eye tests that
include assessing vision and determining whether there are any
signs of eye disease. Our optometrists can also refer patients
to an eye doctor, known as an ophthalmologist in Australia, if
advanced eye care is needed. At our Oscar Wylee glasses store in
Keilor Central, Victoria, our retail staff, including our
optical dispensers are also available to help customers shop for
a new pair of stylish frames from our wide range that includes
prescription glasses, prescription sunglasses and
non-prescription eyewear.
If you are in need of an eye health test in Keilor Central,
Victoria, you can find an Oscar Wylee optometrist in-store, on
the ground floor of the shopping centre. At Oscar Wylee Keilor
Central, our optometrists are fully equipped with the latest
optometry equipment to provide customers with eye tests that
include assessing vision and determining whether there are any
signs of eye disease. Our optometrists can also refer patients
to an eye doctor, known as an ophthalmologist in Australia, if
advanced eye care is needed. At our Oscar Wylee glasses store in
Keilor Central, Victoria, our retail staff, including our
optical dispensers are also available to help customers shop for
a new pair of stylish frames from our wide range that includes
prescription glasses, prescription sunglasses and
non-prescription eyewear.
## How to Find an Optometrist in Keilor Central, Victoria?
To find an optometrist in Keilor Central, Victoria you can take
certain steps that can help make it easier for you such as
searching online, assessing the store’s opening hours and
finding the directions to your chosen location.
The steps on how to find an optometrist in Keilor Central,
Victoria are listed below.
1. Search online using the phrase, optometrist near me in Keilor
Central. This can also be done here on the website via our
locations page.
2. Click on the Oscar Wylee link, which will take you directly to
our Keilor Central optometrist store page.
3. See the store’s opening hours and where the store is located
specifically.
4. Use the Highpoint Google Business page link located under
store hours to see the directions on how to get to the store.
You can also find an optometrist in Keilor Central, Victoria by
searching the keywords optometrist near me. If you have
locations enabled on your smartphone and you’re in the Keilor
Central, Victoria area, our Keilor Central store page should
appear easily for you to click on.
### Is it Hard to Get an Eye Appointment in Keilor Central, Victoria?
No, it is not hard to get an eye appointment in Keilor Central.
You can easily book an appointment to see an Oscar Wylee
optometrist in Keilor Central, Victoria right here on this page.
At Oscar Wylee we have highly qualified optometrists available
for bulk billed eye appointments, which can be booked online or
in-store.
#### How to Compare Optometrists in Keilor Central, Victoria to Each
Other?
To compare optometrists in Keilor Central, Victoria, you can use
factors such as eye
tests offered, health fund coverage, lens types and add-ons
and eyewear offered.
To take care of your vision and eye health, it is important to
receive an eye test at least once every two years. There are
different types of tests that can be performed in an eye test
and not all optometrists may offer the same tests. Health funds
can be used to help cover some of the cost of your frames and
lenses. To find out if your health fund is accepted at an
optometrist in Keilor Central, Victoria visit their website. In
the case of Oscar Wylee, we accept all major health funds and
provide on-the-spot claims in-store. There are many different
lens options available for prescription glasses such as
single-vision, multifocal and high-index lenses. Most
optometrists in Keilor Central, Victoria will offer these lenses
although it is good to make sure. There are also lens add-ons
available to enhance your glasses such as anti-reflective and
blue light filters. Finally, if you are looking to purchase a
pair of glasses after your eye test, you can compare the
different styles and colours you are interested in from the
optometrists in Keilor Central, Victoria. Oscar Wylee offers a
wide range of frames with vintage and modern inspirations in
bold colours and subtle designs.
#### How to Find an Eyeglasses Shop in Keilor Central, Victoria?
To find a glasses store in Keilor Central, Victoria you can try
to follow these simple steps including
searching online, selecting a convenient location and looking
at their health insurance policies.
The steps on how to find a glasses store in Keilor Central,
Victoria are listed below.
1. Search online using the phrase, glasses store in Keilor
Central, Victoria. This will provide you with various options
for glasses stores in the whole Keilor Central, Victoria area.
2. Select a glasses store that is most convenient for you to
travel to.
3. Click the link to find out more information such as opening
hours, exact location and directions to the glasses store in
Keilor Central.
4. Read their health insurance policies to ensure you know what
health benefits you have access to.
Our Oscar Wylee glasses store in Keilor Central, Victoria offers
primary eye care services such as comprehensive eye tests as
well as other services performed by an optometrist and offers
prescription and non-prescription eyewear.
##### Is it Possible to Purchase Prescribed Sunglasses in Keilor
Central, Victoria Without Seeing an Optometrist?
Yes and no, it is possible to
[purchase prescribed sunglasses](https://www.oscarwylee.com.au/sunglasses.html)
in Keilor Central, Victoria without seeing an optometrist if you
already have a prescription that has not expired. If your
prescription is expired, you can book an eye test to receive an
updated or new prescription which will require you to see an
optometrist. This will ensure your prescription sunglasses are
appropriate for your visual needs.
## Where is the Oscar Wylee Keilor Central, Victoria Optometrist
Located?
The Oscar Wylee Keilor Central optometrist is located on the
ground level of the Keilor Central Shopping Centre. Keilor
Central Shopping Centre can be found in Keilor Downs, Victoria.
### What is the Phone Number of Oscar Wylee Keilor Central, Victoria
Optometrist Store?
The phone number for our Oscar Wylee Keilor Central, Victoria
optometrist store is (03) 9994 3699. Our Oscar Wylee Keilor
Central, Victoria store is open, and our staff are available to
be contacted, between the hours of 9 am and 5.30 pm from Monday
to Wednesday, 9 am and 9 pm on Thursdays and Fridays, 9 am and 5
pm on Saturdays and 10 am and 5 pm on Sundays.
### What are the Reviews for Oscar Wylee Keilor Central, Victoria
Optometrist?
The customer reviews for our Oscar Wylee Keilor Central,
Victoria optometrist, can be found here on the website as well
as online when you search for Oscar Wylee Keilor Central
optometrist. The reviews for our Oscar Wylee Keilor Central
optometrist are listed below.
* Debby Hirst:  Efficient and friendly team. Every aspect
of my appointment was clearly explained. Cost was checked and
double-checked. Really appreciate this level of service.
* Leann Dalton:  It was my first time visiting this store
and I was very impressed. Kevin the optometrist was brilliant
and knew what he was doing. Also, Anna was very helpful and
honest in helping pick out some frames. I will now be a
regular customer.
* Kathryn Tobin:  Great range of glasses at a reasonable
price. Would definitely recommend them to family and friends.
All my questions regarding my eye health were answered. Will
definitely be going back again when needed.
#### What Treatments or Eye Care Processes are Done in the Oscar Wylee
Keilor Central, Victoria Optometrist Location?
The treatments or eye care processes done in the Oscar Wylee
Keilor Central, Victoria optometrist location include
a tonometry test, a slit lamp exam and a refraction test.
Additional tests that may also be performed can include
a dilated fundus exam. The treatments or eye-care
processes that are done in the Oscar Wylee Keilor Central
optometrist location are listed below.
* A Tonometry Test: An optometrist or optical dispenser
will conduct a tonometry test which involves the use of a
machine that will release small puffs of air into your eyes.
This will assist with measuring pressure in the eye.
* Slit Lamp Test: A slit lamp test can be used to
evaluate your eye health, by examining your cornea and iris
which are the anterior and posterior of the eye.
* Refraction Test: During a refraction test, an
optometrist will have you view an image through different
lenses and ask you to confirm which helps you see the image
clearer.
* Dilated Fundus Exam: A dilated fundus exam can help an
optometrist assess your health in more detail by getting a
clear view of the retina. This test is typically carried out
for patients with diabetes and those who may be at risk of
developing retinal damage.
## How Many Optometrists Exist in Keilor Central, Victoria?
There are many optometrists that exist in Keilo Centra, Victoria
including Oscar Wylee. The amount of optometrists available in
an area will typically depend on the population and the eye care
needs of those in the area. At Oscar Wylee Keilor Central,
Victoria, our team is passionate about providing our customers
with high-quality, dedicated eye care services. Our optometrists
are available to provide bulk billed eye tests with our
dedicated optometrists, prescription updates and new frames. If
you are looking for an optometrist in Keilor Central, Victoria,
Oscar Wylee is available to provide all your eye care and
eyewear needs.
### What are the Other Closest Optometrist Locations to Keilor
Central, Victoria in Australia?
The closest optometrist Oscar Wylee location to Keilor Central,
Victoria in Australia is
Epping, Doncaster and Moonee Ponds. The closest
optometrist locations to Keilor Central, Victoria are listed
below.
* Epping:  Epping is a suburb approximately 30 km away
from Keilor Central where you can find optometrists including
Oscar Wylee.
[Oscar Wylee Pacific Epping](https://www.oscarwylee.com.au/locations/optometrist-epping.html)
is located on the ground floor of the Pacific Epping Shopping
Centre, where our team are available to provide a range of eye
care services.
* Doncaster:  Doncaster is a location close to Keilor
Central, approximately 38 km away in which there are several
optometrists available.
[Oscar Wylee Doncaster](https://www.oscarwylee.com.au/locations/optometrist-doncaster.html)
is located in the Doncaster Westfield shopping centre. Here
our optometrists provide Medicare bulk billed eye tests.
* Moonee Ponds:  Moonee Ponds is a suburb approximately
15 km away from Keilor Central, where there are several
optometrists including Oscar Wylee. You can find
[Oscar Wylee Moonee Ponds](https://www.oscarwylee.com.au/locations/optometrist-moonee-ponds.html)
in the Moonee Ponds Central Shopping Centre where our team
provides eye care services such as eye tests and new frames.
### Bulk Billed Eye Tests with Oscar Wylee Optometrists
Oscar Wylee Keilor Central offers a range of eye care processes
including Medicare bulk billed eye health tests, which assess vision
and help to detect eye diseases or conditions. Come in and have your
prescription updated and shop for a new pair of eyeglasses on the same
day. For high-quality eye care and optometrists near you in Keilor
Downs, come in and see the team at Oscar Wylee Keilor Central!
### Health Fund Claims at Oscar Wylee Keilor Central
Our Oscar Wylee eyeglasses shop in Keilor Central accepts leading
health funds in-store. Bring your valid health fund card to our store
and our Keilor Central Oscar Wylee team can help process your claim
and answer any questions you have about eligibility.
### Fashion-Forward Frames at Oscar Wylee Keilor Central
At Oscar Wylee Keilor Central, our in-store team can help you shop our
range of frames, from prescription eyeglasses, prescription
sunglasses, and non-prescription glasses. Oscar Wylee glasses come in
a variety of shapes, sizes and colours, with both modern and vintage
design inspirations. There’s a frame for everyone at Oscar Wylee and
the team in Keilor Central will help you find the pair that are
perfect for you!
Book Appointment
[Call us: 1300 164 990](tel:1300 164 990)