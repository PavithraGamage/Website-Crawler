# Source: https://www.oscarwylee.com.au/glasses/eye/polarised-sunglasses-blocks-blue-light

# Do Polarised Sunglasses Block Blue Light?
Updated on December 17th, 2024
Published on July 11th, 2023
Australia
[Australia](https://www.oscarwylee.com.au/glasses/eye/polarised-sunglasses-blocks-blue-light)
[New Zealand](https://www.oscarwylee.co.nz/glasses/eye/polarised-sunglasses-blocks-blue-light)
[Canada](https://oscarwylee.ca/glasses/eye/polarized-sunglasses-blocks-blue-light)
[Canadian French](https://oscarwylee.ca/fr/glasses/eye/polarized-sunglasses-blocks-blue-light)
Yes, polarised sunglasses
may be able to block blue light when outdoors depending on the particular
lens coating and only to certain degrees.
Polarised lenses are created by coating the lenses with a certain chemical.
The chemical used on polarised sunglasses is laminated with a special
pattern that vertically blocks any reflected horizontal light from flat
reflective surfaces. The only amount of light that is able to pass through
polarised lenses are light rays that have bounced off vertically. As a
result, only a reduced amount of light can fit through, which causes images
to appear darker than they do through regular sunglasses according to the
American Academy of Ophthalmology. Polarised sunglasses were invented in
1929 by a Harvard University student, Edwin Land according to Mivision.
Glare can occur when light waves reflect off surfaces such as bodies of
water, snow, or shiny and smooth surfaces. According to TheraSpecs and Total
Vision, most sunglasses, including polarised sunglasses, may be effective in
blocking blue light and offer protection from UV rays and glare. However, it
is important to note that
not all sunglasses and polarised sunglasses offer equal levels of
protection.
Oscar Wylee offers polarised sunglasses that provide good UV protection and
includes an anti-reflective coating.
[Definition](#Definition) [Advantages](#Advantages)
[Disadvantages](#Disadvantages)
[Choosing Polarised Sunglasses](#Choosing)
## What are Polarised Lenses in Sunglasses?
The polarised lenses in sunglasses have a
special coating that is designed to reduce light, in turn making the
appearance of images darker but also clearer in detail.
The answer to what are the chemicals used for polarising sunglasses
lenses is heated PVA material that is stretched to create a long chain
molecule. PVA stands for polyvinyl alcohol which is an odourless,
colourless synthetic polymer that can be dissolved in water. The long
chain molecule is vertically positioned along the lens in a single
direction, similar to blinds on a window, according to Dave Barton. This
sheet is then laminated between two high-quality lenses with an
injection mold. The answer to how does the chemical’s molecules that are
lined up for blocking sunlight in polarised sunglasses work is that they
are essentially like blinds on your sunglasses. These ‘blinds’ only
allow vertical light rays to reach your eyes.
### How Do Polarised Sunglasses and Lenses Work?
Polarised sunglasses and lenses work
by blocking some of the scattered light that normally reflects off
surfaces at different angles. The long chain molecule on polarised
lenses functions as a filter that helps only vertical light to pass
through.
The material used is a film of polyvinyl alcohol that is heated and
stretched. Polarised sunglasses are able to maintain their
polarisation unless the lenses are damaged, so it is important to take
care of them. You can take care of your polarised sunglasses by
cleaning them with a microfibre cloth and a lens cleaner. Be sure to
gently wipe the lenses to prevent scratching them.
Do you have any concerns about your vision?
See one of our friendly optometrists today.
[Book an eye test](https://www.oscarwylee.com.au/booking)
### How Do Polarised Sunglasses Block Blue Light?
Polarised sunglasses may be able to block blue light from the sun to
certain degrees, depending on the level of protection they offer
against visible light.
Polarised sunglasses can block horizontal light and as a result,
can potentially block a certain amount of blue light,
according to Total Vision and the National Library of Medicine.
However, polarised glasses are specifically designed to reduce glare,
especially from surfaces such as water, glass and snow. Consequently,
although impeding more light from reaching the eyes may mean
protection from blue light, it is uncertain how much
[blue light](https://www.oscarwylee.com.au/glasses/blue-light)
can be blocked. According to the National Library of Medicine, most
sunglasses have plastic (polycarbonate or Trivex) lenses which can
naturally protect the eyes from UV light. The absorption rate of UV
radiation for most sunglass lenses is 400mm, which is in accordance
with the cutoff for the Australian/New Zealand standard.
#### Is it Bad to Wear Polarised Lens Glasses All Day?
Yes, it may be bad to wear polarised lens glasses all day.
Polarised glasses hinder a significant amount of light from
reaching the eyes, therefore, they are not suitable for driving at
night or in low light conditions.
They can be worn every day in sunny conditions, especially for those
who go fishing, golfing, boating or spend their time in the snow. It
is not advisable to use polarised glasses when looking at LCD
screens as they can alter the colour of LCD screens, making them
look either black or darkened according to the American Academy of
Ophthalmology. LCD screens can include cell phones, car dashboards
and ATM machines.
## What are the Advantages of Polarised Sunglasses?
The advantages of polarised sunglasses are
reduced glare, better display of colours, clearer vision and the
option to add them to many different styles of sunglasses.
The advantages of polarised sunglasses are listed below.
* Reduced Glare: Polarised glasses can
aid with reduced glare, especially in circumstances where you may be
driving with the sun shining directly at your windshield. They are
also suitable for outdoor activities out on the water or in the snow.
* Better Display of Colours: Polarised
glasses may be able to result in a better display of colours due to
their function of reducing scattered light. Blocking more light can
help colours show more accurately.
* Clearer Vision: Polarised glasses can
assist with clearer vision as the reduced light and glare can increase
the contrast which will help objects and details appear sharper and
more accurate in colour.
* Colour and Style Options: A
polarisation filter can be added to any colour and style of frames,
allowing you to choose the style you like best. However, your
optometrist may advise frames that are best for polarisation.
## What are the Disadvantages of Polarised Sunglasses?
The disadvantages of polarised sunglasses can include
poor low-light visibility, the altered appearance of LCD screens and
when conditions may require more light.
The disadvantages of polarised sunglasses are listed below.
* Poor Low Light Visibility: Polarised
sunglasses may not be suitable for low-light conditions and for
night-time use due to how much light they block out.
* Altered Appearance of LCD Screens:
Polarised sunglasses can alter the appearance of LCD screens as they
can make them look darkened or completely black. LCD screens can
include your smartphone, ATM machines and computer and television
screens.
* When Conditions Require More Light:
Polarised sunglasses may be disadvantageous when conditions require
more light. There are some cases where glare or extra light is needed
for safety such as driving on icy roads.
## What are the Best Polarised Sunglasses?
The best polarised sunglasses
should have a clear label stating UV 400 or 100% protection from UV
rays
according to All About Vision. It is important for polarised sunglasses
to include this as not all polarised sunglasses provide protection
against UV rays. Oscar Wylee offers polarised lenses that offer UV 400
protection and are available in brown, grey and green tints.
### How to Choose the Best Polarised Sunglasses?
Choosing the best polarised sunglasses is important for when and how
you may use them. Firstly, it is important to make sure they
are labelled with either 100% protection from UV rays or UV 400.
This is to ensure they effectively block out the right amount of UV
light to properly protect your eyes. Secondly,
consider your frequent activities and lifestyle. If you are an
active person that frequents outdoor based activities or if you
causally spend time outdoors or prefer to stay indoors. This can
affect how much you want to spend on a pair of polarised sunglasses
and the level of durability you require.
#### Does Face Shape Matter for Choosing a Polarised Sunglasses Frame?
Yes, face shape can matter when choosing a polarised sunglasses
frame.
There are certain frames that are more suited for each face
shape, therefore, it can be beneficial to choose frames according
to your face shape.
You can determine what face shape you have based on your particular
facial features and dimensions, which you can read more about in our
[best glasses for different face shapes](https://www.oscarwylee.com.au/glasses/face-shapes)
article. The most common frame shapes are rectangle, square, oval,
round and cat eye. For round, oval, and diamond face shapes,
rectangle frames are most suited. For square, diamond and pear face
shapes, oval frames are recommended. Square glasses suit heart, oval
and round face shapes. Cat eye glasses suit diamond, pear and round
face shapes. For rectangle, square and pear face shapes, round
glasses are best suited.
Find an Oscar Wylee store near you
Our knowledgeable and friendly team can help you find a pair of
stylish and affordable frames.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
## How Do Polarised Sunglasses Protect Eye Health?
Polarised sunglasses protect eye health
by blocking horizontal light waves which can cause glare and
excessive light reflection.
Polarised sunglasses can protect the eyes against UV rays, given that
they are labelled with either 100% protection from UV rays or UV 400.
Reducing glare and excessive light reflection may be able to prevent eye
strain and irritation that can occur from too much light reaching the
eyes. Learn more about how you can
[keep your eyesight healthy.](https://www.oscarwylee.com.au/glasses/eye/health-tips-keeping-eyesight-healthy)
### When to Use Polarised Sunglasses?
Polarised sunglasses can be used
when you are driving and the sun is shining directly in your
eyeline. Polarised sunglasses may also be used during outdoor
activities during sunny conditions,
especially when you are out on the boat or out in the snow. Polarised
sunglasses may be beneficial for individuals who frequently partake in
outdoor activities, especially watersports or winter sports. The
answer to when to not use polarised sunglasses is during the use of
devices with liquid crystal display (LCD) screens, which include
televisions, computer monitors, most smartphones and some car
dashboard controls. It is also strongly advised not to use polarised
sunglasses during low light conditions and during night.
#### What are Polarised Lenses For?
Polarised lenses are used for
the purpose of eliminating glare and excessive light reflection
that can be brought on by sunny weather.
Polarised lenses specifically impede light waves that are
horizontally reflected from surfaces that are shiny or smooth. The
reason for needing to reduce glare is due to the potential
irritation, discomfort or eye strain that can occur when our eyes
are exposed to excessive light.
### What are the Types of Polarised Lenses?
The types of polarised lenses are
polarised lenses with laminated film and polarised lenses with thin
film
according to Lensology and Sport RX. The types of polarised lenses are
listed below.
* Thin Film: Polarised lenses that are
made with a thin film that is coated on one side of the lens. These
may result in a film thickness of only 0.75mm and are categorised as
a lower quality option of polarised lenses.
* Laminated Film: Polarised lenses
with laminated film in between the lens material may result in a
thicker film of 1.1mm and is considered a higher quality option for
polarised lenses.
#### How Do Polarised Lenses Protect Against Glare?
Polarised lenses protect against glare
with their coating of long chain molecules that are positioned
specifically to block out horizontally reflected light waves. Glare can occur when the sun is shining directly in your view of
sight or when light is reflected off surfaces that are smooth or
shiny. Glare can also occur during the night when driving past other
cars that have their headlights or high-beam lights on, however, it
is strongly advised not to wear polarised sunglasses in lowlight
conditions or during the night as it can hinder your vision. You can
read more helpful information about how you can protect your eyes
against glare in our
[anti-glare (anti-reflective) glasses](https://www.oscarwylee.com.au/guides/lenses/anti-glare)
article.
#### How Do Polarised Lenses Work?
Polarised lenses work
by reducing excessive brightness and glare during driving and
outdoor activities.
Polarisation can be added to sunglasses and cannot be removed
afterwards. Polarised lenses are specifically for blocking excessive
light and glare during the day. They are not intended for any other
purposes.
##### What Are Polarised Lenses Not For?
Polarised lenses are
not for nighttime use, when looking at LCD screens or during
certain conditions when extra light may be helpful. Polarised lenses are not suitable to use during night as they
are designed to block out a significant amount of light. Polarised
lenses should not be used for blocking blue light from digital
devices as they can change the colour of LCD screens.
Additionally, polarised sunglasses may not be able to block the
blue light from digital devices according to the American Academy
of Ophthalmology. Although polarised lenses are able to provide
protection against glare and excessive light, they are not for
looking at the sun.
##### When to Choose Polarised Lenses Compared to When to Choose Tinted
Lenses For Sunglasses?
It may be advisable to choose polarised lenses
when you want to reduce glare or excessive light reflection. However, tinted lenses can offer different benefits,
including reducing some glare depending on the colour of the
lenses according to All About Vision. Blue or purple tinted
lenses can offer enhanced colour perception, defined shapes and
lines of objects and reduction of glare that can come from water
and snow. Blue/purple lenses may be suitable for foggy or misty
conditions according to Vision Direct. Red or pink tinted lenses
can block blue light as well as improve depth of field and
visibly clarify details of objects Red/pink lenses may be
helpful for skiing and other winter sports. Brown tinted lenses can help increase brightness during cloudy
conditions, filter blue light, and improve depth of perception.
Brown/yellow lenses may be beneficial for indoor and outdoor
sports such as golf or baseball.
While different coloured tinted lenses can offer varying
benefits and provide aid during different activities, polarised
sunglasses may be more capable of eliminating harsh glare.
## When to Choose Polarised Sunglasses Over Blue Light Blocking Glasses?
It may be best to choose polarised sunglasses over blue light block
glasses
when you are spending time outdoors or driving in sunny weather. Blue
light blocking glasses are mainly intended for use when spending long
hours looking at digital screens.
However, polarised sunglasses may be able to block blue light emitted
from the sun due to the amount of light it can block. Sunglasses without
polarisation are capable of blocking blue light from the sun to certain
degrees, therefore, either sunglasses or polarised sunglasses are both
viable options. If you are concerned about blue light affecting sleep
quality or quantity, blue light blocking glasses may be a helpful option
as they are designed to either absorb or reflect blue light. Read our
article for the
[best blue light blocking glasses](https://www.oscarwylee.com.au/glasses/blue-light/review).
### When to Choose Polarised Sunglasses Over UV Blocking Glasses?
It is best to choose sunglasses that have both polarisation and UV
blocking capabilities. In some cases
polarised sunglasses are capable of providing protection against UV
rays
although it is important to note that not all polarised sunglasses
offer equal levels of protection against glare and UV rays. Therefore,
it is vital to
ensure that when choosing polarised sunglasses, that they are
clearly labelled with 100% protection from UV rays or UV 400.
The difference between UV light and blue light is their wavelength
with blue light measuring at 400 to 495 nm and UV light measuring at
10 to 400 nm which is not visible to the human eye according to the
Centre for Science Education. At Oscar Wylee, we offer polarised
lenses that provide 100% protection against UV rays and are available
in brown, grey and green. Read our
[best types of UV sunglasses](https://www.oscarwylee.com.au/glasses/best-uv-sunglasses-for-eye-protection)
article to learn more about options for blocking UV.
## What are the Other Types of Sunglasses Lenses Besides Polarised Lenses?
The other types of sunglasses lenses besides polarised lenses include
photochromic sunglasses and wraparound style sunglasses.
Photochromic sunglasses also known as transition lenses are a good
option for protection and function by darkening in response to UV rays.
Photochromic have a coating that causes them to darken when exposed to
direct sunlight with the darkness of the lenses increasing according to
how many rays there are. Wraparound style sunglasses are another type of
sunglasses that fit closely around the face and help to reduce the
entrance of light that may come from the sides. Both photochromic
sunglasses and wraparound style sunglasses are recommended options for
suitable sun protection. At Oscar Wylee, we offer both photochromic
lenses and wraparound style sunglasses.
### Are Polarised Sunglasses Better Than UV Protection Glasses?
No, polarised sunglasses
may not be better than UV protection glasses as polarised
sunglasses are designed to help reduce glare and increase the
contrast of images. However, conditions may not always cause
excessive brightness and glare.
UV protection glasses may be more beneficial as UV light is always
present during the day, even in colder seasons.
[Polarised sunglasses and UV protection glasses](https://www.oscarwylee.com.au/glasses/eye/polarised-vs-uv-protection)
offer different benefits, especially depending on weather conditions.
However, it is always recommended to opt for UV protection to prevent
the risk of UV light damage over time.
Read Do Polarised Sunglasses Block Blue Light in other Oscar Wylee
regions and their languages.
Australia
[Australia](https://www.oscarwylee.com.au/glasses/eye/polarised-sunglasses-blocks-blue-light)
[New Zealand](https://www.oscarwylee.co.nz/glasses/eye/polarised-sunglasses-blocks-blue-light)
[Canada](https://oscarwylee.ca/glasses/eye/polarized-sunglasses-blocks-blue-light)
[Canadian French](https://oscarwylee.ca/fr/glasses/eye/polarized-sunglasses-blocks-blue-light)
Find your nearest Oscar Wylee store
Come and visit your local store and our team will help you with your
eye care needs, from eye tests to new frames.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
Our Oscar Wylee optometrists cover a range of eye care services.
Visit our dedicated team in-store today.
[Book an eye test](https://www.oscarwylee.com.au/booking)