# Source: https://www.oscarwylee.com.au/eye-care/eye-conditions/hyperopia

# Hyperopia (Farsightedness) - Meaning, Causes, Treatment
Hyperopia, also known as farsightedness or longsightedness, is a refractive error in which light entering the eye does not focus properly. If a person has hyperopia, they will have more trouble seeing nearby objects, whereas distance objects are generally more in focus. Hyperopia is a condition that can be treated with glasses or laser eye surgery if suitable. Keep reading to find out more about hyperopia, what the symptoms are, and how it can be corrected.
Need an eye test?
Book online with one of our Oscar Wylee optometrists.
[Book an eye test](https://www.oscarwylee.com.au/booking)
## What is hyperopia (farsightedness)?
Hyperopia (farsightedness) describes a condition in which light does not refract within the eye correctly, affecting how well the eye sees objects at a near distance. One of the most common symptoms of hyperopia is blurry near vision. If a person has hyperopia, their distance vision will often remain clear. If the hyperopia is unable to be accommodated by the eye, it may affect both near and distance vision. Generally, people with hyperopia are born with it. Hyperopia is not to be confused with presbyopia, which is an age-related condition in which the eye struggles to see near objects.
### What is latent hyperopia?
Latent hyperopia refers to hyperopia that the eye is able to hide or cover up. If a person has latent hyperopia, the muscles of the eye can reduce or mask the symptoms of hyperopia such as blurry vision, by working extra hard to focus. Though latent hyperopia may mask a person’s inability to focus on near objects or reduce blurry vision, this masking does not correct farsightedness issues. There are several symptoms that indicate a person has latent hyperopia, listed below.
* Eye strain
* Fatigue
* Headaches
* Poor hand and eye coordination
* Misaligned eyes (Strabismus)
## Symptoms of hyperopia (farsightedness)
One of the most common symptoms of hyperopia (farsightedness) is blurry near vision. There are, however, some additional symptoms to look out for, listed below.
* Eyestrain
* Headaches
* Eye squinting
* Difficulty reading small print
* Dull eye pain after reading small print or conducting other close up work
## What causes hyperopia (farsightedness)?
Hyperopia (farsightedness) is a refractive error, meaning that the light entering your eye does not bend properly. When the eye looks at light, the cornea and the lens work together to move this light into the eye, towards the retina, which then sends the image signals to the brain. If someone has hyperopia, the combined focal power of the cornea and lens is often weak, or the eyeballs may be on the smaller side. As a result, the light entering the eye is directed more towards the back of the retina instead of on the retina. This causes blurry near vision.
Source: American Academy of Ophthalmology
### Who is most likely to get hyperopia (farsightedness)?
Hyperopia (farsightedness) is a condition that can affect all people, including adults and children. However, people who have a family history of hyperopia, are at greater risk of developing the condition.
## How is hyperopia (farsightedness) diagnosed?
Hyperopia (farsightedness) is most often diagnosed during a comprehensive eye test, likely with an optometrist. The tests that may diagnose hyperopia are listed below.
* Visual acuity test: This test measures the sharpness and clarity of your vision at certain distances.
* Near and binocular vision testing: This test assesses numerous visual functioning and perceptual skills including but not exclusive to; accommodation (eye focusing skills), vergence (eye teaming), ocular motility (eye movements) and depth perception (3D vision).
* Refraction test: This test helps to assess what prescription glasses a person may need, whilst also assessing how well the cornea and lens are working.
## Hyperopia (farsightedness) treatment
The goal of hyperopia (farsightedness) treatment is to fix the refractive error that is causing light to focus behind the retina, as opposed to on the retina. Treatment can include corrective lenses and laser eye surgery.
### How is hyperopia (farsightedness) corrected?
Hyperopia (farsightedness) can be corrected through the use of corrective lenses, or laser eye surgery, which you may have heard referred to as LASIK eye surgery. Corrective lenses, or glasses lenses, are the most common way to correct hyperopia. Corrective lenses will help direct the light entering the eye on the retina, as opposed to behind the retina. The lenses that correct hyperopia are called convex or plus lenses. Convex lenses are thickest in the centre and help light refocus back onto the retina. Laser eye surgery is a procedure in which a laser is used to help reshape the structure of the eye. Laser eye surgery can be used to treat hyperopia by reshaping the cornea, helping light to focus on the retina. Laser eye surgery can comfortably correct prescriptions up to +3.00D. There are many pros to getting laser eye surgery for hyperopia treatment, including a reduction in symptoms and lesser need for strong optical glasses. One of the major cons of laser eye surgery is that not everyone will be a suitable candidate for the procedure. If a person has corneas that are very thin, or are suffering from cataracts for instance, they may not be able to get this surgery. If you believe you have hyperopia and may benefit from treatment, it is always best to speak with an optometrist. Come in and speak to the team and see how they can help you take the next step in looking after your eye health.
NOTE: Oscar Wylee does not provide laser eye surgery.
Find your local Oscar Wylee store.
Come in and see the team for your eye care needs.
[Find a Store](https://www.oscarwylee.com.au/locations/full-store-list.html)
## How can I prevent hyperopia (farsightedness)?
Hyperopia (farsightedness) is not generally a condition that can be prevented. However, there are some measures that you can take to protect your eyes and your vision, and help slow the progression of symptoms. Some of the ways you can take care of your eyes and maintain good eye health are listed below.
* Eye testing: Keep up with your regular eye test, even if you feel your vision is clear. An optometrist will be able to monitor the progression of myopia during an eye test.
* Wear Sunglasses: Protect your eyes from the sun and damaging UV rays by wearing sunglasses outside. This will help maintain good eye health.
* Rest your eyes: When looking at digital screens for extended periods, be sure to regularly rest the eyes, to avoid straining them.
* Maintain a healthy lifestyle: Eating well, exercising and avoiding tobacco products, can help maintain good eye health.
## Hyperopia vs presbyopia
Hyperopia and presbyopia are similar in that both conditions affect a person’s ability to see objects at a close distance. Where hyperopia and presbyopia differ are in their causes. Where people may be born with hyperopia, presbyopia is an age related condition in which the lens hardens over time, becoming less flexible. This makes it hard for the eye to focus on objects close up. Presbyopia generally begins around age 40 and onwards. A person can have hyperopia and presbyopia at the same time. Those with hyperopia may find that presbyopia begins to develop earlier than those without.
## Hyperopia (farsightedness) vs myopia (nearsightedness)
Myopia (nearsightedness) is the opposite condition to hyperopia (farsightedness). Myopia refers to an eye condition in which objects at a far distance may appear blurry, whilst near vision generally remains clear, unless affected by another, unrelated vision issue. Myopia is caused by a refractive error in which light focuses in front of the retina, as opposed to on the retina, the opposite refractive issue to hyperopia.
### Can you have myopia and hyperopia at the same time?
Generally, a person can not have myopia and hyperopia in the same eye, at the same time. You may have one eye that has myopia and the other with hyperopia, but not in the same eye. A person may have hyperopia and another eye condition called astigmatism in one eye, at the same time. Astigmatism is a condition in which the curve of the eye is misshapen, which may cause blurred or distorted vision at near or far distances.
## Hyperopia (farsightedness) complications
If left untreated, hyperopia (farsightedness) may produce complications such as amblyopia (lazy eye), eye strain, reduced quality of life and in children, strabismus (misaligned eyes) and learning difficulties. If you are having trouble seeing things at a near distance, come into one of our stores and our dedicated optometrists will conduct an eye test to determine if you have hyperopia.
## Hyperopia (farsightedness) in children
Hyperopia (farsightedness) is an eye condition that can affect children just as much as it affects adults. As so much of a child’s development relies on sight, it is important that you get your child’s eyes examined if they are showing signs of hyperopia. Generally, the symptoms of hyperopia for children are the same as the symptoms for adults. Hyperopia can contribute to issues with learning and reading in school if left untreated. It is important to remember that not all optometrists perform eye tests on children. It is best to contact your optometrist and ask before making any appointments for your child.
## How to know if you have hyperopia (farsightedness)?
The best way to determine if you have hyperopia (farsightedness) is to have an eye test. Book an appointment with one of our dedicated Oscar Wylee optometrists, and they will be able to conduct the appropriate exams to determine if you have hyperopia.
There are many other common eye conditions such as macular degeneration that can affect a person’s vision. [Read more about AMD](https://www.oscarwylee.com.au/eye-care/eye-conditions/presbyopia) and its symptoms.
## Find a store near you
Contact or visit your nearest Oscar Wylee Store.
[Find a store near you](https://www.oscarwylee.com.au/locations/full-store-list.html)
## Due for an eye test?
Oscar Wylee offers bulk billed eye tests for eligible Medicare cardholders.
[Book an eye test](https://www.oscarwylee.com.au/booking)