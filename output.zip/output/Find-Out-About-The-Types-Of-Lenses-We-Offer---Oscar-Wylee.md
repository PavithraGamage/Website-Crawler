# Source: https://www.oscarwylee.com.au/faq-lenses.html

* [POPULAR FAQS](https://www.oscarwylee.com.au/faq-popular.html)
* [ORDERING](https://www.oscarwylee.com.au/faq-ordering.html)
* [PRESCRIPTIONS](https://www.oscarwylee.com.au/faq-prescriptions.html)
* [SUNGLASSES](https://www.oscarwylee.com.au/faq-sunglasses.html)
* [RETURNS &amp; WARRANTIES](https://www.oscarwylee.com.au/faq-returns.html)
* [PAYMENT](https://www.oscarwylee.com.au/faq-payment.html)
* [HEALTH FUNDS](https://www.oscarwylee.com.au/faq-healthfund.html)
* [LENSES](https://www.oscarwylee.com.au/glasses/eye/types-of-lenses)
* [FRAMES](https://www.oscarwylee.com.au/faq-frames.html)
* [SHIPPING](https://www.oscarwylee.com.au/faq-shipping.html)
* [EYEWEAR STYLING TIPS](https://www.oscarwylee.com.au/faq-eyewear-styling-tips.html)
POPULAR
ORDERING
PRESCRIPTIONS
SUNGLASSES
RETURNS &amp; WARRANTIES
PAYMENT
HEALTH FUNDS
LENSES
FRAMES
SHIPPING
EYEWEAR STYLING TIPS
### LENSES
What lens types do you offer?
We have a lot of different lens types available:
SVD (Single Vision Distance) - SVD lenses are used for far distance like driving, tv, or walking around. Some people can have a SVD prescription and use this for everything. This is called a constant or SVC (Single Vision Constant) prescription.
SVN (Single Vision Near) - SVN lenses are used for close vision like reading books or magazines.
SVI (Single Vision Intermediate) (Only available to order in store) - SVI lenses give clarity around 1m away. Good for computer use or reading sheet music when playing an instrument.
Multifocal (Only available to order in store) - Multifocal lenses, also known as progressive lenses, give multiple focal lengths from one lens. They have multiple prescriptions ground into the lens. They look like a standard lens but help you to see in the distance (like driving or tv), medium-range (like computer distance) and near (reading books or a phone).
Non-prescription - These are lenses with no prescription.
Do I have to pay extra for lens coatings?
All of our prescription lenses come with scratch resistance and UV-proof coatings as standard. We have various lens extras available for an additional fee.
What lens coatings do you offer?
We have a lot of different lens coatings available:
Anti-Reflective - A coating added to the lens that makes the lens anti-reflective, scratch-resistant and added UV protection.
Premium Anti-Reflective - This has the same benefits as our Anti-Reflective coating with the added advantages of extra scratch resistance, smudge resistance and anti-static.
Blue Light Filter - This lens neutralises the blue light that emits from LCD/LED screens, such as computers, TV screens and smartphones. It can help in reducing eye strain and fatigue.
Please note this filter is only available for clear lenses and is unavailable for sunglasses due to the tint. Our Blue Light Filter is only available in standard 1.5, 1.6 and 1.67 index lenses. For more information, please visit our [Blue Light Glasses](https://www.oscarwylee.com.au/blue-light-glasses.html) page.
Tint - A dye added to the lenses to make them darker for sunglasses. Includes our Basic Anti-Reflective coating as standard.
Polarised - A coating that is applied to the lens to darken it and add colour. This also cuts out glare on the horizontal wavelength. Also includes our Basic Anti-Reflective coating as standard.
Photochromic - Clear lenses that tint to grey when exposed to UV light.
My glasses have already arrived. Can I add any lens coatings?
All our lenses are treated before they're cut to fit your new glasses. As a result of this, we are unable to add coatings after production has finished.
Do you offer multifocal lenses?
Yes, we offer multifocal lenses (also known as progressive lenses). Although, to order you must visit one of our [stores](https://www.oscarwylee.com.au/locations.html) to be correctly measured for these lenses. Buy one pair from our optical range and you can get standard multifocal lenses for FREE.
If you are unable to make it to a store, you can always purchase the frames as non-prescription and your local optician can fit multifocal lenses. This is not included in our one pair with free multifocal lenses.
Do you offer reading glasses?
Of course, we do! Just select the frames you’d like to buy and click the “Add to Cart” button to add them to your shopping cart. During checkout, you’ll be given the option to purchase a prescription or non-prescription, Single vision distance or Single vision near glasses. Select “Single Vision Near”.
Can you provide high-index (thinner and lighter) lenses?
We sure can! For those who need stronger prescriptions, we offer high index options. One of our store team can help you select the best lenses based on your prescription.
If your prescription contains a combined Sphere and Cylinder value of +/-3.00 or stronger, when you order online, you will be prompted during the checkout process to add high-index lenses to your order. This only applies if you manually entered your prescription details and not uploaded a picture or entered your optometrist details.
If unsure, [contact us](https://www.oscarwylee.com.au/contact) before you place your order. We also check all online orders before they go to our lab and may contact you via email if we think a different lens type to the one chosen is more suitable.
How do I clean my lenses?
It's easy to clean your lenses. Read [here](https://www.oscarwylee.com.au/eye-care/guides/how-to-clean-glasses) for detailed instructions.
We also recommend using our lens spray (available to purchase in all our stores).