# Source: https://www.oscarwylee.com.au/health-funds/hif.html

# HIF at Oscar Wylee
As a member of HIF, you can claim on optical extras using your health
fund’s coverage for optical services, such as prescription frames,
lenses or glasses. HIF benefits reset every calendar year,
claim your glasses before time runs out! At the end of the year, any
extras you don’t use will be lost.
With Oscar Wylee, you can have up to 100% coverage on select
optical purchases when you shop with us. Look at the table below to see
your HIF policy’s name and the amount of coverage that policy gives when
you shop at Oscar Wylee. Your coverage might change or not
apply to extras such as add-ons, coatings or tinting.
## Take care of your eyes today
Oscar Wylee offers no-gap bulk billed eye exams. Book yours
today!
[Get your eyes tested](https://www.oscarwylee.com.au/booking)
#### Waiting Period
2 Months
#### Benefit Limits Reset
1st of January
#### Claimable Benefits %
100%
To learn whether your plan includes single vision-lenses, bifocal lenses
and/or multifocal lenses, talk to your health insurance provider.
| Your Extras Package Annual Limit:* | Basic Extras | Value Extras | Simple Extras | Essential Extras | Advanced Extras | Top Extras | SINGLES COVER | 1 Standard OW Pair
from $169^ | 2 Standard OW Pairs
from $199^ | 3 Standard OW Pairs
from $249^ |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| $150 per person | $150 | $200 per person | $200 | $275 | $300 |
| Partial Cover | Partial Cover | Covered | Covered | Covered | Covered |
| Partial Cover | Partial Cover | Covered | Covered | Covered | Covered |
| Partial Cover | Partial Cover | Partial Cover | Partial Cover | Covered | Covered |
^Excludes add-ons. Standard frames and lenses only. Oscar Wylee’s
standard product inclusions are calculated based on the optical
allowances under each health fund package and may vary. If unsure,
please confirm with your provider. Our two pair and three pair deals are
only available per person and cannot be split between two people. Only
one prescription can be used per offer. If you have a distance and a
reading prescription, this is included in the offer as this is
considered to be one prescription. Any prescriptions must have the full
name of the person claiming and a valid expiry date to be able to order.
If you have two different prescribed prescriptions, you will need to
visit a store to be eligible for our two pair and three pair deals.
| FAMILY COVER | 1 Standard OW Pair
from $169^ | 2 Standard OW Pairs
from $199^ | 3 Standard OW Pairs
from $249^ |
| --- | --- | --- | --- |
| $300 per policy | $150 per person | $400 per policy | $200 per person | $275 per person | $300 per person |
| Partial Cover | Partial Cover | Covered | Covered | Covered | Covered |
| Partial Cover | Partial Cover | Covered | Covered | Covered | Covered |
| Partial Cover | Partial Cover | Partial Cover | Partial Cover | Covered | Covered |
^Excludes add-ons. Standard frames and lenses only. Oscar Wylee’s
standard product inclusions are calculated based on the optical
allowances under each health fund package and may vary. If unsure,
please confirm with your provider. Our two pair and three pair deals are
only available per person and cannot be split between two people. Only
one prescription can be used per offer. If you have a distance and a
reading prescription, this is included in the offer as this is
considered to be one prescription. Any prescriptions must have the full
name of the person claiming and a valid expiry date to be able to order.
If you have two different prescribed prescriptions, you will need to
visit a store to be eligible for our two pair and three pair deals.
## Get a Full Quote in Store
Get fitted for your next pair of glasses at Oscar Wylee by visiting
us in store and talk to our friendly staff for a complete
quote.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
*Based on HIF’s
[Cover Guide](https://www.hif.com.au/health-insurance/extras-cover)
and product factsheet as presented to the Commonwealth Ombudsman:
[1](https://www.hif.com.au/theme/hif/assets/public/File/Factsheets/HIF_Basic_Extras.pdf)
[2](https://www.hif.com.au/theme/hif/assets/public/File/Factsheets/HIF_Value_Extras.pdf)
[3](https://www.hif.com.au/theme/hif/assets/public/File/Factsheets/HIF_Simple_Extras.pdf)
[4](https://www.hif.com.au/theme/hif/assets/public/File/Factsheets/HIF_Essential_Extras.pdf)
[5](https://www.hif.com.au/theme/hif/assets/public/File/Factsheets/HIF_Advanced_Extras.pdf)
[6](https://www.hif.com.au/theme/hif/assets/public/File/Factsheets/HIF_Top_Extras.pdf)
. 
1With HIF’s Value Extras, Essential Extras, Advanced Extras
and Top Extras policies, the annual limit is applied per person.
Dependents are given the same cover limit as the primary member, the
amount is not shared between all parties.
Information correct as of November 2024.
## Your eye test explained
Routine eye test appointments are quick and painless. Find out
what to expect during an eye exam and how to understand your eye
test results.
[Find out more](https://www.oscarwylee.com.au/eye-health/your-eye-test-explained.html)
## Bulk Billing
Find out what bulk billing is and whether you're eligible to
receive an eye test free of charge.
[Find out more](https://www.oscarwylee.com.au/eye-health/eye-test-info/bulk-billing.html)
## What is Pupillary Distance? (PD)
Do you know your PD? It's something you'll need to know when
ordering glasses online. Find out what Pupillary Distance is and
how you can measure your own.
[Read more](https://www.oscarwylee.com.au/eye-care/eye-test/what-is-pupillary-distance.html)
## Book an eye test
Oscar Wylee eye tests are bulk billed through Medicare. This
means there will be no out-of-pocket expense for eligible
Medicare cardholders.
[Book online](https://www.oscarwylee.com.au/booking/)
## Find a store near you
Contact or visit your nearest store for a full quote.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)