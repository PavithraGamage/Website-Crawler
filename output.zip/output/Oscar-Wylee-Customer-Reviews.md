# Source: https://www.oscarwylee.com.au/review

# Oscar Wylee Reviews
Hear what our beloved #OW customers had to say about our frames and services
"I went in for an eye test and the whole process was smooth and hassle-free from start to finish.. Dr Natasha, a professional through and through, made everything easy to understand. The service by the team, 2 lovely young ladies at the counter, were efficient, and the attention to detail ensured I got exactly what I needed. Overall, a seamless and positive experience—highly recommended Oscar Wylee Castle Towers."
– Devi M
Store Location: Castle Towers, NSWSource: Google
"Such friendly and professional staff. My optometrist was very supportive and knowledgeable regarding my sight and astigmatism. Looking forward to my new flashier frames and more importantly, my new lenses. Thank you Oscar Wylee Frankston."
– Pam M
Store Location: Frankston, VICSource: Google
"I've always had such a pleasant experience every time I come in for my appointments. The staff are very friendly and helpful. I personally recommend Oscar Wylee Eyewear to my family and to anyone that wants a great and comfortable and well looked after experience."
– Mandy I
Source: Trust Pilot
"Excellent service! Everyone was friendly, professional and very thorough. They took the time to explain everything clearly and made the whole experience comfortable and stress-free. Highly recommend"
– Cassie A
Source: Google
"Went to Oscar Wylee in Westfield Carindale for an eye test recently and I have to say they were fantastic. Very thorough test with a lot of details. Professional staff and I also copped a couple of amazing new lenses too! So many options! Highly recommended"
– Kevin Y
Store Location: Carindale QLDSource: Google
"The staff were all very patient and friendly. The eye test was very thorough and they took great care with everything. They were also quick to help whenever I had questions. I highly recommend it!"
– Niki Y
Store Location: Ryde, NSWSource: Google
"Comprehensive testing done in house by an experienced Optometrist. Overall I had a positive relaxed visit. No high pressure selling, prices very reasonably and a good selection of frames. The staff were very helpful and friendly. Bulk Billing."
– Paul W
Store Location: Casuarina Square, NTSource: Google
"I popped into Oscar Wylee Canberra Centre for some adjustments and repairs, and the team was absolutely amazing! They were so friendly, quick, and made sure everything fit perfectly before I left. Such great service, they really go above and beyond to make sure you're happy. I couldn't recommend them enough!"
– Kaz B
Store Location: Canberra Centre, ACTSource: Google
"A good experience. I was greeted and didn't have to wait for my appointment. The optometrist was courteous, professional, and easy to talk to. She explained the whole process clearly and was thorough with the exam. She went over my results so I could understand my options. Overall, I left feeling really happy."
– Peter S
Store Location: Castle Towers, NSWSource: Google
"Prompt and friendly service and advice given on my recent annual check up appointment. Always a pleasure and looking forward to my new frames."
– Sally C
Store Location: Ellenbrook Central, WASource: Google
"Great experience at this optometrist clinic. The staff were friendly and welcoming, and the optometrist was thorough, professional, and took the time to explain everything clearly. The clinic was clean and well-organised, with a good selection of frames. I felt well looked after and would highly recommend their services."
– Panrada T
Store Location: Perth Carousel, WASource: Google
"A very positive experience. The optometrist and technician were courteous and professional. A range of tests were performed and I was kept informed of the purpose of each procedure. The attention I received was far superior to my experiences at other optometrists. Very pleased."
– Mike R
Store: Chatswood Chase, NSWSource: Google
"Friendly and helpful staff. The optometrist was very good at their job. Really happy with the experience."
– L.P. Davis
Store: Hobart, TASSource: Google
"Tuggeranong ACT store - Wonderful experience, lovely to deal with, staff were amazing, nothing was a problem and I didn't feel rushed in selecting the appropriate frames, spent well over an hour trying to make up my mind :) A+"
– Melissa M
Store: Tuggeranong, ACTSource: Google
"Super friendly staff. Very professional. If had to describe in one word, that word would be: Genuine"
-Konstandinos B
Store: Fountain Gate, VICSource: Google
"They were so accommodating, I got an eye test on the spot and new glasses ordered within 45mins. Friendly and knowledgeable staff."
– Kirsty H
Store: Albury, NSWSource: Google
"My wife went in for an eye test and glasses. The staff was so friendly and accommodating. The glasses only look a few days and they were perfectly fitted! Thank you."
– Louis D
Store: Newtown NSWSource: Google
"Professional and thorough eye examination. Highly recommended."
– Edwina M
Store: Chapel St, VICSource: Google
"The girls at Oscar Wylee Parramatta are super friendly, helpful and accomodating. My appointment was on time and the care and interest shown was quite lovely...whilst being extremely professional."
– Diane B
Store: Parramatta, NSWSource: Google
"Really great service at Oscar Wylee in St Ives. Friendly, efficient, knowledgeable. We have been customers since we moved to the Upper North Shore four years ago."
– Wesley R
Store: St Ives, NSWSource: Google
"Have had glasses for years and always gone to the same business. Decided it was time for a change and all I can say is thank you. The four staff members I dealt with had passion, care and understanding, down to earth and left feeling I'd made a good choice."
– Brad C
Store: Marion, SASource: Google
"Very friendly and informative. Helpful in choosing the right frames for my face. Reasonable price frames- happy all round."
– Lyn W
Store: Collandes, SASource: Google
"Recently visited for new glasses — great selection and very reasonable prices. I returned for a separate appointment about a floater and again received excellent service. Everything was explained clearly and in a way that was easy to understand. I highly recommend it."
– Suzanne M
Store: Plenty ValleySource: Google
"The whole team at Oscar Wylee Vic Gardens are lovely and it was so nice to go back after 2 years and see the same optometrist and for her to know my eye history."
– Bronywn N
Store: Victoria GardensSource: Google
"Optometrist was quick, clear, professional, helpful and nice, honestly couldn't ask for anything more. The sales staff was helpful, delightful and non-pushy and I look forward to coming back for my next pair."
– Josh M
Store: Karrinyup, WASource: Google
"I had a great experience at this glasses store. The staff were very kind and helpful - they quickly repaired my glasses and made them as good as new. The service was fast, professional, and much appreciated. I highly recommend it!"
– Enkhma S
Store: Pitt Street, NSWSource: Google
"Service is exceptional as always. Great range of eye wear and very informative Optometrist. Service at the front counter was outstanding."
– Leanne L
Store: Mackay, QLDSource: Google
"Staff are friendly and helpful. The optometrist is amazing. She was caring and explained all the steps she was performing for the eye test."
– Devangini P
Store: Chadstone, VICSource: Google
"The optometrist was very friendly and professional. The staff at Mildura were and always are as helpful as they can be. I have lots of faith in the team and will continue to trust them with my eye care."
– Sherrie W
Store: Mildura, VICSource: Google
"I just went in to get my eyes checked (every 3 years) and had a great experience. Optometrist was super thorough and explained everything really clearly. I was also able to get an appointment the next day which was great."
– Lara
Store Location: Canberra Centre, ACT, AustraliaSource: Google
"Highly recommend this bulk billed professional vision screening service! You deserve the best in life and staff are incredibly wonderful and efficient… I came for their very stylish and chic frames on the spur of the moment no bookings. I was very impressed with the efficient service!"
– Angie H
Store Location: Chatswood Chase, NSW, AustraliaSource: Google
"This was my first visit to an Oscar Wylee store and I was very impressed. I was first greeted by Cassandra who took me through all the steps and got me prepared for my sight test. Lem the optometrist, was excellent, he explained everything and was very thorough during the testing. He detected something that I was unaware of and has booked me in for a follow up examination in a few months. After my sight test Cassandra helped me choose frames and all of the lens options. What a wonderful experience! Love my new glasses!"
– Kayla W
Store Location: Tuggerah, NSW, AustraliaSource: Google
"I had a fantastic experience at this optometrist! The team was welcoming, professional, and took the time to explain everything clearly. The eye test felt thorough yet comfortable, and I never felt rushed. They have a great range of frames—stylish, high-quality, and reasonably priced—and the staff gave honest advice to help me pick the perfect pair. My glasses were ready quickly and fit perfectly from day one. Highly recommend if you're after friendly service and top-notch care!"
– Karthik R
Store Location: Chadstone, VIC, AustraliaSource: Google
"Visited the Richmond location for an eye exam this week. Staff were super friendly and the doctor explained all my results clearly. This is the second time I've had my eyes checked there, and I am looking forward to getting my new frames!"
– Laughing M
Store Location: Richmond Centre, BCSource: Google
"I received fantastic service at Oscar Wylee on Monday, 9th Feb. Christine was so professional and friendly during my eye test. Her manner was really person-focused and she resolved the issues I was having with my previous glasses. Emily was so helpful and kind while supporting me to pick my frames. She did such a great job and I left really happy with my choices. I would highly recommend this store!"
– Lucy H
Store Location: Albert St, QLD, AustraliaSource: Google
"First time here for eye testing and new glasses after all the years of going to other stores. This was the absolute best. The frames seem stronger &amp; better quality, the staff were helpful but didn't pressure/hover and upsell. The eye testing was professional and smooth sailing! and overall an easy, enjoyable experience. many thanks!"
– Frankie L
Store Location: Colonades, SA, AustraliaSource: Google
"Visiting Launceston briefly from another country and developed an acute eye issue on a Saturday. The team were so kind and helpful, booked me an appointment to be seen within 30 minutes! I received very professional and efficient care. Highly recommend."
– Pieta W
Store Location: Launceston, TAS, AustraliaSource: Google
"Throughout my eye test at OW in the Market Place Mall in Bendigo, the Optometrist clearly explained what changes had occurred to my vision and also taking the time to explain the changes that occur to eye health as we age. A very positive experience."
– Brendan B
Store Location: Bendigo, VIC, AustraliaSource: Google
"Friendly and efficient staff. Calm and clear communication at all times. Great choice of frames and clear explanations of possible extras, and costs. Definitely will continue to get eye care from Oscar Wylee."
– Kathleen T
Store Location: Broadmeadows, VIC, AustraliaSource: Google
"I cannot express how amazing the team at Oscar Wylee Cairns Central are! From start to finish, the service was absolutely flawless. Johnny was so caring and attentive, making sure every little detail was perfect. And Alanna, you honestly deserve a medal! Your patience, honesty, and natural ability to make people feel comfortable is incredible. I never once felt pressured, just genuine care and honest opinions that made the whole experience feel like I was family. Thank you so much to the whole team – I only wish I had found you sooner. Truly 1000% perfection!"
– Deanne M
Store Location: Cairns, QLD, AustraliaSource: Google
"I highly recommend Oscar Wylee Optometrist - Rundle Mall, especially to those people who needs assistance to have a better vision. The staff are very nice and kind, they did a pretty good job. They assisted me with warmth. They even given me enough time to try the frame for my glasses. The process is very easy and done in a very short time with ease. They are very accommodating. All in all, I'm very satisfied and excited for my new glasses."
– Mariana G
Store Location: Adelaide Rundle Mall, SA, AustraliaSource: Google
"Alan was so helpful and wonderful to work with. They have a great selection at reasonable prices. I appreciated the input and expertise Alan offered, and he did so with so much patience. Would highly recommend looking for glasses here."
– Annita H
Store Location: Oshawa, ON, CanadaSource: Google
"Was a really great experience with my 13 year old daughter. The optometrist is very knowledgeable and picked up a condition not noticed in previous appointments. The technicians were also very helpful and happy for my daughter to take her time choosing her frames. Price wise, it is VERY affordable! We got 3 pairs of glasses (including sunglasses) for only a fraction more than the cost of 1 pair at another optometrist. Highly recommend."
– Karen H
Store Location: Manukau City Centre, Auckland, New ZealandSource: Google
"The team at Warringah Mall always look after me so well. I've been going there for years now and the level of professionalism, caring and customer service are second to none!"
– Douglas
Store Location: Warringah Mall, NSW, AustraliaSource: Product Review
"I've been going to Oscar Wylee for my glasses for nearly 10 years now. For a lot of reasons, but the main one being the transparent pricing. At no point does my brain have to question if only some of the frames in the store are within my price range, because literally all of them are priced in the same way. Also, it helps that they have such a lovely range of designs and that too, organised by shape. I've always been biased towards the geometric and cat-eye styles myself, and of course, customer service and support 11/10. Anytime I've noticed an issue requiring repair, they've been able to tackle it within 30 minutes."
– Dhvani B
Store Location: Blacktown, NSW, AustraliaSource: Product Review
"I am a very happy repeat customer. Recent changes to my sight meant that it was not an easy task to test my eyes but I am very happy with my new glasses."
– Vin2far
Store Location: Sunshine Plaza, QLD, AustraliaSource: Product Review
"My daughter and I both had our eyes tested a few days ago. All on time and a terrific experience. The Optometrist was particularly helpful. My vision has changed slightly as I have developed something behind my left eye. The Optometrist then explained about getting bloods done to see what could be the cause behind my issue and to get on top of it as soon as possible. The Ladies at front of house were amazing, helpful, not pushy and no sales dribble! In all, a really nice experience. Thank you, your team are a credit to you!"
– Maggie B
Store Location: Elizabeth, SA, AustraliaSource: Google
"I have never had such a fantastic optometrist for myself and my children. Firstly so great with my kids (all on the spectrum). Secondly, very thorough with her testing explained things with my eyes that others haven't told me and I've had glasses since I was 6. My kids absolutely adore the Dr and the staff are amazing. This will definitely be our usual store from now on."
– Samantha V
Store Location: Mackay, QLD, AustraliaSource: Google
"Highly recommend for anyone looking for top-notch service and modern, reasonably priced eyewear!"
– Leila K
Store Location: Belconnen, ACT, AustraliaSource: Google
"Amazing customer service! I was overdue for my eye examination and desperately in need of new glasses. The optometrist was so helpful as my prescription had changed. The sales staff at the North Lakes store were super awesome! I was going for a whole new look and needed help choosing frames that were right for my face and skin colour. The sales associate was spot on with her suggestions. With so many options it can be a little overwhelming with the choices. But once e narrowed don the particular frame material it was so easy from there. I have had so many compliments on my new glasses. I have been a repeat customer for many years, and I will continue to be. Thank you to all of the amazing staff."
– Joslene P
Store Location: North Lakes, QLD, AustraliaSource: Product Review
"All the staff were very professional &amp; helpful especially CJ who helped me pick out my three different glasses everyday wear, reading glasses, and sunglasses polarised."
– Amanda L
Store Location: Traralgon, VIC, AustraliaSource: Product Review
"I visited the Macquarie Centre location yesterday and was greeted with friendly staff. My assessment was thorough and explained and I was given options for not only now, but moving forward. I was guided with frames and helped select two that suit beautifully." It was great care
– Angela B
Store Location: Macquarie Centre, NSW, AustraliaSource: Google
"I recently had an eye exam, and it was a pleasant experience. The optometrist Sophie was very professional and took the time to explain everything thoroughly. I felt comfortable and confident in the care I received. Thank you for providing such great service!"
– Bryan M
Store Location: Mt Druitt, NSW, AustraliaSource: Google
"Staff at Oscar Wylee, Marion were all friendly and super helpful. I had an eye test and chose two pairs of glasses. This took some time and the assistant was lovely and patient, offering me her opinion and assistance. I am excited to pick up my new glasses in a couple of weeks. I hope they are as good as the staff."
– Julia B
Store Location: Marion, SA, AustraliaSource: Google
"In spite of my being late for the appointment - I did call ahead - they were able to accommodate me. The whole process was clear, thorough and pleasant. I've been told that my current magnifiers are sufficient, but I now also have the prescription for new glasses when I need them."
– Nick B
Store Location: Woden, ACT, AustraliaSource: Google
"We went into the Oscar Wylee with the intention of buying a case for our spectacles. We were attended by Michael who was really friendly and very helpful even though we were only there to get a case, rather than buying spectacles. He got us a really nice solid case, and we're grateful for his help. Top-notch service!"
– Tenzin T
Store Location: Broadway, NSW, AustraliaSource: Google
"My young daughters were so nervous... but Jason the optometrist was very patient, explained what was going to happen and made them feel comfortable. Both my girls loved the glasses range."
– Meyrem H
Store Location: Narellan, NSW, AustraliaSource: Google
"Staff at Oscar Wylee, Marion were all friendly and super helpful. I had an eye test and chose two pairs of glasses. This took some time and the assistant was lovely and patient, offering me her opinion and assistance. I am excited to pick up my new glasses in a couple of weeks. I hope they are as good as the staff."
– Julia B
Store Location: Westfield Marion, SA, AustraliaSource: Google
"Brilliant experience. The Optometrist I saw was the best I've ever seen. Explained everything so well, including pros and cons of different lens styles in reference to my every day use of the glasses. The lady who helped me choose the actual frame was amazing. She was so helpful and honest about what suited my face and what didn't. I really appreciated that."
– Sarah H
Store Location: Chirnside Park, VIC, AustraliaSource: Google
"I had such a great experience at Oscar Wylee. From the moment I walked in, I was given a warm welcome and made to feel comfortable straight away. The team were professional yet very personal at the same time, which made the whole experience relaxed and enjoyable. They really listened to my needs and concerns and were incredibly accommodating and understanding throughout the process. What stood out most was the time and effort they put into helping me choose my frames — it never felt like a quick sale. It was genuinely about finding what suited me best and what worked within my budget. I wouldn't hesitate to recommend them to anyone. In my opinion, the surrounding competitors don't even come close. Outstanding service all round."
– Peter B
Store Location: Midland Gate, WA, AustraliaSource: Google
"The team at Warringah Mall always look after me so well. I've been going there for years now and the level of professionalism, caring and customer service are second to none!"
– Douglas
Store Location: Warringah Mall, NSW, AustraliaSource: Product Reviews
"The clerks were awesome! They got me in quickly. The doctor was thorough. Good selection of really nice glasses and it was really appreciated that we were able to try on the glasses without having to ask someone else to access them."
– Doris L
Store Location: West Edmonton Mall, AB, CanadaSource: Google
"Lovely customer service from the moment you walk in, they help with all your needs &amp; are efficient with everything. Can't wait to get our glasses, I'll be bringing my younger two on that day for check ups as well."
– Moomah S
Store Location: Albert St, QLD, AustraliaSource: Google
"Had a great experience at Oscar Wylee Lynmall in Sunday afternoon. The staff helped me repair my nose pad and were very friendly and helpful. Really appreciated the quick service and positive attitude. Thank you!"
– Jiali X
Store Location: Lynn Mall, Auckland, New ZealandSource: Google
"The whole experience was great! Approachable staff and thorough eye examination. Eyewear selection was cool too. I would definitely recommend it to friends."
– Christina O
Store Location: Westfield Carousel, WA, AustraliaSource: Google
'I appreciate the professional eye test conducted by Optometrist Mary at Oscar Wylee, Rundle Mall. She is very professional and patient. Mary checked my eyes and explained to me very carefully. I would say it was an excellent experience.'
– Xioalin Z
Store Location: Adelaide Rundle Mall, SA, AustraliaSource: Google
"Comprehensive testing done in house by an experienced Optometrist. Overall I had a positive relaxed visit. No high pressure selling, Prices very reasonably and a good selection of frames. Staff were very helpful and friendly. Bulk Billing."
– Paul W
Store Location: Casuarina, NT, AustraliaSource: Google
"Dr. Ashley was very thorough in explaining all steps of the process and made me feel very comfortable. She and her team were very pleasant and professional!"
– Sydney M
Store Location: Halifax, NS, CanadaSource: Google
"The team is amazing, so helpful and friendly. My daughter broke her glasses for the third time this year and I had no clue we can actually fix them under warranty. Long story short, her frame was replaced with a new one, free of charge and under 5 minutes! So happy they could help us fast and efficiently."
– Katya T
Store Location: West Lakes, SA, AustraliaSource: Google
"In spite of my being late for the appointment - I did call ahead - they were able to accommodate me. The whole process was clear, thorough and pleasant. I've been told that my current magnifiers are sufficient, but I now also have the prescription for new glasses when I need them."
– Nick B
Store Location: Westfield Woden, ACT, AustraliaSource: Google
"Great service, very friendly staff, price for prescription glasses are way cheaper than anywhere else in the market."
– Tarif U
Store Location: Townsville Shopping Centre, QLD, AustraliaSource: Google
"I would recommend going here. The staff are all lovely and make you feel so welcome. The optometrist was great he took the time to explain what he was doing. I will definitely be coming back as they have great customer service !"
– Kristie C
Store Location: Lakeside Joondalup, WA, AustraliaSource: Google
"Very good service from Mr. Bashar, optician! He knows how to advise us well and guide us in our choices. A place that I highly recommend! Thanks to the whole team."
– Firas H
Store Location:  Carrefour Laval, QC, CanadaSource: Google
"The optometrist herself was great, taking the time to ask further questions and understand my issues. The retail staff were also extremely friendly and explained in detail my different lens options in an easy to understand way. Had a great experience."
– Rebecca S
Store Location: Wollongong Central, NSW, AustraliaSource: Google
"Just bought two pairs of glasses from a lovely girl named Jules, she was very professional, informative and helpful! Thank you Jules for the amazing service!"
– Christina B
Store Location: Adelaide Rundle Mall, SA, AustraliaSource: Google
"Such friendly and professional staff. My optometrist was very supportive and knowledgeable regarding my sight and astigmatism. Looking forward to my new flashier frames and more importantly, my new lenses. Thank you Oscar Wylee Frankston."
– Pam M
Store Location: Frankston, VIC, AustraliaSource: Google
"I had a great experience at Oscar Wylee Claremont. The team were super friendly and easy to deal with, guiding me through everything from the eye test to choosing my new glasses. They made the whole process simple and stress-free. I would definitely recommend it!"
– Warren B
Store Location: Claremont Quarter, WA, AustraliaSource: Google
"Excellent experience. The optometrist was very nice, professional and informative. Made me feel in good hands. Good prices too!"
– Hila C
Store Location: Warringah Mall, NSW, AustraliaSource: Google
"First time I have been to Oscar Wylee but it won't be the last. Everybody was so nice and Optometrist was 100% professional and totally understood the dilemma I was having with my eye, which I totally appreciated. Well done OW at Northland"
– Vivien T
Store Location: Northland, VIC, AustraliaSource: Google
"I had an eye exam and purchased glasses - overall, me and my partner had an excellent experience! Everyone was very helpful."
– Shara V
Store Location: Chinook CentreSource: Google
"Absolutely amazing staff very friendly and helpful...my appointment was a walk in and was done within 10mins... Can't wait for my new glasses..10/10"
– Lorral C
Store Location: Elizabeth, SA, AustraliaSource: Google
"The girls at Oscar Wylee Parramatta are super friendly, helpful and accomodating. My appointment was on time and the care and interest shown was quite lovely...whilst being extremely professional."
– Dianne B
Store Location: Parramatta, NSW, AustraliaSource: Google
"The optometrist was so lovely &amp; helpful, guiding me with treatment for my dry eyes at my eye test. The new range of coloured frames are gorgeous, it's hard to narrow down choices - but the staff kindly helped me to see which pairs suited me better."
– Zoe H
Store Location: Booragoon, WA, AustraliaSource: Google
"I have had a wonderful experience here. It was easy to book an appointment with the optometrist, who was extremely helpful. The eye test was quick, thorough and highly effective. There is a wide choice of frames, each with an outstanding design. I have received my glasses now, and the prescription is perfect, making it so much easier to see. I am very satisfied."
– Adam E
Store Location: Southland, VIC, AustraliaSource: Google
"I could not fault my experience at Oscar Wylee from start to finish. I dealt with 3 members of staff who were all very helpful, kind and professional. The eye test was quick yet thorough and I felt very at ease. My prescription was thoroughly explained to me. There is a huge range of glasses to choose from and all of the different offers and optional upgrades were explained. The friendly staff offered unbiased opinions and helped me select the perfect two frames. Overall I was so impressed and I would recommend Oscar Wylee to anyone, as I have done already."
– Holly F
Store Location: Sunshine Plaza, QLD, AustraliaSource: Google
"Excellent customer service. Optometrist was professional and staff super helpful to find suitable frames from a great selection! Easy to book online and confirmation call for appointment. Bought two pairs with a promotion and quick transaction to my health fund. Super happy with my in store experience! Glasses were available within a week - love them!"
– Lavi N
Store Location: Rhodes, NSW, AustraliaSource: Google
"Highly recommend it! Optometrist was very thorough and educational, and helped me understand more than I ever have about my eye tests! All the staff during my visit and subsequent visit to pick up glasses were super friendly, helpful and welcoming. The shop was also very child friendly- they let my toddler come in and watch me get my eyes checked, and had colouring pages, markers and stickers for her as well!"
– Amy C
Store Location: Rhodes, NSW, AustraliaSource: Google
"Had a very disappointing experience with the optometrist and sales assistant when I first went back for issues with my new glasses. With my subsequent visits I was assisted by the store manager Ben who was extremely reassuring and went above and beyond in sorting out issues with the new glasses. Really grateful for his assistance and he managed to change my experience at the store from a negative one to a positive one."
– Christy H
Store Location: The Galeries, NSW, AustraliaSource: Google
"Excellent Eye Care Experience. I recently visited Oscar Wylee Optometrist Burwood for an eye test, and I must say I was thoroughly impressed with the level of professionalism and care I received. Overall, my experience at Oscar Wylee Optometrist was excellent, and I highly recommend their services."
– Anil S
Store Location: Burwood, NSW, AustraliaSource: Google
"The staff was very friendly and nice. Everything went smoothly during my eye examination. They have affordable price ranges for eye exams and eyeglasses, so I highly recommend this place."
– Pubudu W
Store Location: Market Mall, Calgary, AB, CanadaSource: Google
"Great customer service! I went for an eye test and they took me in straight away - no time spent waiting at all. Online booking system was really convenient too."
– Hayley C
Store Location: Burwood, NSW, AustraliaSource: Google
"Best customer service and a huge variety of glasses frames to choose from. They also helped me to choose the best additional options to pick."
– Gamerboi 21
Store Location: Burwood, NSW, AustraliaSource: Google
"First time buying glasses from Oscar Wylee and it was a pleasant and fun experience. Lots of frames to choose from and the staff were A1 on customer service. Our eye test was the best we have ever experienced, the optometrist was patient and very thorough and explained every step and answered all our questions in an easy to understand way. We are very happy customers."
– David L
Store Location: Booragoon, NSW, AustraliaSource: Google
"I would like to Thank the wonderful service rendered by optometrist Sharon and customer service Kylie. When I had glasses last time with Parramatta Branch, never thought I would experience such issues with glasses, unfortunately I couldn't change it on time, meantime I went to Castle towers branch, Sharon was explaining me the issue very well, really happy with the way she tried to fix the issue also for solution given. Also, Kylie was really helpful taking correct measurements and helping out to fix the issue. Thank you all for the wonderful service. "
– Sharm S
Store Location: Castle Hill, NSW, AustraliaSource: Google
"I was greeted with a smile and the willingness to help me as I had never been to the store before or used their service. I was able to have an appointment with the optometrist who I believe was very thorough. The end result is a new pair of glasses and sunglasses at a very affordable price. I'm truly one happy customer thank you to the team at Oscar Wylee."
– Pauline V
Store Location: Woodgrove, VIC, AustraliaSource: Google
"Amazing service. The glasses are superb quality. Everybody was super helpful and friendly. I highly recommend it. The staff was super helpful for an issue with my prescription from another place and eventually accommodated going out of their way."
– Shagufta H
Store Location: Sherway Gardens, ON, CanadaSource: Google
"The customer service was 10/10. Both ladies who served me were friendly and helpful. They made choosing frames a lot of fun and had plenty of information around lens types, bundles and caring for my new frames."
– Rachal A
Store Location: Wollongong, NSW, AustraliaSource: Google
"I was very happy with the service. I am type 1 diabetic and they found early signs of cataracts, which I can now address and look after. Staff were very knowledgeable and helpful both in Woden and the Canberra Centre branch."
– Raymund R
Store Location: Woden, ACT, AustraliaSource: Google
"I had an outstanding experience at Oscar Wylee Optometrist in Wetherill Park. The staff were incredibly friendly and knowledgeable, making me feel comfortable from the moment I walked through the door. The optometrist was thorough and patient in explaining my eye test results. The wide selection of frames available was impressive, and I found a pair that suited my style and budget. The service was top-notch and I highly recommend Oscar Wylee Optometrist to anyone in need of eye care. Five stars!"
– Loranzo B
Store Location: Wetherill Park, NSW, AustraliaSource: Google
"I went to Oscar Wylee Whitfords recently and saw optometrist Sarah who was lovely and helpful and saw Mirijana and Chloe who's customer service was amazing with helping me choose my glasses, such good frames for men also."
– Willam D
Store Location: Westfield Whitford City, WA, AustraliaSource: Google
"I felt comfortable and confident with my care regarding upgrading my lenses. The staff were prompt, friendly and professional and I love the range of frames to choose from. Thank you Oscar Wylee."
– TheBravemouse
Store Location: Werribee, VIC, AustraliaSource: Google
"Friendly staff, very helpful and knowledgeable about glasses. the whole process from start to finish was great, didn't take long at all, highly recommend , great selection of modern glasses."
– Rachel B
Store Location: Watergardens, VIC, AustraliaSource: Google
"It was a great experience. Very easy to book online, staff were friendly and professional and the only hard part was choosing from the great selection they had."
– Cate T
Store Location: Wellington Central, New ZealandSource: Google
"I really appreciated my experience at Oscar Wylee yesterday. The staff were welcoming and easy to deal with, and the optometrist clearly explained everything he was doing so it was very comfortable. There was a great selection of frames, and I'm looking forward to picking up my new pairs of glasses soon. (Also really appreciated that there was no pushy upselling - the options were explained and then I could make my choice. This was a real plus!) I would absolutely recommend Oscar Wylee. "
– Isabel R
Store Location: Wellington Central, New ZealandSource: Google
"My partner and I attended Oscar Wylee Thursday 12 Oct evening for the first time. The guys there were very professional, helpful and friendly. We were able to check out the frames without any pressure to buy. There was such a great selection of frames - so hard to choose. I'm so impressed I will be purchasing another pair again for sure. Big thanks and appreciation."
– Kari
Store Location: Warringah Mall, NSW, AustraliaSource: Google
"Great place to get an eye test. The optometrist is very informative, and I thought I knew about longsightedness before my visit. I feel much more informed now. Reasonably priced glasses in a variety of trendy styles. My partner and I both would recommend it."
– Louise B
Store Location: Warringah Mall, NSW, AustraliaSource: Google
"Friendly and professional staff who made my experience of getting my eyes tested and picking frames a complete joy! The staff at Tuggeranong were also very helpful to offer advice choosing frames for me. Would definitely recommend the service and value for price."
– Rosanna G
Store Location: Tuggeranong, NSW, AustraliaSource: Google
"What a wonderful team at the Toowoomba Grand Central store. From arrival I was made to feel welcome and everything was explained in detail. And what a selection of frames and advice on what suited me best. Will recommend and definitely be back."
– Sharon S
Store Location: Toowoomba, QLD, AustraliaSource: Google
"The staff were very welcoming and thorough. The optometrist was very thorough in her exam and explained everything very well. The whole procedure was very relaxing for me. Kudos to the whole staff."
– Clem B
Store Location: Kingsway Mall, Edmonton, AB, CanadaSource: Google
"Very friendly and efficient. Everyone is very helpful and the frames range is fabulous. Value for money, fashionable frames and lovely staff. I absolutely recommend Oscar Wylee. I love the frames I chose."
– Marisa D
Store Location: Tea Tree Plaza, SA, AustraliaSource: Google
"The professionalism of the staff at Oscar Wylee Maroochydore, the thoroughness of the examination, and selections of glasses available are high quality. I'm impressed by the improved clarity in my vision and helpful recommendations from the optometrist."
– Wendy C
Store Location: Sunshine Plaza, QLD, AustraliaSource: Google
"My wife and I had our eye check-up last Monday after many years. The two staff who served and conducted the eye test were both very professional and provided us an accurate diagnosis on the state of our eyes. I would not hesitate to recommend Oscar Wylee Optometrist to anyone including my family."
– Meinardo L
Store Location: Rhodes, NSW, AustraliaSource: Google
"Very easy and pleasant experience. Staff were knowledgeable and helpful, optometrist was thorough, friendly and helpful and she listened to what I needed and wanted."
– Luisa B
Store Location:  Narre Warren, VIC, AustraliaSource: Product Reviews
"Cat Eye Prescription Sunglasses are Amazing!I have longsightedness and my prescription sunglasses have honestly changed my life! They are so perfect and have helped me immensely."
– Sophie M
Store Location: Erina, NSW, AustraliaSource: Product Reviews
"I recently ordered two pairs of multi focal glasses here. Great value after health insurance benefits. Even better than the health fund's own optical business. Unfortunately when the glasses arrived about 2 weeks later, they were nowhere near the prescription that was ordered and were essentially flat glass lenses with absolutely no effect. I returned them the next day, and the staff were very good at taking responsibility to get it corrected. 10 days later, a second set arrived and this time they were perfect. Very happy with the purchase and my rating would be 5 out of 5, if it wasn't for the error and delay. So 4 out of 5 this time."
– Savvas E
Store Location: Miranda, NSW, AustraliaSource: Google
"The best! I have 5 pairs of Oscar Wylee, and they are all my favourites. The quality is superb. stylish, and the eye exam service was professional. I can't recommend Oscar Wylee more. For me, Oscar Wylee is the best!"
– Yaryna
Store Location: Booragoon, WA, AustraliaSource: Product Reviews
"Incredible experience. I had such a great experience choosing my glasses, the staff were kind and knowledgeable and helped me pick frames. I'm excited to wear it. My glasses arrived for collection in a timely manner and were easy to pick up. I've received many compliments on my frames, they are comfortable and fit perfectly."
– Kim
Store Location:  Rouse Hill, NSW, AustraliaSource: Product Reviews
"Such a great place. Was made to feel at ease and given all the information needed for my eye test. Every step was Explained before beginning. Best eye test to date. Thanks to the Oscar Wylee team."
– Daniel M
Store Location: Rhodes, NSW, AustraliaSource: Google
"My eye test was perfect, straight to the point and straight to finding my new spectacles. The staff are very obliging, helpful and informative. The range was awesome, I had a wonderful time trying on all different styles, shapes and colours. I recommend you give them a go you won't be disappointed."
– Barbara W
Store Location: Woodgrove, VIC, AustraliaSource: Google
"After visiting the Oscar Wylee city store some years ago, I was reluctant to approach the group again. However, I was completely turned around by the service, attention to detail and overall support from the team at Oscar Wylee Burwood. From start to finish, the team was very professional. I'll continue to get my glasses from this wonderful franchise. Great job team!"
– Thaao P
Store Location: Burwood, NSW, AustraliaSource: Google
"First ever eye exam in 38 years. Nothing but good things to say. Optometrist was lovely, explained everything well, and the eye test was at a reasonable price."
– April P
Store Location: Queensgate, Wellington, New ZealandSource: Google
"Excellent – I never have any negative experiences dealing with Oscar Wylee. They're really nice to customers. The optometrist I've seen there was genuinely the best I've seen since I started wearing glasses 20 years ago (aside from my ophthalmologist. It's because she —optom— works in synch with what he diagnosed and his notes to her. My previous glasses place was always in a hurry so I never 'got' what they meant so I swapped to OW on specs and it's been a good move."
– Michelle
Store Location: Canberra, ACT, AustraliaSource: ProductReview
"Excellent – I have become a loyal customer because I have experienced several years of excellent service at the Marion store. They are efficient, friendly and helpful making the experience easy and enjoyable."
– Shannon
Store Location: Marion Westfield, SA, AustraliaSource: ProductReview.com.au
"I needed an eye test and had not had one for a long time. I'm really glad I chose this store as the staff were absolutely delightful, informative and knowledgeable. I walked out knowing my eyes had been checked properly and I got just the right glasses for me. I got two pairs and my out of pocket was only $20!"
– Mark S
Store Location: St Ives, NSW, AustraliaSource: Google
"After going to a bigger 'chain' for Optometry I wanted a more one on one personal experience which I got! Polite, professional and did not feel pressured or rushed. Thank you- can't wait to get my new glasses."
– Debra B
Store Location: Hornsby, NSW, AustraliaSource: Google
"The staff at Oscar Wylee Hurstville (I met three) were simply lovely and it was a pleasure dealing with them. My glasses are excellent so far - the prescriptions are very accurate."
– Brian
Store Location: Hurstville, NSW, AustraliaSource: ProductReview
"Outstanding! – Outstanding customer service from the optometrist and team at Rockingham WA practice. The range and quality of frames is amazing and I keep returning to the store to add to my collection."
– Dayle L
Store Location: Rockingham, WA, AustraliaSource: ProductReview.com.au
"My eye exam went smoothly &amp; the young lady who performed the exam was exceptional. The choice of frames is awesome &amp; are reasonably priced. All the staff were helpful &amp; pleasant. This is why Oscar Wylee is my first choice for glasses."
– Karen
Store Location: Warringah, NSW, AustraliaSource: Google
"I've been coming here for the past four years for eye tests and glasses, and the service has consistently been excellent. During my most recent visit, I had a more complex issue, and the staff went above and beyond to help me. Their care, professionalism, and attention to detail truly set them apart—I wouldn't go anywhere else now. Thank you again for the outstanding service!"
– Alexandra H
Store Location: Chapel St, VIC, AustraliaSource: Google
"The exam was very thorough. The doctor has an amazing gift for relating to clients. Her pleasant manner made me feel comfortable from the start. I felt her focus was entirely on me, and I am grateful for her thoroughness and assistance, which includes a follow-up visit."
– Jeffrey R
Store Location: Halifax Shopping Centre, NS, CanadaSource: Google
"Had a great experience in store today. Both optometrist and front-of-house staff were thorough and friendly. I appreciated the verbal descriptions of the prelim tests to prepare me for some surprise flashes. Not much waiting time either, everything flowed smoothly and left a good feeling."
– Quynh H
Store Location: Watergardens, VIC, AustraliaSource: Google
"The Optometrist I had was great, talked me through the tests &amp; explained it all as he went. The staff members were helpful while trying on new frames &amp; choosing the right ones to suit. I couldn't fault them."
– Chanara S
Store Location: Bendigo, VIC, AustraliaSource: Google
"I came in for an eye check up along with my daughter and the team at Geelong Westfield made the process so simple. They were helpful as well as made it fun for my daughters first eye test. Amazing experience and an amazing team."
– Emma S
Store Location: Geelong, VIC, AustraliaSource: Google
"I took my two kids (7 &amp; 4) for their first eye test and the staff were so kind, patient and engaging with them. Thank you for creating such a positive experience for them."
– Molly H
Store Location: West Lakes, SA, AustraliaSource: Google
"Very professional optometrist. Confirmed my eye health exactly as my previous Optometrist. The assistant has a flair for style when you let him know what you're trying to achieve, so I'm very happy with my selection of 3 pairs I'm getting: 2 specs for daily wear and a pair of sunglasses. Thank you!"
– Janine W
Store Location: Forest Hill, VIC, AustraliaSource: Google
" Great customer service experience right from the start, with my initial enquiry, through to booking an appointment and then in store with every person who helped me. Reasonable prices too. Looking forward to getting my new specs! "
– Anne Terry
Store Location: Queensgate, Wellington, New ZealandSource: Google
"The service I received here was amazing and efficient! It was my first time at the optometrist and they were very thorough and clear with everything. I highly recommend them!"
– Shara
Store Location: Rockhampton, QLD, AustraliaSource: Google
"Fantastic!!! – Great customer service from all staff at Doncaster shop. The optometrist was very knowledgeable and courteous. I loved the range of glasses to choose from. I will definitely be back!!"
– Debbie C
Store Location: Doncaster, VIC, AustraliaSource: ProductReview
"Excellent service. The optometrist was able to explain everything clearly and provided advice which helped me to understand what was happening with my sight. The customer service staff were incredibly patient and helpful when selecting new frames and took the time to run over everything with me too."
– Alishia T
Store Location: Orion Springfield, QLD, AustraliaSource: Google
"Another great experience at Oscar Wylee Penrith – Picked up another pair of glasses from Oscar Wylee Penrith recently . Great service and products as usual. A good range of glasses on display, and knowledgeable and helpful staff."
– Jon D
Store Location: Penrith, NSW, AustraliaSource: ProductReview
"Oscar Wylee is the best – I never go anywhere other than Oscar Wylee. My Castle Towers local store is the best. The same staff, who remember me and have the most professional and friendly helpful service. The range is great and suits my style."
– Katrina
Store Location: Castle Hill, NSW, AustraliaSource: ProductReview
"Helpful staff, good service – I have used Oscar Wylee for my glasses and prescriptions for some years now and never had any problems. Staff always seem courteous and helpful, and I will go again next time I'm due for a check-up."
– Terry W
Store Location: Victoria Gardens, VIC, AustraliaSource: ProductReview
" Friendly, helpful, love the styles and colors they had on offer. There were no hidden prices. First class assistance, I would recommend Oscar Wylee Optometrist to friends and family. Made my visit pleasant."
– Noleen S
Store Location: Queensgate, Wellington, New ZealandSource: Google
"Very friendly, professional service. I was free to make my own choice of glasses without pressure and staff were happy to assist when I was unable to make a choice. I was able to choose two different pairs for the price of one at other places I have been ????. Very happy and would highly recommend it."
– Fiona W
Store Location: Kotara, NSW, AustraliaSource: Google
"I went to OW for the first time after using another optometrist my whole life. The two staff members that helped conduct the eye test and pick frames were really friendly and helpful (I can't remember their names, sorry!). They both made my experience at OW really pleasant."
– Lachlan M
Store Location: Parramatta, NSW, AustraliaSource: Google
"The staff and optometrist are super nice and helpful. Eye checks are really thorough and the optometrist will patiently explain everything to you. Staff has a good taste when assisting in frame selection as well!"
– Andrea T
Store Location: Eastgardens, NSW, AustraliaSource: Google
"I am always looked after at Oscar Wylee. No wait times, so easy to make an appointment, lovely helpful staff, and the quality of the glasses and lenses are far superior to other brands I've used. The optometrist there has also been very patient with me and takes her time in finding out my prescription. I don't feel rushed. I highly recommend it. Exceptional."
– Jess L
Store Location: Belconnen, ACT, AustraliaSource: Google
"The waiting time was nice and short. The staff were wonderfully professional and friendly. They explained all of my options to me very well and helped me find a pair of glasses that suited me. Could not have asked for better service!"
– Hugh L
Store Location: Wollongong Central, NSW, AustraliaSource: Google
"The eye check was quick and easy, the shop attendant and the optometrist were also friendly and helpful."
– Siphachanh
Store Location: Southport, QLD, AustraliaSource: Google
"My son had a great visit to Oscar-Wylee. His eye check was fantastic. Very very thorough and explained every process. We have been able to establish a review plan and will be back again in 3 months time to check how everything is going."
– Samantha
Store Location: Helensvale, QLD, AustraliaSource: Google
"As per every visit; friendly and accommodating staff with strong optometrical knowledge.,I felt at ease when making my first purchase with the staff's assistance in selecting the appropriate frames for my required lenses. The optometrist delivered understanding and clear communication regarding my eye health requirements and what the next steps to take."
– Tara D
Store Location: Fountaingate, VIC, AustraliaSource: Google
"I recently had an eye test with Oscar Wylee. Can I just say how amazing the staff were when it came to picking the right set of frames and also had an amazing experience with the whole eye test process. Will definitely be continuing to use Oscar Wylee, thank you so much for your service. "
– Pia S
Store Location: Strathpine, QLD, AustraliaSource: Google
"The staff were great. They were all so helpful and kind. Made choosing the right frames for my face shape so easy. I highly recommend them."
– Faith S
Store Location: Miranda, NSW, AustraliaSource: Google
"Very friendly, and super helpful when trying on new frames for my new prescription, making sure I got the best value."
– Mandy H
Store Location: Winston Hills, NSW, AustraliaSource: Google
"Amazing customer service, helped with adjusting my glasses and helping me with some warranty issues"!
– Kevin
Store Location: Bankstown, NSW, AustraliaSource: Google
"I am pleasantly surprised and grateful for the service I had yesterday. I truly felt great. The doctor who treated me was very kind, and the technology they have is incredible. I 100% recommend them to anyone who wants a realistic and accurate diagnosis regarding their eye health."
– Karina A
Store Location: Robina, QLD, AustraliaSource: Google
"The staff that I dealt with were so lovely and helpful! Great range of glasses to choose from. I wouldn't go anywhere else for my eye test or to purchase glasses.. Very happy ????"
– Nikki W
Store Location: Noosa Civic, QLD, AustraliaSource: Google
"Affordable and fashionable glasses.,Great service as well! "
– Ali
Store Location: Bankstown, NSW, AustraliaSource: Google
"Great, friendly and helpful service. I would highly recommend it to anyone. Thanks for having good customer service and pricing which is rare nowadays. I will be shopping here for my glasses in the future from now on!"
– Monique M
Store Location: Kawana, QLD, AustraliaSource: Google
"I had a very positive experience at my first yesterday with Oscar Wylee. They explained each step and were thorough. Their equipment was very impressive. Excellent service with a sense of humour, which I found relaxing, he understood my needs and style and recommended excellent options ."
– Am P
Store Location: Burwood, NSW, AustraliaSource: Google
"How can you go wrong with good staff, great professionals and great service? The Oscar Wylee crew were wonderful. This is the second time for an appointment and they did not disappoint. Thank you for your time and experience."
– Brownyn B
Store Location: Carousel, WA, AustraliaSource: Google
"Very helpful service by the team.,Terrific optometrist who was happy to spend some time to get the best results."
– Russel S
Store Location: Tuggeranong, NSW, AustraliaSource: Google
"My experience at Oscar Wylee was positive throughout. My welcome was polite and friendly, the various eye tests I underwent were the most thorough I have had from any optometrist and I felt I was treated in a most professional manner."
– Ann M
Store Location: Hobart, TAS, AustraliaSource: Google
"Awesome service!!! Super friendly and made the experience fun for my 4.5 year old. Casey the optometrist was great with my daughter and made her feel safe and comfortable."
– Jaz K.
Store Location: Sunshine Plaza, QLD, AustraliaSource: Google
"Cannot fault the team at Oscar Wylee, Hannah has gone above and beyond to make sure my glasses were perfect &amp; that I felt comfortable in store. Will definitely be going back in future &amp; will be recommending them to everyone."
– Sara T
Store Location: West Lakes, SA, AustraliaSource: Google
"Excellent customer service. They accommodated me changing my mind and choosing different glasses at the very last minute, no problems whatsoever. Top notch service!"
– Susan B
Store Location: Cairns Central, QLD, AustraliaSource: Google
"Super helpful – Extremely helpful above and beyond my expectations, will go there again!"
– Emily O
Store Location: West Lakes, SA, AustraliaSource: ProductReview
"The staff were extremely helpful and pleasant, the Dr I saw actually told me my script from another optometrist was completely wrong and now after getting my new glasses, I can see! Big thank you to the Shellharbour staff. "
– Effie
Store Location: NSW, AustraliaSource: ProductReview
"The staff at Oscar Wylee Hurstville (I met three) were simply lovely and it was a pleasure dealing with them. My glasses are excellent so far - the prescriptions are very accurate."
– Brian
Store Location: Hurstville, NSW, AustraliaSource: ProductReview
"I went into the Queen Street Mall Brisbane store. The customer service was excellent. Great range of funky frames. I had a specific query and the optometrist came out and chatted with me. They also helped me make the most of my particular health insurance benefit."
– Yasmin C.
Store Location: Queen Street Mall, QLD, AustraliaSource: ProductReview
"Helpful – Received my new lenses but one was still a bit blurry so I had another eye test &amp; it was noted that I have a cataract forming. The optometrist &amp; staff were friendly &amp; helpful."
– Amanda
Store Location: NSW, AustraliaSource: ProductReview
"First time I've been to Oscar Wylee and the staff were fantastic. It was towards the end of a weekend- but they were friendly, knowledgeable and more than willing to support me as I needed two complex prescriptions. Was a wonderful first time there and looking forward to picking up my two new glasses in a couple of weeks. "
– Kanchan B
Store Location: Indooroopilly, QLD, AustraliaSource: Google
"Very happy with the service – The staff at the Mackay store were great. I had my glasses ready for me in quick time and was very pleased with them. I would not hesitate to use their services again and would recommend them to anyone needing optical."
– Geoff D
Store Location: Mackay, QLD, AustraliaSource: ProductReview
"Oscar Wylee is the best – I never go anywhere other than Oscar Wylee. My Castle Towers local store is the best. The same staff, who remember me and have the most professional and friendly helpful service. The range is great and suits my style."
– Katrina
Store Location: Castle Hill, NSW, AustraliaSource: ProductReview
"Love new glasses – Absolutely love my glasses! I have 5 pairs now! The service in my local store was fantastic. I also didn't have to wait long for my glasses to arrive."
– Dani J
Store Location: Tasmania, AustraliaSource: ProductReview
"Very kind, professional Staff. The appointment was on time, actually earlier and did not have to wait at all. We got a very good price offer for 2 pairs of glasses. Very recommended."
– Beata P
Store Location: Launceston, TAS, AustraliaSource: Google
"Was immediately greeted and felt welcome in the store by the friendly staff. The charming young lady who served me named Emily was extremely attentive and helped me through my chronic indecision. Overall I was very happy with the service and would return gladly."
– Alex
Store Location: Chermside, NSWQLDAustraliaSource: Google
"I always get my glasses here and it's perfect every time. The girl who assisted me when I picked up my order was also super sweet!"
– Angeni L
Store Location: Glen Waverley, VIC, AustraliaSource: Google
"G reat and professional staff and Optometrist was really good. Everyone was very friendly and knowledgeable. I felt safe and cared for. They also had great deals on good quality cheap frames."
– Penny M
Store Location: Cat and Fiddle, Hobart, TAS, AustraliaSource: Google
"I had an absolutely wonderful experience at my recent visit to Oscar Wylee Albury.... the staff went above &amp; beyond. They were very accommodating. Very happy customer!"
– Deb S.
Store Location: Albury, NSW, AustraliaSource: Google
" Great staff, informative and clear eye test and great pricing on chosen glasses. 10/10 experience "
– Ryan E
Store Location: The Plaza, Palmerston North, New ZealandSource: Google
"Absolutely lovely experience! The women were friendly and efficient, and even spent ages making sure my fit was correct when my new glasses arrived (early too btw!). Delighted."
– Laura M
Store Location: Burwood, NSW, AustraliaSource: Google
"Great service and great price! No hidden costs, best of all they have a great variety of frames to choose from."
– Jessica B
Store Location: Albury, NSW, AustraliaSource: Google
"Eye Test appointment was easy and staff were very friendly and helpful. There was no hard sell to buy additional products and services like other optometrist chains. Experienced a rare feeling from the Top Ryde team - customer respect - which was refreshing."
– Guy R
Store Location: Top Ryde, NSW, AustraliaSource: Google
"Awesome customer service made me feel good even when I was being indecisive about the glass and lenses. The optometrist I saw was so helpful and a very good educator and big on advocacy of eye health and preventative measures. Thank you."
– Susmita R
Store Location: Casuarina, NT, AustraliaSource: Google
"V ery friendly, efficient ladies. I managed to get an eye test at very short notice. An excellent choice of frames too. Thoroughly recommend the Tweed outlet."
– Anne H.
Store Location: Tweed City, NSW, AustraliaSource: Google
"S uper efficient &amp; friendly. Had an eye check &amp; got a few calls prior to confirming times &amp; concerns etc. Staff were very friendly &amp; well informed &amp; the Optometrist was lovely too. Very clear at communicating &amp; felt very at ease."
– Kate E
Store Location: Wagga Wagga, NSW, AustraliaSource: Google
"Toowoomba store staff are friendly and helpful - highly recommended – Quality and range of glasses is great. End product is amazing, very happy with all 3 pairs. Staff in the Toowoomba store were happy, helpful and relaxed - thank you!"
– Libby H
Store Location: Toowoomba, QLD, AustraliaSource: ProductReview
"I had my first eye exam with Oscar Wylee at Watergardens. The staff were all knowledgeable &amp; really helpful, especially when it came time to pick new frames. Definitely recommend them.'"
– Leona B.
Store Location: Watergardens, VIC, AustraliaSource: Google
"I can not rave enough about the Oscar Wylee team at Broadway. I arrived an hour early for my appointment, thinking I had booked for 11.40am rather than 12.40pm. They slotted me in quickly rather than sending me away. They were also super helpful in recommending which frames worked well on me."
– Jane O
Store Location: Broadway, NSW, AustraliaSource: Google
Due for an eye test? Book now:
[Book an eye test](https://www.oscarwylee.com.au/booking/)
We recommend that everyone should have an eye exam with an optometrist at least once every 2 years.
# Optometrist
Looking after your vision.