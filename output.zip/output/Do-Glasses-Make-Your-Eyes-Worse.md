# Source: https://www.oscarwylee.com.au/glasses/make-vision-worse

# Do Glasses Make Your Eyes Worse?
Published on October 31st, 2025
Updated on March 21st, 2025 
Australia
Australia
New Zealand
Canada
Canadian French

Glasses do not make your eyes worse. It is a common myth
that glasses can make your eyesight worse and increase the progression of
vision issues. In fact, wearing correct and accurate prescription glasses
allows for optimal vision correction that is tailored to your refractive
needs. Read on for more information on this common myth and ways to truly
take care of your eye health.
Keep up with your eye health.
Book an eye test with our Oscar Wylee optometrists, bulk billed with no
out-of-pocket expenses for eligible Medicare cardholders.
[Eye test near me](https://www.oscarwylee.com.au/booking)
[Worsened Eyesight](#worsened-eyesight)
[Causes of Vision Deterioration](#causes-of-vision-deterioration)
[Aging and Glasses](#aging-and-glasses)
## Does Wearing Glasses Worsen Eyesight Over Time?
No, wearing glasses does not worsen eyesight over time.
Prescription glasses aim to correct the vision problems of the wearer to
lessen eye strain and allow for optimal visual clarity.
[Glasses for correct vision](https://www.oscarwylee.com.au/glasses/eye/health-tips-keeping-eyesight-healthy)
do not change the anatomy of your eye, so they will not make your
eyesight worse, according to The Eye Lab Melbourne. Rather, your
prescription glasses will be based on your present eye anatomy and the
eye problems that emerge as a result.
### Why Is My Eyesight Getting Worse Even with Glasses?
Your eyesight
could be getting worse even with glasses due to the emergence of
age-related conditions and other lifestyle factors. It is important to look out for the
[signs of the need for glasses](https://www.oscarwylee.com.au/glasses/eye/signs-for-new-glasses)
such as visual blurriness, eye strain and headaches. A common
age-related condition, presbyopia, for example, can occur around the
mid-40s when the eye lens becomes less flexible and hardens over time.
With an aging lens, light can't focus on the retina, making nearby
objects blurry. Computer Vision Syndrome, also referred to as digital
eyestrain, defined as "a complex of eye and vision problems" may also
lead to worsened eyesight or eye strain and ache, according to Guide
Dogs Australia, additionally, lifestyle factors such as smoking can
lead to an increased risk of developing eye diseases, while a diet low
on essential nutrients can make you more susceptible to eye diseases,
according to Total Vision Optometrists.
#### Can Wearing Glasses Improve Eyesight Permanently?
No, wearing glasses does not improve eyesight
permanently.
Glasses are worn to improve your vision while you are wearing them;
however, they are not able to correct refractive errors and other
eye problems you may experience.
#### Is -4 Eyesight Bad?
A
-4.00 prescription is not bad, but can be considered a moderate
level short-sighted prescription. The 4.00 refers to the SPH (sphere) power in dioptres, which
indicates the strength of the prescription. The minus sign in
'-4.00' indicates shortsightedness also known as
[myopia](https://www.oscarwylee.com.au/glasses/eye/nearsightedness), which means that you struggle to focus on objects at a distance.
Find Your Local Oscar Wylee Store
Come in and see the team for your eye care needs, including eye
testing. All major health funds are accepted in-store.
[Optometrist near me](https://www.oscarwylee.com.au/locations/full-store-list.html)
## What Are the Common Causes of Vision Deterioration?
The common causes of vision deterioration can encompass
age-related macular degeneration, cataracts and glaucoma. Read more about these common causes of vision deterioration below.
* Age-Related Macular Degeneration: Age-related macular Degeneration (AMD) is the leading cause of vision
loss in Australians over 50 years old, according to the Vision
Australia Organisation. This eye condition refers to a gradual or
sudden decline in the ability to see objects clearly.
* Cataracts: Cataracts are one of the
most common eye conditions impacting older Australians. This eye
condition refers to the clouding of the clear lens in one or both
eyes. It can occur due to aging, but it can also affect younger
people, and babies can be born with cataracts.
* Glaucoma: Glaucoma is a disease that
damages the optic nerve, leading to the gradual loss of sight. Those
who are short-sighted, have diabetes or use steroids are considered to
have an increased risk.
### Do Children's Eyes Become Dependent on Glasses?
No, children's eyes will not become dependent on glasses.
It is important that children wear prescription glasses if they suffer
from vision issues. If a child does not wear the glasses prescribed by
an Optometrist, normal vision development can be adversely affected,
according to Western Sydney Eye Doctors. Common vision issues that can
occur in children include astigmatism,
[lazy eye](https://www.oscarwylee.com.au/glasses/eye/lazy-definition)
(amblyopia) and Strabismus, which is when eyes are misaligned or
crossed, according to The Optometrists Organisation.
### Does Wearing the Wrong Prescription Harm Your Eyes?
No, wearing the wrong prescription will not necessarily harm your
eyes or worsen your eyesight.
However, a prescription that is either too weak or too strong for your
eyes can lead to headaches, eye strain, or fatigue.
### Can Eye Exercises Reduce Dependence on Glasses?
Eye exercises
may not necessarily reduce dependence on glasses for each
individual.
There is no conclusive evidence to suggest that eye exercises reduce
the need for glasses. However, they can potentially have a variety of
benefits, such as improving ocular focus and reducing eye strain,
according to the Optometrists Network. Eye exercises include Figure
Eight, which involves tracking an object with the eyes in the shape of
an 'eight' and Pencil Push-Ups, where a pencil is placed in proximity
to the centre of the face, and the eyes have to focus on it.
### How Does Aging Affect Vision Regardless of Glasses?
Aging affects vision, regardless of whether you wear glasses or
not.
Common eye conditions that emerge as a result of aging include
[presbyopia](https://www.oscarwylee.com.au/glasses/eye/presbyopia), a condition commonly emerging in your 40s where the eyes lose the
ability to focus and age-related macular degeneration, a disease of
the macula, the centre of the retina, which can cause blindness or
severe vision loss. Diseases such as this can occur in people as they
age, regardless of whether they needed glasses previously or not.
### What Happens if You Wear Prescription Glasses When You Don't Need
Them?
If you wear prescription glasses when you don't need them, you
might experience eye strain and headaches.
It is ultimately not a good idea to wear prescription glasses
unnecessarily, as it will cause more problems, such as headaches and
tension. Prescription glasses are designed to correct vision
conditions, making them necessary for those with eye problems to wear.
#### Is 0.75 Eyesight Bad?
0.75 eyesight is not considered to be bad, but rather a mild
prescription.
+0.75 written in a prescription indicates mild hyperopia, which is
when close objects can appear blurry, such as visuals on a computer
screen or words in a book. Wearing prescription glasses that magnify
nearby objects will allow for clearer eyesight and lessened eye
strain.
#### Can 1.25 Eyesight be Cured?
No, 1.25 eyesight cannot be cured. There may be a
need for a weaker prescription over time if your eyesight improves;
however, it is unlikely that perfect vision can happen organically.
Glasses and contact lenses are corrective measures for vision while
they are being worn. However, procedures such as LASIK Surgery have
allowed for around 99% of people to gain 20/40 vision or better,
according to the Mayo Clinic.
Read Do Glasses Make Your Eyes Worse? in other Oscar Wylee regions and
their languages.
Australia
Australia
New Zealand
Canada
Canadian French

Find Your Local Oscar Wylee Store
Come in and see the team for your eye care needs, including eye
testing. All major health funds are accepted in-store.
[Discover Health Funds](https://www.oscarwylee.com.au/health-funds.html)
Book an Eye Test at Oscar Wylee
If you are an eligible Medicare cardholder, our eye tests will be bulk
billed.
[Eye test near me](https://www.oscarwylee.com.au/booking)