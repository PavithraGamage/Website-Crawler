# Source: https://www.oscarwylee.com.au/health-funds/nib.html

# NIB at Oscar Wylee
As a member of NIB, you can claim on optical extras using your health fund’s coverage for optical services, such as prescription frames, lenses or glasses. NIB benefits reset every calendar year, claim your glasses before time runs out! At the end of the year, any extras you don’t use will be lost.  With Oscar Wylee, you can have partial coverage on optical purchases when you shop with us. Look at the table below to see your NIB policy’s name and the amount of coverage that policy gives when you shop at Oscar Wylee. Your coverage might change or not apply to extras such as add-ons, coatings or tinting.
## Have your eyes tested
Oscar offers all eligible medicare cardholders a bulk billed eye test as performed by a fully qualified optometrist.
[Book your eye test](https://www.oscarwylee.com.au/booking)
#### Waiting Period
6 Months
#### Benefit Limits Reset
1st of January
#### Claimable Benefits %
100% for Basic Extras, 60% for Core Extras/Core and Wellbeing Extras, 70% for Advantage Extras
To learn whether your plan includes single vision lenses, bifocal lenses and/or multifocal lenses, talk to your health insurance provider.
| Your Extras Package Annual Limit:* | Basic Extras | Core Extras | Core and Wellbeing Extras | Advantage Extras | SINGLES COVER | 1 Standard OW Pair from $169^ | 2 Standard OW Pairs from $199^ | 3 Standard OW Pairs from $249^ |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| $150 | $250 | $250 | $250 |
| Partial Cover | Partial Cover | Partial Cover | Partial Cover |
| Partial Cover | Partial Cover | Partial Cover | Partial Cover |
| Partial Cover | Partial Cover | Partial Cover | Partial Cover |
^Excludes add-ons. Standard frames and lenses only. Oscar Wylee’s standard product inclusions are calculated based on the optical allowances under each health fund package and may vary. If unsure, please confirm with your provider. Our two pair and three pair deals are only available per person and cannot be split between two people. Only one prescription can be used per offer. If you have a distance and a reading prescription, this is included in the offer as this is considered to be one prescription. Any prescriptions must have the full name of the person claiming and a valid expiry date to be able to order. If you have two different prescribed prescriptions, you will need to visit a store to be eligible for our two pair and three pair deals.
| FAMILY COVER | 1 Standard OW Pair from $169^ | 2 Standard OW Pairs from $199^ | 3 Standard OW Pairs from $249^ |
| --- | --- | --- | --- |
| $300 per policy1 | $250 per person | $250 per person | $250 per person |
| Partial Cover | Partial Cover | Partial Cover | Partial Cover |
| Partial Cover | Partial Cover | Partial Cover | Partial Cover |
| Partial Cover | Partial Cover | Partial Cover | Partial Cover |
^Excludes add-ons. Standard frames and lenses only. Oscar Wylee’s standard product inclusions are calculated based on the optical allowances under each health fund package and may vary. If unsure, please confirm with your provider. Our two pair and three pair deals are only available per person and cannot be split between two people. Only one prescription can be used per offer. If you have a distance and a reading prescription, this is included in the offer as this is considered to be one prescription. Any prescriptions must have the full name of the person claiming and a valid expiry date to be able to order. If you have two different prescribed prescriptions, you will need to visit a store to be eligible for our two pair and three pair deals.
## Medicare cardholder? Try a bulk-billed eye test!
Oscar Wylee offers all eligible medicare cardholders a bulk-billed eye test in our stores. Come test with us today!
[In-store eye test](https://www.oscarwylee.com.au/booking)
*Based on NIB [Cover Guide](https://www.nib.com.au/health-insurance/extras) and product factsheet as presented to the Commonwealth Ombudsman [1](https://www.privatehealth.gov.au/dynamic/Download/NIB/I18/SCEW20) [2](https://www.privatehealth.gov.au/dynamic/Download/NIB/I19/TCGU20) [3](https://www.privatehealth.gov.au/dynamic/Download/NIB/I26/NCNY20) [4](https://www.privatehealth.gov.au/dynamic/Download/NIB/I33/TDOB20).1 For family cover, per policy means the shared maximum limit between family members that can be claimed within a calendar year. Coverage or partial coverage for our 1,2,3 pair deals is dependent on the per person limit, not exceeding the annual limit under each extras plan.Information correct as of October 2024.
## Your eye test explained
Routine eye test appointments are quick and painless. Find out what to expect during an eye exam and how to understand your eye test results.
[Find out more](https://www.oscarwylee.com.au/eye-health/your-eye-test-explained.html)
## Bulk Billing
Find out what bulk billing is and whether you're eligible to receive an eye test free of charge.
[Find out more](https://www.oscarwylee.com.au/eye-health/eye-test-info/bulk-billing.html)
## What is Pupillary Distance? (PD)
Do you know your PD? It's something you'll need to know when ordering glasses online. Find out what Pupillary Distance is and how you can measure your own.
[Read more](https://www.oscarwylee.com.au/eye-care/eye-test/what-is-pupillary-distance.html)
## Book an eye test
Oscar Wylee eye tests are bulk billed through Medicare. This means there will be no out-of-pocket expense for eligible Medicare cardholders.
[Book online](https://www.oscarwylee.com.au/booking/)
## Find a store near you
Contact or visit your nearest store for a full quote.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)