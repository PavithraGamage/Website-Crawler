# Source: https://www.oscarwylee.com.au/glasses/eye/dilated-pupil-exam

# Dilated Pupil Exam: Definition, Importance, Preparations
Published on May 10th, 2024
Updated on June 10th, 2024   
Australia    
[Australia](https://www.oscarwylee.com.au/glasses/eye/dilated-pupil-exam)
[Canada](https://oscarwylee.ca/glasses/eye/dilated-pupil-exam)
[Canadian French](https://oscarwylee.ca/fr/glasses/eye/dilated-pupil-exam)
A dilated pupil exam involves dilating a patient’s pupils in an eye test so an optometrist can get a better view of the deeper structures of the eye. A dilated pupil exam can check for signs of eye conditions including glaucoma, macular degeneration and diabetic retinopathy. It is recommended that a person should have a dilated eye exam every one to two years if they are over the age of 60 or have a family history of glaucoma. Keep reading to learn about how to prepare for a dilated pupil exam and how the test is conducted.
Do You Need Your Eyes Tested?
Book an appointment with an Oscar Wylee optometrist to have your eye health and vision assessed.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Definition](#definition) [Eye Conditions](#conditions) [Risks](#risks) [Frequency](#frequency)
## What is a Dilated Pupil Exam?
A dilated pupil exam refers to a procedure that requires an optometrist to dilate a person’s eyes to have a better view of the eye’s inner structures. An optometrist performs a dilated pupil exam to help them gain an in-depth picture of their patient's eye health that they cannot get in a standard eye exam. This eye test is used to detect eye conditions including macular degeneration, diabetic retinopathy and glaucoma, according to the National Eye Institute. As this exam involves [dilated pupils](https://www.oscarwylee.com.au/glasses/eye/anatomy/pupil), a person is recommended to not drive after the appointment as they can experience blurry vision and a sensitivity to light for some time afterwards.
### How is a Dilated Pupil Exam Conducted?
A dilated pupil exam is conducted by an optometrist in an eye test. To perform this eye exam, the optometrist will administer eye drops to dilate the pupils which will widen the pupil to give the [optometrist](https://www.oscarwylee.com.au/eye-care/optometrist) a better look at the inner structures of the eyes. According to the National Eye Institute, a dilated pupil exam may include a visual field test, a visual acuity test, an eye muscle test, a tonometry test and a pupil response test.
## Why are Dilated Pupil Exams Important for Eye Health?
A dilated pupil exam is important for a person’s eye health as it allows the optometrist to have a better view of the back of the eye that is limited if the eyes are not dilated. Eye dilatation is important as it can detect certain eye diseases such as glaucoma and diabetic retinopathy so they can be managed and treated.
### What Can a Dilated Pupil Exam Reveal About Your Eyes?
A dilated pupil exam is performed by an optometrist to look into the deeper structures of the eyes to learn and reveal more about the patient’s eye health. A dilated pupil exam can help diagnose eye conditions such as glaucoma, macular degeneration and diabetic retinopathy. These eye conditions and their definitions are listed below.
* Glaucoma: Glaucoma is a group of eye conditions or diseases in which damage to the optic nerve causes vision loss. To diagnose glaucoma, an optometrist will perform a comprehensive dilated eye exam, according to the National Eye Institute.
* Macular degeneration: Macular Degeneration is an eye disease that affects a person’s central vision, caused by damage to the cells. A dilated eye exam can help an optometrist diagnose macular degeneration.
* Diabetic retinopathy: Diabetic retinopathy is a complication of diabetes where the small blood vessels in the retina located at the back of the eye are damaged. Diabetic retinopathy is diagnosed using a dilated eye exam.
### What Happens to Dilated Eyes?
Dilated eyes occur when the pupil expands in response to light to let more light into the eye to help a person see. The pupil is the black circle in the centre of the eye and is controlled by the iris, the coloured part of the eye. When a person’s eyes are dilated for a pupil exam using dilating eye drops, the eyes do not respond normally to light so an eye care professional can look into the eyes without them constricting.
#### Are There Any Risks Associated with Dilated Pupil Exams?
The risks associated with dilated pupil exams are low although they may cause allergic reactions in certain patients. An eye care professional will take precautions to ensure any side effects are addressed.
Find an Oscar Wylee Store Near You
Our team in-store can help you with all things optometry and eyewear.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
## How to Prepare for a Dilated Pupil Exam?
A dilated pupil exam is non-invasive and requires little preparation. As the eyes will remain dilated for some time after the exam, a person will need to organise transportation home. Dilated pupils can cause blurry vision and sensitivity to light making it dangerous to drive.
### What to Expect After a Dilated Pupil Exam?
After a person has had their eyes dilated for a dilated pupil exam, their eyes will remain dilated for a period of time. According to Medical News Today, a person with dilated pupils may experience blurred vision, difficulty focusing on near objects and sensitivity to bright lights. Your optometrist will explain all [eye checkup expectations](https://www.oscarwylee.com.au/glasses/eye/check-up) that are involved when you have an eye test.
### How Often Should You Have a Dilated Pupil Exam?
How often a person should have a dilated pupil exam varies depending on their eye health. According to the National Eye Institute, a person should have a dilated eye exam every one to two years if they are over the age of 60 or if they have a family history of glaucoma. They also report that people who have high blood pressure or diabetes should have a dilated eye exam at least once a year.
#### Can Children Undergo a Dilated Pupil Exam?
Yes, a child can undergo a dilated pupil exam if the eye care professional deems it necessary. Dilation may be needed in a children’s eye exam as young kids may not provide accurate feedback about their vision and therefore, an optometrist will need to have a better look at the structures of their eyes. The other tests performed in a [children’s eye exam](https://www.oscarwylee.com.au/glasses/eye/exam-for-children) include a visual acuity test, eye pressure test and refraction test.
### What is the Difference Between a Dilated Pupil Exam and a Refraction Eye Exam?
A dilated pupil exam and a refraction eye exam are both aspects of an eye test performed by an optometrist to learn different things about the patient's eye health and vision. A dilated pupil exam allows an optometrist to get a better view of the back of a patient’s eye which can detect eye conditions such as macular degeneration, diabetic retinopathy and glaucoma. A refraction eye exam is used to detect refractive errors such as nearsightedness, farsightedness and astigmatism.
Read Dilated Pupil Exam: Definition, Importance, Preparations in other Oscar Wylee regions and their languages.
Australia    
[Australia](https://www.oscarwylee.com.au/glasses/eye/dilated-pupil-exam)
[Canada](https://oscarwylee.ca/glasses/eye/dilated-pupil-exam)
[Canadian French](https://oscarwylee.ca/fr/glasses/eye/dilated-pupil-exam)
Due for an Eye Test?
Prioritise your eye health today and book a bulk billed eye test with one of our skilled optometrists.
[Book an Eye Test](https://www.oscarwylee.com.au/booking)
Major Health Funds Accepted at Oscar Wylee
Visit our team in-store for a full quote and advice on how you can use your health fund for some of Oscar Wylee’s eye care services.
[Explore Health Funds](https://www.oscarwylee.com.au/health-funds.html)