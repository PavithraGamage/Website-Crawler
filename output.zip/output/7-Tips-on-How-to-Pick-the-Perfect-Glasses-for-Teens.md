# Source: https://www.oscarwylee.com.au/glasses/how-to-pick-glasses-for-teens

# 7 Tips on How to Pick the Perfect Glasses for Teens
Published on January 17th, 2025
Updated on January 11th, 2024 
The 7 tips on how to pick the perfect glasses for teens are to consider your teen’s lifestyle, check for prescription updates, evaluate face shape compatibility, choose the right frame material, think about lens options, explore style preferences and test the glasses. These tips are important to consider as teens get ready for another year of learning. With the frequent use of electronic devices in both their academic and social lives, it’s important to start the year off with a pair of glasses they will enjoy wearing.
Make Eye Health a Priority at Oscar Wylee
Oscar Wylee optometrists are available to perform high quality eye tests, bulk billed for eligible Medicare card holders.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Popular Frames Amongst Teens](#popular) [Specific Glasses for Boys and Girls](#types) [Reading Glasses for Teens](#reading)
The 7 tips on how to pick the perfect glasses for teens are to consider your teen’s lifestyle, check for prescription updates, evaluate face shape compatibility, choose the right frame material and style, think about lens options, explore style preferences and test the glasses. The 7 tips on how to pick the perfect glasses for teens are listed below.
* Consider your Teen’s Lifestyle:  Consider your teen’s lifestyle when choosing the perfect pair of glasses. Blue light blocking lenses can be good for those who have high levels of screen time for example.
* Check for Prescription Updates:  Check for prescription updates by booking them an eye test. It is recommended that teens get eye tests at least every two years.
* Evaluate Face Shape Compatibility:  Evaluate your teen’s face shape before deciding on their glasses frame shape. The common face shapes are round, oval, heart, square, pear and diamond.
* Choose a Compatible Frame Shape:  Choose a compatible frame shape once you have identified the face shape of your teenager. The most common glasses frame shapes are rectangle, oval, square, [cat-eye](https://www.oscarwylee.com.au/glasses/silhouette/cat-eye-glasses.html) and round glasses.
* Choose the Right Frame Material and Style:  Choosing the right frame material and style are important to ensure your teen has a pair of glasses they will enjoy wearing and feel comfortable in. Alongside picking the material, style is also an important factor.
* Think About Lens Options:  Think about lens options that can accommodate your teen’s lifestyle such as tinted lenses if your teen is out in the sun for long periods of time.
* Test the Glasses:  It is important that your teen tries on the glasses in store before purchasing for optimal comfortability.
## 1. Consider Your Teen’s Lifestyle
Consider your teen’s lifestyle when choosing the perfect pair of glasses. For example, they will need glasses that can accommodate blue light blocking lenses if they have high levels of screen time. Lightweight, impact-resistant glasses if they participate in sport or outdoor hobbies. Selecting a pair of glasses that accommodate your teen’s lifestyle ensures the glasses have optimal value in your teen’s daily activities.
## 2. Check for Prescription Updates
Check for potential prescription updates your teen may have. It is recommended that teens get eye tests at least every two years. Your teen should get an eye test if they haven’t had one in more than two years, or if they find their vision has worsened. Signs of this include if they are unable to see the smartboard clearly or are getting headaches. This will ensure your teen has the most accurate prescription available before picking out their glasses.
## 3. Evaluate Face Shape
Evaluate your teen’s face shape before deciding on their glasses frame shape. The common face shapes are round, oval, heart, square, pear and diamond. Evaluate their face shape using the descriptions below.
* Round:  Round faces are proportional in length and width and have soft, rounded curves with fuller cheekbones.
* Oval:  An oval face has an oblong shape with a wide forehead and a rounder jawline and chin.
* Heart:  A heart shaped face features a broad forehead and a small chin.
* Square:  Square faces have proportional width and length with a square jaw and broad forehead.
* Pear:  A pear face shape is characterised by a wide jawline with the face becoming narrow until it gets to the forehead, the smallest feature of the face.
* Diamond:  Diamond faces are the widest at the cheekbones with a narrow forehead and tapered chin.
## 4. Choose a Compatible Frame Shape
Choose a compatible frame shape once you have identified the face shape of your teenager. The most common glasses frame shapes are rectangle, oval, square, cat-eye and round glasses. The most faces shapes with these frames are listed below.
* Rectangle glasses:  Rectangle glasses suit oval, round and diamond faces because their angular lines balance out the softer features of these face shapes.
* Oval glasses:  Oval glasses suit square, diamond and pear faces as the soft curves offset their more angular features.
* Square glasses:  Square glasses suit heart, oval and round faces as the proportionate shape and sharp lines complement the circular features of these face shapes.
* Cat-eye glasses:  Cat-eye glasses suit pear, round and diamond faces because the feline feature at the upper corner of the frame draws the eye upwards and adds balance to the face.
* Round glasses:  Round glasses suit rectangle, square and pear faces as their proportional, circular shape adds softness and balance to the appearance.
Alongside face shape, face size is also important to consider. Measure the length and width of their face. If it’s on the smaller side, we have a range of [petite glasses](https://www.oscarwylee.com.au/glasses/collection/petite-collection.html) to fit them perfectly.
## 5. Choose the Right Frame Material and Style
Choosing the right frame material and style is important to ensure your teen has a pair of glasses they will enjoy wearing and feel comfortable in. Memory metal is great for teens who tend to be rough on their glasses due to their bendability. Titanium is renowned for its lightweightedness, for those seeking an unobtrusive fit. Acetate frames are often thicker and encompass a variety of frame colours for the more eclectic teen. Alongside picking the material, style is also an important factor. Consider colour or trendy transparent frames, pattern, frame thickness, and embellishments when it comes to selecting the perfect style.
## 6. Think About Lens Options
Think about lens options that can accommodate your teen’s lifestyle. Teens will likely be spending a lot of time online for schoolwork and social reasons. Having blue light blocking lenses can reduce the eye strain that can come with this screen time. Tinted lenses can be a helpful add on if your teen is out in the sun for long periods of time. Anti-reflective coatings can be beneficial to reduce glare, while photochromatic lenses adjust the lens tint to different lighting conditions which can benefit teens with heightened sensitivity to light, for their convenience. Choosing the correct lenses is important in ensuring further comfort and eye health.
## 7. Test the Glasses
It is important that your teen tests the glasses before purchasing. Ensure the fit is comfortable, and that there isn’t added pressure on the nose bridge or tops of the ears. Make sure the frame isn’t too small or big on their face. A good fit is important to ensure they will be comfortable wearing the glasses for long periods.
Find an Oscar Wylee Store Near You
Come and visit your local Oscar Wylee store and try on our range of stylish frames.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
## What Types of Glasses Frames are Popular Among Teens?
The types of glasses frames that are popular among teens include [round glasses](https://www.oscarwylee.com.au/glasses/silhouette/round-glasses.html), clear frames and slim frames. These frames can be seen worn amongst social media influencers, which teens frequently follow on social media platforms. These types of glasses frames that are popular among teens are listed below.
* Round glasses:  Round glasses have become increasingly popular among teens due to their vintage-inspired look and quirky, unique aesthetic they can bring to any outfit.
* Clear frames:  Clear frames are worn frequently amongst influencers and have found an appeal in teenagers alike. They offer a minimalist, discrete look that complements a variety of outfits.
* Slim frames:  Slim frames have found popularity amongst young people due to their minimalist, subtle look in comparison to thicker frames.
### Are There Specific Glasses for Teen Boys and Girls?
There are specific glasses that might appeal separately to teen boys and girls. Neutral coloured, angular frame shapes will likely appeal to boys. Sports sunglasses such as TR90 frames are also resistant to wear and tear which would be beneficial to more active, sporty boys. Meanwhile, round or cat-eye frames have a more feminine shape to appeal to girls. They may prefer these shapes, or other glasses frames with stylish accents around the rims. However, any pair of glasses can be worn by boys or girls. They may even find a more compatible fit in our petite range of glasses, catered to smaller faces. While some may lean towards more masculine or feminine aesthetics, it is ultimately up to the personal preference of your teen.
#### Will Aviator Glasses Look Good on Teens?
Yes, aviator glasses look good on teens. Ultimately it is the face shape that factors into whether [aviator glasses](https://www.oscarwylee.com.au/glasses/aviator) will be compatible with your teen's face. Teens with heart-shaped faces will likely suit aviator glasses the most.
## What Features Should Teen Boys Look for in Eyeglasses?
Teen boys should look for both comfort and stylistic features. Adjustable nose pads and lightweight frames are characteristics that allow for unobtrusive, well-fitting spectacles that can be worn easily throughout the day. UV protective lenses can be an asset to sporty teenage boys for total clarity and more sun protection during physical activity. Polarised lenses for instance have a UV400 rating which blocks essentially 100% of the sun's ultraviolet rays from reaching the eyes, perfect for teen boys who partake in outdoor sports frequently. A masculine design such as colour, shape and other embellishments is also pivotal, as a frame they enjoy the aesthetics of is one they will want to wear.
## What are the Top Features to Look for in Teen Girl Glasses?
The top features to look for in teen girl glasses encompass functionality and style. A scratch-resistant coating can be useful for girls as it ensures further protection of the lenses, particularly if they are kept in handbags or school bags. Blue light lenses are ideal for girls who are often on their phones, laptops and other devices. Alongside these functional features, stylish frames will make all the difference as girls will be more inclined to wear them. Consider frame shapes, colours and added embellishments for a feminine accessory they will enjoy wearing.
#### Are Reading Glasses Necessary for Teens?
Reading glasses may be necessary for some teens if they are farsighted, and reading close-up text causes eye strain or headaches. Having an eye exam can gauge whether [reading glasses](https://www.oscarwylee.com.au/reading_glasses.html) are necessary.
Take Care of Your Eyes at Oscar Wylee
It is recommended that you have an eye test with an optometrist at least once every 2 years. Book your eye test at Oscar Wylee today.
[Book an eye test](https://www.oscarwylee.com.au/booking)
Oscar Wylee Accepts Major Health Funds In-store
Visit Oscar Wylee in-store for eye care services and your health fund may help cover some of the cost.
[Health funds](https://www.oscarwylee.com.au/health-funds.html)