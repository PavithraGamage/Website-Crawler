# Source: https://www.oscarwylee.com.au/celeste-optical.html

# Celeste
1
## Frame Design of Celeste Glasses
The frame design of Oscar Wylee’s Celeste glasses is characterised by an oval shape, a low-bridge nose fit and an acetate frame. Celeste glasses are a women’s frame that will work for any occasion, whether the wearer wants to liven up their work style or complement a fun outfit for a night out.
$169    
In stock
Only %1 left
2 pairs from $199
Discount auto-applied at checkout
3 pairs from $249
Discount auto-applied at checkout
Qty
Add to cart
Book an eye test
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
excluding prescription lenses
## About Celeste Frames
Oscar Wylee’s signature transparent style, with a slightly smaller fit and square eyewear design. Celeste is crafted to flatter all face shapes, both men and women.
| Frame fit | Measurements |
| --- | --- |
| NARROW | 51 - 18 - 140 |
These measurements mean lens width, bridge, and temple length in millimetres (mm). They can be found on the inside of the temple arm. If you already have a pair that you like, you can compare it to these measurements.
### Made from Acetate
Oscar Wylee’s Celeste frame is a woman’s, rounded oval glasses frame that is perfect for narrow faces and those with square, oval or heart face shapes. The Celeste frame is a widely wearable frame that can be worn every day. The main specs of Oscar Wylee’s Celeste glasses frame including dimensions, shape, materials, lenses and nose fit are listed below.
| Celeste Frame Features | Celeste Frame Description | Dimensions | Shape | Materials | Lenses | Nose Fit |
| --- | --- | --- | --- | --- | --- | --- |
| The dimensions of the Celeste frame are measured in millimetres (mm) and are 51 - 18 - 140, meaning the lens width is 51 mm, the bridge is 18 mm and the temple length is 140 mm. |
| The Celeste frame is a rounded oval shape, well suited to narrow faces. |
| Celeste glasses are made from a material called acetate. |
| The lenses that can be used in the Celeste frame are optical lenses, which include single vision and multifocal lenses and non-prescription lenses, which are plain and can have a filter like a blue light filter applied. |
| The nose fit of Celeste glasses is a low nose fit, designed for low-bridge noses. |
Show All
### What Inspired the Frame Design of Oscar Wylee’s Celeste Glasses?
The Oscar Wylee Celeste frame design was inspired by current fashion trends as oval shapes are often in fashion. An oval glasses shape is timeless meaning it remains popular throughout the decades while other trends pass.
## What to Know About Oscar Wylee’s Celeste Glasses?
There are many aspects of the Oscar Wylee Celeste frames that customers should know about, so they can decide whether this is the right frame for them. The Celeste frame is a women’s oval-shaped frame. Oscar Wylee’s Celeste frame is suitable for many face shapes but particularly compatible with square, oval and heart face shapes. The Celeste frame’s simple design means that they are fashionable all year round. Celeste glasses feature the standard [parts of glasses such as a rim, temples, lenses and a low nose bridge.](https://www.oscarwylee.com.au/glasses/eye/part-of-glasses)
### What are the Types of Temple Tips or Earpieces Included with Oscar Wylee’s Celeste Glasses?
The type of temple tips or earpieces included in Oscar Wylee’s Celeste Glasses are made from acetate, the same as the rest of the temple and rim.
### What Type of Nose Bridge do Oscar Wylee’s Celeste Glasses Have?
The type of nose bridge included in Oscar Wylee’s Celeste frame is a low nose bridge fit. A low-nose bridge fit is suitable for those with low-nose bridges.
### What Type of Nose Pads are Included with Oscar Wylee’s Celeste Glasses?
Oscar Wylee’s Celeste frame does not include any type of nose pads.
### What Type of Lenses do Oscar Wylee’s Celeste Glasses Have?
The type of lenses that typically come with the Oscar Wylee Celeste [glasses frame are optical lenses. Optical lenses are glasses lenses that have a prescription within the lens to help correct vision issues such as myopia, hyperopia and astigmatism. Celeste glasses can also come with non-prescription lenses, with add-ons like a blue light filter. Celeste frames are currently unavailable as sunglasses online, however, customers can customise in-store and add on tint or polarisation.](https://www.oscarwylee.com.au/glasses.html)
### What Material is Used for the Rim of Oscar Wylee’s Celeste Glasses?
The material used for the rim of Oscar Wylee’s Celeste glasses frames is acetate. The rim refers to the part of a glasses frame that holds the lenses.
## What Face Types are Most Suitable for Oscar Wylee’s Celeste Glasses?
The face types that are most suitable for Oscar Wylee’s Celeste frame are heart, oval and square face types. The Celeste frame is a rounded oval shape, meaning that it complements the structure of oval faces particularly well. The rounded Celeste frames help to balance the features of an [oval face shape and heart face shape, bringing the eyes and brows forward in a flattering way. The Celeste frame is also suitable for a](https://www.oscarwylee.com.au/glasses/face-shapes/oval)[square face shape. Round and oval frames help to bring forward the sharp and striking features of a square face type, highlighting without overemphasising them. Although there are many](https://www.oscarwylee.com.au/glasses/face-shapes/square)[glasses for face shapes that may be considered more aesthetically suitable, it is important that people also choose the frames that make them feel most comfortable, and represent their personal style.](https://www.oscarwylee.com.au/glasses/face-shapes)
## What Size Options are Available for Oscar Wylee’s Celeste Glasses?
The size options available for Oscar Wylee’s Celeste frame are a narrow-frame fit across all colours. The frame is also offered in a Celeste Small frame in the colour Clear Crystal.
## What Materials are Used to Create Oscar Wylee’s Celeste Glasses?
The primary material used to create the Oscar Wylee Celeste frame is acetate. Acetate, also known as cellulose acetate, is a bioplastic, made from cotton fibres or wood pulp. At Oscar Wylee, acetate glasses are made by adding a dye to cellulose acetate, which is rolled into a sheet. The shape of the glasses is then cut from this sheet.
## What’s Included
## OW Case &amp; Cloth
Protective Case and Lens Cloth
Our high-quality glasses case and lens cloth are included with every purchase of an Oscar Wylee frame. The stylish, magnetic case is made from a hard shell. This sturdy and durable material keeps your glasses protected and safe, wherever you go. Ensure your lenses are clean and scratch-free with our OW microfibre cloth, specifically designed to ensure you have comfortable vision through your lenses.
Oscar Wylee offers:
* Free Shipping for Australian Orders
* 1 Year Warranty on frames and lenses
* Scratch resistance lens coating on all prescriptions
* UV-proof coating on all prescriptions
Health fund rebate: Once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. Learn more about [health funds](https://www.oscarwylee.com.au/health-funds.html).
## Make and Materials
The frames then go through cleaning and strict quality control, and many pairs of crafting hands to be hand-assembled and polished. After your frames have gone through the production process, they are individually examined and packed before making their way to you!Also known as cellulose acetate, these frames are traditionally hand-crafted by skilled craftsmen, with each frame passing through numerous stages of production and are hand-polished to ensure a glorious lustre.
## Warranty Information
### Warranty Information
### Warranty Information
Oscar Wylee provides a 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects. 
We will repair or replace faulty or defective frames or lenses free of charge for warranty claims made within 1 year of the delivery.
We also offer repairs or replacement for problems experienced with vision during everyday use for claims made within 30 days of delivery. If the same product has been discontinued or is no longer available, then we may offer an exchange for a similar product or a refund.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Find a Store Location](https://www.oscarwylee.com.au/locations/full-store-list.html)
Recommended
1. [](https://www.oscarwylee.com.au/odette-optical.html)
[Odette](https://www.oscarwylee.com.au/odette-optical.html)
Champagne
2. [](https://www.oscarwylee.com.au/evans-optical.html)
[Evans](https://www.oscarwylee.com.au/evans-optical.html)
Citrus