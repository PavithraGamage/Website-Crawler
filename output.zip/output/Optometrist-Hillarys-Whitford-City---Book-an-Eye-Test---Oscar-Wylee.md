# Source: https://www.oscarwylee.com.au/locations/optometrist-whitford-city.html

# Optometrist Hillarys Whitford City
Westfield Whitford CityShop 169, Cnr Marmion Ave &amp;, Whitfords AveHillarys WA 6025
* Opposite Aldi
Opening hours
Monday9:00am - 5:30pm
Tuesday9:00am - 5:30pm
Wednesday9:00am - 5:30pm
Thursday9:00am - 7:00pm
Friday9:00am - 5:30pm
Saturday9:00am - 5:00pm
Sunday11:00am - 4:00pm
*Store hours reflect local standard trading hours and exclude public holidays
[Visit our Whitford City Google Business page for directions, reviews, and updates.](https://g.page/r/Cfc-i0P3W2SYEBM)
Book Appointment
[Call us: (08) 6209 5899](tel:(08) 6209 5899)
[Leave a Review!](https://g.page/r/Cfc-i0P3W2SYEBM/review)
Our Reviews
Ash Hams
2 years ago
Was recommended by a friend and was so glad I went! The ladies were such professional’s and really h...elpful- both for my eye tests and helping me pick out my glasses. Zero pushiness which I so appreciated. Just genuine support. Thanks team! I’ll definitely recommend.
See more
Lisa
2 years ago
Amazing experience. Optometrist was brilliant and staff were fantastic! The range is great and fashi...on forward!
See more
A Google User
2 years ago
Great service. Thank you
ebony sky
2 years ago
Hannah
3 years ago
I visited Oscar Wylee today and I had an outside prescription. I was welcomed by a lovely lady calle...d Mena, which I believe she was the Optometrist herself. She took her time to help me with the most beautiful selection of frames and made my experience really nice being first time at Oscar Wylee. Unfortunately I didn’t have my private health insurance card to order my beautiful frames but I'll go back this week. Highly recommended!
See more
## Find an Optometrist in Whitford City With Oscar Wylee
If you live close to the Craigie, Padbury and Kallaroo areas, then our Oscar Wylee store at Westfield Whitford City is your go-to for all things optometry and eyewear. You can find us on level 1, across from Miss Mauds and Aldi, where our dedicated optometrists can provide Medicare bulk billed eye tests. Our friendly retail team will also help you find a pair of our stylish and affordable frames.
To make your appointment with us, you can take one of the several buses that stop outside the centre or you can drive in and use the centre’s complimentary parking. Whilst here, why not make the most of your trip and explore the many retail stores Westfield has on offer, from Country Road to EB Games. If you want more adventure, the Aquarium of Western Australia is also nearby. Come in and see the Oscar Wylee team at Westfield Whitford City!        
Meet Our Team
* Optometrist Partner
BSc (Hons)
MCOptom
* Retail Partner
* Store Manager
Certificate IV in Optical Dispensing
Our Services
* Bulk Billed Eye Examinations
* Professional Frame Styling
* Frame Adjustments and Repairs
* Visual Fields Testing
* Digital Retinal Scanning
Show All
## Find an Optometrist in Whitford, Western Australia for an Eye Health Test
An optometrist in Whitford, Western Australia is where you can get your eyes tested for a bulk billed price courtesy of Australia’s Medicare system. Our optometrists conduct thorough eye health tests in Whitford and are dedicated to ensuring your comfort during the entire procedure. Along with our skilled optical dispenser, you are guaranteed great-fitting frames! For more complex eye conditions, we may likely refer you to an eye doctor in the area for further assessment. Let us help you prioritise your eye and vision health by making an appointment here online or in-store. Regular eye tests help maintain ocular health and pick up on signs of eye diseases. During an eye test, you can expect different tests to be carried out which help the optometrist examine different regions of the eye. If you need prescription sunglasses, look no further than Oscar Wylee in Whitford for a wide variety of styles.
The average price for an optometrist in Whitford may depend on factors such as the total number of available optometrists in Whitford, required equipment and the current health of your vision.
## How to Find an Optometrist in Whitford, Western Australia?
To find an optometrist in Whitford, Western Australia, you can take certain steps that can help make it easier for you such as searching online, assessing the store’s opening hours and finding the directions to your chosen location.The steps on how to find an optometrist in Whitford are listed below.
1. Search online using the phrase, Whitford optometrist near me. This can also be done here on the website via our locations page.
2. Click on the Oscar Wylee link, which will take you directly to our Whitford optometrist store page.
3. See the store’s opening hours and where the store is located specifically.
4. Use the Whitford Google Business page link located under store hours to see the directions on how to get to the store.
You can also find an optometrist in Whitford by searching the keywords optometrist near me. If you have locations enabled on your smartphone and you’re in the area of Whitford, our Whitford store page should appear easily for you to click on.
### Is it Hard to Get an Eye Appointment in Whitford, Western Australia?
No, it is not hard to get an eye appointment in Whitford. You can easily book an appointment to see an Oscar Wylee optometrist in Whitford right here on this page. At Oscar Wylee we have highly qualified optometrists available for bulk billed eye appointments, which can be booked online or in-store.
#### How to Compare Optometrists in Whitford to Each Other?
To compare optometrists in Whitford, you can use factors such as eye tests offered, health fund coverage, lens types and add-ons and eyewear offered. To take care of your vision and eye health, it is important to receive an eye test at least once every two years. There are different types of tests that can be performed in an eye test and not all optometrists may offer the same tests. Health funds can be used to help cover some of the cost of your frames and lenses. To find out if your health fund is accepted at Whitford optometrist in Western Australia, visit their website. In the case of Oscar Wylee, we accept all major health funds and provide on-the-spot claims in-store. There are many different lens options available for prescription glasses such as single vision, multifocal and high index lenses. Most optometrists in Whitford will offer these lenses although it is good to make sure. There are also lens add-ons available to enhance your glasses such as anti-reflective and blue light filters. Finally, if you are looking to purchase a pair of glasses after your eye test, you can compare the different styles and colours you are interested in from Whitford optometrists in Western Australia. Oscar Wylee offers a wide range of frames with vintage and modern inspirations in bold colours and subtle designs.
#### How to Find an Eyeglasses Shop in Whitford, Western Australia?
To find a glasses store in Whitford, you can try to follow these simple steps including searching online, selecting a convenient location and looking at their health insurance policies. The steps on how to find a glasses store in Whitford, Western Australia are listed below.
1. Search online using the phrase, glasses store in Whitford. This will provide you with various options for glasses stores in the whole Whitford, Western Australia area.
2. Select a glasses store that is most convenient for you to travel to.
3. Click the link to find out more information such as opening hours, exact location and directions to the glasses store in Whitford.
4. Read their health insurance policies to ensure you know what health benefits you have access to.
Our Oscar Wylee glasses store in Whitford, Western Australia offers primary eye care services such as comprehensive eye tests as well as other services performed by an optometrist and offers prescription and non-prescription eyewear.
##### Is it Possible to Purchase Prescribed Sunglasses in Whitford, Western Australia Without Seeing an Optometrist?
Yes and no, it is possible to [purchase prescribed sunglasses](https://www.oscarwylee.com.au/sunglasses.html) in Whitford, Western Australia without seeing an optometrist if you already have a prescription that has not expired. If your prescription is expired, you can book an eye test to receive an updated or new prescription which will require you to see an optometrist. This will ensure your prescription sunglasses are appropriate for your visual needs.
## Where is the Oscar Wylee Whitford Optometrist in Western Australia Located?
The Oscar Wylee Whitford optometrist is located in the Westfield Whitford Shopping Centre. You can find the Oscar Wylee Whitford store opposite Aldi.
### What is the Phone Number of Oscar Wylee Whitford Optometrist Store?
The Oscar Wylee Whitford optometrist store phone number is (08) 6209 5899. You can contact the Oscar Wylee Whitford store between 9 am and 5:30 pm on Monday, Tuesday, Wednesday and Friday, on Thursdays between 9 am and 9 pm, on Saturdays between 9 am and 5 pm and on Sundays between 10 am and 5 pm.
### What are the Reviews for Oscar Wylee Whitford Optometrist in Western Australia?
The many reviews for Oscar Wylee Whitford optometrist in Western Australia, left by our various customers can be found here on the website and online when you search for Oscar Wylee Whitford optometrist. The reviews for Oscar Wylee Whitford optometrist are listed below.
* Ray Harris:  Excellent and quick service from the optometrist. Having my eyelashes poking into my eye, was removed and was a great relief.
* Barbara Packer:  Very happy, lovely people, lots of lovely frames and definitely want to go back when I need to.
* Nat Smith:  Friendly staff, quick process. Very happy.
* Maria Huynh:  We had Chloe help us pick out our frames and explanation of lenses, etc. She was very nice and helpful, able to answer our questions thoroughly and also giving great advice without feeling pushed to purchase anything (which I've felt at other stores before). Chloe was able to handle multiple customers (while we were still searching for our frames) and still handled each of us with care, even though she was the only one there. Place was kept clean and tidy and I loved how the glasses were arranged. We can't wait to get our glasses.
#### What Treatments or Eye Care Processes are Done in the Oscar Wylee Whitford Optometrist Location?
The treatments or eye care processes done in the Oscar Wylee Whitford optometrist Western Australia location include a tonometry test, a digital photograph, a slit lamp exam and a refraction test. Additional tests that may also be performed can include a visual field test and a dilated fundus exam. The treatments or eye-care processes that are done in the Oscar Wylee Whitford optometrist Western Australia location are listed below.
* A Tonometry Test: An optometrist or optical dispenser will conduct a tonometry test which involves the use of a machine that will release small puffs of air into your eyes. This will assist with measuring pressure in the eye.
* A Digital Photograph:  An optometrist or optical dispenser may take a digital photograph of your eye which can be kept on record to use in future appointments to evaluate any changes to your eye.
* Slit Lamp Test: A slit lamp test can be used to evaluate your eye health, by examining your cornea and iris which are the anterior and posterior of the eye.
* Refraction Test: During a refraction test, an optometrist will have you view an image through different lenses and ask you to confirm which helps you see the image clearer.
* Visual Field Test: A visual field test can assist with assessing your peripheral vision, which may be beneficial for identifying any signs of glaucoma.
* Dilated Fundus Exam: A dilated fundus exam can help an optometrist assess your health in more detail by getting a clear view of the retina. This test is typically carried out for patients with diabetes and those who may be at risk of developing retinal damage.
## How Many Optometrists Exist in Whitford, Western Australia?
Many optometrists exist in Whitford, Western Australia who are available for comprehensive eye tests and a wide range of eyewear, including Oscar Wylee. The number of optometrists found in Whitford, Western Australia may depend on reasons including the geographical size and location and the total number of residents in the area. Here at Oscar Wylee Whitford, you can receive professionally conducted services and care for all your optometry concerns.
### What are the Other Closest Optometrist Locations to Whitford, Western Australia in Australia?
The other closest Oscar Wylee optometrist locations to Whitford are Joondalup and Karinyup. Joondalup is close to Whitford with 9 km in between stores and is located at 420 Joondalup Drive. The [Oscar Wylee Joondalup](https://www.oscarwylee.com.au/locations/optometrist-joondalup.html) store can be found on the ground level near Woolworths and is where you receive top-quality eye health services such as comprehensive eye tests and prescription eyewear. Karinyup is close to Whitford with 12-16 km in between stores and is located at the Karrinyup shopping centre at 200 Karrinyup Road. The [Oscar Wylee Karrinyup](https://www.oscarwylee.com.au/locations/optometrist-karrinyup.html) store is your go-to for an abundant selection of modern and vintage-style frames for either prescription or non-prescription eyewear.
### Bulk Billed Eye Tests at Oscar Wylee
For some of the best optometrists in Hillarys, Australia, visit Oscar Wylee at Whitford City Westfield. Our Oscar Wylee optometrists provide a range of eye care processes including examining the eyes for potential eye diseases and vision testing. Come in and have your eye health test, prescription updated and shop for a new pair of eyeglasses, all on the same day. For all your eyesight and eye health needs, visit Oscar Wylee in Whitford City Westfield!
### Health Funds Accepted
Oscar Wylee in Westfield Whitford City accepts major health funds in-store. Come to Oscar Wylee for your eye care needs such as prescription glasses and your health fund may help cover some of the costs. Our team can process your claim in-store with a valid health fund card, as well as help you out with any questions on eligibility, to make sure you’re getting the best price for your prescription glasses needs.
### Fashion-Forward Frames at Oscar Wylee
Here at our Oscar Wylee eyeglasses shop in Hillary’s Westfield Whitford City, we offer prescription glasses, prescription sunglasses and non-prescription glasses in a variety of modern and vintage-inspired styles. Oscar Wylee also has various lens options such as multifocals, and add-ons such as blue light filters for an additional price, so you can get the most from your glasses. For all your eye care needs, visit Oscar Wylee at Westfield Whitford City.
Book Appointment
[Call us: (08) 6209 5899](tel:(08) 6209 5899)
[Leave a Review!](https://g.page/r/Cfc-i0P3W2SYEBM/review)