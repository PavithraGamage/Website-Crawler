# Source: https://www.oscarwylee.com.au/glasses/eye/presbyopia

# Presbyopia: Definition, Causes, Symptoms, Diagnosis, and Treatment
Published on July 31st, 2023
Updated on December 11th, 2024
Australia
[Australia](https://www.oscarwylee.com.au/glasses/eye/presbyopia)
[Canada](https://oscarwylee.ca/glasses/eye/presbyopia)
[Canadian French](https://oscarwylee.ca/fr/glasses/eye/presbyopia)
Presbyopia is an age-related eye condition in which a person’s near vision
is blurry, caused by the natural ageing of the lens which results in the
lens becoming harder and less flexible. This article will discuss the
presbyopia definition, its causes, symptoms, diagnosis and treatment. The
symptoms of presbyopia include blurry near vision, headaches, eye strain and
moving objects further away to see. Presbyopia can be diagnosed through a
comprehensive eye test performed by an optometrist. The main treatments for
presbyopia include corrective devices which are prescription glasses and
contact lenses. Keep reading to learn more about presbyopia and how this
age-related eye condition is caused.
[Definition](#Definition) [Causes](#Causes)
[Symptoms](#Symptoms) [Treatment](#Treatment)
## What is Presbyopia?
The answer to what is presbyopia, or the presbyopia definition, is an
age-related eye condition and refractive error that causes blurry vision
when looking at objects close up and it typically presents after the age of
40. While presbyopia has similar symptoms to farsightedness (hyperopia),
that being blurry near vision, they are different eye conditions with
different causes. Presbyopia causes near vision to be blurry as, when a
person ages, the lens in their eye becomes hard and less flexible which
makes it more difficult for the eyes to focus on near objects. Presbyopia is
a very
[common eye condition](https://www.oscarwylee.com.au/glasses/eye/common-problems)
with the Australian Institute of Health and Welfare reporting that over 1.3
million Australian seniors have self-reported as having presbyopia in a 2005
study.
### Is Presbyopia the Same as Nearsightedness?
No, presbyopia is not the same as nearsightedness although they are both
refractive errors that cause vision issues.
[Nearsightedness](https://www.oscarwylee.com.au/glasses/eye/nearsightedness), known scientifically as myopia, can cause a person’s distance vision
to appear blurry. This eye condition causes blurry vision due to either
an elongated eyeball or an overly curved cornea, as the eye is not as
capable of bending and focusing light onto the retina correctly. A
person can have presbyopia and myopia (nearsightedness) at the same time
which may require a prescription lens with multiple prescriptions such
as bifocals or multifocals as they correct both near and far vision.
### How Does Presbyopia Work?
Presbyopia works or is concerned with the lens changing due to age which causes it to harden and lose
flexibility, resulting in the eye losing its ability to change shape to
allow for greater levels of focus.
There are five different types of presbyopia which are incidental
presbyopia, functional presbyopia, absolute presbyopia, premature
presbyopia and nocturnal presbyopia. According to the National Eye
Institute, once presbyopia is developed, it continues to get worse until
approximately the age of 65.
### What Parts of the Eye are Affected by Presbyopia?
The main
[part of the eye](https://www.oscarwylee.com.au/glasses/eye/anatomy)
that is affected by presbyopia is
the lens which then affects how light interacts with other parts of the
eye including the retina.
As a person ages, the crystalline lens, which sits behind the iris,
naturally changes, becoming harder and less flexible. These changes make
it difficult for the eye to focus on near objects as it loses its ability
to easily change shape. Due to these problems in the lens, it stops light
from correctly focusing on the retina. The below image shows
the parts of the eye that are affected by presbyopia.
Medicare Bulk Billed Eye Tests Available
Get your eye test bulk billed at Oscar Wylee with a valid Medicare card.
[Book an eye test](https://www.oscarwylee.com.au/booking)
## What Causes Presbyopia to Occur?
Presbyopia is a refractive error that is caused by the natural ageing process. As a person ages, their lens gets
harder and becomes less flexible, resulting in the eye not being able to
focus light correctly on the retina. Due to this issue, it causes close-up objects to look blurry, although it
is a different condition than farsightedness which also causes near
objects to appear blurry. There are not any other major causes of
presbyopia besides age which is why it cannot be prevented.
### At What Age do People Normally Develop Presbyopia?
The age that people normally develop presbyopia is early to mid-40s, according to the Mayo Clinic. Presbyopia is an age-related eye
condition, also called age-related farsightedness, that occurs as the
lens becomes less flexible and hard as you age. People often notice the
symptoms of presbyopia around the age of 40. Presbyopia will typically
continue to worsen over time until the age of 65.
### Do Kids Develop Presbyopia?
No, presbyopia does not typically develop in kids, although
it is possible to develop this eye condition before the age of 40 with people showing signs of this eye condition as early as 35. This is
called premature presbyopia and people may be at a higher risk if they
have existing health conditions such as cardiovascular disease and
diabetes or if the person has farsightedness or nearsightedness. People
who work a lot with their near vision such as on a computer or working
with small numbers are more likely to notice the signs of presbyopia
developing as they are constantly using their near vision for tasks that
require significant concentration.
### Can Smartphones Cause Presbyopia?
No, there is no scientific evidence that states smartphones cause
presbyopia.
While there is much discussion about the rapid increase in smartphone
usage and the impact it has on eye health, there is little evidence to
support that presbyopia can be caused by smartphones. Presbyopia is an
age-related eye condition meaning it occurs naturally as you age. While
there is a condition called premature presbyopia, it is not very common
and the risk factors according to the Cleveland Clinic include taking
certain medications, having certain existing medical conditions and
having farsightedness, none of which concern using a smartphone.
## What are the Symptoms of Presbyopia?
The symptoms of presbyopia include headaches, blurred vision close-up, requiring a great focus distance when
reading and eye strain.
These presbyopia symptoms and their definitions are listed below.
* Headaches: Headaches can be experienced by
people with presbyopia when they are doing close-up work like reading or
knitting.
* Blurred vision close-up: Blurred vision
when looking at close-up objects is a common symptom of presbyopia caused
by the natural ageing in the lens that can be corrected using glasses.
* Requiring a greater focus distance when reading:
Presbyopia causes a person’s near vision to be blurry, therefore, when
reading they may require a greater focus distance, meaning they will hold
the item further away from their eyes.
* Eye strain: Eye strain is caused by
presbyopia as the eyes are working harder to focus on near objects due to
their blurriness.
### 1. Headaches
Headaches can be experienced by people with presbyopia when they are
doing close-up work like reading or knitting. According to Health
Direct, because people with presbyopia have to strain their eyes to see near
objects, it could lead to headaches. To prevent headaches caused by presbyopia, corrective devices are
prescribed which magnify near objects, stopping the eye from focusing
too hard.
### 2. Blurred Vision Close-Up
Blurred vision when looking at close-up objects is the main symptom of presbyopia and caused due to age-related changes in the
lens. Blurred vision for presbyopia makes near objects appear hazy and
unfocused, losing their sharp and precise details. Blurred vision can be
corrected with prescription glasses using a plus-powered lens that acts
as a magnifier. Experiencing blurred vision up close often leads to
another common symptom which is requiring a greater focus distance when
reading.
### 3. Requiring a Greater Focus Distance When Reading
People with presbyopia often require a greater focus distance when reading as they struggle or
cannot see close up, meaning they hold the book further away from their
eyes.
Presbyopia causes a person’s near vision to be blurry, therefore, when
reading they may be unable to focus on the small print which can be
corrected using prescription glasses. As presbyopia only affects near
vision, as a book moves further away from their eyesight, it becomes
sharper and clearer.
### 4. Eye Strain
Eye strain is a symptom of presbyopia as this age-related eye condition
causes a person’s near vision to be blurry, making it difficult to do
near tasks such as reading, writing and knitting. Eye strain is caused by presbyopia as when performing these near tasks, the eyes have
to work extra hard to focus, causing the eyes to strain, leading to discomfort and fatigue. By correcting presbyopia, the eyes
will be able to see close-up tasks and objects clearly, which helps to
eliminate eye strain.
Need a New Pair of Glasses?
Visit our friendly team in-store to find the lenses that suit your
prescription and lifestyle needs.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
## How is Presbyopia Diagnosed?
Presbyopia is a refractive error that can be diagnosed in a standard eye
test. According to John Hopkins Medicine, the tests used to diagnose presbyopia include a visual acuity test, a
refraction test and a slit lamp test.
A visual acuity test is a common eye test performed by an optometrist to
assess the sharpness and clarity of a patient’s vision. Visual acuity is
tested using a Snellen eye chart or other similar letter charts, set at a
distance of 6 metres or 20 feet away. A refraction test is used to
determine the prescription a patient needs for vision correction. This
test involves the patient looking through different lenses on a special
optometry device called a refractor or phoropter to determine what lenses
make a person’s vision more clear. Finally, a slit lamp test is used to
assess the structure of the eye including the lens, cornea and iris. A
slit lamp test requires a patient’s head to be placed on a chin rest and
forehead to rest on a band, which is connected to the microscope of the
slit lamp. A beam of light from the microscope is then used to inspect the
eye.
### How Does Presbyopia Lead to Cataracts?
Presbyopia does not lead to [cataracts](https://www.oscarwylee.com.au/glasses/eye/cataracts)
but they are both age-related eye conditions with similar symptoms that
are caused by problems in the lens.
Both presbyopia and cataracts fall under the category of DLS
(dysfunctional lens syndrome) which is a term that describes the natural
changes in a person’s lens due to the ageing process, according to an
article published in the National Library of Medicine. Presbyopia and
cataracts occur due to the natural ageing process that causes the lens
to become hard in the case of presbyopia and for cataracts, the proteins
in the lens break down and clump together, causing clouding of the lens.
Presbyopia and cataracts can both be treated using cataract surgery as
this procedure, according to Better Health Victoria, involves removing
the lens and replacing it with a permanent artificial lens, known as an
intraocular lens. As the lens is completely replaced, it stops
presbyopia and the accompanying symptoms.
### Is Presbyopia the Same as Astigmatism?
No, presbyopia is not the same as astigmatism.
While they are both refractive errors, presbyopia and astigmatism are separate eye conditions that affect the eye differently.
Presbyopia is an age-related condition that causes a person’s near
vision to become blurry. Astigmatism occurs as the cornea or lens is
deformed or misshapen which leads to blurry vision and difficulty seeing
fine detail. Both of these eye conditions can be corrected using
prescription glasses to give a person clear and comfortable vision.
### How Can Presbyopia be Avoided?
Presbyopia cannot be avoided as it is an age-related refractive error,
therefore, it predominantly occurs along with the natural process of
ageing.
While there is no way to prevent or avoid presbyopia, the symptoms can
be managed with glasses that correct a person’s near vision.
#### Can Presbyopia be Cured?
No, presbyopia cannot be cured or reversed, rather it can be corrected
using corrective devices.
Presbyopia is a refractive error that affects a person’s near vision
and can be corrected using prescription glasses or contact lenses. The
type of glasses that can correct presbyopia include reading glasses,
bifocals and multifocal glasses.
## What are Ways to Treat Presbyopia?
The ways to treat presbyopia include progressive/multifocal lenses, contact lenses, reading glasses,
refractive surgery, bifocal glasses and corneal inlays.
These treatments for presbyopia and their definitions are listed below.
* Progressive/multifocal lenses: Progressive
lenses, also known as multifocal lenses, are a type of glasses that
contain three different prescriptions seamlessly in one lens. People with
presbyopia can use progressive lenses if they also have issues with
distance vision.
* Contact lenses: Contact lenses are
corrective devices that have curved lenses that are placed on the eye to
give the wearer clear vision. Contact lenses can be worn by people with
presbyopia.
* Reading glasses: Reading glasses are a
type of single-vision lenses that correct close-up vision. Reading glasses
can be used for people with presbyopia and hyperopia.
* Refractive surgery: Refractive surgery is
a broad term for eye surgery that is performed to improve a person’s
vision by correcting the eye so it focuses light correctly on the retina.
* Bifocal glasses: Bifocal glasses are
similar to multifocals in that they correct near and distance vision in
one lens, but instead of a seamless transition between prescriptions,
bifocals have clear segments separated by a visible line on the lens.
* Corneal inlays: A corneal inlay, also
known as keratophakia, is a device implanted in the eye used to correct
presbyopia.
### 1. Progressive/Multifocal Lenses
Progressive lenses, also known as multifocal lenses, are used to treat presbyopia as the lens contains three different
prescriptions, one for near vision (for those with presbyopia) one for
intermediate vision and one for distance vision. [Progressive lenses](https://www.oscarwylee.com.au/glasses/eye/progressive-lenses)
are a very popular choice of glasses for two main reasons. The first is,
unlike bifocal glasses, multifocals have a seamless transition between
the three prescriptions, meaning there is no interruption to the
wearer’s vision. The second is the ability to experience clear and
comfortable vision all in the one pair of glasses, so you don't have to
constantly switch glasses depending on the activity. At Oscar Wylee, we
offer three different types of multifocal lenses which can be chosen at
an additional cost on top of your standard optical glasses. The three
different types are Multifocal Elite, Multifocal Premium and Multifocal
Standard.
### 2. Contact Lenses
Contact lenses are corrective devices with curved lenses that are placed on the eye to
give the wearer clear vision.
According to an article published in the National Library of Medicine
titled, How can presbyopia be corrected?, contacts are worn on the cornea and they float on a layer of tear
fluid. Contact lenses can be worn by people with presbyopia to correct
the refractive error in their vision similar to prescription glasses.
[Contact lenses](https://www.oscarwylee.com.au/glasses/eye/contact-lenses)
may be a good option for people who are very active and play sports as
they will not get in the way. Contact lenses may not be suitable for
everyone which is why you should consult an eye care professional if you
are thinking about getting contact lenses to correct presbyopia or other
vision problems. At Oscar Wylee, we do not offer contact lenses.
### 3. Reading Glasses
Reading glasses, also known as readers, are a type of single-vision lens used to treat presbyopia by providing
correction for near vision. Single-vision lenses correct vision over a single distance for only
one vision type, which in the case of reading glasses is near distance.
Reading glasses work by magnifying nearby objects so the wearer can do
close-up tasks comfortably like reading a book or knitting without eye
strain or blurry vision. Reading glasses are different from distance
glasses as the latter help people who need help seeing things far away.
### 4. Refractive Surgery
Refractive surgery is a broad term for eye surgery that is performed to improve a person’s
vision by correcting the eye so it focuses light correctly on the
retina. According to the American Academy of Ophthalmology, common types of
refractive surgeries include LASIK (Laser-Assisted In Situ
Keratomileusis), SMILE (Small incision lenticule extraction) and PRK
(Photorefractive keratectomy). Refractive surgery will eliminate the
need for glasses although it does come with certain risks. If you are
interested in undergoing refractive surgery, talk to an eye care
professional about your options.
### 5. Bifocal Glasses
Bifocal glasses are a type of glasses that can be used by people with presbyopia if they
also struggle with distance vision.
Bifocal glasses contain two prescriptions in a single lens, that being a
near prescription and a distance prescription. Bifocal glasses are a
good option for people who have the refractive condition presbyopia as
they won’t have to switch between multiple pairs of glasses, rather they
can experience clear and comfortable vision in the one pair. Bifocal
glasses treat presbyopia as the bottom of the lens will contain a
plus-powered prescription that makes near objects clear and the top of
the lens will contain a distance prescription for those that have blurry
vision when looking at both near and distant objects. Bifocal glasses
are different to multifocal glasses as the two prescriptions are clearly
separated with a visible line whereas, in multifocals, there is a
seamless transition between three different prescriptions.
### 6. Corneal Inlays
Corneal inlays, also known as keratophakia, are devices implanted in the eye used to correct presbyopia. According to the American Academy of Ophthalmology, there are three types of corneal inlays which are refractive corneal
inlays, corneal reshaping inlays and small aperture inlays.
Refractive corneal inlays involve inserting a disc shaped corneal
implant into the eye to change the refractive index of the cornea. This
type of corneal inlay is used to correct both near and distance vision,
working in a similar way to multifocal contact lenses. Cornea reshaping
inlays correct presbyopia by changing the shape of a person’s eye,
specifically increasing the curvature of the anterior corneal surface.
Finally, small aperture inlays work by increasing a person's depth of
focus, improving near vision.
### Can Presbyopia be Prevented Through LASIK?
Presbyopia cannot typically be prevented or treated through LASIK
(Laser-Assisted In Situ Keratomileusis). Although, in Australia, there is a new type of laser surgery called
PRESBYOND which is a treatment for people with presbyopia over the age
of 50 that corrects their near vision. According to an article published
in the National Library of Medicine which was last updated in 2020, the
potential benefits of eye surgery need to be weighed against the
associated risks. Other refractive errors such as nearsightedness,
farsightedness and astigmatism can be corrected through eye surgery.
#### What is the Difference Between Presbyopia and Hyperopia
(Farsightedness)?
While they both are refractive errors and cause near or close-up
vision to be blurry, presbyopia and hyperopia (farsightedness) are
different eye conditions. The main difference between presbyopia and [hyperopia](https://www.oscarwylee.com.au/glasses/eye/hyperopia) is the cause of these eye conditions. Presbyopia is caused by the natural ageing process that affects the
lens, causing it to lose its flexibility, meaning the eyes don’t
change shape to allow for greater levels of focus. Hyperopia can occur
at any age and is caused by issues with the structure of the eye being
either too short or the cornea being flat. These structural issues
cause light to refract incorrectly and focus behind the retina instead
of on the retina, causing difficulty with near vision. Because the
symptoms are very similar, is it important to have your vision tested
by an optometrist as they can determine the differences between
presbyopia and hyperopia.
### Are Presbyopia and Eye Floaters Caused by Ageing?
Yes, both presbyopia and eye floaters can be caused by ageing.
Presbyopia is caused by ageing as, when a person ages, their lens becomes
less flexible making it more difficult for the eyes to focus on near
objects. Ageing is related to
[eye floaters](https://www.oscarwylee.com.au/glasses/eye/floaters-definition)
as the ageing process causes the vitreous to shrink, creating clumps of
collagen in the eye, causing eye floaters in a person’s vision.
Read Presbyopia: Definition, Causes, Symptoms, Diagnosis, and Treatment in
other Oscar Wylee regions and their languages.
Australia
[Australia](https://www.oscarwylee.com.au/glasses/eye/presbyopia)
[Canada](https://oscarwylee.ca/glasses/eye/presbyopia)
[Canadian French](https://oscarwylee.ca/fr/glasses/eye/presbyopia)
Claim In-Store at Oscar Wylee
Bring a valid health fund card to your next appointment and our staff
can process your claim in-store.
[Health Funds](https://www.oscarwylee.com.au/health-funds.html)
Due for an eye test?
Oscar Wylee optometrists are dedicated to providing quality eye care
services.
[Book an eye test](https://www.oscarwylee.com.au/booking)