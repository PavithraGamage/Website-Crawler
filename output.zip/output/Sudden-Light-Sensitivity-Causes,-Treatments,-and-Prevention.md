# Source: https://www.oscarwylee.com.au/glasses/eye/sudden-light-sensitivity

# Sudden Light Sensitivity: Causes, Treatments, and Prevention
Updated on October 10th, 2025
Published September 20th, 2023
Australia   
[Australia](https://www.oscarwylee.com.au/glasses/eye/sudden-light-sensitivity)
New Zealand

[Canada](https://oscarwylee.ca/glasses/eye/sudden-light-sensitivity)
[Canadian French](https://oscarwylee.ca/fr/lunettes/oeil/sensibilite-soudaine-lumiere)
Sudden light sensitivity refers to a sensitivity to light, either natural or artificial light, that comes on suddenly and unexpectedly. Light sensitivity, also known as photophobia, is discomfort or pain that occurs when the eyes are exposed to light. The answer to why your eyes are so sensitive will be dependant upon what the underlying cause of the issue is. The light sensitivity causes range from medical issues to eye conditions and can include migraines, a scratched eye, conjunctivitis (pink eye), chronically dry eyes, scleritis, keratitis and eye dilation. There are also serious medical conditions such as encephalitis, meningitis and herpes keratitis that can cause light sensitivity. The treatment for light sensitivity is dependent upon the underlying cause of the issue. Home treatments for light sensitivity or ways to manage the light sensitivity may include rest, using eye drops and wearing sunglasses. Prevention of sensitivity to light revolves around keeping the eyes healthy to prevent eye issues that may cause light sensitivity and can include getting an eye test, practising good hygiene and protecting the eyes.
It is essential to see a doctor or health care professional as soon as your eyes become sensitive to light, so the cause can be diagnosed and treated immediately. Light sensitivity can be a symptom of a serious medical issue.
Are You Due For An Eye Test?
It is recommended that you get an eye test every two years or as recommended by an optometrist. Book a Medicare bulk billed eye test with our Oscar Wylee optometrists today!
Book an eye test
[Definition](#definition) [Causes](#causes) [Medical Attention](#medical-attention) [Eye Exam](#eye-exam)
## What Does Sudden Light Sensitivity Mean?
Sudden light sensitivity refers to the quick onset of eye discomfort or pain that occurs when exposed to light. Light sensitivity, also known as photophobia, is an intolerance to light that may result in discomfort or pain, according to UCLA Health. Eyes that become unexpectedly sensitive to light can be caused by eye conditions such as viral conjunctivitis, or medical conditions such as migraines. Light sensitivity can be triggered by both natural light such as the sun, or artificial light like the light from a computer screen. If you have sudden sensitivity to light, it is important to see a healthcare professional as soon as possible as this symptom may indicate a serious medical issue.
## What Causes Sudden Light Sensitivity?
The causes of a sudden onset of light sensitivity can range from eye conditions including conjunctivitis, to medical conditions and migraines. Some of the most common causes of light sensitivity are migraines, a scratched eye, conjunctivitis, (pink eye), chronically dry eyes, scleritis, keratitis (corneal ulcer) and eye dilation. According to the Royal National Institute of Blind People, a person may experience sudden light sensitivity if they have an eye condition, due to possible swelling within the eye, slow adapting of the eye to light changes and issues with how light hits the macular part of the eye. The light sensitivity causes are listed below.
* Migraine: A migraine, which is a medical condition involving the brain, is one of the most common causes of light sensitivity.
* Inflamed Eyelid (Blepharitis): Inflamed eyelids, also known as blepharitis, may cause light sensitivity.
* Scratched Eye: A scratched eye also known as a corneal abrasion, can cause a sudden sensitivity to light.
* Conjunctivitis (Pink Eye): Conjunctivitis is an inflammation of the conjunctiva as a result of infection or allergies, that may cause light sensitivity.
* Chronic Dry Eyes: Chronic dry eyes refers to a condition in which the eyes do not produce enough tears to lubricate the eye, leading to dry eyes. A symptom of dry eyes may be light sensitivity.
* Scleritis: Scleritis is inflammation of the sclera, the white part of the eye, which may lead to light sensitivity.
* Keratitis (Corneal Inflammation): Keratitis is a condition in which the cornea is inflamed which can lead to light sensitivity.
* Eye dilation: Eye dilation refers to the process of dilating the pupils, usually using eye drops during an eye test, which may lead to light sensitivity.
### 1. Migraine
Migraines are one of the most common causes of light sensitivity. A migraine is a condition involving the brain that is often characterised by headaches that are severe in nature and may also involve other symptoms such as nausea depending on the type of migraine, according to Health Direct. One of the most common symptoms of migraines is sensitivity to light. Light sensitivity and migraines are so closely linked that light sensitivity is a key criterion in diagnosing migraines, according to the American Migraine Foundation. Those who have light sensitivity during a migraine attack may find that light causes discomfort or pain in the eye and worsens the migraine. Moving to a dark room or wearing sunglasses during a migraine attack to limit the amount of light hitting the eye may provide some relief.
### 2. Inflamed Eyelid (Blepharitis)
An inflamed eyelid, also known as blepharitis, may cause light sensitivity. Inflammation of the eyelids or blepharitis is an eye condition in which the eyelids become inflamed, irritated, red or swollen, often caused by a build-up of bacteria. Symptoms of blepharitis include teary eyes, crusty eyes and light sensitivity.
### 3. Scratched Eye
An eye scratch, also known as a corneal abrasion, may cause sudden sensitivity to light. A scratched eye refers to an abrasion on the surface of the eye, usually on the cornea, the top, clear layer at the front of the eye. According to the National Eye Institute, the cornea helps light entering the eye focus onto the retina properly. An abrasion to the cornea may make the eye more sensitive to light and may cause other symptoms such as discomfort or pain.
### 4. Conjunctivitis (Pink Eye)
Conjunctivitis may cause sensitivity to light as a result of the infection or inflammation caused by this condition. If there is severe sensitivity to light, it is important to see a doctor as soon as possible. [Conjunctivitis](https://www.oscarwylee.com.au/glasses/eye/conjunctivitis), also known as pink eye, is an eye condition in which the whites of the eyes, known as the sclera, become inflamed, as a result of infection or allergies. There are several types of conjunctivitis including bacterial conjunctivitis, viral conjunctivitis and allergic conjunctivitis.
### 5. Chronic Dry Eyes
Chronic dry eyes is an eye condition that may cause light sensitivity. Chronic dry eyes or dry eyes disease is an eye condition in which the eyes do not produce enough tears and are unable to provide adequate lubrication to the surface of the eyes, leaving the eyes dry. Light sensitivity may present as a symptom of dry eyes.
### 7. Scleritis
Scleritis refers to inflammation of the sclera, the white parts of the eye, and may cause sensitivity to light. The sclera is the white part of the eye that helps maintain the shape of the eye and protects it against injury. Scleritis is an inflammation of the sclera and can be caused by a range of issues from eye infections to underlying health conditions such as rheumatoid arthritis. Scleritis can cause symptoms including light sensitivity, pain and tenderness in the eye, according to the American Academy of Ophthalmology.
### 8. Keratitis (Corneal Inflammation)
Keratitis, also known as corneal inflammation, refers to an inflammation of the cornea part of the eye, a symptom of which may be light sensitivity. The cornea is the clear window at the front of the eye that lets light in. Keratitis can be caused by an infection such as bacterial keratitis or can have a non-infectious cause such as an eye injury or vitamin A deficiency, according to the Cleveland Clinic. Keratitis can cause symptoms including light sensitivity, watery eyes and eye pain.
### 9. Eye Dilation
Eye dilation may cause light sensitivity as the pupil is widened during eye dilation and will let more light in than usual. The pupil is the black circle in the centre of the eye that controls light entering the eye. Eye dilation is the process of the pupils becoming dilated or widened by eye drops, as part of an eye test to assist an optometrist in seeing the deeper structures of the eye. Eye dilation may cause light sensitivity as dilation increases the size of the pupil, allowing more light into the eye, according to the Bright Focus Foundation. Eye dilation from a dilated eye exam may last for several hours.
## What are Home Treatments you can do for Sudden Light Sensitivity?
Sudden light sensitivity can be a sign of a serious eye condition if it is accompanied by severe pain and should be assessed by an optometrist or health care professional, but if the situation is mild, there are certain home treatments a person can do to deal with this eye issue. The home treatments for eyes that become sensitive to light include rest, using eye drops and wearing sunglasses. These home treatments and their definitions are listed below.
* Take a Rest: Taking a rest is a great way to treat light sensitivity at home as it allows the eyes to have a break from irritating light by closing the eyes.
* Use Eye Drops: Eye drops may be used to treat light sensitivity if this eye problem is caused by corneal abrasions, conjunctivitis or scleritis.
* Wear Sunglasses: For people who have light sensitivity, wearing sunglasses can help with pain and discomfort by dimming light entering the eye.
### 1. Take a Rest
Taking a rest is a great way to treat light sensitivity at home as it allows the eyes to have a break from irritating light by closing the eyes. For full benefits, make sure to rest in a dark room where possible to escape light causing the sensitivity. You can also use a warm or cold compress over the eyes to further relax and treat discomfort or pain.
### 2. Use Eye Drops
Eye drops may be used to treat light sensitivity if this eye symptom is caused by corneal abrasions, conjunctivitis or scleritis. According to Drugs.com, there are different types of eye drops that can be used to treat light sensitivity, also known as photophobia, depending on the causes. These eye drops include artificial tears for dry eyes, antibiotics for bacterial infections, steroids for eye swelling, antivirals for viral infections and antifungals for fungal infections.
### 3. Wear Sunglasses
For people who have sensitivity to light, wearing sunglasses can help with pain and discomfort by dimming light entering the eye. Sunglasses can be tint, to protect the eyes from UV or there are [polarised sunglasses](https://www.oscarwylee.com.au/glasses/eye/polarised-lenses), to protect the eyes from glare. However, make sure not to wear sunglasses indoors as a study published in the Elsevier Survey of Ophthalmology in 2015 found that this can aggravate a person’s sensitivity to light as they are dark adapting their retinas.
### What are Other Serious Reasons for Sudden Light Sensitivity?
Sudden light sensitivity can be caused by serious medical conditions including herpes keratitis, encephalitis and meningitis. If you have the symptoms of any of the above symptoms, it is important to seek immediate medical attention. The serious causes of sudden light sensitivity are listed below.
* Herpes Keratitis: Herpes keratitis, also known as eye herpes, is an eye infection caused by the HSV-1 virus. Symptoms of Herpes keratitis can be a serious condition and lead to blindness if not treated.
* Encephalitis: Encephalitis is a serious condition in which the brain is inflamed. Symptoms of encephalitis can include confusion, seizures, changes in personality, speech or movement, weakness, and may also include light sensitivity according to Health Direct. It is essential to seek medical attention if you have symptoms of encephalitis as it can lead to permanent brain damage.
* Meningitis: Meningitis is a serious medical condition involving the inflammation of the tissue and membranes surrounding the brain and spinal cord. According to the World Health Organisation, meningitis can be fatal and it is important to seek immediate medical attention if you have symptoms of meningitis. According to the NHS, symptoms of meningitis can include high fever, cold hands, confusion, vomiting, a stiff neck, seizures, a rash and sensitivity to bright lights.
## When to Call Your Doctor About Sudden Light Sensitivity?
It is important to see a healthcare professional as soon as you develop unexpected light sensitivity so the cause can be determined and treatment can begin. If light sensitivity gets painful or severe, it is important to see a doctor. Whilst light sensitivity may be a minor symptom if caused by a dilated eye exam and chronic dry eyes, it may be a symptom of something more serious such as encephalitis or meningitis.
Find Your Local Oscar Wylee Store
Whether you need an eye test or new frames, Oscar Wylee has you covered. Come in and see the team at your nearest store for your eye-care needs.
Find a store
### What are the Possible Effects If Light Sensitivity is Not Treated Immediately?
The effects of not treating light sensitivity depend on the underlying cause of light sensitivity. It is important to treat conjunctivitis, which may cause light sensitivity, as eye damage may be caused by chronic, untreated conjunctivitis, according to Mount Sinai Health System.
## How to Prevent Sudden Light Sensitivity?
The ways to prevent light sensitivity revolve around keeping the eyes in good health to prevent the eye conditions that may cause this symptom. As light sensitivity can be caused by a range of different conditions, including medical and eye diseases, the best way to prevent light sensitivity is to maintain [eye health](https://www.oscarwylee.com.au/glasses/eye/health-tips-keeping-eyesight-healthy) to prevent these issues from occurring. The best ways to keep the eyes healthy include getting an eye test, practising good hygiene and protecting the eyes. The ways to prevent light sensitivity are listed below.
* Get an eye test: Getting an eye test is a way to keep the eyes healthy and prevent eye issues that may cause light sensitivity. An eye test will be conducted by an optometrist or eye care professional and can help detect potential problems within the eye.
* Practising good hygiene: Good hygiene can help keep the eyes healthy and prevent eye issues such as conjunctivitis, which may result in light sensitivity. Good hygiene includes not touching the eyes with unclean hands and properly cleaning contact lenses before and after use.
* Protecting the eyes: Protecting the eyes can help prevent eye issues that may cause light sensitivity. Protecting the eyes includes wearing protective eyewear to prevent eye injuries that may lead to light sensitivity such as corneal abrasions.
### Can Non-Prescription Glasses Prevent Sudden Light Sensitivity?
Non-prescription glasses may help to prevent eye issues that may cause light sensitivity, such as eye injuries. Injuries to the eye, such as corneal abrasions, may cause light sensitivity. Non-prescription protective glasses may help prevent eye injuries during activities such as gardening or working in conditions where there is debris. [Non-prescription glasses](https://www.oscarwylee.com.au/guides/lenses/non-prescription-glasses) such as sunglasses can be useful in the management of light sensitivity as they can shield the eyes from bright lights.
#### Should I Go to the Hospital After Experiencing Sudden Light Sensitivity?
It is essential to seek medical attention if you experience sudden light sensitivity. Depending on the cause of sudden light sensitivity and how serious it is, you may need to go to the hospital. If sudden light sensitivity is minor and the result of eye dilation or conditions such as conjunctivitis, this can usually be managed by your optometrist or doctor. If light sensitivity is severe and painful, and the result of a serious medical issue such as meningitis, it will require serious medical attention.
#### Can Eye Test Determine the Causes of Sudden Light Sensitivity?
Yes, an eye test may help to determine the cause of sudden light sensitivity. An [eye test](https://www.oscarwylee.com.au/glasses/eye/check-up) is a procedure carried out by an optometrist or other healthcare professionals that assesses the structures and functions of the eye and can diagnose vision issues and diseases, some of which may be the underlying cause of light sensitivity.
Read Sudden Light Sensitivity: Causes, Treatments and Prevention in other Oscar Wylee regions and their languages.
Australia   
[Australia](https://www.oscarwylee.com.au/glasses/eye/sudden-light-sensitivity)
New Zealand

[Canada](https://oscarwylee.ca/glasses/eye/sudden-light-sensitivity)
[Canadian French](https://oscarwylee.ca/fr/lunettes/oeil/sensibilite-soudaine-lumiere)
Major Health Funds Accepted At Oscar Wylee
Visit our team in-store for your eye care needs and your health fund may help cover some of the cost.
[Health funds](https://www.oscarwylee.com.au/health-funds.html)
Take care of your eyes at Oscar Wylee!
Book an eye test with one of our experienced optometrists and look after your eye health. Oscar Wylee eye tests are bulk billed for eligible Medicare cardholders.
[Book an eye test](https://www.oscarwylee.com.au/booking)