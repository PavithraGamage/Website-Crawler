# Source: https://www.oscarwylee.com.au/vs-laubman-and-pank

# Oscar Wylee vs Laubman &amp; Pank Glasses and Eyewear
Published on July 2nd, 2025
Updated on March 21st, 2025 
Oscar Wylee is an Australian founded eyewear company selling in-house designed glasses, first launching online in 2012. [Oscar Wylee](https://www.oscarwylee.com.au/) then branched into physical stores, with its first store opening in Sydney, Australia in 2015, eventually expanding to New Zealand in 2019 and Canada in 2021. Oscar Wylee now has over 130 stores across Australia, Canada and New Zealand. Laubman &amp; Pank is an eyewear and eye health brand that began in 1908 by business partners Carl Laubman and Harold Pank with the first store opening in Adelaide in South Australia. Both men were opticians and became highly regarded in their field, and travelled in rural areas in Australia to provide eye health services. Read on for the similarities, differences and characteristics of both notable eyewear companies.
Book an Eye Test With Oscar&nbsp;Wylee Today
Our highly trained optometrists are available to provide bulk billed eye tests to eligible Medicare card holders.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Distinctions](#distinctions) [Blue Light Blocking Lenses](#blue-light) [Products Range Differences](#range)
## What are the Distinctive Characteristics of Oscar Wylee and Laubman &amp; Pank?
Some distinctive characteristics of Oscar Wylee compared to Laubman &amp; Pank are their in-house developed glasses, international presence and free eye test for international students initiative. Oscar Wylee's glasses are all in-house developed. Incorporating both global and local inspiration as well as vintage and contemporary aesthetics, Oscar Wylee eyewear aims to appeal to a variety of consumers. This provides Oscar Wylee's glasses with a distinct individuality from more notable brands. Oscar Wylee stores can be found in Australia, New Zealand and Canada. This international presence makes Oscar Wylee a more known eyewear brand beyond Australia. Both Laubman &amp; Pank and Oscar Wylee accept bulk billing from Medicare and private health insurance. Oscar Wylee extends extra assistance to international students in Australia and New Zealand. If students buy a pair of Oscar Wylee glasses, then they can receive a free eye test on the same day.
Some distinctive characteristics of Laubman &amp; Pank compared to Oscar Wylee are that they sell branded glasses, contact lenses and multiple eye test packages. Specsavers offers a variety of branded eyewear, such as Prada, Vogue Eyewear and Ray-Ban. This can be favourable to customers who desire the reputation and distinct appeal of branded frames. Laubman &amp; Pank also have a range of contact lenses, with various types to choose from for those that prefer the convenience contact lenses can provide, such as easy wear during physical activity. Laubman &amp; Pank has multiple eye test packages available for customers to choose from. Laubman &amp; Pank have a standard eye test, the Essential, which includes a Digital Retinal Scan, the Essential+ using an Ultra Wide Digital Retinal Scan which reveals more of the retina and blood vessels compared to the normal retinal scan and the Essential Total Care Package encompassing tests, scans and screenings alongside an Optical Coherence Tomography (OCT). They also have a contact lens consultation available for contact wearers.
### What Stylistic Eyewear Options Does Oscar Wylee Offer Compared to Laubman &amp; Pank?
Some stylish eyewear options from Oscar Wylee include Serge Large, Heba, Aerin and Poppy. Read more about some of the stylish eyewear options at Oscar Wylee compared to Laubman &amp; Pank listed below.
* Serge Large: The Serge Large Frame is a bigger, bolder version of our classic Serge frame for an even larger statement accessory.
* Heba: Heba is a quirky round shape with a high nose bridge, providing an interesting and feminine look to any outfit.
* Aerin: Aerin, with a sleek stainless steel frame and rectangular shape is for those who want both intellectual and stylish eyewear.
* Poppy: Poppy is a playful frame in a classic shape, with stunning colourways that will add a beautiful pop of colour.
[](https://www.oscarwylee.com.au/heba-optical.html)
[Heba](https://www.oscarwylee.com.au/heba-optical.html)
$169    
Add to Cart
[Shop Heba](https://www.oscarwylee.com.au/heba-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/heba-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/heba-optical.html)
[](https://www.oscarwylee.com.au/aerin-optical.html)
[Aerin](https://www.oscarwylee.com.au/aerin-optical.html)
$169    
Add to Cart
[Shop Aerin](https://www.oscarwylee.com.au/aerin-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/aerin-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/aerin-optical.html)
[](https://www.oscarwylee.com.au/poppy-optical.html)
[Poppy](https://www.oscarwylee.com.au/poppy-optical.html)
$169    
Add to Cart
[Shop Poppy](https://www.oscarwylee.com.au/poppy-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/poppy-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/poppy-optical.html)
### Why Choose Oscar Wylee or Laubman &amp; Pank for Specialised Lenses?
Oscar Wylee and Laubman &amp; Pank both have specialised lens options to customise their glasses so customers can purchase eyewear that accommodates their everyday needs.
#### Oscar Wylee Specialised Lenses
Oscar Wylee does standard prescription and non-prescription frames. Oscar Wylee specialised lenses include extra thin, super thin and ultimate thin lens options alongside their standard lens to accommodate stronger prescriptions. These Oscar Wylee thin lenses come with a complimentary Basic Anti-Reflective coating. Oscar Wylee has a range of sunglasses for UV protection. Oscar Wylee has a Premium Anti-Reflective Lens Coating add-on that is also anti-static, scratch, and smudge resistant, while the Blue Light Filter reduces potentially harmful blue light from digital screens. Oscar Wylee also has Transitions® GEN S™ lenses available in store, smart lenses that automatically darken in the sun and quickly return to clear indoors.
#### Laubman &amp; Pank Specialised Lenses
Laubman &amp; Pank's specialised lenses include Premium-Thin, Superior-High Index, Ultimate -- Ultra High Index ​lens options alongside their standard lens to accommodate stronger prescriptions. Laubman &amp; Pank also have other innovative lens options such as the the Varilux® XR Series™ Progressive Lenses which are progressive lenses powered by AI, Eyezen® lenses that are single vision aimed to reduce digital eye strain, Transitions® GEN S™ lenses, Stellest® lenses to slow down myopia progression in children, polarised lenses, blue-violet light lenses, Panorama Plus Progressive Lenses and Sunfit Lenses.
### Why Choose Oscar Wylee or Laubman &amp; Pank for Blue Light Blocking Lenses?
Both Oscar Wylee and Laubman &amp; Pank offer [blue light blocking lenses](https://www.oscarwylee.com.au/glasses/blue-light/review). Oscar Wylee allows glasses wearers to add a blue light filter to any optical prescription up to 1.67 index, or to non-prescription glasses. The Oscar Wylee Blue Light Filter product includes a basic anti reflective coating. Laubman &amp; Pank have Blue-Violet Lenses by BlueGuard® that are designed for protection against UV and filtering blue-violet light. Other lenses Laubman &amp; Pank have such as the Eyezen® lenses, Transitions® GEN S™ lenses and Sunfit Lenses also have blue-violet light blocking properties.
#### Do Oscar Wylee or Laubman and Pank Offer Repairs, Adjustments, or Warranty Replacements for Glasses?
Yes, Oscar Wylee offers repairs, adjustments or warranty adjustments for glasses. Oscar Wylee customers can head into the store and be assisted by a retail member to repair their glasses. Oscar Wylee has a warranty period of 12 months. If there are production faults, such as material issues, defective frames or damage from the product's manufacturing, Oscar Wylee offers replacement or repair of your purchase, completely free of charge. However, charges may apply for items not covered under the 12-month warranty. Laubman &amp; Pank do ​​not offer repair services or spare parts. If their product is defective within 24 months of purchase, it can be replaced or refunded under the policy. For Change of Mind in-store purchases at Laubman &amp; Pank, you must present the product in 'as new' condition with proof of purchase within 30 calendar days.
### How Long Have Oscar Wylee and Laubman &amp; Pank Been in Business?
Oscar Wylee has been in business since 2012, beginning as an E-commerce store. Oscar Wylee's first physical store opened in Chatswood Interchange, NSW in Sydney, Australia in 2015. Laubman &amp; Pank was established in 1908 in Victoria Square, Adelaide.
### What Products and Services Does Oscar Wylee Offer?
Oscar Wylee provides prescription glasses, non-prescription glasses, and sunglasses. Services at Oscar Wylee includes bulk billed eye tests and a lifetime guarantee of adjustments or professional cleaning for Oscar Wylee glasses.
#### Does Oscar Wylee Have In-House Eye Specialists?
No, Oscar Wylee does not have in-house [eye specialists](https://www.oscarwylee.com.au/eye-health/optometrist-vs-ophthalmologist.html) such as ophthalmologists. However, Oscar Wylee does have optometrists who conduct extensive eye tests, diagnose eye problems and write prescriptions. These Oscar Wylee optometrists can refer you to an ophthalmologist for more serious eye issues. Oscar Wylee also has retail staff at their stores that provide stylistic assistance to customers so they can pick out fashionable glasses that complement their face.
#### Can you Order Prescription Glasses Online from Oscar Wylee?
Yes, you can order prescription glasses online from Oscar Wylee. This can be done directly on the Oscar Wylee website during checkout. You can provide them with your optometrist's contact information and Oscar Wylee will get in touch with them, upload a prescription copy, or click "send later" and send Oscar Wylee a copy via email. These can be delivered to your doorstep or collected in-store.
#### How to Book an Eye Test with Oscar Wylee in Australia?
To find an Oscar Wylee Optometrist in Australia is simple. All there is to do is go to the locations page, enter your postcode, select the most convenient location and check the opening hours. Read more on these steps on how to find an Oscar Wylee Optometrist in Australia below.
1. Go to the Locations Page: Go to the locations page on the Oscar Wylee website. This can be found at the very top of the website or at the footer under the heading 'Company.'
2. Enter your Postcode: Enter your postcode in the search bar to find the nearest Oscar Wylee optometrist to your home or desired location.
3. Select the Most Convenient Location: Select the most convenient Oscar Wylee location once you have typed in your postcode.
4. Check the Opening Hours: Check the opening hours and address to find the perfect time to visit, and directions on how to get there.
Visit our team in-store!
Come and say hi to our friendly in-store team, who can help you with your eye care needs.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
## What Products and Services does Laubman &amp; Pank Offer?
Laubman &amp; Pank products encompass glasses, sunglasses and contacts lenses. Laubman &amp; Pank services encompass eye test packages such as standard eye test, the Essential which includes a Digital Retinal Scan, the Essential+ using an Ultra Wide Digital Retinal Scan which reveals more of the retina and blood vessels compared to the normal retinal scan and the Essential Total Care Package encompassing tests, scans and screenings alongside an Optical Coherence Tomography (OCT). They also have a contact lens consultation available for contact wearers.
### What Brands Does Laubman and Pank Carry?
Laubman &amp; Pank carry a variety of brands such as Oakley, Versace, Tiffany and Co, and Ray-Ban and Armani Exchange to name a few.
#### Does Laubman &amp; Pank Offer Access to Optometrists or Prescription Validation?
Yes, Laubman and Pank do offer access to optometrists that can write prescriptions. Laubman and Pank provide bulk billed eye tests for all eligible Medicare cardholders for the detection of eye diseases and general eye health maintenance.
## How Do the Product Ranges of Oscar Wylee and Laubman &amp; Pank Differ?
The product ranges of Oscar Wylee and Laubman &amp; Pank differ through their brands offered, collections, and eye test offerings. The product range differences between Oscar Wylee and Laubman and Pank are listed below.
| Category | Oscar Wylee | Laubman &amp; Pank |
| --- | --- | --- |
| Brands offered | Oscar Wylee solely sells their own in-house designed eyewear. | Laubman &amp; Pank sell a variety of notable eyewear brands. |
| Collections | Oscar Wylee releases multiple glasses' collections every year based on a common material or theme the range has such as the Memory Metal collection or Together Collection which focuses on individuality and personal expression. | Laubman &amp; Pank does not release any eyewear collections. |
| Eye Tests | Oscar Wylee offers eye tests for all ages and demographics. | Laubman &amp; Pank offer specific eye test packages such as standard eye test, the Essential, the Essential+ and the Essential Total Care Package. |
### Where Can You Visit Oscar Wylee Physical Stores?
You can visit Oscar Wylee's [physical stores](https://www.oscarwylee.com.au/locations/full-store-list.html) across Australia, New Zealand and Canada, where there are stores across multiple states and provinces.
#### Can Oscar Wylee Ship Their Products Globally?
No, Oscar Wylee does not ship it's products globally. However, Oscar Wylee customers are eligible for domestic [shipping](https://www.oscarwylee.com.au/shipping.html) if they live in Australia or New Zealand. Canadian customers will have to collect their glasses order in-store. In Australia, all Oscar Wylee domestic shipping orders are free.
#### Where does Laubman &amp; Pank Ship From And To?
Laubman &amp; Pank does not do shipping. Customers can purchase glasses from one of the Laubman &amp; Pank stores located in Australia, specifically in Queensland, South Australia and Western Australia as of June 2025.
#### Can Laubman &amp; Pank Ship Their Products Globally?
No, Laubman &amp; Pank do not ship their products globally.
#### Does Oscar Wylee or Laubman &amp; Pank Accept Medicare?
Yes, both Oscar Wylee and EyeQ Optometrists accept Medicare. Oscar Wylee does Medicare bulk billed eye tests for those with a valid medicare card. Laubman &amp; Park accept Medicare for eye tests. The standard eye test is bulk billed; however, the eye test packages are not and incur a gap payment as of July 2025.
#### Does Oscar Wylee or Laubman &amp; Pank Accept Health Funds for Glasses?
Yes, both Oscar Wylee and Laubman &amp; Pank accept health insurance for glasses. Oscar Wylee accepts all major health funds, so you can use your health fund to cover some of the cost when purchasing [prescription glasses](https://www.oscarwylee.com.au/glasses/eye/prescription-glasses-lenses) and lenses. Customers can bring their membership details or health fund card to their next appointment, and our staff can help with checking what benefits you have access to and can make a claim on the spot. Laubman &amp; Pank has partnerships with over 40 health funds, which include major ones such as NIB, Medibank and HBF and accepts all Australian health funds for glasses.
## What are the Main Alternatives to Laubman &amp; Pank?
The main alternatives to Laubman &amp; Pank include Oscar Wylee, EyeBuyDirect, OPSM, 1001 Optometry, Bailey Nelson, Specsavers Quay Australia, Vision Direct, LeSpecs and EyeQ. The following are the main alternatives to Laubman &amp; Pank, along with their distinguishing characteristics listed below.
* Oscar Wylee: [Oscar Wylee](https://www.oscarwylee.com.au/) creates solely in-house glasses for distinguished eyewear that are stylish, affordable, and suited to every demographic. [Oscar Wylee](https://www.oscarwylee.com.au/) also offers a free eye test for international students when they purchase any pair of glasses on the same day.
* EyeBuyDirect: [EyeBuyDirect](https://www.oscarwylee.com.au/vs-eyebuydirect) is a budget-friendly eyewear brand that is solely based online, with home try-on options for many frame styles.
* OPSM: [OPSM](https://www.oscarwylee.com.au/vs-opsm) is an Australian eyewear company with a range of glasses, lenses and optical technology. OPSM also has a global eyecare charity, OneSight.
* 1001 Optometry: [1001 Optometry](https://www.oscarwylee.com.au/vs-1001-optometry) offers many brands of glasses, sunglasses and contact lenses. Some of their notable branded glasses include Prada and Gucci.
* Bailey Nelson: [Bailey Nelson's](https://www.oscarwylee.com.au/vs-bailey-nelson) wide glasses range are designed in Australia. They also have accessories such as clip-on's which are polarised lenses that can be attached to the front of prescription glasses using a simple clip mechanism.
* Specsavers: [Specsavers](https://www.oscarwylee.com.au/vs-specsavers) is an English eyewear retailer selling notable designer brands and popular glasses collaborations alongside optometry and audiology services.
* Vision Direct: [Vision Direct](https://www.oscarwylee.com.au/vs-vision-direct) is an Australian eyewear company focused on affordable and accessible glasses.
* Quay: [Quay](https://www.oscarwylee.com.au/vs-quay) is an Australian sunglasses brand that is known for trendy sunglasses often worn at live music events and festivals.
* Le Specs: [Le Specs](https://www.oscarwylee.com.au/vs-le-specs) has a wide range of sunglasses, all from their own brand for trendy accessories perfect for a sunny day.
* EyeQ: [EyeQ](https://www.oscarwylee.com.au/vs-eyeq) is an Australian optometrist brand selling glasses, notable for their knowledgeable optometrist team and eyecare services.
Major Health Funds Accepted&nbsp;In-store
For the purchase of frames and lenses, use your private health fund insurance to minimise how much you pay from your own pocket.
[Explore health funds](https://www.oscarwylee.com.au/health-funds.html)
Are you due for an eye test?
At Oscar Wylee we offer bulk billed eye tests for eligible medicare card holders.
[Book an eye test](https://www.oscarwylee.com.au/booking)