# Source: https://www.oscarwylee.com.au/nick-optical.html

# Nick
1
## Frame Design of Nick Glasses
The frame design of Oscar Wylee’s Nick glasses is characterised by their rectangle shape, high nose bridge, and bio acetate frame. Nick is a versatile unisex glasses frame that you can rely on, day to night.
$169    
In stock
Only %1 left
2 pairs from $199
Discount auto-applied at checkout
3 pairs from $249
Discount auto-applied at checkout
Qty
Add to cart
Book an eye test
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
excluding prescription lenses
## About Nick Frames
Nick is a classic pair with its striking rectangular frame. No matter the occasion, Nick is a reminder to stay present amongst your surroundings.
| Frame fit | Measurements |
| --- | --- |
| MEDIUM | 55 - 17 - 145 |
These measurements mean lens width, bridge, and temple length in millimetres (mm). They can be found on the inside of the temple arm. If you already have a pair that you like, you can compare it to these measurements.
### Made from Bio Acetate
Oscar Wylee’s Nick frame is a unisex rectangle glasses frame that is perfect for those with round and oval face shapes. The Nick frame is a sleek, modern frame that can be worn every day. The main specs of Oscar Wylee’s Nick glasses frame, including dimensions, shape, materials, lenses, nose fit, and hinges, are listed below.
| Nick Frame Features | Nick Frame Description | Dimensions | Shape | Materials | Lenses | Nose Fit | Hinges |
| --- | --- | --- | --- | --- | --- | --- | --- |
| The dimensions of the Nick frame are measured in millimetres (mm) and are 55 - 17 - 145, meaning the lens width is 55 mm, the bridge is 17 mm, and the temple length is 145 mm. |
| Nick is a rectangle shape, well-suited to medium faces. |
| Nick is made from bio acetate. |
| The lenses that can be used in the Nick frame include optical lenses, such as single-vision and multifocal, and non-prescription lenses, which are plain and can have a filter, such as a blue-light filter applied. |
| The nose fit for Nick is a high nose bridge fit. |
| The hinges in Nick are spring hinges, which are more flexible than other types of hinges and can extend past 90 degrees. |
Show All
### What Inspired the Frame Design of Oscar Wylee’s Nick Glasses?
The Oscar Wylee Nick frame design was inspired by current fashion trends, as rectangle shapes are often in fashion. A rectangle glasses shape is timeless; it remains popular throughout the decades while other trends come and go.
## What to Know About Oscar Wylee’s Nick Glasses?
There are many aspects of the Oscar Wylee Nick frames that customers should know about to decide whether this is the right frame for them. The Nick frame is a unisex rectangle-shaped frame. Oscar Wylee’s Nick frame is suitable for many face shapes, but particularly compatible with round and oval face shapes. The Nick frame’s simple design makes them fashionable all year round. Nick features the standard [parts of glasses](https://www.oscarwylee.com.au/glasses/eye/part-of-glasses), such as a rim, temples, lenses, spring hinges, and a high nose bridge fit.
### What are the Types of Temple Tips or Earpieces Included with Oscar Wylee’s Nick Glasses?
The type of temple tips or earpieces included in Oscar Wylee’s Nick Glasses are made from bio acetate.
### What Type of Nose Bridge do Oscar Wylee’s Nick Glasses Have?
The type of nose bridge included in Oscar Wylee’s Nick frame is a high nose bridge fit.
### What Type of Nose Pads are Included with Oscar Wylee’s Nick Glasses?
Oscar Wylee’s Nick frame does not include adjustable silicone nose pads.
### What Type of Lenses do Oscar Wylee’s Nick Glasses Have?
The type of lenses that typically come with the Oscar Wylee Nick [glasses frame](https://www.oscarwylee.com.au/glasses.html) are optical lenses. Optical lenses are glasses lenses that have a prescription within the lens to help correct vision issues such as myopia, hyperopia, and astigmatism. Nick can also come with non-prescription lenses, with add-ons such as a blue light filter. Nick frames can be customised into sunglasses in-store or online with add-on tints or polarisation.
### What Material is Used for the Rim of Oscar Wylee’s Nick Glasses?
The material used for the rim of Oscar Wylee’s Nick glasses frames is bio acetate. The rim refers to the part of a glasses frame that holds the lenses.
### What Type of Hinges are Included with Oscar Wylee’s Nick Glasses?
The type of hinges included with Oscar Wylee’s Nick frames are spring hinges. A spring hinge in a glasses frame refers to hinges that are more flexible than normal hinges and can go slightly beyond 90 degrees. Spring hinges can provide a closer fit to the face.
## What Face Types are Most Suitable for Oscar Wylee’s Nick Glasses?
The face types that are most suitable for Oscar Wylee’s Nick frame are round and oval face types. The Nick frame is a rectangle shape, meaning that it complements the structure of round and oval faces particularly well. The rectangle Nick frames help balance the features of a [round face shape](https://www.oscarwylee.com.au/glasses/face-shapes/round) and an [oval face shape](https://www.oscarwylee.com.au/glasses/face-shapes/oval), bringing the eyes and brows forward in a flattering way. Although there are many [glasses for face shapes](https://www.oscarwylee.com.au/glasses/face-shapes) that may be considered more aesthetically suitable, it is important that people also choose frames that make them feel most comfortable and represent their personal style.
## What Size Options are Available for Oscar Wylee’s Nick Glasses?
The size options available for Oscar Wylee’s Nick frame are a medium-fit frame across all colours.
## What Materials are Used to Create Oscar Wylee’s Nick Glasses?
The primary material used to create the Oscar Wylee Nick frame is bio acetate. Bio acetate is predominantly made from renewable plant matter such as wood pulp, for a more eco-conscious foundation.
## What’s Included
## OW Case &amp; Cloth
Protective Case and Lens Cloth
Our high-quality glasses case and lens cloth are included with every purchase of an Oscar Wylee frame. The stylish, magnetic case is made from a hard shell. This sturdy and durable material keeps your glasses protected and safe, wherever you go. Ensure your lenses are clean and scratch-free with our OW microfibre cloth, specifically designed to ensure you have comfortable vision through your lenses.
Oscar Wylee offers:
* Free Shipping for Australian Orders
* 1 Year Warranty on frames and lenses
* Scratch resistance lens coating on all prescriptions
* UV-proof coating on all prescriptions
Health fund rebate: Once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. Learn more about [health funds](https://www.oscarwylee.com.au/health-funds.html).
## Make and Materials
Eco-consciousness meets durability with bio-acetate. Replacing unbiodegradable plasticisers with plant based alternatives, bio-acetate allows a biodegradable lens frame, leaving a reduced carbon footprint on the environment.The frames then go through cleaning and strict quality control, and many pairs of crafting hands to be hand-assembled and polished. After your frames have gone through the production process, they are individually examined and&nbsp;packed before making their way to you!
## Warranty Information
### Warranty Information
Task Monitoring
Task Monitoring
100%
10
A12
### Warranty Information
Oscar Wylee provides a 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects. We will repair or replace faulty or defective frames or lenses free of charge for warranty claims made within 1 year of the delivery. We also offer repairs or replacement for problems experienced with vision during everyday use for claims made within 30 days of delivery. If the same product has been discontinued or is no longer available, then we may offer an exchange for a similar product or a refund.
### Warranty Information
Oscar Wylee provides a 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects. We will repair or replace faulty or defective frames or lenses free of charge for warranty claims made within 1 year of the delivery. We also offer repairs or replacement for problems experienced with vision during everyday use for claims made within 30 days of delivery. If the same product has been discontinued or is no longer available, then we may offer an exchange for a similar product or a refund.
### Warranty Information
Oscar Wylee provides a 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects. We will repair or replace faulty or defective frames or lenses free of charge for warranty claims made within 1 year of the delivery. We also offer repairs or replacement for problems experienced with vision during everyday use for claims made within 30 days of delivery. If the same product has been discontinued or is no longer available, then we may offer an exchange for a similar product or a refund.
A12                             
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Find a Store Location](https://www.oscarwylee.com.au/locations/full-store-list.html)