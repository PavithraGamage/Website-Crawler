# Source: https://www.oscarwylee.com.au/locations/optometrist-moonee-ponds.html

# Optometrist Moonee Ponds
Moonee Ponds CentralGround Level, Shop 7914-16 Hall StreetMoonee Ponds VIC 3039
* Opposite Witchery
Opening hours
Monday9:00am - 5:30pm
Tuesday9:00am - 5:30pm
Wednesday9:00am - 5:30pm
Thursday9:00am - 7:00pm
Friday9:00am - 7:00pm
Saturday9:00am - 5:00pm
Sunday10:00am - 5:00pm
*Store hours reflect local standard trading hours and exclude public holidays
[Visit our Moonee Ponds Google Business page for directions, reviews, and updates.](https://g.page/r/CZlOvwjAZMx9EBM)
Book Appointment
[Call us: (03) 8528 6288](tel:(03) 8528 6288)
[Leave a Review!](https://g.page/r/CZlOvwjAZMx9EBM/review)
Our Reviews
Amanda Hughes
1 week ago
Excellent customer service and helpful advice would recommend highly
Peter Scougall
1 week ago
I attended an eye test at the Moonee Ponds store. If i could give a 6 star rating to Runa i would.  ...She was patient, attentive and professional and very knowledgeable in offering advice and guidance.  I have had several eye tests over the years and Runa was undoubtedly the best!  Peter
See more
Devika Judd
2 weeks ago
Kindness and compassionate care, highly recommended
u b
2 weeks ago
It was a good overall experience. Everyone was friendly but one staff member was too friendly with m...y boyfriend, kept looking at him when it was my appointment we were there for.
But overall still a good team despite her being alone on the front desk.
See more
Ingrid Thomas
1 month ago
Friendly professional service with a fabulous range of glasses to choose from. Far superior to Spec ...Savers, service and selection.
See more
A
1 month ago
Liam B
1 month ago
Great service, knowledge and attention to detail by the staff working on the 15th of July 2026. Appr...eciate how easy it was getting some new pairs sorted with a new prescription. Was a very warming experience thank you.
See more
Nicolás Muñoz
1 month ago
I was so enchanted with the professionalism of John. He is a great optometrist and a very careful an...d lovely person. Hope to see him again.
See more
Deepak Manchikanti
1 month ago
Extremely knowledgeable optometrist and the staff went above and beyond to be helpful. Couldn't reco...mmend more.
See more
Barbara Odachowski
1 month ago
Friendly, efficient &amp; knowledgeable. Thank you!
Jackie Boyle
1 month ago
Karima was excellent - so knowledgeable and amazing to talk to!
Jenny Thomson
2 months ago
Fantastic optometrist really reccomend
Bruno Braz
2 months ago
Alana Hunter
2 months ago
I love Oscar Wylees variety of glasses, but honestly the staff at this particular store were a stand... out! Very friendly and helpful, it made for such a good eye test and shopping experience.
See more
Murat AKSAKAL
2 months ago
Philip Bickley
2 months ago
Excellent service staff were polite and professional and felt totally relaxed during the eye examina...tion. The sales person was honest in terms of feedback in terms of the frames l was selecting and nothing was too much trouble
See more
Johan Campos
2 months ago
Shonali Samuel
3 months ago
Lovely, caring staff here. Thank you so much Karima (and Casey) for your gentle manner and thorough ...help today ????
See more
Dominic Cannata
3 months ago
Tamer Antakly
3 months ago
I really satisfied the care I had when I returned again to Oscar Wylee Moonee Ponds to discuss a sec...ond opinion I had with another optometry provider.
The optometrist Karima listened to me and answered every question I had and reassessed my vision and explained the outcome and future progress possibilities.
The optometrist also discussed possible solutions.
The I also moved out to the other staff who were also professional and finalized the needed work after I had chosen my glasses. Really appreciate the care I had.
See more
Carolyn Flett
3 months ago
It was a great experience. I was advised of the process and my options. The staff were lovely.
Arta Azel
3 months ago
Great customer service with friendly and helpful staff.
Cherrie Baker
3 months ago
Efficient, professional and helpful!
Salvatore Giuliano
3 months ago
Very Good
Miles Primrose
3 months ago
I went there today as another place did not get my script correct
I was looked after by Mel and John... and they were very helpfull
I will be a return customer
See more
Heather Ettles
3 months ago
My 8 year old got her eyes tested today, we were in and out in less than 20 mins, the process was se...amless! All her questions (lots of questions) were answered sincerely. The results were discussed, and all my concerns listened to. Would recommend anytime!
See more
Mia Ellis
3 months ago
the team were super helpful and really informative. I felt very looked after! x
Senay Celik
3 months ago
Helen Pouliassis
3 months ago
Informative and thorough
Orla-Eoghan Joint Email
3 months ago
Cherie Campbell
3 months ago
Lovely staff, very reasonable prices, would definitely recommend
Melissa Green
4 months ago
Caroline D
4 months ago
The team here were lovely, they were on time, efficient, personable and helpful without ever making ...me feel pressured. Equally importantly, they had a much better selection of glasses styles and colors than other providers, which is why I chose Oscar Wylee this time around.
See more
Carolyn R
4 months ago
Just been to the Moonee Ponds store, Megan was lovely, she helped me with the issue of my glasses an...d because of my job I needed a quick fix, obviously it was done because they had a spare. Megan's customer service was top notch.
See more
Dina De Nardo
4 months ago
Johnathan and his team are absolutely amazing.
Very friendly, helpful and professional.
They took th...e time to discuss the best options for my Dad who is elderly.
Thank you so much
See more
Rodney Bradshaw
5 months ago
Good day I meet the best young lady ever in customer service and it was Monique I came in to get gla...sses adjusted, but cause she is professional she saw they wert getting fixed broken ! Did not even know that next thing I know Monique is coming out with a fantastic black pair she said do you want these I said yes pls ! Are you sure Monique was so happy to change for me at no cost to me , I just about cried my eyes out it was one of the loveliest things that’s happened to me in a long time ! MOnique you saved me so much money and time thank thank you you as your the best Oscar Wyler this is called customer service and it 500% what this World is made of , I believe she part time make her full time and I will bring the family in ! Thank you Monique your the best
See more
Anoop R. S.
5 months ago
Julie Wright
5 months ago
Great service and communication. John is very thorough and caring.
Chelody
5 months ago
The optometrist was very through and I felt quite comfortable.
kalrav patel
5 months ago
Outstanding as always
John Cristallini
5 months ago
Very polite and professional recently assisted me with eye emergency!! John the optometrist was very... helpful along with the receptionist….
See more
Susan Newbold
6 months ago
Tongkang Lee
6 months ago
Erin Grace Donnarumma
6 months ago
The optometrist was very personable, skilled and professional. It was a very positive experience.
Sudhanshu Singh
6 months ago
Very helpful and supportive staff. Great experience
Nooy
6 months ago
ayşe gürkan
6 months ago
Great
Andrew Wurster
6 months ago
Very thorough and well explained - made me feel comfortable and supported
Carol Tootell
6 months ago
This was my first time visiting an Oscar Wylee store the service was Excellent, the friendly staff m...ember, made my experience a very positive visit.The Information following my visit through emails has been very impressive.
Thank you for the wonderful help picking  a new set of glasses,also.
See more
Elsa Mulleda-Rudd
6 months ago
The staffs are friendly and professional. They were able to examine my son's eyes well. Highly recom...mended.
See more
## Find an Optometrist in Moonee Ponds With Oscar Wylee
Oscar Wylee Moonee Ponds is located between Peter Alexander and Trenery in Moonee Ponds Central Shopping Centre. With an optometrist on site to perform Medicare bulk billed eye tests, you can have your eye health checked and update your prescription. Our friendly retail staff will also help you find your new favourite pair of glasses - all on the same day! 
Our store is a 4-minute walk from Moonee Ponds Train Station with trams and buses also available nearby for easy travel. There is also parking, free for up to 2 hours at the centre. Once here, why not enjoy the local area? Moonee Ponds boasts a selection of nice cafes, and the centre is also a short walk from Queens Park, perfect for picnics. If you live close to the Aberfeldie or Ascot Vale areas and want to be looked after by passionate and experienced optometrists near you, then come and see us at Oscar Wylee Moonee Ponds.        
Meet Our Team
* Optometrist
B. Vis Sci
M.Optometry
Therapeutically Endorsed
* Store Manager
Our Services
* Bulk Billed Eye Examinations
* Professional Frame Styling
* Frame Adjustments and Repairs
Show All
## Find an Optometrist in Moonee Ponds, Victoria for an Eye Health Test
If you are in need of an eye health test, you can find an Oscar Wylee optometrist in Moonee Ponds, Victoria. Our Oscar Wylee optometrists are available in-store at Moonee Ponds Central to provide eye tests at a bulk billed price, for those eligible under Australia’s Medicare system. Our eye testing services include vision testing and the detection of eye diseases. Our Moonee Ponds optometrists can also work with an ophthalmologist, also known as an eye doctor, for the management and treatment of complex eye issues. The average price range for an optometrist or other eye care services in Moonee Ponds, Victoria can vary depending on factors such as the patient’s age and visual needs.
Oscar Wylee Moonee Ponds is also home to our dedicated and passionate retail staff, including our optical dispensers, who are available to help customers shop for new eyewear from our wide stylish range. From prescription glasses to prescription sunglasses and non-prescription eyewear, our staff will make sure customers find the frame that is perfect for them. If you are in need of an eye health test in Moonee Ponds, Victoria, or want to purchase some new frames, visit our Oscar Wylee glasses store where our dedicated team will take care of you!
## How to Find an Optometrist in Moonee Ponds, Victoria?
To find an optometrist in Moonee Ponds, Victoria you can take certain steps that can help make it easier for you such as searching online, assessing the store’s opening hours and finding the directions to your chosen location. The steps on how to find an optometrist in Moonee Ponds, Victoria are listed below.
1. Search online using the phrase, optometrist near me in Moonee Ponds. This can also be done here on the website via our locations page.
2. Click on the Oscar Wylee link, which will take you directly to our Moonee Ponds optometrist store page.
3. See the store’s opening hours and where the store is located specifically.
4. Use the Moonee Ponds Google Business page link located under store hours to see the directions on how to get to the store.
You can also find an optometrist in Moonee Ponds, Victoria by searching the keywords optometrist near me. If you have locations enabled on your smartphone and you’re in the Moonee Ponds, Victoria area, our Moonee Ponds store page should appear easily for you to click on.
### Is it Hard to Get an Eye Appointment in Moonee Ponds, Victoria?
No, it is not hard to get an eye appointment in Moonee Ponds. You can easily book an appointment to see an Oscar Wylee optometrist in Moonee Ponds, Victoria right here on this page. At Oscar Wylee we have highly qualified optometrists available for bulk billed eye appointments, which can be booked online or in-store.
#### How to Compare Optometrists in Moonee Ponds, Victoria to Each Other?
To compare optometrists in Moonee Ponds, Victoria, you can use factors such as eye tests offered, health fund coverage, lens types and add-ons and eyewear offered. To take care of your vision and eye health, it is important to receive an eye test at least once every two years. There are different types of tests that can be performed in an eye test and not all optometrists may offer the same tests. Health funds can be used to help cover some of the cost of your frames and lenses. To find out if your health fund is accepted at an optometrist in Moonee Ponds, Victoria visit their website. In the case of Oscar Wylee, we accept all major health funds and provide on-the-spot claims in-store. There are many different lens options available for prescription glasses such as single-vision, multifocal and high-index lenses. Most optometrists in Moonee Ponds, Victoria will offer these lenses although it is good to make sure. There are also lens add-ons available to enhance your glasses such as anti-reflective and blue light filters. Finally, if you are looking to purchase a pair of glasses after your eye test, you can compare the different styles and colours you are interested in from the optometrists in Moonee Ponds, Victoria. Oscar Wylee offers a wide range of frames with vintage and modern inspirations in bold colours and subtle designs.
#### How to Find an Eyeglasses Shop in Moonee Ponds, Victoria?
To find a glasses store in Moonee Ponds, Victoria you can try to follow these simple steps including searching online, selecting a convenient location and looking at their health insurance policies. The steps on how to find a glasses store in Moonee Ponds, Victoria are listed below.
1. Search online using the phrase, glasses store in Moonee Ponds, Victoria. This will provide you with various options for glasses stores in the whole Moonee Ponds, Victoria area.
2. Select a glasses store that is most convenient for you to travel to.
3. Click the link to find out more information such as opening hours, exact location and directions to the glasses store in Moonee Ponds.
4. Read their health insurance policies to ensure you know what health benefits you can access.
Our Oscar Wylee glasses store in Moonee Ponds, Victoria offers primary eye care services such as comprehensive eye tests as well as other services performed by an optometrist and offers prescription and non-prescription eyewear.
##### Is it Possible to Purchase Prescribed Sunglasses in Moonee Ponds, Victoria Without Seeing an Optometrist?
Yes and no, it is possible to [purchase prescribed sunglasses](https://www.oscarwylee.com.au/sunglasses.html) in Moonee Ponds, Victoria without seeing an optometrist if you already have a prescription that has not expired. If your prescription is expired, you can book an eye test to receive an updated or new prescription which will require you to see an optometrist. This will ensure your prescription sunglasses are appropriate for your visual needs.
## Where is the Oscar Wylee Moonee Ponds, Victoria Optometrist Located?
The Oscar Wylee Moonee Ponds optometrist is located on the ground level of the Moonee Ponds Central Shopping Centre. Moonee Ponds Central Shopping Centre can be found on Hall Street, in Moonee Ponds, Victoria.
### What is the Phone Number of Oscar Wylee Moonee Ponds, Victoria Optometrist Store?
The phone number for our Oscar Wylee Moonee Ponds, Victoria optometrist store is (03) 8528 6288. Our Oscar Wylee Moonee Ponds, Victoria store is open, and our staff are available to be contacted between 9 am and 5.30 pm from Monday to Wednesday, 9 am to 7 pm on Thursdays and Fridays, 9 am to 5 pm on Saturdays and 10 am to 5 pm on Sundays.
### What are the Reviews for Oscar Wylee Moonee Ponds, Victoria Optometrist?
The customer reviews for our Oscar Wylee Moonee Ponds, Victoria optometrist, can be found here on the website as well as online when you search for Oscar Wylee Moonee Ponds optometrist. The reviews for our Oscar Wylee Moonee Ponds optometrist are listed below.
* Diablo Nash:  From the customer service to the quality of the product, OW is my new prescription glasses provider. I’ve tried two other companies previously and Oscar Wylee are by far the best. So happy 11 out of 10.
* Karen Holden:  Helpful staff, friendly and honest advice on glasses, frames and options. Optical dispenser is also friendly and efficient with advice. Happy to go back, would recommend.
* Deborah Devereaux:  Super easy, friendly staff, with a nice range of frames to choose from. Eye test was quick and easy, was done and dusted within 30 mins.
Rebecca Narayan: 
Best and most comfortable eye test I have had so far. Staff were quick and very friendly.
Choosing my glasses was a breeze as I was left free to choose and not forced into getting
designs that I didn’t like or were expensive. I would definitely recommend people to go and
visit them.

#### What Treatments or Eye Care Processes are Done in the Oscar Wylee Moonee Ponds, Victoria Optometrist Location?
The treatments or eye care processes done in the Oscar Wylee Moonee Ponds, Victoria optometrist location include a tonometry test, a slit lamp exam and a refraction test. Additional tests that may also be performed can include a dilated fundus exam. The treatments or eye-care processes that are done in the Oscar Wylee Moonee Ponds optometrist location are listed below.
* A Tonometry Test: An optometrist or optical dispenser will conduct a tonometry test which involves the use of a machine that will release small puffs of air into your eyes. This will assist with measuring pressure in the eye.
A Digital Photograph: An optometrist or optical dispenser
may take a digital photograph of your eye which can be kept on
record to use in future appointments to evaluate any changes to
your eye.

* Slit Lamp Test: A slit lamp test can be used to evaluate your eye health, by examining your cornea and iris which are the anterior and posterior of the eye.
* Refraction Test: During a refraction test, an optometrist will have you view an image through different lenses and ask you to confirm which helps you see the image clearer.
Visual Field Test: A visual field test can assist with
assessing your peripheral vision, which may be beneficial for
identifying any signs of glaucoma.

* Dilated Fundus Exam: A dilated fundus exam can help an optometrist assess your health in more detail by getting a clear view of the retina. This test is typically carried out for patients with diabetes and those who may be at risk of developing retinal damage.
## How Many Optometrists Exist in Moonee Ponds, Victoria?
There are many optometrists that exist in Moonee Ponds, Victoria including Oscar Wylee. The amount of optometrists available in an area will typically depend on the population and the eye care needs of those in the area. At Oscar Wylee Moonee Ponds, Victoria, our team is passionate about providing our customers with high-quality, dedicated eye care services. Our optometrists are available to provide bulk billed eye tests with our dedicated optometrists, prescription updates and new frames. If you are looking for an optometrist in Moonee Ponds, Victoria, Oscar Wylee is available to provide all your eye care and eyewear needs.
### What are the Other Closest Optometrist Locations to Moonee Ponds, Victoria in Australia?
The closest Oscar Wylee optometrist locations to Moonee Ponds, Victoria in Australia are Doncaster, Northland and Melbourne Central. The closest optometrist locations to Moonee Ponds, Victoria are listed below.
* Doncaster:  Doncaster is a suburb around 23 km away from Moonee Ponds which is home to several optometrists including Oscar Wylee. [Oscar Wylee Doncaster](https://www.oscarwylee.com.au/locations/optometrist-doncaster.html) can be found in Doncaster Westfield where our team provides eye tests, new prescriptions and eye care advice.
* Northland:  Northland is a shopping centre located in Preston, Victoria approximately 13.5 km away from Moonee Ponds. [Oscar Wylee Northland](https://www.oscarwylee.com.au/locations/optometrist-northland.html) is located on the ground level of the shopping centre where our optometrists can provide Medicare bulk billed eye tests.
* Melbourne Central:  Melbourne Central is a shopping centre approximately 8 km away from Moonee Ponds where you can find optometry providers including Oscar Wylee. [Oscar Wylee Melbourne Central](https://www.oscarwylee.com.au/locations/optometrist-melbourne-central.html) is located on the ground floor of the shopping centre, where our team is available to provide services such as eye tests and prescription updates.
### Optometrist Bulk Billed Eye Tests
At our Oscar Wylee eyeglasses shop at Moonee Ponds, our optometrists are passionate about providing our customers with high-quality and affordable eye care. Oscar Wylee Moonee Ponds optometrists offer a range of eye care processes including Medicare bulk billed eye health tests which include vision assessment and examining the eyes for detection of possible eye diseases and conditions. For some of the best optometrists in Moonee Ponds, Australia, visit Oscar Wylee Moonee Ponds Central Shopping Centre.
### Leading Health Funds Accepted at Oscar Wylee
Bring your valid health fund card to Oscar Wylee Moonee Ponds and our team can help process your health fund claims and answer any questions about eligibility. Visit Oscar Wylee Moonee Ponds for eye care services such as eye tests and new prescription frames, and your health fund may help cover some of the cost.
### Expert Frame Advice with Oscar Wylee Moonee Ponds
Our Oscar Wylee team at Moonee Ponds are trained to help our customers find the glasses that are perfect for them. Oscar Wylee’s collection has a range of sizes, styles and colours, suitable for any face shape or size. No matter if you’re buying a pair of prescription glasses, prescription sunglasses, or non-prescription frames, our team have got you covered.
Book Appointment
[Call us: (03) 8528 6288](tel:(03) 8528 6288)
[Leave a Review!](https://g.page/r/CZlOvwjAZMx9EBM/review)