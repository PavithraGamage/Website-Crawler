# Source: https://www.oscarwylee.com.au/locations/optometrist-charlestown.html

# Optometrist Charlestown
We’re moving to a new location in the centre on the Ground Level
near Coles.
Our new space opens on Thursday, April 30th, and bookings
are now available from that date.
If you’d like to visit us sooner, our closest locations
are:
Kotara
(9 minutes away)
Green Hills
(37 minutes away)

Charlestown SquareGround Level, Shop G800830 Pearson StreetCharlestown NSW 2290
* Near Coles
Opening hours
Monday9:00am - 5:30pm
Tuesday9:00am - 5:30pm
Wednesday9:00am - 5:30pm
Thursday9:00am - 8:00pm
Friday9:00am - 5:30pm
Saturday9:00am - 5:00pm
Sunday10:00am - 4:00pm
*Store hours reflect local standard trading hours and exclude public holidays
[Visit our Charlestown Google Business page for directions, reviews, and updates.](https://g.page/r/CUch5cCNZbofEBM)
Book Appointment
[Call us: (02) 4049 6371](tel:(02) 4049 6371)
[Leave a Review!](https://g.page/r/CUch5cCNZbofEBM/review)
Our Reviews
Abby Bland
1 day ago
Exceptional service to my husband who was initially reluctant to change looks to an updated/timeless... version. He loves his aviator rims so much he bought 3 pairs; and for that price hubby bought me coffee!
Thanks again Oscar Wylee
See more
Diana Rysa Asuncion
4 days ago
everyone was helpful and i finally have a glasses that really fits my style
Greg stenberg
5 days ago
Very pleasant, efficient, and went the extra mile to ensure our visit was terrific
.
Carol Phillips
1 week ago
Excellent 1st time with Oscar Wylee both employees friendly and efficient.  Explained everything and... answered questions.  Price and quality are also great.
See more
Lisa Stenberg
1 week ago
Kendy was great and very professional in her knowledge and approach. Ruby was lovely as well. Good e...xperience.
See more
Guy Hodgetts
2 weeks ago
The young optometrist went out of her way to help. She escorted me to where I need to get my eye sca...nned, was very thorough, explained everything as she was going. A great service provided.
See more
Tanya McCosker
2 weeks ago
Terrific. First time there and will definitely be going back.
anthea murray
2 weeks ago
A very good experience was given advice on eye care beyond testing and was very satisfied with my ch...oices
See more
Kathryn Codner
2 weeks ago
Great Appointment, the girls were friendly &amp; efficient. I left with lots of confidence that they hav...e helped my condition Thanks
See more
Lupcho
1 month ago
eye test was booked and done nice and quickly within 30mins of booking.
A F
1 month ago
Great service, very friendly and helpful.
My glasses were ready for pickup sooner than expected, gre...at value and love them.
See more
Lynette Eckersley
1 month ago
The BEST optometrist appt ever!!! So knowledgeable and really helped with my script! Subina was supe...r helpful as well when completing my purchase! Highly recommend
See more
jacqui morrison
1 month ago
The ophthalmologist was very thorough and very good at explaining the problems with my eyes and the ...girls were very lovely and very welcoming
See more
wayne thoroughgood
2 months ago
Oscar Wylee have been very helpful with information and communication has been a very good experienc...e
See more
jacqueline hornery
2 months ago
Staff and optometrist was  friendly,efficient, smart , and found pretty glasses
kylie Gibson
3 months ago
The staff at Charlestown Oscar Wiley have been amazing! They go above and beyond to ensure your need...s are met. Such a positive experience all round. Highly recommend!
See more
Michelle R J
3 months ago
Always such wonderful service from Oscar Wylee at Charlestown. Very helpful and the range of frames ...is excellent and affordable ???? Highly recommend.
See more
Rosie
3 months ago
Always such wonderful service from Oscar Wylee at Charlestown. Very helpful and the range of frames ...is excellent and affordable ???? Highly recommend.
See more
Debbie Lawson
3 months ago
I had my eye check at Oscar Wylee Charlestown Square on Sat 2.6.26. The staff were terrific.  Terry ...was very helpful and fixed my broken glasses and booked me in for an eye test that afternoon.  The ophthalmologist was really good.
See more
Pat Battle
4 months ago
The girls at the Charlestown Square store were absolutely amazing &amp; so helpful I can’t thank them en...ough for helping me choose frames.
See more
Elissia Goldman
4 months ago
beverley stuart
4 months ago
I’m absolutely sold- wonderful staff that took the time to explain everything to me giving me option...s and giving me the confidence that I was at the right place. I highly recommend the staff at Charlestown and will keep on returning
See more
Richard Jones
4 months ago
My first time at Oscar Wylee Charlestown, I was very impressed by the service, I recieved. The staff... are very engaging and really helpful in choosing the correct style of glasses and after my eye test they took great care in getting the measurements correct.
Thank you to the team at Oscar Wylee
See more
sagar javheri
4 months ago
had my eye test today and couldn’t be happier with the service. She was fab—very friendly, professio...nal, and took the time to explain everything properly. Highly recommend!”
See more
Andrew Sprogis
5 months ago
Very enjoyable no pain easy going friendly staff Kendy was great highly recommend this outlet I’ll b...e going back when I have to thanks for your help it was a pleasure
See more
jo McNulty
5 months ago
Antony Tee
5 months ago
Seeking an optical shop for your visual needs. Look no further if you happen to be at Level 2, Charl...estown Square. I highly recommend Oscar Wylee, where I was warmly welcomed and treated with exceptional service by a professional team, including Trudy, the Manager, Ruby, Annie, and Kendy, the Optometrist. Kendy's attention to detail and care were indeed reassuring. Thank you to everyone at Oscar Wylee, a truly deserving recipient of an Oscar for service excellence, much like the company's namesake.
See more
Samuel Gaudreau
5 months ago
Super courteous, super friendly and quick. I'm very happy to have great normal and expected customer... service. A rare thing nowadays.
See more
Ngaire Mason
5 months ago
Honestly, the service was amazing!  Mandy really went above and beyond, making sure everything was p...erfect.  I felt so well taken care of throughout the whole process.  Seriously, I'm already planning on telling everyone I know to check them out.  You won't regret it!
See more
Jessica Gilbert
5 months ago
I was able to be slotted in for an appointment very quickly. The optometrist was extremely thorough ...and personable, making sure to explain everything as we went along.
I chose the 3 pairs of glasses for $249 deal, and was given wonderful help making my 3 choices by the team members. They were lovely, and happy to help me through my (long) shortlist of styles, taking into account my job, face shape, and fussiness with accessories. I left feeling really confident with the choices and am excited to pick up my new glasses.
Thankyou team.
See more
Mackenzie Collier
6 months ago
Michael Northam
6 months ago
Prompt, professional and courteous attention
Melanie Pole
7 months ago
Kendy was amazing she went above and beyond on my recent eye check.  I can’t recommend her enough.
Ian Abbott
7 months ago
Kendy is very professional and caring.
Kim
7 months ago
Very happy with the service at the Charlestown store.  Very friendly &amp; helpful staff
Amir Motallebzadeh
7 months ago
Harry Safari
7 months ago
Excellent service. Professional staff. Thorough examination. Picked up potential future problems , n...o immediate problems Many thanks.
See more
Jahra Legaspi-Gullick
7 months ago
The staff at the Oscar Wylee Charlestown branch are truly commendable! They are all very knowledgeab...le and helpful.
See more
Shannen Mcmillan
7 months ago
Nicole Garrard
8 months ago
The team are lovely and really helpful. It was a positive experience and I will be back again.
Sandra Ramos
8 months ago
marli gray
8 months ago
Meghan Woodbridge
8 months ago
Jye Lawrence
9 months ago
Excellent experience
Terry Pierce
9 months ago
Staff very good , polite , Efficient and on time
Very Pleasant appointment
Veronica deVille
9 months ago
Lovely people, thanks for fitting me in.
mariane rose
9 months ago
garry owens
9 months ago
Neale Spencer
10 months ago
Natasha Rego
10 months ago
## Find an Optometrist in Charlestown With Oscar Wylee
Located in the city of Lake Macquarie’s largest town, Oscar Wylee Charlestown is close to areas such as Kahibah and Kotara South. Oscar Wylee is a modern and vintage-inspired eyewear brand that can provide you with prescription glasses and prescription sunglasses, as well as in-store eye health tests and vision testing. 
You can find us inside Charlestown Square near Coles on Ground Level, which is the largest shopping and entertainment destination in the Hunter region. You can find beaches and bush walks nearby, or do some shopping within the centre with its large variety of retail stores and restaurants. Oscar Wylee has some of the best optometrists in Charlestown so come see us in our eyeglasses shop for essential optometry services. There are plenty of things for kids to do as well, such as spending the day at Timezone. There is also easy access to public transport and ample parking with open and undercover options available.        
Meet Our Team
* Optometrist
Masters of Optometry
therapeutically endorsed
* Store Manager
Our Services
* Bulk Billed Eye Examinations
* Professional Frame Styling
* Frame Adjustments and Repairs
* Visual Fields Testing
* Digital Retinal Scanning
Show All
## Find an Optometrist in Charlestown, Greater Newcastle for an Eye Health Test
An optometrist in Charlestown, Greater Newcastle is available for essential services such as an eye health test in Charlestown, prescription sunglasses and non-prescription glasses. Bring an eligible Medicare card to access these services at a bulk billed price courtesy of the Australian Medicare System. Our Oscar Wylee Charlestown, Newcastle team is committed to caring for your vision and general eyewear concerns and with a team of skilled optometrists and an optical dispenser, we can do just that. The average price range for an optometrist in Charlestown can differ from other locations, therefore, it may be difficult to provide an accurate price range for Charlestown optometrists.
A standard procedure for a comprehensive eye test will involve the use of different tools and machines to assess your ocular health and is able to detect signs of eye diseases. If the optometrist does identify signs of an eye disease, you may be referred to an eye doctor, who in Australia, is an ophthalmologist. Make our Oscar Wylee glasses store your go-to if you’re in search of a wide range of stylish frames and a committed team.
## How to Find an Optometrist in Charlestown, Greater Newcastle?
To find an optometrist in Charlestown, Greater Newcastle, you can take certain steps that can help make it easier for you such as  searching online, assessing the store’s opening hours and finding the directions to your chosen location. The steps on how to find an optometrist in Charlestown, Newcastle are listed below.
1. Search online using the phrase, Charlestown optometrist near me. This can also be done here on the website via our locations page.
2. Click on the Oscar Wylee link, which will take you directly to our Charlestown optometrist store page.
3. See the store’s opening hours and where the store is located specifically.
4. Use the Charlestown Google Business page link located under store hours to see the directions on how to get to the store.
You can also find an optometrist in Charlestown by searching the keywords optometrist near me. If you have locations enabled on your smartphone and you’re in the Charlestown, Greater Newcastle area, our Charlestown store page should appear easily for you to click on.
### Is it Hard to Get an Eye Appointment in Charlestown, Newcastle?
No, it is not hard to get an eye appointment in Charlestown. You can easily book an appointment to see an Oscar Wylee optometrist in Charlestown right here on this page. At Oscar Wylee we have highly qualified optometrists available for bulk billed eye appointments, which can be booked online or in-store.
#### How to Compare Optometrists in Charlestown to Each Other?
To compare optometrists in Charlestown, you can use factors such as eye tests offered, health fund coverage, lens types and add-ons and eyewear offered. To take care of your vision and eye health, it is important to receive an eye test at least once every two years. There are different types of tests that can be performed in an eye test and not all optometrists may offer the same tests. Health funds can be used to help cover some of the cost of your frames and lenses. To find out if your health fund is accepted at Charlestown optometrist in Greater Newcastle, visit their website. In the case of Oscar Wylee, we accept all major health funds and provide on-the-spot claims in-store. There are many different lens options available for prescription glasses such as single vision, multifocal and high index lenses. Most optometrists in Charlestown will offer these lenses although it is good to make sure. There are also lens add-ons available to enhance your glasses such as anti-reflective and blue light filters. Finally, if you are looking to purchase a pair of glasses after your eye test, you can compare the different styles and colours you are interested in from Charlestown optometrists in Greater Newcastle. Oscar Wylee offers a wide range of frames with vintage and modern inspirations in bold colours and subtle designs.
#### How to Find an Eyeglasses Shop in Charlestown in Greater Newcastle?
To find a glasses store in Charlestown, you can try to follow these simple steps including searching online, selecting a convenient location and looking at their health insurance policies. The steps on how to find a glasses store are listed below.
1. Search online using the phrase, glasses store in Charlestown. This will provide you with various options for glasses stores in the whole Charlestown, Greater Newcastle area.
2. Select a glasses store that is most convenient for you to travel to.
3. Click the link to find out more information such as opening hours, exact location and directions to the glasses store in Charlestown, Greater Newcastle.
4. Read their health insurance policies to ensure you know what health benefits you have access to.
Our Oscar Wylee glasses store in Charlestown, Greater Newcastle store offers primary eye care services such as comprehensive eye tests as well as other services performed by an optometrist and offers prescription and non-prescription eyewear.
##### Is it Possible to Purchase Prescribed Sunglasses in Charlestown, Greater Newcastle Without Seeing an Optometrist?
Yes and no, it is possible to [purchase prescribed sunglasses](https://www.oscarwylee.com.au/sunglasses.html) in Charlestown, Greater Newcastle without seeing an optometrist if you already have a prescription that has not expired. If your prescription is expired, you can book an eye test to receive an updated or new prescription which will require you to see an optometrist. This will ensure your prescription sunglasses are appropriate for your visual needs.
## Where is the Oscar Wylee Charlestown Optometrist in Greater Newcastle Located?
The Oscar Wylee Charlestown store optometrist can be found on ground level of Charlestown Square, near Coles. Charlestown Square is a large indoor/outdoor shopping and entertainment centre found at 30 Pearson St in Greater Newcastle.
### What is the Phone Number of Oscar Wylee Charlestown Optometrist Store?
The Oscar Wylee Charlestown store phone number is [(02) 4049 6371](tel:(02) 4049 6371). You can call the Oscar Wylee Charlestown optometrist store between 9 am and 5:30 pm on Monday, Tuesday, Wednesday and Friday. On Thursday between 9 am and 7 pm, on Saturday between 9 am and 4 pm and on Sunday between 10 am and 4 pm.
### What are the Reviews for Oscar Wylee Charlestown Optometrist in Greater Newcastle?
The many reviews for Oscar Wylee Charlestown optometrist in Greater Newcastle, from our various customers can be found here on the website and online when you search for Oscar Wylee Charlestown optometrist. The reviews for Oscar Wylee Charlestown optometrist are listed below.
* Susanne Bender:  Great customer service and professionalism.
* Jenni Fox:  professional, friendly, helpful.
* Hai Yu:  Staff are friendly and helpful. Luisa is very professional and caring. She explained the eye test results in detail and made good recommendations on how to look after my eyes and slow down my son's myopia. She also printed out information for us to read.
* Adam McC:  First time in an eye test that I felt I was listened to and was more than just a wallet for the cash register. My eyes are complex, and David spent a considerable amount of time going through things and offering suggestions, including a referral to a specialist. Highly recommend it.
* Divine Samson:  Positive experience in our most recent check-up at Charlestown Square branch. Andrew and Emely (not sure of her name) were exemplary - knowledgeable, patient and pleasant.
#### What Treatments or Eye Care Processes are Done in the Oscar Wylee Charlestown Optometrist Location?
The treatments or eye care processes done in the Oscar Wylee Charlestown optometrist location include a tonometry test, a digital photograph, a slit lamp exam and a refraction test. Additional tests that may also be performed can include a visual field test and a dilated fundus exam. The treatments or eye-care processes that are done in the Oscar Wylee Charlestown optometrist Greater Newcastle location are listed below.
* A Tonometry Test: An optometrist or optical dispenser will conduct a tonometry test which involves the use of a machine that will release small puffs of air into your eyes. This will assist with measuring pressure in the eye.
* A Digital Photograph: An optometrist or optical dispenser may take a digital photograph of your eye which can be kept on record to use in future appointments to evaluate any changes to your eye.
* Slit Lamp Test: A slit lamp test can be used to evaluate your eye health, by examining your cornea and iris which are the anterior and posterior of the eye.
* Refraction Test: During a refraction test, an optometrist will have you view an image through different lenses and ask you to confirm which helps you see the image clearer.
* Visual Field Test: A visual field test can assist with assessing your peripheral vision, which may be beneficial for identifying any signs of glaucoma.
* Dilated Fundus Exam: A dilated fundus exam can help an optometrist assess your health in more detail by getting a clear view of the retina. This test is typically carried out for patients with diabetes and those who may be at risk of developing retinal damage.
## How Many Optometrists Exist in Charlestown, Greater Newcastle?
There are many Oscar Wylee optometrists that exist in Charlestown, Greater Newcastle to provide eye tests and glasses, including Oscar Wylee. The number of optometrists in Charlestown may depend on the number of residents in Charlestown and the possible demand for optometry services. At Oscar Wylee Charlestown located at Charlestown Square Shopping Centre, you can receive excellent eye care and professional assistance at a bulk billed price so you won’t have to worry about any out-of-pocket expenses.
### What are the Other Closest Optometrist Locations to Charlestown, Greater Newcastle in Australia?
The other closest optometrist location to Charlestown, Greater Newcastle in Australia is Kotara with just 4 km in distance between stores. The [Oscar Wylee Kotara](https://www.oscarwylee.com.au/locations/optometrist-kotara.html) store can be found at Westfield Kotara on level 2 along Corner Park Ave &amp; Northcott Dr. You can visit Oscar Wylee Kotara for outstanding optometry services the next time you shop at Westfield Kotara.
### Check Your Eyesight at Charlestown
Come have a comprehensive eye test that includes the necessary eye care processes for your vision and detecting eye diseases. Plan a visit to our eyeglasses shop, where we have eye care professionals carrying out bulk billed eye tests for Medicare cardholders in Australia. You will be able to update your prescription, have your eyes tested and browse for new glasses all on the same day.
### Charlestown Accepts Major Health Funds
At Oscar Wylee, we can process your health fund claim in-store so make sure you have a valid card. We'll assist you by answering any questions about what your health fund can offer you. Oscar Wylee Charlestown will walk you through the hard parts of health insurance, so you won’t be alone. At Oscar Wylee, our Charlestown team are here to ensure that you receive what you need at an affordable price.
### Oscar Wylee Offers Fashion-Forward Glasses
Our Oscar Wylee optometrists in Charlestown are dedicated to bringing your best face forward. You can shop our collection of vintage and fashionable frames at an affordable price. We provide prescription lenses that are available for customising according to all your visual requirements, which can include a blue light filter for better sleep or a multifocal lens. Oscar Wylee Charlestown is trained to aid you with any of your eye care concerns. So come visit our eyeglasses shop and view our range of frames or speak to our team.
Book Appointment
[Call us: (02) 4049 6371](tel:(02) 4049 6371)
[Leave a Review!](https://g.page/r/CUch5cCNZbofEBM/review)