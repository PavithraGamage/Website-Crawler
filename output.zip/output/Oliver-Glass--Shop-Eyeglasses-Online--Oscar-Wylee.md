# Source: https://www.oscarwylee.com.au/oliver-optical.html

# Oliver
1
## Frame Design of Oliver Glasses
The frame design of Oscar Wylee’s Oliver glasses is characterised by their classic shape, low nose bridge, and acetate frame. Oliver is a sleek unisex glasses frame that will complement any outfit, day to night.
$169    
In stock
Only %1 left
2 pairs from $199
Discount auto-applied at checkout
3 pairs from $249
Discount auto-applied at checkout
Qty
Add to cart
Book an eye test
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
excluding prescription lenses
## About Oliver Frames
Looking for something bold? Oliver is your go-to square round frame with a defined double bolt detailing. A powerful look with a playful touch.
| Frame fit | Measurements |
| --- | --- |
| MEDIUM | 50 - 19 - 145 |
These measurements mean lens width, bridge, and temple length in millimetres (mm). They can be found on the inside of the temple arm. If you already have a pair that you like, you can compare it to these measurements.
### Made from Acetate
Oscar Wylee's Oliver frame is a unisex classic glasses frame that is perfect for those with square, oval, and pear face shapes. The Oliver frame is a refined, wearable frame that can be worn every day. The main specs of Oscar Wylee's Oliver glasses frame, including dimensions, shape, materials, lenses, nose fit and hinges are listed below.
| Oliver Frame Features | Oliver Frame Description | Dimensions | Shape | Materials | Lenses | Nose Fit | Hinges |
| --- | --- | --- | --- | --- | --- | --- | --- |
| The dimensions of the Oliver frame are measured in millimetres (mm) and are 50 - 19 - 145, meaning the lens width is 50 mm, the bridge is 19 mm, and the temple length is 145 mm. |
| Oliver is a classic shape, well-suited to medium faces. |
| Oliver is made from acetate. |
| The lenses that can be used in the Oliver frame include optical lenses, such as single-vision and multifocal, and non-prescription lenses, which are plain and can have a filter, such as a blue-light filter applied. Oliver also comes as sunglasses. |
| The nose fit for Oliver is a low nose bridge fit. |
| The hinges in Oliver are normal hinges, also known as standard or barrel hinges. |
Show All
### What Inspired the Frame Design of Oscar Wylee's Oliver Glasses?
The Oscar Wylee Oliver frame design was inspired by current fashion trends, as classic shapes are often in fashion. A classic glasses shape is timeless; it remains popular throughout the decades while other trends come and go.
## What to Know About Oscar Wylee's Oliver Glasses?
There are many aspects of the Oscar Wylee Oliver frames that customers should know about to decide whether this is the right frame for them. The Oliver frame is a unisex classic-shaped frame. Oscar Wylee's Oliver frame is suitable for many face shapes, but particularly compatible with square, oval, and pear face shapes. The Oliver frame's simple design makes them fashionable all year round. Oliver features the standard [parts of glasses](https://www.oscarwylee.com.au/glasses/eye/part-of-glasses), such as a rim, temples, lenses, hinges, and a low nose bridge.
### What are the Types of Temple Tips or Earpieces Included with Oscar Wylee's Oliver Glasses?
The type of temple tips or earpieces included in Oscar Wylee's Oliver Glasses are made from acetate.
### What Type of Nose Bridge do Oscar Wylee's Oliver Glasses Have?
The type of nose bridge included in Oscar Wylee's Oliver frame is a low nose bridge fit.
### What Type of Nose Pads are Included with Oscar Wylee's Oliver Glasses?
Oscar Wylee's Oliver frame does not include adjustable silicone nose pads.
### What Type of Lenses do Oscar Wylee's Oliver Glasses Have?
The type of lenses that typically come with the Oscar Wylee Oliver [glasses frame](https://www.oscarwylee.com.au/glasses.html) are optical lenses. Optical lenses are glasses lenses that have a prescription within the lens to help correct vision issues such as myopia, hyperopia, and astigmatism. Oliver frames can also come as sunglasses and with non-prescription lenses and add-ons such as a blue-light filter.
### What Material is Used for the Rim of Oscar Wylee's Oliver Glasses?
The material used for the rim of Oscar Wylee's Oliver glasses frames is acetate. The rim refers to the part of a glasses frame that holds the lenses.
### What Type of Hinges are Included with Oscar Wylee's Oliver Glasses?
The type of hinges included with Oscar Wylee's Oliver frames are normal hinges. These provide strength and smooth movement connecting the frame's arms and lenses.
## What Face Types are Most Suitable for Oscar Wylee's Oliver Glasses?
The face types that are most suitable for Oscar Wylee's Oliver frame are square, oval, and pear face types. The Oliver frame is a classic shape, meaning that they complement the structure of square, oval, and pear faces particularly well. The classic Oliver frames help balance the features of a [square face shape](https://www.oscarwylee.com.au/glasses/face-shapes/square), an [oval face shape](https://www.oscarwylee.com.au/glasses/face-shapes/oval), and a [pear face shape](https://www.oscarwylee.com.au/glasses/face-shapes/pear), bringing the eyes and brows forward in a flattering way. Although there are many [glasses for face shapes](https://www.oscarwylee.com.au/glasses/face-shapes) that may be considered more aesthetically suitable, it is important that people also choose frames that make them feel most comfortable and represent their personal style.
## What Size Options are Available for Oscar Wylee's Oliver Glasses?
The size options available for Oscar Wylee's Oliver frame are a medium-fit frame across all colours.
## What Materials are Used to Create Oscar Wylee's Oliver Glasses?
The primary material used to create the Oscar Wylee Oliver frame is acetate. Acetate, also known as cellulose acetate, is a bioplastic made from cotton fibres or wood pulp. At Oscar Wylee, acetate glasses are made by adding a dye to cellulose acetate, which is then rolled into a sheet. The shape of the glasses is then cut from this sheet.
## What’s Included
## What's Included
Each pair of glasses comes with a stylish frame case and lens cloth. We offer free shipping across Australia and 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects.
* Free Shipping for Australian Orders
* 1 Year Warranty on frames and lenses
* Scratch resistance lens coating on all prescriptions
* UV-proof coating on all prescriptions
* Stylish case and cloth
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
## Make and Materials
The frames then go through cleaning and strict quality control, and many pairs of crafting hands to be hand-assembled and polished. After your frames have gone through the production process, they are individually examined and packed before making their way to you!Also known as cellulose acetate, these frames are traditionally hand-crafted by skilled craftsmen, with each frame passing through numerous stages of production and are hand-polished to ensure a glorious lustre.
## Warranty Information
### Warranty Information
### Warranty Information
Oscar Wylee provides a 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects. 
We will repair or replace faulty or defective frames or lenses free of charge for warranty claims made within 1 year of the delivery.
We also offer repairs or replacement for problems experienced with vision during everyday use for claims made within 30 days of delivery. If the same product has been discontinued or is no longer available, then we may offer an exchange for a similar product or a refund.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Find a Store Location](https://www.oscarwylee.com.au/locations/full-store-list.html)
Recommended
1. [](https://www.oscarwylee.com.au/windsor-optical.html)
[Windsor](https://www.oscarwylee.com.au/windsor-optical.html)
Citrus