# Source: https://www.oscarwylee.com.au/3-pairs-from-249

# Pairs for more than one occasion.
* Staying in and relaxing? Keep a pair at home.
* For the days you’re in the office, why not keep a pair at work?
* Got a party or social event to attend? Wear a statement pair!
With the most trending styles and popping colours, Oscar Wylee has you covered to suit your every occasion and mood you’re in.
Ready to find your 3 pairs?
[Browse the collection](https://www.oscarwylee.com.au/glasses)
Choose 3 complete pairs of glasses from $249 from our exclusive standard range of frames.
A complete pair includes single vision prescription lenses with scratch resistant and UV coatings.
Due for an eye test? Book now:
Book an eye test
We recommend that everyone should have an eye test with an optometrist at least once every 2 years.
*Free eye test with optical glasses purchase on the same day. Otherwise $30.
Ready to find your 3 pairs?
Shop our collection
Choose 3 complete pairs of glasses from $249 from our exclusive standard range of frames.
A complete pair includes single vision prescription lenses with scratch resistant and UV coatings.Our offers:
[](https://www.oscarwylee.com.au/glasses)
[](https://www.oscarwylee.com.au/glasses)
[](https://www.oscarwylee.com.au/glasses)
[Find your 3 pairs](https://www.oscarwylee.com.au/glasses)
## Glasses
## Men's Glasses
Explore our range of high-quality frames for men at great value.
[Shop now](https://www.oscarwylee.com.au/glasses/collection/mens-glasses.html)
## Women's Glasses
Check out our women’s eyewear and discover fresh styles and playful frames.
[Shop now](https://www.oscarwylee.com.au/glasses/collection/womens-glasses.html)
## Sunglasses
## Men's Sunglasses
From trendy to classic, explore our high-quality range of men’s sunglasses.
[Shop now](https://www.oscarwylee.com.au/sunglasses/collection/mens-sunglasses.html)
## Women's Sunglasses
Looking for fashion forward frames, quality sunglasses and exceptional value?
[Shop now](https://www.oscarwylee.com.au/sunglasses/collection/womens-sunglasses.html)
# Choose your terrific trio
Head into a store near you and ask about our 3 from $249 offer and our team members can help you select your perfect pairs today.
[Find your nearest location](https://www.oscarwylee.com.au/locations/full-store-list.html)
Want 3 pairs but need to update your prescription? Make a booking at a store near you.
[Book an eye test](https://www.oscarwylee.com.au/booking)