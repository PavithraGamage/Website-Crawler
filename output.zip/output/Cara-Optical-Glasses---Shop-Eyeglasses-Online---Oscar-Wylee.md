# Source: https://www.oscarwylee.com.au/cara-optical.html

# Cara
1
## Frame Design of Cara Glasses
The frame design of Oscar Wylee’s Cara glasses is characterised by a rounded shape, a low-bridge nose fit and a TR90 and metal frame. Cara glasses are a widely wearable women’s frame that will work with any occasion or outfit.
$169    
In stock
Only %1 left
2 pairs from $199
Discount auto-applied at checkout
3 pairs from $249
Discount auto-applied at checkout
Qty
Add to cart
Book an eye test
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
excluding prescription lenses
## About Cara Frames
This unique, round frame, with its combined materials, exudes a luxurious yet playful appeal. Cara’s tasteful two-tone colour way will take you effortlessly from day to night. Perfect for oval and square face shapes.
| Frame fit | Measurements |
| --- | --- |
| MEDIUM | 52 - 18 - 144 |
These measurements mean lens width, bridge, and temple length in millimetres (mm). They can be found on the inside of the temple arm. If you already have a pair that you like, you can compare it to these measurements.
### Made from TR90 and Metal
Oscar Wylee’s Cara frame is a women’s, round glasses frame that is perfect for medium faces and those with square, oval or heart face shapes. The Cara frame is a stylish, widely wearable frame that can be worn every day or out to a formal dinner. The main specs of Oscar Wylee’s Cara glasses frame including dimensions, shape, materials, lenses, nose fit and hinges are listed below.
| Cara Frame Features | Cara Frame Description | Dimensions | Shape | Materials | Lenses | Nose Fit | Hinges |
| --- | --- | --- | --- | --- | --- | --- | --- |
| The dimensions of the Cara frame are measured in millimetres (mm) and are 52 - 18 - 144, meaning the lens width is 52 mm, the bridge is 18 mm and the temple length is 144 mm. |
| The Cara frame is a round shape, well suited to medium faces. |
| Cara glasses are made from both TR90 and metal. |
| The lenses that can be used in the Cara frame are optical lenses, which include single vision and multifocal lenses and non-prescription lenses, which are plain and can have a filter like a blue light filter applied. |
| The nose fit of a Cara frame is a low nose bridge fit. |
| The hinges in the Cara frame are normal hinges, also known as standard or barrel hinges. |
Show All
### What Inspired the Frame Design of Oscar Wylee’s Cara Glasses?
The Oscar Wylee Cara frame design was inspired by current fashion trends as round shapes are often in fashion.
## What to Know About Oscar Wylee’s Cara Glasses?
There are many aspects of the Oscar Wylee Cara frames that customers should know about, so they can decide whether this is the right frame for them. The Cara frame is a woman’s round-shaped frame. Oscar Wylee’s Cara frame is suitable for many face shapes but particularly compatible with square, oval and heart face shapes. The Cara frame’s simple design means that they are fashionable all year round. Cara glasses feature the standard [parts of glasses such as a rim, temples, lenses, normal hinges and a low nose bridge.](https://www.oscarwylee.com.au/glasses/eye/part-of-glasses)
### What are the Types of Temple Tips or Earpieces Included with Oscar Wylee’s Cara Glasses?
The type of temple tips or earpieces included in Oscar Wylee’s Cara Glasses are made from acetate and stainless steel.
### What Type of Nose Bridge do Oscar Wylee’s Cara Glasses Have?
The type of nose bridge included in Oscar Wylee’s Cara frame is a low nose bridge fit. A low nose bridge fit is suitable for those with low-nose bridges.
### What Type of Nose Pads are Included with Oscar Wylee’s Cara Glasses?
Oscar Wylee’s Cara frame includes standard nose pads. Nose pads are adjustable for a perfect fit.
### What Type of Lenses do Oscar Wylee’s Cara Glasses Have?
The type of lenses that typically come with the Oscar Wylee Cara [glasses frame are optical lenses. Optical lenses are glasses lenses that have a prescription within the lens to help correct vision issues such as myopia, hyperopia and astigmatism. Cara frames can also come with non-prescription lenses, with add-ons such as a blue light filter. Cara frames are currently unavailable as sunglasses online, however, customers can customise in-store and add on tint or polarisation.](https://www.oscarwylee.com.au/glasses.html)
### What Material is Used for the Rim of Oscar Wylee’s Cara Glasses?
The material used for the rim of Oscar Wylee’s Cara glasses frames is TR90 and stainless steel. The rim refers to the part of a glasses frame that holds the lenses.
### What Type of Hinges are Included with Oscar Wylee’s Cara Glasses?
The type of hinges included with Oscar Wylee’s Cara frames are normal hinges, also known as standard or barrel hinges. These hinges have many interlocking loops that are stabilised with a small screw.
## What Face Types are Most Suitable for Oscar Wylee’s Cara Glasses?
The face types that are most suitable for Oscar Wylee’s Cara frame are heart, oval and square face types. The Cara frame is a rounded shape, meaning that it complements the structure of oval faces particularly well. The rounded Cara frames help to balance the features of an [oval face shape and a heart face shape, bringing the eyes and brows forward in a flattering way. The Cara frame is also suitable for a](https://www.oscarwylee.com.au/glasses/face-shapes/oval)[square face shape. Round frames help to bring forward the sharp and striking features of a square face type, highlighting without overemphasising them. Although there are many](https://www.oscarwylee.com.au/glasses/face-shapes/square)[glasses for face shapes that may be considered more aesthetically suitable, it is important that people also choose the frames that make them feel most comfortable, and represent their personal style.](https://www.oscarwylee.com.au/glasses/face-shapes)
## What Size Options are Available for Oscar Wylee’s Cara Glasses?
The size options available for Oscar Wylee’s Cara frame are a medium-frame fit across all colours.
## What Materials are Used to Create Oscar Wylee’s Cara Glasses?
The materials used to create the Oscar Wylee Cara frame are TR90, stainless steel, cupronickel and acetate. Acetate, also known as cellulose acetate, is a bioplastic, made from cotton fibres or wood pulp.
## What’s Included
## OW Case &amp; Cloth
Protective Case and Lens Cloth
Our high-quality glasses case and lens cloth are included with every purchase of an Oscar Wylee frame. The stylish, magnetic case is made from a hard shell. This sturdy and durable material keeps your glasses protected and safe, wherever you go. Ensure your lenses are clean and scratch-free with our OW microfibre cloth, specifically designed to ensure you have comfortable vision through your lenses.
Oscar Wylee offers:
* Free Shipping for Australian Orders
* 1 Year Warranty on frames and lenses
* Scratch resistance lens coating on all prescriptions
* UV-proof coating on all prescriptions
Health fund rebate: Once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. Learn more about [health funds](https://www.oscarwylee.com.au/health-funds.html).
## Make and Materials
The frames then go through cleaning and strict quality control, and many pairs of crafting hands to be hand-assembled and polished. After your frames have gone through the production process, they are individually examined and&nbsp;packed before making their way to you!Also known as cellulose acetate, these frames are traditionally hand-crafted by skilled craftsmen, with each frame passing through numerous stages of production and are hand-polished to ensure a glorious lustre.
                            
## Warranty Information
### Warranty Information
### Warranty Information
Oscar Wylee provides a 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects. 
We will repair or replace faulty or defective frames or lenses free of charge for warranty claims made within 1 year of the delivery.
We also offer repairs or replacement for problems experienced with vision during everyday use for claims made within 30 days of delivery. If the same product has been discontinued or is no longer available, then we may offer an exchange for a similar product or a refund.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Find a Store Location](https://www.oscarwylee.com.au/locations/full-store-list.html)
Recommended
1. [](https://www.oscarwylee.com.au/evans-optical.html)
[Evans](https://www.oscarwylee.com.au/evans-optical.html)
Citrus
2. [](https://www.oscarwylee.com.au/drew-optical.html)
[Drew](https://www.oscarwylee.com.au/drew-optical.html)
Clear Crystal