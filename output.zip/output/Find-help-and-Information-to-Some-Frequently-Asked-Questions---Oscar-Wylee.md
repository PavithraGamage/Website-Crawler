# Source: https://www.oscarwylee.com.au/faq-popular.html

* [POPULAR FAQS](https://www.oscarwylee.com.au/faq-popular.html)
* [ORDERING](https://www.oscarwylee.com.au/faq-ordering.html)
* [PRESCRIPTIONS](https://www.oscarwylee.com.au/faq-prescriptions.html)
* [SUNGLASSES](https://www.oscarwylee.com.au/faq-sunglasses.html)
* [RETURNS &amp; WARRANTIES](https://www.oscarwylee.com.au/faq-returns.html)
* [PAYMENT](https://www.oscarwylee.com.au/faq-payment.html)
* [HEALTH FUNDS](https://www.oscarwylee.com.au/faq-healthfund.html)
* [LENSES](https://www.oscarwylee.com.au/glasses/eye/types-of-lenses)
* [FRAMES](https://www.oscarwylee.com.au/faq-frames.html)
* [SHIPPING](https://www.oscarwylee.com.au/faq-shipping.html)
* [EYEWEAR STYLING TIPS](https://www.oscarwylee.com.au/faq-eyewear-styling-tips.html)
POPULAR
ORDERING
PRESCRIPTIONS
SUNGLASSES
RETURNS &amp; WARRANTIES
PAYMENT
HEALTH FUNDS
LENSES
FRAMES
SHIPPING
EYEWEAR STYLING TIPS
### POPULAR QUESTIONS
How do I reschedule my booking?
To reschedule your eye test, you can click the link in your
confirmation booking. This will take you to the booking page, and you
can pick another time or day that is suitable. You can also ring the
store where your eye test will be held and ask to reschedule your
appointment to a preferred time. Find your store information here: [https://www.oscarwylee.com.au/locations/full-store-list.html](https://www.oscarwylee.com.au/locations/full-store-list.html)
How do I cancel my appointment? 
To cancel your eye test, you can click the link in your confirmation
booking. You can also ring the store where your eye test will be held
to cancel. Find your store information here:
[https://www.oscarwylee.com.au/locations/full-store-list.html](https://www.oscarwylee.com.au/locations/full-store-list.html) [](https://www.oscarwylee.com.au/locations/full-store-list.html)
What is the delivery time/When can I expect frames?
Delivery on Australian orders is free, and your order will be sent
out via standard parcel delivery. We are unable to send any orders out
via Express Post. The expected wait time for orders to arrive at our
warehouse is 7-10 business days. Once it arrives and has been shipped,
you will get an email with the tracking information. It should be
noted that the wait time for the delivery to arrive from the warehouse
to your address will be an additional 1-2 weeks. If you are not
available to take delivery, a calling card will be left with
instructions on how to pick up your package. Unfortunately, there are
no deliveries on public holidays. In this instance, please expect your
delivery to be delayed by one business day. Please allow more time for
collection or delivery during peak times of the year like public
holidays or the Christmas period.
Why is my order 'On Hold'/ What does "on hold" mean?
Our orders can have a different status depending on where it's at in
the production line.Here is a break down of each status and what it means:On Hold
- This means that your order is on hold in our system whilst we attain
more information. We may need to contact you or your previous
optometrist and update your order before we submit it to our lab for
production.Processing - Your order is ready to
be sent to our lab.Attention Needed - This
means your order is ready to be sent to our lab and needs to be
checked once it arrives in store.Exported to Lab
- Your order is in production.Exported to Review
- This means that your order is in production but we need to check
your order before we contact you for collection.Complete
- Your order has arrived in-store or has been shipped out to you. You
will receive an email to either confirm store collection or with a
copy of the tracking information if posted.Closed/Cancelled
- This means that the order has been closed in our system. If you
think this is incorrect, please contact us.
How do I get a copy of my prescription? 
To find your prescription, you can follow these steps:
Visit an Oscar Wylee Store: As of 28th July 2026,
due to the increasing risk of scams, identity fraud, and social
engineering attacks, prescriptions can no longer be released over the
phone. If you’ve had your eyes tested at an Oscar Wylee store, your
prescription will be on file. Customers can visit any Oscar Wylee
store to retrieve their existing prescription.
Book a New Eye Test: If your prescription has
expired or you haven’t had an eye test recently, you’ll need to book
an eye test to obtain an up-to-date prescription. Oscar Wylee offers
bulk-billed eye tests for eligible Medicare cardholders.
Book an eye test with an Oscar Wylee optometrist
[Book an eye test](https://www.oscarwylee.com.au/booking)
Pricing?
We offer a single pair of prescription glasses from $169 or two pairs
from $199. Lens extras such as premium anti-reflective, blue light
filter or polarised coatings are available for an additional cost.
Speak with our store team and they can help with pricing and health fund
quoting.
How much does an eye test cost?
At Oscar Wylee, eye tests are bulk billed through Medicare for
eligible Medicare cardholders, meaning there is no out-of-pocket
expense. For those who are not covered under Medicare, the cost of an
eye test is $70.
For international students, Oscar Wylee offers a free eye test when
they purchase any pair of glasses on the same day. To qualify for this
offer, you will need to present a valid international ID and student
ID. This offer is available in-store, and our friendly staff will
assist you with any questions you may have.
Can I order my glasses online? 
Yes, you can order your pair of Oscar Wylee glasses online for your
convenience. You will be asked to simply fill in your prescription,
lens and contact details, and your order will be shipped to your
preferred address.
Repairs/Returns
Repairs
If your frames are damaged, head in and see our store teams and they
will be able to help fix or replace them for you.
Charges may apply for items not covered under our 12-month warranty.
Returns
Since each pair of glasses is customised based on your prescription, we
cannot offer any exchange or refund for change of mind on prescription
items.
If the prescription provided from an external optometrist is incorrect
or if the prescription is no longer valid, purchasers agree that Oscar
Wylee is not responsible for the cost of the remake.
You may exchange or refund non-prescription, over-the-counter
sunglasses within 30 days of delivery if you change your mind. These
should be in brand new, saleable condition and accompanied by the
original packaging.
Can I change my order? 
No, you can’t change your order. Once an order has been placed, we
are unable to modify or cancel it. Your order will be sent to the
manufacturer at the close of business on the day you have purchased
your eyewear.
Can I speed up my order?
There is no way to speed up your order as Oscar Wylee does not do
fast track deliveries. However, you can monitor your order easily
through the email you will receive once it has arrived in our warehouse,
which takes around 7-10 business days.
Can someone else pick up my glasses for me?
Yes, someone else can pick up your glasses for you. You just have to
notify the store that someone else is collecting the order on your
behalf, and ensure the person is sent the order confirmation text you
had received. When the person arrives to collect your order, they will
be asked to show this confirmation text and ID to verify that they are
meant to collect the glasses. It should be noted that if adjustments
to your glasses are necessary, you will need to come in yourself to
get them fixed.
Is the two pair and three pair prescription glasses deal available for
all glasses?
The two pair and three pair prescription glasses deal do not apply to
all glasses orders. Oscar Wylee offers deals wherein customers can get
2 pairs of optical prescription glasses from $199 and 3 pairs of
optical prescription glasses from $249. However, these price points
apply to standard single vision lenses. Multifocal lenses and other
lens add ons will cost extra.
Are the two pair and three pair sunglass deal available for all
sunglasses?
The two and three pair sunglass deal is only available for
non-prescription sunglasses. Oscar Wylee offers deals wherein
customers can get 2 pairs of non-prescription sunglasses from $199 and
3 pairs of optical prescription glasses from $249. However,
prescription sunglasses and other add-ons will increase the
price.
Can you mix and match frames in the 2 or 3 pair deals?
Yes, you can mix and match any optical or sunglass frames, as long as
they are a part of our 2 pairs for $199 or 3 pairs for $249 deals.
This applies for both prescription and non-prescription glasses!
However, if you purchase sunglasses with a prescription, there will be
an extra $30 cost per pair to add a tint
or an extra $100 per pair to add polarised lenses.
Following up an order?
We recommend allowing up to 10 business days for your order to be ready
for collection in store. If you are having your order posted to you, you
will receive an email with the tracking number once your order has been
shipped.
Lens issue?
If you are having issues with your lenses, head in-store and one of our
team will be happy to take a look and let you know the best next steps.
Can I get just my lenses replaced and keep the frames/Can I get lenses
replaced?
Yes, at Oscar Wylee you can get your lenses replaced for your Oscar
Wylee frames, but this will be at a cost. There is a base cost of $89
for reglazing the lenses, then any additional lens add-ons, such as
lens thinning, multifocals and blue light filters. This service is not
available for other brand glasses.
What are the store locations?
Oscar Wylee has many store locations across Australia, New Zealand
and Canada. Click here to search for the closest one to you.
Find an Oscar Wylee Store Near You
[Store Locations](https://www.oscarwylee.com.au/locations/full-store-list.html)
What is your warranty policy?
Oscar Wylee provides a 1-year warranty from the date of delivery on
frames and lenses against manufacturing faults or defects. We also
offer a repair or replacement for problems experienced with vision
during everyday use for claims made within 30 days of collection or
delivery. Feel free to view further details regarding our warranty
policy here:[https://www.oscarwylee.com.au/legal/oscar-wylee-warranty.html](https://www.oscarwylee.com.au/legal/oscar-wylee-warranty.html)