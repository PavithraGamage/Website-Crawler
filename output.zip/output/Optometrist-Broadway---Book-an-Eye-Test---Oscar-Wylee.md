# Source: https://www.oscarwylee.com.au/locations/optometrist-broadway.html

# Optometrist Broadway
Broadway Shopping CentreGround Floor, 1 Bay StreetUltimo NSW 2000
* Near Bed Bath N' Table
Opening hours
Monday10:00am - 7:00pm
Tuesday10:00am - 7:00pm
Wednesday10:00am - 7:00pm
Thursday10:00am - 9:00pm
Friday10:00am -7:00pm
Saturday9:00am - 6:00pm
Sunday10:00am - 6:00pm
*Store hours reflect local standard trading hours and exclude public holidays
[Visit our Broadway Google Business page for directions, reviews, and updates.](https://g.page/r/CWnyb6G24RKIEBM)
Book Appointment
[Call us: (02) 8385 5600](tel:(02) 8385 5600)
[Leave a Review!](https://g.page/r/CWnyb6G24RKIEBM/review)
Our Reviews
Blessing Songo
4 days ago
Amir Najafi
2 weeks ago
Silvie Calder-Hickey
2 weeks ago
A good first experience, staff helpful. But I think automatically emailing your new glasses prescrip...tion with the receipt of your purchase would be really good customer service so you have it to hand when travelling. As a frequent traveller its important to have prescription to hand when overseas and specs are lost or broken.
See more
Kazem Ghaemi
3 weeks ago
Hi
Was a great and perfect of exam you have done for me and I am so satisfied
Rowley and Co.
3 weeks ago
Had a really good experience here. Janine was friendly and knowledgeable and I really enjoyed her co...nversation. Highly recommend!
See more
027 -
4 weeks ago
nice service！
Avie Mae
1 month ago
Shout out to Mikayla who was so friendly, knowledgeable and helpful. She was always available and en...couraged me to try on as many pairs as I needed, even though that meant more work for her putting them all back. She didn’t make me feel silly for taking over 45 minutes to choose 3 pairs of glasses ????
She explained all the pricing and lens coatings really clearly and I feel like I understood the pros and cons of them all.
I also felt like my eye check with the optometrist was really thorough and that she spent the time making sure my new script and prism was correct and didn’t rush me out. I got emailed my new prescription so I could buy my glasses somewhere else if I wanted.
Would recommend the broadway team for both eye checks and buying frames.
See more
Richard van
1 month ago
Sue Beatty
1 month ago
Staff were extremely helpful &amp; efficient
John Truong
1 month ago
I’ve been there many times for eye checking and glasses, i don’t think elsewhere better than Oscar W...ylee!
Thanks for looking after my eyes
See more
Brad Bennett
1 month ago
Professional excellent customer service informative and welcoming
Yunn
1 month ago
Went to Oscar Wylee on Tuesday afternoon, the staff were very helpful and kind, super professional! ...The Optometrist was was very kind to listen to my concerns and gave me great advice about my eye health as well as put my concerns to rest. Thank you  kindly everything who helped me. My partner also has been this Oscar Wylee and had a great experience, he got two pairs of glasses that looked great on him. Thank you everyone who helped us &lt;3
See more
Amye Murphy
1 month ago
Cain Molloy
1 month ago
Great People, very Professional, Tested my eyes, and I need to think about purchasing some glasses, ...in a couple of weeks. .
Would recommend them.
See more
rick edney
1 month ago
Penny Gilkes
1 month ago
Very professional. Good communication. Knowledgeable.
Kathy Te Nuku
1 month ago
Very friendly and extremely professional
Peter Christie
1 month ago
Very convenient to schedule and appointment. The staff at the store were efficient, friendly and ver...y helpful.
See more
Janine Grevh
1 month ago
lauren daly
1 month ago
Deborah Young
1 month ago
Excellent service.
Simren C
2 months ago
Hi! Very good &amp; professional!
Fanny
2 months ago
Neal Bedford
2 months ago
Very professional and accommodating. I was running late and called to let them know - rebooked witho...ut any fanfare. Very courteous and helpful.
Optometrist was knowledgeable and explained things in a way that made sense. She took the time to answer all my questions. Even the dumb ones ????
Would recommend to anyone who needs and optometrist for a yearly checkup or any other optometric needs ????????
See more
Julie McConnell
2 months ago
senyenlee
2 months ago
Mikayla and Caity were really helpful and sweet! They had best customer service, absolutely recommen...d. Best manager on the floor award goes to: Mikayla!! ⭐️
Special thanks to Pricilla for helping me with my eye tests too.
See more
Ridha Aulia
2 months ago
mike mate
3 months ago
Friendly and helpful staff, they helped me with my vision
Mark Ryan
3 months ago
Great staff, very reassuring
Jonathan Tidball
3 months ago
always a great service here whenever i go fo my optical needs also
very helpful and with all my ques...tions!
i wouldn't go anywhere else!
See more
Yasmine Ghoniem
3 months ago
lovely team
Steven Nguyen
3 months ago
The most thorough eye test I’ve ever had, really impressed with how detailed and professional the ex...perience was!
See more
Torgeir Robertson
3 months ago
Had a busted frame with a seared screw. Sophie was very helpful and with the borrowed tools were abl...e to remove the screw. Thank you thank you, thank you.
See more
Robyn Adler
3 months ago
Daniel Bennett
3 months ago
I had a really positive experience at Oscar Wylee Broadway. From the moment I walked in, the staff w...ere friendly, approachable, and genuinely helpful without being pushy. They took the time to explain my options clearly, which made the whole process feel easy and stress-free.
The eye test was thorough and professional, and I felt confident in the advice I was given. Everything was handled efficiently, and I never felt rushed or overwhelmed at any point.
Overall, the service was honest, smooth, and customer-focused. I’d definitely recommend Oscar Wylee Broadway to anyone looking for a straightforward and affordable eyewear experience.
See more
Anica Holgate
4 months ago
Such a warm, helpful and professional team at the Broadway store. Could not recommend more highly
Nyalima George
4 months ago
Linda Carn
4 months ago
Professional service.
Julie Noreen
4 months ago
The whole experience was met with smiles all round and not in the least bit uncomfortable
William Lin
4 months ago
Anne Empson
4 months ago
ali wardill
4 months ago
Didn't have an appointment at the Broadway mall store, but was seen quickly. Lovely staff, very appr...oachable, informative &amp; helpful. Happy with the cost &amp; will definitely go back.
See more
Manuel David González Pérez
4 months ago
Priscilla was super helpful and fixed my glasses with a bent frame after I had sat on them. I knew t...here was a risk of breaking them but she was very careful and skilled. Excellent customer service!
See more
Nexttech
4 months ago
Hi Priscilia I am the person you helped yesterday fixing his glasses after the little accident I had... in the restaurant, and without them , I wasn’t able to drive or go anywhere because of my high astigmatism even unable to use my phone .My prescription glasses were purchased at a different store , and unfortunately they were all closed, so I walked into Oscar Wylee store and I asked for assistance, Pariscilia ????helped fixing the frame and putting the lens back in and she made sure they were okay before I leave the store , and I got home safely ????. Thanks a lot Priscilia for yesterday and for your friendly assistance, you are a wonderful person ????.
See more
Michelle Wilson-Webster
5 months ago
The staff and optometrist were very helpful and lovely to deal with
Tim Pham-Vu
5 months ago
Thank you for the professional and friendly service.
Sara Ghrier
5 months ago
They are good reliable and cheap they are honest I will be back again next year better than Specsave...rs.
See more
Drew Andrea
5 months ago
Super easy (I really shouldn't wait so many years between checking my eyes). The optometrist was gre...at and gave me tips on what strength glasses have pro's and cons.
See more
Sarah Pearce
5 months ago
Very helpful and patient staff. Good choice of glasses
Niklas Gustavsson
5 months ago
## Find an Optometrist in Broadway with Oscar Wylee
Located within Sydney’s Broadway Shopping Centre and only minutes away from Glebe and Chippendale, Oscar Wylee Broadway’s trained optometrists are able to perform on-site eye vision exams. In-store you can browse our wide selection of frame styles, from vintage to contemporary. We also have prescription and non-prescription sunglasses and accessories on offer too! After your appointment, you can explore Broadway Sydney which has 3 floors of great shopping and delicious places to eat. You could also catch a movie at HOYTS Broadway. 
Curious about Oscar Wylee Broadway? Come visit us in-store where we are offering some of the best optometrist services in Sydney. We're located on the ground floor of Broadway Shopping Centre, near Bed Bath N' Table and are just a bus stop away from UTS and the University of Sydney. We are committed to looking after your eye health and bringing you fashion-forward frames at affordable prices.        
Meet Our Team
* Optometrist Partner
BVisSc/Moptom
TPA Endorsed
* Store Manager
Our Services
* Bulk Billed Eye Examinations
* Professional Frame Styling
* Frame Adjustments and Repairs
Show All
## Find an Optometrist in Broadway, Sydney for an Eye Health Test
An optometrist in Broadway, Sydney can take care of your optometry concerns such as an eye health test in Broadway, assistance with eyewear from an optical dispenser and other important eye care services. At Oscar Wylee, you can receive a comprehensive eye test for a bulk billed price if you’re a part of Australia’s Medicare System and have an eligible Medicare card. Signs of eye diseases can often develop unnoticed so it is important to maintain regular eye tests. Come into our glasses store so we can help and also browse our wide range of modern and vintage-inspired frames.
While an optometrist is not considered an eye doctor here in Australia, they have all the necessary training and qualifications to provide excellent fundamental eye care services catered to your vision health and any concerns. Optometrists in Broadway can vary in price according to factors such as the facilities they operate in, the equipment used and the health of your vision.
## How to Find an Optometrist in Broadway, Sydney?
To find an optometrist in Broadway, Sydney, you can take certain steps that can help make it easier for you such as searching online, assessing the store’s opening hours and finding the directions to your chosen location. The steps on how to find an optometrist in Broadway are listed below.
1. Search online using the phrase, Broadway optometrist near me. This can also be done here on the website via our locations page.
2. Click on the Oscar Wylee link, which will take you directly to our Broadway optometrist store page.
3. See the store’s opening hours and where the store is located specifically.
4. Use the Broadway Google Business page link located under store hours to see the directions on how to get to the store.
You can also find an optometrist in Broadway by searching the keywords optometrist near me. If you have locations enabled on your smartphone and you’re in the area, our Broadway store page should appear easily for you to click on.
### Is it Hard to Get an Eye Appointment in Broadway, Sydney?
No, it is not hard to get an eye appointment in Broadway. You can easily book an appointment to see an Oscar Wylee optometrist in Broadway right here on this page. At Oscar Wylee we have highly qualified optometrists available for bulk billed eye appointments, which can be booked online or in-store.
#### How to Compare Optometrists in Broadway To Each Other?
To compare optometrists in Broadway, you can use factors such as eye tests offered, health fund coverage, lens types and add-ons and eyewear offered. To take care of your vision and eye health, it is important to receive an eye test at least once every two years. There are different types of tests that can be performed in an eye test and not all optometrists may offer the same tests. Health funds can be used to help cover some of the cost of your frames and lenses. To find out if your health fund is accepted at Broadway optometrist in Sydney, visit their website. In the case of Oscar Wylee, we accept all major health funds and provide on-the-spot claims in-store. There are many different lens options available for prescription glasses such as single vision, multifocal and high index lenses. Most optometrists in Broadway will offer these lenses although it is good to make sure. There are also lens add-ons available to enhance your glasses such as anti-reflective and blue light filters. Finally, if you are looking to purchase a pair of glasses after your eye test, you can compare the different styles and colours you are interested in from Broadway optometrists in Sydney. Oscar Wylee offers a wide range of frames with vintage and modern inspirations in bold colours and subtle designs.
#### How to Find an Eyeglasses Shop in Broadway, Sydney?
To find a glasses store in Broadway you can try to follow these simple steps including searching online, selecting a convenient location and looking at their health insurance policies. The steps on how to find a glasses store in Broadway are listed below.
1. Search online using the phrase, glasses store in Broadway. This will provide you with various options for glasses stores in the whole Broadway, Sydney area.
2. Select a glasses store that is most convenient for you to travel to.
3. Click the link to find out more information such as opening hours, exact location and directions to the glasses store in Broadway.
4. Read their health insurance policies to ensure you know what health benefits you have access to.
Our Oscar Wylee glasses store in Broadway, Sydney offers primary eye care services such as comprehensive eye tests as well as other services performed by an optometrist and offers prescription and non-prescription eyewear.
##### Is it Possible to Purchase Prescribed Sunglasses in Broadway, Sydney Without Seeing an Optometrist?
Yes and no, it is possible to [purchase prescribed sunglasses](https://www.oscarwylee.com.au/sunglasses.html) in Broadway, Sydney without seeing an optometrist if you already have a prescription that has not expired. If your prescription is expired, you can book an eye test to receive an updated or new prescription which will require you to see an optometrist. This will ensure your prescription sunglasses are appropriate for your visual needs.
## Where is the Oscar Wylee Broadway Optometrist in Sydney Located?
The Oscar Wylee Broadway optometrist in Sydney is located on the ground floor of Ultimo shopping centre, near Bed Bath N’ Table.
### What is the Phone Number of Oscar Wylee Broadway Optometrist Store?
The Oscar Wylee Broadway optometrist store phone number is (02) 8385 5600 which you can contact between the hours of 10 am and 7 pm on Monday, Tuesday, Wednesday and Friday. On Thursday between 10 am and 9 pm, on Saturday between 9 am and 6 pm and on Sunday between 10 am and 6 pm.
### What are the Reviews for Oscar Wylee Broadway Optometrist in Sydney?
The reviews for Oscar Wylee Broadway optometrist in Sydney are left by our various customers and can be found here on the website and online. The reviews for Oscar Wylee Broadway optometrist in Sydney are listed below.
* Kristine De Belen Mendoza:  Friendly staff and accommodating.
* George Milonas:  Great customer service. Optometrist Pricilla was very nice and helpful. I am very happy.
* Steven Mora:  I’m so happy how the lady (Ash) attended us, especially how she explained to us, my mum. I definitely recommend this shop.
* Hanyang Du:  Great service!
* Don Rozario: One of the most important consultations I had with them. The optometrist was very good at explaining the various reading tests, lenses she suggested to compare for my distance and reading materials. I’ll recommend everyone to go to Oscar Wylee.
#### What Treatments or Eye Care Processes are Done in the Oscar Wylee Broadway Optometrist Location?
The treatments or eye care processes done in the Oscar Wylee Broadway optometrist Sydney location include a tonometry test, a digital photograph, a slit lamp exam and a refraction test. Additional tests that may also be performed can include a visual field test and a dilated fundus exam. The treatments or eye-care processes that are done in the Oscar Wylee Broadway optometrist Sydney location are listed below.
* A Tonometry Test: An optometrist or optical dispenser will conduct a tonometry test which involves the use of a machine that will release small puffs of air into your eyes. This will assist with measuring pressure in the eye.
* A Digital Photograph: An optometrist or optical dispenser may take a digital photograph of your eye which can be kept on record to use in future appointments to evaluate any changes to your eye.
* Slit Lamp Test: A slit lamp test can be used to evaluate your eye health, by examining your cornea and iris which are the anterior and posterior of the eye.
* Refraction Test: During a refraction test, an optometrist will have you view an image through different lenses and ask you to confirm which helps you see the image clearer.
* Visual Field Test: A visual field test can assist with assessing your peripheral vision, which may be beneficial for identifying any signs of glaucoma.
* Dilated Fundus Exam: A dilated fundus exam can help an optometrist assess your health in more detail by getting a clear view of the retina. This test is typically carried out for patients with diabetes and those who may be at risk of developing retinal damage.
## How Many Optometrists Exist in Broadway, Sydney?
There are many optometrists that exist in Broadway, Sydney that provide eye tests and glasses, including Oscar Wylee. At Oscar Wylee Broadway located in Sydney, we offer excellent eyecare services including eye health tests performed by skilled optometrists using high-quality equipment. We also have a wide range of fashion-forward frames that customers can browse in a large selection of sizes and colours. Every location including Broadway can have a different number of optometrists and this may be due to various reasons such as the number of resident population and the level of demand. If you’re in the area, come visit Oscar Wylee Broadway and let us help you care for your eyes and vision.
### What are the Other Closest Optometrist Locations to Broadway, Sydney?
The other closest Oscar Wylee optometrist locations to Broadway, Sydney are Newtown, The Galeries, Bondi and Eastgardens. The locations and their distance from Broadway are listed below.
* Newtown: Newtown is close to Broadway with just 2 km in between stores and can be found along King Street near Big Daddy's Burger Bar. At the [Oscar Wylee Newtown](https://www.oscarwylee.com.au/locations/optometrist-newtown.html) store, you will find high-standard optometry services such as eye health tests, assistance with your prescription sunglasses and glasses and many other services.
* The Galeries:  The Galeries is close to Broadway, just around 3 km in distance and can be found at 275 Pitt Street opposite ANZ Tower. [The Oscar Wylee store in The Galeries](https://www.oscarwylee.com.au/locations/optometrist-sydney-galeries.html) is where you can receive excellent optometry services not just for prescription eyewear needs but also for non-prescription eyewear services and more.
* Bondi: Bondi is close to Broadway with 6-7 km in between stores and can be visited at the Westfield Bondi Junction Shopping Centre. The [Oscar Wylee Bondi](https://www.oscarwylee.com.au/locations/optometrist-bondi-junction.html) store offers comprehensive eye tests that are helpful for monitoring your vision.
* Eastgardens: Eastgardens is close to Broadway, around 10-12 km and offers essential eye care services you may need. You can visit the [Oscar Wylee Eastgardens](https://www.oscarwylee.com.au/locations/optometrist-eastgardens.html) store when you shop at Eastgardens Westfield, just head to level 2 of the shopping centre and you will find the Oscar Wylee Eastgardens store next to Specsavers.
### Oscar Wylee Broadway optometrists perform bulk billed eye tests
You can take the first step in prioritising your eye health and vision by stopping by our Oscar Wylee eyeglasses shop in Broadway Sydney, where there are eye care processes available including prescription updates, eye health tests to assess vision and detect certain eye diseases, and frame shopping. At Oscar Wylee Broadway, eye tests are bulk billed for eligible Medicare card holders and performed by our dedicated and experienced Oscar Wylee optometrists.
### Oscar Wylee Broadway accepts major health funds
At Oscar Wylee Broadway, our staff can process your health fund claim in-store with a valid health fund card and help answer any questions about what you’re eligible for with your health fund. You don’t have to navigate the hardest parts of health insurance alone. Use your private health fund insurance to limit how much you pay from your own pocket so you can save on frames and lenses. Oscar Wylee Broadway is dedicated to making sure you get what you need at an affordable, competitive price.
### Fashion-forward styles at affordable prices
Oscar Wylee Broadway is committed to helping you find your perfect pair of frames, offering modern and vintage-style glasses at an affordable price. Our Oscar Wylee Broadway optometrists provide prescription lenses to fit customer needs - whether it’s polarised lens for your prescription sunglasses or a blue light filter, our experts in-store are ready to help you with any of your eye care needs.
Book Appointment
[Call us: (02) 8385 5600](tel:(02) 8385 5600)
[Leave a Review!](https://g.page/r/CWnyb6G24RKIEBM/review)