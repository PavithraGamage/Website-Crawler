# Source: https://www.oscarwylee.com.au/maise-optical.html

# Maise
1
## Frame Design of Maise Glasses
The frame design of Oscar Wylee’s Maise glasses is characterised by a round shape, a high nose bridge fit and an acetate frame. Maise glasses are a women’s, essential frame that will work for any occasion.
$169    
In stock
Only %1 left
2 pairs from $199
Discount auto-applied at checkout
3 pairs from $249
Discount auto-applied at checkout
Qty
Add to cart
Book an eye test
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
excluding prescription lenses
## About Maise Frames
Perfect and petite, Maise has everything you want wrapped into one neat package. This full acetate frame is good for high prescriptions and great for smaller, squarer face shapes. Spring hinges and this seasons most popular colours are the cherry on top.
| Frame fit | Measurements |
| --- | --- |
| NARROW | 49 - 19 - 140 |
These measurements mean lens width, bridge, and temple length in millimetres (mm). They can be found on the inside of the temple arm. If you already have a pair that you like, you can compare it to these measurements.
### Made from Acetate
Oscar Wylee’s Maise frame is a women’s, round glasses frame that is perfect for narrow faces and those with square, oval and heart face shapes. The Maise frame is a stylish, widely wearable frame that can be worn every day. The main specs of Oscar Wylee’s Maise glasses frame including dimensions, shape, materials, lenses, nose fit and hinges are listed below.
| Maise Frame Features | Maise Frame Description | Dimensions | Shape | Materials | Lenses | Nose Fit | Hinges |
| --- | --- | --- | --- | --- | --- | --- | --- |
| The dimensions of the Maise frame are measured in millimetres (mm) and are 49 - 19 - 140, meaning the lens width is 49 mm, the bridge is 19 mm and the temple length is 140 mm. |
| The Maise frame is a round frame shape, well suited to narrow faces. |
| Maise glasses are made from a material called acetate. |
| The lenses that can be used in the Maise frame are optical lenses, which include single vision and multifocal lenses and non-prescription lenses, which are plain and can have a filter like a blue light filter applied. |
| The nose fit of Maise frames is a high nose bridge fit. |
| The hinges in Maise glasses are spring hinges, which are more flexible than other types of hinges and can extend past 90 degrees. |
Show All
### What Inspired the Frame Design of Oscar Wylee’s Maise Glasses?
The Oscar Wylee Maise frame design was inspired by current fashion trends as round glasses shapes are a must-have for those who appreciate a classic look.
## What to Know About Oscar Wylee’s Maise Glasses?
There are many aspects of the Oscar Wylee Maise frames that customers should know about, so they can decide whether this is the right frame for them. The Maise frame is a woman’s round-shaped frame. Oscar Wylee’s Maise frame is suitable for many face shapes but particularly compatible with square, oval and heart shapes. The Maise frame’s simple design means that they are fashionable all year round. Maise glasses feature the standard [parts of glasses](https://www.oscarwylee.com.au/glasses/eye/part-of-glasses) such as a rim, temples, lenses, spring hinge and a high nose bridge fit.
### What are the Types of Temple Tips or Earpieces Included with Oscar Wylee’s Maise Glasses?
The type of temple tips or earpieces included in Oscar Wylee’s Maise Glasses are made from acetate.
### What Type of Nose Bridge do Oscar Wylee’s Maise Glasses Have?
The type of nose bridge included in Oscar Wylee’s Maise frame is a high nose bridge fit.
### What Type of Nose Pads are Included with Oscar Wylee’s Maise Glasses?
Oscar Wylee’s Maise frame does not include any type of nose pads.
### What Type of Lenses do Oscar Wylee’s Maise Glasses Have?
The type of lenses that typically come with the Oscar Wylee Maise [glasses frame](https://www.oscarwylee.com.au/glasses.html) are optical lenses. Optical lenses are glasses lenses that have a prescription within the lens to help correct vision issues such as myopia, hyperopia and astigmatism. Maise glasses can also come with non-prescription lenses, with add-ons such as a blue light filter. Maise frames are currently unavailable as sunglasses online, however, customers can customise in-store and add on tint or polarisation.
### What Material is Used for the Rim of Oscar Wylee’s Maise Glasses?
The material used for the rim of Oscar Wylee’s Maise glasses frames is acetate. The rim refers to the part of a glasses frame that holds the lenses.
### What Type of Hinges are Included with Oscar Wylee’s Maise Glasses?
The type of hinges included with Oscar Wylee’s Maise frames are spring hinges, A spring hinge in a glasses frame refers to hinges that are more flexible than normal hinges and can go slightly beyond 90 degrees. Spring hinges can provide a closer fit to the face.
## What Face Types are Most Suitable for Oscar Wylee’s Maise Glasses?
The face types most suitable for Oscar Wylee’s Maise frame are square, oval and heart face shapes. The Maise frame is a round shape, meaning that it complements the structure of square, oval and heart face shapes particularly well. The round Maise frames help to balance the features of a [square face shape](https://www.oscarwylee.com.au/glasses/face-shapes/square), [round face shape](https://www.oscarwylee.com.au/glasses/face-shapes/round) and an [oval face shape](https://www.oscarwylee.com.au/glasses/face-shapes/oval), bringing the eyes and brows forward in a flattering way. Round frames help to flatter oval face types creating a pleasing visual contrast between sharp angles and rounded features highlighting without overemphasising them. Although there are many glasses for face shapes that may be considered more aesthetically suitable, it is important that people also choose the frames that make them feel most comfortable, and represent their personal style.
## What Size Options are Available for Oscar Wylee’s Maise Glasses?
The size options available for Oscar Wylee’s Maise frame are a narrow-frame fit across all colours.
## What Materials are Used to Create Oscar Wylee’s Maise Glasses?
The primary material used to create the Oscar Wylee Maise frame is acetate. Acetate, also known as cellulose acetate, is a bioplastic, made from cotton fibres or wood pulp. At Oscar Wylee, acetate glasses are made by adding a dye to cellulose acetate, which is rolled into a sheet. The shape of the glasses is then cut from this sheet.
## What’s Included
## OW Case &amp;a Cloth
Protective Case and Lens Cloth
Our high-quality glasses case and lens cloth are included with every purchase of an Oscar Wylee frame. The stylish, magnetic case is made from a hard shell. This sturdy and durable material keeps your glasses protected and safe, wherever you go. Ensure your lenses are clean and scratch-free with our OW microfibre cloth, specifically designed to ensure you have comfortable vision through your lenses.
Oscar Wylee offers:
* Free Shipping for Australian Orders
* 1 Year Warranty on frames and lenses
* Scratch resistance lens coating on all prescriptions
* UV-proof coating on all prescriptions
Health fund rebate: Once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. Learn more about [health funds](https://www.oscarwylee.com.au/health-funds.html).
## Make and Materials
The frames then go through cleaning and strict quality control, and many pairs of crafting hands to be hand-assembled and polished. After your frames have gone through the production process, they are individually examined and packed before making their way to you!Also known as cellulose acetate, these frames are traditionally hand-crafted by skilled craftsmen, with each frame passing through numerous stages of production and are hand-polished to ensure a glorious lustre.
## Warranty Information
### Warranty Information
### Warranty Information
Oscar Wylee provides a 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects. We will repair or replace faulty or defective frames or lenses free of charge for warranty claims made within 1 year of the delivery. We also offer repairs or replacement for problems experienced with vision during everyday use for claims made within 30 days of delivery. If the same product has been discontinued or is no longer available, then we may offer an exchange for a similar product or a refund.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Find a Store Location](https://www.oscarwylee.com.au/locations/full-store-list.html)