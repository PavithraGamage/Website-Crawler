# Source: https://www.oscarwylee.com.au/locations/optometrist-chadstone.html

# Optometrist Chadstone
Chadstone Shopping Centre,Shop B-081, 1341 Dandenong Road,Chadstone VIC 3148
* Located next door to Nandos
Opening hours
Monday9:00am - 5:30pm
Tuesday9:00am - 5:30pm
Wednesday9:00am - 5:30pm
Thursday9:00am - 9:00pm
Friday9:00am - 9:00pm
Saturday9:00am - 7:00pm
Sunday10:00am - 6:30pm
*Store hours reflect local standard trading hours and exclude public holidays
[Visit our Chadstone Google Business page for directions, reviews, and updates.](https://g.page/r/CTsvbuXKDLGBEBM)
Book Appointment
[Call us: (03) 9972 6771](tel:(03) 9972 6771)
[Leave a Review!](https://g.page/r/CTsvbuXKDLGBEBM/review)
Our Reviews
Tanya Moody
22 hours ago
I walked in and was able to get an appointment straight away, everyone was friendly and the optometr...ist was knowledgeable. Overall a great experience
See more
Jill Andrew
5 days ago
Excellent service provided to check eyes for retina damage! Lovely staff!
Bradley Serry
1 week ago
The Chadstone store was great. The Melbourne Central store is not. The MC store told me I needed to ...buy a new set of frames for my new prescription but it seemed fishy, like they were looking for a sale, because I was repeating that I wanted to keep the same frames. So I left and then visited the Chadstone store a few days later who said the MC store was wrong. The Chadstone store were able to put the new prescription into my existing frames. Really disappointing from MC staff but fortunately the staff at Chadstone are good. Saved me a few hundred dollars for not buying the new frames. Someone ought to teach the MC staff how to treat customers properly.
See more
Phetcharat Phiphatcahroenwong
1 week ago
Five-star service from Angus! He made the whole process of getting new glasses seamless and easy. Fr...iendly, professional, and very precise with the fitting. Thanks????
See more
Sandy Cantin
1 week ago
I had an examination with Ed Thea yesterday, due to an inflammation in my right eye.  As always, he ...was on-time, professional, put me at-ease, and thorough.  He asked a series of questions and explained what he was going to do.
I left very satisfied, with a prescription in-hand and knowing next steps.
See more
Margarette Perez
2 weeks ago
Great experience and great value, the optometrists made me super comfortable and explained all my op...tions thoroughly. I’m very picky when it comes to glasses as I’ll be wearing them everyday but the workers here allowed me to take my time choosing and made the eye testing super straight forward and really assured me that I was getting prescriptions suitable and tailored for my eyes. I ended up getting 1x prescription glasses (Daisy) with blue light and 1x Sabrina sun glasses (w prescription and anti glare) and insurance covered most of it, and only had to pay $50 out of pocket. Strongly recommend!! Heaps of variety
See more
jonathan young
3 weeks ago
Sue and the team rock my world, Oscar Wylee is def my goto for eye tests and glasses!!
Eva Komarudin
3 weeks ago
Very helpful! Great choice of frame! Good price!
Captain Yesterday
3 weeks ago
Excellent service from Sue and Ed????
Yanghua Zhang
4 weeks ago
Niki Murrone
1 month ago
I had enough issues with glasses going to other stores so I thought I would give Oscar Wylee a chanc...e. The optometrist I had was so great!! He flew through the test, gave me really good info about my vision and the frame selection was great! I love this store and can’t wait to pick up my new specs! Thanks guys!
See more
Linda Baitton
1 month ago
Quick and informative eye test and helpful staff that helped me pick out two pairs of glasses, I’ll ...continue to purchase my glasses from Oscar Wylee Chadstone
See more
Fiona
1 month ago
So grateful for the team at Oscar Wylee Chadstone! My son's glasses snapped in half, but Sue stepped... up and went above and beyond so he wouldn't be stuck without them. Everyone there was so friendly—such a lifesaver!
See more
Susan Mutch
1 month ago
Easy to deal with.test successful on first attempt..report supplied in writing on the day..fantastic... service
See more
Maree Hewson
2 months ago
Very efficient staff!
Great job by front of house staff dealing with customers -  the shop was reall...y busy but they were polite and did not make you feel "rushed"
Optometrist also was very professional and polite.
,,,And they all looked happy and were smiling!
See more
AlCrissy K
2 months ago
Fantastic!  I was running late and was still able to be seen.  They are professionals and I was able... to get through my test very quickly.  Highly recommend!
See more
Kenneth Kamulegeya
2 months ago
Great customer service
Lorenie Marquez
2 months ago
alouella
3 months ago
Ed and Sue were fantastic!
henry kang
3 months ago
The experience was great, the testing was professional, and I would recommend it. Overall, it was ex...cellent.
See more
Ian Raymond
4 months ago
Edward, the optometrist, was brilliant in solving my eye issue.
Emma Jane
4 months ago
On time, friendly and helpful. Great range of glasses
Devangini Patel
4 months ago
Staff are friendly and helpful. The optometrist is amazing. She was caring and explained all the ste...ps she was performing for the eye test.
See more
Derek Stott
4 months ago
My eye examination iteself was very good in my view.  So I am pleased with that aspect -  the proof ...of the pudding of course will be when I receive my new spectacles.
What I was a little irritated about was that I seemed to be managed by two customer people and we were going backwards and forwards -  I would have been much happier to have had a single continuous dialogue with just one of them.
See more
myint Australia
4 months ago
Isabelle Lette
4 months ago
Rinlapat Chok
5 months ago
I had my eye test here today and the service was absolutely amazing. The optometrist was very profes...sional, thorough, and made me feel comfortable throughout the whole process.
Also, the staff member who helped me choose my glasses was incredibly helpful and giving great advice on what style suited me best.Highly recommend this place!
See more
Sharon Reneaux
5 months ago
Professional, honest and helpful
KRISHNA SHUKLA
5 months ago
The gold standard of eye care. Thank you, Shwetha! ⭐⭐⭐⭐⭐
I honestly cannot recommend Shwetha Ravich...andran at Oscar Wylee Chadstone enough. In a world where appointments often feel rushed and transactional, Shwetha was a breath of fresh air—she truly embodies what it means to be a caring healthcare professional.
From the moment we started the consultation, I could feel her genuine passion and enthusiasm for what she does. But what really stood out was her patience. I came in feeling a bit anxious about some changes I had noticed in my vision, but Shwetha took the time to make sure I never felt rushed.
She didn’t just read off a chart; she sat with me and carefully explained the "why" behind my eye condition. She meticulously walked me through my results, comparing them with my previous specialist’s notes to show me exactly what changes had occurred since my last visit. It was incredibly reassuring to have someone who is so highly knowledgeable take that extra step to connect the dots for me.
Beyond just the diagnosis, she showed genuine care for my long-term wellbeing. She educated me on the specific precautions I need to take to maintain my eye health moving forward, empowering me with the knowledge to take better care of myself.
If you are looking for an optometrist who is not only brilliant at her job but also treats you like a human being rather than just another appointment, go see Shwetha. She is an absolute asset to Oscar Wylee Chadstone.
See more
Sahil Adlakonda
5 months ago
Shwetha R did a fantastic job with my eye checkup - her skilful approach made me feel at ease and th...e test was quick and straightforward.
See more
Rosetta Gava
5 months ago
Rohani Sherren
5 months ago
10 out of 10 overall experience including the eye checked up, services and optometrist Ed is super k...nowledgeable. Sue is knowledgeable as well and very helpful. Thank you.
See more
Edwin Kusuma
5 months ago
Hina Tasaki
6 months ago
Generally good, had a nice experience on eye test.
andree deliyannis
6 months ago
Beautifully presented store,
Optometrist, experienced and caring!
Keep up the good work ????
Jak
6 months ago
A screw had come out of my sunglasses and I quickly went in and the store owner was very helpful and... fixed it straight away :)
See more
Jordana JC
7 months ago
Enjoyable visit! Great customer service and quick test.
Mark Dorrington
8 months ago
Sue, Eddie, Karen and team at OW Chadstone are fab - I've been going to them for years and have alwa...ys had great results. They're proactive, reminding me of health cover benefits, and always put together the best package. Only on one occasion did I have a problem with my frames - I took them in (a discontinued frame), and Sue found a spare pair, fitted my lenses on the spot and I walked out with no cost. Highly recommend Oscar Wylee to anyone
See more
Jonathan Allen
8 months ago
Edward the optometrist has looked after my eyes for years. He is not only highly skilled but also pl...easant and informative to deal with. Couple that with the range and price point of frames and the helpful accomodating guy front of house why go anywhere else!
See more
Bejoy Machumpurath
8 months ago
Great experience with Ed at Oscar Wylee, who was very knowledgeable and reassuring. Picked up a grea...t deal as well!
See more
Fiona Tudor
8 months ago
Jill McIntyre
8 months ago
Sam Morris
9 months ago
Andrea Quinlan
9 months ago
I feel silly for going to other places before this. Oscar Wylee made everything quick, simple, and s...tress-free. The experience was smooth from start to finish, and I’m really happy with the process. Highly recommend!
See more
pimu
9 months ago
Both the lady at the front desk and the optometrist were exceptionally kind and helpful :) Glasses a...re a good price for 2 pairs, so long as you don't need anything extra added - otherwise the price adds up quickly with each extra customisation (thin lenses, blue light filter, etc.) a lot more fun/colourful frames than most other stores, and a wide variety of shapes too. Staff help you to pick glasses that will look good and suit your face.
They don't offer contact lenses, but that wasn't really an issue for me - plus they gave me a free tote bag, which was cute! (Felt like a good quality one too &lt;3)
See more
Lim Chinglang
9 months ago
Good service
Brenda Lam
10 months ago
Good service
Emma
10 months ago
Linda and kathleen are so great and friendly· Such two amazing girl in the store. Very welcome and p...rofessional. Thanks for text my eye pressure.
All the best please come to this store !!! Highly recommend
See more
Leora Elton
10 months ago
Staff were so lovely and helpful. Great range of glasses!
Susan Gilmour
10 months ago
Great experience! The optometrist was thorough and saw me as a walk in which was fabulous. Would def...initely choose this business again!
See more
## Find an Optometrist in Chadstone With Oscar Wylee
Located in the middle of the Fashion Capital, you can find our optometrists in Oscar Wylee Chadstone Shopping Centre neighbouring Oakleigh and Malvern East. The Mall has over 10,000 parking spaces, with the closest station a 20-minute walk away. Oscar Wylee Chadstone offers bulk billed eye tests to valid Medicare cardholders. Find your perfect specs here in any style, from modern trends to vintage classics. Our unique shopping experience will let you get your prescription renewed the same day you find your new favourite pair of glasses! 
Chadstone Shopping Centre is the biggest shopping centre in all of Australia, offering over 530 stores and 250 hotel rooms. The mall’s beautiful indoor design is already worth the long walk around the entire building, but with more than 20 million visitors every year, there’s bound to be something to match you and your brand-new frames. For those who live in the area, Oscar Wylee optometrists nearest to you include Oscar Wylee Southland and Oscar Wylee Chapel St. Visit the Oscar Wylee team for some of the best eye care processes in Chadstone, Australia.        
Meet Our Team
* Optometrist Partner
BVisSc
MOptom
Opthalmic Medicines Prescriber
* Retail Partner
Our Services
* Bulk Billed Eye Examinations
* Professional Frame Styling
* Frame Adjustments and Repairs
* Visual Fields Testing
* Digital Retinal Scanning
Show All
## Find an Optometrist in Chadstone, Melbourne for an Eye Health Test
An optometrist in Chadstone, Melbourne can provide optometry services such as an eye health test or prescription update. At Oscar Wylee Chadstone, we offer eye tests at a bulk billed price for valid Medicare cardholders. However, the average price range for an optometrist in Chadstone can vary depending on factors such as the patient’s age and overall health. We do not have an eye doctor in-store, although a patient will be referred to one if needed for more advanced care.
In-store at Oscar Wylee Chadstone, Melbourne, we have a great selection of frames in different colours, sizes and styles. We have an optical dispenser to provide professional styling and fitting so you can feel confident picking one of these frames for your optical glasses or prescription sunglasses. An eye health test in Chadstone will look at a patient’s vision and eye health to detect signs of eye diseases.
## How to Find an Optometrist in Chadstone, Melbourne?
To find an optometrist in Chadstone, Melbourne, you can take certain steps that can help make it easier for you such as searching online, assessing the store’s opening hours and finding the directions to your chosen location. The steps on how to find an optometrist in Chadstone are listed below.
1. Search online using the phrase, Chadstone optometrist near me. This can also be done here on the website via our locations page.
2. Click on the Oscar Wylee link, which will take you directly to our Chadstone optometrist store page.
3. See the store’s opening hours and where the store is located specifically.
4. Use the Chadstone Google Business page link located under store hours to see the directions on how to get to the store.
You can also find an optometrist in Chadstone, Melbourne by searching the keywords optometrist near me. If you have locations enabled on your smartphone and you’re in the Chadstone area, our Oscar Wylee Chadstone store page should appear easily for you to click on.
### Is it Hard to Get an Eye Appointment in Chadstone, Melbourne?
No, it is not hard to get an eye appointment in Chadstone. You can easily book an appointment to see an Oscar Wylee optometrist in Chadstone right here on this page. At Oscar Wylee we have highly qualified optometrists available for bulk billed eye appointments, which can be booked online, over the phone, or in-store.
#### How to Compare Optometrists in Chadstone to Each Other?
To compare optometrists in Chadstone, you can use factors such as eye tests offered, health fund coverage, lens types and add-ons and eyewear offered. To take care of your vision and eye health, it is important to receive an eye test at least once every two years. There are different types of tests that can be performed in an eye test and not all optometrists may offer the same tests. Health funds can be used to help cover some of the cost of your frames and lenses. To find out if your health fund is accepted at a Chadstone optometrist in Melbourne, visit their website. In the case of Oscar Wylee, we accept all major health funds and provide on-the-spot claims in-store. There are many different lens options available for prescription glasses such as single vision, multifocal and high index lenses. Most optometrists in Chadstone will offer these lenses although it is good to make sure. There are also lens add-ons available to enhance your glasses such as anti-reflective and blue light filters. Finally, if you are looking to purchase a pair of glasses after your eye test, you can compare the different styles and colours you are interested in from the optometrists in Chadstone, Melbourne. Oscar Wylee offers a wide range of frames with vintage and modern inspirations in bold colours and subtle designs.
#### How to Find an Eyeglasses Shop in Chadstone, Melbourne?
To find a glasses store in Chadstone, you can try to follow these simple steps including searching online, selecting a convenient location and looking at their health insurance policies. The steps on how to find a glasses store in Chadstone, Melbourne are listed below.
1. Search online using the phrase, glasses store in Chadstone. This will provide you with various options for glasses stores in the whole Chadstone, Melbourne area.
2. Select a glasses store that is most convenient for you to travel to.
3. Click the link to find out more information such as opening hours, exact location and directions to the glasses store in Chadstone.
4. Read their health insurance policies to ensure you know what health benefits you can access.
Our Oscar Wylee glasses store in Chadstone, Melbourne offers primary eye care services such as comprehensive eye tests as well as other services performed by an optometrist and offers prescription and non-prescription eyewear.
##### Is it Possible to Purchase Prescribed Sunglasses in Chadstone, Melbourne, Without Seeing an Optometrist?
Yes and no, it is possible to [purchase prescribed sunglasses](https://www.oscarwylee.com.au/sunglasses.html) in Chadstone, Melbourne without seeing an optometrist if you already have a prescription that has not expired. If your prescription is expired, you can book an eye test to receive an updated or new prescription which will require you to see an optometrist. This will ensure your prescription sunglasses are appropriate for your visual needs.
## Where is the Oscar Wylee Chadstone Optometrist Located in Melbourne?
The Oscar Wylee Chadstone optometrist is located at the Chadstone Shopping Centre, near Culture Kings. Chadstone is a suburb in Melbourne, approximately 14 km south-east of the Melbourne CBD.
### What is the Phone Number of Oscar Wylee Chadstone Optometrist Store?
The Oscar Wylee Chadstone optometrist store phone number is (03) 9972 6771. You can contact the Oscar Wylee Chadstone store between the hours of 9 am and 5:30 pm from Monday to Wednesday, 9 am and 9 pm on Thursdays and Fridays, 9 am and 7 pm on Saturdays and 10 am and 6:30 pm on Sundays.
### What are the Reviews for Oscar Wylee Chadstone Optometrist in Melbourne?
The many reviews for Oscar Wylee Chadstone optometrist in Melbourne, left by our various customers can be found here on the website and online when you search for Oscar Wylee Chadstone optometrist. The reviews for Oscar Wylee Chadstone optometrist are listed below.
* Hua Huang:  Very good and professional advice.
* Suzanne Chavasse:  The optometrist Eric, was brilliant. He was patient, knowledgeable and very helpful. Even came out to give me help choosing frames. Excellent service by all the staff at Chadstone.
* Glenda Steckoll:  Good service and great choice of frames.
* Alvin Lee:  Attentive to details and patiently explained by the optometrist and store keeper. Keep up the good work team!
#### What Treatments or Eye Care Processes are Done in the Oscar Wylee Chadstone Optometrist Location?
The treatments or eye care processes done in the Oscar Wylee Chadstone optometrist Melbourne location include a tonometry test, a digital photograph, a slit lamp exam and a refraction test. Additional tests that may also be performed can include a visual field test and a dilated fundus exam. The treatments or eye-care processes that are done in the Oscar Wylee Chadstone optometrist Melbourne location are listed below.
* A Tonometry Test: An optometrist or optical dispenser will conduct a tonometry test which involves the use of a machine that will release small puffs of air into your eyes. This will assist with measuring pressure in the eye.
* A Digital Photograph: An optometrist or optical dispenser may take a digital photograph of your eye which can be kept on record to use in future appointments to evaluate any changes to your eye.
* Slit Lamp Test: A slit lamp test can be used to evaluate your eye health, by examining your cornea and iris which are the anterior and posterior of the eye.
* Refraction Test: During a refraction test, an optometrist will have you view an image through different lenses and ask you to confirm which helps you see the image clearer.
* Visual Field Test: A visual field test can assist with assessing your peripheral vision, which may be beneficial for identifying any signs of glaucoma.
* Dilated Fundus Exam: A dilated fundus exam can help an optometrist assess your health in more detail by getting a clear view of the retina. This test is typically carried out for patients with diabetes and those who may be at risk of developing retinal damage.
## How Many Optometrists Exist in Chadstone, Melbourne?
There are many optometrists that exist in Chadstone, Melbourne to provide eye tests and glasses, including Oscar Wylee. The number of optometrists available in an area will typically depend on the population. At Oscar Wylee Chadstone, we offer excellent optometry services including eye tests performed by skilled optometrists using high-quality equipment. We also have a wide range of fashion-forward frames that customers can browse in a large selection of sizes and colours. If you’re looking for an optometrist in Chadstone, choose Oscar Wylee and we will take care of your optometry and eyewear needs.
### What are the Other Closest Optometrist Locations to Chadstone, Melbourne in Australia?
The other closest Oscar Wylee optometrist locations to Chadstone in Australia are Chapel St, Forest Hill and Southland. The locations and their distance from Chadstone are listed below.
* Chapel St:  Chapel St is close to Chadstone, around 10 km. The [Oscar Wylee Chapel St](https://www.oscarwylee.com.au/locations/optometrist-chapel-st.html) store is located in South Yarra near Aldi. Our Oscar Wylee store on Chapel St offers comprehensive eye tests and professional frame styling.
* Southland:  Southland is close to Chadstone, around 10 km. The [Oscar Wylee Southland](https://www.oscarwylee.com.au/locations/optometrist-southland.html) store is located in Westfield Southland in Cheltenham, near David Jones. Here you will find bulk billed eye tests and a wide range of fashionable eyewear to browse.
* Forest Hill:  Forest Hill is close to Chadstone, around 14 km. The [Oscar Wylee Forest Hill](https://www.oscarwylee.com.au/locations/optometrist-forest-hill.html) store is located in the Forest Hill Chase Shopping Centre, near Woolworths. You can visit Oscar Wylee Forest Hill for professional optometry services.
### Bulk Billing Available at Oscar Wylee
Choose Oscar Wylee Chadstone for your regular eye test. Our skilled optometrist can assess your vision, check your eye health for certain diseases, and provide an updated prescription. Oscar Wylee offers bulk billing on eye tests for those with a valid Medicare card. Our trained optometrists in Oscar Wylee Chadstone can update your prescription or issue a new one, usually in under 30 minutes so you can shop and order your glasses on the same day.
### Oscar Wylee Accepts Leading Health Funds
Oscar Wylee Chadstone accepts all leading health funds for those with a valid card. Visit us in-store and our staff and process your claim and provide an on-the-spot quote for frames and lenses. Oscar Wylee Chadstone helps our customers navigate the ins and outs of their insurance to make sure they get the best price every single time for prescription glasses and sunglasses.
### Frames for the Fashion-Forward at Chadstone
Here at our eyeglasses shop in Chadstone - Victoria’s Fashion Capital, Oscar Wylee offers prescription eyeglasses and prescription sunglasses in a variety of trendy and vintage styles. Get fitted by our experts in Oscar Wylee Chadstone for a frame that matches your style and compliments your face shape. Plus, you can customise your lenses with a number of add-ons including a blue light filter and anti-reflective coating.
Book Appointment
[Call us: (03) 9972 6771](tel:(03) 9972 6771)
[Leave a Review!](https://g.page/r/CTsvbuXKDLGBEBM/review)