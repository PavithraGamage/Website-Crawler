# Source: https://www.oscarwylee.com.au/nolan-sunglasses.html

# Nolan
1
## Frame Design of Nolan Sunglasses
The frame design of Oscar Wylee’s Nolan sunglasses is characterised by their square shape, low nose bridge and TR90 frame. Nolan is a wearable men’s glasses frame that will complement any outfit or event, day to night.
$169    
In stock
Only %1 left
2 pairs from $199
Discount auto-applied at checkout
3 pairs from $249
Discount auto-applied at checkout
* 2 &amp; 3 Pair pricing applies to non-prescription sunglasses only. Prescription sunglasses incur additional charges.    
[Non-Prescription](https://www.oscarwylee.com.au/nolan-sunglasses.html#)
Qty
Prescription
Book an eye test
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
excluding prescription lenses
## About Nolan Sunglasses
The beloved Nolan is back with more colour extensions to choose from! Made from the lightweight TR90, Nolan is the thrillseeker of the pack and the promise of new adventures to come.
| Frame fit | Measurements |
| --- | --- |
| WIDE | 58 - 17 - 134 |
These measurements mean lens width, bridge, and temple length in millimetres (mm). They can be found on the inside of the temple arm. If you already have a pair that you like, you can compare it to these measurements.
### Made from TR90
Oscar Wylee’s Nolan frame is a men’s square sunglasses frame that is perfect for those with round and oval face shapes. The Nolan frame is a sleek and versatile frame that can be worn everyday. The main specs of Oscar Wylee’s Nolan glasses frame, including dimensions, shape, materials, lenses, nose fit, and hinges, are listed below.
Filter category 2 (Fire Tortoise only) - General purpose sunglasses. Good protection against sunglare. Good UV Protection. Not suitable for driving in twilight, at night or under dull conditions
Filter category 3 (Frosted Slate, Navy Forest, and Obsidian Black Matte only) - General purpose sunglasses. High protection against sunglare. Good UV Protection. Not suitable for driving in twilight, at night or under dull conditions
This frame comes with polarised lenses. An additional $100 will be added to your order total for prescription orders.
| Nolan Frame Features | Nolan Frame Description | Dimensions | Shape | Materials | Lenses | Nose Fit | Hinges |
| --- | --- | --- | --- | --- | --- | --- | --- |
| The dimensions of the Nolan frame are measured in millimetres (mm) and are 58 - 17 - 134, meaning the lens width is 58 mm, the bridge is 17 mm, and the temple length is 134 mm. |
| Nolan is a square shape, well-suited to wide faces. |
| Nolan is made from TR90 with rubber temple tips. |
| The lenses that can be used in the Nolan frame are sunglass lenses, which provide UV protection. Prescription lenses are also available to purchase for the Nolan sunglass frame, both online and in-store. |
| The nose fit for Nolan is a low nose bridge fit. |
| The hinges in Nolan are normal hinges, also known as standard or barrel hinges. |
Show All
### What Inspired the Frame Design of Oscar Wylee's Nolan Glasses?
The Oscar Wylee Nolan frame design was inspired by current fashion trends, as square shapes are often in fashion. A square glasses shape is timeless, meaning it remains popular throughout the decades while other trends pass.
## What to Know About Oscar Wylee's Nolan Sunglasses?
There are many aspects of the Oscar Wylee Nolan frames that customers should know about, so they can decide whether this is the right frame for them. The Nolan frame is a men's square-shaped frame. Oscar Wylee's Nolan frame is suitable for many face shapes, but particularly compatible with round and oval face shapes. The Nolan frame's simple design makes them fashionable all year round. Nolan features the standard [parts of glasses](https://www.oscarwylee.com.au/glasses/eye/part-of-glasses), such as a rim, temples, lenses, hinges and a low nose bridge fit.
### What are the Types of Temple Tips or Earpieces Included with Oscar Wylee's Nolan Glasses?
The type of temple tips or earpieces included in Oscar Wylee's Nolan Glasses are made from rubber.
### What Type of Nose Bridge do Oscar Wylee's Nolan Glasses Have?
The type of nose bridge included in Oscar Wylee's Nolan frame is a low nose bridge fit.
### What Type of Nose Pads are Included with Oscar Wylee's Nolan Glasses?
Oscar Wylee's Nolan frame does not include adjustable silicone nose pads.
### What Type of Lenses do Oscar Wylee's Nolan Sunglasses Have?
The lenses that can be used in the Nolan frame are sunglass lenses, which provide UV protection. UV protection lenses block harmful ultraviolet rays, safeguarding eyes from damage. It comes in two filters: Filter Category 2 and Filter Category 3. Filter Category 2 is available for Fire Tortoise. These are general purpose sunglasses and provide good protection against sunglare. Filter Category 3 is available for Frosted Slate, Navy Forest, and Obsidian Black Matte only. This filter provides higher protection against sunglare. They are not suitable for use while driving at night. Prescription lenses are also available for the Nolan frame, both online and in-store.
### What Material is Used for the Rim of Oscar Wylee's Nolan Glasses?
The material used for the rim of Oscar Wylee's Nolan glasses frames is TR90. The rim refers to the part of a glasses frame that holds the lenses.
### What Type of Hinges are Included with Oscar Wylee's Nolan Glasses?
The type of hinges included with Oscar Wylee's Nolan frames are normal hinges. These provide strength and smooth movement connecting the frame's arms and lenses.
## What Face Types are Most Suitable for Oscar Wylee's Nolan Glasses?
The face types that are most suitable for Oscar Wylee's Nolan frame are round and oval face types. The Nolan frame is a square shape, meaning that it complements the structure of round and oval faces particularly well. The square Nolan frames help to balance the features of a [round face shape](https://www.oscarwylee.com.au/glasses/face-shapes/round) and an [oval face shape](https://www.oscarwylee.com.au/glasses/face-shapes/oval), bringing the eyes and brows forward in a flattering way. Although there are many [glasses for face shapes](https://www.oscarwylee.com.au/glasses/face-shapes) that may be considered more aesthetically suitable, it is important that people also choose the frames that make them feel most comfortable and represent their personal style.
## What Size Options are Available for Oscar Wylee's Nolan Glasses?
The size options available for Oscar Wylee's Nolan frame are a wide-fit frame across all colours.
## What Materials are Used to Create Oscar Wylee's Nolan Glasses?
The primary material used to create the Oscar Wylee Nolan frame is TR90. TR90 is a form of thermoplastic material, perfect for making flexible, durable, and lightweight glasses.
## What’s Included
## OW Case &amp; Cloth
Protective Case and Lens Cloth
Our high-quality glasses case and lens cloth are included with every purchase of an Oscar Wylee frame. The stylish, magnetic case is made from a hard shell. This sturdy and durable material keeps your glasses protected and safe, wherever you go. Ensure your lenses are clean and scratch-free with our OW microfibre cloth, specifically designed to ensure you have comfortable vision through your lenses.
Oscar Wylee offers:
* Free Shipping for Australian Orders
* 1 Year Warranty on frames and lenses
* Scratch resistance lens coating on all prescriptions
* UV-proof coating on all prescriptions
Health fund rebate: Once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. Learn more about [health funds](https://www.oscarwylee.com.au/health-funds.html).
## Make and Materials
Our TR90 glasses are for the adventurers! TR90 is a thermoplastic material renowned for its lightweight nature, durability and comfort. TR90 is produced through Swiss technology that allows it to be incredibly strong and tough to impact, perfect for the active wearer.The frames go through cleaning and strict quality control.After your frames have gone through the production process, they are individually examined and packed before making their way to you!
## Warranty Information
### Warranty Information
### Warranty Information
Oscar Wylee provides a 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects. We will repair or replace faulty or defective frames or lenses free of charge for warranty claims made within 1 year of the delivery. We also offer repairs or replacement for problems experienced with vision during everyday use for claims made within 30 days of delivery. If the same product has been discontinued or is no longer available, then we may offer an exchange for a similar product or a refund.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Find a Store Location](https://www.oscarwylee.com.au/locations/full-store-list.html)