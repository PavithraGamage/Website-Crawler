# Source: https://www.oscarwylee.com.au/

[](https://www.oscarwylee.com.au/glasses.html)
[](https://www.oscarwylee.com.au/booking)
[](https://www.oscarwylee.com.au/glasses.html)
[](https://www.oscarwylee.com.au/glasses.html)
[](https://www.oscarwylee.com.au/sunglasses.html)
[](https://www.oscarwylee.com.au/glasses/collection/serge-family)
[](https://www.oscarwylee.com.au/glasses.html)
# Look &amp; See with Oscar Wylee. Optometrist Bulk Billed Eye Tests.
## Bulk Billed Eye Test
We offer bulk billed comprehensive eye tests with skilled optometrists for valid Medicare cardholders, so there are no out-of-pocket expenses.
[Book an Eye Test](https://www.oscarwylee.com.au/booking)
## The Moderne Collection
Elevated everyday frames that embody contemporary styles made for your go-to look. Explore the Moderne Collection!
[Browse Collection](https://www.oscarwylee.com.au/glasses/collection/moderne.html)
Discover our range
[Women's Glasses](https://www.oscarwylee.com.au/glasses/womens-glasses.html) 
[Men's Glasses](https://www.oscarwylee.com.au/glasses/collection/mens-glasses.html) 
[Seniors Glasses](https://www.oscarwylee.com.au/glasses/collection/seniors.html) 
[Sunglasses](https://www.oscarwylee.com.au/sunglasses.html) 
All major [health funds](https://www.oscarwylee.com.au/health-funds.html)accepted in-store
Book an eye test near you
[search](https://www.oscarwylee.com.au/booking)
[Book appointment](https://www.oscarwylee.com.au/booking/)
Excellent Service with On-Trend Styles and Dedicated Optometrists!
[](https://www.oscarwylee.com.au/review)
Previous
☆ ☆ ☆ ☆ ☆
Jessica G | Broadway
Highly Recommend
Highly recommend!! Every staff member was knowledgeable, approachable and really helpful. I had everything explained to me clearly in the eye exam, I was fit in straight away and their lenses are all really good. Hard to choose. Great deals too! The best.
☆ ☆ ☆ ☆ ☆
Nikolai | Macquarie Centre
Friendly and Professional
The staff here are friendly and professional, elevating my shopping experience. The service is convenient and efficient, with quick assistance and the right equipment. The process was simple and fast, making it easy for me to find the perfect pair of glasses with helpful and thoughtful advice.
☆ ☆ ☆ ☆ ☆
Elena D | Warringah Mall
Best Experience in an Optometrist
This is the best experience I have ever had in an optometrist. The optometrist was very knowledgeable and gave me great advice.The staff at the shop were fantastic and didn't pressure me to spend more money than necessary like I have felt in other optometrists.The frames are gorgeous and ended up getting 2 pairs. Really good value for money as well. I'm very pleased with Oscar Wylee. Highly recommended.
☆ ☆ ☆ ☆ ☆
Sabera S | Burwood
Really Good Experience
I had a really good experience at Oscar Wylee Burwood. The staff were friendly and helpful, making it easy to find the right frames. The store has a nice atmosphere, and the optometrist was thorough and took the time to explain things properly. The whole process felt smooth and professional. I would definitely recommend!
☆ ☆ ☆ ☆ ☆
Bron S | Sunshine Plaza
First Eye Test went Really Well
First eye test with Oscar Wylee and it went really well. I had issues with glasses from another provider and with some different testing, found my script didn't need to be as strong. The selection of glasses is really good and reasonably priced.
☆ ☆ ☆ ☆ ☆
Cassandra M | Bendigo
Amazing Experience
I had an amazing experience at Oscar Wylee. The optometrist was incredibly experienced and picked up on things no one had noticed before. The staff were extremely helpful, guiding me through different glasses options and making sure I found the perfect pair. What really stood out was their kindness—when my baby started crying during my eye test, they went out of their way to help, making the whole process much easier. I highly recommend them for their expertise and outstanding service!
☆ ☆ ☆ ☆ ☆
Jan C | Mildura
Friendly, Patient and Professional
Very friendly, patient and professional front of store staff and a great optometrist. Can't wait to pick up my new glasses. Very impressed with the variety of frames offered especially for wide faces. Thank you!
☆ ☆ ☆ ☆ ☆
Georgie W | Rockingham
Great Service and Welcoming
First time visiting Oscar Wylee. Great service in Rockingham. The receptionist was welcoming and gave our little boy some colouring in. The optometrist was very professional and knowledgeable. Definitely visit again.
☆ ☆ ☆ ☆ ☆
Kirstie W | Canberra Centre
Always a Great Experience
Always a great experience visiting the team at the Civic centre in Canberra. Professional, friendly and very helpful. Looking forward to my new glasses and sunglasses
☆ ☆ ☆ ☆ ☆
Alex M | Marion
Great Experience from Eye Test to Buying Glasses
I had a great experience from my eye test all the way up to buying some glasses. Staff were incredibly friendly, didn't push you to buy any extra coatings if you didn't seem keen and gave great advice with frame types that fit your face. Will be my go to from now on!
Next
.customer-reviews {
width: 95%;
max-width: 1280px;
margin: auto;
box-sizing: border-box;
padding: 0 40px;
margin-top: -20px
}
.customer-reviews__header {
display: flex;
justify-content: space-between
}
.customer-reviews__header .header {
display: flex;
justify-content: space-between
}
.customer-reviews__header .header-title {
font-size: 2.5rem;
font-weight: 600;
align-self: center
}
.customer-reviews__header .header-certificate .image {
max-width: 120px;
height: auto
}
.customer-reviews .customer-reviews__header .header-certificate .image {
margin-top: 20px
}
.customer-reviews__main-content .main-content {
max-width: 1280px;
min-height: 300px;
opacity: 0
}
.customer-reviews__main-content .main-content.slick-initialized {
opacity: 1;
transition: opacity .3s ease-out
}
.customer-reviews__main-content .main-content.slick-initialized .rate {
display: block
}
.customer-reviews__main-content .main-content .slick-arrow {
border: none;
width: auto;
height: 100%
}
.customer-reviews__main-content .main-content .slick-arrow.slick-prev {
z-index: 1;
left: -50px
}
.customer-reviews__main-content .main-content .slick-arrow.slick-prev:before {
content: '\e906';
font-family: 'luma-icons';
color: #000;
font-size: 4rem;
font-weight: 700
}
.customer-reviews__main-content .main-content .slick-arrow.slick-prev.slick-disabled:before {
opacity: .5
}
.customer-reviews__main-content .main-content .slick-arrow.slick-next {
z-index: 1;
right: -48px
}
.customer-reviews__main-content .main-content .slick-arrow.slick-next:before {
content: '\e904';
color: #000;
font-size: 4rem;
font-weight: 700
}
.customer-reviews__main-content .main-content .slick-arrow.slick-next.slick-disabled:before {
opacity: .5
}
.customer-reviews__main-content .main-content .rate {
padding: 0 5rem;
display: none
}
.customer-reviews__main-content .main-content .rate__star .rating {
display: flex
}
.customer-reviews__main-content .main-content .rate__star .rating .star>label {
position: relative;
width: 1.1em;
font-size: 30px;
color: #f1e0c0;
cursor: pointer;
opacity: 1 !important
}
.customer-reviews__main-content .main-content .rate__star .rating .star.checked>label:before {
content: "\2605";
position: absolute;
opacity: 1
}
.customer-reviews__main-content .main-content .rate__owner {
font-size: 16px
}
.customer-reviews__main-content .main-content .rate__content .header {
font-size: 2.5rem;
margin-top: 2rem;
font-weight: 600
}
@media only screen and (max-width: 1023px) {
.customer-reviews__header {
margin: auto
}
.customer-reviews__header .header-title {
font-weight: 700;
padding-left: 10px
}
.customer-reviews__main-content .main-content {
max-width: 90%;
margin: auto
}
.customer-reviews__main-content .main-content .rate {
padding: 0 2rem
}
}
@media only screen and (max-width: 767px) {
.customer-reviews {
padding: unset;
margin-top: unset
}
.customer-reviews__header .header-title {
font-size: 2rem
}
.customer-reviews__header .header-certificate .image {
max-width: 80px;
margin-top: 15px
}
.customer-reviews__main-content .main-content .slick-arrow.slick-prev {
left: -30px
}
.customer-reviews__main-content .main-content .slick-arrow.slick-next {
right: -28px
}
.customer-reviews__main-content .main-content .rate {
padding: 0 4rem
}
}
.slick-track {
will-change: transform;
display: flex !important;
flex-wrap: nowrap !important;
opacity: 1 !important;
width: 6400px;
transition: transform 500ms;
transform: translateX(-4920px) !important;
}
Find an Optometrist Location
Optometrists in Australia provide bulk billed eye tests at any one of our
120+ locations.
Come visit us to have your eye health checked,
look out for eye problems or eye diseases, update your prescription, and
try on all of our glasses frames to find the perfect fit. Our in-store
stylists are here to help you find the right pair of glasses or
sunglasses.
Look and see with Oscar Wylee for quality optometry
services and on-trend eyewear.
[Optometrist](https://www.oscarwylee.com.au/locations/full-store-list.html) locations
Meet Our Serge Family
Our beloved Serge frame has been an enduring favourite, and the
family keeps growing! Read more about our bold and beautiful Serge
frames. We have one ready to suit every face!
[Explore the Serge Family](https://www.oscarwylee.com.au/glasses/collection/serge-family)
[](https://www.oscarwylee.com.au/glasses/collection/serge-family)
Upgrade With Anti-Reflective Lenses
Oscar Wylee’s Premium Anti-Reflective add-on is our highest quality
lens upgrade, providing reduced glare, increased clarity, and
protecting your lenses from scratches, smudges, and dust.
[Explore Anti-Reflective Lenses](https://www.oscarwylee.com.au/premium-anti-reflective)
[](https://www.oscarwylee.com.au/premium-anti-reflective)
Protect your child’s vision for the future with Stellest®
myopia control lenses
Stellest® myopia control lenses are designed to both
correct myopia and slow its progression in children and teenagers
when worn 12 hours a day1. By managing myopia early, you
can help support your child’s eyesight as they grow and learn.
[Explore Myopia Control](https://www.oscarwylee.com.au/myopia-control-lenses)
[](https://www.oscarwylee.com.au/myopia-control-lenses)
Design Your Perfect Pair
From high index and Transitions® lenses to specialised
coatings like BLULite and polarisation, you can easily customise
your Oscar Wylee frames to fit your lifestyle.
[Customise Your Frames](https://www.oscarwylee.com.au/customise-your-frames/)
[](https://www.oscarwylee.com.au/customise-your-frames/)
Styled by you
@oscarwylee
You wear it best. Show us how you style your frames and tag @oscarwylee for the chance to be featured.
Due for an eye test? Book now:
[Eye test near me](https://www.oscarwylee.com.au/booking)
We recommend that everyone should have an eye test with an optometrist at least once every 2 years.
Oscar Wylee offers bulk billed eye test, so there are no out-of-pocket expenses for eligible Medicare card holders.
Best Glasses for Women
[Learn More](https://www.oscarwylee.com.au/glasses/best-women)
Best Glasses for Men
[Learn More](https://www.oscarwylee.com.au/glasses/best-men-eyeglasses-for-every-face-shape)
Best Glasses for Different Face Shapes
[Learn More](https://www.oscarwylee.com.au/glasses/face-shapes)
Glasses for Round Faces
[Learn More](https://www.oscarwylee.com.au/glasses/face-shapes/round)
More Glasses and Eye Health Guides
[Bold Glasses](https://www.oscarwylee.com.au/glasses/collection/bold.html)
[Spring Hinge Glasses](https://www.oscarwylee.com.au/glasses/collection/spring-hinge.html)
[Square Glasses](https://www.oscarwylee.com.au/glasses/silhouette/square.html)
[Medium Size Glasses](https://www.oscarwylee.com.au/glasses/collection/medium-frame.html)
[7 Different Types of Eye Drops](https://www.oscarwylee.com.au/glasses/eye/types-of-eye-drops)
[Eye Twitching](https://www.oscarwylee.com.au/glasses/eye/twitching-definition)
[Understanding the Gunk in my Eyes](https://www.oscarwylee.com.au/glasses/eye/reason-of-eye-gunk)
[Best Glasses for Oval Face](https://www.oscarwylee.com.au/glasses/face-shapes/oval)
[Night Driving and Vision Glasses](https://www.oscarwylee.com.au/glasses/night-driving)
[Blue Light Glasses](https://www.oscarwylee.com.au/glasses/eye/blue-light)
[Checkup Eye Test](https://www.oscarwylee.com.au/glasses/eye/check-up)
[Multifocal Lenses](https://www.oscarwylee.com.au/glasses/eye/multifocal-lenses)