# Source: https://www.oscarwylee.com.au/glasses/eye/anatomy/photoreceptor

# Photoreceptors: Function, Types, and How to Care for Them
Published on June 28th, 2024
Updated on Month Date, 2025 
Australia
[Australia](https://www.oscarwylee.com.au/glasses/eye/anatomy/photoreceptor)
New Zealand

[Canada](https://oscarwylee.ca/glasses/eye/anatomy/photoreceptor)
Canadian French

Photoreceptors refer to the
light-sensitive cells in the retina that help turn the light the eye sees
into electrical images, that then get sent to the brain to form the images
we see. The two main types of photoreceptors are rod cells and cone cells. Cone
cells are responsible for colour vision and rod cells are responsible for
helping us see in low light conditions. Photoreceptors are an important part
of how the eye sees light. Damage to the photoreceptors due to conditions
such as retinitis pigmentosa can impact how well the retina responds to
light and affect vision. It is therefore important to take care of your
eyes, which includes the photoreceptors, to reduce the risk of damage to the
photoreceptors. The ways to take care of the eyes and in turn, the
photoreceptors include getting regular eye tests, eating a healthy and
balanced diet, exercising regularly and not smoking. Keep reading to learn
more about
Prioritise Your Eye Health at Oscar Wylee
Oscar Wylee optometrists are available to perform bulk billed eye tests,
with no out-of-pocket expenses for eligible Medicare cardholders.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Definition](#definition) [Function](#function)
[Types](#types) [Eye Conditions](#conditions)
[Care](#care)
## What are Photoreceptors?
Photoreceptors are
cells in the retina that detect light and turn this light into
electrical signals that are then sent to the brain.
The
[retina](https://www.oscarwylee.com.au/glasses/eye/anatomy/retina)
is the light-sensitive layer at the back of the eye. There are two main
types of photoreceptors; cone cells and rod cells. Cone cells are
responsible for colour vision. Rod cells help people to see in low light
conditions.
### Where are Photoreceptors Located?
Photoreceptors are located in the retina. The retina is a
light-sensitive layer of tissue at the back of the eye. The retina is
responsible for sensing light and turning this light into electrical
signals that are sent to the brain so a person can see. Cone cells are
located in the macula, an area at the retina's centre. The rod cells
are located towards the retina's periphery and are not found in the
macula.
### What is the Function of Photoreceptors?
The function of photoreceptors is
to help the retina turn light that the eye sees into electrical
signals. These electrical signals are then sent to the brain via the optic
nerve so we can see. Each type of photoreceptor has its own individual
role in helping a person see. The rods' main function is to help
people see in low light conditions, as well as see peripherally. The
main function of cone cells is to provide colour vision.
#### How do Photoreceptors React to Light?
Photoreceptors react to light
through a process called phototransduction. When light hits
the photoreceptors, proteins located in the rods and the cells
change this light into electrical signals to be sent to the brain.
Phototransduction is the process by which a photon of light is
converted into an electrical signal, according to Science Direct.
Find an Oscar Wylee Store Near You
Come and visit your local Oscar Wylee store where our friendly team
will help you shop our range of stylish and affordable frames, and
assist with your eye care needs.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
## What are the Types of Photoreceptors?
There are two types of photoreceptors found in the retina;
rod cells and cone cells. According to the American Academy of
Ophthalmology, the retina has approximately 120 million rods and 6
million cones. Both rod cells and cone cells contribute to the process
of converting light into electrical signals, that are then sent to the
brain to help us see. The type of photoreceptors and their functions are
listed below.
* Cone cells:  Cone cells are a type of
photoreceptor that provides colour vision.
* Rod cells:  Rod cells are a type of
photoreceptor that provide vision in low light conditions as well as
peripheral vision.
### 1. Cone Cells
Cone cells are
a type of photoreceptor that are responsible for colour vision.
[Cones cells](https://www.oscarwylee.com.au/glasses/eye/cone-cells)
are distributed throughout the retina but are concentrated most
densely in the macula. The macula is an area located in the centre of
the retina, responsible for central vision. There are three different
types of cones cells, L cones, S cones and M cones, each responsible
for detecting different colours. L cones or red-sensing cones help the
eyes detect red colours. S cones or blue-sensing cones, are
responsible for detecting blue colours. M cones or green-sensing cones
help detect green colours.
### 2. Rod Cells
Rod cells are a
type of photoreceptor responsible for providing vision in low-light
conditions.
[Rod cells](https://www.oscarwylee.com.au/glasses/eye/anatomy/rod-cells)
are sensitive to light levels and work by processing a single photon
of light that enters the eye during dim-light conditions. Rod cells
are located on the outer edges of the retina.
## What Eye Conditions Can Affect the Photoreceptors?
There are several eye conditions that can affect the photoreceptors
including
retinitis pigmentosa, cone dystrophy and colour blindness. The
eye conditions that can affect photoreceptors are listed below.
* Retinitis Pigmentosa: Retinitis
pigmentosa is a group of eye conditions that affect the retina,
causing its cells to gradually break down. Retinitis pigmentosa
changes how the retina responds to light and causes vision issues or
vision loss. Symptoms of retinitis pigmentosa include loss of
peripheral vision, loss of night vision, or loss of central vision.
* Cone Dystrophy:  Cone dystrophy refers
to a group of rare eye disorders that affect the cone cells. Cone
dystrophy can cause symptoms such as decreased visual acuity, lack of
colour perception and light sensitivity.
* Colour Blindness:  Colour blindness is
an eye condition in which a person struggles to distinguish between
certain colours.
## What Tests Can Be Done to Check Photoreceptors?
The main test used to check whether the photoreceptors are working
properly is called an
electroretinogram or an electroretinography. An electroretinogram
measures the electrical response of the light-sensitive cells in the
retina, or the rods and cones. According to the Mount Sinai Medical
Organisation, an electroretinogram works by placing an electrical sensor
or electrode on the eye which measures how the eye reacts to light
stimulus. A light will then flash and the electrode will send the eye
activity to a computer-like monitor. Another test that can be done to
check how the photoreceptors are working, specifically cone cells, is a
[colour vision test](https://www.oscarwylee.com.au/glasses/eye/test/colour-vision-test). Issues with the cone cells may lead to colour blindness or colour
vision deficiency. If a person is having trouble distinguishing colours,
an optometrist may conduct a colour vision test. Colour vision tests can
include the Ishihara test (colour plate test) and a colour hue test
(colour arrangement test).
## How to Take Care of Photoreceptors?
The way to take care of photoreceptors is to take care of eye health in
general. The ways to take care of the health of your eyes, including the
photoreceptors, are to get
regular eye tests, eat a healthy and balanced diet, exercise
regularly and not smoke. The ways to take care of the photoreceptors are listed below.
* Regular eye tests: Regular eye tests
are a hugely important part of taking care of the overall health of
the eyes, including the photoreceptors. Regular eye tests allow your
optometrist to assess vision and the health of the eye, as well as
detect, diagnose and monitor possible eye conditions.
* Eating a healthy and balanced diet: 
Eating a balanced diet is a way to take care of the eyes, including
the photoreceptors. A healthy and balanced diet is described as a diet
that is high in fruits and vegetables, whole foods, proteins and
healthy fats. A healthy and balanced diet is good for your overall
health and provides important nutrients to the eyes.
* Exercise regularly:  Exercising
regularly, whether walking, running, pilates or playing sports, is a
good way to take care of overall health, including the health of the
eyes and photoreceptors. Regular exercise helps reduce the risk of
developing health conditions and eye conditions such as age-related
macular degeneration (AMD).
* Not smoking:  Not smoking is a way to
take care of your overall health, as well as being of huge benefit to
the eye, including the photoreceptors. Smoking has been linked to
reduced eye functionality and an increased risk of several eye
diseases, including age-related macular degeneration (AMD) and
cataracts. Quitting smoking if you smoke, or not starting, is a good
way to take care of the health of the eyes and the photoreceptors.
### What Happens If Photoreceptors Are Damaged?
If photoreceptors are damaged, it
can impact how the retina reacts to light and impact a person’s
[vision](https://www.oscarwylee.com.au/glasses/eye/perfect-vision). According to The Centre for Eye Research Australia, loss or
degeneration of photoreceptors is one of the most common causes of
blindness in the Western world. Eye conditions that can damage the
retina and the photoreceptors include retinitis pigmentosa.
### How Does Vitamin A Impact Photoreceptors?
Vitamin A has been
shown to have a positive impact on photoreceptors. According to
Crouch, Cono and Tang in the paper,
Role in Vitamin A in Retinal Diseases, vitamin A helps to form
photosensitive pigments that absorb light in the eye, as well as help
to maintain the structural integrity of the retina.
Read Photoreceptors: Function, Types, and How to Care for Them in
other Oscar Wylee regions and their languages.
Australia
[Australia](https://www.oscarwylee.com.au/glasses/eye/anatomy/photoreceptor)
New Zealand

[Canada](https://oscarwylee.ca/glasses/eye/anatomy/photoreceptor)
Canadian French

Are you Due for an Eye Test?
Oscar Wylee offers bulk billed eye tests, so there are no
out-of-pocket expenses for eligible Medicare cardholders.
[Book an Eye Test](https://www.oscarwylee.com.au/booking)
Oscar Wylee Accepts Major Health Funds In-store
Visit Oscar Wylee in-store for eye care services and your health fund
may help cover some of the cost.
[Explore Health Funds](https://www.oscarwylee.com.au/health-funds.html)