# Source: https://www.oscarwylee.com.au/serge-l-optical.html

# Serge Large
1
## Frame Design of Serge Large Glasses
The frame design of Oscar Wylee’s Serge Large glasses is characterised by their square shape, low nose bridge and acetate frame. Serge Large is a unisex, striking glasses frame that will complement any outfit, day to night.
$169    
In stock
Only %1 left
2 pairs from $199
Discount auto-applied at checkout
3 pairs from $249
Discount auto-applied at checkout
Qty
Add to cart
Book an eye test
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
excluding prescription lenses
## About Serge Large Frames
We’ve taken our bestselling Serge and given it an upgrade. This square, modern frame has a bold, unisex profile that now comes in a larger size.
| Frame fit | Measurements |
| --- | --- |
| WIDE | 56 - 21 - 145 |
These measurements mean lens width, bridge, and temple length in millimetres (mm). They can be found on the inside of the temple arm. If you already have a pair that you like, you can compare it to these measurements.
### Made from Acetate
Oscar Wylee's Serge Large frame is a unisex, square glasses frame that is perfect for those with round and oval face shapes. The Serge Large frame is a modern, statement frame that can be worn every day. The main specs of Oscar Wylee's Serge Large glasses frame, including dimensions, shape, materials, lenses, nose fit and hinges are listed below.
| Serge Large Frame Features | Serge Large Frame Description | Dimensions | Shape | Materials | Lenses | Nose Fit | Hinges |
| --- | --- | --- | --- | --- | --- | --- | --- |
| The dimensions of the Serge Large frame are measured in millimetres (mm) and are 56 - 21 - 145, meaning the lens width is 56 mm, the bridge is 21 mm, and the temple length is 145 mm. |
| Serge Large is a square shape with a bold rim, well suited to wide faces. |
| Serge Large is made from acetate. |
| The lenses that can be used in the Serge Large frame are optical lenses, which include single vision and multifocal lenses and non-prescription lenses, which are plain and can have a filter like a blue light filter applied. |
| The nose fit for Serge Large is a low nose bridge fit. |
| The hinges in Serge Large are spring hinges, which are more flexible than other types of hinges and can extend past 90 degrees. |
Show All
### What Inspired the Frame Design of Oscar Wylee's Serge Large Glasses?
The Oscar Wylee Serge Large frame design was inspired by modern, of-the-moment shapes, as opposed to vintage references. Named after the French musician, Serge Gainsbourg, the Serge frame embodies a modern and trendy style.
## What to Know About Oscar Wylee's Serge Large Glasses?
There are many aspects of the Oscar Wylee Serge Large frames that customers should know about, so they can decide whether this is the right frame for them. The Serge Large frame is a unisex, bold, wide-fit, square-shaped glasses frame. Oscar Wylee's Serge Large frame is suitable for many face shapes, but particularly compatible with round and oval face shapes due to its blocky, square shape. Serge Large features the standard [parts of glasses](https://www.oscarwylee.com.au/glasses/eye/part-of-glasses) such as a rim, temples, lenses, spring hinge and a low nose bridge.
### What are the Types of Temple Tips or Earpieces Included with Oscar Wylee's Serge Large Glasses?
The type of temple tips or earpieces included in Oscar Wylee's Serge Large Glasses are made from acetate.
### What Type of Nose Bridge do Oscar Wylee's Serge Large Glasses Have?
The type of nose bridge included in Oscar Wylee's Serge Large frame is a low nose bridge fit.
### What Type of Nose Pads are Included with Oscar Wylee's Serge Large Glasses?
Oscar Wylee's Serge Large frame does not include adjustable silicone nose pads.
### What Type of Lenses do Oscar Wylee's Serge Large Glasses Have?
The type of lenses that typically come with the Oscar Wylee Serge Large [glasses frame](https://www.oscarwylee.com.au/glasses.html) are optical lenses. Optical lenses are glasses lenses that have a prescription within the lens to help correct vision issues such as myopia, hyperopia and astigmatism. Serge Large can also come with non-prescription lenses, with add-ons such as a blue light filter. Serge Large frames are currently unavailable as sunglasses online, however, customers can customise in-store and add on tint or polarisation.
### What Material is Used for the Rim of Oscar Wylee's Serge Large Glasses?
The material used for the rim of Oscar Wylee's Serge Large glasses frames is acetate. The rim refers to the part of a glasses frame that holds the lenses.
### What Type of Hinges are Included with Oscar Wylee's Serge Large Glasses?
The type of hinges included with Oscar Wylee's Serge Large frames are spring hinges. A spring hinge in a glasses frame refers to hinges that are more flexible than normal hinges and can go slightly beyond 90 degrees. Spring hinges can provide a closer fit to the face.
## What Face Types are Most Suitable for Oscar Wylee's Serge Large Glasses?
The face types that are most suitable for Oscar Wylee's Serge Large frame are round and oval face types. The Serge Large frame is a bold square shape, meaning that it complements the structure of round and oval faces particularly well. The square Serge frames help to balance the features of a [round face shape](https://www.oscarwylee.com.au/glasses/face-shapes/round) or an [oval face shape](https://www.oscarwylee.com.au/glasses/face-shapes/oval), bringing the eyes and brows forward in a flattering way. Although there are many [glasses for face shapes](https://www.oscarwylee.com.au/glasses/face-shapes) that may be considered more aesthetically suitable, it is important that people also choose the frames that make them feel most comfortable and represent their personal style.
## What Size Options are Available for Oscar Wylee's Serge Large Glasses?
The size options available for Oscar Wylee's Serge Large frame are a wide-frame fit across all colours. This frame is also available as Serge Small and Serge, which is the regular size.
## What Materials are Used to Create Oscar Wylee's Serge Large Glasses?
The primary material used to create the Oscar Wylee Serge Large frame is acetate. Acetate, also known as cellulose acetate, is a bioplastic, made from cotton fibres or wood pulp. At Oscar Wylee, acetate glasses are made by adding a dye to cellulose acetate, which is rolled into a sheet. The shape of the glasses is then cut from this sheet.
## What’s Included
## OW Case &amp; Cloth
Protective Case and Lens Cloth
Our high-quality glasses case and lens cloth are included with every purchase of an Oscar Wylee frame. The stylish, magnetic case is made from a hard shell. This sturdy and durable material keeps your glasses protected and safe, wherever you go. Ensure your lenses are clean and scratch-free with our OW microfibre cloth, specifically designed to ensure you have comfortable vision through your lenses.
Oscar Wylee offers:
* Free Shipping for Australian Orders
* 1 Year Warranty on frames and lenses
* Scratch resistance lens coating on all prescriptions
* UV-proof coating on all prescriptions
Health fund rebate: Once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. Learn more about [health funds](https://www.oscarwylee.com.au/health-funds.html).
## Make and Materials
Also known as cellulose acetate, these frames are traditionally hand-crafted by skilled craftsmen, with each frame passing through numerous stages of production and are hand-polished to ensure a glorious lustre.
The frames then go through cleaning and strict quality control, and many pairs of crafting hands to be hand-assembled and polished. After your frames have gone through the production process, they are individually examined and packed before making their way to you!
## Warranty Information
### Warranty Information
### Warranty Information
Oscar Wylee provides a 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects. We will repair or replace faulty or defective frames or lenses free of charge for warranty claims made within 1 year of the delivery. We also offer repairs or replacement for problems experienced with vision during everyday use for claims made within 30 days of delivery. If the same product has been discontinued or is no longer available, then we may offer an exchange for a similar product or a refund.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Find a Store Location](https://www.oscarwylee.com.au/locations/full-store-list.html)