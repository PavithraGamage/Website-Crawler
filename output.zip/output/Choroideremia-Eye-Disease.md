# Source: https://www.oscarwylee.com.au/glasses/eye/choroideremia

# Choroideremia Eye Disease
Published on May 18th, 2026
Choroideremia eye disease is an inherited retinal condition that can cause vision loss. The vision loss is caused by damage to the photoreceptor cells in the retina due to damage to the choroid. Choroideremia can be characterised by a white patchy appearance of the retina as a result of the choroidal layer thinning, according to Retina Australia. This condition can be caused by mutations in a gene called CHM, which is a gene that is responsible for creating a protein essential for the maintenance of healthy cells in the retina. Choroideremia symptoms can include trouble seeing at night, vision loss and light sensitivity that is irreversible. The contents of this article are for informational purposes only and should not be used to participate in any self-diagnosis. If you are concerned, it is important to see your optometrist for a comprehensive examination.
Stay on top of your eye health!
It is recommended to get an eye test at least once every 1-2 years unless advised otherwise by an optometrist.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Definition](#definition) [Causes](#causes) [Symptoms](#symptoms) [Treatment](#treatment)
## What is Choroideremia Eye Disease?
Choroideremia is a rare genetic eye disease that can cause blindness. Choroideremia causes the choroid, retinal pigment epithelium and photoreceptors to degenerate, according to the Retina Associates. This [eye disease](https://www.oscarwylee.com.au/glasses/eye/health) does not have any treatments, but symptoms may be managed with sunglasses to prevent discomfort from increased light sensitivity.
### How is Choroideremia Defined as a Genetic Eye Disease?
Choroideremia is defined as a genetic eye disease that individuals can inherit through X-linked inheritance, according to Retina Australia. Females are carriers of the disease, but may not typically present with notable symptoms. Males possess only one X chromosome, which means a male will likely become affected if he is born with a faulty copy of the gene, according to Retina Australia.
#### Is Choroideremia a Rare Eye Disease?
Yes, choroideremia is considered a rare eye disease. Choroideremia may be classed as a [rare eye disease](https://www.oscarwylee.com.au/glasses/eye/rare-genetic-eye-diseases) because the prevalence rate is 1 in 3000, according to Dr Thomas Edwards in his article for the University of Tasmania, titled 'A Vision for the Future'.
## How does Choroideremia Affect the Choroid of the Eye?
Choroideremia may affect the choroid of the eye by causing it to degenerate or thin, which is then what causes loss of vision. The [choroid](https://www.oscarwylee.com.au/glasses/eye/choroid) constitutes the middle layer of the retina and supplies the outer layers of the retina with oxygen and nutrients, maintaining eye pressure.
### What Role Does the Choroid Play in Vision?
The role that the choroid plays in vision is crucial, as it provides the outer retina with oxygen and nutrients. According to Nickla and Wallman (2009), the choroid also aids in preserving the eye's blood circulation and is a notable vascular layer of the eye.
#### Does Damage to the Choroid Lead to Blindness?
Yes, damage to the choroid can lead to blindness. Damage to the choroid can lead to [vision impairment and blindness](https://www.oscarwylee.com.au/glasses/eye/visual-impairment), as this layer of the eye is responsible for supplying oxygen and nutrients to the retina. Therefore, damage from causes such as other eye conditions, inflammation and physical trauma can disrupt the normal function of the choroid.
## What Causes Choroideremia?
The cause of choroideremia can include mutations in the X-linked CHM gene, which can be found on the X chromosome. Choroideremia may primarily affect males since this gene is positioned on the X chromosome. In a healthy eye, the CHM gene produces a protein known as REP-1. This protein helps filter important nutrients and waste products in and out of the cells. When a gene mutation occurs, the body cannot create enough of this protein, which can cause the photoreceptors and the choroid to deteriorate from the lack of nutrients supplied.
## How is Choroideremia Inherited in Families?
Choroideremia is inherited in families through the X-linked pattern. Females have two X chromosomes, so if one X chromosome has a mutated gene and the other is normal, they may be considered carriers. Males have only one X chromosome, and therefore, if their one X chromosome possesses the faulty gene, they may develop choroideremia.
#### Is Choroideremia a Hereditary Eye Disease That Causes Blindness?
Yes, choroideremia is a hereditary eye disease that can cause blindness. Choroideremia can stem from mutations in the CHM gene and may primarily affect males more than females, according to Mitsios et al. (2018).
Visit us in-store!
See our team and optometrist in-store for any of your eyecare needs.
[Find a store](https://www.oscarwylee.com.au/locations/)
## What are the Early Signs of Choroideremia?
The early signs of choroideremia may include night blindness and peripheral vision loss. Choroideremia may lead to night blindness as an early sign, which may come about in childhood or early adulthood, according to the Choroideremia Research Foundation. Individuals may often report experiencing loss of vision that progresses to peripheral vision loss, according to Brambati et al. (2019).
### How does Night Vision Decline in This Condition?
Night vision may decline in this condition due to damage to the choroid, which is essential for providing oxygen and nutrients to the retina. When the photoreceptors in the retina are compromised or damaged, night vision may decline.
#### Does Peripheral Vision Loss Happen First?
No, peripheral vision loss may not happen first when experiencing choroideremia. According to Lam et al. (2021), peripheral vision loss can arise in diagnosed patients as their condition progresses, so they may have trouble seeing at night first. However, this can differ between patients depending on the severity of their condition and other factors.
## How does Choroideremia Progress Over Time?
Choroideremia can progress over time from [night blindness](https://www.oscarwylee.com.au/glasses/eye/night-blindness) to peripheral vision loss, depending on the severity of one's condition. The nature of progression will vary between patients, so there may not be a definitive progression rate for choroideremia.
#### Can Choroideremia Lead to Complete Blindness?
Yes, choroideremia can lead to complete blindness. According to Pennes et al. (2019), choroideremia may inevitably lead to blindness as the vision loss is progressive. It is also stated that males diagnosed with the disease report trouble seeing at night during their first or second decade of life, followed by more noticeable peripheral vision loss in their 20s.
### What Symptoms Overlap With Retinitis Pigmentosa and Similar Conditions?
The symptom that can overlap with retinitis pigmentosa and similar conditions is poor night vision and loss of peripheral vision. Retinitis pigmentosa can cause individuals to experience difficulty seeing at night or in low light conditions during childhood or early adolescence, according to MedlinePlus.
## What Treatment Options are Available for Choroideremia?
There are currently no treatment options available for choroideremia. However, there may be effective gene-supplementation methods for gene therapy, which have been shown to help with slowing the degeneration in some cases, according to the Centre for Eye Research Australia. Other helpful methods, such as low vision aids or wearing sunglasses for UV protection, can aid in managing the condition.
### How is Gene Therapy Being Used in Choroideremia Treatment?
Gene therapy may be used in choroideremia treatment as therapy focuses on providing a healthy copy of the gene into retinal cells, typically by using viral vectors like adeno-associated virus, according to Elsayed et al., (2025) in their research paper titled Gene Therapy For Choroideremia: Progress, Potential and Pitfalls.
## Why is Light Sensitivity Significant for People With Choroideremia?
Light sensitivity may be more significant for people with choroideremia as a result of the damage to the photoreceptor cells in the retina. This is why it is typically recommended that patients with potentially increased [light sensitivity](https://www.oscarwylee.com.au/glasses/eye/light-sensitivity) always wear sunglasses with proper UV protection.
### How can Sunglasses Help Reduce Discomfort from Bright Light?
Sunglasses can help reduce discomfort from bright lights as they aid in reducing high amounts of visible light from reaching your eyes. You can ask the optometrist for their recommendation for the right [sunglasses](https://www.oscarwylee.com.au/glasses/eye/sunglasses) frame to ensure optimal protection from bright light.
#### Do UV-Blocking Lenses Protect Light-Sensitive Eyes?
Yes, and no, UV-blocking lenses can help protect light-sensitive eyes if they are also tinted with dark lenses. UV-blocking lenses will help protect the eyes from the sun's harmful UV rays and reduce the risk of damage. However, to shield sensitive eyes from bright lights, dark sunglasses may be more effective in eliminating visible bright light.
## Which Prescription Glasses Support Vision in Choroideremia?
There aren't specific prescription glasses that support vision in choroideremia. However, the eye care professional who is assisting you with your condition will be able to advise you on what can best support your vision during choroideremia. The right [prescription glasses](https://www.oscarwylee.com.au/glasses/prescription) will depend on the extent of your condition and vision.
#### What Should Women Look for in Sunglasses and Glasses for Light Sensitivity?
Women should look for tinted lenses, polarisation and photochromic lenses in sunglasses for light sensitivity. However, it is important to note that there aren't any specific women's glasses that can help with light sensitivity in choroideremia. An ideal option for [women's sunglasses](https://www.oscarwylee.com.au/sunglasses/collection/womens-sunglasses.html) is sunglasses or prescription glasses that feature both optimal protection from the sun and proper UV protection. The factors that women should look for in sunglasses and glasses for light sensitivity are listed below.
* Tinted Lenses: Tinted lenses aid in reducing bright visible light from reaching the eyes and may prevent the discomfort and/or need to squint for those whose eyes may be more sensitive.
* Polarised Lenses: Polarised lenses are also an effective add-on option that can eliminate glare from reflective surfaces and excessive brightness during sunny conditions.
* Photochromic Lenses: Photochromic lenses are a helpful lens option for those with light sensitivity, as they can provide glasses that shift from clear to dark lenses according to the level of sunlight in your environment.
#### Are Wider Frames Better for Blocking Excess Light?
Yes, wider frames may be better for blocking excess light as they can cover more of the facial area. The sun's UV light rays can cause damage to the eyes and the skin surrounding them, making wider frames an optimal choice for blocking excess light.
## Which Men's Glasses Help With Light Sensitivity in Choroideremia?
There aren't any specific men's glasses that can help with light sensitivity in choroideremia. However, ensuring you wear sunglasses with dark lenses, choosing polarised glasses or photochromic glasses to reduce the bright light from sunny weather may help mitigate light sensitivity. Choosing the right [men's sunglasses](https://www.oscarwylee.com.au/glasses/collection/mens-glasses.html) should depend on your personal preferences and style, and what is advised by your optometrist for your condition.
### What Features Should Men Consider in Sunglasses and Prescription Frames?
The features that men should consider in sunglasses and prescription frames are dark lenses, polarised lenses and photochromic lenses. The features that men should consider in sunglasses and prescription frames are listed below.
* Dark Lenses: Dark lenses are an important feature to consider in sunglasses and prescription frames for choroideremia, as they can aid in reducing excessive visible brightness for patients who may have increased light sensitivity.
* Polarised Lenses: Polarised lenses are important to consider in sunglasses, as this can also significantly aid in eliminating glare from reflective surfaces and excessive brightness during sunny weather. This can help prevent discomfort for those with light sensitivity.
* Photochromic Lenses: Photochromic lenses are a considerable feature in sunglasses and prescription frames as they can shift from clear to dark lenses in response to the light in your environment. This can remove the need to carry more than one pair of frames and ensure sun protection.
#### Can Polarised Lenses Improve Outdoor Vision Comfort?
Yes, polarised lenses can improve outdoor vision comfort as they reduce glare from reflective surfaces and extra brightness that can occur during sunny weather. Wearing [polarised sunglasses](https://www.oscarwylee.com.au/glasses/eye/polarised-lenses) can prevent the need to squint when outdoors, enhancing clarity and comfort for your eyes. Those with choroideremia and increased light sensitivity as a result may find polarised lenses beneficial, but it won't likely help with other symptoms.
## How can the Risk of Choroideremia be Reduced in Families?
The risk of choroideremia cannot be necessarily reduced in families, as it is an inherited disease. However, it is important to get your eyes tested if you are experiencing any changes to your vision, and if a family member is diagnosed with choroideremia, it is strongly recommended that other members of your family get their eyes tested by an optometrist or an ophthalmologist, according to Retina Australia.
Experience Quality Eye Care!
We have knowledgeable optometrists at Oscar Wylee, who are available in-store to perform high-quality eye tests.
[Book an eye test](https://www.oscarwylee.com.au/booking)
Oscar Wylee Accepts Major Health Funds In-store
Visit Oscar Wylee in-store for eye care and eye wear services, and your health fund may help cover some of the cost.
[Explore health funds](https://www.oscarwylee.com.au/health-funds.html)