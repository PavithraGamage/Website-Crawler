# Source: https://www.oscarwylee.com.au/mirae-optical.html

# Mirae
1
## Frame Design of Mirae Glasses
The frame design of Oscar Wylee’s Mirae glasses is characterised by their classic shape, high nose bridge, and ultra light acetate and stainless steel frame. Mirae is a versatile women's glasses frame that will complement any outfit, day to night.
$169    
In stock
Only %1 left
2 pairs from $199
Discount auto-applied at checkout
3 pairs from $249
Discount auto-applied at checkout
Qty
Add to cart
Book an eye test
Health fund rebate: once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. [Learn more.](https://www.oscarwylee.com.au/health-funds.html)
excluding prescription lenses
## About Mirae Glasses
Mirae’s classic shape offers intentionally smooth curves in a thin profile for a minimal piece.
| Frame fit | Measurements |
| --- | --- |
| MEDIUM | 51 - 17 - 145 |
These measurements mean lens width, bridge, and temple length in millimetres (mm). They can be found on the inside of the temple arm. If you already have a pair that you like, you can compare it to these measurements.
### Made from Acetate and Stainless Steel
Oscar Wylee’s Mirae frame is a women's classic glasses frame that is perfect for those with square, oval, and pear face shapes. The Mirae frame is a sleek, ultra light frame that can be worn every day. The main specs of Oscar Wylee’s Mirae glasses frame, including dimensions, shape, materials, lenses, nose fit, and hinges are listed below.
| Mirae Frame Features | Mirae Frame Description | Dimensions | Shape | Materials | Lenses | Nose Fit | Hinges |
| --- | --- | --- | --- | --- | --- | --- | --- |
| The dimensions of the Mirae frame are measured in millimetres (mm) and are 51 - 17 - 145, meaning the lens width is 51 mm, the bridge is 17 mm, and the temple length is 145 mm. |
| Mirae is a classic shape, well-suited to medium faces. |
| Mirae is made from acetate and stainless steel. |
| The lenses that can be used in the Mirae frame include optical lenses, such as single-vision and multifocal, and non-prescription lenses, which are plain and can have a filter, such as a blue-light filter applied. |
| The nose fit for Mirae is a high nose bridge fit. |
| The hinges in Mirae are normal hinges, also known as standard or barrel hinges. |
Show All
### What Inspired the Frame Design of Oscar Wylee’s Mirae Glasses?
The Oscar Wylee Mirae frame design was inspired by current fashion trends, as classic shapes are often in fashion. A classic glasses shape is timeless; it remains popular throughout the decades while other trends come and go.
## What to Know About Oscar Wylee’s Mirae Glasses?
There are many aspects of the Oscar Wylee Mirae frames that customers should know about to decide whether this is the right frame for them. The Mirae frame is a women's classic-shaped frame. Oscar Wylee’s Mirae frame is suitable for many face shapes, but particularly compatible with square, oval, and pear face shapes. The Mirae frame’s simple design makes them fashionable all year round. Mirae features the standard [parts of glasses](https://www.oscarwylee.com.au/glasses/eye/part-of-glasses), such as a rim, temples, lenses, hinges, and a high nose bridge.
### What are the Types of Temple Tips or Earpieces Included with Oscar Wylee’s Mirae Glasses?
The type of temple tips or earpieces included in Oscar Wylee’s Mirae Glasses are made from acetate.
### What Type of Nose Bridge do Oscar Wylee’s Mirae Glasses Have?
The type of nose bridge included in Oscar Wylee’s Mirae frame is a high nose bridge fit.
### What Type of Nose Pads are Included with Oscar Wylee’s Mirae Glasses?
Oscar Wylee’s Mirae frame does not include adjustable silicone nose pads.
### What Type of Lenses do Oscar Wylee’s Mirae Glasses Have?
The type of lenses that typically come with the Oscar Wylee Mirae [glasses frame](https://www.oscarwylee.com.au/glasses.html) are optical lenses. Optical lenses are glasses lenses that have a prescription within the lens to help correct vision issues such as myopia, hyperopia, and astigmatism. Mirae can also come with non-prescription lenses, with add-ons such as a blue light filter. Mirae frames can be customised into sunglasses in-store or online with add-on tints or polarisation.
### What Material is Used for the Rim of Oscar Wylee’s Mirae Glasses?
The material used for the rim of Oscar Wylee’s Mirae glasses frames is acetate. The rim refers to the part of a glasses frame that holds the lenses.
### What Type of Hinges are Included with Oscar Wylee’s Mirae Glasses?
The type of hinges included with Oscar Wylee’s Mirae frames are normal hinges. These provide strength and smooth movement connecting the frame’s arms and lenses.
## What Face Types are Most Suitable for Oscar Wylee’s Mirae Glasses?
The face types that are most suitable for Oscar Wylee’s Mirae frame are square, oval, and pear face types. The Mirae frame is a classic shape, meaning that it complements the structure of square, oval, and pear faces particularly well. The classic Mirae frames help balance the features of a [square face shape](https://www.oscarwylee.com.au/glasses/face-shapes/square), an [oval face shape](https://www.oscarwylee.com.au/glasses/face-shapes/oval), and a [pear face shape](https://www.oscarwylee.com.au/glasses/face-shapes/pear), bringing the eyes and brows forward in a flattering way. Although there are many [glasses for face shapes](https://www.oscarwylee.com.au/glasses/face-shapes) that may be considered more aesthetically suitable, it is important that people also choose frames that make them feel most comfortable and represent their personal style.
## What Size Options are Available for Oscar Wylee’s Mirae Glasses?
The size options available for Oscar Wylee’s Mirae frame are a medium-frame fit across all colours.
## What Materials are Used to Create Oscar Wylee’s Mirae Glasses?
The material used to create the Oscar Wylee Mirae frame is acetate and stainless steel. Acetate, also known as cellulose acetate, is a bioplastic made from cotton fibres or wood pulp. At Oscar Wylee, acetate glasses are made by adding a dye to cellulose acetate, which is rolled into a sheet. The shape of the glasses is then cut from this sheet. Stainless steel is a durable iron-based alloy.
## What’s Included
## OW Case &amp; Cloth
Protective Case and Lens Cloth
Our high-quality glasses case and lens cloth are included with every purchase of an Oscar Wylee frame. The stylish, magnetic case is made from a hard shell. This sturdy and durable material keeps your glasses protected and safe, wherever you go. Ensure your lenses are clean and scratch-free with our OW microfibre cloth, specifically designed to ensure you have comfortable vision through your lenses.
Oscar Wylee offers:
* Free Shipping on all orders
* 1 Year Warranty on frames and lenses
* Scratch resistance lens coating on all prescriptions
* UV-proof coating on all prescriptions
Health fund rebate: Once you place an order, we will send you an email with your order details so you can make a claim if you are a health fund member. Learn more about [health funds](https://www.oscarwylee.com.au/health-funds.html).
## Make and Materials
Also known as cellulose acetate, these frames are traditionally hand-crafted by skilled craftsmen, with each frame passing through numerous stages of production and are hand-polished to ensure a glorious lustre. The frames then go through cleaning and strict quality control, and many pairs of crafting hands to be hand-assembled and polished. After your frames have gone through the production process, they are individually examined and&nbsp;packed before making their way to you!
## Warranty Information
### Warranty Information
### Warranty Information
Oscar Wylee provides a 1 year warranty from the date of delivery on frames and lenses against manufacturing faults or defects. We will repair or replace faulty or defective frames or lenses free of charge for warranty claims made within 1 year of the delivery. We also offer repairs or replacement for problems experienced with vision during everyday use for claims made within 30 days of delivery. If the same product has been discontinued or is no longer available, then we may offer an exchange for a similar product or a refund.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Find a Store Location](https://www.oscarwylee.com.au/locations/full-store-list.html)