# Source: https://www.oscarwylee.com.au/glasses/eye/common-problems/fuchs-dystrophy

# Fuchs' Dystrophy: Causes, Symptoms, and Treatments
Published on March 20th, 2024
Updated on December 10th, 2024
Fuchs' dystrophy
is a type of corneal dystrophy and is a genetic disease that affects the
cornea, which is the clear dome located at the front of the eye. Fuchs' dystrophy causes the endothelium cells, which are responsible for
the cornea’s fluid levels, to break down and cause small bumps medically
known as guttae to form on the back of the cornea. This can also lead to a
build-up of fluid and then swelling in the cornea. Symptoms of Fuchs’ eye
disease can include sensitivity to light, a rough or gritty sensation in the
eye, eye pain, eye problems exacerbated in humid areas and blurry vision.
According to John Hopkins, while Fuchs' dystrophy occurs at birth, symptoms
may not occur until middle age. Fuchs' dystrophy cannot be cured, therefore,
yearly eye tests are recommended especially for patients who are over 40
years or older.
Need to Have Your Eyesight Checked?
We recommend everyone has a complete eye test at least once every two
years. Book yours today with Oscar Wylee.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Definition](#definition)
[Causes](#causes)
[Symptoms](#symptoms)
[Diagnosis](#diagnosis)
## What is Fuchs' Dystrophy?
Fuchs' dystrophy is
an inherited disease of the eye that affects the cornea as it causes
the endothelium cells to deteriorate, which can lead to a build-up of
fluid and then swelling in the cornea, known as corneal edema. The endothelium cells are what control fluid
levels in the cornea. Risk factors for Fuchs' dystrophy include having a
history of Fuchs' dystrophy in the family and older age, according to
the Centre For Eye Research Australia. Symptoms of Fuchs' dystrophy
include light sensitivity, exacerbated eye problems in humid areas,
blurry vision and eye pain.
The figure below shows the cloudy appearance of the eye as a result of
Fuchs’ dystrophy and the appearance of a thickened stroma due to corneal
swelling.
## What Causes Fuchs' Dystrophy?
The main causes of Fuchs' dystrophy are
having a history of Fuchs' dystrophy in the family, increased age and
gender. Increased age is a common cause as Fuchs' dystrophy typically
presents symptoms after the age of 50 years. According to the American
Academy of Ophthalmology, Fuchs' dystrophy was found to occur in women
more than men.
### Is Fuch Dystrophy Hereditary?
Yes, Fuchs' dystrophy is hereditary.
Fuchs' dystrophy can be inherited through an autosomal dominant
nature, according to the National Institutes of Health, which means that
a single copy of the mutated gene from just one parent is
sufficient to cause the genetic disease to develop.
### Is Fuchs' Dystrophy an Autoimmune Disease?
No, Fuchs' dystrophy is
not an autoimmune disease. An autoimmune disease refers to
conditions that cause the immune system to attack its own body
and can include common forms such as rheumatoid arthritis, psoriasis
or thyroid diseases. Fuchs' dystrophy is a corneal condition passed
down through parents.
## What are the Symptoms of Fuchs' Dystrophy?
The symptoms of Fuchs' dystrophy are
sensitivity to light, a rough or gritty sensation in the eye, eye
pain, eye problems exacerbated in humid areas and blurry vision. The symptoms of Fuchs' dystrophy are listed below.
* Sensitivity to Light:  Sensitivity to
light refers to the discomfort or pain experienced when the eyes are
exposed to light. Light sensitivity can develop as a symptom of Fuchs'
dystrophy due to swelling in the cornea, which can leave the eyes
tender and more vulnerable to stimuli.
* Rough or Gritty Sensation:  A rough or
gritty sensation in the eye can occur as a consequence of the tiny
bumps that form on the back of the cornea due to Fuchs’ dystrophy.
* Eye Pain: 
Eye pain can arise during Fuchs' dystrophy as the swelling that occurs
can cause increased pressure in the cornea. Corneal swelling can leave
the eye more sensitive and tender as the cornea is the most innervated
structure in the eye and, therefore, more susceptible to pain.
* Eye Problems Exacerbated in Humid Areas:
The exacerbation of eye problems in humid areas may be due to the
quicker evaporation of tears in the eye causing dry eye. This can
leave the eye in discomfort as the eye requires a certain amount of
moisture for optimal health and comfort.
* Blurry Vision: 
Blurry vision can occur in relation to Fuchs' dystrophy from the
build-up of fluid in the cornea. Blurry vision can be described as
vision that lacks sharpness and detail.
## How to Diagnose Fuchs' Dystrophy?
To diagnose Fuchs' dystrophy,
a standard eye test completed by an optometrist or ophthalmologist is
required. A slit lamp exam in particular is typically performed as
part of standard eye tests, which can identify corneal swelling and
guttae, which is a clear indication of Fuchs’ dystrophy, according to the Lions Eye Institute. Eye tests are important in
maintaining eye health as they are the surest way to detect a wide range
of eye problems such as Fuchs' dystrophy. To specifically examine the
corneal endothelium, it requires a diagnostic test known as specular
microscopy, which is usually performed before surgery by an
ophthalmologist.
## What are the Fuchs' Dystrophy Treatments?
There are
no treatments for Fuchs' dystrophy, however, there may be treatments
to help reduce occurring symptoms such as eye drops or eye
ointments. According to the Centre for Eye Research Australia, eye drops or
ointments may aid in alleviating corneal swelling. For severe cases of
Fuchs' dystrophy where vision loss has occurred, the patient may require
a corneal transplant. A corneal transplant is a
[surgery performed in the eyes](https://www.oscarwylee.com.au/glasses/eye/surgery)
and involves replacing all or parts of the affected corneal cells with a
healthy donated cornea.
## How to Prevent Fuchs' Eye Disease?
It is not possible to prevent Fuchs' eye disease, therefore, it is
important and strongly recommended to get regular eye tests with an
[optometrist](https://www.oscarwylee.com.au/glasses/eye/doctors), especially after the age of 50. The recommended frequency of eye
tests is generally once every 2 years unless advised otherwise by your
optometrist. According to the Cleveland Clinic, while
Fuchs' eye disease cannot be prevented, it may be beneficial to your
overall health by managing sugar levels if you have diabetes and
quitting smoking.
### What is the Difference Between Fuchs' Dystrophy and Corneal Dystrophy?
There is
no difference between Fuchs' dystrophy and corneal dystrophy.
Corneal dystrophy is the term used for genetic and progressive eye
diseases that impair the cornea. Other than Fuchs' dystrophy, types of
[corneal dystrophy](https://www.oscarwylee.com.au/glasses/eye/corneal-dystrophy)
also include keratoconus and lattice corneal dystrophy.
### What is the Difference between Fuchs' Dystrophy and Cone-rod
Dystrophy?
The difference between Fuchs’ dystrophy and cone-rod dystrophy is
which region of the eye they affect and how they can impair vision.
Fuchs’ dystrophy impacts the cornea, causing the endothelium cells in the cornea to deteriorate over
time leading to increased fluid and swelling, which causes cloudy
and/or blurry vision. Fuchs’ dystrophy normally presents symptoms
during middle age, whereas cone-rod dystrophy can develop in patients
from childhood to early adulthood.
[Cone-rod dystrophy](https://www.oscarwylee.com.au/glasses/eye/cone-rod-dystrophy)
impairs the light-sensitive cells, known as the rods and cones in
the retina, impairing
visual acuity and the ability to distinguish between certain colors.
Fuchs’ dystrophy and cone-rod dystrophy are both inherited types of
eye diseases and can eventually lead to partial loss of vision.
Find a Store Near You
Contact or visit your nearest store for a full quote.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
### Can I Use Glasses if I Have Fuchs' Dystrophy?
Yes, you may be able to use glasses
if you have Fuchs’ dystrophy and are experiencing sensitivity to
light but it will also depend on what is advised by your
optometrist. According to the American Academy of Ophthalmology, a specific
strength of glasses may be prescribed to Fuchs’ dystrophy patients who
undergo corneal transplant or penetrating keratoplasty to help achieve
optimal vision. According to the National Library of Medicine,
[therapeutic contact lenses](https://www.oscarwylee.com.au/glasses/eye/contact-lenses/therapeutic)
may be used in combination with 5% sodium chloride for a week to help
alleviate symptoms (Erdinest et al., 2022).
### Does Having Fuchs' Dystrophy Make You Blind?
No, while Fuchs’ dystrophy
can lead to a partial loss of vision over time, it may not result
in complete blindness unless it is a severe case, according to the NW Cornea Institute. Fuchs’ dystrophy impairs
vision as it causes cloudy or blurry vision as a result of the
swelling in the cornea.
#### Can I Drive a Vehicle if I Have Fuchs' Dystrophy?
Yes and no, you
may still be able to drive with Fuchs' dystrophy depending on
your visual condition. However, the optometrist or ophthalmologist
who is treating you will be able to inform you whether you are fit
to [drive with visual impairment](https://www.oscarwylee.com.au/glasses/eye/visual-impairment). According to Optometry Australia, the minimum visual condition
required in Australia is 6/12 with one or both eyes. Nevertheless,
it is important to consult with an eye care professional as
circumstances may differ according to your condition.
How is Your Vision?
If you are worried about your vision health, book a bulk billed eye
test with Oscar Wylee today.
[Book an eye test](https://www.oscarwylee.com.au/booking)
Major Health Funds Accepted In-store
For the purchase of frames and lenses, use your private health fund
insurance to limit how much you pay from your own pocket.
[Explore health funds](https://www.oscarwylee.com.au/health-funds.html)