# Source: https://www.oscarwylee.com.au/glasses/distance

# Distance Glasses: Types, Benefits and Usage
Published on February 17th, 2025
Updated on Month Date, 2025 
Australia
[Australia](https://www.oscarwylee.com.au/glasses/distance)
New Zealand

[Canada](https://oscarwylee.ca/glasses/distance)
Canadian French

Distance glasses, also known as single-vision distance glasses, are a type of eyewear designed to help correct refractive errors that
blur a person's distance vision. This could include myopia, hyperopia or
astigmatism. There are several different types of lens variations when it comes to
distance glasses, including single-vision distance glasses, bifocal
glasses, progressive lenses, polarised sunglasses with a distance
prescription, photochromic glasses and high index lenses. The benefits of
distance glasses are that they help to correct the refractive error
myopia, whilst the glasses are being worn. Keep reading to learn more
about distance glasses.
Ready to book an eye test?
At Oscar Wylee we offer bulk billed eye tests for all eligible Medicare
card holders.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Definition](#Definition) [Correcting Myopia](#Myopia)
[Types](#Types) [Benefits](#Benefits)
## What are Distance Glasses?
Distance glasses, known also as single-vision distance glasses, are a
type of prescription glasses that help to correct refractive errors that blur a person's distance
vision. This could include myopia, hyperopia or astigmatism. Distance
glasses are [prescription glasses](https://www.oscarwylee.com.au/glasses/prescription) that most commonly help to correct myopia or short-sightedness. Myopia is a type of refractive error affecting distance vision.
Distance glasses will have a prescription over the lens to correct
this vision issue and allow a person to see distant objects clearly
when wearing the glasses.
### What Vision Issues Do Distance Glasses Fix?
The vision issue that distance glasses fix is typically myopia or nearsightedness, as well as hyperopia and astigmatism. [Myopia](https://www.oscarwylee.com.au/glasses/eye/nearsightedness)
refers to a refractive error in which the eyeball or cornea is
mishappened, meaning light cannot reflect onto the retina as it
should. This then causes distance vision to be blurry. Distance
glasses, also known as single vision distance glasses, work by
redirecting the light onto the retina correctly, helping to reduce
blurry distance vision whilst the glasses are on.
### How do Long-Distance Glasses Differ from Reading Glasses?
Long-distance glasses differ from reading glasses as they are required for different eye conditions. Long-distance glasses are designed for people with myopia,
hyperopia or astigmatism, to help improve their ability to see
faraway objects. [Reading glasses](https://www.oscarwylee.com.au/reading_glasses.html), however, would be suited for those with hyperopia or presbyopia
which is when the eyes struggle to see objects up close. Make sure
your prescription is accurate, particularly if you feel your vision
has changed recently as these glasses can help with particular eye
conditions.
#### Is it Bad to Wear Distance Glasses for Reading?
Wearing distance glasses for reading, or close-up tasks won't necessarily be bad or have detrimental effects on your
eyes. They may not be effective in helping you see clearly at a near
distance. Distance glasses will generally have a prescription in
the lens to help correct conditions like myopia and provide clear
vision for far objects. In some cases, distance glasses can be
worn all the time and provide some benefits for near tasks. Ask
your optometrist if you are unsure whether to use your glasses for
distance or reading.
#### What are Non-prescription Reading Glasses?
Non-prescription reading glasses are glasses that do not have a prescription from an optometrist
to help correct a refractive error.
However, these glasses may still have a level of general
magnification to assist someone with reading, or other tasks
carried out at a near distance.
## What are the Different Types of Distance Glasses?
There are several different lens variations when it comes to distance
glasses, with types including single-vision distance glasses, bifocal glasses, progressive lenses,
polarised sunglasses with a distance prescription, photochromic
glasses and high index lenses. The different types of distance glasses are listed below.
* Single-vision distance glasses: Single
vision distance glasses are glasses with one single prescription in
the lens.
* Bifocal glasses: Bifocal glasses refer to glasses with two prescriptions in the
lens.
* Progressive lenses: Progressive lenses have multiple prescriptions within one
lens.
* Polarised sunglasses with a distance prescription: Polarised sunglasses with a distance prescription help to correct
distance vision whilst also providing UV protection from the
sun.
* Photochromic glasses: Photochromic glasses refer to glasses with lenses that can change
from clear to a sunglasses tint when exposed to UV rays from the
sun.
* High index lenses: High index lenses refer to light, thin lenses designed for people
with strong or high prescriptions.
### 1. Single-vision Distance Glasses
Single-vision distance glasses refer to glasses that will have one prescription within the lens. If a person needs to correct a single type of vision impairment
or refractive error, [single vision glasses](https://www.oscarwylee.com.au/glasses/eye/single-vision-lenses)&nbsp;will be a good eyewear choice. There are also lens add-ons
that a person can get for their distance glasses, including
anti-glare coating, to help reduce glare and blue light filters. [Blue light glasses](https://www.oscarwylee.com.au/glasses/eye/blue-light)
may help in cutting the amount of blue light entering the eye. It
may also be possible to have a distance prescription fitted into
certain pairs of [sports sunglasses](https://www.oscarwylee.com.au/glasses/sport-sunglasses), to help you see better when playing sports outside.
### 2. Bifocal Glasses
Bifocal glasses are glasses that have two prescriptions within one lens. [Bifocal glasses](https://www.oscarwylee.com.au/guides/lenses/bifocal.html)
will have a prescription to help with distance vision and one to
help with near vision, separated by a visible line.
### 3. Progressive Lenses
Progressive lenses are lenses that
have two or three prescriptions within one lens and are not
separated by a visible line. The prescriptions in [progressive lenses](https://www.oscarwylee.com.au/glasses/eye/progressive-lenses)
will be blended together, so the eye moves seamlessly from one
prescription to the other. Progressive lenses will have near, middle
and distance vision correction.
### 4. Polarised Sunglasses with Distance Prescription
Polarised sunglasses can come with a distance prescription to help
people see clearer, whilst also protecting their eyes from UV rays, and minimising glare. [Polarised sunglasses](https://www.oscarwylee.com.au/glasses/eye/polarised-lenses)
refer to sunglasses with a coating or a filter that stops horizontal
light, the type of light that causes glare, getting through the lens
to the eye.
### 5. Photochromic Glasses
Photochromic glasses refer to glasses with lenses that change from a clear to a dark
tint when exposed to UV rays from the sun. A person with distance glasses can have [photochromic lenses](https://www.oscarwylee.com.au/glasses/eye/photochromic-lenses)
so that they do not have to change from sunglasses to prescription
glasses when moving inside and out.
### 6. High-Index Lenses
High index lenses refer to light and thin glasses lenses designed for people with
strong or high prescriptions. If a person needs a high prescription to help correct myopia,
then their distance glasses can be fitted with a [high index lens](https://www.oscarwylee.com.au/glasses/eye/high-index-lenses).
#### Should You Wear Distance Glasses All the Time?
Distance glasses, also known as single vision distance glasses,
should be worn at the advice of your optometrist. They are most effective in contexts where distance vision is
necessary such as driving and reading smartboards. There are no
concrete studies to suggest that constant wear of distance glasses
will strain your eyes. However, if they are not worn during
periods where long-distance vision is required then your eyes will
likely be strained. Ultimately, consult an optometrist to get
advice on how frequently you should wear them.
Visit a Store Near You
We have highly qualified teams in every store dedicated to helping
with your eye care and eyewear needs.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
### What are The Best Distance Glasses for Driving?
Most types of lens variations for distance glasses will be suitable for
driving. However, there are certain features that might make vision while
driving even more clear. Anti-glare coatings will allow for more
clarity against sunny conditions while on the road and wider lenses
may allow for wider peripheral vision which is important whilst
driving.
### When Should Long-Sighted Individuals Wear Glasses?
Long-sighted people generally have trouble seeing objects at a near
distance, meaning glasses should be worn whilst reading and other
close-up tasks. Long-sightedness, also known as hyperopia, is a
refractive error that can cause issues with near vision or the
ability to focus.
## What are the Benefits of Distance Glasses?
The benefit of distance glasses, also known as single vision distance
glasses, is that they will help correct refractive errors that cause blurry
distance vision. Additional benefits of distance glasses include reduced eye strain,
as the prescription lessens how hard the eye has to work to see with a
refractive error.
### How do you Choose the Best Distance Glasses for your Needs?
The way to choose the best distance glasses for your needs
is to discuss your eye care needs with your optometrist, as well as
consider your personal style. Your optometrist will provide you with a distance prescription if
required and may give you advice on any add-ons that may be suitable
for your eye care needs. You should also consider personal style
when choosing distance glasses. Distance glasses can come in a
variety of styles, sizes and colours, so it is important to choose a
frame you like, that will suit your style.
#### Do Distance Glasses Work to Correct Presbyopia?
No, distance glasses will not work to correct presbyopia. [Presbyopia](https://www.oscarwylee.com.au/glasses/eye/presbyopia)
refers to an age-related eye condition that causes blurry near
vision. Presbyopia is caused by the natural aging of the lens,
which results in the lens becoming harder and less flexible.
Glasses that have a prescription for near vision correction will
help to correct presbyopia, not distance glasses.
Read Distance Glasses: Types, Benefits and Usage in other Oscar Wylee
regions and their languages.
Australia
[Australia](https://www.oscarwylee.com.au/glasses/distance)
New Zealand

[Canada](https://oscarwylee.ca/glasses/distance)
Canadian French

Are You Due for an Eye test?
Regular eye tests are an important step in keeping eyes healthy. Book
now and an Oscar Wylee optometrist can provide a Medicare bulk billed
eye test.
[Book an eye test](https://www.oscarwylee.com.au/booking)
Major Health Funds Accepted In-store
For the purchase of frames and lenses, use your private health fund
insurance to limit how much you pay from your own pocket.
[Explore Health funds](https://www.oscarwylee.com.au/health-funds.html)