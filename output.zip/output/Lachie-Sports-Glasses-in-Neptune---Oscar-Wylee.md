# Source: https://www.oscarwylee.com.au/lachie-in-neptune

# Lachie
in Neptune
$129
Lachie is made for speed, whether that’s on the track, trail or train to work. A wrapped style with rubber
nose pads and temples for a secure fit.
This product cannot be made with prescription lenses.
Frame Colour Options
[](https://www.oscarwylee.com.au/lachie-in-neptune)
[](https://www.oscarwylee.com.au/lachie-in-burnt-amber)

2 pairs from
$199
Discount auto-applied at checkout
3 pairs from
$249
Discount auto-applied at checkout
[Book an eye test](https://www.oscarwylee.com.au/booking)
This product cannot be purchased online. Please purchase in-store.
## About Lachie Frames
### Made from TR90
| Frame fit | Measurements |
| --- | --- |
| Wide | 62 - 17 - 128 |
These measurements mean lens width, bridge, and temple length in
millimetres (mm). They can be found on the inside of the temple
arm. If you already have a pair that you like, you can compare it
to these measurements.
Features 
| Features |
| --- |
| Impact resistant | Scratch resistant |
| Lightweight material | UV protection |
| Anti-Glare | Polarised |
| Rubber nose pads | Rubber temples for grip |
## What's Included
Protective Hard Case and Lens Cloth
Our high-quality glasses case and lens cloth are included with every purchase of an Oscar Wylee frame. For
larger frames, we have hard cases that provide extra protection, with a zip close and soft pouch to put the
frames inside. This sturdy and durable material keeps your glasses safe, wherever you go. Ensure your lenses
are clean and scratch-free with our OW microfibre cloth, specifically designed to ensure you have
comfortable
vision through your lenses.
Oscar Wylee offers:
* Free Shipping for Australian Orders
* 1 Year Warranty on frames and lenses
* Scratch-resistant coating on all lenses
* UV-proof coating on all lenses
Stylish case and cloth 
Health fund rebate: once you place an order, we
will send you an email with your order details so you can make a
claim if you are a health fund member.
Learn more.

## Make and Materials
Our sports frames are made from TR90, a thermoplastic material produced through Swiss technology. TR90 is
incredibly durable, flexible and lightweight.
These frames also include anti-slip technology in the form of rubber materials to ensure they are secure on
your face through all activities.
After your frames have gone through the production process, they undergo cleaning and strict quality
control,
are individually examined and then packed before making their way to you!
## Warranty Information
Oscar Wylee provides a 1 year warranty from the date of delivery
on frames and lenses against manufacturing faults or defects. We
will repair or replace faulty or defective frames or lenses free
of charge for warranty claims made within 1 year of the delivery.
We also offer repairs or replacement for problems experienced with
vision during everyday use for claims made within 30 days of
delivery. If the same product has been discontinued or is no
longer available, then we may offer an exchange for a similar
product or a refund.

[Book an eye test](https://www.oscarwylee.com.au/booking)

[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)