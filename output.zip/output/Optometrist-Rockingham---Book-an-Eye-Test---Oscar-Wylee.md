# Source: https://www.oscarwylee.com.au/locations/optometrist-rockingham.html

# Optometrist Rockingham
Rockingham Shopping Centre Shop G057, 1 Council Ave Rockingham WA 6168
* Opposite Optus
Opening hours
Monday9:00am - 5:30pm
Tuesday9:00am - 5:30pm
Wednesday9:00am - 5:30pm
Thursday9:00am - 8:00pm
Friday9:00am - 5:30pm
Saturday9:00am - 5:00pm
Sunday11:00am - 5:00pm
*Store hours reflect local standard trading hours and exclude public holidays
[Visit our Rockingham Shopping Centre Google Business page for directions, reviews, and updates.](https://g.page/r/CTWqzOyo7up5EBM)
Book Appointment
[Call us: (08) 9505 8599](tel:(08) 9505 8599)
[Leave a Review!](https://g.page/r/CTWqzOyo7up5EBM/review)
Our Reviews
Floridyn Tonette Torcal
1 week ago
Staff are friendly and nice . Fast service. Matthew the manager helps me with my eye measurements fo...r my multifocal specs. He walks me through the process thoroughly. Lily is very helpful too. Highly recommended. ????
See more
Jeanette McCabe
1 week ago
Professional fast service!
Angela Newbon
3 weeks ago
Matthew the manager is a absolute legend
Jan O'Keefe
3 weeks ago
Very well looked after
marci pillar
3 weeks ago
deegii s
3 weeks ago
Johnny's Life
4 weeks ago
I had Dr Tang and he was great, very friendly and knowledgeable.
1 note can you put the pupillary d...istance on the reports as I needed that for my prescription.
Other than that definitely recommended!
See more
Andie Lazaro
1 month ago
I have a lovely experience at Rockingham branch. Both Matt and Chris has been awesome ???? Matt take...n care of my favourite pair of optics and has taken my measurements making sure it was as accurate as possible. Chris has listened to my concerns about my vision and has provided me the best advice he could. I am excited to get my new pair. Its my first time with OW and I hope its as awesome as my experience with Rockingham branch.
See more
nadia
1 month ago
Had such a positive experience with Oscar Wiley for an eye assessment and purchasing of frames.
The ...front desk staff and the optometrist were so friendly, helpful and reassuring. They were professional and had such a good energy. Can’t wait to get my glasses. The price was very reasonable as well.  Highly recommend.
See more
Cherie Brown
1 month ago
Just popped in tonight to ask some questions. Lily was an amazing help, thank you for your patience.
Adesumbo Ogunrinola
1 month ago
Have always liked Oscarwylee, never been disappointed.
Waheed Iqbal
1 month ago
I’ve visited three Oscar Wylee stores, and the Rockingham store is by far the best. The customer ser...vice here is extraordinary. The front desk gentleman was incredibly welcoming, friendly, and professional. Unfortunately, I didn’t catch his name, but he made my visit a great experience. His excellent service is the reason I’ll be coming back. Highly recommend the Rockingham team!
See more
robyn alirejo
1 month ago
Service was excellent.  The optometrist Mee was so good explained everything and was very thorough. ... Would definitely recommend the store at Rockingham city.
See more
Awadia Mahamud
1 month ago
Best experience I have ever had glasses shopping. From glasses, prescription and just customer servi...ce in general everything was amazing.
As someone who is indecisive and never knows what shape or colour to get. Louise hit the nail on the head twice on the first go.
She helped me pick out 2 frames and I’m obsessed couldn’t be happier. She is so kind and patient it really makes the whole experience feel like a breeze.
See more
Jess Pellicano
2 months ago
Matt at Rockingham was absolutely phenomenal. 10/10 customer service from start to finish. He was ki...nd and approachable and super knowledgeable, made it a really easy process
See more
Hanna Stewart
2 months ago
The staff were exceptionally helpful
Joseph Heffernan
2 months ago
Friendly and engaging staff, thorough checks and tests.  Good service in reviewing a number of frame...s.  Breakdown of cost explained well
See more
Daniel Morris
3 months ago
Carmella Sorgiovanni
3 months ago
Sharon Blagg
3 months ago
I recently visited Oscar Wylee after my glasses were accidentally broken, and I wanted to express ho...w grateful I am for the outstanding service I received from Lily.
Lily, went above and beyond to help me. &nbsp;She was incredibly kind, patient, and understanding. &nbsp;Nothing was too much trouble for her, and she made me feel genuinely cared for.
Thank you again, Lily, for your exceptional customer service!
See more
Sadna Nawosah
3 months ago
Riley Allison
3 months ago
Ana
4 months ago
Excellent customer service Olivia ,thank you very much for the patience and thoroughly explaining al...l options
See more
Jodie Birt
4 months ago
All the staff were so friendly and helpful. They were knowledgeable and provided great advice. The r...ange of glasses available is fantastic with so many options available
See more
Natasha Visscher
4 months ago
Super friendly and welcoming first time experience! Can't wait to pick up my new glasses
Michael Wilkinson
4 months ago
The team at Rockingham Oscar Wylee were incredibly friendly and helpful. Very positive experience th...ere.
See more
Salvisto James
4 months ago
Charmaine
4 months ago
Samantha, Louise and Lily made my eye test and glasses shopping experience pleasant. Really friendly... and welcoming team. Louise went above and beyond in assisting with my glasses replacement and helping me find the perfect pair :-)
See more
Mollie Owen
5 months ago
Everyone who was working while I was there was amazing they all were very positive and joking around... with customers I asked for advice and I don’t think I have ever been hyped up as much as I was while there
See more
Alfred Joshua
5 months ago
Highly professional and friendly
Had a very good experience there
Annalysse Lazzari
5 months ago
Love Oscar Wylee Rockingham and their range! Always super helpful and today specifically, Lily could...n’t do more to help and was so attentive! Looking up my past orders and offering similar styles so I could get exactly what I want and be happy, noticing the smallest details about the glasses I had originally picked. Highly recommend this store and thanks Lily! You’re so good at your job!
See more
Gaylene Intveld
5 months ago
The staff are very friendly.
Melonie Knight
5 months ago
Staff were extremely friendly and helpful
Matthew Cooney
5 months ago
Lisa
5 months ago
Lily is an absolute superstar! She provides such amazing customer service. It is so apparent that sh...e cares about her customers and makes you feel so comfortable and valued. You are blessed to have such a wonderful employee! I could not be happier with the service or glasses that Lily helped me select. Thank you so much!
See more
Daria Attard
5 months ago
Prompt service and great experience
Ken Farrand
5 months ago
Lily gave excellent service when I took my broken glasses in and she was happy and able to put the l...enses in a old frame for me
See more
Sera O
5 months ago
Lily is absolutely lovely and very helpful! Far better than the experience I had with the assistant ...manager at Karrinyup who was awfully rude to me
When she made a mistake and sent my glasses to a store on the opposite end of Perth. Highly recommend the Rockingham team and especially Lily!
See more
Tamara Knapp
5 months ago
Fantastic experience at Oscar Wylee! Lily and Sam were exceptionally friendly and helpful, making th...e entire process smooth and efficient. I was made to feel completely comfortable from the moment I walked in. Highly recommend!
See more
Noor Theeb
6 months ago
I just wanted to give a huge shout out for Oscar Wylee staff member Louise! I came into the store wi...th broken glasses on my lunch break, and Louise went well and truly above and beyond to help me and get the glasses repaired and back to me before I started work. Louise's kindness and thoughtfulness made the whole experience stress-free and I could not recommend Louise or the store enough. Thank you!!
See more
Feny Fitriany
6 months ago
Vickey Brown
6 months ago
Visited Rockingham store, (not my regular store) but nontheless I was looked after by Lily. She was ...knowledgeable, very helpful, seemed genuine, nothing was too much trouble and she did a great job. Thanks Lily.
See more
Kristeen Melling
6 months ago
Girls were great
Helpful in picking an assortment of the sort of frames I liked.
Test was prompt and... on time.
They were training a newbie and gave good instruction.
Will be back next time I need new glasses.
Perfect service so far
See more
Isobel Walker
6 months ago
Great service. Friendly staff. Thank you.
Patrick Bell
6 months ago
Great service, staff friendly and knowledgeable .
Highly recommend .
Gavin Prime
7 months ago
Great service, friendly staff, my first time to this store, and no need to look anywhere else in the... future. Thanks to the Rockingham team for making it a great experience!
See more
Renee Stevens
7 months ago
The lady who looked at my eyes was very nice but was supposed to give m a follow up call and didn’t....
See more
Kelly Barringhaus
7 months ago
Great service, helpful and will be back
Zachery Taylor
7 months ago
Juliet Nichole
7 months ago
Staff are so friendly.
## Find an Optometrist in Rockingham With Oscar Wylee
Come visit our Oscar Wylee store located in Rockingham Shopping Centre on the crossroads of Optus and Telstra, where our Oscar Wylee optometrists offer bulk billed eye health tests to eligible Medicare cardholders. Close to areas such as Hillman and Cooloongup and a 10-minute drive from Port Kennedy, our friendly staff and optometrists are able to provide on-site eye tests, update your prescription, and help you find your new favourite pair of glasses on the same day!There is lots to do in Rockingham if you have time after your appointment. You can visit Penguin Island, skydive onto the beach or go to the wake park. Only a 6-minute drive to the beautiful beach, with great brunch spots and a view of Garden Island, Rockingham Oscar Wylee is the place to go for expert eye care.
Meet Our Team
* 
Our Services
* Bulk Billed Eye Examinations
* Professional Frame Styling
* Frame Adjustments and Repairs
* Visual Fields Testing
* Digital Retinal Scanning
Show All
## Find an Optometrist in Rockingham, Perth for an Eye Health Test
An optometrist in Rockingham, Perth is where you can expect high-quality eye health tests in Rockingham, professional assistance with frame selection and styling advice. We take pride in prioritising vision health, so we have skilled and dedicated optometrists who are qualified to diagnose a range of eye diseases. You can easily make an appointment here online to get bulk billed priced services as part of Australia’s Medicare system.
You can expect great-fitting frames thanks to our friendly optical dispenser in-store who can also answer any questions related to your eyewear. For eye conditions that may require a specialist, we will refer you to an eye doctor. Come in-store today to browse our wide selection of prescription sunglasses and more.
## How to Find an Optometrist in Rockingham, Perth?
To find an optometrist in Rockingham, Perth, you can take certain steps that can help make it easier for you such as searching online, assessing the store’s opening hours and finding the directions to your chosen location. The steps on how to find an optometrist in Rockingham are listed below.
1. Search online using the phrase, Rockingham optometrist near me. This can also be done here on the website via our locations page.
2. Click on the Oscar Wylee link, which will take you directly to our Rockingham optometrist store page.
3. See the store’s opening hours and where the store is located specifically.
4. Use the Rockingham Google Business page link located under store hours to see the directions on how to get to the store.
You can also find an optometrist in Rockingham by searching the keywords optometrist near me. If you have locations enabled on your smartphone and you’re in the area of Rockingham, our Rockingham store page should appear easily for you to click on.
### Is it Hard to Get an Eye Appointment in Rockingham, Perth?
No, it is not hard to get an eye appointment in Rockingham. You can easily book an appointment to see an Oscar Wylee optometrist in Rockingham right here on this page. At Oscar Wylee we have highly qualified optometrists available for bulk billed eye appointments, which can be booked online or in-store.
#### How to Compare Optometrists in Rockingham to Each Other?
To compare optometrists in Rockingham, you can use factors such as eye tests offered, health fund coverage, lens types and add-ons and eyewear offered. To take care of your vision and eye health, it is important to receive an eye test at least once every two years. There are different types of tests that can be performed in an eye test and not all optometrists may offer the same tests. Health funds can be used to help cover some of the cost of your frames and lenses. To find out if your health fund is accepted at Rockingham optometrist in Perth, visit their website. In the case of Oscar Wylee, we accept all major health funds and provide on-the-spot claims in-store. There are many different lens options available for prescription glasses such as single vision, multifocal and high index lenses. Most optometrists in Rockingham will offer these lenses although it is good to make sure. There are also lens add-ons available to enhance your glasses such as anti-reflective and blue light filters. Finally, if you are looking to purchase a pair of glasses after your eye test, you can compare the different styles and colours you are interested in from Rockingham optometrists in Perth. Oscar Wylee offers a wide range of frames with vintage and modern inspirations in bold colours and subtle designs.
#### How to Find an Eyeglasses Shop in Rockingham, Perth?
To find a glasses store in Rockingham, you can try to follow these simple steps including searching online, selecting a convenient location and looking at their health insurance policies. The steps on how to find a glasses store in Rockingham, Perth are listed below.
1. Search online using the phrase, glasses store in Rockingham. This will provide you with various options for glasses stores in the whole Rockingham, Perth area.
2. Select a glasses store that is most convenient for you to travel to.
3. Click the link to find out more information such as opening hours, exact location and directions to the glasses store in Rockingham.
4. Read their health insurance policies to ensure you know what health benefits you have access to.
Our Oscar Wylee glasses store in Rockingham, Perth offers primary eye care services such as comprehensive eye tests as well as other services performed by an optometrist and offers prescription and non-prescription eyewear.
##### Is it Possible to Purchase Prescribed Sunglasses in Rockingham, Perth Without Seeing an Optometrist?
Yes and no, it is possible to [purchase prescribed sunglasses](https://www.oscarwylee.com.au/sunglasses.html) in Rockingham, Perth without seeing an optometrist if you already have a prescription that has not expired. If your prescription is expired, you can book an eye test to receive an updated or new prescription which will require you to see an optometrist. This will ensure your prescription sunglasses are appropriate for your visual needs.
## Where is the Oscar Wylee Rockingham Optometrist in Perth Located?
The Oscar Wylee Perth optometrist is located in the Westfield Rockingham Shopping Centre located at 1 Council Avenue, Rockingham. The Oscar Wylee Rockingham store can be found opposite Optus.
### What is the Phone Number of Oscar Wylee Rockingham Optometrist Store?
The Oscar Wylee Rockingham optometrist store phone number is (08) 9505 8599. You can contact the Oscar Wylee Rockingham store between 9 am and 5:30 pm on Monday, Tuesday, Wednesday and Friday, on Thursdays between 9 am and 8 pm, on Saturdays between 9 am and 5 pm and on Sundays between 11 am and 5 pm.
### What are the Reviews for Oscar Wylee Rockingham Optometrist in Perth?
The many reviews for Oscar Wylee Rockingham optometrist in Perth, left by our various customers can be found here on the website and online when you search for Oscar Wylee Rockingham optometrist. The reviews for Oscar Wylee Rockingham optometrist are listed below.
* Mulenga Eugenia Chisha:  I loved the customer service I got at Oscar Wylee Rockingham. Kai, Wendy and Louise answered my questions well, were very patient with me as I was indecisive, and gave good suggestions. Appreciate them for that.
* Julie Hall:  I am impressed with Oscar Wylee. Both Optometrists that I saw were extremely helpful as were the staff. Great experience.
* Sponge Bob:  Louise at Rockingham is amazing! She is so professional and helpful even when working under pressure. She is exceptional at multitasking when the shop is busy. Louise is also kind and helpful to her work colleagues who are new or need support.
* Peter Hartley:  Went back to the Rockingham store today to get my glasses adjusted. Once again the staff were friendly and efficient, it's refreshing to receive such great service.
#### What Treatments or Eye Care Processes are Done in the Oscar Wylee Rockingham Optometrist Location?
The treatments or eye care processes done in the Oscar Wylee Rockingham optometrist Perth location include a tonometry test, a digital photograph, a slit lamp exam and a refraction test. Additional tests that may also be performed can include a visual field test and a dilated fundus exam. The treatments or eye-care processes that are done in the Oscar Wylee Rockingham optometrist Perth location are listed below.
* A Tonometry Test: An optometrist or optical dispenser will conduct a tonometry test which involves the use of a machine that will release small puffs of air into your eyes. This will assist with measuring pressure in the eye.
* A Digital Photograph:  An optometrist or optical dispenser may take a digital photograph of your eye which can be kept on record to use in future appointments to evaluate any changes to your eye.
* Slit Lamp Test: A slit lamp test can be used to evaluate your eye health, by examining your cornea and iris which are the anterior and posterior of the eye.
* Refraction Test: During a refraction test, an optometrist will have you view an image through different lenses and ask you to confirm which helps you see the image clearer.
* Visual Field Test: A visual field test can assist with assessing your peripheral vision, which may be beneficial for identifying any signs of glaucoma.
* Dilated Fundus Exam: A dilated fundus exam can help an optometrist assess your health in more detail by getting a clear view of the retina. This test is typically carried out for patients with diabetes and those who may be at risk of developing retinal damage.
## How Many Optometrists Exist in Rockingham, Perth?
Many optometrists exist in Rockingham, Perth that are available for comprehensive eye tests and a wide range of eyewear, including Oscar Wylee. The number of optometrists found in Rockingham, Perth may depend on reasons including the geographical size and location and the total number of residents in the area. Here at Oscar Wylee Rockingham, you can receive professionally conducted services and care for all your optometry concerns.
### What are the Other Closest Optometrist Locations to Rockingham, Perth in Australia?
The other closest Oscar Wylee optometrist location to Rockingham is Mandurah. Mandurah is close to Rockingham with 31-34 km in between stores. The [Oscar Wylee Mandurah](https://www.oscarwylee.com.au/locations/optometrist-mandurah.html) store is the perfect destination to browse for your next pair of fashion-forward frames and eye test services.
### Bulk Billed Eye Tests at Oscar Wylee
For some of the best optometrists in Rockingham, Australia, visit Oscar Wylee in the Rockingham Shopping Centre. Here our dedicated optometrists can provide Medicare bulk billed eye tests, which include eye care processes such as vision testing and eye examinations for potential eye diseases or conditions. With our quick and efficient service, you can get your eyes tested, prescription updated and shop for your new frames all on the same day! For your eye care needs, visit Oscar Wylee Rockingham!
### Health Funds Accepted at Oscar Wylee Rockingham
Our Oscar Wylee eyeglasses shop in Rockingham Shopping Centre accepts major health funds. Come to our store for eye testing and prescription updates, and your health fund may help cover the cost of new prescription frames. Bring a valid health fund card and our team can process your claim in-store as well as answer any questions about eligibility at Oscar Wylee.
### Stylish and Affordable Frames at Oscar Wylee
At Oscar Wylee Rockingham, we offer a range of stylish and affordable frames, including prescription glasses, prescription sunglasses and non-prescription glasses in a variety of modern and vintage-inspired styles. Choose from our lens options such as multifocals or lens thinning, or pick an add-on including a blue light filter for an additional price, to get the most from your glasses. Our Oscar Wylee team in-store at Rockingham will help you choose the frame that is the perfect fit for you.
Book Appointment
[Call us: (08) 9505 8599](tel:(08) 9505 8599)
[Leave a Review!](https://g.page/r/CTWqzOyo7up5EBM/review)