# Source: https://www.oscarwylee.com.au/locations/optometrist-coomera.html

# Optometrist Coomera
Westfield Coomera1095A, 103-119 Foxwell Rd Coomera QLD 4209
* Level 1, Near H&amp;M
Opening hours
Monday9:00am - 5:30pm
Tuesday9:00am - 5:30pm
Wednesday9:00am - 5:30pm
Thursday9:00am - 9:00pm
Friday9:00am - 5:30pm
Saturday9:00am - 5:00pm
Sunday10:00am - 4:00pm
*Store hours reflect local standard trading hours and exclude public holidays
[Visit our title Google Business page for directions, reviews, and updates.](https://g.page/r/CZfWw2kK8N5ZEBM)
Book Appointment
[Call us: (07) 2111 2606](tel:(07) 2111 2606)
[Leave a Review!](https://g.page/r/CZfWw2kK8N5ZEBM/review)
Our Reviews
Natalie
6 days ago
I've had nothing but great experiences with this OW store and all the staff, including the optometri...st. Everyone was so helpful and patient with my many questions and concerns after a not-so-great experience at another store. I'm really happy with the service I received and my new glasses, which are a great fit and the correct prescription.
See more
Matt
4 weeks ago
Had an eye test last week and the optometrist, Wendy, was fantastic professional, thorough, and made... the whole experience comfortable. I also had a lot of help from a lovely young lady named Kendall, who assisted me in finding the perfect frames. Such great, friendly service from start to finish. I highly recommend them and will definitely be bringing my children back soon!
See more
BK
2 months ago
Friendly and professional store with fantastic optometrist who provided exceptional care and a thoro...ugh examination. Highly recommended!
See more
## Find an Optometrist in Coomera With Oscar Wylee
If you live in areas such as Pimpama, Helensvale, or Broadbeach, our Oscar Wylee store at Westfield Shopping Centre in Coomera is your go-to for high-quality optometry and eye care services. Here, our Oscar Wylee optometrists will provide Medicare bulk billed eye tests. Once you are done with your test, our friendly retail team will help you shop our range of affordable and stylish frames.
When you finish your appointment, why not make the most of the clothes stores, cafes and supermarkets Westfield Shopping Centre has to offer? Whether you need a trip to Woolworths to restock the fridge, want to pick out the perfect outfit from H&amp;M or Universal Store, or need a refreshing drink from Boost Juice, you’ll find everything you need at Coomera Westfield Shopping Centre.
For those who live in the Coomera area, other Oscar Wylee optometrists nearest to you include Oscar Wylee Helensvale, Oscar Wylee Southport, and Oscar Wylee Pacific Fair. Come in and see us at our Oscar Wylee eyeglasses shop today, and experience some of the best optometry services in Queensland!
Meet Our Team
* Optometrist
M.Optom
TPA Endorsed
* Store Manager
Our Services
* Bulk Billed Eye Examinations
* Professional Frame Styling
* Frame Adjustments and Repairs
* Visual Fields Testing
* Digital Retinal Scanning
Show All
## Find an Optometrist in Coomera, Queensland for an Eye Health Test
You can find an Oscar Wylee optometrist in Coomera, Queensland, for an eye health test and other eye care services such as prescription updates and new frames. Located in Coomera Westfield, Oscar Wylee optometrists are available to perform eye tests that will include vision testing and the detection of eye diseases and eye conditions. Other eye care services available at Oscar Wylee Coomera include prescription updates, eye care advice and referrals to an ophthalmologist, also known as an eye doctor, for specialised care if needed. In Coomera, Queensland, the average cost for an optometrist often depends on factors such as a person's age, health and eye care needs. At Oscar Wylee, our eye tests are conducted at a bulk billed price under Australia's Medicare system.
At Oscar Wylee's glasses shop in Coomera Westfield Shopping Centre, we have a wide range of frames available for purchase, including prescription glasses, prescription sunglasses and non-prescription glasses. Our retail team, including our optical dispensers, are located in-store to help customers shop our frames. If you need adjustments or lens add-ons such as a blue light filter, our team will be able to assist with this, ensuring all of our customers leave with eyewear that is right for their vision and lifestyle needs. For high-quality eye care services, such as new frames or eye health tests in Coomera, Queensland, come and visit our Oscar Wylee team!
## How to Find an Optometrist in Coomera, Queensland?
To find an optometrist in Coomera, Queensland, you can take certain steps that can help make it easier for you, such as searching online, assessing the store's opening hours and finding the directions to your chosen location. The steps on how to find an optometrist in Coomera, Queensland, are listed below.
1. Search online using the phrase, 'optometrist near me in Coomera'. This can also be done here on the website via our locations page.
2. Click on the Oscar Wylee link, which will take you directly to our Coomera optometrist store page.
3. See the store's opening hours and where the store is located, specifically.
4. Use the Westfield Coomera Google Business page link located under store hours to see the directions on how to get to the store.
You can also find an optometrist in Coomera, Queensland by searching the keywords 'optometrist near me'. If you have locations enabled on your smartphone and you're in the Coomera, Queensland area, our Coomera store page should appear easily for you to click on.
### Is it Hard to Get an Eye Appointment in Coomera?
No, it is not hard to get an eye appointment in Coomera. You can easily book an appointment to see an Oscar Wylee optometrist in Coomera, right here on this page. At Oscar Wylee, we have highly qualified optometrists available for bulk billed eye appointments, which can be booked online or in-store.
#### How to Compare Optometrists in Coomera, Queensland to Each Other?
To compare optometrists in Coomera, Queensland you can use factors such as eye tests offered, health fund coverage, lens types, add-ons and eyewear offered. To take care of your vision and eye health, it is important to receive an eye test at least once every two years. There are different types of tests that can be performed in an eye test, and not all optometrists may offer the same tests. Health funds can be used to help cover some of the cost of your frames and lenses. To find out if your health fund is accepted at an optometrist in Coomera, Queensland, visit their website. In the case of Oscar Wylee, we accept all major health funds and provide on-the-spot claims in-store. There are many different lens options available for prescription glasses, such as single-vision, multifocal and high-index lenses. Most optometrists in Coomera, Queensland, will offer these lenses, although it is good to make sure. There are also lens add-ons available to enhance your glasses, such as anti-reflective and blue light filters. Finally, if you are looking to purchase a pair of glasses after your eye test, you can compare the different styles and colours you are interested in from the optometrists in Coomera. Oscar Wylee offers a wide range of frames with vintage and modern inspirations in bold colours and subtle designs.
#### How to Find an Eyeglasses Shop in Coomera, Queensland?
To find a glasses store in Coomera, Queensland, you can try to follow these simple steps, including searching online, selecting a convenient location and looking at their health insurance policies. The steps on how to find a glasses store in Coomera, Queensland, are listed below.
1. Search online using the phrase, glasses store in Coomera, Queensland. This will provide you with various options for glasses stores in the whole Coomera, Queensland area.
2. Select a glasses store that is most convenient for you to travel to.
3. Click the link to find out more information, such as opening hours, exact location and directions to the glasses store in Coomera.
4. Read their health insurance policies to ensure you know what health benefits you have access to.
Our Oscar Wylee glasses store in Coomera offers primary eye care services such as comprehensive eye tests, as well as other services performed by an optometrist and offers prescription and non-prescription eyewear.
##### Is it Possible to Purchase Prescribed Sunglasses in Coomera Without Seeing an Optometrist?
Yes and no, it is possible to [purchase prescribed sunglasses](https://www.oscarwylee.com.au/sunglasses.html) in Coomera without seeing an optometrist if you already have a prescription that has not expired. If your prescription has expired, you can book an eye test to receive an updated or new prescription, which will require you to see an optometrist. This will ensure your prescription sunglasses are appropriate for your visual needs.
## Where is the Oscar Wylee Coomera, Queensland Optometrist Located?
The Oscar Wylee Coomera Queensland optometrist is located in Westfield Shopping Centre, in the suburb of Coomera in Queensland.
### What is the Phone Number of Oscar Wylee Coomera Optometrist Store?
The phone number for our Oscar Wylee Coomera optometrist store is (07) 2111 2606. Our Oscar Wylee Coomera store is open, and our staff are available to be contacted.
### What are the Reviews for Oscar Wylee Coomera Optometrist?
The customer reviews for our Oscar Wylee Coomera optometrist, can be found here on our website and online when you search for 'Oscar Wylee Coomera optometrist.'
#### What Treatments or Eye Care Processes Are Done in the Oscar Wylee Coomera Australia Optometrist Location?
The treatments or eye care processes done in the Oscar Wylee Coomera optometrist location include a tonometry test, a slit lamp exam, a digital photograph, and a refraction test. Additional tests that may also be performed can include a visual field test and a dilated fundus exam. The treatments or eye-care processes that are done in the Oscar Wylee Coomera optometrist location are listed below.
* A Tonometry Test: An optometrist or optical dispenser will conduct a tonometry test, which involves the use of a machine that will release small puffs of air into your eyes. This will assist with measuring pressure in the eye.
* A Digital Photograph: An optometrist or optical dispenser may take a digital photograph of your eye, which can be kept on record to use in future appointments to evaluate any changes to your eye.
* Slit Lamp Test: A slit lamp test can be used to evaluate your eye health by examining your cornea and iris, which are the anterior and posterior of the eye.
* Refraction Test: During a refraction test, an optometrist will have you view an image through different lenses and ask you to confirm which one helps you see the image clearly.
* Visual Field Test: A visual field test can assist with assessing your peripheral vision, which may be beneficial for identifying any signs of glaucoma.
* Dilated Fundus Exam: A dilated fundus exam can help an optometrist assess your health in more detail by getting a clear view of the retina. This test is typically carried out for patients with diabetes and those at risk of developing retinal damage.
## How Many Optometrists Exist in Coomera, Queensland?
Many optometrists exist in Coomera, Queensland and in the Westfield shopping centre, including Oscar Wylee. The number of optometrists available in an area will typically depend on the population and the eye care needs of those in the area. At Oscar Wylee Coomera, Queensland, our team is passionate about providing our customers with high-quality, dedicated eye care services. Our optometrists are available to provide bulk billed eye tests, prescription updates and new frames. If you are looking for an optometrist in Coomera, Queensland, Oscar Wylee is available to provide all your eye care and eyewear needs.
### What are the Other Closest Optometrist Locations to Coomera, Queensland, in Australia?
The closest Oscar Wylee optometrist locations to Coomera are in Helensvale, Southport and Broadbeach. The closest Oscar Wylee optometrist locations to Coomera, Queensland are listed below.
* Westfield Helensvale: Westfield Helensvale is located 10-14km away from Coomera, where you can find an Oscar Wylee optometrist for eye care services. [Oscar Wylee Helensvale](https://www.oscarwylee.com.au/locations/optometrist-helensvale.html) is located at the Westfield shopping centre where our optometrist can provide Medicare bulk billed eye tests and prescription updates.
* Australia Fair: Australia Fair is located in Southport located approximately 22km from Coomera where you can find an Oscar Wylee optometrist. Find our [Oscar Wylee Australia Fair](https://www.oscarwylee.com.au/locations/optometrist-southport.html) team for eye care services, including eye tests and new frames.
* Pacific Fair: Pacific Fair Shopping Centre is located approximately 29km away from Coomera where you can find an Oscar Wylee optometrist. [Oscar Wylee Pacific Fair](https://www.oscarwylee.com.au/locations/optometrist-pacific-fair.html) is located in the suburb of Broadbeach, where our optometrists can provide Medicare bulk billed eye tests and our retail staff can help customers shop for new frames from our stylish collection.
### Stylish Glasses in Coomera
Oscar Wylee Coomera offers a range of prescription eyeglasses and prescription sunglasses in a variety of modern and vintage-inspired styles. With add-ons such as anti-reflective coating, a blue light filter, or polarised lenses, you’ll be sure to find a pair of frames to meet your eye care needs. Oscar Wylee’s experts in-store can assist in ensuring you receive the frames that are best suited to your lifestyle and prescription needs.
### Coomera Queensland Bulk Billed Eye Examinations
Come in and have your prescription updated at Oscar Wylee at Coomera Westfield Shopping Centre, so you can shop for a new pair of fashion-forward eyeglasses on the same day. Our trained Oscar Wylee Coomera optometrists are on-site to update your prescription or provide a new one if necessary, usually in under 30 minutes. Oscar Wylee optometrists will assess your vision, check your eye health and diagnose possible eye diseases and conditions. With the recommended frequency of an eye check-up and vision testing being at least once every two years, Oscar Wylee’s optometrist-led eye tests in-store at Oscar Wylee Coomera, Australia, can keep you up-to-date on your eyesight and eye health needs.
### Health Funds Accepted at Oscar Wylee
Oscar Wylee in Coomera Westfield Coomera accepts all major health funds, including Bupa, Medibank and HCF. Our friendly staff are trained to process your claim in-store with a valid health fund card, as well as answer any questions you have about your claim. Remember to bring your health fund card to your next appointment with Oscar Wylee Coomera for your eyewear and optometry needs.
Book Appointment
[Call us: (07) 2111 2606](tel:(07) 2111 2606)
[Leave a Review!](https://g.page/r/CZfWw2kK8N5ZEBM/review)