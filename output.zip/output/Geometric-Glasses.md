# Source: https://www.oscarwylee.com.au/glasses/silhouette/geometric.html

8 Products        
Showing 8
1. [](https://www.oscarwylee.com.au/miranda-optical.html)
[Miranda](https://www.oscarwylee.com.au/miranda-optical.html)
$199    
[2 pairs from $249](https://www.oscarwylee.com.au/miranda-optical.html)
2. [](https://www.oscarwylee.com.au/kitty-optical.html)
[Kitty](https://www.oscarwylee.com.au/kitty-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/kitty-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/kitty-optical.html)
3. [](https://www.oscarwylee.com.au/zeke-optical.html)
[Zeke](https://www.oscarwylee.com.au/zeke-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/zeke-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/zeke-optical.html)
4. [](https://www.oscarwylee.com.au/reece-optical.html)
[Reece](https://www.oscarwylee.com.au/reece-optical.html)
$199    
[2 pairs from $249](https://www.oscarwylee.com.au/reece-optical.html)
5. [](https://www.oscarwylee.com.au/kane-optical.html)
[Kane](https://www.oscarwylee.com.au/kane-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/kane-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/kane-optical.html)
6. [](https://www.oscarwylee.com.au/bowery-optical.html)
[Bowery](https://www.oscarwylee.com.au/bowery-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/bowery-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/bowery-optical.html)
7. [](https://www.oscarwylee.com.au/farrell-optical.html)
[Farrell](https://www.oscarwylee.com.au/farrell-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/farrell-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/farrell-optical.html)
8. [](https://www.oscarwylee.com.au/fariza-optical.html)
[Fariza](https://www.oscarwylee.com.au/fariza-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/fariza-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/fariza-optical.html)
8 Products        
Showing 8
Overview of Geometric Glasses Frame Materials and Build Quality Usage and Lifestyle Face Shape and Fit Orders, Shipping and Returns
## What are Geometric Glasses?
Geometric glasses refer to frames that feature straight lines and sharp angles. They often take the shape of hexagons or octagons and provide a more distinctive look compared to more conventional glasses shapes, such as circular or rectangular ones.
### Are Geometric Glasses Suitable for All Ages?
Yes, geometric glasses are suitable for all ages. People of different ages and genders can find a pair of geometric glasses to suit their face and sense of style.
### What Types of Geometric Glasses are Better for Women?
The types of geometric glasses that are better for [women](https://www.oscarwylee.com.au/glasses/collection/womens-glasses.html) will differ for each person. Some factors to consider are size, colour and material. Women may want to select from unisex geometric frames as well for more variety.
### What Types of Geometric Glasses are Better for Men?
The type of geometric glasses that are better for [men](https://www.oscarwylee.com.au/glasses/collection/mens-glasses.html) will vary by individual. They should consider fit, colour, material and how it complements their appearance. Men can opt for men's geometric glasses and unisex glasses.
### Can Geometric Glasses be Repaired If the Frame Gets Damaged?
Yes, geometric glasses from Oscar Wylee can be repaired or replaced under our 12-month warranty against manufacturing faults, in addition to your rights under the Australian Consumer Law. If the frame has factory-caused damage or faults, major failure, unacceptable quality or damage in transit within 12 months of purchase, we offer replacement or repair of your purchase, free of charge.
#### Do I Need an Eye Test Before Buying Geometric Glasses?
You may need an [eye test](https://www.oscarwylee.com.au/eye-care/eye-test) before buying geometric glasses if your prescription is outdated. An updated prescription is essential for prescription geometric glasses to ensure optimal visual clarity. You can [book an eye test](https://www.oscarwylee.com.au/booking) with one of our friendly optometrists online.
## What Materials are Commonly Used to Make Geometric Glasses Frames?
The materials that are commonly used to make geometric glasses include metal, acetate &amp; metal, acetate, TR90 and titanium.
* Metal: [Metal](https://www.oscarwylee.com.au/glasses/metal) geometric glasses offer a sleek, thin profile often made from stainless steel. They are perfect for those who want more understated eyewear, with the unique aesthetic of geometric shapes.
* Acetate &amp; Metal: Acetate and metal geometric glasses combine the minimal profile of metal with the more pronounced acetate, often on the temple tips.
* Acetate: Acetate geometric glasses offer a thicker rim for a bolder take on the geometric frame, often with more colourways.
* TR90: TR90 geometric glasses are made from the thermoplastic material that is renowned for being durable, flexible and lightweight.
* Titanium: [Titanium](https://www.oscarwylee.com.au/glasses/titanium) geometric glasses provide a lightweight, durable piece that is sometimes combined with other materials such as acetate.
### What are the Advantages of Acetate in Geometric Glasses?
The advantages of acetate in geometric glasses include strength, variety of colourways, and a lightweight feel. Read more about the advantages of acetate in geometric glasses below.
* Strength: Strength is characteristic of acetate frames as it can withstand a certain amount of wear and tear, for relatively long-lasting wear.
* Variety of Colourways: Acetate comes in a variety of colourways, showcasing many colours and patterns through its thicker frame. It is perfect for those who want bolder geometric frames.
* Lightweight Feel: A lightweight feel is notable in acetate geometric glasses, allowing for a more comfortable feel on the face.
### Why is TR90 Used in Lightweight Geometric Glasses?
TR90 thermoplastic may be used in lightweight geometric glasses as it is notable for its lightweight properties. [TR90](https://www.oscarwylee.com.au/glasses/tr90) is also characterised by its durability and flexibility.
#### Are Acetate Geometric Glasses Comfortable for All-Day Wear?
Yes, [acetate](https://www.oscarwylee.com.au/glasses/acetate-frame) geometric glasses are comfortable for all-day wear. For any geometric glasses frame, it is best to try on the frames before purchasing to see if they are an accommodating fit for your face.
## What Types of Lens Materials Are Available for Geometric Glasses?
The type of lens material that is available for geometric glasses at Oscar Wylee is premium engineered polymers. They are formed under strict quality control conditions for excellent quality.
### What are the Advantages of Plastic (CR-39) Lenses in Geometric Glasses?
The advantages of CR-39 lenses are their clarity and versatility, making them a widely used lens material. Compared to polycarbonate lenses, CR-39 lenses are thicker but offer excellent optical clarity.
### When Should You Choose High-Index Lenses for Geometric Glasses?
High-index lenses will be a good option for those with strong or high prescriptions. An optometrist will let you know if you need [high-index lenses](https://www.oscarwylee.com.au/glasses/eye/high-index-lenses) for your geometric glasses, which will likely be if you have a strong prescription.
#### Which Lens Material Is Best for Thin and Lightweight Geometric Prescription Glasses?
The lens material which can be best for thin and lightweight geometric prescription glasses will be premium engineered polymer lenses. These are offered at Oscar Wylee and can be made into high-index lenses for those with high prescriptions to ensure a thin profile.
## Are Geometric Glasses Suitable for Office Wear?
Yes, geometric glasses are suitable for office wear. Geometric glasses in neutral tones, such as black and silver, can be professional, sleek accessories for office attire.
### Can Geometric Glasses Be Styled for Casual Outfits?
Yes, geometric glasses can be styled for casual outfits. Any pair that matches the colour scheme of your casual outfit can be a perfect fit, such as a rose gold frame paired with a white t-shirt and light-washed jeans.
### Are Geometric Glasses Appropriate for Formal Occasions?
Yes, geometric glasses can be appropriate for formal occasions. For formal occasions such as dinner parties or corporate events, you may want to opt for a thin, metal geometric frame for a more minimal, elegant accessory.
#### Do Geometric Glasses Provide Good Lens Coverage?
Yes, geometric glasses can provide good lens coverage for your eyes for visual clarity, as any other glasses shape would.
## What Face Shapes Suit Geometric Glasses Best?
The face shapes that suit geometric glasses best are [round](https://www.oscarwylee.com.au/glasses/face-shapes/round) and [oval](https://www.oscarwylee.com.au/glasses/face-shapes/oval) face shapes. This is because the softer curves of round and oval faces are contrasted well by the sharp angles and lines characteristic of geometric glasses.
### How Do You Choose Geometric Glasses Based on Face Shape?
To choose geometric glasses based on [face shape](https://www.oscarwylee.com.au/glasses/face-shapes), assess your face shape, consider nose shape, choose your frame based on personal style, and try it on. Read more about choosing geometric glasses based on face shape below.
1. Assess your Face Shape: Assess your face shape. Round and oval face shapes are most compatible with geometric glasses, as the sharp lines and angles offset the soft curves of these face shapes seamlessly.
2. Consider Nose Shape: Consider nose shape when selecting a geometric frame. For example, if you have a low nose bridge, you may want geometric glasses that have adjustable nose pads.
3. Choose your Frame Based on Personal Style: Choose your frame based on personal style. For example, you may want a black metal geometric frame for classic style, or a bold patterned acetate frame to make a statement.
4. Try it On: Try on your geometric glasses before purchasing. This will allow you to assess how it complements your appearance and the fit.
#### What Makes Geometric Glasses Look Balanced on the Face?
Geometric glasses can look balanced due to their symmetrical appearance, as they often come in symmetrical shapes such as hexagons. This symmetry can create a balanced look with your natural features.
#### How do Different Nose Shapes Affect the Fit of Geometric Glasses?
Different [nose shapes](https://www.oscarwylee.com.au/glasses/nose-types), regardless of appearance, can find geometric glasses that fit them well. The part of the nose that will be most affected by the fit of the glasses is the nose bridge. A low nose bridge, which is flatter and less pronounced, for example, may benefit most from metal glasses that feature adjustable nose pads to properly grip onto the nose.
## Where Can I Buy Geometric Glasses Online from Oscar Wylee?
You can buy geometric glasses online from Oscar Wylee by going to the website and selecting the frames you want. Simply click 'Add to Cart' on your chosen frames and 'Proceed to Checkout' once you have filled out the relevant information, such as lens add-ons for each frame.
### What Shipping Options Are Available for Oscar Wylee Geometric Glasses?
The shipping option that is available for Oscar Wylee geometric glasses is free shipping for all orders placed on the website in Australia. These orders will usually be dispatched within 7-10 business days.
### How Can I Track My Geometric Glasses Order from Oscar Wylee?
You can track your geometric glasses order from Oscar Wylee simply by logging into your account. Go to the "My Orders" page to check the status of your shipment. Alternatively, you will receive an email with tracking information for your geometric glasses order.
#### How Long Does It Take to Process Refunds for Oscar Wylee Orders?
Oscar Wylee does not take refunds for prescription geometric glasses. This is because each pair of glasses is customised for you based on your prescription. However, if your glasses are faulty or do not meet your prescription requirements, you are entitled to a repair, replacement, or refund under the Australian Consumer Law.
[Prescription Glasses](https://www.oscarwylee.com.au/glasses.html)
[Women’s Glasses](https://www.oscarwylee.com.au/glasses/collection/womens-glasses.html)
[Men’s Glasses](https://www.oscarwylee.com.au/glasses/collection/mens-glasses.html)
[Senior Glasses](https://www.oscarwylee.com.au/glasses/collection/seniors.html)
[Glasses for Kids](https://www.oscarwylee.com.au/glasses/collection/kids-collection.html)