# Source: https://www.oscarwylee.com.au/clement-optical.html

219 Products        
Showing 15 of 219
1. [](https://www.oscarwylee.com.au/tia-optical.html)
[Tia](https://www.oscarwylee.com.au/tia-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/tia-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/tia-optical.html)
2. [](https://www.oscarwylee.com.au/torie-optical.html)
[Torie](https://www.oscarwylee.com.au/torie-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/torie-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/torie-optical.html)
3. [](https://www.oscarwylee.com.au/mumford-optical.html)
[Mumford](https://www.oscarwylee.com.au/mumford-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/mumford-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/mumford-optical.html)
4. [](https://www.oscarwylee.com.au/emma-optical.html)
[Emma](https://www.oscarwylee.com.au/emma-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/emma-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/emma-optical.html)
5. [](https://www.oscarwylee.com.au/solene-optical.html)
[Solene](https://www.oscarwylee.com.au/solene-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/solene-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/solene-optical.html)
6. [](https://www.oscarwylee.com.au/vivian-optical.html)
[Vivian](https://www.oscarwylee.com.au/vivian-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/vivian-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/vivian-optical.html)
7. [](https://www.oscarwylee.com.au/yumi-optical.html)
[Yumi](https://www.oscarwylee.com.au/yumi-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/yumi-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/yumi-optical.html)
8. [](https://www.oscarwylee.com.au/hailey-optical.html)
[Hailey](https://www.oscarwylee.com.au/hailey-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/hailey-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/hailey-optical.html)
9. [](https://www.oscarwylee.com.au/daisy-optical.html)
[Daisy](https://www.oscarwylee.com.au/daisy-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/daisy-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/daisy-optical.html)
10. [](https://www.oscarwylee.com.au/lupita-optical.html)
[Lupita](https://www.oscarwylee.com.au/lupita-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/lupita-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/lupita-optical.html)
11. [](https://www.oscarwylee.com.au/katie-optical.html)
[Katie](https://www.oscarwylee.com.au/katie-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/katie-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/katie-optical.html)
12. [](https://www.oscarwylee.com.au/tahlia-optical.html)
[Tahlia](https://www.oscarwylee.com.au/tahlia-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/tahlia-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/tahlia-optical.html)
13. [](https://www.oscarwylee.com.au/duckworth-optical.html)
[Duckworth](https://www.oscarwylee.com.au/duckworth-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/duckworth-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/duckworth-optical.html)
14. [](https://www.oscarwylee.com.au/sabrina-optical.html)
[Sabrina](https://www.oscarwylee.com.au/sabrina-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/sabrina-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/sabrina-optical.html)
15. [](https://www.oscarwylee.com.au/parker-l-optical.html)
[Parker Large](https://www.oscarwylee.com.au/parker-l-optical.html)
$169    
[2 pairs from $199](https://www.oscarwylee.com.au/parker-l-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/parker-l-optical.html)
219 Products        
Showing 15 of 219
Choosing Prescription Glasses Characteristics &amp; Suitability Styling &amp; FAQ
## How to Choose the Best Prescription Glasses for Women?
To choose the best prescription glasses for women, first book an eye test to get an optical glasses prescription, consider your face shape, browse women’s prescription glasses, consider material and colour, and try the frame on. Read on below for how to choose the [best prescription glasses for women](https://www.oscarwylee.com.au/glasses/best-women).
1. Book an Eye Test to get an Optical Glasses Prescription: Book an eye test to get an optical glasses prescription. An eye test is done by an Optometrist who will conduct a series of eye tests to assess your vision and what lenses you may need such as single vision lenses for shortsightedness or longsightedness, or multifocal lenses that provide clear vision for near, intermediate and distance vision. The lenses of your desired glasses will be fitted with this prescription so you can have optimal vision. [Book an eye test](https://www.oscarwylee.com.au/booking) with Oscar Wylee to receive your prescription and get your eyes assessed by a professional.
2. Browse Women's Prescription Glasses: Browse women's prescription glasses in store or online. Women's prescription glasses come in a range of colours, shapes and fits that are popular among female demographics. You may even want to explore unisex options.
3. Consider Face Shape: Considering face shape is important as some face shapes suit certain glasses shapes more than others. An example of this is round glasses suiting square and pear shaped faces, but not working as well with similarly round faces.
4. Consider Material and Colour: Consider material and colour together when selecting women's glasses. Titanium glasses provide strength and a thin, sleek profile while acetate frames are thicker with a wider variety of colourways. Consider material and colour together when selecting your glasses as these work together to create a frame best suited to your lifestyle and aesthetic.
5. Try the Frame on: Try the frame on before purchasing. Assess temple length and whether they are too long or short, and how the nose bridge feels on the top of your nose. A comfortable frame is the most important factor to consider as you will be wearing the glasses for long periods of time.
[](https://www.oscarwylee.com.au/mesa-optical.html)
[Mesa](https://www.oscarwylee.com.au/mesa-optical.html)
$169    
Add to Cart
[Shop Mesa](https://www.oscarwylee.com.au/mesa-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/mesa-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/mesa-optical.html)
[](https://www.oscarwylee.com.au/cara-optical.html)
[Cara](https://www.oscarwylee.com.au/cara-optical.html)
$169    
Add to Cart
[Shop Cara](https://www.oscarwylee.com.au/cara-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/cara-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/cara-optical.html)
[](https://www.oscarwylee.com.au/frieda-optical.html)
[Frieda](https://www.oscarwylee.com.au/frieda-optical.html)
$169    
Add to Cart
[Shop Frieda](https://www.oscarwylee.com.au/frieda-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/frieda-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/frieda-optical.html)
[](https://www.oscarwylee.com.au/parker-optical.html)
[Parker](https://www.oscarwylee.com.au/parker-optical.html)
$169    
Add to Cart
[Shop Parker](https://www.oscarwylee.com.au/parker-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/parker-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/parker-optical.html)
## How to Choose the Best Prescription Glasses for Men?
To choose the best prescription glasses for men, first book an eye test to an optical glasses prescription, consider your face shape, browse men’s prescription glasses, consider material and colour, and try the frame on. Read on below for how to choose the [best prescription glasses for men](https://www.oscarwylee.com.au/glasses/best-men-eyeglasses-for-every-face-shape).
1. Book an Eye Test to get an Optical Glasses Prescription: Book an eye test to get an optical glasses prescription. An eye test is done by an Optometrist who will conduct a series of tests on different machines to assess your vision and what lenses you may need such as single vision lenses for shortsightedness or longsightedness, or multifocal lenses that provide clear vision for near, intermediate and distance vision. The lenses of your desired glasses will be fitted with this prescription for clear sight. [Book an eye test](https://www.oscarwylee.com.au/booking) with Oscar Wylee to receive your prescription by having your eyes assessed by a professional.
2. Browse Men's Prescription Glasses: Browse [men's glasses](https://www.oscarwylee.com.au/glasses/collection/mens-glasses.html) in store or online. Glasses can come in a range of colours, shapes and fits that are considered more suited to men's styling preferences.
3. Consider Face Shape: Considering face shape is important as some face shapes suit certain glasses shapes more. The classic aviator shape for example is well suited to square and diamond face shapes, but may not pair well with round faces.
4. Consider Material and Colour: Consider material and colour together when selecting men's glasses. The characteristics and look of certain materials should be considered with various colours to see which best suits your aesthetic and lifestyle. For example, TR90 glasses are renowned for lightweightedness but often do not come in much colour variety as opposed to frames such as acetate which come in a range of colours and patterns.
5. Try the Frame On: Try the frame on before purchasing to assess compatibility. You will likely be wearing the frames regularly, so ensuring a comfortable fit is crucial for an unobtrusive and pleasant fit.
[](https://www.oscarwylee.com.au/andrew-optical.html)
[Andrew](https://www.oscarwylee.com.au/andrew-optical.html)
$169    
Add to Cart
[Shop Andrew](https://www.oscarwylee.com.au/andrew-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/andrew-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/andrew-optical.html)
[](https://www.oscarwylee.com.au/neal-optical.html)
[Neal](https://www.oscarwylee.com.au/neal-optical.html)
$169    
Add to Cart
[Shop Neal](https://www.oscarwylee.com.au/neal-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/neal-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/neal-optical.html)
[](https://www.oscarwylee.com.au/arnaud-optical.html)
[Arnaud](https://www.oscarwylee.com.au/arnaud-optical.html)
$169    
Add to Cart
[Shop Arnaud](https://www.oscarwylee.com.au/arnaud-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/arnaud-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/arnaud-optical.html)
[](https://www.oscarwylee.com.au/crane-optical.html)
[Crane](https://www.oscarwylee.com.au/crane-optical.html)
$169    
Add to Cart
[Shop Crane](https://www.oscarwylee.com.au/crane-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/crane-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/crane-optical.html)
### How to Choose the Best Prescription Glasses According to Skin Tone?
To choose the best prescription glasses according to skin tone, a person needs to first identify their skin undertone and then pick a complementary colour to it. Identify your skin tone by looking at the veins on the inner wrist. If the veins are blue or purple, this usually indicates a cooler tone. For cooler skin tones, similarly cooler colours such as blues, green, purple or greys will pair well. If the veins are more yellow or green looking, this can indicate a warm undertone. For warmer skin undertones, frames in warm and earthy colours, such as orange, brown, tortoiseshell and deep reds will look good. If the veins are more blue-green, then a person may have neutral undertones which can generally pair well with any colour frame.
### How to Choose the Best Prescription Glasses According to Face Shape?
To choose the best prescription glasses according to [face shape](https://www.oscarwylee.com.au/glasses/face-shapes) you must first identify what face shape you have and what glasses will best complement this face shape. The most common face shapes are round, square, pear, oval and heart face shapes. The ways to choose the best prescription glasses according to face shape are listed below.
* Round face shapes: [Round face shapes](https://www.oscarwylee.com.au/glasses/face-shapes/round) are characterised by a circular and smooth silhouette, lacking angles. Round face shapes are well-suited to rectangular or square frames, as these help to bring angles to the face. Even geometric frames such as the [Bowery optical glasses that can be shopped online or in store](https://www.oscarwylee.com.au/bowery-optical.html), pair well with round faces.
* Square face shapes: Square face shapes often have the same width and length. The [best glasses for square face shapes](https://www.oscarwylee.com.au/glasses/face-shapes/square) include round and oval glasses, as the natural curves of these shapes help soften the face. The intellectual look of the [Haskell Optical glasses to shop online or in store](https://www.oscarwylee.com.au/haskell-optical.html) is a great round frame.
* Pear face shapes: Pear face shapes are characterised by a narrow forehead and fuller jaw. Cat-eye and rectangular glasses are some of the [best glasses for pear faces](https://www.oscarwylee.com.au/glasses/face-shapes/pear) as they bring attention away from the broad jawline and towards the narrow forehead.
* Oval face shape: Oval face shapes can be complemented by various frame shapes due to their oblong shape which is longer, with less curves or angles. Prescription glasses [best for an oval face shape](https://www.oscarwylee.com.au/glasses/face-shapes/oval) include rectangular and square glasses for added definition, and aviators for a symmetrical, more balanced silhouette.
* Heart face shape: A heart-shaped face is characterised by a wider forehead and a smaller chin. Prescription [glasses best for heart-shaped faces](https://www.oscarwylee.com.au/glasses/face-shapes/heart) are square, cat-eye and oval glasses as these balance the natural proportions of the heart face.
### How to Choose the Best Prescription Glasses According to Eye Colour?
Eye colour does not play a huge role in determining the suitability of prescription glasses. Other factors like skin tone, face shape and size will influence how well you suit your prescription glasses. However, if you have blue or green eyes, similar cool colour frames such as silver, blue, and grey will make them pop. Similarly, warm coloured eye colours such as brown, hazel and amber will suit warm colour frames in colours such as brown, tortoiseshell or gold. For more on the luxe appeal of gold frames, read [Gold Frame Glasses: Are They Still in Style?](https://www.oscarwylee.com.au/glasses/gold-frame)
#### Are Titanium Frames Best for Prescription Glasses?
Titanium frames can be a great option for prescription glasses. They are a lightweight and durable material offering a sleek profile for those who want a minimalist accessory. Whether [titanium glasses frames](https://www.oscarwylee.com.au/glasses/materials/titanium.html) are the best prescription eyewear choice, will ultimately depend on the wearer and their preferences.
#### Are Prescription Glasses Suitable for Seniors?
Prescription glasses are definitely suitable for seniors. In fact, many seniors will likely need glasses as 93% of people over the age of 65 are affected by a long-term vision disorder according to the Australian Institute of Health and Welfare in a 2023 study. [Senior glasses](https://www.oscarwylee.com.au/glasses/collection/seniors.html), like other glasses, come in many colours, shapes and sizes to appeal to any sense of style.
## How to Buy Prescription Glasses According to Bridge Width?
Prescription glasses can be bought according to bridge width for a compatible fit such as Narrow, Medium and Wide. There are various [types of bridges for glasses](https://www.oscarwylee.com.au/glasses/nose-bridge-types) to accommodate different types of faces. Read about how to buy prescription glasses according to bridge width below.
* Narrow: Narrow prescription glasses are available for petite and thinner faces who need a more compatible fit that won't slip off their face.
* Medium: Medium prescription glasses are accommodating for average width faces, often compatible with both men and women.
* Wide: Wide titanium glasses can come in many frame shapes and aim to accommodate broader and wider faces for a fit that isn't too constricting on the face.
[](https://www.oscarwylee.com.au/lucien-optical.html)
[Lucien](https://www.oscarwylee.com.au/lucien-optical.html)
$169    
Add to Cart
[Shop Lucien](https://www.oscarwylee.com.au/lucien-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/lucien-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/lucien-optical.html)
[](https://www.oscarwylee.com.au/opal-optical.html)
[Opal](https://www.oscarwylee.com.au/opal-optical.html)
$169    
Add to Cart
[Shop Opal](https://www.oscarwylee.com.au/opal-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/opal-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/opal-optical.html)
[](https://www.oscarwylee.com.au/mumford-optical.html)
[Mumford](https://www.oscarwylee.com.au/mumford-optical.html)
$169    
Add to Cart
[Shop Mumford](https://www.oscarwylee.com.au/mumford-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/mumford-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/mumford-optical.html)
### Which Colour Pattern is Best for Prescription Glasses?
There is no singular best colour pattern for prescription glasses as it is ultimately up to the wearers own aesthetic. Common glasses colour patterns include matte, solid, tortoise, transparent and two-toned. Read on for the various colour patterns that could be the best for prescription glasses frames.
* Matte: Matte glasses refer to a low-gloss, flat-looking eyewear finish for a smooth, minimal aesthetic.
* Solid: Solid colour frames are classic and versatile, whether pink or blue solid frames, to complement a variety of colour schemes.
* Tortoise: Tortoise shell patterns offer a blend of often brown tones and are an effortlessly stylish accessory for a chic uplift to any outfit.
* Transparent: Transparent, clear frames are popular due to their minimalist profile for those who prefer subtle eyewear.
* Two-toned: Two-toned glasses are for those who want to capture striking colour in their eyewear through a unique blend of colour.
#### Are Titanium Frames Best for Oversized Prescription Glasses?
Titanium frames can be a good option for oversized prescription glasses. However, they are not necessarily the best as this will be dependent on the wearer. Titanium frames are thin and while they can have oversized lenses, this thinness may not provide as much of a statement piece. Acetate [oversized glasses](https://www.oscarwylee.com.au/glasses/silhouette/oversized.html), with their thicker frame and often more varied colourways will provide a bold accent for your eyewear.
[](https://www.oscarwylee.com.au/kato-optical.html)
[Kato](https://www.oscarwylee.com.au/kato-optical.html)
$169    
Add to Cart
[Shop Kato](https://www.oscarwylee.com.au/kato-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/kato-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/kato-optical.html)
[](https://www.oscarwylee.com.au/aaron-optical.html)
[Aaron](https://www.oscarwylee.com.au/aaron-optical.html)
$199    
Add to Cart
[Shop Aaron](https://www.oscarwylee.com.au/aaron-optical.html)
[2 pairs from $249](https://www.oscarwylee.com.au/aaron-optical.html)
#### Are Prescription Sunglasses a Good Option for Teens Outdoors?
Prescription sunglasses can be a good option for teens outdoors who require vision correction and sun protection. They are the perfect accessory for beach days, picnics, and walks on sunny days. However, teens who participate in active sports such as soccer, running or volleyball might want to try [active sunglasses](https://www.oscarwylee.com.au/sunglasses/collection/active-collection.html), which can be made from TR90, a strong and impact-resistant material.
### What Factors Affect the Price of Prescription Glasses?
The price factors for prescription glasses at Oscar Wylee will vary depending on the characteristics of the frame such as material, lens type and lens add-ons. One pair of prescription glasses in Oscar Wylee’s core range starts from $169, 2 pairs from $199 and 3 pairs from $249. Additionally, one pair of prescription glasses in Oscar Wylee’s Iconic range starts from $199 and 2 pairs start from $249. It should be noted that lens thickness, material and other lens add-ons such as the Oscar Wylee BluLite Filter will affect overall pricing of your frames. We have a range of eyewear materials at Oscar Wylee such as acetate, bioacetate, and various metals such as stainless steel, titanium and memory metal. The Iconic range encompasses premium materials such as memory metal and titanium, thus affecting the price points of these frames. Read Oscar Wylee’s full[price guide](https://www.oscarwylee.com.au/price-guide/) for more information.
### How to Adjust Prescription Glasses for a Comfortable Fit?
To adjust your prescription glasses for a comfortable fit, you should bring your frame to the optical retailer you purchased them from to have them adjusted professionally. At Oscar Wylee, we offer lifetime adjustments for those who have purchased glasses. Simply take them to your nearest Oscar Wylee store to have them adjusted by one of our friendly retail staff.
## What Lens Types Work Best for Prescription Glasses?
There is no singular lens type that works best with prescription glasses. It is ultimately up to the wearer, their lifestyle and visual needs. For example, if a person frequently uses digital devices for work or recreational activities a blue light filter will be useful as these block blue light that emits from devices, which can lead to eye strain. For those who want convenient eyewear, Transitions® lenses are lenses that automatically darken when in the sun and quickly return to clear indoors.
### What Outfits Work Best with Stylish Prescription Glasses?
Any outfit can work best with stylish prescription glasses. Prescription glasses are endlessly versatile in their appearance to suit any face shape and clothing style. For the eclectic, bright coloured frames in blue, pink, red and green can be a stylish accessory to similarly colourful patterned or solid coloured outfits. For those who frequently wear business attire such as suits, pantsuits, or formal dresses, timelessly sophisticated prescription frames in black, greys and navy always pair seamlessly. Any prescription frame can be a stylish one, as long as it complements the colour palette of your clothing.
### How Long Does It Take to Get Prescription Glasses?
It takes around 7-10 business days for your prescription glasses order to arrive at an Oscar Wylee store for pick-up. It should be noted that it will take 2 weeks to be delivered if you are expecting a home delivery. An email will be sent to you confirming the order alongside an order tracking link for your convenience.
[Prescription Glasses](https://www.oscarwylee.com.au/glasses.html)
[Women’s Glasses](https://www.oscarwylee.com.au/glasses/collection/womens-glasses.html)
[Men’s Glasses](https://www.oscarwylee.com.au/glasses/collection/mens-glasses.html)
[Senior Glasses](https://www.oscarwylee.com.au/glasses/collection/seniors.html)
[Glasses for Kids](https://www.oscarwylee.com.au/glasses/collection/kids-collection.html)