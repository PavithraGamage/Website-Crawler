# Source: https://www.oscarwylee.com.au/glasses/thin-frame

# Thin Glasses: The Growing Popularity of Thin Frame Glasses
Published on April 2nd, 2025
Updated on March 21st, 2025 
Australia
Australia
Canada
Canadian French

Thin glasses
are characterised by their slim and lightweight appearance. They can be
made from a range of different materials but the most common is Ultem,
TR90 or metal (stainless and titanium). Thin glasses can be a popular choice of frames due to their smart, sleek
look, minimal feel and appearance. Thin glasses are a long-standing popular
frame and continue to remain popular in the eyewear industry due to their
versatility and ability to complement instead of overwhelming your facial
features. Thin frames offer wearers a lightweight look that is both modern
and minimal. Titanium glasses refer to glasses frames made from the metal
titanium. They are a lightweight, durable and corrosion-resistant material,
making them a favourable choice for eyewear. Continue reading for an
in-depth guide on thin glasses, its distinct features and recommendations.
Book your next eye test at Oscar Wylee for excellent eyecare!
We have a dedicated team at all our stores and offer a wide range of
styles and colours for thin frames.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Definition](#definition) [Benefits](#benefits)
[How to Choose](#how_to_choose)
[Durability](#durability)
## What Are Thin Glasses?
Thin glasses are
a style of glasses that are slim in appearance and feel and are
commonly made from Ultem, TR90 or metal (stainless and titanium). Thin glasses are generally available in a wide variety of styles,
shapes and colours. Thin frames for glasses may likely be a popular type
of
[women’s glasses](https://www.oscarwylee.com.au/glasses/collection/womens-glasses.html)
or men’s glasses, due to their light look on the face and minimal
nature that they can subtly elevate your look without adding too much
visual clutter.
## What are the Benefits of Lightweight Titanium Glasses?
The benefits of lightweight titanium glasses
are their comfortable feel, corrosion resistance properties and
minimalist appearance.
The benefits of lightweight titanium eyeglasses frames are listed below.
* Comfortable Feel: One of the benefits
of lightweight titanium glasses is their comfortable feel. Their
lightweight nature helps the frame to sit lightly instead of feeling
heavy on the nose and temples.
* Corrosion Resistance Properties: Another benefit of lightweight titanium glasses is their corrosion
resistance properties, which aid in their long-lasting durability.
Titanium frames are corrosion-resistant due to their natural external
protective layer formed when exposed to oxygen according to Prando et
al., 2018.
* Minimalist Appearance: A distinct
benefit of lightweight titanium glasses is their minimalist
appearance. Their thin silhouette and natural colour contribute to
achieving a visually simple and essential look.
### How to Choose the Best Titanium Glasses for a Slim Frame?
To choose the best titanium glasses for a slim frame,
opt for lightweight materials, contemplate your face shape and
finally, select suitable lenses. The steps on how to choose the best titanium glasses for a slim
frame are listed below.
* Opt for lightweight materials: Opt
for lightweight materials when choosing the best titanium glasses
for a slim frame as some materials are heavier than others.
* Contemplate your face shape: Contemplate your face shape when choosing the best titanium glasses
for a slim frame. Choosing your frames according to your face shape
can help with flattering your natural features and overall
suitability.
* Select suitable lenses: Select the
best titanium glasses for a slim frame by selecting suitable frames.
Select suitable lenses through one option, gravitating towards
high-index lenses if you require a stronger prescription. Think
about other lens add-ons that you may need and whether they are
suitable for lightweight frames.
### How Do Titanium Eyeglass Frames Compare to Other Glasses?
Titanium eyeglasses are often
lighter and more corrosion-resistant compared to other glasses due
to the natural properties of titanium.
Unlike materials such as acetate which can be slightly more bulky,
[titanium](https://www.oscarwylee.com.au/glasses/titanium)
is known for its lightweight nature. This ensures the wearer is fitted
with a comfortable, unobtrusive frame. While materials such as
titanium and aluminum are considered corrosion-resistant, titanium is
even more so hence why it is more expensive than these metal frames.
It's characteristics such as these that can make titanium a more
viable option over other materials.
### What Are the Best Thin Glasses Frames for Men?
The best thin glasses frames for men
may include round frames, square frames and aviator frames. The
best thin glasses frames for men are listed below.
* Round Frames: Round frames may be a
suitable option for men as they flattering on different face shapes.
They are especially helpful in complementing those with strong
facial angles such as square faces. Their simple design means they
can work easily with different outfit styles and occasions. An Oscar
Wylee round, thin glasses frame for men can include the
[Kato frame](https://www.oscarwylee.com.au/kato-optical.html).
* Square Frames: Square frames are one
of the best thin glasses frames for men as they may be well suited
to round, oval and heart face shapes. Thin square frames can help
add interesting lines and angles to more rounded facial features. An
Oscar Wylee square, thin glasses frame for men may include the
[Clement frame](https://www.oscarwylee.com.au/clement-optical.html).
* Aviator Frames: Aviator frames can
be a stylish thin frame option for men with their distinctive shape
and design. Thin aviator frames can be a good option for those who
want to elevate their regular eyewear game. An Oscar Wylee thin,
aviator frame for men can include the
[Taku frame](https://www.oscarwylee.com.au/taku-optical.html).
[](https://www.oscarwylee.com.au/kato-optical.html)
[Kato](https://www.oscarwylee.com.au/kato-optical.html)
$169    
Add to Cart
[Shop Kato](https://www.oscarwylee.com.au/kato-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/kato-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/kato-optical.html)
[](https://www.oscarwylee.com.au/clement-optical.html)
[Clement](https://www.oscarwylee.com.au/clement-optical.html)
Out of stock
[Shop Clement](https://www.oscarwylee.com.au/clement-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/clement-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/clement-optical.html)
[](https://www.oscarwylee.com.au/taku-optical.html)
[Taku](https://www.oscarwylee.com.au/taku-optical.html)
$169    
Add to Cart
[Shop Taku](https://www.oscarwylee.com.au/taku-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/taku-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/taku-optical.html)
#### Are Titanium Frames the Lightest Eyeglass Frames Available?
Yes, titanium frames
are one of the lightest eyeglass frames available, however, there
are also other materials that are optimal for lightweight frames
such as Ultem and [TR90](https://www.oscarwylee.com.au/glasses/tr90). Ultem is an ideal material for
[lightweight glasses](https://www.oscarwylee.com.au/glasses/materials/lightweight.html)
and features strength and resistance to heat making it an excellent
eyewear choice to withstand everyday life. TR90 is suitable for
light eyeglass frames and is known for its durability and impact
resistance, making it perfect for those on the go. Learn more about
[lightweight eyeglasses, including materials, design, and
comfort](https://www.oscarwylee.com.au/glasses/lightweight-frame).
### What are Thin Rimmed Glasses?
Thin-rimmed glasses are
a style of glasses that have a minimalist and sleek design with
very narrow or thin borders around the lenses.
These frames are often made from materials like metals (titanium and
stainless steel), Ultem or TR90 to give them a delicate, and minimal
look compared to more traditional, thicker frames.
### What Makes Titanium Eyeglass Frames a Durable Option?
Titanium eyeglasses frames are a durable option
due to the special mix of properties that contribute to their
strength.
Titanium frames make durable, flexible and light glasses as a result
of their high strength-to-weight ratio according to Standford Advanced
Materials. Additionally, titanium frames possess optimal elasticity
and corrosion resistance allowing them to maintain stability through
long periods of wear.
## What are the Advantages of Titanium Reading Glasses?
The advantages of titanium reading glasses
are their lightweight feel, durability and style. The advantages
of titanium
[reading glasses](https://www.oscarwylee.com.au/reading_glasses.html)
are listed below.
* Lightweight Feel: An advantage of
titanium reading glasses is their lightweight feel making them
comfortable to wear for long periods. Their light nature can help
their minimal feel on your nose and temples.
* Durability: Titanium reading glasses
feature durability and strength which helps them maintain quality
throughout daily use. Their distinct durability and strength can aid
in preventing easy breakage or bending.
* Style: The style of titanium reading
glasses is minimal, sleek and light making them an easy frame to
incorporate into your daily outfits and varying occasions. They can
subtly enhance your overall appearance without dominating your facial
features.
### Can You Get Thin Rimless Glasses with Titanium Frames?
No, you cannot get thin rimless glasses with titanium frames.
Rimless glasses are a style of glasses that do not have a frame, its nose bridge and temples connect directly to the lenses.
However, you may be able to get semi-rimless titanium glasses or
rimless glasses with titanium arms at certain eyewear retailers. We do
not currently sell rimless glasses at Oscar Wylee, however, we have a
wide range of titanium and lightweight frames available in various
styles and colours.
Visit our Optometrists In-store!
Find your nearest Oscar Wylee location for excellent optometry
services. While you're here you can browse our range of stylish
glasses.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
## What Are the Benefits of Lightweight Glasses for Everyday Use?
The benefits of lightweight glasses for everyday use are their
comfort, minimalist appeal and durability. The benefits of
lightweight glasses for everyday use are listed below.
* Comfort: Lightweight glasses for
everyday use can benefit individuals as they provide distinct comfort
due to their lightweight and thin nature. Lightweight glasses may have
a minimal feel on your nose and temples compared to regular,
non-lightweight glasses.
* Minimalist Appeal: Lightweight glasses
offer that perfect minimalist appeal, especially for those who
gravitate towards more simple yet elegant designs. Their minimalist
style additionally allows them to blend in with but also elevate a
range of fashion aesthetics.
* Durability: Lightweight glasses are
perfect for everyday use since they do not feel heavy to wear but they
are also strong and able to endure long periods of wear and handling.
When handled properly, they are not vulnerable to easily breaking.
### Can Titanium Eyewear Be Both Stylish and Durable?
Yes, titanium eyewear can be both stylish and durable. Titanium is a
lightweight, strong, and corrosion-resistant metal, making it an
optimal material for glasses frames.
Its durability ensures the long life of frames and can maintain
quality during extended periods of use, while its sleek, and thin
appearance adds a stylish, smart and minimalist touch.
Titanium's ability to be moulded into thin frames without compromising
strength makes it a popular choice for eyewear that is both stylish
and durable.
## What are Ultra-Light Glasses Frames Made From?
Ultra-light glasses frames are most commonly made from
Ultem or TR90. However, they can be made from many of the typical
materials used for regular glasses frames.
### How to Choose the Best Lightweight Frames for Glasses?
To choose the best lightweight frames for glasses
consider the frame fit, assess the suitability of your prescription
and consider your lifestyle. The steps to follow when choosing the best
[lightweight frames](https://www.oscarwylee.com.au/glasses/lightweight-frame)
for glasses are listed below.
1. Consider the frame fit: Consider the
frame fit of lightweight frames for the best glasses by ensuring the
glasses properly fit your face. They should contour your face well
and rest lightly and comfortably on the nose temples and ears
without excessively moving.
2. Assess the suitability of your prescription: Assess the suitability of your prescription. You can check with the
optometrist to make sure your prescription is compatible with
lightweight frames first. You can also opt for high-index lenses if
you have a strong prescription as these are the lightest lenses
available.
3. Consider your lifestyle: Consider
your lifestyle when choosing the best lightweight frames. Those with
more active routines may benefit from the flexibility and strength
of TR90 and memory metal glasses. However, those with less active
routines may prefer the reliability and comfort of titanium or Ultem
frames. Learn more about[memory metal glasses, including their durability, flexibility, and
lightweight](https://www.oscarwylee.com.au/glasses/memory-metal)
qualities.
### How Do Titanium Frame Glasses Compare to Regular Metal Frames?
Titanium frame glasses
may be considered lighter compared to regular metal frames.
Titanium frames are known for their strength and durability while
still providing their unique lightweight nature. Other
[metal frames](https://www.oscarwylee.com.au/glasses/metal)
such as stainless steel, which also features strength and durability,
may not typically be classed as a lightweight material for frames.
### How Do Thin Glasses Frames Impact Your Overall Look?
Thin glasses frames
can impact your overall look by adding a subtle and sleek visual
element. Thin glasses frames can help create a more delicate, refined
appearance making them perfect for a minimalist style. Thin frames
don't dominate your facial features allowing them to stand out
naturally. They are often perceived as stylish, and smart and can work
well with various face shapes. Additionally, thin frames can be
lighter and more comfortable.
### How Do Ultra Lightweight Glasses Frames Improve Comfort for All-Day
Wear?
Ultra-lightweight glasses frames
may improve comfort for all-day wear as they can sit lightly on the
nose, temples and ears.
When wearing ultra-lightweight glasses, the physical feel on certain
parts of your face and head may not be as noticeable as other
non-lightweight glasses. The reduced weight may help with longer wear.
This combination of lightness and comfort makes ultra-lightweight
frames ideal for those seeking practical eyewear that can be worn
throughout the day without discomfort or too much weight.
Read Thin Glasses: The Growing Popularity of Thin Frame Glasses in
other Oscar Wylee regions and their languages.
Australia
Australia
Canada
Canadian French

Oscar Wylee Accepts Leading Health Funds
Be sure to bring your health fund details when you visit and we can
help you use your health benefits to cover some of the cost.
[Explore Health Funds](https://www.oscarwylee.com.au/health-funds.html)
Need to See an Optometrist?
Visit Oscar Wylee for a high-quality eye test performed by our
dedicated optometrists.
[Book an eye test](https://www.oscarwylee.com.au/booking)