# Source: https://www.oscarwylee.com.au/glasses/eye/strain

# Eye Strain Headache: Definition, Treatment, Prevention, and Diagnosis
Published on June 9th, 2023
Updated on September 24th, 2024
Australia
[Australia](https://www.oscarwylee.com.au/glasses/eye/strain)
[New Zealand](https://www.oscarwylee.co.nz/glasses/eye/strain)
[Canada](https://oscarwylee.ca/glasses/eye/strain)
[Canadian French](https://oscarwylee.ca/fr/glasses/eye/strain)
An eye strain headache occurs when there is pain in the head and around
the eyes which is most commonly caused by uncorrected refractive errors or
other vision issues. It can also be caused by prolonged time spent looking
and working on a computer screen or other digital screens, this is known
as digital eye strain. Eye strain headache side effects and symptoms
include sore eyes, sensitivity to light and dry eyes. Eye strain is a
common eye-related issue often caused by looking at digital screens for
hours at a time and concentrating intensely on certain tasks such as
reading and writing. Some eye strain headache precautions include taking
frequent breaks from tasks that require intense concentration, using
artificial tears to add moisture to the surface of the eye and limiting
screen time where possible. Sometimes, eye strain headaches can be
mistaken for other headaches which have systemic consequences. Therefore,
you should see a health professional if you are experiencing
headaches.
Keep reading to learn more about eye strain headache definition, their
causes and symptoms and how they are diagnosed.
Need an updated prescription?
Our optometrists are available to provide eye tests, so you can get a new
prescription and pick out your frames on the same day!
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Definition](#Definition) [Causes](#Causes)
[Symptoms](#Symptoms) [Complications](#Complications)
## What is Eye Strain Headache?
An eye strain headache is&nbsp;a condition in which the head or eyes are in pain due to eye strain
which is a common eye condition caused by the eyes concentrating
intensely for long periods of time.&nbsp;According to Health Direct, a headache is among the symptoms of
eye strain. Other symptoms of eye strain include sensitivity to light,
a burning sensation in the eyes, double or blurry vision and
difficulty concentrating. An eye strain headache can be treated and
prevented by addressing eye strain which involves frequently resting
the eyes and using lubricating eye drops.
## How Common is Eye Strain Headache?
An eye strain headache is&nbsp;not a common eye problem as this symptom of eye strain is
uncommon.&nbsp;According to an article written by the American Migraine
Foundation, eye strain is an uncommon cause of headaches and is rarely
associated with any function-limiting activity. The article explains
that headaches are not typically caused by anything relating to eye
problems such as eye strain, rather they are due to a headache
disorder such as a migraine. According to the Mayo Clinic, the eye
condition eye strain is a common condition caused by the eyes becoming
tired after intense use. The most common form of eye strain is digital
eye strain and according to CooperVision Australia, approximately 70%
of adults experience digital eye strain symptoms.
## How Does an Eye Strain Headache Develop?
An eye strain headache is&nbsp;typically developed when a person concentrates intensely for a long
period of time on certain tasks and activities such as driving or
reading and writing.&nbsp;Digital eye strain is a common form of eye strain that is
developed by spending prolonged periods on digital screens such as a
computer, tablet or smartphone.
### What Does Eye Strain Headache Feel Like?
An eye strain headache can feel different to each person, but
some&nbsp;common feelings and symptoms include dull pain or ache behind the
eyes, eye fatigue, blurred vision and pain in the shoulders, neck
and back.&nbsp;A regular headache, according to the Cleveland Clinic, is
often described as a pressure felt in the head that is a constant,
dull or sharp throbbing.
### How Long Does an Eye Strain Headache Usually Last?
It is difficult to determine how long an eye strain headache lasts
as it&nbsp;can vary depending on the person.&nbsp;According to HealthDirect, eye strain typically goes away
once you rest your eyes and stop the activity that is causing the
discomfort such as working on a computer or reading.
## What are the Causes of Eye Strain Headaches
According to Migraine &amp; Headache Australia,&nbsp;the most common cause of an eye strain headache is an uncorrected
refractive error.&nbsp;Refractive errors are a category of visual issue that occurs
when light entering the eye does not properly hit a person’s retina.
This could mean light hits before the retina, or behind the retina,
resulting in vision issues that affect a person’s ability to see
clearly. Common refractive errors include myopia, hyperopia and
astigmatism. According to Migraine &amp; Headache Australia, other
eye-related problems that cause eye problems include inflammatory
conditions such as conjunctivitis and iritis.
Eye strain headaches can also be caused by prolonged periods of time
of intense concentration on tasks such as reading and writing and
especially on digital screens such as working on a computer for work
or school. The eyes may become fatigued and irritated from the intense
concentration, causing the muscles to become strained, leading to a
headache.
### What Medical Conditions Cause Headaches From Eye Strain?
There are no medical conditions that cause headaches from eye
strain&nbsp;as this eye issue is commonly caused by refractive errors and
spending too much time concentrating on digital screens which are
not medical conditions.
## What are the Symptoms of an Eye Strain Headache?
The symptoms of an eye strain headache are mostly the same as the
symptoms of eye strain. The symptoms of an eye strain headache
include&nbsp;sore eyes, dry eyes, neck, shoulder, or backaches, sensitivity to
light, trouble concentrating, blurry vision and difficulty keeping
your eyes open.&nbsp;The symptoms of eye strain headaches and their definitions are
listed below.
* Sore eyes: Sore eyes is a symptom of
eye strain that causes the eyes to feel irritated or mildly painful
which can occur due to many different factors.
* Dry eyes:&nbsp;Dry eyes
is a condition caused by a lack of tear production meaning there is an
insufficient amount of moisture on the eye’s surface to maintain their
health.
* Neck, shoulder, or backaches:&nbsp;Neck, shoulder, or backaches can be symptoms of
tension headaches and can also occur alongside digital eye strain.
* Sensitivity to light:&nbsp;Also known as photophobia, sensitivity to light is
a common symptom of eye-related issues including eye strain headaches
and eye strain in general.
* Trouble concentrating:&nbsp;An eye strain headache can make it difficult to
focus on certain tasks especially those that require a significant
amount of effort like reading and writing.
* Blurry vision:&nbsp;Blurry vision refers to a person’s vision being
unclear and hazy which may be caused by many eye conditions such as
eye strain and also refractive errors including astigmatism and
hyperopia.
* Difficulty keeping your eyes open:&nbsp;It can be difficult to keep your eyes open when
you are experiencing an eye strain headache or a headache in general.
This may be due to a sensitivity to light or pain and irritation.
### 1. Sore Eyes
Sore eyes is&nbsp;a symptom of eye strain that causes the eyes to feel irritated or
mildly painful&nbsp;which can occur due to many different factors.&nbsp;[Sore eyes](https://www.oscarwylee.com.au/glasses/eye/sore/remedies)&nbsp;can be accompanied by symptoms such as blurry vision, watery
or tearing eyes, dry eyes and eye pain. Sore eyes caused by eye
strain may be prevented by taking regular breaks to let the eyes
rest and limiting screen time as this could be aggravating the eye
strain.
### 2. Dry Eyes
Dry eyes is a condition&nbsp;caused by a lack of tear production meaning there is an
insufficient amount of moisture in the eyes to maintain their
health.&nbsp;Eye strain can cause&nbsp;[dry eyes](https://www.oscarwylee.com.au/glasses/eye/dry-eyes)&nbsp;as a person with eye strain will typically blink less. Other
causes of dry eyes include aging, medical conditions, hormonal
changes and eye surgery. People who have dry eyes may experience
itchiness, irritation and a gritty sensation in the eyes.
### 3. Neck, Shoulder, or Backaches
Neck, shoulder, or backaches&nbsp;can be symptoms of tension headaches which can cause pain due to
tight muscles.&nbsp;Neck, shoulder and backaches&nbsp;commonly occur alongside digital eye strain as the position of the
computer or monitor may be putting stress on the body.&nbsp;To prevent these aches when working on a computer, adjust the
monitor to improve your comfort levels. According to the Queensland
Government’s Health Department, they recommend the monitor should be
positioned an arms-length away and directly in front of you with the
top of the monitor at or just under eye level to ensure your neck is
not straining upwards or downwards.
### 4. Sensitivity to Light
Sensitivity to light is a common symptom of eye-related issues
including eye strain. An increased&nbsp;[sensitivity to light](https://www.oscarwylee.com.au/glasses/eye/sudden-light-sensitivity), also known as photophobia,&nbsp;describes the eyes struggling to look at bright light.&nbsp;The eyes can often be aggravated by the light emitted from a
digital screen when working on a computer all day. To reduce this
irritation, you may decrease the brightness of the screen or turn on
the blue light filter if available.
A sensitivity to light can also be a sign of another medical
condition. It is important to have this symptom checked by a
healthcare professional as soon as possible.
### 5. Trouble Concentrating
A headache can cause trouble concentrating&nbsp;due to the pain or throbbing which can distract you from the task
at hand.&nbsp;An eye strain headache can make working on a computer and
reading and writing very difficult as when your eyes focus too long,
it can overtax the eyes making it difficult to focus. The eye
muscles can also become overworked, therefore, you should take
breaks and rest the eyes when you are struggling to
concentrate.
### 6. Blurry Vision
Blurry vision&nbsp;refers to a person’s vision being unclear and hazy which may be
caused by many eye conditions such as eye strain.&nbsp;Blurry vision may also be caused by refractive errors such as
presbyopia and myopia. According to Optometrists.org, uncorrected
refractive errors can cause headaches as the eyes are straining to
see objects clearly.&nbsp;[Blurry vision](https://www.oscarwylee.com.au/glasses/eye/blurred-vision)&nbsp;can be corrected with prescription glasses if it is caused by
a refractive error.
### 7. Difficulty Keeping Your Eyes Open
A symptom of eye strain is a person may have difficulty keeping
their eyes open&nbsp;due to a sensitivity to light or pain and irritation.&nbsp;Treatments for this symptom of eye strain include taking
frequent breaks to rest the eyes and the eye muscles until the
discomfort goes away.
It is important to seek medical attention if you are unable to
open your eyes or struggle to keep them open for a prolonged
period of time.
### What are the Eye Strain Headache Complications?
There are&nbsp;no complications of eye strain or an eye strain headache.&nbsp;An eye strain headache can cause uncomfortable symptoms but
will not progress past a dull ache or pain. If you are experiencing
severe pain or a prolonged headache, seek medical attention to have
your symptoms assessed by a healthcare professional.
Visit a store near you
Come and see our friendly staff who can assist you in all your optical
and eyewear needs.
[Find a store](https://www.oscarwylee.com.au/locations/)
## How are Eye Strain Headaches Diagnosed?
Eye strain headaches can be&nbsp;diagnosed by an eye care professional, typically an
optometrist.&nbsp;They will enquire about your symptoms and when the headache
occurs to learn if there is a pattern associated with headaches. This
will be part of a regular eye test that will include an assessment of
your vision and eye health.
### Can Eye Strain Headaches be Diagnosed Just by Their Symptoms?
No,&nbsp;an optometrist will not diagnose an eye condition without first
performing a comprehensive eye test&nbsp;to determine the health of a person’s eye and assess their
vision. Identifying symptoms of an eye strain headache is an
important aspect of diagnosis but is not solely relied upon.
### How Can I Identify Whether My Headache is Caused by Eye Strain or
Another Condition?
To identify whether your headache is caused by eye strain or
another condition, you need to&nbsp;be aware and note when the headaches are occurring and what you
have been doing before they started.&nbsp;According to the American Migraine Foundation, if a headache
is present when you wake up or is causing you to wake up, the
headache is not caused by eye strain. If you experience a headache
after doing tasks that require intense concentration from the eyes
such as working on a computer, it may be caused by eye strain. It is
important to have your vision and eye health assessed by an
optometrist if you think you have an eye strain headache as you may
need prescription glasses. An optometrist can assess for other eye
conditions that may be causing the headache.&nbsp;If you think that your headache could be caused by something other
than eye strain, seek medical attention.
## What are the Treatments for an Eye Strain Headache?
Treatments for an eye strain headache often&nbsp;involve practices that work to treat eye strain, as a headache is a
symptom of this eye condition.&nbsp;Eye strain headache relief and treatment include using
lubricating eyedrops, also known as artificial tears, as they add
moisture to the surface of the eye, relieving discomfort. Another
treatment includes resting the eyes meaning stopping any tasks that
require intense concentration such as working on a computer. Finally,
bright or artificial light can cause irritation for people with eye
strain and eye strain headaches, therefore, avoiding light and resting
in a dim room may help with the headache. At&nbsp;Oscar Wylee,&nbsp;we offer a blue light filter that can be added to a pair of
optical glasses which may also help in reducing digital eye
fatigue.
## How are Eye Strain Headaches Prevented?
Eye strain headaches may be prevented by performing activities aimed
to reduce eye strain which, therefore, prevents its symptoms, one of
which is a headache. Ways to prevent eye strain include&nbsp;practising the 20-20-20 rule, taking frequent breaks, limiting screen
time and using proper lighting when reading.The ways to prevent eye strain headaches and their definitions are
listed below.
* 20-20-20 rule: The 20-20-20 rule is
used to prevent and relieve eye strain when working on a digital
screen. This rule suggests that for every 20 minutes of screen time,
you look away for 20 seconds and focus your eyes on something 20 feet
away, or 6 metres.
* Take frequent breaks:&nbsp;Eye strain may be prevented by taking frequent
breaks from tasks that require intense concentration from the eyes
such as working on a computer, reading and writing.
* Limit screen time:&nbsp;Digital eye strain is a common eye condition
caused by prolonged periods of time looking at a screen such as a
computer or a tablet. Limiting screen time may reduce eye strain and
can also reduce sleep disruptions.
* Use proper lighting:&nbsp;Inadequate light when reading or writing can cause
eye strain as the eyes have to work extra hard to see the words on the
page. To prevent eye strain, ensure you are using proper lighting
for&nbsp;activities where required such as when reading.
### Does Limiting Caffeine Consumption Reduce Eye Strain Headaches?
No,&nbsp;caffeine consumption does not have any effect on an eye strain
headache, although it can both reduce and cause a regular
headache.&nbsp;According to the Mayo Clinic Health System, caffeine can
treat and trigger a headache, therefore, the effect of caffeine on a
headache can differ from person to person. Caffeine may cause a
headache as regular consumption can cause the body to form a
reliance on caffeine and if it is not consumed in this regular
pattern, it can lead to a withdrawal headache.
### Can Eating a Healthy Diet Help Reduce Eye Strain Headaches?
Yes,&nbsp;eating a healthy diet may help improve overall eye health,
therefore, it may help reduce eye strain headaches.&nbsp;According to the American Migraine Foundation, diet plays a
role in how often people experience migraines as some foods such as
chocolate and alcohol can trigger migraines. A healthy and balanced
diet consisting of fruits and vegetables, whole foods and healthy
proteins and fats is beneficial for the whole body including the
eyes. Eating healthy foods helps to boost immunity and can also
reduce a person’s risk of certain health conditions such as
cardiovascular diseases and diabetes.
### How Can I Reduce Eye Strain When Working on a Computer?
There are many easy tips a person can follow to reduce eye strain
when working on a computer. The ways to reduce computer eye strain
include&nbsp;using eye drops, staying hydrated, wearing prescription glasses,
adjusting computer brightness, performing eye exercises, taking
frequent breaks and remembering to blink.&nbsp;The instructions on how to reduce eye strain when working on
a computer are listed below.
* Use eye drops: Artificial tears,
also known as lubricating eye drops, can be used to reduce eye
strain when working on a computer screen as they add moisture to the
surface of the eye, relieving discomfort.
* Stay hydrated:&nbsp;Drinking plenty of water to stay hydrated can
reduce eye strain as hydration is extremely important in the
production of tears which are needed to moisten the eye’s surface.
* Wear prescription glasses:&nbsp;Wearing proper prescription glasses can reduce
eye strain on a computer as eye strain is commonly caused by
uncorrected refractive errors such as astigmatism and hyperopia.
* Adjust the computer brightness:&nbsp;Adjusting the computer brightness may reduce eye
strain as it helps eyes that have become sensitive to light.
Adjusting the brightness can include turning the brightness down,
turning on a blue light filter or changing the colours of the screen
to a warm hue which is less harsh on the eyes.
* Perform eye exercises:&nbsp;Performing eye exercises ensures the muscles in
the eyes are being properly worked and strengthened. This can be
very beneficial after spending long periods of time working at a
computer. Eye exercises also give the eyes a chance to rest.
* Take frequent breaks:&nbsp;Taking breaks when working on a computer can
help to reduce eye strain. Frequent breaks allow the eyes to rest
from intense concentration as prolonged effort from the eyes can
lead to them becoming irritated or tired.
* Remember to blink:&nbsp;It is common for people to blink less when
working on a computer due to intense concentration. Try and remember
to blink when on a digital screen as your eyes may become strained
as less moisture is being added to the eyes.
Read Eye Strain Headache: Definition, Treatment, Prevention, and
Diagnosis in other Oscar Wylee regions and their languages.
Australia
[Australia](https://www.oscarwylee.com.au/glasses/eye/strain)
[New Zealand](https://www.oscarwylee.co.nz/glasses/eye/strain)
[Canada](https://oscarwylee.ca/glasses/eye/strain)
[Canadian French](https://oscarwylee.ca/fr/glasses/eye/strain)
We accept all leading health funds
Use your private health fund insurance to limit how much you pay for
frames and lenses.
[Discover health funds](https://www.oscarwylee.com.au/health-funds.html)
Ready for an eye test?
Book yours today with our trusted Oscar Wylee optometrists. We offer
bulk billed eye tests for eligible Medicare cardholders.
[Book an eye test](https://www.oscarwylee.com.au/booking)