# Source: https://www.oscarwylee.com.au/eye-care/eye-conditions/dry-eyes

# Dry Eyes: Definitions, Causes, Symptoms, Treatments
Dry eyes is a common eye health condition that feels like having scratched, red or light sensitive eyes. Dry eyes occur when the tears in the eye aren’t able to lubricate them well enough.
## What is dry eyes
Dry eyes, or dry eye disease, is an eye condition where eyes are unable to produce enough tears or tears aren't able to provide lubrication to the surface of the eyes. Symptoms of dry eyes can also happen if there are any issues with the tear film or if the eyes are producing poor quality tears.According to [Hospital Health](https://www.hospitalhealth.com.au/content/clinical-services/news/dry-eye-77-australians-experience-symptoms-but-many-unaware-891268247#:~:text=Dry%20eye%3A%2077%25%20Australians%20experience%20symptoms%20but%20many%20unaware,-Wednesday%2C%2025%20May&amp;text=In%20Australia%2C%2077%25%20have%20experienced,by%20eye%20care%20company%20Alcon.), over 77% of Australians have experienced the symptoms of dry eyes in some way, shape or form. The most common symptoms are noted to be feelings of dryness or blurred vision. A feeling of exhausted eyes was the most noted issue. Despite the prevalence of symptoms, very few book an appointment with an optometrist due to mistaking a possible case of dry eyes with another condition, such as allergies.
Source: Hospital Health
Are you in need of an eye test?
We recommend everyone has a complete eye examination at least once every two years. Book yours today with Oscar Wylee.
[Book an eye test](https://www.oscarwylee.com.au/booking)
## What are the symptoms of dry eyes?
The following are symptoms that can occur when you have dry eyes:
1. A feeling of burning, itchy or scratching eyes
2. Eyes become sensitive to light
3. Reddening around the eyes
4. Eyes are unexplainably watery
5. Vision is becoming blurry
6. A constant feeling that something is in your eye
Other symptoms like exhausted or strained eyes are also possible.
## What causes dry eyes?
Dry eyes can be caused by multiple factors, such as: Your eyes are not producing enough tears, or the tears in your eyes are drying out too quickly. Dry eyes could also be caused by issues in the tear film and its makeup. The tear film is composed of [three layers:](https://www.ncbi.nlm.nih.gov/books/NBK572136/#:~:text=It%20can%20conceptually%20be%20thought,conjunctiva%20and%20accessory%20lacrimal%20glands.)
1. The Lipid Layer: This outer layer contains different types of oils and lipids that prevent the tears from drying too quickly.
2. The Aqueous Layer: This middle layer is where the tears prevents infection and washes away particles nourishing the eye.
3. The Mucin Layer: This inner layer helps distribute the water from the aqueous layer across the eyes, as well as nourishes and takes care of the cornea.
If one of these layers is compromised, your tears may not be functioning properly, and this could cause dryness in your eyes.
Source: National Library of Medicine
## Dry eyes vs. blepharitis:
The symptoms of dry eye can be easily mistaken for the eye health condition called blepharitis. Blepharitis is the medical term for inflammation of the eyelids. Although the symptoms of dry eye and blepharitis can feel the same, each eye condition is separate. It’s possible to have dry eyes and blepharitis at the same time. Dry eyes can also be caused by meibomian gland dysfunction. Meibomian gland dysfunction occurs when the part of the eye that produces the oils for tears are not functioning correctly. Meibomian gland dysfunction is a possible side effect of blepharitis or meibomitis, which is the condition for when the gland itself is becoming inflamed. There is no curing dry eyes, but managing the symptoms may involve treating both conditions as they appear.
## When to see an optometrist:
When the symptoms of dry eye condition are affecting your quality of life or ability to see, or you suspect you may be showing signs of itchy dry eyes, it is recommended that you book an appointment with an optometrist as soon as possible.
### At Oscar Wylee:
Oscar Wylee offers bulk billed eye tests performed by a fully qualified optometrist in all stores. Please be advised not all Oscar Wylee stores have the equipment or medication available to diagnose dry eye and treat symptoms of dry eyes.
Curious about other eye conditions? Read about [presbyopia](https://www.oscarwylee.com.au/eye-care/eye-conditions/presbyopia) or [macular degeneration.](https://www.oscarwylee.com.au/eye-care/eye-conditions/macular-degeneration)
Get a Full Quote in Store
Get fitted for your glasses at Oscar Wylee by visiting us in store and talk to our friendly staff for a complete quote. All major health funds accepted.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
## How to fix dry eye
Dry eyes treatment involves artificially moisturising the eyes. This is done through several different methods. Eye drops for dry eyes are the most common method of alleviating or easing the symptoms of dry eyes. Other treatments might include IPL treatment, treating causes like blepharitis, adjustments to how you may be wearing your contact lenses and supplements such as vitamin A or omega-3. For more severe cases, steroid drops may be used in the treatments. Please note: IPL treatments are not available at Oscar Wylee.If the cause is eyelid dysfunctions or other physical issues in the eye itself, surgery for dry eyes could be a viable solution, but only in rare cases, where the condition was intensely severe. According to Healthline, surgery for dry eye might involve a minor gland salivary autotransplant. This surgery involved transplanting a salivary gland in your eyes in order to moisturise them. This method is very intensive, however, and it is rarely done in Australia.
## Simple home remedies for dry eyes
Simple home remedies for dry eyes are not recommended as a misused product or type of eye drop may cause damage or add further discomfort to the symptoms of dry eyes. However, there are still some basic and safe actions that can be taken to prevent dry eye or alleviate the more uncomfortable symptoms. The following are simple actions that can be taken to treat dry eyes symptoms at home:
* Keep your eyes hydrated.
* Wash your eyelids. Please take caution when any substance, even water, is directly touching the eye.
* A warm compress for eyes: soak a clean and lint or debris free cloth in a bowl of warm water. Place the cloth over your eyes for 5-10 minutes. Keep your eyes closed as the cloth is placed over them.
* Gently massage the eyelids to help the meibomian glands to release the oils.
* Add more fatty acids into your diet, especially vitamins such as Omega-3.
* Change your environment to involve less dry air or substances that may affect your eyes, such as dust or smoke.
## How to cure dry eyes permanently:
There is currently no immediate and long-lasting cure for those who are affected by dry eyes. Dry eye and its symptoms can be a lifelong condition. The more uncomfortable effects can be treated or mitigated for a better quality of life, however. For long-term relief for dry eyes, it is recommended that you see an optometrist to discover the best and most personally beneficial methods for you. There are many other common eye conditions such as ocular migraines that can affect a person’s vision. Read more about ocular migraines and its symptoms.
## Looking for your next pair of glasses?
Locate your nearest Oscar Wylee store and our friendly team members can assist you.
[Find a store near you](https://www.oscarwylee.com.au/locations/full-store-list.html)
## Need to have your eyesight checked?
Oscar Wylee offers bulk billed eye tests, so there are no out-of-pocket expenses for eligible Medicare cardholders.
[Book an eye test](https://www.oscarwylee.com.au/booking)