# Source: https://www.oscarwylee.com.au/glasses/best-for-grey-hair

# Best Glasses Colour for Grey Hair
Updated on June 25th, 2026
Published on August 15th, 2024
Australia
Australia
New Zealand
Canada
Canadian French

The best glasses colours for grey hair can include
tortoiseshell, dark reds, purple, blue and green. There are
many different types of grey hair, including light grey, dark grey, silver
grey, salt and pepper and ash grey. At Oscar Wylee, some of the best glasses
for grey hair include Mesa in Auburn Tortoise, Andrew in Ribbon Blue, and
Parker in Spearmint. These frames will complement grey hair well, enhancing
the colour and bringing dimension and vibrancy to a person's overall look.
The glasses colours that may not be suitable for grey hair include yellows,
beige, gold and darker and heavier frames, as this may dull the appearance
and will not bring a lot of dimension or colour to a look. In addition to
considering hair colour when picking frames, it is also important to
consider other factors such as face shape, hairstyle and length, frame size
and eye colour. Keep reading to learn more about the best glasses colour for
grey hair.
Need to Have Your Eyesight Checked?
At Oscar Wylee, we offer bulk billed eye tests for all eligible Medicare
cardholders.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Best Colours](#best-colours)
[Best Colour Glasses For Men](#best-for-men)
[Best Colour Glasses For Women](#best-for-women)
[Main Factors](#main-factors)
The best glasses colours for grey hair can include
tortoiseshell, deep red, blue frames, classic black frames, metallic
frames
and transparent frames. The best glasses colours for
grey hair are listed below.
* Tortoiseshell: Tortoiseshell patterns
are a distinctive pattern that often blends various warm tones such as
amber and brown with black and can be complementary to grey hair due
to their visual warmth.
* Deep Red: Deep red is rich and
intense, which can provide a bold contrast from grey hair for a bold
pop of colour.
* Blue Frames: Blue frames can include
different shades such as navy, cobalt, or powder blue and can suit
grey hair as the perfect contrast against the cool and subdued
appearance of grey hair.
* Classic Black Frames: Classic black
frames are a reliable frame colour for everyday as they can be
universally suitable for grey hair and pair well with any outfit.
* Metallic Frames: Metallic frames are a
great frame colour for grey hair as they blend seamlessly with the
subdued tones of grey hair, offering a visual accent.
* Transparent Frames: Transparent frames
are a great alternative to traditional eyewear for grey hair thanks to
their versatility and perfectly modern look, which garnered popularity
among fashion enthusiasts. Clear frame glasses offer a minimalist look
that can complement various clothing styles.
## 1. Tortoiseshell
Tortoiseshell frames are
characterised by their multi-toned pattern that blends amber, various
brown hues and a hint of black. Tortoiseshell frames can provide a complementary look for those with
grey hair, with the visual addition of a subtle warm palette.
## 2. Deep Red
Deep red frames can be an ideal frame colour for grey hair,
with their strong and rich hues providing a bold pop of
colour. There are many shades of deep red available at Oscar Wylee, including
Garnet, Matte Burgundy, Burnt Maroon, Ruby, and Cherry.
## 3. Blue Frames
Blue frames can
help create an aesthetically pleasing contrast against grey hair and
look especially complementary due to the cool-toned
combination. Blue frames at Oscar Wylee can include Bright Cobalt, Seaside,
Unicorn, Blue Lagoon, Navy Shadow, Indigo Night, Ocean Fade, Surf Blue,
Azure, Navy Tortoise, Atlantic and Sea Snake.
## 4. Classic Black Frames
Classic black frames are
available in a variety of shapes, sizes and frames that are
compatible for any occasion for those with grey hair. Whether it's thick black frame glasses or a classic rectangle staple,
classic black frames are an easy colour to pair with grey hair due to
the high contrast and their versatility.
## 5. Metallic Frames
Metallic frames such
as gold, silver and rose gold tend to lean into the various shades of
grey hair.
Metallic frames can be an easily wearable frame colour as they don't
stand out in contrast, which can be a stylish move; they instead add to
the overall polished palette. Gold frames offer a warm and refined look;
silver metallic frames provide a cool-toned and polished finish, and
rose gold also offers that perfect warmth that can be needed to help
brighten up an overall muted look.
## 6. Transparent Frames
Transparent frames can be an ideal colour for grey hair as they
provide the wearer with a subtle elevation to their typical eyewear
look.
Transparent frames are available in a wide variety of shapes and styles,
which adds to their versatility. They can be popular due to their modern
appearance and ability to blend well with varying clothing styles.
### What are the Best Colour Glasses for Men with Grey Hair?
The best colour glasses for men with grey hair include tortoiseshell,
dark reds, purple and blue. The best Oscar Wylee
[glasses for men](https://www.oscarwylee.com.au/glasses/collection/mens-glasses.html)
with grey hair are
Mesa in Auburn Tortoise, Andrew in Ribbon Blue and Parker in
Spearmint. The best colour glasses for men with grey hair are listed below.
While the glasses mentioned are typically popular with men, the style
and colours can be worn by anyone of any gender. Glasses are not
strictly defined as male or female; at Oscar Wylee, we encourage you
to choose whatever glasses feel best for you and fit your personal
style.
* Mesa in Auburn Tortoise: Mesa in
Auburn Tortoise is a slightly oversized, tortoiseshell frame and one
of the best colour glasses for men with grey hair at Oscar Wylee.
Mesa in Auburn Tortoise starts from $169.
* Andrew in Ribbon Blue: Andrew in
Ribbon Blue is a darker blue, rectangular frame, a great choice of
Oscar Wylee frame for those with grey hair. Andrew in Ribbon Blue is
available from $169.
* Parker in Spearmint: Parker in
Spearmint is a rectangle frame in dark green, one of the best
glasses colours for men with grey hair at Oscar Wylee. Parker in
Spearmint is available from $169.
[](https://www.oscarwylee.com.au/mesa-optical.html)
[](https://www.oscarwylee.com.au/andrew-optical.html)
[](https://www.oscarwylee.com.au/parker-optical.html)
[](https://www.oscarwylee.com.au/mesa-optical.html)
[](https://www.oscarwylee.com.au/andrew-optical.html)
[](https://www.oscarwylee.com.au/parker-optical.html)
### What are the Best Colour Glasses for Women with Grey Hair?
The best colour glasses for women with grey hair include green, blue,
purple, dark red and tortoiseshell. The best Oscar Wylee
[glasses for women](https://www.oscarwylee.com.au/glasses/collection/womens-glasses.html)
with grey hair are
Julie in Cherry, Serge in Orchid and Frieda in Spearmint. The best colour glasses for women with grey hair are listed below.
While these glasses are typically popular with women, they can be worn
by anyone regardless of gender. Glasses are not strictly defined as
male or female; we encourage you to choose whatever glasses suit your
personal style and glasses you feel good in.
* Julie in Cherry: Julie in Cherry is
a vibrant red and rectangular Oscar Wylee glasses frame, a good
choice for those with grey hair. Julie in Cherry is available from
$169.
* Serge in Orchid: Serge in Orchid is
an oversized, rich purple frame and one of the best colour glasses
for women with grey hair at Oscar Wylee. Serge in Orchid starts from
$169.
* Frieda in Spearmint: Frieda in
Spearmint is a subtle cat eye frame in a deep green, one of the best
glasses colours for women with grey hair at Oscar Wylee. Frieda in
Spearmint is available from $169.
[](https://www.oscarwylee.com.au/julie-optical.html)
[](https://www.oscarwylee.com.au/serge-optical.html)
[](https://www.oscarwylee.com.au/frieda-optical.html)
[](https://www.oscarwylee.com.au/julie-optical.html)
[](https://www.oscarwylee.com.au/serge-optical.html)
[](https://www.oscarwylee.com.au/frieda-optical.html)
#### Do Rose Gold Frames Pair Well With Grey Hair?
Yes, rose gold frames
can pair well with grey hair as their warm metallic finish can
provide a complementary contrast and natural warmth.
Rose gold frames can help strike the ideal balance between pink
undertones while still visually adding more warmth to the palette of
those with grey hair.
## Which Eyeglass Frames are most Flattering for Grey Hair?
The eyeglass frames that may be most flattering for grey hair
may include round and oval frames, rectangle frames, browline frames,
oversized frames and square frames and can be broken down into the
best colour options, face shapes and why, specifically. The eyeglass frames that may be most flattering for
grey hair are listed and described in the table below.
|  | Best Colour Options | Face Shape Suited | Why it Flatters Grey Hair |
| --- | --- | --- | --- |
| Round and Oval Frames | The best colour options for round and oval frames may include
tortoiseshell, deep red, blue frames, classic black frames,
metallic frames and transparent frames. | The face shapes suited to round and oval frames may include
square, diamond and pear face shapes | Round and oval frames in these mentioned colours can flatter
grey hair as they can suit several different face types and
complement the overall colour palette of grey hair. |
| Rectangle Frames | The best colour options for rectangle frames may include
tortoiseshell, deep red, blue frames, classic black frames,
metallic frames and transparent frames. | The face shapes suited to rectangle frames may include
round, oval, diamond and pear face shapes | Rectangle frames in these mentioned colours can flatter grey
hair as they are a classic shape perfect for daily wear and a
smart, elevated look. |
| Browline Frames | The best colour options for browline frames may include
tortoiseshell, deep red, blue frames, classic black frames,
metallic frames and transparent frames. | The face shapes suited to browline frames may include
square and round face shapes. | Browline frames in these mentioned colours can flatter grey hair
as they offer wearers a distinctive look that adds more visual
framing to the face. |
| Oversized Frames | The best colour options for oversized frames may include
tortoiseshell, deep red, blue frames, classic black frames,
metallic frames and transparent frames. | The face shapes suited to oversized frames may include
diamond, heart and square face shapes. | Oversized frames in these mentioned colours can flatter grey
hair as they can help wearers achieve that trendy and modern
look. |
| Square Frames | The best colour options for square frames may include
tortoiseshell, deep red, blue frames, classic black frames,
metallic frames and transparent frames. | The face shapes suited to square frames may include
round, oval and heart face shapes. | Square frames in these mentioned colours can flatter grey hair
as their classic appeal can easily be paired with any outfit for
any occasion. Sleek and straight lines offer that perfect
uniform and smart look. |
Find an Oscar Wylee Store Near You
Come and visit your local Oscar Wylee store where our friendly team
will help you shop our range of stylish and affordable frames.
[Find a store](https://www.oscarwylee.com.au/locations)
## What are the Main Factors to Choosing Glasses for Grey Hair?
Several main factors go into choosing glasses for grey hair, including
face shape, hairstyle and length, frame size and eye colour.
These factors in choosing glasses for grey hair are listed below.
* Face shape: Face shape can be
considered when choosing glasses for grey hair, as certain face shapes
suit certain frames more than others.
* Hairstyle and length: A person's
hairstyle and length can be considered when choosing glasses for grey
hair and picking glasses in general.
* Frame size: Frame size is important
when choosing glasses for grey hair as it can affect fit, comfort
levels and how the frames look on the face.
* Eye colour: Eye colour can be used as
a way to choose a pair of glasses for grey hair, or in general, by
finding complementary colours.
### 1. Face Shape
Face shape is a factor a person may want to consider when choosing
glasses for grey hair, as certain face shapes suit certain shaped
frames better than others. The main
[face shapes](https://www.oscarwylee.com.au/glasses/face-shapes)
are oval, round, diamond, square and pear. The
different face shapes are listed below.
* Oval face shape: An oval face shape
is most suited to frames that help to emphasise the even and soft
features of the face, whilst also adding dimension and balance.
Square, rectangle and aviator are the glasses most suited to oval
faces.
* Round face shape: A round face shape
will be most compatible with square, rectangle and geometric face
shapes, as the strong lines and angles help bring balance and
structure to the face.
* Diamond face shape: A diamond face
shape is most suited to frames that help to soften the features and
bring balance to the face. Frames for diamond faces include oval,
round and cat-eye frames.
* Square face shape: A square face
shape is most compatible with frames that help to bring balance to
the strong lines and angles of the features by softening them.
Frames for square faces include round, cat-eye and aviator frames.
* Pear face shapes: Pear face shapes
are most suited to frames that help to balance out the broader jaw
by bringing attention to the upper area of the face. Glasses for
pear face shapes include round, cat-eye and square glasses.
### 2. Hair Style and Length
Hair style and length are
factors that a person can consider when choosing glasses for grey
hair, as well as glasses in general, as certain frames may suit
certain styles better. For example, if a person has a fringe, they may want to choose a
thinner frame to ensure the top half of the face is not overwhelmed.
### 3. Frame Size
Frame size is
an important factor to consider when choosing frames for grey hair,
or choosing frames in general, as this can affect how glasses fit,
how comfortable they are and how they look on the face. If a frame is too big or too small for a person's face, this will
affect the fit over the nose and the ears as well as affect how
comfortable a person is when wearing them. If a person has a smaller
head and chooses a frame that is too big, this may affect how the
frames look on the face by overwhelming features.
### 4. Eye Colour
Eye colour
can be a factor to consider when choosing frames for grey glasses,
or glasses in general, as there will be certain colour glasses more
complementary than others. Blue eyes, for example, may be well suited to rich browns and
tortoiseshell-coloured frames.
### What Frame Colours Work Best for Neutral Skin Tones with Grey Hair?
The frame colours that may work best for neutral skin tones with grey
hair may include
transparent frames, tortoiseshell frames, black frames, red frames,
blue frames
and grey frames. Those with neutral skin tones and
grey hair may have flexible options due to their overall palette. The
frame colours that may work best for neutral skin tones with grey hair
are listed below.
* Transparent Frames: Transparent
frames may work well with neutral tones with grey hair as they help
add a light element that doesn't overpower one's natural features.
Transparent frames are versatile and modern, ideal for daily wear.
* Tortoiseshell Frames: Tortoiseshell
may work best for neutral skin tones with grey hair as they have
warm undertones and can also complement cooler-toned grey hair well.
Tortoiseshell is a pattern that combines dark browns and golden
yellows.
* Black Frames: Black frames may be
best for natural skin tones with grey hair as the high-contrast and
classic look ties in aesthetically. Black frames can also help frame
one's face more with the sleek silhouette of black.
* Red Frames: Red frames such as
maroon and burgundy are good glasses colours for neutral skin tone
with grey hair as they can enhance the grey and bring vibrancy to an
overall look.
* Blue Frames: Blue frames such as
sapphire blue, navy blue and royal blue can all be good glasses
colours for neutral tones with grey hair as they offer a stunning
pop of colour.
* Grey Frames: Grey frames can work
ideally on neutral tones with grey hair as they can help achieve a
harmonious look. The monochromatic look of grey hues can offer
wearers an even more minimalistic look and an alternative option to
transparent frames.
#### Do Multitone Frames Enhance Grey Hair on Neutral Skin Tones?
Yes, multitone frames can enhance grey hair on natural skin tones
as the different colours can add more hues to the overall
palette.
Since neutral skin tones can lean both warm and cool, multitone
glasses can offer that mix as well.
## How Does Hair Shade Affect Your Glasses Choice?
Yes, hair shade may affect your glasses choice and what you personally
like on your natural features,
as the colour of your glasses can look notably different on different
hair colours. Hair shade can be important when choosing your glasses, as some
colours may not pair well together; glasses colours that seamlessly
blend in with your hair colour or stand as the perfect contrast against
your hair colour.
### What Frames Suit Salt-and-Pepper Hair?
The frames that can suit salt-and-pepper hair can include
silver frames, vibrant frames, black frames and tortoiseshell
frames. It is important to note that the most suitable frames will
ultimately depend on your preferences and what you feel your best in.
The frames that suit salt-and-pepper hair are listed below.
* Silver Frames: Silver frames may be
suitable for salt-and-pepper hair as they subtly blend in with your
hair and elevate your overall look. Silver metal frames can provide
a polished and shiny accent to salt-and-pepper hair.
* Vibrant Frames: Vibrant frames such
as red or blue frames in deep and rich hues can pop vibrantly
against your hair.
* Black Frames: Black frames can suit
salt-and-pepper hair as they can tie the different hues of your hair
all together. A solid black frame can act as the perfect anchor to
one's multicoloured palette.
* Tortoiseshell Frames: Tortoiseshell
frames can be an ideal option for those with salt-and-pepper hair as
their various colours can offer an accent of warmth and visual
interest.
#### Does Hair Texture Influence Which Frames Look Best?
No,
hair texture may not influence which frames look best
necessarily. Frames will look best based on colour pairing and
face shape. The frames that can look best will also depend on what you feel
your best in.
## What Glasses Colour Should be Avoided for Grey Hair?
Glasses colours that
may not be as complementary for those with grey hair and could be
avoided include yellows, beige, and gold frames. These colours may clash with grey hair and may give the overall look
a washed-out and dull appearance. It may also be beneficial to avoid
frames that are too dark and heavy, as this may dull the appearance.
However, it is important to choose the glasses colour that you like
best, that you feel comfortable in and that expresses your style.
#### Does the Shade of Grey Hair Change Which Colours to Avoid?
Yes, the shade of grey hair can change which colours to avoid,
as some frame colours can clash with your hair colour or make your
overall appearance washed out.
There are a range of grey hair types including light grey, dark grey,
silver grey, salt and pepper and ash grey, which may require trying on
the right frames suited to the hue and contrast of your grey hair.
Read Best Glasses Colour for Grey Hair in other Oscar Wylee regions
and their languages.
Australia
Australia
New Zealand
Canada
Canadian French

Oscar Wylee Accepts Major Health Funds In-store
Visit Oscar Wylee in-store and our team can help you with your health
fund claims.
[Explore health funds](https://www.oscarwylee.com.au/health-funds.html)
Book an Oscar Wylee Eye Test
We recommend that everyone should have an eye test with an optometrist
at least once every 2 years or as otherwise advised.
[Book an eye test](https://www.oscarwylee.com.au/booking)