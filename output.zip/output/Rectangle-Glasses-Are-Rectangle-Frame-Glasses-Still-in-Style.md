# Source: https://www.oscarwylee.com.au/glasses/rectangle-frame

# Rectangle Glasses: Are Rectangle Frame Glasses Still in Style?
Published on December 2nd, 2024
Updated on January 11th, 2024 
Rectangle glasses refer to
a glasses frame that is rectangular shaped around the lenses.
Rectangular frames are typically wider than they are tall. Rectangular
glasses are a timeless frame shape, meaning they are always in style, and
remain a staple eyewear choice through changing trends. The benefits of
choosing rectangular glasses frames is that they are suitable for many face
shapes, they are always in style to some degree and they are a versatile
accessory. The way to pick the right rectangle eyeglasses for you is to
consider the length and width of your face, as well as the face shape. Keep
reading to learn more about rectangle frames.
Take care of your eyes at Oscar Wylee
We recommend that everyone has an eye test at least once every two years
or as recommended by an optometrist.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Definition](#Definition)
[Benefits](#Benefits)
[Face Shapes for Rectangle Glasses](#Glasses)
[Sizing](#Sizing)
[Colours](#Colours)
## What are Rectangle Glasses?
Rectangle glasses refer to
a glasses frame that has a rectangular shape around the lenses.
Rectangle glasses are timeless, widely wearable frame shapes that are
always in style to some degree. Rectangle glasses can come in a variety
of materials, including metals and acetate, as well as designs.
Rectangle glasses can be thin or thick, and come in a variety of colours
and patterns.
## What are the Benefits of Choosing Rectangular Glasses Frames?
There are many benefits of choosing rectangular glasses frames including
their suitability for many face shapes, the way they are always in
style, and are a versatile accessory.
The benefits of choosing rectangular glasses are listed below
* Suitable for many face shapes: 
Suitability for many face shapes is the benefit of rectangle glasses.
Rectangle glasses will suit round, oval, pear and diamond face shapes
as the strong lines and angles can help to bring balance and structure
to the face.
* Always in style: 
Rectangle glasses are always in style to some degree, which is one of
their major benefits. Rectangle glasses can come in many frame
thicknesses, colours, and patterns, with some variation of these
frames always in style. In 2024, thin wire rectangle frames have been
in style, whereas in the 70s and 80s, thicker and more colourful
acetate frames were in style.
* Versatility:  Versatility is a major
benefit of choosing rectangular glasses. Rectangular frames can come
in a variety of colours, patterns and lens thicknesses, meaning that a
person can find a rectangle frame that will suit any outfit or
occasion.
### How do I Select the Right Rectangle Glasses for My Face Shape?
The way to select the right rectangle
[glasses for your face shape](https://www.oscarwylee.com.au/glasses/best-men-eyeglasses-for-every-face-shape)
is to consider what face shape you have, what size your face is and
what frame will complement this the best. The face shapes that best suit rectangle glasses are round, oval,
diamond and pear face shapes. Rectangle glasses suit these face shapes
as the strong lines and angles can bring some balance and structure to
a face with more curves. Those with a smaller face may want to choose
a medium or smaller rectangle frame with a thinner rim, so as to not
overwhelm the face.
#### Are Thin Rectangle Glasses Better for a Minimalist Look?
Yes, thin rectangle glasses
can be a better choice for a minimalist look than a thicker, more
colourful frame.
Thin rectangle glasses, made with either metals or acetate, can be a
subtle more understated accessory to an outfit.
#### Are Rectangle Glasses Frames Still in Style?
Yes, rectangle glasses frames are still in style. Rectangle
glasses are a timeless frame shape, meaning they are always in
style, and remain a popular, staple eyewear choice even when trends
change. In 2024, thin wire rectangle frames are in style, as office
siren and corporate baddie aesthetics have been trending online. In
the 70s and 80s, thicker and more colourful acetate rectangle frames
were in style.
### What’s the Difference Between Rectangle and Square Glasses?
The difference between rectangle and square glasses is
that rectangle glasses are wider than they are tall, whereas square
glasses have equal length and width.
[Square glasses](https://www.oscarwylee.com.au/glasses/square-frame)
are more angular than rectangle glasses, and have a boxier look than
the longer, sleek style of rectangle frames.
### Which Rectangular Glasses Frames Are Best for Men?
The rectangular glasses frames that
are best for men are the ones that will best suit their face shape
and size. Rectangle frames are a unisex shape, suitable for all genders. For
those that want a more masculine frame, rectangular acetate glasses in
colour such as black and grey may be a good choice. Metal rectangular
glasses frames can be a more unisex frame, giving a neutral, sleek and
sophisticated look.
Find an Oscar Wylee store near you
Come and visit your local Oscar Wylee store and our friendly staff can
assist you with your eye care needs.
[FInd a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
### Which Rectangular Glasses Frames Are Best for Women?
The rectangular frame glasses frame that
are best for women will be the frames that best suit their face
shape, size and personal style preferences. Rectangle frames are a unisex shape, suitable for all genders. For
those that want a more feminine rectangle shape, lighter colours and a
thinner acetate frame may be a good choice.
### Why Choose Metal Frame Rectangle Glasses for a Classic Look?
Metal frame rectangle glasses can give the wearer
a classic look as metal is a frame material that is timeless and
sleek. Many famous glasses throughout the history of fashion have been
made from metal, including aviators which were popularised by the
American military in the 1930s and 1940s. Some of the earliest
rectangular frames were made with metal materials.
## How to Pick the Right Size Rectangle Frames for Your Face?
The way to pick the right size rectangle frames for your face is to
consider the length of your face, and the width of your face, then
pick a frame size.
The ways to pick the right size rectangle frame for your face are listed
below.
1. Consider the length of your face: 
Considering the length of your face is the first step in picking the
right size rectangular frame size for your face shape. The length of
your face refers to the distance between your forehead and your chin.
If a person has a longer distance between these features, a smaller or
thicker frame may help to bring balance to this. If a person has a
shorter length face, a smaller frame
2. Consider the width of your face: 
Consider the width of your face. The width of your face refers to the
distance between ear to ear. If a person has a small distance between
these features, it may be best to choose a smaller-sized frame so the
glasses do not overwhelm the face. If a person has a larger distance
between these features, they should choose a large frame that keeps in
proportion to these features.
3. Choose a frame size: 
Once you have considered your face size, you should choose a frame
size. At Oscar Wylee, we have glasses in small, medium and wide fits,
with different frame thicknesses and designs. Whilst you should choose
a frame size that complements your face, you should also choose a
frame that you like and will enjoy wearing.
### What are the Best Prescription Rectangle Glasses for Daily Use?
The best prescription rectangle glasses for daily use
will be dependent on a person’s personal style preferences.
Generally, any rectangle glasses purchased from a legitimate optical
business can be fitted with a prescription lens. At Oscar Wylee, we
have a range of rectangle frames that a person can use as their daily
use
[prescription glasses](https://www.oscarwylee.com.au/glasses/prescription)
including Logan, Brosque and Crane. The best prescription
rectangle glasses for daily use are listed below.
* Logan: 
Logan is Oscar Wylee’s take on the classic rectangular frame shape.
Logan is a lightweight frame made from Ultem.
* Brosque: 
Brosque is an Oscar Wylee rectangular frame made from acetate and
metal.
* Crane: 
Crane is an Oscar Wylee rectangular frame minimal in its
construction and sleek in appearance. Crane is made from a mixture
of acetate, stainless steel and cupronickel materials.
[](https://www.oscarwylee.com.au/logan-optical.html)
[Logan](https://www.oscarwylee.com.au/logan-optical.html)
$199    
Add to Cart
[Shop Logan](https://www.oscarwylee.com.au/logan-optical.html)
[2 pairs from $249](https://www.oscarwylee.com.au/logan-optical.html)
[](https://www.oscarwylee.com.au/brosque-optical.html)
[Brosque](https://www.oscarwylee.com.au/brosque-optical.html)
$169    
Add to Cart
[Shop Brosque](https://www.oscarwylee.com.au/brosque-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/brosque-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/brosque-optical.html)
[](https://www.oscarwylee.com.au/crane-optical.html)
[Crane](https://www.oscarwylee.com.au/crane-optical.html)
$169    
Add to Cart
[Shop Crane](https://www.oscarwylee.com.au/crane-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/crane-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/crane-optical.html)
#### Are Small Rectangular Glasses Suitable for Narrow Faces?
Yes, small rectangular glasses
can be worn by those with narrow faces, however, frames that are
taller may be a more complementary choice. A narrow face refers to a face that is longer than it is wide.
Frames that are taller than they are wide, such as square or cat-eye
frames may be more complementary as they can help bring some
proportion to the length of the face.
### What are Popular Colour Options for Rectangle Glasses Frames?
The popular colour options for rectangle glasses frames include
black, clear, bright colours and muted colours. If shopping for
rectangle sunglasses there are also a range of
[sunglasses lens colours](https://www.oscarwylee.com.au/glasses/sunglasses-lens-colour)
available such as grey and brown. The popular colour options for
rectangle glasses are listed below.
* Black: 
Black is a popular colour option for rectangular glasses frames and
glasses in general, as it is neutral and will be suitable for many
different outfits and occasions.
* Clear: 
Clear is a popular colour option for rectangle glasses frames as it
is neutral and can make frames appear subtle and unobtrusive of the
face. Clear refers to glasses that have transparent frames. In
addition to a general non-colour clear, these frames can also come
in muted pinks, purples and beige colours that are still
transparent.
* Bright colours: 
Bright colours are often a popular colour choice for rectangle
frames as they can bring vibrancy to a person’s look. Bright colours
refer to any colour in which the saturation and hue of a colour is
vibrant.
* Muted colours: 
Muted-coloured rectangle frames are a popular colour option as they
bring some colour to a person’s look, without being too bold. Muted
colours refer to any colours in which the saturation is low.
#### Can I Get Rectangle Sunglasses with a Metal Frame?
Yes,
you are able to get rectangle sunglasses with a metal frame.
A metal frame can be made from a variety of materials including
titanium and stainless steel. A rectangular metal sunglasses frame
can give a sleek and sophisticated look.
### How do I Choose the Right Designer Rectangle Glasses?
The way to choose the right designer rectangles is to
consider your face shape, face size and personal style preferences,
as well as material and design.
The right designer rectangle glasses will be the ones a person feels
comfortable and confident in, that complements their face and fits
well.
Book an eye test with an Oscar Wylee optometrist
Oscar Wylee offers bulk billed eye tests for eligible Medicare card
holders.
[Book an eye test](https://www.oscarwylee.com.au/booking)
Major Health Funds Accepted at Oscar Wylee
Visit our team in-store for a full quote and advice on how you can use
your health fund for some of Oscar Wylee’s eye care services
[Explore health funds](https://www.oscarwylee.com.au/health-funds.html)