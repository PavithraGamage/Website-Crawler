# Source: https://www.oscarwylee.com.au/glasses/is-wearing-scratched-glasses-bad

# Is Wearing Scratched Glasses Bad?
Published on March 13th, 2025
Updated on March 21st, 2025  
Australia   
[Australia](https://www.oscarwylee.com.au/glasses/is-wearing-scratched-glasses-bad)
New Zealand

[Canada](https://oscarwylee.ca/glasses/is-wearing-scratched-glasses-bad)
[Canadian French](https://oscarwylee.ca/fr/glasses/is-wearing-scratched-glasses-bad)
Scratched glasses can refer to scratches on both the arms and frame of glasses, as well as the lenses. For this article, scratched lenses and how they can impact vision are the main concerns. Wearing scratched glasses, specifically scratched lenses, is not bad, in that it will not have a major effect on your eye health, but it may affect how well a person can see through their glasses. If a person is struggling to see through their glasses because of significant scratching, this can lead to eye strain and possibly headaches. Badly scratched glasses lenses that impact how well a person sees should be replaced. It is not recommended that a person tries to fix their scratched glasses at home, using remedies such as baking soda or toothpaste, as this may lead to further damage to the lenses. Keep reading to learn more about scratched glasses.
Take Care of Your Vision
Our Oscar Wylee optometrists can help care for your vision with an eye test in-store.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[How Vision is Affected](#vision) [How To Fix Scratched At Home](#fix) [Scratched Lenses Effectiveness](#effectiveness) [Replacing Scratched Lenses](#replace)
## Do Scratches on Glasses Affect Vision?
Yes, scratches on glasses lenses can affect vision. Minor scratches on the lens of glasses may not affect vision, however, large, or deep scratches that change the surface of the lens significantly, may lead to issues with how a person is seeing through it. This is largely applicable to prescription lenses, but non-prescription glasses or sunglasses may also be affected. Scratches on glasses may distort vision and make it hard to focus on objects, causing [blurry vision](https://www.oscarwylee.com.au/glasses/eye/blurred-vision) and eye strain. Glasses with scratches may also distort how light is reflected on the lens, further affecting vision, and possibly leading to issues such as eye strain and headaches.
### Can Scratched Glasses Cause Dizziness?
Scratched glasses may cause dizziness, but this is not the most likely symptom associated with scratched glasses. If a glasses lens is scratched, it may make it difficult for the eyes to focus on certain objects. This can lead to eye strain and headaches, and in severe cases, may also cause dizziness.
### Can Dirty Glasses Cause Eye Strain?
Yes, dirty glasses may cause eye strain. If the lenses of a person’s glasses are dirty, then the eyes may have to work harder to see through the dirt. If this goes on for a long time, it may cause [eye strain](https://www.oscarwylee.com.au/glasses/eye/strain). Cleaning glasses regularly with lens cleaner and a microfibre cloth can help to prevent this issue.
#### Can Scratched Lenses Be Fixed?
Scratched lenses can not generally be fixed, and it is usually recommended that severely scratched lenses are replaced. If the scratch on the lens is small, and not directly impacting vision, it may be acceptable to leave the lenses as they are. It is not recommended to use any home remedies on scratched glasses, such as toothpaste or baking soda, as these will not fix the scratch, and may cause further damage to the lenses. Baking soda and toothpaste may erode any lens coatings, such as UV protection that has been added. To avoid scratching glasses lenses, it is recommended to keep glasses in a case when not in use, and to not hang glasses off of clothing, in case they fall off.
### How to Fix Scratched Glasses at Home?
It is not recommended that a person tries to fix their scratched glasses lenses at home themselves, as this may lead to further damage to the lenses. Popular home remedies for fixing glasses include using baking soda, mixed with water and placed onto the glasses' lenses as a paste. Baking soda is an abrasive material, however, and using it to get a scratch out of your glasses may result in additional wear, such as the stripping away of lens coatings. Another home remedy for getting scratches out of glasses is using toothpaste on the lens. According to the Optometrists Network, toothpaste contains some abrasive chemicals that may damage or erode lens coatings.
#### How do Scratched Glasses Affect Eye Health?
Scratched glasses will not have major effects on eye health, but may temporarily impact vision. Scratched glasses may impact how well a person sees through their glasses, which can lead to eye strain. Eye strain will not generally have a major impact on [eye health](https://www.oscarwylee.com.au/glasses/eye/health-tips-keeping-eyesight-healthy), and will go away when the scratched lenses are replaced, and a person’s field of vision is clear again.
#### Can Scratched Glasses Cause Headaches?
Yes, scratched glasses may cause headaches if the scratch is obscuring vision. If a scratched lens is impacting how well a person is seeing through their glasses and obscuring vision, it may lead to eye-straining in an attempt to see better. Prolonged eye strain may cause headaches.
#### Do Scratched Glasses Reduce UV Protection?
Scratched glasses may reduce UV protection if the damage is severe. Glasses that have been scratched deeply, or several times across the lens, may lead to a reduction in how well the [UV protection](https://www.oscarwylee.com.au/glasses/eye/uv-blocking) works in that area. Depending on whether UV protection is within the lens, or added as a coating to the top of the lens, may also impact whether UV protection is impacted by scratches. If a person tries to fix their glasses with baking soda or toothpaste, they may also reduce the UV protection of glasses, as these can be abrasive and damage UV coatings.
Find a Store Near You
Come and visit your local Oscar Wylee store for Medicare bulk billed eye tests and explore frames from our stylish range.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
#### Are Scratched Prescription Glasses Less Effective?
Scratched prescription glasses will be less effective in correcting refraction errors and helping with clear vision if the scratches are extensive across the whole lens. If the glasses' lenses have been scratched over a large area of the lens, it will usually make seeing through the lens harder. For people who rely on their [prescription glasses](https://www.oscarwylee.com.au/glasses/prescription) to see clearer, such as someone with myopia needing to see far away objects, this will make their glasses less effective. However, a smaller scratch towards the edges of the lenses, may not impact how effective prescription glasses are in correcting refractive errors.
##### Should you Replace Scratched Glasses?
Yes, a person should generally replace scratched glasses. Some scratches, if small and outside of a person’s central field of vision, may not necessitate a full replacement of the lens. However, if the scratched lens is impacting how well a person sees, they should replace the lens. If a person is unsure about whether they should replace their glasses, they should take them to the optical retailer they bought them from for advice. Depending on the retailer, they may be able to replace just the glasses lens, allowing you to keep the frame. Other places may require full replacement of both lenses and glasses frames.
Read update_new_title in other Oscar Wylee regions and their languages.
Australia   
[Australia](https://www.oscarwylee.com.au/glasses/is-wearing-scratched-glasses-bad)
New Zealand

[Canada](https://oscarwylee.ca/glasses/is-wearing-scratched-glasses-bad)
[Canadian French](https://oscarwylee.ca/fr/glasses/is-wearing-scratched-glasses-bad)
Are You Due for an Eye Test?
Oscar Wylee offers bulk billed eye tests, so there are no out-of-pocket expenses for eligible Medicare cardholders.
[Book an eye test](https://www.oscarwylee.com.au/booking)
Oscar Wylee Accepts Major Health Funds In-store
Visit Oscar Wylee in-store for eye care services and your health fund may help cover some of the cost.
[Explore health funds](https://www.oscarwylee.com.au/health-funds.html)