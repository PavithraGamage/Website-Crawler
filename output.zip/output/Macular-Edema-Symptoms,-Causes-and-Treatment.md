# Source: https://www.oscarwylee.com.au/glasses/eye/macular-edema

# Macular Edema: Symptoms, Causes and Treatment
Published on May 27th, 2024
Updated on January 16th, 2025
Australia   
[Australia](https://www.oscarwylee.com.au/glasses/eye/macular-edema)
New Zealand

[Canada](https://oscarwylee.ca/glasses/eye/macular-edema)
Macular edema refers to the swelling of the macula, often caused by damaged blood vessels leaking fluid into the eye. Several eye conditions can cause macular edema including diabetes, uveitis, retinal vein occlusion (RVO), age-related macular degeneration, medication, macular pucker and eye surgery. The symptoms of macular edema can include blurry vision, objects that appear wavy and colours that appear faded. Treatment for macula edema can involve treating the underlying condition that is causing the swelling, such as diabetes or a macular pucker, but also includes treatment to address the swelling itself. Treatment includes anti-VEGF injections, laser surgery, steroids and eye drops. Keep reading to learn more about macular edema.
Prioritise Your Eye Health at Oscar Wylee
Oscar Wylee optometrists are available to perform bulk-billed eye tests, with no out-of-pocket expenses for eligible Medicare cardholders.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Definition](#definition) [Symptoms](#symptoms) [Causes](#causes) [Treatments](#treatments)
## What is Macular Edema?
Macular edema refers to a swelling of the macula. The [macula](https://www.oscarwylee.com.au/glasses/eye/anatomy/macula) is a part of the retina, the light-sensitive layer at the back of the eye. The macula is responsible for central vision and helps a person see the objects directly in front of them. Macular edema is often caused by damaged blood vessels that leak into the eye, leading to swelling in the macula, according to the National Eye Institute.
## What are Macular Edema Symptoms?
Several symptoms may occur if a person has macular edema including blurry vision, objects that appear wavy and colours that appear faded. Vision will typically worsen over time with macular edema. If you experience any macular edema symptoms, it is important to seek medical attention. The possible symptoms of macular edema are listed below.
* Blurry vision:  Blurry vision is one of the most common symptoms of macular edema according to the National Eye Institute. Blurry vision refers to vision that is not sharp or clear.
* Objects appearing wavy:  Objects appearing wavy is a possible symptom of macular edema, caused by the way the swelling of the macula affects central vision.
* Colours appearing faded: Colours appearing faded or washed out is a potential symptom of macular edema.
## What are Macular Edema Causes?
Macular edema refers to a swelling in the eye that occurs when damaged blood vessels leak into the eye. There are several eye conditions that can cause macular edema including diabetes, uveitis, retinal vein occlusion (RVO), age-related macular degeneration, medication, macular pucker and eye surgery. The possible causes of macular edema are listed below.
* Diabetes:  Diabetes can cause a type of macular edema called diabetic macular edema, according to the American Academy of Ophthalmology.
* Uveitis:  Uveitis refers to inflammation of the uvea or middle layer of the eye. According to the American Academy of Ophthalmology, uveitis can cause macular edema as this condition may damage blood vessels in the eye, causing them to leak.
* Retinal Vein Occlusion (RVO): Retinal vein occlusion (RVO) is a condition in which the veins in the retina become blocked and blood cannot drain properly. As a result of vein blockage, blood and fluid can leak into the macula causing swelling, or macular edema.
* Age-related macular degeneration (AMD): Age-related macular degeneration (AMD) is an eye disease in which the cells in the macula are damaged, leading to a loss of central vision. A type of age-related macular degeneration called wet AMD, in which abnormal blood vessels grow in the macula may cause macular edema if these abnormal blood vessels leak.
* Medication: Certain medications may have side effects that can cause macular edema, according to the American Academy of Ophthalmology.
* Macular pucker: A macular pucker refers to a bulge or wrinkle on the macula, often caused by the formation of scar tissue. A macular pucker may cause macular edema if pockets of fluid collect under scar tissue, according to the American Academy of Ophthalmology.
* Eye surgery: Eye surgery, such as cataract surgery, may cause macular edema as a complication.
Visit Our Team In-Store
Visit an Oscar Wylee store near you where you can speak to our knowledgeable staff and experience professional frame styling.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
## What are the Macular Edema Treatments?
There are several methods used for macular edema treatment including anti-VEGF injections, laser surgery, steroids and eye drops. Macular edema treatment can also focus on treating the underlying issues that are causing the edema, such as diabetes or macular pucker. The treatments for macular edema are listed below.
* Anti-VEGF injections:  Anti-VEGF injections are a type of medication that stops the growth of a protein called vascular endothelial growth factor (VEGF). VEGF can cause blood vessels to leak, leading to swelling in the retina and subsequently macular edema, according to the National Eye Institute.
* Laser surgery:  Laser surgery refers to eye surgery that uses a beam of light to treat various eye issues, including macular edema. According to the NHS, laser surgery helps treat macular edema by reducing the leakage from blood vessels and helping to reduce the fluid that causes swelling.
* Steroids: Steroids, or Corticosteroids, are a type of anti-inflammatory medication that can be used to treat macular edema by reducing swelling.
* Eye drops: Eye drops can be prescribed to help treat macular edema. Eye drops may be steroid eye drops or non-steroid. Both steroid and non-steroid eye drops help to treat macular edema by reducing the swelling in the macular.
### What Eye Drops Treat Macular Edema?
Two main types of eye drops can help to treat macular edema; steroid eye drops and NSAIDs eye drops. Eye drops refer to a type of medication that is applied to the eyes using a dropper tool. Steroid eye drops refer to eye drops that have steroids or corticosteroids, which are anti-inflammatory medications that can help treat macular edema by reducing the swelling that causes this condition. NSAIDs, which stands for non-steroidal anti-inflammatory medications, may help to reduce inflammation and swelling that causes macular edema, without the side effects of steroids, according to the Optometrists Network.
#### Can Macular Edema Be Prevented?
Macular edema may be preventable by managing the underlying conditions that cause it, such as diabetes or age-related macular degeneration (AMD). People must regularly see their optometrist so these conditions can be closely monitored and managed. Keeping good general eye health may also help prevent the eye conditions that lead to macular edema, or prevent macular edema from worsening when it occurs. Tips for good eye health include exercising regularly, not smoking, eating a balanced diet, using safety eyewear and wearing your prescription glasses if you have them. If a person has Diabetic Macular Edema, managing blood sugar levels can also help to prevent macular edema.
#### Can Aqueous Humor Fluid Build-Up Cause Macular Edema?
A build-up of aqueous humour fluid does not usually cause macular edema. A build-up of [aqueous humour](https://www.oscarwylee.com.au/glasses/eye/aqueous-humour) fluid is more likely to lead to glaucoma, as this type of fluid build-up can lead to increased eye pressure. Macular edema is typically caused by a buildup of fluid in the macula due to leaking blood vessels.
#### Can Macular Edema Be Healed?
Yes, macular edema can be healed. Treatment such as anti-VEGF injections, eye drops and laser surgery can help to reduce the swelling of the macular and reduce fluid in the eye.
#### Is Macular Edema Vision-Threatening?
Macular edema is not vision-threatening in that it will not cause blindness, however, the condition can damage eyesight if left untreated. If you believe you have symptoms of macular edema, it is important to see an optometrist as soon as possible to reduce possible damage to eyesight.
#### Can Children Get Macular Edema?
Yes, children can get macular edema, though this is not as common as it is for adults. According to a study by Nguyen, Mekonnen, Kim, et al. called, Clinical outcomes of pediatric macular edema associated with non-infectious uveitis, 15% of children who presented with non-infectious uveitis, also had macular edema. If a person suspects their child has macular edema, or any type of eye condition, it is important to take them to see an optometrist or health care professional for a [children’s eye test](https://www.oscarwylee.com.au/glasses/eye/exam-for-children) and vision assessment.
#### Can Glasses Help Macular Edema?
Glasses can not help to treat macular edema and may not always help with vision issues relating to this condition. [Glasses](https://www.oscarwylee.com.au/glasses/types) refer to eyewear that is worn on the face to help correct refractive errors and protect the eyes. If a person has macular edema as well as other vision problems such as refractive errors, then it is important to wear their prescription glasses so they can correct this error and not compound vision issues from macular edema. According to the NHS and the Macular Society, wearing glasses that block UV and blue light and reduce glare may help those suffering from Diabetic Macular edema-related vision loss more comfortable.
#### Can you Have Cataract Surgery if You Have Macular Edema?
It is possible to have cataract surgery if you have macular edema that is being treated, but this may not be the right choice for all people. According to a study by Starr, Mahr, Smith, et. al, published in the American Journal of Ophthalmology in 2021, patients with macular edema may undergo cataract surgery, but this may worsen macular edema.
### What is the Difference Between Macular Edema and Macular Pucker?
Macular edema and macular pucker are both eye conditions that affect the macula part of the eye but in different ways. A [macular pucker](https://www.oscarwylee.com.au/glasses/eye/macular-pucker) is a bulge or wrinkle on the macula, often caused by the formation of scar tissue. According to the American Academy of Ophthalmology, macular puckers are often caused by older age, which can lead to the vitreous part of the eye pulling away from the retina. This can occur without problem, however in some cases, the vitreous may stick to the retina causing scar tissue. Macular edema refers to a swelling of the macula. A macular pucker may lead to macula edema if pockets of fluid collect under scar tissue.
Read Macular Edema: Symptoms, Causes and Treatment in other Oscar Wylee regions and their languages.
Australia   
[Australia](https://www.oscarwylee.com.au/glasses/eye/macular-edema)
New Zealand

[Canada](https://oscarwylee.ca/glasses/eye/macular-edema)
Your Eyes Need Care Too!
Prioritise your eye health and make an appointment with a skilled Oscar Wylee optometrist.
[Book an Eye Test](https://www.oscarwylee.com.au/booking)
All Major Health Funds Accepted
For the purchase of frames and lenses, use your private health fund insurance to limit how much you pay from your pocket.
[Explore Health Funds](https://www.oscarwylee.com.au/health-funds.html)