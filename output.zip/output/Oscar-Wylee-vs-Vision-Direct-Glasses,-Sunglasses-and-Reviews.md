# Source: https://www.oscarwylee.com.au/vs-vision-direct

# Oscar Wylee vs Vision Direct Glasses, Sunglasses and Reviews
Published on June 23, 2025
Updated on January 21st, 2025 
Australia
Australia
New Zealand
Canada

Oscar Wylee is an eyewear company founded in 2012. An Australian-owned
company, Oscar Wylee’s headquarters are in Sydney.
Starting as an online company, Oscar Wylee then evolved into physical
stores, with its first opening in Australia in 2015. Oscar Wylee went on
to open their first two stores in New Zealand in 2019, followed by their
first store in Canada in 2021. Oscar Wylee now has over 130 stores across
Australia, Canada, and New Zealand, providing eye testing services, as
well as stylish frames, to its customers.
Vision Direct is a primarily online eyewear retailer, with one physical
store and showroom in Hong Kong, where they are headquartered. Vision Direct was founded in 2006 by three Australian entrepreneurs
Doron Kalinko, David Menning and Tony Zhuang. Vision Direct caters to
customers from around the globe, delivering to over 100 countries. Vision
Direct is currently part of the SmartBuyGlasses Optical Group, one of the
world’s largest designer eyewear e-retailers. Oscar Wylee and Vision
Direct are both widely known eyewear companies that provide a variety of
prescription and non-prescription glasses, with Vision Direct also selling
contact lenses.
Book an Eye Test With Oscar Wylee Today
Our highly trained optometrists are available to provide bulk billed eye
tests to eligible Medicare card holders.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Distinctions between Oscar Wylee and Vision Direct](#Distinctions)
[Specialised Lenses in Oscar Wylee and Vision Direct](#Specialised)
[Product Ranges Differences](#Product)
## What are Some of the Distinctions between Oscar Wylee and Vision Direct?
Some distinctive characteristics of Oscar Wylee are their in-house made prescription and non-prescription glasses and
sunglasses, and free eye tests for international students
initiative.
Oscar Wylee’s glasses are all designed in-house. Oscar Wylee glasses
are hand-assembled, ensuring a high standard of care. This ensures
Oscar Wylee’s glasses are a consistent quality with a distinct
individuality from more notable brands. Oscar Wylee has physical
stores in three countries, with optometrists present in each store.
These optometrists provide a high level of eye care including eye
tests. Oscar Wylee extends extra assistance to international students
in Australia and New Zealand. If students buy a pair of Oscar Wylee
glasses, then they can receive a free eye test on the same day.
Vision Direct’s distinctive characteristics compared to Oscar Wylee
include their branded glasses, virtual try-on capabilities and the fact that they
sell contact lenses.
Vision Direct offers eyewear brands including SmartBuy, which is the
parent company of Vision Direct, Ray-Ban, Oakley and Versace. This can
be preferred by
customers who desire the reputation and appeal of branded frames.
Vision Direct also sell a variety of contact lens brands. Another
distinctive characteristic of Vision Direct is that they have a
virtual try-on application on their website, where
customers can pick a frame, upload a photo of themselves or use their
camera in real time, and the frame is superimposed on their face. This
can be of appeal to customers so they can understand what a frame will
look like on their face before purchasing online.
### What Stylish Eyewear Options Does Oscar Wylee Offer?
Some stylish eyewear options from Oscar Wylee are Mumford, Jinky, Duckworth and Alya. From vintage-inspired, modern, practical and minimalist styles,
there is a pair for every preference. Read more about some of the
stylish eyewear options at Oscar Wylee listed below.
* Mumford: Mumford is a stylish, widely wearable Oscar Wylee frame,
characterised by a square-round shape, a low-bridge nose fit and a
metal and acetate frame.
* Jinky: Jinky is a widely wearable, square, Oscar Wylee frame. Jinky is
unisex, lightweight and perfect for medium faces
* Duckworth:
Duckworth is an Oscar Wylee aviator-shaped frame that will work
for any occasion.
* Alya: Alya is an Oscar Wylee frame with a striking round
shape and a TR90 build. Alya is a stylish, lightweight frame that
will pair perfectly with any outfit.
[](https://www.oscarwylee.com.au/mumford-optical.html)
[Mumford](https://www.oscarwylee.com.au/mumford-optical.html)
$169    
Add to Cart
[Shop Mumford](https://www.oscarwylee.com.au/mumford-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/mumford-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/mumford-optical.html)
[](https://www.oscarwylee.com.au/jinky-optical.html)
[Jinky](https://www.oscarwylee.com.au/jinky-optical.html)
$169    
Add to Cart
[Shop Jinky](https://www.oscarwylee.com.au/jinky-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/jinky-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/jinky-optical.html)
[](https://www.oscarwylee.com.au/duckworth-optical.html)
[Duckworth](https://www.oscarwylee.com.au/duckworth-optical.html)
$169    
Add to Cart
[Shop Duckworth](https://www.oscarwylee.com.au/duckworth-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/duckworth-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/duckworth-optical.html)
[](https://www.oscarwylee.com.au/alya-optical.html)
[Alya](https://www.oscarwylee.com.au/alya-optical.html)
$169    
Add to Cart
[Shop Alya](https://www.oscarwylee.com.au/alya-optical.html)
[2 pairs from $199](https://www.oscarwylee.com.au/alya-optical.html)
[3 pairs from $249](https://www.oscarwylee.com.au/alya-optical.html)
### Why Choose Oscar Wylee or Vision Direct for Specialised Lenses?
Oscar Wylee and Vision Direct
both have specialised lenses and lens offerings for customers to add
to their eyewear.
#### Oscar Wylee Specialised Lenses
Oscar Wylee specialised lenses and lens offerings include prescription and
non-prescription lenses, multifocal lenses, as well as lens
add-ons, such as blue light filter, high-index lenses and
anti-glare coating. Oscar Wylee’s sunglasses range also includes lens offerings
such as polarised lenses, adaptive lenses,and lenses to
accommodate stronger prescriptions.
#### Vision Direct Specialised Lenses
Vision Direct also
has a range of specialised lenses and lens offerings include
prescription and non-prescription lenses, multifocal lenses, as
well as lens add-ons, such as blue light filter. Vision Direct
also offers contact lenses. The range of contact lenses Vision Direct offers includes daily,
weekly and monthly contacts, as well as toric contact lenses,
silicone contact lenses, spherical contact lenses, multifocal
lenses and coloured contact lenses.
### Do Oscar Wylee and Vision Direct offer Blue Light Blocking Lenses?
Both Oscar Wylee and Vision Direct both offer [blue light blocking lenses](https://www.oscarwylee.com.au/glasses/blue-light/review).
Oscar Wylee allows glasses wearers to add a blue light filter to any
optical prescription up to 1.67 index, or to non-prescription
glasses. The Oscar Wylee Blue Light Filter product includes a basic
anti reflective coating. Vision Direct offers blue light glasses
across a variety of different brands, available on their
website.
#### Do Oscar Wylee or Vision Direct Offer Repairs, Adjustments, or
Warranty Replacements for Glasses?
Yes,
Oscar Wylee and Vision Direct each offer some degree of services
such as repairs, adjustments, or warranty replacements for
glasses. At Oscar Wylee, customers have access to lifetime cleaning and
adjustment of Oscar Wylee frames. Oscar Wylee provides a 1 year
warranty from the date of delivery on frames and lenses against
manufacturing faults or defects. They will also repair or replace
faulty or defective frames or lenses free of charge for warranty
claims made within 1 year of delivery. Oscar Wylee also offers a
repair or replacement for problems experienced with vision during
everyday use for claims made within 30 days of delivery. At Vision
Direct there is a 24-month warranty for glasses from the date of
purchase, against all manufacturers’ defects on optical frames,
sunglasses and prescription lenses. For contact lenses, there is a
3-month warranty covering manufacturers’ defects. Vision Direct
also offers a 100-day return policy for your order.
### How Long Have Oscar Wylee and Vision Direct been in Business?
Oscar Wylee has been in business since 2012, initially starting as an E-commerce store. Its first physical
store opened in Chatswood Interchange in 2015. Vision Direct has been in business since 2006.
Visit our team in-store!
Come and say hi to our friendly in-store team who can help you with
your eye care needs
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
### What Products and Services does Oscar Wylee Offer?
Oscar Wylee products and services include eye testing and a wide
range of in-house designed glasses. The products Oscar Wylee
provides are prescription glasses, non-prescription glasses, and [sunglasses](https://www.oscarwylee.com.au/sunglasses.html), as well as a range of lens add-ons. Their services include eye tests, digital retinal scans, bulk billed visual field tests
and a lifetime guarantee of adjustments or professional cleaning for your Oscar Wylee glasses.
#### Does Oscar Wylee have In-House Eye Specialists?
Yes, Oscar Wylee has in-house [eye specialists](https://www.oscarwylee.com.au/eye-health/optometrist-vs-ophthalmologist.html).
Oscar Wylee’s in-house eye specialists are optometrists. These
optometrists can conduct eye tests which include diagnosing eye
problems and writing prescriptions. Oscar Wylee also has
experienced retail staff that can provide customers with advice on
how to pick out glasses, and help ensure glasses fit to the face.
#### Can you Order Prescription Glasses Online from Oscar Wylee?
Yes, you can order prescription glasses online
from Oscar Wylee Australia and New Zealand. This can be done
directly on the website. You can browse their collection of
glasses online and pick a frame you like, with several options
available for giving them your prescription. You can then provide
them with your optician’s contact information, and Oscar Wylee
will get in touch with them for your prescription, or you can
upload a copy of your prescription at the checkout, or click "send
later" and send Oscar Wylee a copy via email.
#### How to Book an Eye Test with Oscar Wylee in Australia?
To book an eye test with Oscar Wylee in Australia,
customers
can book online, call your local store, or walk in and make an
appointment. To book an eye test with Oscar Wylee in Australia, customers
can visit their website and click book an eye test at the top
right corner. This will take customers to their booking page. On
this page, you can click the location closest, pick a date and
time, and confirm the booking. Customers can also call Oscar Wylee
and make an appointment by using the number 1300 164 990.
Customers can also navigate to Oscar Wylee’s location page, and
find your local store’s direct phone number. On this page,
customers can also find your local store's address and visit them
in-store to book an appointment.
## What Products and Services does Vision Direct Offer?
According to the Vision Direct AU website, as of June 2025, Vision Direct offer a range of products including prescription and
non-prescription glasses, sunglasses and contact lenses, and reglazing
services.
Vision Direct’s product offering is large, and includes a variety of
designer glasses, as well as a variety of contact lenses. Vision
Direct also provides a reglazing service in which customers can
purchase new prescription lenses which can be fitted to their current
frames. This is a good service for customers who have broken their
lenses, or need a new prescription but want to keep their current
frames. Vision Direct also offers a virtual try-on service in which
customers can virtually try on frames before purchasing. Vision Direct also have opticians available to assist customers through a phone call or video
consultation who are able to answer eye health queries.
### What Brands does Vision Direct Carry?
Vision Direct
carries a range of eyewear brands, including SmartBuy, which is the
parent company of Vision Direct, as well as Oakley and Nike.
Other brands Vision Direct carry include Ralph Lauren, Ray-Ban and
Tom Ford.
#### Does Vision Direct Offer Access to Optometrists?
Vision Direct does not offer direct access to an optometrist, but they do have
trained opticians available to help answer customer enquiries. Vision Direct has several options for how to get a customer’s
prescription added to their glasses. Prescriptions can be entered
manually or chosen from the customer’s prescription details from
their account. Prescriptions can also be uploaded as an image or
emailed to Vision Direct after the order is complete. If a
customer does not know their prescription, they may also be able
to use Vision Direct’s Lens Scanner App, which allows customers to
scan their current prescription lenses, for an estimate of what
the current prescription is. This is not a substitute for an eye
test.
## How do the Product Ranges and Services of Oscar Wylee and Vision Direct
Differ?
The product ranges and service differences between Oscar Wylee and Vision
Direct include designed vs branded frames,
eye testing and optometry services and contact lenses. The product range differences of both companies are listed in more
detail below.
|
|
| Category | Oscar Wylee | Vision Direct |
| In-house Designed or Branded Frames | Oscar Wylee’s glasses are designed in-house, carrying no other
brands. | Vision Direct carries a range of glasses brands, including
SmartBuy, the parent company of Vision Direct, and other brands
like Oakley. |
| Contact Lenses | Oscar Wylee does not offer contact lenses. | Vision Direct offers a range of contact lenses brands. |
| Eye Testing and Optometry Services | Oscar Wylee offers comprehensive eye tests and optometry services. | Vision Direct does not conduct eye testing, but does have
opticians available to assist customers through a phone call or
video consultation. |
| Virtual Try Ons | Oscar Wylee does not have virtual try ons. | Vision Direct has a virtual try on tool, allowing customers to try
on frames virtually before buying. |
### Where Can You Visit Oscar Wylee’s Physical Stores?
You can visit Oscar Wylee’s physical stores in Australia, Canada and New Zealand. There are currently more than 130 Oscar Wylee stores.
#### Can Oscar Wylee Ship Their Products Globally?
Oscar Wylee does not ship its products globally.
Customers are eligible for domestic [shipping](https://www.oscarwylee.com.au/shipping.html)
if they live in Australia, New Zealand and Canada with all
domestic shipping in Australia free.
#### Can Vision Direct Ship Its Products Globally
Yes, Vision Direct can ship its products to many places across the
globe. Currently, Vision Direct ships to over 100 countries. Vision Direct ships to and from a variety of locations including
Hong Kong, Italy, Australia, and the US.
### Which Brand offers a Wider Selection of Glasses, Oscar Wylee or Vision
Direct?
The brand that offers the widest selection of glasses
is generally Vision Direct, as they carry over 200 brands, in
different styles, colours and shapes. However, Oscar Wylee also
carries many frames in various styles, shapes and colours, of their
own brand.
### Which Brand Offers Better Value For Money, Oscar Wylee or Vision
Direct?
Both Oscar Wylee and Vision Direct offer good value for money through their quality products and services. Oscar Wylee not only provides bulk billed eye tests but also a
diverse range of eyewear, allowing customers to get on-hand eye care
services as well as an in-store experience. Vision Direct offers
good value for money with their wide range of eyewear and
designer-branded eyewear. However, Vision Direct does not currently
have any physical stores in Australia and therefore, does not
provide eye test services.
### What are the Return and Exchange Policies of Oscar Wylee and Vision
Direct?
The return and exchange policies of
Oscar Wylee and Vision Direct both include an aspect of returning
your prescription glasses after a specified period based on certain
criteria.
Oscar Wylee’s return and exchange policy includes an option to return your frames or lenses
if you find any possible production faults within 12 months of
delivery or purchase. Oscar Wylee also offers repairs or replacement
for problems experienced with vision during everyday use for claims
made within 30 days of delivery or receipt of purchase. Vision
Direct’s return and exchange policy includes returns for all
designer eyewear, prescription glasses and contact lenses within 100
days of receipt of shipment. Customers can choose whether they
prefer to receive a refund or an exchange for an alternative item.
#### Do Oscar Wylee or Vision Direct Offer Virtual Try-on Tools
Oscar Wylee does not offer virtual try-on tools, but Vision
Direct does.
With Vision Direct’s virtual try-on tool, customers can upload a
photo of themselves, or take a live photo, and the frame of their
choice will be superimposed on their face. This allows customers
to virtually try on the frames, and see how they would look,
before buying them online.
#### Are Oscar Wylee or Vision Direct Better for Prescription Sunglasses?
Whether Oscar Wylee or Vision Direct are better for prescription
sunglasses, depends on personal style and brand preference.
Both Oscar Wylee and Vision Direct offer prescription sunglasses
of many shapes, colours and sizes. If a customer prefers a brand,
they may shop prescription sunglasses at Vision Direct, as the
retailer carries brands such as Oakely and Nike sunglasses, which
can come with prescription lenses. At Oscar Wylee, all glasses,
including prescription sunglasses, are designed in-house, meaning
customers can purchase a unique prescription sunglasses frame in a
variety of styles, shapes and colours.
### Which Brand has Better Customer Reviews and Satisfaction, Oscar Wylee
or Vision Direct?
Both Oscar Wylee and Vision Direct have mixed customer reviews and satisfaction.
Oscar Wylee customer reviews often highlight the positive eye test
services and general care often experienced in-store. Many other
reviews mention the wide variety of frame style options that are
available for different face shapes and personal preferences. Vision
Direct’s customer reviews include their notable online customer
service as well as the availability of stylish frames.
## What are the Main Alternatives to Vision Direct?
The main alternatives to Vision Direct include Oscar Wylee, EyeBuyDirect and OPSM. These are the main alternatives to&nbsp; Vision Direct, and their
distinguishing characteristics are listed below.
* Oscar Wylee: Oscar Wylee creates solely in-house glasses for distinguished
eyewear that are stylish, affordable, and suited to every
demographic. Oscar Wylee also offers a free eye test for
international students when they purchase any pair of glasses on the
same day.
* EyeBuyDirect: [EyeBuyDirect](https://www.oscarwylee.com.au/vs-eyebuydirect)
is a budget-friendly eyewear brand that is solely based online, with home try-on options for many frame styles.
* Bailey Nelson: [Bailey Nelson](https://www.oscarwylee.com.au/vs-bailey-nelson)’s glasses range are developed
in Australia. They have a variety of their own branded glasses,
sunglasses and contact lenses on offer.
* OPSM: [OPSM](https://www.oscarwylee.com.au/vs-opsm)
is an Australian eyewear company with a range of glasses, lenses and
optical technology. OPSM also has a global eyecare charity,
OneSight.
* Specsavers: [Specsavers](https://www.oscarwylee.com.au/vs-specsavers)
is an English eyewear retailer selling notable designer brands, with
popular glasses collaborations alongside optometry and audiology
services.
* Warby Parker:
[Warby Parker](https://www.oscarwylee.com.au/vs-warby-parker)
is an American eyewear brand selling a variety of stylish frames
with helpful features such as a Style Quiz.
* Quay:
[Quay](https://www.oscarwylee.com.au/vs-quay-glasses) is
an Australian eyewear brand selling festival inspired
sunglasses.
* 1001 Optometry:
[1001 Optometry](https://www.oscarwylee.com.au/vs-1001-optometry)
offers many notable brands of glasses, sunglasses and contact
lenses.
Read Visual Acuity Tests: Types, Procedures, Benefits and Limitations
in other Oscar Wylee regions and their languages.
Australia
Australia
New Zealand
Canada

Major Health Funds Accepted In-store
For the purchase of frames and lenses, use your private health fund
insurance to minimise how much you pay from your own pocket.
[Discover health funds](https://www.oscarwylee.com.au/health-funds.html)
Are you due for an eye test?
At Oscar Wylee we offer bulk billed eye tests for all eligible
medicare card holders.
[Book an eye test](https://www.oscarwylee.com.au/booking)