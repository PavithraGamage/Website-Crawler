# Source: https://www.oscarwylee.com.au/glasses/eye/anatomy

# Eye: Definition, How does it Work, Anatomy, and Functions
Updated on November 15th, 2024
Published on February 19th, 2023
Australia
[Australia](https://www.oscarwylee.com.au/glasses/eye/anatomy)
[New Zealand](https://www.oscarwylee.co.nz/glasses/eye/anatomy)
[Canada](https://oscarwylee.ca/glasses/eye/anatomy)
[Canadian French](https://oscarwylee.ca/fr/lunettes/oeil/anatomie)
The eye is defined as the part of&nbsp;the human body that creates and controls how and what a person is capable
of seeing. The anatomy of the eye is made up of several parts, each with its own
purpose in protecting the eye or assisting with sight. The eye receives
light through the pupil which is sent to the lens which bends and
transforms shapes in order to send light to the retina and macula, which
creates images to send to the brain through the optic nerve. The parts of
the eye include the outer layer, which receives light and protects the
other layers, the middle layer, which nourishes the eye and contains the
most blood of the eye, and the inner layer, which receives light and
transforms the light into images to send to the brain.
Eye colour and eye shape vary heavily from person to person. The
eye-seeing ability is affected by damage, diseases and eye conditions, and
blue light wavelengths. Other animals, such as eagles, have different
makeup in their eye anatomy that affects their vision and allows them to
see clearer or sharper than the human eye is capable of seeing.
Are you due for an eye test?
Oscar Wylee offers bulk billed eye tests for eligible Medicare
cardholders.
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Definition](#Definition) [Parts](#Parts)
[Function](#Function) [Eye Diseases](#Diseases)
## What is the Eye?
The eye is&nbsp;an organ in the human body that controls sight and allows a person to
see. It is an asymmetrical globe located in the head. The iris of the
eye can be different colours, or pigmentations. The eye is similar to
an organic camera located in the head's socket, it is capable of
focusing on one single object for the sake of visual clarity and
perceiving as much detail as possible while blurring any irrelevant or
non-focused aspects of the immediate image.
The evolution of the eye is not a clear matter. The eye was believed
to have evolved from organic mechanics that helped the body to find
and keep a circadian rhythm: the ability to tell night and day outside
for the sake of knowing when to rest and when to wake up and take
action in the daytime, according to I R Schwab, from the University of
California’s Department of Ophthalmology &amp; Vision Science, during
a lecture on the development of the ocular toolkit.
What is the white part of the eye called?The white
part of the eye is called the sclera. The sclera shields the eye from
injury and helps the eye to stay in a globe shape.
## How Does the Human Eye Work?
The human eye works by&nbsp;receiving light through the pupil, focusing light through the lens
onto the macula and retina.&nbsp;The eye creates sight by absorbing light wavelengths from the
outside world through the outer layer of the eye. The outer layer of
the eye contains the white part of the eye, called the sclera, the
cornea and the iris. The eye takes this light and uses the inner layer
of the eye to create an image from the light the outer layer received.
The inner layer of the eye contains the retina and the optic nerve.
The middle layer of the eye is used to nourish the eye and contains
the choroid and the iris.The eye must stay moist to function properly, and has the 3 major
layers of the tear film to create tears which contain oils that supply
constant lubrication and nourishment.
## What are the Different Parts of an Eye?
There are 19 main part of the eye. The components of the eye and how
they function are listed below.
1. The choroid:&nbsp;The choroid is located between
the sclera and the retina and is where 85% of the eyes’ blood is
stored.
2. The ciliary body:&nbsp;The ciliary body is one of three parts that forms the middle layer
of the eye and provides nutrients for the lens and cornea.
3. The cone cells:&nbsp;The cone cells are
photoreceptors, a structure that helps convert light into signals that
are then sent to the brain. Cone cells control colour vision.
4. The cornea:&nbsp;The cornea is the transparent
outer layer at the front of the eye. The cornea helps the eye focus on
light.
5. The conjunctiva:&nbsp;The conjunctiva is the
membrane that covers the eyelids and the surface of the eye. The
conjunctiva protects the eye and keeps it wet.
6. The crystalline lens:&nbsp;The crystalline lens or
more commonly known as the lens, is a transparent structure that helps
the eye to focus light onto the retina.
7. The fovea:&nbsp;The fovea is a small depression
located at the centre of the retina that is responsible for direct and
central vision in the eye.
8. The iris:&nbsp;The iris is the visible, coloured
part of the eye. It controls the amount of light that enters the eye.
9. The Lens:&nbsp;A different term for the&nbsp;crystalline lens.
10. The macula:&nbsp;The macula is the centre of the
retina, located at the back of the eye. It converts light seen in the
eye into images.
11. The optic disc:&nbsp;The optic disc is an opening
that communicates signals between the optic nerve and photoreceivers,
allowing us to see.
12. The optic nerve:&nbsp;The optic nerve controls and
transmits all visual information to the brain.
13. The pupil:&nbsp;The pupil is in the iris. The
pupil is responsible for the volume of light that enters the eye.
14. The retina:&nbsp;The retina is a structure at the
back of the eyeball. The retina converts the light that enters the eye
into images that are sent to the brain.
15. The rod cells:&nbsp;The rod cells are
photoreceptors that are sensitive to low levels of light. They will
help you see at nighttime.
16. The sclera:&nbsp;The sclera is the visible white
of the eyeball. The sclera shields the eye from injury and helps keep
its shape.
17. The tear film:&nbsp;The tear film refers to
several layers of fluid that cover the surface of the eye. The tear
film keeps the eyes lubricated and stops them from going dry.
18. The vitreous body:&nbsp;The vitreous body is a gel
substance found throughout the eye. The vitreous body keeps the eye in
its round shape.
19. The zonules:&nbsp;The zonules are tiny fibres
found in the eye. The zonules help the lens in place.
### 1. Choroid
The choroid is a layer of the eyes located between the sclera and
the retina. According to ScienceDirect, the&nbsp;[choroid](https://www.oscarwylee.com.au/glasses/eye/choroid)&nbsp;is made up predominantly of blood vessels and accounts for
much of the blood flow found within the eyes.&nbsp;The choroid’s first function&nbsp;in the eye is to use the blood flow to provide nutrients and
sustenance to other vital parts of the eye, such as the retina,
macular and optic nerve.&nbsp;The second function&nbsp;of the choroid is to shield the eye from possibly harmful
light and reflection. The protective part of the choroid is what
causes ‘red eye’ in photography.If the choroid is damaged the retina begins bleeding. The damage
eventually results in the loss of peripheral vision and central
vision.
### 2. Ciliary Body
The ciliary body is a circular ring that is connected to the iris.
The ciliary body is one of three parts that form the middle layer of
the eye. The other parts of the middle layer are the choroid and the
iris.&nbsp;The first function&nbsp;of the&nbsp;[ciliary body](https://www.oscarwylee.com.au/glasses/eye/ciliary-body)&nbsp;is&nbsp;to hold the lens in place in the eye using the&nbsp;ciliary muscle&nbsp;which also helps to accommodate the lens, making the lens
able to change shape and focus the eyes.&nbsp;The second function&nbsp;of the ciliary body is to use&nbsp;the ciliary processes to&nbsp;produce a fluid in the eye called&nbsp;aqueous humour. Aqueous humour is a visible, clear fluid that is vital for
nourishing the eye and helps the eye to maintain its shape.Damage to the ciliary body results in blurred vision and an
inability to focus. Damage to the ciliary body results in complete
vision loss if it is left untreated.
### 3. Cone Cells
Cone cells are found near the macula of the eye and help to
perceive colours and details. There are 6 million cone cells found
within the eye.&nbsp;The first function&nbsp;of cone cells is to help convert light into signals to send
to the brain as they are photoreceptors which are cells in the eye
that are sensitive to light.&nbsp;[Cone cells](https://www.oscarwylee.com.au/glasses/eye/cone-cells)&nbsp;are one of two types of photoreceptors found within the eye.
The other type of photoreceptor is the eye rods and their
variations. There are three types of cone cells:&nbsp;red-sensing cone cells,&nbsp;blue-sensing cone cells&nbsp;and&nbsp;green-sensing cone cells. Each type of cone cell functions to help the eye perceive the
pigmentation of the cone cells sensing colour.Cone cells are responsible for colour vision within the eye. The
second function of cone cells and rod cells is to translate light
into electric signals and then send them to the brain through the
optic nerve.Damage to the cone cells results in sensitivity to light, less
visual information when looking straight ahead and difficulty seeing
colour.
### 4. Cornea
The cornea is the clear outer layer at the front of the eye,
according to the National Eye Institute. It is located in the very
front portion of the eye, directly covering the pupil, iris and
anterior chamber.&nbsp;The first function&nbsp;of the cornea is to control how much light enters the eyes
and focus the light that is received. The&nbsp;[cornea](https://www.oscarwylee.com.au/glasses/eye/cornea)&nbsp;bends and refracts any light the eye receives by changing
size, becoming smaller or larger, depending on the volume of light
entering the eye. The cornea is the first contact light has with the
human eye and serves to focus the majority of the light the eye
receives.The cornea’s second function is to protect the eye by filtering out
harmful glare from the eye, such as ultraviolet rays from sunlight.
The cornea is equipped to deal with minor damage, such as cuts,
scars or other abrasions.Heavy damage to the cornea results in distorted vision and a lesser
ability to see light.
### 5. Conjunctiva
The conjunctiva is a thin layer of tissue, referred to as a mucous
membrane, that covers the whites of the eye and lines the inside of
the eyelid. The conjunctiva’s layer of tissue is clear and
see-through. It is located in the outer layer of the
eye.&nbsp;The first function&nbsp;of the conjunctiva is to secrete fluids that keep the eyes
lubricated and protected from infections and outside bacteria and
bodies, such as dust or other bodies.The&nbsp;[conjunctiva](https://www.oscarwylee.com.au/glasses/eye/anatomy/conjunctiva)&nbsp;itself is made up of three aspects, the&nbsp;bulbar conjunctiva, the palpebral conjunctiva and the fornix
conjunctiva.&nbsp;The&nbsp;bulbar conjunctiva&nbsp;is the section that covers the sclera but not the cornea.
The&nbsp;palpebral conjunctiva&nbsp;is the section that covers the eyelid in both its upper and lower
parts. The&nbsp;fornix conjunctiva&nbsp;is located between the other two sections, the fornix
conjunctiva allows the eyelid and eyeball freedom of
movement.&nbsp;The second function&nbsp;of the conjunctiva is to ensure no foreign body or object
slips behind the eye, such as contact lenses.Damage to the conjunctiva affects the eyes' appearance, making them
discoloured and visibly injured and causing conditions such as dry
eye and blurred vision.
### 6. Crystalline Lens
The crystalline lens is a natural focusing lens in the eyes that
provides a portion of the optical power found within the eye. It is
also simply referred to as the lens of the eye.&nbsp;The first function&nbsp;of the lens is for bending and focusing light by changing
shape with its natural elasticity. The lens uses its changing shape
to shine the light it receives directly into the retina, which
begins the process of changing outside light into a perceivable
image.&nbsp;The second function&nbsp;of the lens is to work together with the ciliary muscle when
focusing in order to see distant objects. Part of the crystalline
lens' ability to change shape is provided by the ciliary muscles’
power.When the [crystalline lens](https://www.oscarwylee.com.au/glasses/eye/anatomy/crystalline-lens)
transfers the light of an image, the image is actually received
upside down. As light from the crystalline lens is transferred to
the brain, the optic nerve reverses the image to be right-side
up.Damage to the crystalline lens causes cataracts, a dislocated lens
and blurred vision. Damage to the crystalline lens is irreversible,
such as scratching or dislocation. Damage to the crystalline lens
may also affect the iris as the iris loses its support within the
structure of the eye.
### 7. Fovea
The fovea, or fovea centralis, is a small depression or pit located
at the centre of the retina that controls the sharpness of central
vision. The fovea centralis and its surrounding, the parafovea and
perifovea regions, contain cone cells that assist in vision. The
fovea itself contains a massive amount of cone cells, which is why
its main function is for the clarity of central vision and central
vision's ability to see exact detail.Damage to the fovea causes a loss of ability to see colour,
perceive daytime and would reduce the eye's ability to see sharp
details. Damage to the&nbsp;[fovea](https://www.oscarwylee.com.au/glasses/eye/anatomy/fovea)&nbsp;is caused by eye conditions such as macular degeneration and
Stargardt disease. If the fovea is compromised, the retina actually
forms what is known as a ‘pseudofovea’, according to an article
written by the Fighting Blindness Foundation in 2013. A pseudofovea
is a new focal point that optimises the remaining photoreceptors in
the eye.
### 8. Iris
The iris is a visible and coloured part of the eye located behind
the cornea and in front of the crystalline lens.&nbsp;The main function&nbsp;of the iris is to control the size of the pupil and the eye's
general ability to let light in. The iris is a muscle that shrinks
the pupil in response to too much light and widens the pupil if
there is too little light. The&nbsp;[iris](https://www.oscarwylee.com.au/glasses/eye/anatomy/iris)&nbsp;is connected to the ciliary body. The iris contains the
pigmentation that determines what a person's eye colour is, based on
genetics and the amount of melanin that is within the front layers
of the iris.Damage to the iris changes the appearance of the eye and affects
how well the eye receives light. This results in intense light
sensitivity and vision loss.
### 9. Lens
The lens is simply a more common term for the crystalline lens. There is no difference between the [lens](https://www.oscarwylee.com.au/glasses/eye/anatomy/crystalline-lens)
and the crystalline lens in the eye’s anatomy. The main function of the lens is to help focus light onto the retina.
### 10. Macula
The macula is an area of the eye found in the very centre of the
back of the eyeball and the retina. It is the central part of the
retina.&nbsp;The main function&nbsp;of the macula is to translate light into images, allowing a
person to see clear and precise details of objects in front of the
eyes, such as writing or seeing the details of people's faces.
The&nbsp;[macula](https://www.oscarwylee.com.au/glasses/eye/anatomy/macula)&nbsp;is made up of photoreceptor cells like cones cells, which
detect light and colour.Damage to the macular results in difficulty seeing fine details
like small print and distortion in general vision. If the damage is
severe or long-lasting, it results in a ‘black hole’ or black patch
in a person's vision.
### 11. Optic Disc
The optic disc is a round disc found in the back of the eye. The
optic disc is also referred to as the optic nerve head and is where
the optic nerve begins.&nbsp;The first function&nbsp;of the optic disc is that it is the exit point for the
retinal ganglion cells to leave the eye, allowing the cells to
transfer signals from the eye’s photoreceptors to the optic
nerve.&nbsp;The second function&nbsp;of the&nbsp;[optic disc](https://www.oscarwylee.com.au/glasses/eye/anatomy/optic-disc)&nbsp;is it acts as the entry point for the blood vessels that
supply the retina. The optic disc has no photoreceptors surrounding
it, and its place in the eye is a small blindspot.Damage to the optic disc affects how the optic nerve functions and
can lead to immediate or gradual loss of vision.
### 12. Optic Nerve
The optic nerve is a long nerve that extends directly out the back
of the eyes that begins at the optic disc. The optic nerve is made
up of millions of nerve fibres and its&nbsp;first function&nbsp;is to carry messages directly from the eyes towards the
brain. It is not just part of the eye, but also part of the body's
central nervous system. The&nbsp;[optic nerve](https://www.oscarwylee.com.au/glasses/eye/anatomy/optic-nerve)&nbsp;is one of the most critical parts of the eye, as without it
no visual information could be received by the brain. The optic
nerve is made up of branches of&nbsp;retinal ganglion cells&nbsp;and&nbsp;glial cells&nbsp;and its&nbsp;second function&nbsp;is that these branches split up and reach out into the left
and right eye in order to retrieve visual information from all
possible sources, such as the retina and the fovea. These cells
reach into the eyes to connect to photoreceptors like the rods and
cones, and from there send the visual information the receptors
receive to the brain.Damage to the optic nerve will result in vision loss, both
temporary and permanent depending on the condition of the nerve and
the cause of the damage. Untreated optic nerve damage leads to
blindness.
### 13. Pupil
The pupil is an opening in the iris located directly in the centre
of the eye and covered by the cornea. The pupil is surrounded by
the&nbsp;iris, which controls its size to maintain how much light is allowed
inside of the eye depending on the volume of the light being
viewed.&nbsp;The first function&nbsp;of the pupil is to allow light into the eye so it may be
focused in the&nbsp;retina&nbsp;by the eye's&nbsp;lens&nbsp;and transferred into images.&nbsp;The second function&nbsp;of the&nbsp;[pupil](https://www.oscarwylee.com.au/glasses/eye/anatomy/pupil)&nbsp;is that it is the pathway that&nbsp;aqueous humour&nbsp;from the&nbsp;ciliary body&nbsp;reaches the front of the eye and provides nourishment to all
parts of the eye near the pupil.Damage to the pupil is not directly possible, however damage to the
iris or the nerves connected to the pupil will result in extreme
light sensitivity during the day, or when looking at bright light
and glares. A non-functioning or large dilated pupil is called a
blown pupil. It is not responsive to light and is caused by severe
brain trauma, such as a stroke.
### 14. Retina
The retina is a layer of tissue located directly at the back of the
eye.&nbsp;The retina’s main function&nbsp;is to receive light that comes in through the eye's lens and
translate that light into images. The retina is made up of two
parts, the macula, which is responsible for the direct frontal
vision and the ability to perceive up close and small details, such
as fine print and the peripheral&nbsp;[retina](https://www.oscarwylee.com.au/glasses/eye/anatomy/retina)&nbsp;which is responsible for vision outside of direct central
vision, and for what is seen from the corners of the eye.Damage to the retina results in blurred vision, seeing floating
spots or flashes of light.
### 15. Rod Cells
Rod cells are photoreceptors in the eye that are highly sensitive
to light and shapes and are located within the retina.&nbsp;The first function&nbsp;of rod cells is to provide good vision when a person is in
low light.&nbsp;The second function&nbsp;of&nbsp;[rod cells](https://www.oscarwylee.com.au/glasses/eye/anatomy/rod-cells)&nbsp;is to perceive the size, shape and brightness of an image
that they are activated by. Rod cells do not respond to colour and
are not responsible for colour vision. They are much more sensitive
to light than cone cells. According to the National Library of
Medicine, there are approximately 120 million rod cells within the
retina. Rod cells are located around the periphery of the retina,
compared to the cone cells found in the macula and the fovea.Damage to the rod cells results in night blindness, diminished
periphery vision, light sensitivity and photophobia.
### 16. Sclera
The sclera is the visible whites of the eye. They are located on
the outer layer of the eye, by the cornea. The sclera is a form of
tissue made up of 4 layers, the episclera, loose tissue that rests on top of the whites of the eyeballs, the stroma,
made up of collagen tough fibres, the same thick material as the
cornea, the lamina fusca, made up of elastic fibres that help transition the [sclera](https://www.oscarwylee.com.au/glasses/eye/anatomy/sclera)
between the choroid and the ciliary body, and the endothelium, the innermost layer of the sclera, which contains pigments.The sclera’s main function&nbsp;is to hold the shape of the eyeball through its strong
fibres. The sclera is the part of the eye that moves using the
eyelid muscles in order for the eye to see in different
directions.Damage to the sclera results in blurry vision, sensitivity to light
and excessive tearing.
### 17. Tear Film
The tear film covers the entire surface of the eye.&nbsp;The first function&nbsp;of the tear film is to keep the eyes lubricated. The
[tear film](https://www.oscarwylee.com.au/glasses/eye/tear-layer)
is reapplied to the eye when a person blinks and remains as a
constant coating across the ocular surface. The tear film is
provided by the tear gland, located on the top of the eyes, near the
eyebrows.The tear film is made up of three layers,&nbsp;the lipid layer, which holds oils and fatty acids that keeps the tears from
drying,&nbsp;the aqueous layer&nbsp;where the tears nourish the eye and clean away unneeded
nourishing particles, and&nbsp;the mucin layer, which distributes liquid from the aqueous layer throughout the
eye and nourishes the cornea.The second function&nbsp;of the tear film is to prevent infection and keep the surface
of the eye smooth and clean, enabling better light refraction.Damage to the tear film will result in dry, itchy eyes, blurred
vision and inflammation.
### 18. Vitreous Body
The vitreous body is a gel substance that fills most of the space
of the eye, from the lens down to the retina. It is also referred to
as
[vitreous humour](https://www.oscarwylee.com.au/glasses/eye/vitreous-humour)
and is the largest part of the eyeball. The fluid of the vitreous
body is clear, gelatinous and has no colour.&nbsp;The first function&nbsp;of the vitreous body is to protect all the parts of the eye
it covers.&nbsp;The second function&nbsp;of the vitreous body is to help the eye keep its spherical
shape and hold the retina in place.Damage to the vitreous body results in shadows appearing in the
retina, and what many people call ‘floaters’ appearing in
eyesight.
### 19. Zonules
Zonules, technically referred to as ‘zonule of Zinn’, are tiny
fibres that form a band around the lens of the eye. Zonules are made
of fibrillin, a protein fibre found commonly in protective
tissue.&nbsp;The first function&nbsp;of zonules is to hold the lens in place and connect the lens
to the ciliary body.&nbsp;The second function&nbsp;of Zonules is to assist the lens in changing shape in order
to bend light for better vision. The zonules strands will pull the
lenses to help up-close vision, and flatten the lens for distance
vision.Zonules cannot directly be damaged, however weak or weakened
zonules result in strange pupil dilation, cataracts and poor
functioning of the lens, causing blurred vision and an inability to
focus the eyes.
### What are the Examples of Simple Eye Diagrams?
The following images show examples of eye anatomy labelled, and
where each part of the eye sits inside the spherical structure. Some
parts of the eye, such as the cone rods and cone cells, cannot
directly be displayed.The examples of simple eye diagrams are as follows:
### What are the Examples of Labelled Eye Anatomy Diagrams?
The&nbsp;number 1 component&nbsp;in the labelled eye diagram for eye anatomy demonstrates
the&nbsp;tear layer,&nbsp;which keeps all other parts of the eye lubricated and directly
nourishes other parts of the eye including&nbsp;component 2,&nbsp;the sclera&nbsp;and&nbsp;component 3,&nbsp;the cornea.The&nbsp;number 2 component&nbsp;in the labelled eye diagram for eye anatomy
demonstrates&nbsp;the sclera,&nbsp;the white part of the eye,&nbsp;which provides shielding for the eye against injury and helps
maintain the eyes shape.The&nbsp;number 3 component&nbsp;in the labelled eye diagram for eye anatomy
demonstrates&nbsp;the cornea, which receives the light from the outside world and helps other
parts of the eye, components&nbsp;number 4&nbsp;and&nbsp;number 5,&nbsp;the iris&nbsp;and&nbsp;the pupil, to focus the light into images.The&nbsp;number 4 component&nbsp;in the labelled eye diagram for eye anatomy
demonstrates&nbsp;the iris, which is a muscle that forms the pupil&nbsp;component number 5,&nbsp;the pupil. The iris controls the size of the pupil, and by extension, the
amount of light the pupil allows into the rest of the eye.The&nbsp;number 5 component&nbsp;in the labelled eye diagram for eye anatomy
demonstrates&nbsp;the pupil. The iris modifies the shape of the pupil which then focuses light
onto the lens.&nbsp;The pupil&nbsp;itself is not a structure, but rather the name for the hole
in&nbsp;the iris.The&nbsp;number 6 component&nbsp;in the labelled eye diagram for eye anatomy
demonstrates&nbsp;the lens, which receives light controlled and contained by the pupil and
transfers it further into the eye, towards the lens.
## What is the Function of the Eye?
The function of the eye is to&nbsp;receive light from the outside world, transform that light into a
viewable image and then send that image to the brain through the optic
nerve, creating vision and sight.The eye magnifies the images it receives and assists the brain in
focusing and storing information.
### How Does the Eye Achieve Visual Acuity?
The eye performs visual acuity by receiving light through the
cornea, which is then adjusted by the pupil and iris to control how
much light goes into the eye and how much light the lens receives.
The lens then sends the light to the retina, a layer of the eye
found directly at the back of the eye’s structure. On the way to the
retina, the light will pass through the vitreous body and then focus
onto the macula. The retina then sends electrical signals to the
brain through the optic nerve in order to create a visible
image.
### How do Eyes Perceive Colours?
The eye perceives colour&nbsp;through the cone cells, photoreceptors found inside the retina and
the macula. When light wavelengths hit the eyes, the cones are stimulated and
send a signal through the optic nerve to the brain. There are three
different types of cone cells, red-sensing cone cells, blue-sensing
cone cells and green-sensing cone cells, each of which is stimulated
to determine which colour of light the eye is seeing. The eye
condition&nbsp;[colour blindness](https://www.oscarwylee.com.au/glasses/eye/colour-blindness-types)&nbsp;can affect how a person perceives colours.
### How do Rod Cells and Cones Help for Light Sensitivity?
Rod cells and cones help with light sensitivity by&nbsp;responding differently to the level of light the eye receives, allowing for better vision in low or high light, depending on
whether the cone cells have enough light to be active or not.There are 120 million rod cells in the retina, and 6 million cone
cells according to the National Library of Medicine. Rod cells are
responsible for vision at low light, also known as scotopic vision.
Rod cells have a lesser ability to perceive colour than cone cells
but are much more sensitive to any light the eye receives.Cone cells are less sensitive to light but are sensitive to one of
three colours, red, green and blue, which they only perceive in
decent lighting. The majority of cone cells are found within the
fovea, which controls central vision.
### What are Eye Diseases that Affect Different Eye Functions?
The different types of&nbsp;[eye diseases](https://www.oscarwylee.com.au/glasses/eye/how-to-detect-diseases)&nbsp;for different eye functions mostly relate to&nbsp;age-related eye conditions.&nbsp;These age-related diseases include&nbsp;age-related macular degeneration,&nbsp;cataracts,&nbsp;glaucoma&nbsp;and&nbsp;amblyopia. The different types of eye diseases are listed below.
* Age-Related Macular Degeneration: Age-related macular
degeneration is caused by damage to the macular that comes from it
naturally growing older. Macular degeneration results in a
diminished ability to see fine details or to see well through the
eyes' central vision. Over 200 thousand people suffer from macular
degeneration, according to the Australian Government Department of
Health and Aged Care.
* Cataracts: Cataracts are cloudy areas in the lens of the eye.
They are caused by age or injury. As cataracts are caused by ageing
they will, at some point, affect all seeing humans and animals in
their lifetime.
* Glaucoma: Glaucoma is an umbrella term for a group of eye
problems. The root cause of glaucoma is damage to the optic nerve.
The damage can be caused by high and low blood pressure, age, family
genetics, or eye injuries. Over 300,000 Australians suffer from
Glaucoma, according to Glaucoma Australia.
* Amblyopia: Amblyopia, also known as lazy eye, is caused by
one of the eyes having poor vision compared to the other. The
imbalance of the eyes causes one or both of them to cross inward or
look too far outward. 3 out of 100 children are born with amblyopia,
according to the National Eye Institute.
### What are the Different Parts of Eye Layers' Function?
The different parts of the eye’s layers and their functions are
the&nbsp;inner layer that controls sight, the middle layer that nourishes
the eye and the outer layer that protects. The different layers of the eye and their functions are listed
below.
* The Middle Layer (The Uvea): The middle layer of the eye
contains the majority of the blood cells, and it contains the parts
of the eye that feed the entire structure, such as the choroid. It
is also known as the vascular tunic.
* The Outer Layer:&nbsp;The Outer layer of the eye contains strong fibres and layers of
tissue found in the cornea. The outer layer is made up of the
sclera and the cornea, which protect the eye from bacteria,
excessive light and other outside interference. It is also known
as the fibrous tunic.
* The Inner Layer:&nbsp;The inner layer of the eye controls how the eye sees by
transforming light into images which are then sent to the brain to
enable the body's ability to see. It contains the retina, optic
nerve, macula and fovea. It is also known as the nervous
tunic.
#### What is the Function of the Outer Layer of the Eye?
The function of the outer layer of the eye is&nbsp;to protect the inner layers from damage and to receive light for
the rest of the eye, as well as containing the eye's focusing power and tears. It is
made up of the cornea and the sclera.
##### What is the Anatomy of the Eye Socket?
The anatomy of the eye socket is made up of 7 different
bones:&nbsp;the sphenoid, the zygomatic, the frontal,the lacrimal, the
maxilla, the palatine and the ethmoid. These bones make up the eye socket, also called the ‘orbit’.
The eye socket contains fat, muscles and nerves built to help
hold the globe of the eye within it. At the back of the socket
is the opening to the optic canal and the optic nerve’s flow to
the brain.
#### What is the Function of the Middle Layer of the Eye?
The function of the middle layer of the eye is to&nbsp;nourish the entirety of the eye. The middle layer of the eye contains the most blood vessels. It
is made up of the choroid, the ciliary body and the iris. The
majority of this layer is the responsibility and function of the
choroid.
#### What is the Function of the Inner Layer of the Eye?
The function of the inner layer of the eye is to&nbsp;receive light&nbsp;in the retina, fovea and macula and&nbsp;transfer the light into an image to send to the brain&nbsp;through the optic nerve, creating sight and vision.
## How Did the Eye Evolve?
The eye evolved from an organism called the trilobites over 541
million years ago. Trilobites' eyes were compound, similar in makeup
to an insect. Before trilobites, there were no animals that had
evolved eyes during the Cambrian explosion. According to I R
Schwab,&nbsp;the mechanisms that eyes would evolve from in proto-mammals were
originally photoreceptors that could only measure the brightness of
the immediate area. These photoreceptors evolved in order to help the body recognize
night from day, and would control the body's circadian rhythm, the
time it would need to be active and the time the body would need to
test.In an article for the New York Times, science writer Carl Zimmer
stated that the common ancestor of all forms of evolution in the eye
is a molecule called the opsin. It is the presence of opsin that the
proto eye reacted to and evolved with in order to accommodate for the
opsins functions.
### What is Pigmentation in the Eye?
Pigmentation in the eye is the technical term for&nbsp;colour found in different parts of the body, in this case, the eye
and the colour of the iris in the eye specifically. Pigmentation in the eye evolved from chromophore, a part of a
molecule that controls colour. Pigmentation in the eye can be found
in the iris. The amount of melanin, a pigmentation that can be found
in the hair, the eyes and the skin controls the darkness of the
pigment's appearance. Pigmentation changes in the eye are visible
and are a warning sign of damage or macular degeneration.
## What are the Three Chambers of Fluid in the Eye Ball?
The three chambers of fluid in the eyeball are&nbsp;the anterior chamber, found between the cornea and the iris, the
posterior chamber, located between the zonules and the lens, and the
vitreous chamber, between the lens and the retina. The first two chambers are filled with aqueous humour, a substance
that provides nutrition, protection, cleaning and moisture to the eye.
The third chamber is filled with the vitreous body, which maintains
the eye's shape.
### 1. Anterior Chamber
The anterior chamber is a space of fluid close to the eye's outer
layer. The anterior chamber’s function is to&nbsp;hold aqueous humour and give the benefits of aqueous humour to the
cornea and iris. The anterior chamber is also used by eye health professionals to
determine the risk of glaucoma by measuring the depth of the
chamber's size.
### 2. Posterior Chamber
The posterior chamber of the eye is a small space behind the iris
and in front of the lens and ciliary body. The posterior chamber is
close to the ciliary body and&nbsp;directly receives and stores aqueous humour the ciliary body
creates, storing it for the middle layer of the eye and assisting in
nourishing the parts of the eye close to it.
### 3. Vitreous Chamber
The vitreous chamber of the eye is a large space behind the lens
that covers and embodies a large part of the eye. It is filled with
the vitreous humour, also known as the vitreous body, which is a
thick substance that&nbsp;helps the lens to magnify its focus and assists the eye in keeping
its globular shape.
Find your local Oscar Wylee store
Come and see our team for your optometry needs, including eye tests
and optometry advice. All major health funds accepted in store.
[Find a store](https://www.oscarwylee.com.au/locations)
## What Part of the Eye is Responsible for Vision?
The retina is the part of the eye directly responsible for vision. The retina is a layer of tissue at the back of the eye that is
light sensitive and is&nbsp;[responsible for vision](https://www.oscarwylee.com.au/glasses/eye/perfect-vision)&nbsp;as it creates and controls the production of images created
from light to be sent to the brain through the optic nerve.
### What Happens to the Eyes when Exposed to Blue Light from Devices?
When the eye is exposed to blue light from digital devices, it
associates the light with light emitted from the sun, due to the
large amount of blue light UV rays contains, causing the body to
feel alert, aware and awake, no matter what the time of day is, or
how much natural light is outside.
### What Part of the Eyes Protects the Eye from Blue Light?
The eye is protected from blue light by the cornea and the
crystalline lens.
### How Can You Keep Your Eyes Healthy?
Here are&nbsp;[five tips for eye health](https://www.oscarwylee.com.au/glasses/eye/health-tips-keeping-eyesight-healthy).&nbsp;The first method is to&nbsp;eat healthily and have a good diet. By eating well, the body will receive Omega 3 fatty acids that
the eye needs in order to function at its peak level. Fish and green
vegetables especially contain the premium nutrients needed for
healthy eyes.The second method to keep your eyes healthy is to&nbsp;regularly see an eye health professional&nbsp;to regularly check vision skills, update possible prescriptions and
give personalised advice on the best methods of eye health
care.The third method to keep the eyes healthy is to&nbsp;wear sunglasses and protect the eyes from UV rays. UV can cause damage to the lens of the eye and lead to cancerous
growths. By wearing sunglasses or other forms of UV protection for
the eyes,&nbsp;the eyes can stay healthier for longer.The fifth method to keep your eyes healthy is to&nbsp;healthy weight and exercise regularly. Diabetes greatly increases the chances of glaucoma and other eye
health conditions, and an improper or unhealthy diet results in the
eyes not receiving essential nutrition.The fifth method to&nbsp;keep a record of family medical history. Records from optometrists and eye doctors keep track of possible
hereditary eye diseases, such as Stargardt disease, Choroideremia or
Cone-rod Dystrophy. Hereditary conditions can be prevented or
monitored early if they are identified and made known as soon as
possible.
#### Is Blue Light Harmful to the Eyes?
There is not yet any definitive scientific evidence to conclude
that blue light is harmful to the eyes. However, the effects blue
light has on the body once it has been received by the eye are
potentially harmful, and prolonged exposure to blue light may lead
to dry eyes or cataracts.
#### Do Blue Light Glasses Work?
Blue light glasses can be effective for restoring sleep cycles
and reducing the eye strain excessive amounts of blue light from
digital and artificial sources can cause, according to a study
performed by Chung Shang Medical University.
## What are the Different Types of Eye in Living Things?
There are six main different types of eyes in living things. These
types are sorted into compound eyes and simple eyes. Simple eyes have
a single type of eye structure that functions together. Compound eyes
may be made up of entirely photoreceptors, or have multiple eye
structures inside their makeup. Human eyes can be classified as
matching multiple categories of eye types. The main types of eyes in
living things are&nbsp;pit eyes, reflector eyes, apposition eyes, eyes with refractive
corneas, eyes with multiple lenses, and&nbsp;superposition eyes. The main type of eyes in living things are listed below.
* Pit Eyes:&nbsp;Pit eyes are eyes capable of
retracting into a pit in the skull in order to reduce the light the
eye receives, or change the angle of the incoming light. They are
classified as simple eyes.
* Reflector eyes:&nbsp;Reflector eyes are eyes that
have a layer of tissue in the eyes called a tapetum lucidum in place
of the lens. They are most common in scallops. They are classified as
simple eyes.
* Apposition eyes:&nbsp;Apposition eyes are eyes
that can move separately and that function by gathering information
from each eye separately. They are most commonly found in crabs. They
are classified as compound eyes.
* Eyes with refractive corneas:&nbsp;Eyes with
refractive corneas are eyes that are capable of refraction in the
corneas and the vitreous body, meaning the outside of the eye can
assist the lens in focusing the light eye receives. These are human
eyes and the most common eye type in mammals. Refractive corneas are
classified as simple eyes.
* Eyes with multiple lenses:&nbsp;Eyes with multiple
lenses are eyes that have more than one lens inside of the eye's
structure, typically arranged in a line that is similar to a
telescope. Multiple lenses can be found in eagles and certain spider
species. They are classified as simple eyes.
* Superposition eyes:&nbsp;Superposition eyes are
eyes that are fixed in place and gather light from all angles except
the frontal, central position. Superposition eyes are found in insects
such as flies. They are classified as compound eyes.
### How Does Eagle Vision differ from Human Vision?
An eagle's vision is assumed to be 8 times stronger and sharper
than humans.&nbsp;An eagle's eye contains retinas bigger and full of more nerves
and photoreceptors than a human does. Eagle eyes contain a much deeper fovea, allowing the eye to have
more cone cells.Eagles are capable of seeing through each eye individually, meaning
both eyes do not have to focus on the same target in an eagle's
vision. This is called monocular vision. Eagles have a set of
eyelids that humans do not have, called the nictitating membrane.
The nictitating membrane allows eagles to see with their eyes
closed.
## What are the Types of Eye Shapes?
There are six main types of eye shapes:&nbsp;Hooded,&nbsp;upturned,&nbsp;round,&nbsp;monolid,&nbsp;downturned&nbsp;and&nbsp;almond. The eye shapes and what they look like are listed below.
* Hooded eye shape:&nbsp;A hooded eye shape is when
the eyes have skin and tissue extending from the eyebrows that cover
the top of the eyelid. This growth does not cover the eye itself.
* Upturned eye shape:&nbsp;An upturned eye shape
means that the corner of the outside of the eye turns upwards into the
forehead.
* Round eye shape:&nbsp;A round eye shape is an eye
shape that is much more circular than average, exposing more of the
whites of the sclera
* Monolid eye shape:&nbsp;A monolid eye shape is
when the skin of the upper eyelids covers the entirety of the inner
eye, leaving no sight of any upper eye muscles
* Downturned eye shape:&nbsp;A downturned eye shape
means that the corner of the outside of the eye turns downward,
towards the mouth.
* Almond eye shape:&nbsp;An almond eye shape is when
the eye itself is longer in width than it is wide, being similar in
shape to an almond nut.
### What Determines Eye Colour?
Eye colour is related to the iris and&nbsp;how much melanin, a type of pigmentation, is in the iris’s front
layer.&nbsp;For instance, people with brown&nbsp;[eye colour](https://www.oscarwylee.com.au/glasses/eye/colour-and-shape-say-about-health)&nbsp;have a greater amount of melanin in their eyes than those
with blue eyes. The amount of melanin in the eyes changes depending
on many factors, but the major one is genealogy.
### How Does Eye Shape Affect Glasses Frame Style?
Eye shape affects glasses frame style by&nbsp;having an outward appearance that is more suitable for specific
styles of frames. As eye shape will blend with the style of the glasses, it is best
to choose frames that compliment or are a similar style to the eye
shape, such as round glasses for round eyes or aviator glasses for
almond eyes.
Read Eye: Definition, How does it Work, Anatomy, and Functions in
other Oscar Wylee regions and their languages.
Australia
[Australia](https://www.oscarwylee.com.au/glasses/eye/anatomy)
[New Zealand](https://www.oscarwylee.co.nz/glasses/eye/anatomy)
[Canada](https://oscarwylee.ca/glasses/eye/anatomy)
[Canadian French](https://oscarwylee.ca/fr/lunettes/oeil/anatomie)
Find an Oscar Wylee store near you
Our friendly team can help you shop our range of stylish and
affordable frames.
[Find a store](https://www.oscarwylee.com.au/locations/)
Prioritise your eye health at Oscar Wylee
Book an eye test with our dedicated and experienced optometrists
[Book an eye test](https://www.oscarwylee.com.au/booking)