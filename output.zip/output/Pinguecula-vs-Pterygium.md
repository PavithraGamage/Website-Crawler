# Source: https://www.oscarwylee.com.au/glasses/eye/pinguecula-vs-pterygium

# Pinguecula vs Pterygium
Published on July 2nd, 2026
Pinguecula and pterygium are common, non-cancerous growths that form on the conjunctiva, or white part
of the eye. The main difference between pinguecula and pterygium is that pinguecula
grows solely on the conjunctiva, while pterygium grows over the cornea as
well. They are mainly caused by long-term exposure to UV rays, wind, and
dust, and appear more commonly in those who spend extended time outdoors.
The main symptoms of pinguecula and pterygium are the visible growths on
the eye, which may be accompanied by dryness, irritation, a foreign body
sensation, redness, and swelling. UV400 lenses are recommended for
prevention because they block nearly 100% of UVA and UVB radiation. The
recommended sunglass styles to protect against UV exposure are wraparound
sunglasses, large frame sunglasses, close-fitting sunglasses, UV400
sunglasses, and UV400 polarised sunglasses.
It is important to note that Oscar Wylee offers optometry services only;
this article is for educational purposes only and is not a substitute for
professional medical advice, diagnosis, or treatment.
Prioritise Your Eye Health
Our team can help you stay up to date with regular eye tests to keep your
eyes healthy!
[Book an eye test](https://www.oscarwylee.com.au/booking)
[Definition](#definition) [Appearance](#appearance)
[Causes](#causes) [Symptoms](#symptoms)
[Diagnosis](#diagnosis) [Treatment](#treatment)
[Complications](#complications)
## What Are Pinguecula and Pterygium?
[Pinguecula](https://www.oscarwylee.com.au/glasses/eye/pinguecula)
and
[pterygium](https://www.oscarwylee.com.au/glasses/eye/pterygium-definition)
are both common, non-cancerous growths on the eye. A pinguecula is a small yellowish growth on the white of the eye,
and a pterygium is a fleshy tissue that grows over the cornea,
according to the North Shore Eye Centre, Sydney. Pinguecula and
pterygium differ in their size, appearance, and effects on vision.
If you notice a new growth on or around your eye, we recommend you
book in to see your optometrist immediately.
### How Do These Eye Growths Develop?
Pinguecula and pterygium primarily develop due to long-term UV exposure and chronic irritation from wind,
dust, and dry environments,
according to the Better Health Channel, Victoria. Both pinguecula
and pterygium can be made worse by chronic dryness and
irritation.
#### Are Pinguecula and Pterygium The Same Condition?
No, pinguecula and pterygium are not the same condition, but they are
both common, non-cancerous growths on the conjunctiva.
A pinguecula is a small yellowish growth on the white of the eye,
and a pterygium is a fleshy tissue that grows over the cornea,
according to the North Shore Eye Centre, Sydney. A pinguecula can
turn into a pterygium in some cases.
## What Does a Pinguecula Look Like Compared to a Pterygium?
A pinguecula stays on the conjunctiva, or white part of the eye,
whereas a pterygium grows over the cornea, the clear surface covering
the coloured part of the eye,
according to the Royal Australian and New Zealand College of
Ophthalmologists (RANZCO). Pinguecula are described as a small,
raised, yellowish bump, whereas a pterygium is described as a pink,
fleshy, triangular-shaped growth. Pterygium also often appears redder
and more inflamed as it has a visible blood supply, whereas pinguecula
does not often have clear blood vessels.
### Where Do These Growths Usually Appear on the Eye?
These growths usually appear on the white part of the eye, called the
conjunctiva. Pinguecula and pterygium most commonly appear on the side of the
eye closest to the nose, but can also appear on the other side.
Pterygium differs from pinguecula in that, although it also starts
growing on the conjunctiva, it extends outwards and grows over the
cornea. Both eyes can be affected by pinguecula and pterygium.
### What Role Does The Conjunctiva Play in Pinguecula and Pterygium?
The
[conjunctiva](https://www.oscarwylee.com.au/glasses/eye/anatomy/conjunctiva)
is the tissue where pinguecula and pterygium grow. The conjunctiva is a thin, clear membrane that covers the inside
of the eyelid, according to the Royal Australian College of General
Practitioners (RACGP). Its role is to protect and cover the eye
surface.
#### Can Both Conditions Affect One Eye or Both Eyes?
Yes, both conditions can affect one
[eye](https://www.oscarwylee.com.au/glasses/eye/anatomy)
or both eyes.
The severity of pinguecula and pterygium may differ between eyes.
When pinguecula and pterygium appear in both eyes, they often
appear simultaneously, as they are due to environmental
factors.
## What Causes Pinguecula and Pterygium?
Pinguecula and pterygium are caused by long-term exposure to UV light and environmental irritants, and may also be caused by chronic dry eye.
The causes of pinguecula and pterygium are explained below.
* UV light: UV light
exposure is the main cause of pinguecula and pterygium. People who
have extended exposure to UV light, such as those who work outdoors,
are at a higher risk of developing these eye growths.
* Environmental irritants:
Environmental irritants such as wind, dust, and dry air can accelerate
the growth of pinguecula and pterygium. Prolonged exposure to these
environmental irritants can dry the eyes out, which promotes the
growth of pinguecula and pterygium.
* Chronic dry eye:
Chronic dry eye can worsen irritation of the eye and promote the
growth of pinguecula and pterygium.
Find Your Nearest OW Store!
We've got knowledgeable teams who are passionate about delivering
high-quality care.
[Find a store](https://www.oscarwylee.com.au/locations/full-store-list.html)
### How Does Sun Exposure Contribute to Their Formation?
Sun exposure contributes to the formation of pinguecula and
pterygium because it causes UV radiation damage to the conjunctiva, which damages
surface eye tissues over time. Sun damage changes the eye tissues gradually over time, meaning
risk increases with prolonged exposure to UV rays. Sun protection,
such as sunglasses, is important to protect your eyes and reduce the
risk of developing eye growths such as pinguecula and
pterygium.
### Why are UV400 Lenses Recommended for Preventing Pinguecula and
Pterygium?
[UV400 lenses](https://www.oscarwylee.com.au/glasses/eye/uv-400-lenses)
are recommended for preventing pinguecula and pterygium because they block almost 100% of UVA and UVB rays,
which protects eye tissues from sun damage. Pinguecula and pterygium
are mainly triggered and worsened by long-term sun exposure; UV400
lenses are recommended to prevent the benign growths.
### Which Sunglasses Styles Provide Better Protection Against UV Exposure?
The sunglasses styles that provide better protection against UV
exposure are wraparound sunglasses, large frame sunglasses, close-fitting
sunglasses, UV400 sunglasses, and polarised UV400 sunglasses. These sunglasses styles that provide better protection against UV
exposure are explained below.
* Wraparound Sunglasses:
Wraparound sunglasses can help reduce sun exposure, preventing UV
rays from entering the sides, top, and bottom, according to Cancer
Council NSW. Oscar Wylee has a range of wraparound style sunglasses,
including our popular
[Stevo frames in Obsidian Matte Black.](https://www.oscarwylee.com.au/stevo-sunglasses.html)
* Large Frame Sunglasses:
Large frame sunglasses help cover more eye area, reducing UV
radiation and glare, according to Cancer Council NSW. Oscar Wylee
has a range of oversized sunglasses, including our popular
[Bale frames in Gilded Tortoise](https://www.oscarwylee.com.au/bale-sunglasses.html).
* Close-Fitting Sunglasses:
Close-fitting sunglasses limit sun exposure, reducing UV radiation
and glare, according to Cancer Council NSW.
* UV400 Sunglasses:
UV400 sunglasses block harmful UV radiation from entering the eyes.
* Polarised UV400 Sunglasses:
Polarised UV400 sunglasses combine glare reduction and UV
protection, according to Cancer Council NSW.
#### Can Dry Eyes Increase the Risk of Developing Pinguecula and
Pterygium?
Yes,
[dry eyes](https://www.oscarwylee.com.au/glasses/eye/dry-eyes) can increase the risk
of developing pinguecula and pterygium. This is due to the
compromised tear film that comes with the condition, which can
lead to friction and micro-inflammation on the eye. This can
accelerate changes to the surface of the eye caused by the
environment.
## What Symptoms Can Help Tell Them Apart?
The symptoms that can help tell them apart may primarily be the involvement of the cornea and appearance. A pterygium can grow over the cornea and affect vision, while a
pinguecula develops on the conjunctiva (the clear layer over the
sclera of the eye) and typically remains there. A pterygium usually
looks like fleshy tissue, and a pinguecula is often characterised by
its yellowish and raised nature. Both of these growths can present
similar symptoms such as
[irritation](https://www.oscarwylee.com.au/glasses/eye/irritation-causes),
[redness](https://www.oscarwylee.com.au/glasses/eye/red-or-bloodshot), inflammation and some discomfort.
#### Does a Pinguecula Always Cause Symptoms?
No, a pinguecula does not always cause symptoms. A pinguecula rarely requires surgical intervention and may only
raise cosmetic concerns. If symptoms of inflammation do arise,
certain types of eye drops are considered effective, according to
Somnath and Tripathy (2023) in their research paper on Pinguecula in
the National Library of Medicine.
[Pinguecula causes](https://www.oscarwylee.com.au/glasses/eye/pinguecula)
can include several factors, including sun exposure, environmental
irritants, chronic dry eye, aging, and contact lens wear.
## How is Pinguecula vs Pterygium Diagnosed?
A pinguecula and pterygium can be diagnosed through a standard eye test with an optometrist.
As part of a routine eye test, a slit-lamp examination can
specifically help identify these growths on the eye. It involves a
special microscope that enables a highly magnified view of the eye's
surface, and an optometrist can then distinguish between them based on
location and appearance.
### What Tests do Eye Doctors Use to Examine these Conditions?
The tests that eye doctors use to examine these conditions can
include a slit-lamp examination, vision testing, corneal assessment and a medical history review.
While eye doctors, also known as ophthalmologists, can examine these
conditions, it may be important to note that optometrists are also
qualified to diagnose and help manage pingueculas and pterygiums.
The tests that eye doctors may use to examine these conditions are
listed below.
* Slit Lamp Examination:
A slit lamp examination can help examine these conditions as it
provides a highly magnified view of the eye's surface.
* Vision Testing:
Vision testing, such as reading off a Snellen chart, allows the eye
doctor to assess your distance vision or can evaluate how light is
bent as it enters your eye.
* Corneal Assessment:
A corneal assessment can help an eye care professional check the
shape and surface to determine corneal health and is typically seen
through a slit-lamp examination.
* Medical History Review:
Your medical history may be brought up to check if you may be at
risk of any systemic conditions and/or to see if other family
members may also have these conditions.
#### Is an Eye Test Usually Enough For Diagnosis?
Yes, an eye exam is usually enough for diagnosis of pinguecula
and pterygium. An optometrist will conduct an
[eye test](https://www.oscarwylee.com.au/glasses/eye/test-glossary), which will enable them to identify any abnormal growths on the
surface of the eye.
Testing methods such as a slit-lamp examination will provide
optometrists with a 3D view of the eye's internal and external
structures.
## How are Pinguecula and Pterygium Treated?
Pinguecula and pterygium may be treated through certain types of eye drops or managed with protective
eyewear
to focus on alleviating symptoms and preventing further damage. A
pinguecula and pterygium may only require eye drops in their early
stages. Surgical removal of a pterygium may only be conducted if the
growth becomes painful, affects blinking function or changes your
cornea shape.
### How Can Good Eye Care Habits Help Prevent Pinguecula and Pterygium?
Good eye care habits may help prevent pinguecula and pterygium as
they focus on protecting the eyes from excessive UV exposure. Good
eye care habits such as wearing sunglasses, wearing hats or limiting sun exposure
may help reduce the risk of developing pinguecula and pterygium.
This is because the condition may be associated with repeated
exposure to UV radiation. The condition is considered more common in
those who spend lots of time outdoors, such as surfers, trade
workers and farmers, according to Australia Wide First Aid.
### Which Treatments Can Relieve Discomfort and Inflammation From
Pinguecula and Pterygium?
The treatments that can relieve discomfort and inflammation from
pinguecula and pterygium may include artificial tears, lubricating ointments, anti-inflammatory drops,
cold compresses, and environmental protection.
The treatments that may relieve discomfort and inflammation from
pinguecula and pterygium are listed below.
* Artificial Tears:
Artificial tears may relieve discomfort and inflammation from
pinguecula and pterygium during their early stages by adding more
lubrication to the eye. This can help reduce friction and
inflammation.
* Lubricating Ointments:
Lubricating ointments can also aid with discomfort and inflammation
from pinguecula and pterygium as they help restore lost moisture and
lessen any friction when blinking.
* Anti-Inflammatory Drops:
Anti-inflammatory eye drops may be used to relieve discomfort and
inflammation from pinguecula and pterygium, as they can disrupt the
body's inflammatory response and work to reduce swelling, redness
and any burning.
* Cold Compresses: A
cold compress may help relieve discomfort and inflammation from
pinguecula and pterygium, as it can aid in constricting the blood
vessels, slowing down fluid build-up, which is what causes the
swelling.
* Environmental Protection:
Environmental protection may refer to avoiding exposure to
pollutants in the air and excessive chemicals, which can help
prevent further irritation.
#### Is Surgery Necessary in Every Case For a Pinguecula and Pterygium?
No, surgery may not be necessary for every case of a pinguecula and
pterygium.
The most suitable treatment will depend on the severity of your
condition.
## What Complications and Long-Term Outcomes Should You Know About
Pinguecula and Pterygium?
The complications and long-term outcomes that you should know about
pinguecula and pterygium can include persistent irritation, growth progression, cosmetic concerns and
recurrence.
The complications and long-term outcomes you should know about
pinguecula and pterygium are listed below.
* Persistent Irritation:
Persistent irritation can be a complication of pinguecula and
pterygium. A pinguecula can cause irritation in the eye due to its
raised surface, which can affect the way tears spread across the eye
and cause irritation. A pterygium can bring on irritation as it can
disrupt the tear film in the eye, with its raised surface leading to
localised dry spots and persistent discomfort.
* Growth Progression:
The growth progression for a pinguecula and pterygium is considered
slow. A pinguecula may start off as built-up protein or calcium
underneath the conjunctiva to a raised yellowish bump on the sclera. A
pterygium may start off as a small and flat wedge-shaped growth on the
conjunctiva, which can then extend over to the cornea.
* Cosmetic Concerns:
The cosmetic concerns for a pinguecula may be due to its yellowish
appearance and increased redness. A pterygium can raise cosmetic
concerns as it can show distinctly and appears very visibly red.
* Recurrence:
Recurrence can be a complication of pinguecula and pterygium even
after surgical removal.
### When Can a Pterygium Become More Serious than a Pinguecula?
A pterygium may become more serious than a pinguecula if it grows extensively to the point of reaching the cornea.
However, it may be important to note that a pinguecula is not
necessarily a worse condition than a pterygium, as it doesn't affect
your vision.
#### Can a Pinguecula Cause Blindness?
No, a pinguecula does not cause blindness. This benign and non-cancerous yellowish bump develops over the
conjunctiva and does not typically grow beyond the conjunctiva,
according to Healthline.
It is important to note that Oscar Wylee offers optometry services
only; this article is for educational purposes only and is not a
substitute for professional medical advice, diagnosis, or
treatment.
Experience High Quality Eyecare Services From Our Team
Book an appointment online with an Oscar Wylee optometrist today.
[Book an eye test](https://www.oscarwylee.com.au/booking)
Major Health Funds Accepted In-store
For the purchase of frames and lenses, use your private health fund to
limit how much you pay from your own pocket.
[Health Funds](https://www.oscarwylee.com.au/health-funds.html)