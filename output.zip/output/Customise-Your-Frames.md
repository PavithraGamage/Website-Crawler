# Source: https://www.oscarwylee.com.au/customise-your-frames/

# Customise Your Frames
Oscar Wylee’s customisation options give you the freedom to tailor your
look, ensuring your frames are as unique as your personality and tailored
specifically to your vision needs. Choose from our versatile range of
optical glasses and sunglasses, then personalise your pair from a selection
of lenses and premium add-ons.
[Book an eye test](https://www.oscarwylee.com.au/booking)
## Design Your Glasses
### Frames
Aviator
Oversized
Oval
Cat Eye
Browline
Geometric
Rectangle
Square
### Lenses
Polarised
Transitions®
GEN S™
Mirror Tint
Lolly Tint
Gradient Tint
Green Tint
### Add-ons
Premium Anti-
Reflective
BLULite Filter
Thinner Lenses
BLULite Filter
Premium
Frame size matters. To ensure total comfort and a great look, our team
will guide you to the right customisations for your specific face
width.Disclaimer: Not all lens types, tints,
and add-ons can be combined; individual compatibility depends on your
unique prescription and frame selection. Subject to availability.
Prescription options require a valid prescription. Additional costs may
apply for premium lens upgrades and add-ons.
[Find Your Nearest Store](https://www.oscarwylee.com.au/locations)
## See How Others Personalised Their Pair
Mumford
personalised with
Colour: Bare
Lenses: Yellow Lolly Tint
Add-on: Premium Anti-Reflective
[Shop Mumford](https://www.oscarwylee.com.au/mumford-optical.html)
Hailey
personalised with
Colour: Cioccolato
Lenses: Brown Polarisation
Add-on: Thinner Lenses 1.67
[Shop Hailey](https://www.oscarwylee.com.au/hailey-optical.html)
Jinky
personalised with
Colour: Storm
Lenses: Silver Mirror Tint
Add-on: Premium Anti-Reflective
[Shop Jinky](https://www.oscarwylee.com.au/jinky-optical.html)
Serge
personalised with
Colour: Crystal Clear
Lenses: Pink Lolly Tint
Add-on: Thinner Lenses 1.61
[Shop Serge](https://www.oscarwylee.com.au/serge-optical.html)
Duckworth
personalised with
Colour: Seaside
Lenses:
Transitions® GEN S™
Lenses
Add-on: Anti-Reflective
[Shop Duckworth](https://www.oscarwylee.com.au/duckworth-optical.html)
Tia
personalised with
Colour: Contemporary Tortoise
Lenses: Elite Multifocal Lenses
Add-on: Anti-Reflective + Thinner
Lenses
[Shop Tia](https://www.oscarwylee.com.au/tia-optical.html)
## Personalise Further With Popular Add-ons
#### Premium Anti-Reflective
+$50
With increased clarity, scratch and smudge resistance, and
anti-static, our Premium Anti-Reflective add-on is a no-brainer.
#### BLULite Filter Premium
+$95
Support your eyes during screen time with our BLULite filter Premium,
developed to reduce digital eye strain and help support healthier
sleep habits.
#### Thinner Lenses
Starting from $110
Our thinner lens options include Extra Thin, Super Thin, and Ultimate
Thin to provide maximum comfort and a natural aesthetic for stronger
prescriptions.
Disclaimer: Standard frames including standard
single-vision lenses start from $169. Component add-on pricing is
additional to the base frame price. The minimum total cost for a frame
with a Premium Anti-Reflective add-on is $219; with a BLULite Filter
Premium is $264; and with Thinner Lenses is $279.
### Discover Your Signature Style
Want to learn more about custom frame options? We've got you
covered.
[Learn More](https://www.oscarwylee.com.au/glasses/custom-or-personalised)
[Visit Your Nearest Store](https://www.oscarwylee.com.au/locations)
## Discover Our Range And Find Your Perfect Pair
Glasses Range
[Explore Now](https://www.oscarwylee.com.au/glasses.html)
Sunglasses Range
[Explore Now](https://www.oscarwylee.com.au/sunglasses.html)
Book an eye test near you
[search](https://www.oscarwylee.com.au/booking)
[Book appointment](https://www.oscarwylee.com.au/booking/)
Show All
### Can I still customise my frames if I do not have a prescription?
Yes! You don't need a prescription to look stylish and protect
your eyes. Many of our customers choose non-prescription glasses
and customise them with a BluLite filter for screen time, or
upgrade their sunglasses with polarised lenses for superior
glare reduction.
### Can I customise my frames online?
Yes and no, you can choose most customisation options online,
but to experience our full range of add-ons, such as mirror and
lolly tints, you will need to visit one of our stores. You can
select a variety of our popular customisation options online,
including:
* Distance, reading, multifocal, and non-prescription lenses
* Lens thickness upgrades (high-index)
* Sunglass tints, including gradient tints, and polarised tints
(grey, brown, and green)
* Photochromic and Transitions® lenses
* Premium anti-reflective lenses
* Blue light filter/Blue light filter premium lenses
### What are the colour options for tints?
We offer a vibrant palette of tint options to match your vibe.
Our tints are categorised into 3 styles: sunglass tints, mirror
tints, and fashion tints. The colour options for each of these
categories are listed below.
* Sunglass tints: Available in grey, brown, and green. Perfect
for everyday sun protection.
* Mirror tints: Available in pink, blue, silver, and orange. For
a bold, reflective look that blocks intense glare.
* Fashion tints: Available in yellow, blue, red and pink. A
subtle, lifestyle tint for the colour obsessed.
### Can I customise kids’ frames?
Yes! Children can absolutely customise their Oscar Wylee frames.
Our kids' range can be upgraded with specialised options,
including impact-resistant lens thicknesses, anti-reflective
coatings, and BluLite filters for screen time. We also offer
photochromic and Transitions® lenses that adapt to changing
light. Just like our adult range, our full range of kids'
customisation options is available in-store.
### Can I return my customised glasses?
Because customised and prescription lenses are tailored
specifically to your unique optical needs, we cannot accept
returns or exchanges for a change of mind. All Oscar Wylee
glasses come with guarantees that cannot be excluded under the
Australian Consumer Law. You are entitled to a replacement or
refund for a major failure and compensation for any other
reasonably foreseeable loss or damage. You can view our full
returns policy on our website
[here](https://www.oscarwylee.com.au/legal/terms-and-conditions.html).